

# Page 1

Bleeding Situations
First Module -
1
GI Mentor
The module is designed to provide skilled endoscopists, trainees and nurses 
with a training model for emergency bleeding situations that require an 
urgent treatment.
The module objectives are:
	
 Performing complete survey of the upper GI tract throughout an 
emergency endoscopy.
	
 Performing diagnostic procedures in “patients” with symptoms of 
bleeding lesions.
	
 Performing therapeutic procedures using a variety of appropriate 
accessories (tools) intended for bleeding pathologies.
The module consists of 10 cases which include all the indicated training 
objectives. The cases were created by Dr. Sven Adamsen and Dr. Søren 
Meisner, Bispebjerg Hospital, Copenhagen, Denmark.


[TABLE]
| Bleeding Situations                                                         |
|:----------------------------------------------------------------------------|
| The module is designed to provide skilled endoscopists, trainees and nurses |
| with a training model for emergency bleeding situations that require an     |
| urgent treatment.                                                           |
| The module objectives are:                                                  |
|  Performing complete survey of the upper GI tract throughout an                                                                             |
| emergency endoscopy.                                                        |
|  Performing diagnostic procedures in “patients” with symptoms of                                                                             |
| bleeding lesions.                                                           |
|  Performing therapeutic procedures using a variety of appropriate                                                                             |
| accessories (tools) intended for bleeding pathologies.                      |
| The module consists of 10 cases which include all the indicated training    |
| objectives. The cases were created by Dr. Sven Adamsen and Dr. Søren        |
| Meisner, Bispebjerg Hospital, Copenhagen, Denmark.                          |

[OCR]
First Module -
Bleeding Situations Y

The module is designed to provide skilled endoscopists, trainees and nurses
with a training model for emergency bleeding situations that require an
urgent treatment.

The module objectives are:

= Performing complete survey of the upper GI tract throughout an
emergency endoscopy.

= Performing diagnostic procedures in “patients” with symptoms of
bleeding lesions.

= Performing therapeutic procedures using a variety of appropriate
accessories (tools) intended for bleeding pathologies.

The module consists of 10 cases which include all the indicated training

objectives. The cases were created by Dr. Sven Adamsen and Dr. Seren

Meisner, Bispebjerg Hospital, Copenhagen, Denmark.

surgical GI Mentor


# Page 2

Bleeding Situations
First Module -
2
GI Mentor
1
Anatomy:  
Bleeding ulcer (Forrest IB) on the lesser curve above the angulus.
Medical History: 
A 64-year-old female arrived at the Emergency Room due to hematemesis. 
She had vomited once with fresh blood at home and then called the 
ambulance. Upon her arrival at the hospital, she is awake but pale. The blood 
pressure is 130/60 mmHg, and the pulse rate is 112/min. A nasogastric tube 
was passed, and it retrieved clots of red blood mixed with clear aspirate.
Biological Tests:
Hemoglobin:	
 78 g/L 	 (120-150) 
Hematocrit: 	
34% 	
(36-48)
She was referred for gastroscopy. Immediately prior to endoscopy, the 
stomach was cleared via the nasogastric tube.
Comments: 
This ulcer can be seen without retroflexion of the scope. The clot should 
be removed by irrigation, after which a dark spot will be seen in the ulcer’s 
base.It should be injected with epinephrine 1:10.000, approximately a 1 
mL/injection, and afterwards, coagulation is performed using a Bipolar 
Coagulation Probe.Biopsies for identification of H. Pylori should be taken from 
the antrum. Taking biopsies from the ulcer is contraindicated; this is done 
later at follow-up.
Case 1 
Bleeding ulcer


[TABLE]
|                                                                                 |                    |
|:--------------------------------------------------------------------------------|:-------------------|
| 1                                                                               | Case 1             |
| Anatomy:                                                                        |                    |
| Bleeding ulcer (Forrest IB) on the lesser curve above the angulus.              |                    |
| Medical History:                                                                |                    |
| A 64-year-old female arrived at the Emergency Room due to hematemesis.          |                    |
| She had vomited once with fresh blood at home and then called the               |                    |
| ambulance. Upon her arrival at the hospital, she is awake but pale. The blood   |                    |
| pressure is 130/60 mmHg, and the pulse rate is 112/min. A nasogastric tube      |                    |
| was passed, and it retrieved clots of red blood mixed with clear aspirate.      |                    |
| Biological Tests:                                                               |                    |
| Hemoglobin:                                                                     | 78 g/L   (120-150) |
| Hematocrit:                                                                     | 34%                |
|                                                                                 | (36-48)            |
| She was referred for gastroscopy. Immediately prior to endoscopy, the           |                    |
| stomach was cleared via the nasogastric tube.                                   |                    |
| Comments:                                                                       |                    |
| This ulcer can be seen without retroflexion of the scope. The clot should       |                    |
| be removed by irrigation, after which a dark spot will be seen in the ulcer’s   |                    |
| base.It should be injected with epinephrine 1:10.000, approximately a 1         |                    |
| mL/injection, and afterwards, coagulation is performed using a Bipolar          |                    |
| Coagulation Probe.Biopsies for identification of H. Pylori should be taken from |                    |
| the antrum. Taking biopsies from the ulcer is contraindicated; this is done     |                    |
| later at follow-up.                                                             |                    |

[OCR_TABLE]
DICE

[OCR]
First Module -
Bleeding Situations Y

Case 1

Anatomy:
Bleeding ulcer (Forrest IB) on the lesser curve above the angulus.

Medical History:

A 64-year-old female arrived at the Emergency Room due to hematemesis.
She had vomited once with fresh blood at home and then called the
ambulance. Upon her arrival at the hospital, she is awake but pale. The blood
pressure is 130/60 mmHg, and the pulse rate is 112/min. A nasogastric tube
was passed, and it retrieved clots of red blood mixed with clear aspirate.

Biological Tests:

Hemoglobin: 78 g/L (120-150)
Hematocrit: 34% (36-48)

She was referred for gastroscopy. Immediately prior to endoscopy, the
stomach was cleared via the nasogastric tube.

Comments:

This ulcer can be seen without retroflexion of the scope. The clot should

be removed by irrigation, after which a dark spot will be seen in the ulcer’s
base.It should be injected with epinephrine 1:10.000, approximately a 1
mL/injection, and afterwards, coagulation is performed using a Bipolar
Coagulation Probe.Biopsies for identification of H. Pylori should be taken from
the antrum. Taking biopsies from the ulcer is contraindicated; this is done
later at follow-up.

Bleeding ulcer

surgical GI Mentor


# Page 3

Bleeding Situations
First Module -
3
GI Mentor
2
Anatomy: 
Ulcer with a clot (Forrest IIB) on lesser curve below the angulus.
Medical History: 
A 62-year-old female complaining of fatigue and dizziness for the last 2 days. 
Her family doctor found anemia and referred her to the hospital on suspicion 
of gastrointestinal bleeding. On her arrival at the hospital, she was pale without 
signs of circulatory instability. A nasogastric tube was passed retrieving clear 
aspirate mixed with “coffee grounds.”
Biological Tests: 
Hemoglobin:	
70 g/L	 (120-150) 
Hematocrit:	
30%	
(36-48)
She was scheduled for gastroscopy the following morning.
Comments: 
Retroflexion may be required to identify and treat an ulcer below the angulus. 
The clot should be removed by irrigation, after which a dark spot will be 
seen in the ulcer’s base. It should be injected with epinephrine 1:10.000, 
approximately a 1 mL/injection, and afterwards coagulation is performed 
using a bipolar coagulation probe. If the clot cannot be completely removed 
by irrigation: Irrigate away as much as possible, then inject with epinephrine 
1:10.000, approximately a 1 mL/injection into the quadrates of the clot.
Afterwards, remove the remainder of the clot by cold snare, and then treat the 
ulcer as described previously. Biopsies for identification of H. Pylori should be 
taken from the antrum. Taking biopsies from the ulcer itself is contraindicated; 
this is done later at follow-up.
Case 2 
Ulcer with a clot


[TABLE]
|                                                                                    |        |           |
|:-----------------------------------------------------------------------------------|:-------|:----------|
| 2                                                                                  | Case 2 |           |
| Anatomy:                                                                           |        |           |
| Ulcer with a clot (Forrest IIB) on lesser curve below the angulus.                 |        |           |
| Medical History:                                                                   |        |           |
| A 62-year-old female complaining of fatigue and dizziness for the last 2 days.     |        |           |
| Her family doctor found anemia and referred her to the hospital on suspicion       |        |           |
| of gastrointestinal bleeding. On her arrival at the hospital, she was pale without |        |           |
| signs of circulatory instability. A nasogastric tube was passed retrieving clear   |        |           |
| aspirate mixed with “coffee grounds.”                                              |        |           |
| Biological Tests:                                                                  |        |           |
| Hemoglobin:                                                                        | 70 g/L | (120-150) |
| Hematocrit:                                                                        | 30%    | (36-48)   |
| She was scheduled for gastroscopy the following morning.                           |        |           |
| Comments:                                                                          |        |           |
| Retroflexion may be required to identify and treat an ulcer below the angulus.     |        |           |
| The clot should be removed by irrigation, after which a dark spot will be          |        |           |
| seen in the ulcer’s base. It should be injected with epinephrine 1:10.000,         |        |           |
| approximately a 1 mL/injection, and afterwards coagulation is performed            |        |           |
| using a bipolar coagulation probe. If the clot cannot be completely removed        |        |           |
| by irrigation: Irrigate away as much as possible, then inject with epinephrine     |        |           |
| 1:10.000, approximately a 1 mL/injection into the quadrates of the clot.           |        |           |
| Afterwards, remove the remainder of the clot by cold snare, and then treat the     |        |           |
| ulcer as described previously. Biopsies for identification of H. Pylori should be  |        |           |
| taken from the antrum. Taking biopsies from the ulcer itself is contraindicated;   |        |           |
| this is done later at follow-up.                                                   |        |           |

[OCR_TABLE]
DICC

[OCR]
First Module -
Bleeding Situations Y

Case 2

Anatomy:
Ulcer with a clot (Forrest IIB) on lesser curve below the angulus.

Medical History:

A 62-year-old female complaining of fatigue and dizziness for the last 2 days.
Her family doctor found anemia and referred her to the hospital on suspicion
of gastrointestinal bleeding. On her arrival at the hospital, she was pale without
signs of circulatory instability. A nasogastric tube was passed retrieving clear
aspirate mixed with “coffee grounds.”

Biological Tests:
Hemoglobin: 70 g/L (120-150)
Hematocrit: 30% (36-48)

She was scheduled for gastroscopy the following morning.

Comments:

Retroflexion may be required to identify and treat an ulcer below the angulus.
The clot should be removed by irrigation, after which a dark spot will be

seen in the ulcer’s base. It should be injected with epinephrine 1:10.000,
approximately a1 mL/injection, and afterwards coagulation is performed
using a bipolar coagulation probe. If the clot cannot be completely removed
by irrigation: Irrigate away as much as possible, then inject with epinephrine
1:10.000, approximately a 1 mL/injection into the quadrates of the clot.
Afterwards, remove the remainder of the clot by cold snare, and then treat the
ulcer as described previously. Biopsies for identification of H. Pylori should be
taken from the antrum. Taking biopsies from the ulcer itself is contraindicated;
this is done later at follow-up.

Ulcer with a clot

surgical GI Mentor


# Page 4

Bleeding Situations
First Module -
4
GI Mentor
3
Anatomy: 
Bleeding ulcer (Forrest IA) on lesser curve above the angulus.
Medical History: 
A 55-year-old male has fainted at work and was referred to the Emergency 
Room. On his arrival, he is awake, pale, and sweating with a pulse of 120/
min and a systolic blood pressure of 90/? mmHg (diastolic blood pressure is 
unmeasurable). In the nasogastric tube, there is bright red blood, and on rectal 
examination, there is dark tarry stool.
Biological Tests: 
Hemoglobin:	
57 g/L	 (139-163) 
Hematocrit:	
22%	
(39-55)
After stabilizing the patient, he was referred for gastroscopy.
Comments: 
A potentially stressful situation for the endoscopist as there is prolific spurting 
from the artery, and the view may be hampered because of “redout.” Active 
irrigation and target injection are important in order to achieve effective 
hemostasis.
Case 3
Bleeding ulcer


[TABLE]
|                                                                                     |        |           |
|:------------------------------------------------------------------------------------|:-------|:----------|
| 3                                                                                   | Case 3 |           |
| Anatomy:                                                                            |        |           |
| Bleeding ulcer (Forrest IA) on lesser curve above the angulus.                      |        |           |
| Medical History:                                                                    |        |           |
| A 55-year-old male has fainted at work and was referred to the Emergency            |        |           |
| Room. On his arrival, he is awake, pale, and sweating with a pulse of 120/          |        |           |
| min and a systolic blood pressure of 90/? mmHg (diastolic blood pressure is         |        |           |
| unmeasurable). In the nasogastric tube, there is bright red blood, and on rectal    |        |           |
| examination, there is dark tarry stool.                                             |        |           |
| Biological Tests:                                                                   |        |           |
| Hemoglobin:                                                                         | 57 g/L | (139-163) |
| Hematocrit:                                                                         | 22%    | (39-55)   |
| After stabilizing the patient, he was referred for gastroscopy.                     |        |           |
| Comments:                                                                           |        |           |
| A potentially stressful situation for the endoscopist as there is prolific spurting |        |           |
| from the artery, and the view may be hampered because of “redout.” Active           |        |           |
| irrigation and target injection are important in order to achieve effective         |        |           |
| hemostasis.                                                                         |        |           |

[OCR_TABLE]
DICC

[OCR]
First Module -
Bleeding Situations Y

Case 3

Anatomy:
Bleeding ulcer (Forrest IA) on lesser curve above the angulus.

Medical History:

A 55-year-old male has fainted at work and was referred to the Emergency
Room. On his arrival, he is awake, pale, and sweating with a pulse of 120/

min and a systolic blood pressure of 90/? mmHg (diastolic blood pressure is
unmeasurable). In the nasogastric tube, there is bright red blood, and on rectal
examination, there is dark tarry stool.

Biological Tests:
Hemoglobin: 57 g/L (139-163)
Hematocrit: 22% (39-55)

After stabilizing the patient, he was referred for gastroscopy.

Comments:

A potentially stressful situation for the endoscopist as there is prolific spurting
from the artery, and the view may be hampered because of “redout.” Active
irrigation and target injection are important in order to achieve effective
hemostasis.

Bleeding ulcer

surgical GI Mentor


# Page 5

Bleeding Situations
First Module -
5
GI Mentor
4
Anatomy: 
A Dieulafoy’s lesion below the cardia on lesser curve.
Medical History: 
A 56-year-old male felt ill at work and then he vomited red blood. Shortly 
afterwards, he arrived at the Emergency Room. On his admission, he was 
stable.
Biological Tests: 
Hemoglobin	
117 g/L	 (139-163) 
Hematocrit:	
42%	
(39-55)
Comments: 
A bleeding Dieulafoy’s lesion is treated like a peptic ulcer. It should be injected 
with epinephrine 1:10.000, approximately a 1 mL/injection, and afterwards 
coagulation is performed using a bipolar coagulation probe. Clips can be used 
as an alternative to injection and coagulation.
Case 4
Dieulafoy’s lesion


[TABLE]
|                                                                                     |         |           |
|:------------------------------------------------------------------------------------|:--------|:----------|
| 4                                                                                   | Case 4  |           |
| Anatomy:                                                                            |         |           |
| A Dieulafoy’s lesion below the cardia on lesser curve.                              |         |           |
| Medical History:                                                                    |         |           |
| A 56-year-old male felt ill at work and then he vomited red blood. Shortly          |         |           |
| afterwards, he arrived at the Emergency Room. On his admission, he was              |         |           |
| stable.                                                                             |         |           |
| Biological Tests:                                                                   |         |           |
| Hemoglobin                                                                          | 117 g/L | (139-163) |
| Hematocrit:                                                                         | 42%     | (39-55)   |
| Comments:                                                                           |         |           |
| A bleeding Dieulafoy’s lesion is treated like a peptic ulcer. It should be injected |         |           |
| with epinephrine 1:10.000, approximately a 1 mL/injection, and afterwards           |         |           |
| coagulation is performed using a bipolar coagulation probe. Clips can be used       |         |           |
| as an alternative to injection and coagulation.                                     |         |           |

[OCR]
First Module -
Bleeding Situations Y

Case 4

Anatomy:
A Dieulafoy’s lesion below the cardia on lesser curve.

Medical History:

A 56-year-old male felt ill at work and then he vomited red blood. Shortly
afterwards, he arrived at the Emergency Room. On his admission, he was
stable.

Biological Tests:
Hemoglobin 117 g/L (139-163)
Hematocrit: 42% (39-55)

Comments:

A bleeding Dieulafoy’s lesion is treated like a peptic ulcer. It should be injected
with epinephrine 1:10.000, approximately a 1 mL/injection, and afterwards
coagulation is performed using a bipolar coagulation probe. Clips can be used
as an alternative to injection and coagulation.

Dieulafoy’s lesion

surgical GI Mentor


# Page 6

Bleeding Situations
First Module -
6
GI Mentor
5
Anatomy: 
A Mallory-Weiss tear in the stomach below the cardia. A small hiatal hernia.
Medical History: 
A 42-year-old female with moderate alcohol abuse has vomited five times. She 
then has hematemesis with red blood. Upon her arrival to the hospital, she is 
sweating, pale, and agitated with a pulse of 124/min and a blood pressure of 
110/60 mmHg.
Biological Tests: 
Hemoglobin:	
135 g/L	 (120-150) 
Hematocrit:	
50%	
(36-48)
Comments: 
Retroflexion is necessary to diagnose and treat this lesion. A bleeding 
Mallory-Weiss tear is treated like a bleeding peptic ulcer by injections and 
coagulations. It should be injected with epinephrine 1:10.000, approximately 
a 1 mL/injection, and afterwards coagulation is performed using a bipolar 
coagulation probe. Clips can be used as an alternative.
Case 5
Mallory-Weiss Tear


[TABLE]
|                                                                               |                    |
|:------------------------------------------------------------------------------|:-------------------|
| 5                                                                             | Case 5             |
| Anatomy:                                                                      |                    |
| A Mallory-Weiss tear in the stomach below the cardia. A small hiatal hernia.  |                    |
| Medical History:                                                              |                    |
| A 42-year-old female with moderate alcohol abuse has vomited five times. She  |                    |
| then has hematemesis with red blood. Upon her arrival to the hospital, she is |                    |
| sweating, pale, and agitated with a pulse of 124/min and a blood pressure of  |                    |
| 110/60 mmHg.                                                                  |                    |
| Biological Tests:                                                             |                    |
| Hemoglobin:                                                                   | 135 g/L  (120-150) |
| Hematocrit:                                                                   | 50%                |
|                                                                               | (36-48)            |
| Comments:                                                                     |                    |
| Retroflexion is necessary to diagnose and treat this lesion. A bleeding       |                    |
| Mallory-Weiss tear is treated like a bleeding peptic ulcer by injections and  |                    |
| coagulations. It should be injected with epinephrine 1:10.000, approximately  |                    |
| a 1 mL/injection, and afterwards coagulation is performed using a bipolar     |                    |
| coagulation probe. Clips can be used as an alternative.                       |                    |

[OCR_TABLE]
DICC

[OCR]
First Module -
Bleeding Situations Y

Case 5

Anatomy:
A Mallory-Weiss tear in the stomach below the cardia. A small hiatal hernia.

Medical History:

A 42-year-old female with moderate alcohol abuse has vomited five times. She
then has hematemesis with red blood. Upon her arrival to the hospital, she is
sweating, pale, and agitated with a pulse of 124/min and a blood pressure of
110/60 mmHg.

Biological Tests:
Hemoglobin: 135 g/L (120-150)
Hematocrit: 50% (36-48)

Comments:

Retroflexion is necessary to diagnose and treat this lesion. A bleeding
Mallory-Weiss tear is treated like a bleeding peptic ulcer by injections and
coagulations. It should be injected with epinephrine 1:10.000, approximately
a1mL/injection, and afterwards coagulation is performed using a bipolar
coagulation probe. Clips can be used as an alternative.

Mallory-Weiss Tear

surgical GI Mentor


# Page 7

Bleeding Situations
First Module -
7
GI Mentor
6
Anatomy: 
Small cancer below the cardia.
Medical History: 
A 71-year-old male has felt weak and tired for the past 2 months. He has lost 
3 kg, but his bowel habits are normal. His family doctor has referred him for 
gastroscopy because of tarry stools and anemia.
Biological Tests: 
Hemoglobin:	
72 g/L	 (139-163) 
Hematocrit:	
35%	
(39-55)
Comments: 
Retroflexion is necessary to diagnose and treat bleeding from a tumor at or 
near the cardia. Irrigation and coagulation should be performed in order to 
control bleeding. Injection is usually not helpful due to the diffuse nature of the 
bleeding. Avoid taking a biopsy during the active bleeding phase.
Case 6
Small cancer


[TABLE]
|                                                                                     |        |           |
|:------------------------------------------------------------------------------------|:-------|:----------|
| 6                                                                                   | Case 6 |           |
| Anatomy:                                                                            |        |           |
| Small cancer below the cardia.                                                      |        |           |
| Medical History:                                                                    |        |           |
| A 71-year-old male has felt weak and tired for the past 2 months. He has lost       |        |           |
| 3 kg, but his bowel habits are normal. His family doctor has referred him for       |        |           |
| gastroscopy because of tarry stools and anemia.                                     |        |           |
| Biological Tests:                                                                   |        |           |
| Hemoglobin:                                                                         | 72 g/L | (139-163) |
| Hematocrit:                                                                         | 35%    | (39-55)   |
| Comments:                                                                           |        |           |
| Retroflexion is necessary to diagnose and treat bleeding from a tumor at or         |        |           |
| near the cardia. Irrigation and coagulation should be performed in order to         |        |           |
| control bleeding. Injection is usually not helpful due to the diffuse nature of the |        |           |
| bleeding. Avoid taking a biopsy during the active bleeding phase.                   |        |           |

[OCR]
First Module -
Bleeding Situations Y

Case 6

Anatomy:
Small cancer below the cardia.

Medical History:

A 71-year-old male has felt weak and tired for the past 2 months. He has lost
3 kg, but his bowel habits are normal. His family doctor has referred him for
gastroscopy because of tarry stools and anemia.

Biological Tests:
Hemoglobin: 72 g/L (139-163)
Hematocrit: 35% (39-55)

Comments:

Retroflexion is necessary to diagnose and treat bleeding from a tumor at or
near the cardia. Irrigation and coagulation should be performed in order to
control bleeding. Injection is usually not helpful due to the diffuse nature of the
bleeding. Avoid taking a biopsy during the active bleeding phase.

Small cancer

surgical GI Mentor


# Page 8

Bleeding Situations
First Module -
8
GI Mentor
7
Anatomy: 
Ulcer in the posterior wall (Forrest IB) of the duodenal bulb.
Medical History: 
A 74-year-old female with hypertension being treated with NSAID has had thin 
black tarry stools for 8-10 hours. On her admittance to the Emergency Room, 
she is awake but pale with a blood pressure of 120/70 mmHg and a pulse rate 
of 104/min. A nasogastric tube was passed, the aspirate was clear. Rectal 
examination: Black tarry stools. She was referred for gastroscopy.
Biological Tests: 
Hemoglobin:	
91 g/L	
(120-150) 
Hematocrit:	
32%	
(36-48)
Comments: 
In a patient with a bleeding duodenal ulcer, there may be no blood in the 
stomach. Treatment: Irrigation and removal of clot, injection with epinephrine 
1:10.000 approximately a 1 mL/injection, and afterwards coagulation is 
performed using a bipolar coagulation probe.
Case 7
Duodenal ulcer


[TABLE]
|                                                                                |        |           |
|:-------------------------------------------------------------------------------|:-------|:----------|
| 7                                                                              | Case 7 |           |
| Anatomy:                                                                       |        |           |
| Ulcer in the posterior wall (Forrest IB) of the duodenal bulb.                 |        |           |
| Medical History:                                                               |        |           |
| A 74-year-old female with hypertension being treated with NSAID has had thin   |        |           |
| black tarry stools for 8-10 hours. On her admittance to the Emergency Room,    |        |           |
| she is awake but pale with a blood pressure of 120/70 mmHg and a pulse rate    |        |           |
| of 104/min. A nasogastric tube was passed, the aspirate was clear. Rectal      |        |           |
| examination: Black tarry stools. She was referred for gastroscopy.             |        |           |
| Biological Tests:                                                              |        |           |
| Hemoglobin:                                                                    | 91 g/L | (120-150) |
| Hematocrit:                                                                    | 32%    | (36-48)   |
| Comments:                                                                      |        |           |
| In a patient with a bleeding duodenal ulcer, there may be no blood in the      |        |           |
| stomach. Treatment: Irrigation and removal of clot, injection with epinephrine |        |           |
| 1:10.000 approximately a 1 mL/injection, and afterwards coagulation is         |        |           |
| performed using a bipolar coagulation probe.                                   |        |           |

[OCR_TABLE]
DICC

[OCR]
First Module -
Bleeding Situations Y

Case 7

Anatomy:
Ulcer in the posterior wall (Forrest IB) of the duodenal bulb.

Medical History:

A 74-year-old female with hypertension being treated with NSAID has had thin
black tarry stools for 8-10 hours. On her admittance to the Emergency Room,
she is awake but pale with a blood pressure of 120/70 mmHg and a pulse rate
of 104/min. A nasogastric tube was passed, the aspirate was clear. Rectal
examination: Black tarry stools. She was referred for gastroscopy.

Biological Tests:
Hemoglobin: 91g/L (120-150)
Hematocrit: 32% (36-48)

Comments:

In a patient with a bleeding duodenal ulcer, there may be no blood in the
stomach. Treatment: Irrigation and removal of clot, injection with epinephrine
1:10.000 approximately a 1 mL/injection, and afterwards coagulation is
performed using a bipolar coagulation probe.

Duodenal ulcer

surgical GI Mentor


# Page 9

Bleeding Situations
First Module -
9
GI Mentor
8
Anatomy: 
Ulcer in the posterior wall (Forrest IA) of the duodenal bulb.
Medical History: 
A 67-year-old male suffered a coronary infarction 1 year ago, and is treated 
with low dose ASA. He woke up in the middle of the night vomiting red blood. 
Upon admission to the ER, he presents with hematochezia, blood pressure 
85/? mmHg (diastolic blood pressure is unmeasurable), the pulse is 116/
min and weak. After initial intravenous hydration, the condition stabilizes. A 
nasogastric tube is passed retrieving bright red blood mixed with darker clots. 
Rectal examination shows dark red blood.
Biological Tests: 
Hemoglobin:	
63 g/L	 (139-163) 
Hematocrit:	
21%	
(39-55)
He was referred for gastroscopy. Immediately prior to endoscopy, the stomach 
was cleared via the nasogastric tube, resulting in clear aspirate.
Comments: 
Pre-endoscopy irrigation is very helpful to clear the stomach of clots, making 
the procedure easier and reducing the risk of clots obstructing the suction 
channel. Treatment: Irrigation, injection, and coagulation.
Case 8
Duodenal ulcer


[TABLE]
|                                                                                |                                                                                 |           |
|:-------------------------------------------------------------------------------|:--------------------------------------------------------------------------------|:----------|
| 8                                                                              | Case 8                                                                          |           |
| Anatomy:                                                                       |                                                                                 |           |
|                                                                                | Ulcer in the posterior wall (Forrest IA) of the duodenal bulb.                  |           |
| Medical History:                                                               |                                                                                 |           |
|                                                                                | A 67-year-old male suffered a coronary infarction 1 year ago, and is treated    |           |
|                                                                                | with low dose ASA. He woke up in the middle of the night vomiting red blood.    |           |
|                                                                                | Upon admission to the ER, he presents with hematochezia, blood pressure         |           |
|                                                                                | 85/? mmHg (diastolic blood pressure is unmeasurable), the pulse is 116/         |           |
|                                                                                | min and weak. After initial intravenous hydration, the condition stabilizes. A  |           |
|                                                                                | nasogastric tube is passed retrieving bright red blood mixed with darker clots. |           |
|                                                                                | Rectal examination shows dark red blood.                                        |           |
| Biological Tests:                                                              |                                                                                 |           |
| Hemoglobin:                                                                    | 63 g/L                                                                          | (139-163) |
| Hematocrit:                                                                    | 21%                                                                             | (39-55)   |
| He was referred for gastroscopy. Immediately prior to endoscopy, the stomach   |                                                                                 |           |
| was cleared via the nasogastric tube, resulting in clear aspirate.             |                                                                                 |           |
| Comments:                                                                      |                                                                                 |           |
| Pre-endoscopy irrigation is very helpful to clear the stomach of clots, making |                                                                                 |           |
| the procedure easier and reducing the risk of clots obstructing the suction    |                                                                                 |           |
| channel. Treatment: Irrigation, injection, and coagulation.                    |                                                                                 |           |

[OCR_TABLE]
DICC

[OCR]
First Module -
Bleeding Situations Y

Case 8

Anatomy:
Ulcer in the posterior wall (Forrest IA) of the duodenal bulb.

Medical History:

A 67-year-old male suffered a coronary infarction 1 year ago, and is treated
with low dose ASA. He woke up in the middle of the night vomiting red blood.
Upon admission to the ER, he presents with hematochezia, blood pressure
85/? mmHg (diastolic blood pressure is unmeasurable), the pulse is 116/

min and weak. After initial intravenous hydration, the condition stabilizes. A
nasogastric tube is passed retrieving bright red blood mixed with darker clots.
Rectal examination shows dark red blood.

Biological Tests:
Hemoglobin: 63 g/L (139-163)
Hematocrit: 21% (39-55)

He was referred for gastroscopy. Immediately prior to endoscopy, the stomach
was cleared via the nasogastric tube, resulting in clear aspirate.

Comments:

Pre-endoscopy irrigation is very helpful to clear the stomach of clots, making
the procedure easier and reducing the risk of clots obstructing the suction
channel. Treatment: Irrigation, injection, and coagulation.

Duodenal ulcer

surgical GI Mentor


# Page 10

Bleeding Situations
First Module -
10
GI Mentor
9
Anatomy: 
Pre-pyloric bleeding ulcer (Forrest IB).
Medical History: 
A 46-year-old male, with a medical history including an ulcer, complaining 
of fatigue, weakness, and epigastric pain for a few days. His family doctor 
found him to be anemic (hemoglobin 67 g/L) and referred him to the 
hospital immediately. On suspicion of upper GI bleeding, he was referred for 
gastroscopy. On admittance to the Emergency Room, the blood pressure is 
105/60 mmHg, and the pulse is 96/min.
Biological Tests: 
Hemoglobin:	
63 g/L	 (139-163)
Comments: 
The clot should be removed by irrigation, after which an oozing visible vessel 
will be seen in the ulcer’s base. It should be injected with epinephrine 1:10.000 
approximately a 1 mL/injection, and afterwards coagulation is performed 
using a bipolar coagulation probe.If the clot cannot be completely removed 
by irrigation: Irrigate away as much as possible, then inject with epinephrine 
1:10.000, approximately a 1 mL/injection into the quadrates of the clot. 
Afterwards, remove the remainder of the clot by cold snare, and then treat the 
ulcer as described previously. Biopsies for identification of H. Pylori should be 
taken from the antrum. Taking biopsies from the ulcer itself is contraindicated; 
these are taken later at follow-up.
Case 9
Pre-pyloric ulcer


[TABLE]
|                                                                                   |        |           |
|:----------------------------------------------------------------------------------|:-------|:----------|
| 9                                                                                 | Case 9 |           |
| Anatomy:                                                                          |        |           |
| Pre-pyloric bleeding ulcer (Forrest IB).                                          |        |           |
| Medical History:                                                                  |        |           |
| A 46-year-old male, with a medical history including an ulcer, complaining        |        |           |
| of fatigue, weakness, and epigastric pain for a few days. His family doctor       |        |           |
| found him to be anemic (hemoglobin 67 g/L) and referred him to the                |        |           |
| hospital immediately. On suspicion of upper GI bleeding, he was referred for      |        |           |
| gastroscopy. On admittance to the Emergency Room, the blood pressure is           |        |           |
| 105/60 mmHg, and the pulse is 96/min.                                             |        |           |
| Biological Tests:                                                                 |        |           |
| Hemoglobin:                                                                       | 63 g/L | (139-163) |
| Comments:                                                                         |        |           |
| The clot should be removed by irrigation, after which an oozing visible vessel    |        |           |
| will be seen in the ulcer’s base. It should be injected with epinephrine 1:10.000 |        |           |
| approximately a 1 mL/injection, and afterwards coagulation is performed           |        |           |
| using a bipolar coagulation probe.If the clot cannot be completely removed        |        |           |
| by irrigation: Irrigate away as much as possible, then inject with epinephrine    |        |           |
| 1:10.000, approximately a 1 mL/injection into the quadrates of the clot.          |        |           |
| Afterwards, remove the remainder of the clot by cold snare, and then treat the    |        |           |
| ulcer as described previously. Biopsies for identification of H. Pylori should be |        |           |
| taken from the antrum. Taking biopsies from the ulcer itself is contraindicated;  |        |           |
| these are taken later at follow-up.                                               |        |           |

[OCR_TABLE]
DICC

[OCR]
First Module -
Bleeding Situations Y

Case 9

Anatomy:
Pre-pyloric bleeding ulcer (Forrest IB).

Medical History:

A 46-year-old male, with a medical history including an ulcer, complaining
of fatigue, weakness, and epigastric pain for a few days. His family doctor
found him to be anemic (hemoglobin 67 g/L) and referred him to the
hospital immediately. On suspicion of upper GI bleeding, he was referred for
gastroscopy. On admittance to the Emergency Room, the blood pressure is
105/60 mmHg, and the pulse is 96/min.

Biological Tests:
Hemoglobin: 63 g/L (139-163)

Comments:

The clot should be removed by irrigation, after which an oozing visible vessel
will be seen in the ulcer’s base. It should be injected with epinephrine 1:10.000
approximately a1 mL/injection, and afterwards coagulation is performed

using a bipolar coagulation probe.lf the clot cannot be completely removed

by irrigation: Irrigate away as much as possible, then inject with epinephrine
1:10.000, approximately a 1 mL/injection into the quadrates of the clot.
Afterwards, remove the remainder of the clot by cold snare, and then treat the
ulcer as described previously. Biopsies for identification of H. Pylori should be
taken from the antrum. Taking biopsies from the ulcer itself is contraindicated;
these are taken later at follow-up.

Pre-pyloric ulcer

surgical GI Mentor


# Page 11

Bleeding Situations
First Module -
11
GI Mentor
10
Anatomy: 
Clean based ulcer (Forrest III) in the duodenal bulb.
Medical History: 
A 72-year-old female has been vomiting for a week and has had epigastric 
pain. After observing “coffee grounds” in her vomit, she went to the Emergency 
Room. A nasogastric tube was passed, the aspirate was clear with small black 
spots.
Biological Tests: 
Hemoglobin:	
142 g/L	 (120-150) 
Hematocrit:	
40%	
(36-48)
Comments: 
An ulcer without stigmata of recent bleeding should not be subjected to 
endoscopic treatment. Biopsy for H. Pylori is not necessary since H. Pylori is 
always present in patients with duodenal ulcer.
Case 10
Duodenal ulcer


[TABLE]
|                                                                                |                    |
|:-------------------------------------------------------------------------------|:-------------------|
| 10                                                                             | Case 10            |
| Anatomy:                                                                       |                    |
| Clean based ulcer (Forrest III) in the duodenal bulb.                          |                    |
| Medical History:                                                               |                    |
| A 72-year-old female has been vomiting for a week and has had epigastric       |                    |
| pain. After observing “coffee grounds” in her vomit, she went to the Emergency |                    |
| Room. A nasogastric tube was passed, the aspirate was clear with small black   |                    |
| spots.                                                                         |                    |
| Biological Tests:                                                              |                    |
| Hemoglobin:                                                                    | 142 g/L  (120-150) |
| Hematocrit:                                                                    | 40%                |
|                                                                                | (36-48)            |
| Comments:                                                                      |                    |
| An ulcer without stigmata of recent bleeding should not be subjected to        |                    |
| endoscopic treatment. Biopsy for H. Pylori is not necessary since H. Pylori is |                    |
| always present in patients with duodenal ulcer.                                |                    |

[OCR_TABLE]
DICC

[OCR]
First Module -
Bleeding Situations Y

Case 10

Anatomy:
Clean based ulcer (Forrest III) in the duodenal bulb.

Medical History:

A 72-year-old female has been vomiting for a week and has had epigastric
pain. After observing “coffee grounds” in her vomit, she went to the Emergency
Room. A nasogastric tube was passed, the aspirate was clear with small black
spots.

Biological Tests:
Hemoglobin: 142 g/L (120-150)
Hematocrit: 40% (36-48)

Comments:

An ulcer without stigmata of recent bleeding should not be subjected to
endoscopic treatment. Biopsy for H. Pylori is not necessary since H. Pylori is
always present in patients with duodenal ulcer.

Duodenal ulcer

surgical GI Mentor