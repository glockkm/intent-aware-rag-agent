

# Page 1

ENDO Suite - HYST Mentor
Simulator
User Guide


[TABLE]
| ENDO Suite - HYST Mentor   |
|:---------------------------|
| Simulator                  |
| User Guide                 |

[OCR]
User Guide

surgical


# Page 2

 
                                                                                                                                                                            
 
 
ENDO SUITE - HYST MENTOR® 
User Guide 
 
 
October 2024 
 
 
 
02-HYSTUG-W01024 
 
 
 


[TABLE]
| E                                                                                                                                                                                 |
|                                                                                                                                                                                   |
| NDO SUITE - HYST MENTOR®                                                                                                                                                          |
|:----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| User Guide                                                                                                                                                                        |
| O                                                                                                                                                                                 |
| ctober 2024                                                                                                                                                                       |
| 0                                                                                                                                                                                 |
| 2-HYSTUG-W01024                                                                                                                                                                   |

[OCR]
ENDO SUITE - HYST MENTOR?

User Guide

October 2024

02-HYSTUG-W01024

surgicalscience


# Page 3

Contents
 
Page ii
 
Contents 
 
Chapter 1 
Safety Precautions ............................................................................................... 1 
Chapter 2 
ENDO Mentor Suite System ................................................................................ 4 
Hardware platform ................................................................................................................... 4 
HYST interchangeable cartridge ......................................................................................... 6 
URO interchangeable cartridge ........................................................................................... 7 
GI-BRONCH interchangeable cartridge .............................................................................. 8 
Scope hanger ........................................................................................................................ 9 
Connecting the scope .......................................................................................................... 9 
Extensions ........................................................................................................................... 10 
Working positions ............................................................................................................... 12 
Height elevation mechanism ............................................................................................. 14 
Turning on the simulator .................................................................................................... 14 
Tool tray ............................................................................................................................... 15 
Foot switch .......................................................................................................................... 16 
Available scope ....................................................................................................................... 17 
Resectoscope ...................................................................................................................... 18 
Chapter 3 
HYST Mentor Library of Modules and Courses ............................................... 21 
Chapter 4 
Getting Started ................................................................................................... 24 
Workflow ................................................................................................................................. 24 


[TABLE]
| Contents   |                                                                                                                                               |
|:-----------|:----------------------------------------------------------------------------------------------------------------------------------------------|
| C          | Safety Precautions ............................................................................................... 1                          |
| hapter 1   |                                                                                                                                               |
| Chapter 2  | ENDO Mentor Suite System ................................................................................ 4                                   |
|            | Hardware platform ................................................................................................................... 4       |
|            | HYST interchangeable cartridge ......................................................................................... 6                    |
|            | URO interchangeable cartridge ........................................................................................... 7                   |
|            | GI-BRONCH interchangeable cartridge .............................................................................. 8                          |
|            | Scope hanger ........................................................................................................................ 9       |
|            | Connecting the scope .......................................................................................................... 9             |
|            | Extensions ........................................................................................................................... 10     |
|            | Working positions ............................................................................................................... 12          |
|            | Height elevation mechanism ............................................................................................. 14                   |
|            | Turning on the simulator .................................................................................................... 14              |
|            | Tool tray ............................................................................................................................... 15  |
|            | Foot switch .......................................................................................................................... 16     |
|            | Available scope ....................................................................................................................... 17    |
|            | Resectoscope ...................................................................................................................... 18        |
| Chapter 3  | HYST Mentor Library of Modules and Courses ............................................... 21                                                 |
| Chapter 4  | Getting Started ................................................................................................... 24                        |
|            | Workflow ................................................................................................................................. 24 |

[OCR]
Contents

| Contents

Chapter 1 Safety Precautions 0... esescsceccseesceeceeeeeecsesseseeseesceecsecsseeeseeeesaseeseeaceesseeeseeee 1
Chapter 2 ENDO Mentor Suite SYSteM ..0... eee ceeeeseeeceeeeceececseeecsesseeaeeesceaceecseeaseeeseeaeeatees 4
Hardware platform 0.0... essessesccseeseecceeeeeeecsesseseeseesceacsecseceeeecsessesaeseeaceassecaeeeeeeesesaeeaeseeaeeaeeees 4
HYST interchangeable Cartridge ........ es eeeesssseseeseesceeecesseecsecseeeeseesceacsecseeacsecseeeeeessesaeeaeees 6
URO interchangeable Cartridge 0... .eesecseessseseeseesceeeseeaceecseeseeaeseeseescsecseeacsecseeeseessesaeaeees 7
GI-BRONCH interchangeable Cartridge... eesesseeseeseeeceeeeceececseeeeeeseeacsecaeeaeeeseeeeeeees 8
SCOPE NANGEM ..... eee eeeseesceseseesceccecseeeceeseescsecseesseecseeseeeesecaeeaeseesceacsecseesseessesaeeaeseeaceaeeeeaeeaeeees 9
CONNECTING the SCOPE .0.... ee eeeeeeeeseeeeeeseeseeeescesceccseesseeesecsesaeseesceacsecseeseeessesaeeaeseeaeeaeeeaeeeeeeees 9
EXTENSIONS oo. cece ce cece cseeeceescseseseescseesecscsesscenscsesssesscsesseesessesseessssesseessssesssesessesseeseeases 10
WOKING POSITIONS... eee eeeceteeeceeceeeeeeesesaeseesceacsecsecseeesessesaeseeseeacsecaeeesseeseseearseeaeeesseees 12
Height elevation MECHANISM 1.0... ee eseeeeesseseseeeesceecscesceecseeaeeeeseeseeeseeseeecseeseeeseeaeeaeetaeee 14
TUPNING ON the SIMULACON «2... eee eee eeeseeeeteesceecseeseeeeseeseacseeseeacsecseeeeseesesaeseeseeaseacseeseeeeeeeets 14
TOOL tray... eeceecscsessesseessesscsecesecsessscsseeseessscseeeessseesessaeesesseseeseaecsssesecseseseeaeesesesscasenseeaeeaees 15
FOOt SWITCH oo. eee cece ceescsececececsesssesscsesesececsesscessssesssesscsesseessssesseesessesseessssssesesesessseesesaees 16
Available SCOPE... eesseseseesseeeesesesseeeescescsecsecseecsessesaeseesceacsecseessseesesaseeeseeacacseeseeeseeeaetasaeaeee 17
RESECCLOSCOPE.......eeeseececcsseseseeseesccesceseeeseeseeeseeseacsacscacuecseesssesseeseseeseeaeacseeaseeseeeaeeaseaeaeee 18

Chapter 3 HYST Mentor Library of Modules and Courses...

Chapter 4 Getting Started oe eee eeecseeseeeeseeseeececseeeceeseseeeesceaceecseesseessesaesaseerseeaeeeeseees 24

WOSKPIOW .... eee eeeeesseseeceeescescscescecscesseesseeseeacsecsceacuasseessecsesaesaescescsacsecseeasseesesaeaeseeaeasseeaeeeseeeaes 24

surgicalscience Page ii


# Page 4

Contents
 
Page iii
 
Chapter 5 
MentorLearn ....................................................................................................... 25 
MentorLearn overview ........................................................................................................... 25 
MentorLearn workflow ........................................................................................................... 25 
Logging in to MentorLearn on the simulator ........................................................................ 26 
Working locally and on a cloud site ................................................................................... 28 
Accessing a module or course within My Curricula or Library ........................................... 29 
Easy Access to courses and modules in the Library ....................................................... 30 
Starting a simulation case or task ..................................................................................... 31 
Chapter 6 
Display Modes ....................................................................................................34 
Diagnostic Hysteroscopy display mode ...............................................................................34 
Screen display layout ......................................................................................................... 35 
Endoscopic View ................................................................................................................. 36 
Hysteroscope Indicators .................................................................................................... 38 
External View ....................................................................................................................... 39 
Virtual instructor ................................................................................................................. 41 
General buttons .................................................................................................................. 41 
Simulation Aids .................................................................................................................... 42 
Patient Discomfort Scale ....................................................................................................43 
Therapeutic Hysteroscopy display mode ........................................................................... 44 
Hystero-resectoscope options .......................................................................................... 45 
Simulation Aids .................................................................................................................... 46 


[TABLE]
|           | Contents                                                                                                                                 |
|:----------|:-----------------------------------------------------------------------------------------------------------------------------------------|
| Chapter 5 | MentorLearn ....................................................................................................... 25                   |
|           | MentorLearn overview ........................................................................................................... 25      |
|           | MentorLearn workflow ........................................................................................................... 25      |
|           | Logging in to MentorLearn on the simulator ........................................................................ 26                   |
|           | Working locally and on a cloud site ................................................................................... 28               |
|           | Accessing a module or course within My Curricula or Library ........................................... 29                               |
|           | Easy Access to courses and modules in the Library ....................................................... 30                             |
|           | Starting a simulation case or task ..................................................................................... 31              |
| Chapter 6 | Display Modes ....................................................................................................34                     |
|           | Diagnostic Hysteroscopy display mode ...............................................................................34                   |
|           | Screen display layout ......................................................................................................... 35       |
|           | Endoscopic View ................................................................................................................. 36     |
|           | Hysteroscope Indicators .................................................................................................... 38          |
|           | External View ....................................................................................................................... 39 |
|           | Virtual instructor ................................................................................................................. 41  |
|           | General buttons .................................................................................................................. 41    |
|           | Simulation Aids .................................................................................................................... 42  |
|           | Patient Discomfort Scale ....................................................................................................43          |
|           | Therapeutic Hysteroscopy display mode ........................................................................... 44                     |
|           | Hystero-resectoscope options .......................................................................................... 45               |
|           | Simulation Aids .................................................................................................................... 46  |

[OCR]
Contents

Chapter 5 MeNtorLearn ou... eeseseeesececeeecscesceeeseeeeeescsacsecsceaeeacseesceecseesesaesaeseeacacseeaseeseeeass 25
MentorLearn OVErVieW ou... esecsescesseecsscsseeeseescescsecseesceecseeaeeeseeacsaeseaceacseeaeeassesaesaeeeaceaceesaeees 25
MentorLearn Workflow... ceeeccscesseccsecsssseseescesceecseesceecseeeeseeseesceaeseeseeacseeaeeasseeaesaeeeeseeaeeeeeees 25

Logging in to MentorLearn on the simulator...
Working locally and On a CIOUC Sit@...... eee eeseeseeeeteceeeeeeeeseeceseeseeacsecaeeeeseeseseeserseeaeeesseees 28

Accessing a module or course within My Curricula or LiDrary....... ee eeeeeseeseeeeeeeeeeeeeeeeees 29

Easy Access to courses and modules in the Library...
Starting a SiMUlation CASE OF TASK... eee eceeeseeeeeeeseesceecsceeceesetaceeseesceeeseeaceacseeseeeeeeeaes 31

Chapter 6 Display MOdES 2.0... ceeescssceseseescescseesseeeseesessescesceacsecseeseeeesessesaeseeseeaceecseeaseeseeeaes 34

Diagnostic Hysteroscopy display mode....

Screen display layout... eee eseeesessesecsecseeeceeeseseeeesesececseescecseeeeeeesesaeseeseeaceaeseeseeeseeeaes 35
ENCOSCOPIC VICW....... ce eeeeeseeeseeseeseeeescescecescessenesecseeaeseesceacsecseeaeseesesaeseesceaeeacseeaeeesseeeeeaesataeee 36
Hysteroscope INdICAtOIS ....... ee eeeeeeeeseeseeeeseeeeseeseesescescaceccaeeaeseeseeaesaeseeseacseeaseeeseeeeeaeseeaeee 38
External ViOW...... cece ceessceceesescesscsesseesscsesscessssesssesessesssecsssessesssssesssesscsesseesessesseeteeaees 39
VirtUal INStPUCTOL oo. eee cec cece ceesesesesececseseseceescsseessesesaeesessesseesecsesseesessesseesessesseesenseeaegs 41
General DUttONS oo. eee cece esesecececsesecececsesssececsesssesecsesseeseesesssesscsesseesesssseeeseeseeaeees 41
SIMUIAtION AIS... ee eee cece ceeeeceeecsesecetscsesesenscseesesscsesseessesessceesssesseesessesseeseeseeaeeees 42
Patient Discomfort SCal@ oo... cece ce ccecenececeesesecetscsesssecessessssssssesssesessssesesessesseeneeaees 43
Therapeutic Hysteroscopy display MOE ........ eee eeeeesceeesctecsseeeeeseseeeeseeacecseeeseecsesaeeaeeee 44
HyStero-reSeCtOSCOpe OPtiONs...... ees eeeesseeseeseeseeecseeseeeceeseseeseeseeacseeseesceeeseseeeeeseeeeeeeeees 45
SIMUIAtION AIS... ee eee cece ceeeeceeecsesecetscsesesenscseesesscsesseessesessceesssesseesessesseeseeseeaeeees 46

surgicalscience Page iii


# Page 5

Contents
 
Page iv
 
Fluid management system ..................................................................................................... 48 
Chapter 7 
Working with Resectoscope .............................................................................. 49 
Tools menu .............................................................................................................................. 49 
Selecting a tool ....................................................................................................................... 50 
Aligning the resectoscope ..................................................................................................... 50 
Inserting and positioning the camera ................................................................................... 52 
Taking snapshots ................................................................................................................ 52 
Focusing the simulation display ........................................................................................ 52 
Zooming the simulation display ......................................................................................... 53 
Ending the case or task ......................................................................................................... 53 
Chapter 8 
Viewing Performance Reports .......................................................................... 55 
Overview ................................................................................................................................. 55 
Viewing reports ....................................................................................................................... 55 
Viewing additional information .......................................................................................... 58 
Viewing recorded videos ................................................................................................... 59 
Enabling complications ....................................................................................................... 61 
Browsing between sessions .............................................................................................. 63 
Understanding the scoreboard ......................................................................................... 63 
Understanding benchmarks and rating scales ................................................................ 65 
Understanding learning curve graphs .............................................................................. 65 
Exporting performance results .............................................................................................. 66 


[TABLE]
|           | Contents                                                                                                                                      |
|:----------|:----------------------------------------------------------------------------------------------------------------------------------------------|
|           | Fluid management system ..................................................................................................... 48              |
| Chapter 7 | Working with Resectoscope .............................................................................. 49                                   |
|           | Tools menu .............................................................................................................................. 49  |
|           | Selecting a tool ....................................................................................................................... 50   |
|           | Aligning the resectoscope ..................................................................................................... 50            |
|           | Inserting and positioning the camera ................................................................................... 52                   |
|           | Taking snapshots ................................................................................................................ 52          |
|           | Focusing the simulation display ........................................................................................ 52                   |
|           | Zooming the simulation display ......................................................................................... 53                   |
|           | Ending the case or task ......................................................................................................... 53          |
| Chapter 8 | Viewing Performance Reports .......................................................................... 55                                     |
|           | Overview ................................................................................................................................. 55 |
|           | Viewing reports ....................................................................................................................... 55    |
|           | Viewing additional information .......................................................................................... 58                  |
|           | Viewing recorded videos ................................................................................................... 59                |
|           | Enabling complications ....................................................................................................... 61             |
|           | Browsing between sessions .............................................................................................. 63                   |
|           | Understanding the scoreboard ......................................................................................... 63                     |
|           | Understanding benchmarks and rating scales ................................................................ 65                                |
|           | Understanding learning curve graphs .............................................................................. 65                         |
|           | Exporting performance results .............................................................................................. 66               |

[OCR]
Contents

Fluid MANAGEMENt SYSTEM... eeeceeseeteeeeeeeseeseceseesesecseeeeeesesseaeseeseescseeseeesecsesaeeetseeaeeeeeeees 48
Chapter 7 Working with RESCCtOSCOPE.......eeesseeeseeteeeeeeeeeeeeeesesecseeseeaceecseeaeeeseeeaeeaeetaeee 49
TOOIS MENU... cece cseeececscsetececsesesscecsesesscessesessescscsesseesecsesssessssessessssessesecsesseesessesseetesseeaees 49

Selecting a tool....
Aligning the reS@CtOSCOPE ...... ee eeesesseseeseeecteeseeeceeseeeeseescscsecseeeeseeseeaseaeseeseacseeaseeseeeetaeseeaeen 50

Inserting and positioning the CAMEMA Qu... eset eseeeeteeeeeeeeteceecseeseeeseeeseeaeeeeseeaeeeeseeaeeeeaeees 52

Taking snapshots...
Focusing the Simulation display .........ceeeeeeeceeseecescesceecseeeeeecseeseeeeseeseeecseeaeeeseeesesaeeeaees 52

Zooming the Simulation display ........ ee eeescecseesesseseeeeesceecseeeceeeseeseseeseeseeeeseeseeaeeeseeeeeeees 53

Ending the case or task....

Chapter 8 Viewing Performance Reports ........ceeseeseecseecseseseeeeesceecseesceecseeseeeeeeeseeaeeeteees 55
OVELVICW oo ceccecececsceteceescseeeceescsesscecsesesssecscsesssesscsesssssecsesssessssessessssesseesessesseesessesseeseesesaegs 55
VIEWING FEPOFtS....... ee eeeceesecseeeeseeeeseseescescsecsecseeessesseseeseesceacsecseeeeseesesaeaeseeaeacseesseeseeseeasaeeeee 55

Viewing additional information .......... ee eessseesescesceccseceeeeceecseeeeseesceacecseeeeeecseseeeerseeaeeeeseees 58
VIEWING FECOPdEd VIGEOS .......eeseecsecseeceeeeseeseecesceaceecsecaeeecsesacsaeseeacacueeaeeesseesesaeeatseeaeeeeeeees 59
Enabling Complications... ee eeecescesceseseeseeesecseeseeeescescecseeeeeecseeaeeeeseeseeacseeaeeeseeaeeassaeeeee 61
BrowSing DeEtWEEN SESSIONS ..........eeseeseeeesseseeeeseesescescescecseeseeeeseesceacseeseescseeaeeeseeeaeeaeaeaeee 63
Understanding the SCOreD Oar ..... eee eesesseeeeeeseeseeeescesceecseeeeeeeseeaeseeseeseeacseeaeeeseeeaeeaesaeaees 63
Understanding benchmarks and rating SCAI@S oes eeeeseeeeeeeeeeeeeeseeeeseeaeeeseeeseeeeeeeaeee 65
Understanding learning CUrVe Graphs... eee eseeceseeseeeceecseeeeseescecsceseeeceeseeeeeeseeaesataees 65
Exporting performance reSults....... ce seseeseeseeseeceseesceecseeeeeecsesseeeeseesceecsecseeeseesesaeseeseeaeeesseees 66

surgicalscience Page iv


# Page 6

Contents
 
Page v
 
Chapter 9 
Technical Support .............................................................................................. 68 
SURGICAL SCIENCE SUPPORT POLICY ........................................................................... 68 
Surgical Science Call Center.............................................................................................. 68 
Chapter 10 
End-User Software License Agreement .......................................................... 69 
HYST Mentor® ..................................................................................................................... 69 
1  EXTENT OF LICENSE ...................................................................................................... 69 
2  CONFIDENCE OF THE SOFTWARE AND COPYRIGHT ................................................ 70 
3  OWNERSHIP OF SOFTWARE ......................................................................................... 71 
4  SUPPORT SERVICES ...................................................................................................... 71 
5  INTEGRITY OF THE SOFTWARE .................................................................................... 71 
6  RIGHT OF ACCESS ......................................................................................................... 72 
7  WARRANTY AND LIMITATION OF LIABILITY ............................................................... 72 
8  TERMINATION ................................................................................................................. 73 
9.  MISCELLANEOUS .......................................................................................................... 74 
Index ............................................................................................................................................ 75 
 


[TABLE]
|                                                                                                                                                       | Contents                                                                                                                              |
|:------------------------------------------------------------------------------------------------------------------------------------------------------|:--------------------------------------------------------------------------------------------------------------------------------------|
| Chapter 9                                                                                                                                             | Technical Support .............................................................................................. 68                   |
|                                                                                                                                                       | SURGICAL SCIENCE SUPPORT POLICY ........................................................................... 68                        |
|                                                                                                                                                       | Surgical Science Call Center.............................................................................................. 68         |
| Chapter 10                                                                                                                                            | End-User Software License Agreement .......................................................... 69                                     |
|                                                                                                                                                       | HYST Mentor® ..................................................................................................................... 69 |
|                                                                                                                                                       | 1  EXTENT OF LICENSE ...................................................................................................... 69        |
|                                                                                                                                                       | 2  CONFIDENCE OF THE SOFTWARE AND COPYRIGHT ................................................ 70                                       |
|                                                                                                                                                       | 3  OWNERSHIP OF SOFTWARE ......................................................................................... 71                 |
|                                                                                                                                                       | 4  SUPPORT SERVICES ...................................................................................................... 71         |
|                                                                                                                                                       | 5  INTEGRITY OF THE SOFTWARE .................................................................................... 71                  |
|                                                                                                                                                       | 6  RIGHT OF ACCESS ......................................................................................................... 72       |
|                                                                                                                                                       | 7  WARRANTY AND LIMITATION OF LIABILITY ............................................................... 72                            |
|                                                                                                                                                       | 8  TERMINATION ................................................................................................................. 73   |
|                                                                                                                                                       | 9.  MISCELLANEOUS .......................................................................................................... 74       |
| Index ............................................................................................................................................ 75 |                                                                                                                                       |

[OCR]
Contents

Chapter 9 Technical SUPPOF Tt... ee eeeeeseesceeesecseeeceeseeeeseesesscseescesseecseesseessesaesateeseeaeeeeaeees 68
SURGICAL SCIENCE SUPPORT POLICY .....ececeeseseseseseseseeessesesesescscsssceeesseessnenseeeeeeeeneees 68
Surgical Science Call Center... ee eesescescescsecsesseseesessceecseesseecseseeseesesaeseeseeaceasseeseeeseeeaes 68

Chapter 10 End-User Software License Agreement...

HYST Mentor? woes ecsececscsesscecscsesssecscsesscesscsesscesscsesssessssessessessesseessssssseesessesseeseeaees 69
1 EXTENT OF LICENSE 000... ecscscseesesesccscscscsescseseseesseeeseesssescsesescscasaceeasseessnenseeseeeeaeees 69
2 CONFIDENCE OF THE SOFTWARE AND COPYRIGHT ........ccsescsesssssescscsesessseeeeeeeeeeee 70
3 OWNERSHIP OF SOFTWARE .......ssssesessseseseescscscscscsesssesesesesnseseeuesescscscasacssasseeseneeeeaes 71
4 SUPPORT SERVICES ....eesesesesesessesseeseescscsessscseseseesseseseenssesesssescscasseeeasseessnenseeeeeeeeeeees 71
5 INTEGRITY OF THE SOFTWARE... ccessescssesescscescscscssseesseseseensessesssesescacacesasseeseeeneeaes 71
6 RIGHT OF ACCESS uo. eeeesesssesesteeseecscscscsescscsessseeesesssessseseseseacacasseeeseseessneeseeneeeeeneees 72
7 WARRANTY AND LIMITATION OF LIABILITY .......ccesesesesesseesescscssseeeseseetseeteneneeeeeneees 72
8B TERMINATION... eecseeseesescsesssesessenscscscscscscassesssnseesseseseenssescscsescscassceeasseessnsnseeaeeeeaeees 73
9. MISCELLANEOUS 100. eseeeseeeeeescscscscscasscseseseeeseseseeussesesesescseasaceeasseessnenseeeeeeeneaes 74
INC OX... eeccecccccscescssceeseceessessesecsecscsscsscsesecsessesscsessacscsecsssseseceeseesessessasessesssesssseassesessussseecseeessessesegs 75

surgicalscience Page v


# Page 7

Figures
 
Page vi
 
Figures 
 
Figure 2-1: ENDO Mentor Suite - HYST Mentor platform ........................................................ 5 
Figure 2-2: HYST interchangeable cartridge ............................................................................ 6 
Figure 2-3: URO interchangeable cartridge .............................................................................. 7 
Figure 2-4: GI-BRONCH interchangeable cartridge – lower orifice selected ......................... 8 
Figure 2-5: Scope hanger – URO scope .................................................................................... 9 
Figure 2-6: System and scope connectors ............................................................................. 10 
Figure 2-7: URO modality extension ......................................................................................... 11 
Figure 2-8: GI modality extension ............................................................................................. 11 
Figure 2-9: GI extension fully opened (left), URO extension fully opened (right) ............... 12 
Figure 2-10: HYST and URO Mentor working position ........................................................... 13 
Figure 2-11: Height elevation panel – (from left to right) USB port, Height Elevation 
mechanism, Computer On/Off button ...................................................................................... 14 
Figure 2-12: Tool tray hanger with resectoscope ................................................................... 15 
Figure 2-13: Resectoscope hung on the tool tray .................................................................. 16 
Figure 2-14: Foot switch ............................................................................................................ 17 
Figure 2-15: Adapted resectoscope ......................................................................................... 18 
Figure 2-16: Resectoscope’s camera handle .......................................................................... 19 
Figure 4-1: My Curricula screen ............................................................................................... 29 
Figure 4-2: HYST Mentor Library screen ................................................................................. 30 
Figure 4-3: Opening a module .................................................................................................. 31 
Figure 4-4: Task/Case description ........................................................................................... 33 
Figure 6-1: Diagnostic Hysteroscopy display mode ...............................................................34 
Figure 6-2: Endoscopic View .................................................................................................... 36 
Figure 6-3: External View .......................................................................................................... 39 
Figure 6-4: Visualization progress bar ..................................................................................... 42 
Figure 6-5: View clouded with blood and tissue and view cleared ......................................43 


[TABLE]
| Figures                                                                                                                                  |
|:-----------------------------------------------------------------------------------------------------------------------------------------|
| Figures                                                                                                                                  |
| F                                                                                                                                        |
| igure 2-1: ENDO Mentor Suite - HYST Mentor platform ........................................................ 5                           |
| Figure 2-2:  HYST interchangeable cartridge ............................................................................ 6               |
| Figure 2-3: URO interchangeable cartridge .............................................................................. 7               |
| Figure 2-4: GI-BRONCH interchangeable cartridge – lower orifice selected ......................... 8                                     |
| Figure 2-5: Scope hanger – URO scope .................................................................................... 9              |
| Figure 2-6: System and scope connectors ............................................................................. 10                 |
| Figure 2-7: URO modality extension ......................................................................................... 11          |
| Figure 2-8: GI modality extension ............................................................................................. 11       |
| Figure 2-9: GI extension fully opened (left), URO extension fully opened (right) ............... 12                                      |
| Figure 2-10: HYST and URO Mentor working position ........................................................... 13                         |
| Figure 2-11: Height elevation panel – (from left to right) USB port, Height Elevation                                                    |
| mechanism, Computer On/Off button ...................................................................................... 14              |
| Figure 2-12: Tool tray hanger with resectoscope ................................................................... 15                   |
| Figure 2-13: Resectoscope hung on the tool tray .................................................................. 16                    |
| Figure 2-14: Foot switch ............................................................................................................ 17 |
| Figure 2-15: Adapted resectoscope ......................................................................................... 18           |
| Figure 2-16: Resectoscope’s camera handle .......................................................................... 19                  |
| Figure 4-1: My Curricula screen ............................................................................................... 29       |
| Figure 4-2: HYST Mentor Library screen ................................................................................. 30              |
| Figure 4-3: Opening a module .................................................................................................. 31       |
| Figure 4-4: Task/Case description ........................................................................................... 33         |
| Figure 6-1: Diagnostic Hysteroscopy display mode ...............................................................34                       |
| Figure 6-2: Endoscopic View .................................................................................................... 36      |
| Figure 6-3: External View .......................................................................................................... 39  |
| Figure 6-4: Visualization progress bar ..................................................................................... 42          |
| Figure 6-5: View clouded with blood and tissue and view cleared ......................................43                                 |

[OCR]
Figures

| Figures

Figure 2-1: ENDO Mentor Suite - HYST Mentor platform ........eceeseseeeeseeceeceeseeceeeeeeeeeeeeeeeeeee 5
Figure 2-2: HYST interchangeable Cartridge 0.0... eee seeeseeeeseescseceeeeeeeeeeseeeesceacecseeeeeeseeaeeatees 6
Figure 2-3: URO interchangeable Cartridge «0.0.0... eeeeesseeceecseesceecseeseeeeseesceecsceaceesseeseeeseeaeeateee 7
Figure 2-4: GI-BRONCH interchangeable cartridge — lower orifice selected... eee 8
Figure 2-5: Scope hanger — URO SCOPE ...... ee eeeesesseseeseescecesceecsecseeeeseesesaeseesceaceacseeeeeessesaeateee 9
Figure 2-6: System and SCOPE CONNECHOSS ....... ee eeeeeeeeseeeeseeeeseeecsecseeeeeeesceaceeeseeaceeseeeeeeesseeaes 10
Figure 2-7: URO modality Extension... eesecseesesseeeeseesceeeseeseeecseeeeseeseesceeceeaeesseeeseeeseeeseeaeee 11
Figure 2-8: Gl modality Extension 0... eeeseeeseecseeseeeeseesceecseeseeecseeseeeeseeaceasseeaeesseeeseeeseeeseeaeee 11
Figure 2-9: GI extension fully opened (left), URO extension fully opened (right) ............... 12
Figure 2-10: HYST and URO Mentor working POSITION ..........cseeeeeseeeeeeeseesceeeeeeaceeeeeeeeeeeseeees 13
Figure 2-11: Height elevation panel - (from left to right) USB port, Height Elevation

mechanism, Computer On/Off DUttON ....... eee eeeeeeeseeeeseeseeeeseesceecsecseceeseesesaeeeseeaceacseeneeeeeeeaes 14
Figure 2-12: Tool tray hanger with reSeCctOSCOPE........eseseeseeeeseesceeceeeseeeeseesceeesceaseecseeeeeeeeeeaes 15
Figure 2-13: Resectoscope hung On the tool tray ...... eee eeseeseeseeecseeeeeeeeeeeeersceaceecseeeseeseeeaes 16
Figure 2-14: Foot SWitCh iu... cesses sscseeeeseeecsceeseecseseeeeesceseeacseeseeecsecseseeseeseeacasseeaeeeseeenseeseeeats 17
Figure 2-15: Adapted reS@CtOSCOPG...... cs sesecscesseeesscseeeeseeseeeesccseeecsecseeeeeesesacseesceaceecseenseesseeats 18
Figure 2-16: Resectoscope’s Camera handle ........ eee eeeesseesceceseesceeceeeeeeeseseceeeseeaseececeeeeeseeeees 19
Figure 4-1: My Curricula SCr@@N ........ceeeseececcseeseeecseeeceeeseesecescesceacsecseeeeseesesaeseeaceaceecseenseeseeeaes 29
Figure 4-2: HYST Mentor Library SCr@@N 0... eeeseseeseseeeeseeeseeeceecseeececeseesceeeseeaseecseeseeeeseeees 30
Figure 4-3: Opening 2 MOCUIC ....... ee eeseeeeccteeseeeceeseeeeseeseeacsecseeecsecseceeeeseeacasseeaeeeseeeeeeeeseeaes 31
Figure 4-4: Task/Case CeSCTiPtion..........eceeseesseceseeeeeceeeseeeescescescsecseeeesessesaeseesceaceecaeenseneeeeaes 33
Figure 6-1: Diagnostic Hysteroscopy display MOE qu... eeseeeeecseeeeeeeseeeceeeeceaeeeceeseeeeeeeees 34
Figure 6-2: ENdOSCOPIC VIEW «uu... eee seeeeeseeseeccsceseeecseeseeeeseeseaeseeseeecsesseseeseesesacsasseeaceesieeeeeeeseeaes 36
Figure 6-3: External VieW.........:cesseesscesessceecseesseecseeseseescesesacscesceecseeseceeseesesaceasseeaseesseeasenseeeaes 39
Figure 6-4: Visualization Progress DAM... ses esseesseseeeeseeseesceeeseeececseseeeeeseeaceecsceaseeseeeeeeeeeaes 42
Figure 6-5: View clouded with blood and tissue and View Cleared ......... cs eeseeseeeeeeseeeeeeeees 43

surgicalscience Page vi


# Page 8

Figures
 
Page vii
 
Figure 6-6: Patient Discomfort Scale .......................................................................................43 
Figure 6-7: Therapeutic hysteroscopy display mode ............................................................ 44 
Figure 6-8: Default View and Show Resection View .............................................................. 47 
Figure 6-9: Resection zones on Resection Map ..................................................................... 47 
Figure 6-10: Pathology removal bar ......................................................................................... 48 
Figure 7-1: Tools Menu with sub-menu of options ................................................................. 49 
Figure 7-2: Working element parallel to camera button ......................................................... 51 
Figure 7-3: Align Scope screen for resectoscope .................................................................. 51 
Figure 7-4: View out of focus and view in focus .................................................................... 53 
Figure 7-5: Zoom percentage ................................................................................................... 53 
Figure 8-1: Single-case report .................................................................................................. 56 
Figure 8-2: Snapshot viewed from single report .................................................................... 59 
Figure 8-3: Recorded video viewed from single report ......................................................... 60 
Figure 8-4: Case benchmark scoreboard ................................................................................ 63 
Figure 8-5: Session benchmark scoreboard ........................................................................... 64 
Figure 8-6: Benchmark rating scale ......................................................................................... 65 
Figure 8-7: Report's learning curve .......................................................................................... 66 
Figure 8-8: Export Performance window ................................................................................. 67 
 


[TABLE]
| Figures                                                                                                                              |
|:-------------------------------------------------------------------------------------------------------------------------------------|
| Figure 6-6: Patient Discomfort Scale .......................................................................................43       |
| Figure 6-7: Therapeutic hysteroscopy display mode ............................................................ 44                    |
| Figure 6-8: Default View and Show Resection View .............................................................. 47                   |
| Figure 6-9: Resection zones on Resection Map ..................................................................... 47                |
| Figure 6-10: Pathology removal bar ......................................................................................... 48      |
| Figure 7-1: Tools Menu with sub-menu of options ................................................................. 49                 |
| Figure 7-2: Working element parallel to camera button ......................................................... 51                   |
| Figure 7-3: Align Scope screen for resectoscope .................................................................. 51                |
| Figure 7-4: View out of focus and view in focus .................................................................... 53              |
| Figure 7-5: Zoom percentage ................................................................................................... 53   |
| Figure 8-1: Single-case report .................................................................................................. 56 |
| Figure 8-2: Snapshot viewed from single report .................................................................... 59               |
| Figure 8-3: Recorded video viewed from single report ......................................................... 60                    |
| Figure 8-4: Case benchmark scoreboard ................................................................................ 63            |
| Figure 8-5: Session benchmark scoreboard ........................................................................... 64              |
| Figure 8-6: Benchmark rating scale ......................................................................................... 65      |
| Figure 8-7: Report's learning curve .......................................................................................... 66    |
| Figure 8-8: Export Performance window ................................................................................. 67           |

[OCR]
Figures

Figure 6-6: Patient Discomfort SCale oo... eee eseeeesseseeceseeseeseseeseeecsecseeeeeeeseeaceeeseeaceecseeeeeesseeats 43
Figure 6-7: Therapeutic hysteroscopy display mode..... 44

Figure 6-8: Default View and Show Resection View...
Figure 6-9: Resection zones on Resection Map...
Figure 6-10: Pathology removal bar...
Figure 7-1: Tools Menu with sub-menu of options...
Figure 7-2: Working element parallel to camera button.
Figure 7-3: Align Scope screen for resectoscope .
Figure 7-4: View out of focus and view in focus

Figure 7-5: Zoom percentage .

Figure 8-1: Single-case report... 56
Figure 8-2: Snapshot viewed from Single report ....... eee eeeceteeseeecseeeeeeeseesceeceeeaceeceeeseeeeseeees 59
Figure 8-3: Recorded video viewed from Single rePOrt «0.0... es eeeeesseeeeeeeeeeeeeeeaeeeseeeeeeeeseeees 60
Figure 8-4: Case benchmark SCOrebOar......... ee eeeeseeseseeseeseeeeseeecsecseeecceseeaceeeseeaceeeseenseeeeeeats 63
Figure 8-5: Session benchmark SCOreDOaIC ........ ee eeeeseeeeseeseeceseeeceecseeeesceseesceeseeaseeceeeseeetseeaes 64
Figure 8-6: Benchmark rating SCale 0... eeteeseeecseeseeceseeseeecscesceecsecseeecscesceaceeeseeaseeseeeeeeeeseeaes 65
Figure 8-7: Report's learning CUrVC ....... ee eseseseeseecseeseeeeseeseeecscescescuceseeeeseeseeacuecsceaseasieeseeaeseaes 66
Figure 8-8: Export Performance WiINdOW..........ceesseseeseseeseeeceecseeseecseeeeeeeseeacaeseeaseeseeeeeeeeeeeaes 67

surgicalscience Page vii


# Page 9

Chapter 1 
 Safety Precautions
 
Page 1
 
Chapter 1 Safety Precautions 
Before using the ENDO Mentor Suite simulator, please read these safety precautions to 
ensure proper use of the equipment. These items contain important notes to prevent 
injury to the operator and damage to the equipment. The following precautions apply to 
the GI Mentor, the BRONCH Mentor, the URO Mentor, and HYST Mentor which share the 
ENDO Mentor Suite platform. 
Two symbols are used to indicate specific types of warnings in addition to the general 
note table, which is clearly marked: 
 
 
A warning that indicates a prohibition. 
 
A general warning that emphasizes essential information about something 
that must be done.  
 
The following safety precautions must be adhered to upon setup and using the ENDO 
Mentor Suite simulator. Failure to follow these precautions may result in the removal of 
the warranty and may cause irreversible damage to the simulator or injury to operators. 
 
 
Read all the instructions and precautions fully before attempting to 
setup or use the ENDO Mentor Suite simulator. 
 
Follow all warnings and instructions marked on the ENDO Mentor Suite 
simulator.  
 
Do not attempt to open, check, alter, or fix any part of the ENDO Mentor 
Suite system, unless directly asked to do so during a support session 
with a Surgical Science representative. 
 
Unplug the ENDO Mentor Suite simulator when you know an electrical 
storm is approaching.  
 
Before cleaning, unplug the ENDO Mentor Suite simulator from the wall 
outlet. Use a dry cloth without liquid. Do not use aerosol cleaners. 


[TABLE]
| Chapter 1                            |                                                                                        | Safety Precautions   |
|:-------------------------------------|:---------------------------------------------------------------------------------------|:---------------------|
| Chapter 1                            | Safety Precautions                                                                     |                      |
|                                      | Before using the ENDO Mentor Suite simulator, please read these safety precautions to  |                      |
|                                      | ensure proper use of the equipment. These items contain important notes to prevent     |                      |
|                                      | injury to the operator and damage to the equipment. The following precautions apply to |                      |
|                                      | the GI Mentor, the BRONCH Mentor, the URO Mentor, and HYST Mentor which share the      |                      |
| ENDO Mentor Suite platform.          |                                                                                        |                      |
|                                      | Two symbols are used to indicate specific types of warnings in addition to the general |                      |
| note table, which is clearly marked: |                                                                                        |                      |

[TABLE]
| Mentor Suite simulator. Failure to follow these precautions may result in the removal of   |
|:-------------------------------------------------------------------------------------------|
| the warranty and may cause irreversible damage to the simulator or injury to operators.    |
| Read all the instructions and precautions fully before attempting to                       |
| setup or use the ENDO Mentor Suite simulator.                                              |
| Follow all warnings and instructions marked on the ENDO Mentor Suite                       |
| simulator.                                                                                 |
| Do not attempt to open, check, alter, or fix any part of the ENDO Mentor                   |
| Suite system, unless directly asked to do so during a support session                      |
| with a Surgical Science representative.                                                    |
| Unplug the ENDO Mentor Suite simulator when you know an electrical                         |
| storm is approaching.                                                                      |
| Before cleaning, unplug the ENDO Mentor Suite simulator from the wall                      |
| outlet. Use a dry cloth without liquid. Do not use aerosol cleaners.                       |

[OCR]
Chapter 1

Safety Precautions

| Chapter1 Safety Precautions

Before using the ENDO Mentor Suite simulator, please read these safety precautions to
ensure proper use of the equipment. These items contain important notes to prevent
injury to the operator and damage to the equipment. The following precautions apply to

the GI Mentor,

the BRONCH Mentor, the URO Mentor, and HYST Mentor which share the

ENDO Mentor Suite platform.

Two symbols are used to indicate specific types of warnings in addition to the general
note table, which is clearly marked:

stor A warning that indicates a prohibition.

A general warning that emphasizes essential information about something
that must be done.

The following safety precautions must be adhered to upon setup and using the ENDO
Mentor Suite simulator. Failure to follow these precautions may result in the removal of
the warranty and may cause irreversible damage to the simulator or injury to operators.

a

Read all the instructions and precautions fully before attempting to
setup or use the ENDO Mentor Suite simulator.

Follow all warnings and instructions marked on the ENDO Mentor Suite
simulator.

Do not attempt to open, check, alter, or fix any part of the ENDO Mentor
Suite system, unless directly asked to do so during a support session
with a Surgical Science representative.

Unplug the ENDO Mentor Suite simulator when you know an electrical
storm is approaching.

Before cleaning, unplug the ENDO Mentor Suite simulator from the wall
outlet. Use a dry cloth without liquid. Do not use aerosol cleaners.

surgicalscience

Page 1


# Page 10

Chapter 1 
 Safety Precautions
 
Page 2
 
 
Do not use the ENDO Mentor Suite near water.  
 
When not in use or upon moving, disconnect all scopes from the system 
side connector. Failing to do so may result in irreparable damage. 
 
When not in use or upon moving, make sure that the tool tray is at its 
original folded position. Failing to do so may result in damage to the 
system. 
 
Make sure scopes and wires are not protruding before closing the 
drawer. Failing to do so may result in irreparable damage to the scopes 
or wires. 
 
When placing the ENDO Mentor Suite in a room with additional 
simulators, other electrical systems, or large amounts of metal, ensure 
that these items are at least 1 meter away from the ENDO Mentor Suite 
simulator. Failing to do so may result in an improper functioning of the 
simulator. 
 
Do not move the interchangeable cartridge in any way while the scope 
is inserted into the cavity. Doing so may result in irreparable scope 
damage. 
 
The interchangeable cartridge must be inserted and locked in place 
properly prior before attempting scope introduction for all the modalities 
to work. 
 
The bronchoscope’s insertion tube should not be bent unnecessarily - 
neither by attaching it to the hanger clip, nor by leaving it within the 
manikin when not being used. 
 
Do not leave the syringe, master tool, or any other instrument inserted 
in the scope’s working channel unnecessarily. 
 
Place the ENDO Mentor Suite on stable ground only. 
 
To protect the ENDO Mentor Suite from overheating, the opening on the 
back of the platform should not be covered or blocked.  


[TABLE]
| Safety Precautions                                                         |
|:---------------------------------------------------------------------------|
| Do not use the ENDO Mentor Suite near water.                               |
| When not in use or upon moving, disconnect all scopes from the system      |
| side connector. Failing to do so may result in irreparable damage.         |
| When not in use or upon moving, make sure that the tool tray is at its     |
| original folded position. Failing to do so may result in damage to the     |
| system.                                                                    |
| Make sure scopes and wires are not protruding before closing the           |
| drawer. Failing to do so may result in irreparable damage to the scopes    |
| or wires.                                                                  |
| When placing the ENDO Mentor Suite in a room with additional               |
| simulators, other electrical systems, or large amounts of metal, ensure    |
| that these items are at least 1 meter away from the ENDO Mentor Suite      |
| simulator. Failing to do so may result in an improper functioning of the   |
| simulator.                                                                 |
| Do not move the interchangeable cartridge in any way while the scope       |
| is inserted into the cavity. Doing so may result in irreparable scope      |
| damage.                                                                    |
| The interchangeable cartridge must be inserted and locked in place         |
| properly prior before attempting scope introduction for all the modalities |
| to work.                                                                   |
| The bronchoscope’s insertion tube should not be bent unnecessarily -       |
| neither by attaching it to the hanger clip, nor by leaving it within the   |
| manikin when not being used.                                               |
| Do not leave the syringe, master tool, or any other instrument inserted    |
| in the scope’s working channel unnecessarily.                              |
| Place the ENDO Mentor Suite on stable ground only.                         |
| To protect the ENDO Mentor Suite from overheating, the opening on the      |
| back of the platform should not be covered or blocked.                     |

[OCR]
Chapter 1

Safety Precautions

a3

a

a

Do not use the ENDO Mentor Suite near water.

When not in use or upon moving, disconnect all scopes from the system
side connector. Failing to do so may result in irreparable damage.

When not in use or upon moving, make sure that the tool tray is at its
original folded position. Failing to do so may result in damage to the
system.

Make sure scopes and wires are not protruding before closing the
drawer. Failing to do so may result in irreparable damage to the scopes
or wires.

When placing the ENDO Mentor Suite in a room with additional
simulators, other electrical systems, or large amounts of metal, ensure
that these items are at least 1 meter away from the ENDO Mentor Suite
simulator. Failing to do so may result in an improper functioning of the
simulator.

Do not move the interchangeable cartridge in any way while the scope
is inserted into the cavity. Doing so may result in irreparable scope
damage.

The interchangeable cartridge must be inserted and locked in place
properly prior before attempting scope introduction for all the modalities
to work.

The bronchoscope’s insertion tube should not be bent unnecessarily -
neither by attaching it to the hanger clip, nor by leaving it within the
manikin when not being used.

Do not leave the syringe, master tool, or any other instrument inserted
in the scope’s working channel unnecessarily.

Place the ENDO Mentor Suite on stable ground only.

To protect the ENDO Mentor Suite from overheating, the opening on the
back of the platform should not be covered or blocked.

surgicalscience

Page 2


# Page 11

Chapter 1 
 Safety Precautions
 
Page 3
 
 
The ENDO Mentor Suite should not be placed near a radiator or heat 
register. 
 
The ENDO Mentor Suite should be placed in a room with a temperature 
range between 5 and 30 degrees centigrade. Proper ventilation is 
crucial.  
 
Do not allow anything to rest on the power cord or position the ENDO 
Mentor Suite where a cord could be stepped on or pulled out 
accidentally. 
 
Do not overload wall outlets and extension cords. 
 
Never spill liquid of any kind on the simulator. 
 
Avoid placing or dropping anything on the ENDO Mentor Suite. It may 
cause a malfunction or irreparable damage. 
 
Power must be off when handling the system or disconnecting any 
internal part during a support session.  
 
Unplug the ENDO Mentor Suite from the wall outlet and contact Surgical 
Science support under the following conditions:  
• 
When any cord, especially the power supply cord, is damaged or 
frayed. 
• 
If liquid has been spilled into the ENDO Mentor Suite. 
• 
If something has been dropped on the ENDO Mentor Suite. 
 
When opening the system’s back panel and pulling out the computer 
drawer during support – please note that the monitor must be in the 
opposite (front) side of the system and the computer drawer must be 
pulled out cautiously to avoid equilibrium problems. 
 
 


[TABLE]
|                                         | Safety Precautions                                                     |
|:----------------------------------------|:-----------------------------------------------------------------------|
|                                         | The ENDO Mentor Suite should not be placed near a radiator or heat     |
| register.                               |                                                                        |
|                                         | The ENDO Mentor Suite should be placed in a room with a temperature    |
|                                         | range between 5 and 30 degrees centigrade. Proper ventilation is       |
| crucial.                                |                                                                        |
|                                         | Do not allow anything to rest on the power cord or position the ENDO   |
|                                         | Mentor Suite where a cord could be stepped on or pulled out            |
| accidentally.                           |                                                                        |
|                                         | Do not overload wall outlets and extension cords.                      |
|                                         | Never spill liquid of any kind on the simulator.                       |
|                                         | Avoid placing or dropping anything on the ENDO Mentor Suite. It may    |
|                                         | cause a malfunction or irreparable damage.                             |
|                                         | Power must be off when handling the system or disconnecting any        |
| internal part during a support session. |                                                                        |
|                                         | Unplug the ENDO Mentor Suite from the wall outlet and contact Surgical |
|                                         | Science support under the following conditions:                        |
| •                                       | When any cord, especially the power supply cord, is damaged or         |

[OCR]
Chapter 1

Safety Precautions

eeeee Pe

The ENDO Mentor Suite should not be placed near a radiator or heat
register.

The ENDO Mentor Suite should be placed in a room with a temperature
range between 5 and 30 degrees centigrade. Proper ventilation is
crucial.

Do not allow anything to rest on the power cord or position the ENDO
Mentor Suite where a cord could be stepped on or pulled out
accidentally.

Do not overload wall outlets and extension cords.

Never spill liquid of any kind on the simulator.

Avoid placing or dropping anything on the ENDO Mentor Suite. It may
cause a malfunction or irreparable damage.

Power must be off when handling the system or disconnecting any
internal part during a support session.

Unplug the ENDO Mentor Suite from the wall outlet and contact Surgical
Science support under the following conditions:

° When any cord, especially the power supply cord, is damaged or
frayed.

° If liquid has been spilled into the ENDO Mentor Suite.
° If something has been dropped on the ENDO Mentor Suite.

When opening the system’s back panel and pulling out the computer
drawer during support — please note that the monitor must be in the
opposite (front) side of the system and the computer drawer must be
pulled out cautiously to avoid equilibrium problems.

surgicalscience

Page 3


# Page 12

Chapter 2 
 ENDO Mentor Suite System
 
Page 4
 
Chapter 2 ENDO Mentor Suite System 
The ENDO Mentor Suite® is a multidisciplinary platform that provides hands-on 
practice of GI, bronchoscopy, endourology, and hysteroscopy procedures for single 
trainees or an entire team.  
Hardware platform 
The platform consists of:  
• 
Wheeled hardware unit. 
• 
One or more scopes according to system configuration 
(Colonoscope/Duodenoscope/Bronchoscope/Rigid Scopes and Flexible Scope 
for Endourology/ and Resectoscope for Endourology and Hysteroscopy).  
• 
Interchangeable cartridge for inserting scopes. 
• 
Set of tools according to system configuration.  
• 
Triple foot switch. 
• 
Wireless keyboard and mouse. 


[TABLE]
| Chapter 2                                                                         | ENDO Mentor Suite System   |
|:----------------------------------------------------------------------------------|:---------------------------|
| Chapter 2  ENDO Mentor Suite System                                               |                            |
| The ENDO Mentor Suite® is a multidisciplinary platform that provides hands-on     |                            |
| practice of GI, bronchoscopy, endourology, and hysteroscopy procedures for single |                            |
| trainees or an entire team.                                                       |                            |
| Hardware platform                                                                 |                            |
| The platform consists of:                                                         |                            |

[TABLE]
| Hardware platform         |                                                                        |
|:--------------------------|:-----------------------------------------------------------------------|
| The platform consists of: |                                                                        |
| •                         | Wheeled hardware unit.                                                 |
| •                         | One or more scopes according to system configuration                   |
|                           | (Colonoscope/Duodenoscope/Bronchoscope/Rigid Scopes and Flexible Scope |
|                           | for Endourology/ and Resectoscope for Endourology and Hysteroscopy).   |
| •                         | Interchangeable cartridge for inserting scopes.                        |
| •                         | Set of tools according to system configuration.                        |
| •                         | Triple foot switch.                                                    |
| •                         | Wireless keyboard and mouse.                                           |

[OCR]
Chapter 2 ENDO Mentor Suite System

| Chapter 2 ENDO Mentor Suite System

The ENDO Mentor Suite® is a multidisciplinary platform that provides hands-on
practice of Gl, bronchoscopy, endourology, and hysteroscopy procedures for single
trainees or an entire team.

Hardware platform

The platform consists of:

° Wheeled hardware unit.

e One or more scopes according to system configuration
(Colonoscope/Duodenoscope/Bronchoscope/Rigid Scopes and Flexible Scope
for Endourology/ and Resectoscope for Endourology and Hysteroscopy).
Interchangeable cartridge for inserting scopes.

Set of tools according to system configuration.

Triple foot switch.

Wireless keyboard and mouse.

surgicalscience Page 4


# Page 13

Chapter 2 
 ENDO Mentor Suite System
 
Page 5
 
 
Figure 2-1: ENDO Mentor Suite - HYST Mentor platform 
1 
27” touch screen 
2 
HYST interchangeable cartridge (see Figure 2-3 on page 7) 
3 
Wireless keyboard and mouse 
4 
Scope hanger (see Figure 2-5 on page 9) 
5 
Scope connectors (see Figure 2-6 on page 10) 
6 
Elevation mechanism (see Figure 2-11 on page 14) 


[TABLE]
| F   |   gure 2-1: ENDO Mentor Suite - HYST Mentor platform |                                                           |
| i   |                                                      |                                                           |
|:----|-----------------------------------------------------:|:----------------------------------------------------------|
|     |                                                    1 | 27” touch screen                                          |
|     |                                                    2 | HYST interchangeable cartridge (see Figure 2-3 on page 7) |
|     |                                                    3 | Wireless keyboard and mouse                               |
|     |                                                    4 | Scope hanger (see Figure 2-5 on page 9)                   |
|     |                                                    5 | Scope connectors (see Figure 2-6 on page 10)              |
|     |                                                    6 | Elevation mechanism (see Figure 2-11 on page 14)          |

[OCR]
Chapter 2 ENDO Mentor Suite System

Figure 2-1: ENDO Mentor Suite - HYST Mentor platform

27” touch screen

HYST interchangeable cartridge (see Figure 2-3 on page 7)
Wireless keyboard and mouse

Scope hanger (see Figure 2-5 on page 9)

Scope connectors (see Figure 2-6 on page 10)

oun Ff WN A

Elevation mechanism (see Figure 2-11 on page 14)

surgicalscience Page 5


# Page 14

Chapter 2 
 ENDO Mentor Suite System
 
Page 6
 
7 
Computer activation button 
8 
Rotating tool tray (see Figure 2-12 on page 15) and 
resectoscope hanger 
9 
Upper drawer for Bronchoscope, 2 URO rigid scopes and 
wires (tools are stored in this drawer when shipped) 
10 
Lower drawer for Colonoscope, Duodenoscope, HYST, URO 
and GI-BRONCH interchangeable cartridges 
11 
Foot switch (not shown) (see Figure 2-15 on page 17) 
12 
Power switch, foot switch connector and USB outlet (on back 
panel) 
HYST interchangeable cartridge   
 
Figure 2-2: HYST interchangeable cartridge 


[TABLE]
| Chapter 2   |                                                             |
|:------------|:------------------------------------------------------------|
| 7           | Computer activation button                                  |
| 8           | Rotating tool tray (see Figure 2-12 on page 15) and         |
|             | resectoscope hanger                                         |
| 9           | Upper drawer for Bronchoscope, 2 URO rigid scopes and       |
|             | wires (tools are stored in this drawer when shipped)        |
| 10          | Lower drawer for Colonoscope, Duodenoscope, HYST, URO       |
|             | and GI-BRONCH interchangeable cartridges                    |
| 11          | Foot switch (not shown) (see Figure 2-15 on page 17)        |
| 12          | Power switch, foot switch connector and USB outlet (on back |
|             | panel)                                                      |

[OCR]
Chapter 2

ENDO Mentor Suite System

11
12

Computer activation button

Rotating tool tray (see Figure 2-12 on page 15) and
resectoscope hanger

Upper drawer for Bronchoscope, 2 URO rigid scopes and
wires (tools are stored in this drawer when shipped)

Lower drawer for Colonoscope, Duodenoscope, HYST, URO
and GI-BRONCH interchangeable cartridges

Foot switch (not shown) (see Figure 2-15 on page 17)

Power switch, foot switch connector and USB outlet (on back
panel)

HYST interchangeable cartridge

Figure 2-2: HYST interchangeable cartridge

surgicalscience

Page 6


# Page 15

Chapter 2 
 ENDO Mentor Suite System
 
Page 7
 
URO interchangeable cartridge   
 
Figure 2-3: URO interchangeable cartridge 
Note: An adaptor should be placed on the penis part of the cartridge for the TURP modules. 


[TABLE]
| Chapter 2                                                                                   | ENDO Mentor Suite System   |
|:--------------------------------------------------------------------------------------------|:---------------------------|
| URO interchangeable cartridge                                                               |                            |
| F                                                                                           |                            |
| i                                                                                           |                            |
| gure 2-3: URO interchangeable cartridge                                                     |                            |
| Note:  An adaptor should be placed on the penis part of the cartridge for the TURP modules. |                            |
|                                                                                             | Page 7                     |

[OCR]
Chapter 2 ENDO Mentor Suite System

URO interchangeable cartridge

Figure 2-3: URO interchangeable cartridge

Note: An adaptor should be placed on the penis part of the cartridge for the TURP modules.

surgicalscience Page 7


# Page 16

Chapter 2 
 ENDO Mentor Suite System
 
Page 8
 
GI-BRONCH interchangeable cartridge  
 
Figure 2-4: GI-BRONCH interchangeable cartridge – lower orifice selected 
Two symbols of the upper GI and lower GI tracts are displayed on the GI-BRONCH 
interchangeable cartridge indicating the relevant GI tract segment. Depending on the 
module selected, the LED will light up on the cartridge to designate the GI tract that 
will be used for procedure. 
To switch between the ENDO Mentor Suite interchangeable cartridges: 
1.  Insert your right hand in the groove at the bottom of the interchangeable cartridge 
and your left hand into the edge on the top of the cartridge and gently free the 
cartridge. You should hear a click. 
2.  Pull the cartridge horizontally out. Store it in its designated cavity in the lower 
drawer. 
3.  Insert the desired cartridge with one hand in the groove and the other on the top 
of the cartridge, push it horizontally into place. You should hear a click. 
 
Note: The cartridge must be properly positioned prior to introducing the scopes. 


[TABLE]
| module selected, the LED will light up on the cartridge to designate the GI tract that   |                                                                                     |
|:-----------------------------------------------------------------------------------------|:------------------------------------------------------------------------------------|
| will be used for procedure.                                                              |                                                                                     |
| To switch between the ENDO Mentor Suite interchangeable cartridges:                      |                                                                                     |
| 1.                                                                                       | Insert your right hand in the groove at the bottom of the interchangeable cartridge |
|                                                                                          | and your left hand into the edge on the top of the cartridge and gently free the    |
|                                                                                          | cartridge. You should hear a click.                                                 |
| 2.   Pull the cartridge horizontally out. Store it in its designated cavity in the lower |                                                                                     |
|                                                                                          | drawer.                                                                             |
| 3.                                                                                       | Insert the desired cartridge with one hand in the groove and the other on the top   |
|                                                                                          | of the cartridge, push it horizontally into place. You should hear a click.         |

[OCR]
Chapter 2 ENDO Mentor Suite System

GI-BRONCH interchangeable cartridge

— &

Figure 2-4: GI-BRONCH interchangeable cartridge — lower orifice selected

Two symbols of the upper GI and lower Gl tracts are displayed on the GI-BRONCH
interchangeable cartridge indicating the relevant GI tract segment. Depending on the
module selected, the LED will light up on the cartridge to designate the Gl tract that
will be used for procedure.

To switch between the ENDO Mentor Suite interchangeable cartridges:

1. Insert your right hand in the groove at the bottom of the interchangeable cartridge
and your left hand into the edge on the top of the cartridge and gently free the
cartridge. You should hear a click.

2. Pull the cartridge horizontally out. Store it in its designated cavity in the lower
drawer.

3. Insert the desired cartridge with one hand in the groove and the other on the top
of the cartridge, push it horizontally into place. You should hear a click.

Note: The cartridge must be properly positioned prior to introducing the scopes.

surgicalscience Page 8


# Page 17

Chapter 2 
 ENDO Mentor Suite System
 
Page 9
 
Scope hanger 
 
Figure 2-5: Scope hanger – URO scope  
The scope hanger units are generic, each scope can fit in any hanger. 
Note: The resectoscope is hung on the tool tray and not on the scope hanger. 
Connecting the scope 
The GI scopes and BRONCH scope are connected to socket C at the front of the 
system.  
The rigid URO scopes are connected to sockets A and B; the BRONCH scope is used 
as a flexible URO scope and is connected to socket C. 
The resectoscope, used in TURP and HYST modules, is connected to socket C at the 
front of the system. 
To connect the scope:  
1.  Fit the scope connector exactly in the prongs and recesses of the system 
connector.  


[TABLE]
| Chapter 2                                                                        | ENDO Mentor Suite System   |
|:---------------------------------------------------------------------------------|:---------------------------|
| Scope hanger                                                                     |                            |
| F                                                                                |                            |
| i                                                                                |                            |
| gure 2-5: Scope hanger – URO scope                                               |                            |
| The scope hanger units are generic, each scope can fit in any hanger.            |                            |
| Note: The resectoscope is hung on the tool tray and not on the scope hanger.     |                            |
| Connecting the scope                                                             |                            |
| The GI scopes and BRONCH scope are connected to socket C at the front of the     |                            |
| system.                                                                          |                            |
| The rigid URO scopes are connected to sockets A and B; the BRONCH scope is used  |                            |
| as a flexible URO scope and is connected to socket C.                            |                            |
| The resectoscope, used in TURP and HYST modules, is connected to socket C at the |                            |
| front of the system.                                                             |                            |
| To connect the scope:                                                            |                            |
| 1.   Fit the scope connector exactly in the prongs and recesses of the system    |                            |
| connector.                                                                       |                            |
|                                                                                  | Page 9                     |

[OCR]
Chapter 2 ENDO Mentor Suite System

Scope hanger

Figure 2-5: Scope hanger - URO scope

The scope hanger units are generic, each scope can fit in any hanger.

Note: The resectoscope is hung on the tool tray and not on the scope hanger.

Connecting the scope

The GI scopes and BRONCH scope are connected to socket C at the front of the
system.

The rigid URO scopes are connected to sockets A and B; the BRONCH scope is used
as a flexible URO scope and is connected to socket C.

The resectoscope, used in TURP and HYST modules, is connected to socket C at the
front of the system.
To connect the scope:

1. Fit the scope connector exactly in the prongs and recesses of the system
connector.

surgicalscience Page 9


# Page 18

Chapter 2 
 ENDO Mentor Suite System
 
Page 10
 
2.  Turn the external dial on the scope connector to the right until you hear a click. 
To disconnect the scope: 
1.  Turn the dial to the left and remove the scope connector. 
Note: Bumping against the scope connector while connected may result in damage to both the 
scope and the system. 
 
Figure 2-6: System and scope connectors 
Extensions 
The GI and URO modules require an extension for performing certain procedures. The 
GI modality extension is on the left side of the ENDO Mentor Suite and the URO 
modality extension is on the back of the simulator. 


[TABLE]
| Chapter 2                                                                                   | ENDO Mentor Suite System   |
|:--------------------------------------------------------------------------------------------|:---------------------------|
| 2.   Turn the external dial on the scope connector to the right until you hear a click.     |                            |
| To disconnect the scope:                                                                    |                            |
| 1.   Turn the dial to the left and remove the scope connector.                              |                            |
| Note:  Bumping against the scope connector while connected may result in damage to both the |                            |
| scope and the system.                                                                       |                            |
| F                                                                                           |                            |
| i                                                                                           |                            |
| gure 2-6: System and scope connectors                                                       |                            |
| Extensions                                                                                  |                            |
| The GI and URO modules require an extension for performing certain procedures. The          |                            |
| GI modality extension is on the left side of the ENDO Mentor Suite and the URO              |                            |
| modality extension is on the back of the simulator.                                         |                            |
|                                                                                             | Page 10                    |

[OCR]
Chapter 2 ENDO Mentor Suite System

2. Turn the external dial on the scope connector to the right until you hear a click.

To disconnect the scope:
1. Turn the dial to the left and remove the scope connector.

Note: Bumping against the scope connector while connected may result in damage to both the
scope and the system.

Figure 2-6: System and scope connectors

Extensions

The GI and URO modules require an extension for performing certain procedures. The
Gl modality extension is on the left side of the ENDO Mentor Suite and the URO
modality extension is on the back of the simulator.

surgicalscience Page 10


# Page 19

Chapter 2 
 ENDO Mentor Suite System
 
Page 11
 
 
Figure 2-7: URO modality extension 
 
 
Figure 2-8: GI modality extension 
To open the extension:  
1.  Press gently the modality extension. It will pop out.  


[TABLE]
| Chapter 2                                                  | ENDO Mentor Suite System   |
|:-----------------------------------------------------------|:---------------------------|
| F                                                          |                            |
| i                                                          |                            |
| gure 2-7: URO modality extension                           |                            |
| F                                                          |                            |
| i                                                          |                            |
| gure 2-8: GI modality extension                            |                            |
| To open the extension:                                     |                            |
| 1.   Press gently the modality extension. It will pop out. |                            |
|                                                            | Page 11                    |

[OCR]
Chapter 2 ENDO Mentor Suite System

Figure 2-7: URO modality extension

Figure 2-8: GI modality extension

To open the extension:
1. Press gently the modality extension. It will pop out.

surgicalscience Page 11


# Page 20

Chapter 2 
 ENDO Mentor Suite System
 
Page 12
 
 
 
2.  Pull it to its full length. 
 
 
Figure 2-9: GI extension fully opened (left), URO extension fully opened (right) 
To close the extension: 
1.  Push the extension until it fits back in place. 
Working positions 
The ENDO Mentor Suite supports different working positions. 
GI Mentor: 
The user is operating in front of the simulator, facing the GI-BRONCH interchangeable 
cartridge. 
BRONCH Mentor: 
• 
Superior – the user is operating from behind the patient’s head. 
• 
Lateral – the user is operating laterally to the patient. 


[TABLE]
| Chapter 2                                                                             |
|  ENDO Mentor Suite System                                                             |
|:--------------------------------------------------------------------------------------|
| 2.   Pull it to its full length.                                                      |
| F                                                                                     |
| i                                                                                     |
| gure 2-9: GI extension fully opened (left), URO extension fully opened (right)        |
| To close the extension:                                                               |
| 1.   Push the extension until it fits back in place.                                  |
| Working positions                                                                     |
| The ENDO Mentor Suite supports different working positions.                           |
| GI Mentor:                                                                            |
| The user is operating in front of the simulator, facing the GI-BRONCH interchangeable |
| cartridge.                                                                            |
| BRONCH Mentor:                                                                        |
| Superior – the user is operating from behind the patient’s head.                      |
| •                                                                                     |
| Lateral – the user is operating laterally to the patient.                             |
| •                                                                                     |
| Page 12                                                                               |

[OCR]
Chapter 2 ENDO Mentor Suite System

2. Pull it to its full length.

4342 Ee

Figure 2-9: GI extension fully opened (left), URO extension fully opened (right)

To close the extension:
1. Push the extension until it fits back in place.

Working positions

The ENDO Mentor Suite supports different working positions.
GI Mentor:

The user is operating in front of the simulator, facing the GI-BRONCH interchangeable
cartridge.

BRONCH Mentor:

. Superior — the user is operating from behind the patient’s head.
e Lateral - the user is operating laterally to the patient.

surgicalscience Page 12


# Page 21

Chapter 2 
 ENDO Mentor Suite System
 
Page 13
 
URO Mentor: 
The user is operating in front of the simulator, facing the URO interchangeable 
cartridge. 
HYST Mentor: 
The user is operating in front of the simulator, facing the HYST interchangeable 
cartridge. 
  
Figure 2-10: HYST and URO Mentor working position 
 
The screen and the tool tray are adjustable to conveniently support each working 
position. 


[TABLE]
| Chapter 2                                                                        | ENDO Mentor Suite System   |
|:---------------------------------------------------------------------------------|:---------------------------|
| URO Mentor:                                                                      |                            |
| The user is operating in front of the simulator, facing the URO interchangeable  |                            |
| cartridge.                                                                       |                            |
| HYST Mentor:                                                                     |                            |
| The user is operating in front of the simulator, facing the HYST interchangeable |                            |
| cartridge.                                                                       |                            |

[OCR]
Chapter 2 ENDO Mentor Suite System

URO Mentor:

The user is operating in front of the simulator, facing the URO interchangeable
cartridge.

HYST Mentor:

The user is operating in front of the simulator, facing the HYST interchangeable
cartridge.

surgicalscience

Figure 2-10: HYST and URO Mentor working position

The screen and the tool tray are adjustable to conveniently support each working
position.

surgicalscience Page 13


# Page 22

Chapter 2 
 ENDO Mentor Suite System
 
Page 14
 
Height elevation mechanism 
The height of the ENDO Mentor Suite platform can be adjusted.  
 
Figure 2-11: Height elevation panel – (from left to right) USB port, Height Elevation mechanism, 
Computer On/Off button 
Use the Up and Down arrows on the Height Elevation panel to find the desired height.  
Note: The USB port can be used for example for connecting an external hard drive. 
Turning on the simulator 
1.  Make sure the On/Off Power switch on the back of the simulator is turned on. 
2.  Use the button to the right of the Height Elevation mechanism to turn on the ENDO 
Mentor Suite computer. 
 


[TABLE]
| Chapter 2                                                                              | ENDO Mentor Suite System                                                                       |
|:---------------------------------------------------------------------------------------|:-----------------------------------------------------------------------------------------------|
| Height elevation mechanism                                                             |                                                                                                |
| The height of the ENDO Mentor Suite platform can be adjusted.                          |                                                                                                |
| F                                                                                      | gure 2-11: Height elevation panel – (from left to right) USB port, Height Elevation mechanism, |
| i                                                                                      |                                                                                                |
| Computer On/Off button                                                                 |                                                                                                |
| Use the Up and Down arrows on the Height Elevation panel to find the desired height.   |                                                                                                |
| Note: The USB port can be used for example for connecting an external hard drive.      |                                                                                                |
| Turning on the simulator                                                               |                                                                                                |
| 1.   Make sure the On/Off Power switch on the back of the simulator is turned on.      |                                                                                                |
| 2.   Use the button to the right of the Height Elevation mechanism to turn on the ENDO |                                                                                                |
| Mentor Suite computer.                                                                 |                                                                                                |
|                                                                                        | Page 14                                                                                        |

[OCR]
Chapter 2 ENDO Mentor Suite System

Height elevation mechanism

The height of the ENDO Mentor Suite platform can be adjusted.

Figure 2-11: Height elevation panel — (from left to right) USB port, Height Elevation mechanism,
Computer On/Off button

Use the Up and Down arrows on the Height Elevation panel to find the desired height.

Note: The USB port can be used for example for connecting an external hard drive.

Turning on the simulator

1. Make sure the On/Off Power switch on the back of the simulator is turned on.
2. Use the button to the right of the Height Elevation mechanism to turn on the ENDO
Mentor Suite computer.

surgicalscience Page 14


# Page 23

Chapter 2 
 ENDO Mentor Suite System
 
Page 15
 
Tool tray 
The rotating tool tray holds all the tools for the ENDO Mentor Suite system: 
• 
Master Tool – URO Mentor, BRONCH Mentor, GI Mentor 
• 
URO forceps – URO Mentor 
• 
Syringe – BRONCH Mentor 
• 
EBUS needle – BRONCH Mentor 
• 
Red and blue wires – GI Mentor 
• 
Resectoscope – HYST and URO Mentor (TURP modules) 
Note: When not being used or upon moving the system, the tool tray must be stored in its 
original position to avoid damage. 
 
 
Figure 2-12: Tool tray hanger with resectoscope 
Note: The resectoscope is positioned on the tool tray so that the camera handle is above the 
HYST Mentor scope clip. 


[TABLE]
| Tool tray                                                                                 |                                                    |
|:------------------------------------------------------------------------------------------|:---------------------------------------------------|
| The rotating tool tray holds all the tools for the ENDO Mentor Suite system:              |                                                    |
| •                                                                                         | Master Tool – URO Mentor, BRONCH Mentor, GI Mentor |
| •                                                                                         | URO forceps – URO Mentor                           |
| •                                                                                         | Syringe – BRONCH Mentor                            |
| •                                                                                         | EBUS needle – BRONCH Mentor                        |
| •                                                                                         | Red and blue wires – GI Mentor                     |
| •                                                                                         | Resectoscope – HYST and URO Mentor (TURP modules)  |
| Note:  When not being used or upon moving the system, the tool tray must be stored in its |                                                    |
|                                                                                           | original position to avoid damage.                 |

[OCR_TABLE]
Chaptel

[OCR]
Chapter 2 ENDO Mentor Suite System

Tool tray

The rotating tool tray holds all the tools for the ENDO Mentor Suite system:

Master Tool - URO Mentor, BRONCH Mentor, GI Mentor
URO forceps — URO Mentor

Syringe - BRONCH Mentor

EBUS needle - BRONCH Mentor

Red and blue wires — GI Mentor

Resectoscope —- HYST and URO Mentor (TURP modules)

Note: When not being used or upon moving the system, the tool tray must be stored in its
original position to avoid damage.

Figure 2-12: Tool tray hanger with resectoscope

Note: The resectoscope is positioned on the tool tray so that the camera handle is above the
HYST Mentor scope clip.

surgicalscience Page 15


# Page 24

Chapter 2 
 ENDO Mentor Suite System
 
Page 16
 
 
Figure 2-13: Resectoscope hung on the tool tray 
Foot switch 
A triple foot switch is provided with the platform and utilized in some of the modules 
for actions such as application of electrosurgical current (left foot switch) or 
application of X-ray (right foot switch).  
The foot switch is utilized in the HYST modules for electrosurgical current: cutting 
(middle foot switch) and coagulation (right foot switch). 


[TABLE]
| F                                                                                      |
| i                                                                                      |
| gure 2-13: Resectoscope hung on the tool tray                                          |
|:---------------------------------------------------------------------------------------|
| Foot switch                                                                            |
| A triple foot switch is provided with the platform and utilized in some of the modules |
| for actions such as application of electrosurgical current (left foot switch) or       |
| application of X-ray (right foot switch).                                              |
| The foot switch is utilized in the HYST modules for electrosurgical current: cutting   |
| (middle foot switch) and coagulation (right foot switch).                              |

[OCR]
Chapter 2 ENDO Mentor Suite System

Figure 2-13: Resectoscope hung on the tool tray

Foot switch

A triple foot switch is provided with the platform and utilized in some of the modules
for actions such as application of electrosurgical current (left foot switch) or
application of X-ray (right foot switch).

The foot switch is utilized in the HYST modules for electrosurgical current: cutting
(middle foot switch) and coagulation (right foot switch).

surgicalscience Page 16


# Page 25

Chapter 2 
 ENDO Mentor Suite System
 
Page 17
 
 
Figure 2-14: Foot switch 
Available scope 
 
 
Make sure the scopes are not protruding before closing the drawer. 
Failing to do so may result in irreparable damage to the scopes. 


[TABLE]
| Chapter 2              | ENDO Mentor Suite System                                           |
|:-----------------------|:-------------------------------------------------------------------|
| F                      |                                                                    |
| i                      |                                                                    |
| gure 2-14: Foot switch |                                                                    |
| Available scope        |                                                                    |
|                        | Make sure the scopes are not protruding before closing the drawer. |
|                        | Failing to do so may result in irreparable damage to the scopes.   |
|                        | Page 17                                                            |

[OCR]
Chapter 2 ENDO Mentor Suite System

Figure 2-14: Foot switch

Available scope

Make sure the scopes are not protruding before closing the drawer.
Failing to do so may result in irreparable damage to the scopes.

surgicalscience Page 17


# Page 26

Chapter 2 
 ENDO Mentor Suite System
 
Page 18
 
Resectoscope 
 
 
Figure 2-15: Adapted resectoscope  
1 
Camera handle 
2 
Camera buttons 
3 
Zoom ring 
4 
Focus ring 
5 
Working element 
6 
Outflow valve 
7 
Outflow tube 
8 
Inflow valve 
9 
Inflow tube 
 


[TABLE]
| F   |   gure 2-15: Adapted resectoscope |                 |
| i   |                                   |                 |
|:----|----------------------------------:|:----------------|
|     |                                 1 | Camera handle   |
|     |                                 2 | Camera buttons  |
|     |                                 3 | Zoom ring       |
|     |                                 4 | Focus ring      |
|     |                                 5 | Working element |
|     |                                 6 | Outflow valve   |
|     |                                 7 | Outflow tube    |
|     |                                 8 | Inflow valve    |
|     |                                 9 | Inflow tube     |

[OCR]
Chapter 2 ENDO Mentor Suite System

Resectoscope

Figure 2-15: Adapted resectoscope

Camera handle
Camera buttons
Zoom ring

Focus ring
Working element
Outflow valve
Outflow tube

Inflow valve

oO aAnN Oo BR WYN

Inflow tube

surgicalscience Page 18


# Page 27

Chapter 2 
 ENDO Mentor Suite System
 
Page 19
 
Camera 
Resectoscope simulates the use of an endoscopic camera with a camera handle and a 
menu of optic angles. You can manipulate the camera exactly as you would manipulate 
a real endoscopic camera. When the camera is inserted, the screen displays a 
simulated image of the operative field and the image changes responsively when you 
move the camera inward and outward and side to side or rotate the camera. 
 
Figure 2-16: Resectoscope’s camera handle 
1 
Camera handle. Use the camera handle to hold the 
endoscopic camera. Once the scope is inserted, you can roll 
the camera in all directions. It is advisable to select an 
appropriate camera angle from the camera menu before use 
(see Camera angle options on page 36).  
2 
Middle button. Press the button to save images during 
procedure.  


[TABLE]
| Chapter 2                                                                    | ENDO Mentor Suite System                                                            |
|:-----------------------------------------------------------------------------|:------------------------------------------------------------------------------------|
| Camera                                                                       |                                                                                     |
|                                                                              | Resectoscope simulates the use of an endoscopic camera with a camera handle and a   |
|                                                                              | menu of optic angles. You can manipulate the camera exactly as you would manipulate |
| a real endoscopic camera. When the camera is inserted, the screen displays a |                                                                                     |
|                                                                              | simulated image of the operative field and the image changes responsively when you  |
| move the camera inward and outward and side to side or rotate the camera.    |                                                                                     |

[TABLE]
| F   | gure 2-16: Resectoscope’s camera handle                     |
| i   |                                                             |
|:----|:------------------------------------------------------------|
| 1   | Camera handle. Use the camera handle to hold the            |
|     | endoscopic camera. Once the scope is inserted, you can roll |
|     | the camera in all directions. It is advisable to select an  |
|     | appropriate camera angle from the camera menu before use    |
|     | (see Camera angle options on page 36).                      |
| 2   | Middle button. Press the button to save images during       |
|     | procedure.                                                  |

[OCR]
Chapter 2 ENDO Mentor Suite System

Camera

Resectoscope simulates the use of an endoscopic camera with a camera handle and a
menu of optic angles. You can manipulate the camera exactly as you would manipulate
a real endoscopic camera. When the camera is inserted, the screen displays a
simulated image of the operative field and the image changes responsively when you
move the camera inward and outward and side to side or rotate the camera.

Figure 2-16: Resectoscope’s camera handle

1 Camera handle. Use the camera handle to hold the
endoscopic camera. Once the scope is inserted, you can roll
the camera in all directions. It is advisable to select an
appropriate camera angle from the camera menu before use
(see Camera angle options on page 36).

2 Middle button. Press the button to save images during
procedure.

surgicalscience Page 19


# Page 28

Chapter 2 
 ENDO Mentor Suite System
 
Page 20
 
 3 Zoom ring. Turn the Zoom ring clockwise to zoom in (subject 
appears closer) and counterclockwise to zoom out (subject 
appears farther away). 
4 
Focus ring. Turn the Focus ring to achieve the sharpest 
possible image. 
 


[TABLE]
| Chapter 2   | ENDO Mentor Suite System                                       |
|:------------|:---------------------------------------------------------------|
|             | 3  Zoom ring. Turn the Zoom ring clockwise to zoom in (subject |
|             | appears closer) and counterclockwise to zoom out (subject      |
|             | appears farther away).                                         |
| 4           | Focus ring. Turn the Focus ring to achieve the sharpest        |
|             | possible image.                                                |
|             | Page 20                                                        |

[OCR]
Chapter 2 ENDO Mentor Suite System

3 Zoom ring. Turn the Zoom ring clockwise to zoom in (subject
appears closer) and counterclockwise to zoom out (subject
appears farther away).

4 Focus ring. Turn the Focus ring to achieve the sharpest
possible image.

surgicalscience Page 20


# Page 29

Chapter 3 
 HYST Mentor Library of Modules and Courses
 
Page 21
 
Chapter 3 HYST Mentor Library of Modules 
and Courses 
The HYST Mentor modules has been developed in close collaboration with the medical 
community to provide a meaningful and valuable training solution. It  provides the most 
comprehensive hysteroscopy hands-on training and practice opportunities for 
diagnostic and therapeutic procedures.  
Introduction to the use of hysteroscopy scopes is done by the practice of actual 
procedures on a variety of virtual patient cases, each with its own unique anatomy and 
pathologies. 
HYST Mentor modules  
Diagnostic 
Hysteroscopy  
The Diagnostic Hysteroscopy module offers a comprehensive 
learning experience across diverse clinical scenarios of 
hysteroscopy, including anatomical variations and various 
pathologies. 
Accompanied by comprehensive educational aids, trainees 
develop proficiency in instrument handling while navigating 
through the cervical canal into the uterus, using cameras and 
angled optics. During the procedure, trainees practice 
visualizing anatomical landmarks, managing irrigation fluid and 
fluid deficiencies, and managing complications such as 
controlling bleeding and preventing perforation. Throughout the 
procedure, trainees can monitor the patient's discomfort scale 
to ensure optimal care. 
Objectives 
• 
Safely navigate the scope through the cervical canal into 
the uterus 
• 
Establish uterine distension and left and right tubal orifice 
visualization 
• 
Achieve a clear endoscopic field while using irrigation 
fluid 
• 
Accurately identify uterine anatomy and detect visible 
pathologies 


[TABLE]
| pathologies.   |                         |                                                                 |
|:---------------|:------------------------|:----------------------------------------------------------------|
|                |                         | HYST Mentor modules                                             |
|                |                         | The Diagnostic Hysteroscopy module offers a comprehensive       |
|                |                         | learning experience across diverse clinical scenarios of        |
|                |                         | hysteroscopy, including anatomical variations and various       |
|                | pathologies.            |                                                                 |
|                |                         | Accompanied by comprehensive educational aids, trainees         |
|                |                         | develop proficiency in instrument handling while navigating     |
|                |                         | through the cervical canal into the uterus, using cameras and   |
|                |                         | angled optics. During the procedure, trainees practice          |
|                |                         | visualizing anatomical landmarks, managing irrigation fluid and |
|                |                         | fluid deficiencies, and managing complications such as          |
|                |                         | controlling bleeding and preventing perforation. Throughout the |
| Diagnostic     |                         |                                                                 |
|                |                         | procedure, trainees can monitor the patient's discomfort scale  |
| Hysteroscopy   |                         |                                                                 |
|                | to ensure optimal care. |                                                                 |
|                | Objectives              |                                                                 |
|                | •                       | Safely navigate the scope through the cervical canal into       |

[TABLE]
|                                                                | controlling bleeding and preventing perforation. Throughout the   |
|:---------------------------------------------------------------|:------------------------------------------------------------------|
| procedure, trainees can monitor the patient's discomfort scale |                                                                   |
| to ensure optimal care.                                        |                                                                   |
| Objectives                                                     |                                                                   |
| •                                                              | Safely navigate the scope through the cervical canal into         |
|                                                                | the uterus                                                        |
| •                                                              | Establish uterine distension and left and right tubal orifice     |
|                                                                | visualization                                                     |
| •                                                              | Achieve a clear endoscopic field while using irrigation           |
|                                                                | fluid                                                             |
| •                                                              | Accurately identify uterine anatomy and detect visible            |
|                                                                | pathologies                                                       |

[OCR_TABLE]
Chaoter 3

[OCR_TABLE]
Unap'’

[OCR]
Chapter 3 HYST Mentor Library of Modules and Courses

Chapter 3 HYST Mentor Library of Modules
and Courses

The HYST Mentor modules has been developed in close collaboration with the medical
community to provide a meaningful and valuable training solution. It provides the most
comprehensive hysteroscopy hands-on training and practice opportunities for
diagnostic and therapeutic procedures.

Introduction to the use of hysteroscopy scopes is done by the practice of actual
procedures on a variety of virtual patient cases, each with its own unique anatomy and
pathologies.

HYST Mentor modules

The Diagnostic Hysteroscopy module offers a comprehensive
learning experience across diverse clinical scenarios of
hysteroscopy, including anatomical variations and various
pathologies.

Accompanied by comprehensive educational aids, trainees
develop proficiency in instrument handling while navigating
through the cervical canal into the uterus, using cameras and
angled optics. During the procedure, trainees practice
visualizing anatomical landmarks, managing irrigation fluid and
fluid deficiencies, and managing complications such as
controlling bleeding and preventing perforation. Throughout the

pyaganestic procedure, trainees can monitor the patient's discomfort scale
ysteroscopy | to ensure optimal care.

Objectives

e Safely navigate the scope through the cervical canal into
the uterus

e Establish uterine distension and left and right tubal orifice
visualization

e Achieve a clear endoscopic field while using irrigation
fluid

e Accurately identify uterine anatomy and detect visible
pathologies

surgicalscience Page 21


# Page 30

Chapter 3 
 HYST Mentor Library of Modules and Courses
 
Page 22
 
 
 
 
Hysteroscopic 
Polypectomy 
module  
 
This module includes a variety of polyps in different positions 
and uterine anatomies for comprehensive training in polyp 
removal using a resectoscope. 
Accompanied by educational aids, trainees develop proficiency 
in instrument handling and safe use of the loop electrode for 
effective resection. 
During the procedure, trainees practice visualizing anatomical 
landmarks, managing irrigation fluid, tracking uterine fluid 
deficiency, and handling complications such as controlling 
bleeding and preventing perforation. 
Objectives 
• 
Establish uterine distension and visualize left and right 
tubal orifices 
• 
Achieve a clear endoscopic field while using irrigation 
fluid  
• 
Safely handle the loop electrode to avoid uterine 
perforation 
• 
Effective resection of polyps 
• 
Identify bleeding sources and coagulate them accurately 
with the loop electrode 
Hysteroscopic 
Myomectomy 
module  
This module includes a variety of myomas in different positions 
and uterine anatomies for comprehensive training in myoma 
removal using a resectoscope. 
Accompanied by educational aids, trainees develop proficiency 
in instrument handling and safe use of the loop electrode for 
effective resection. 
During the procedure, trainees practice visualizing anatomical 
landmarks, managing irrigation fluid, tracking uterine fluid 
deficiency, and handling complications such as controlling 
bleeding and preventing perforation. 
Objectives 
• 
Establish uterine distension and visualize left and right 
tubal orifices 
• 
Achieve a clear endoscopic field while using irrigation 
fluid  


[TABLE]
| Chapter 3     |                      | HYST Mentor Library of Modules and Courses                      |
|:--------------|:---------------------|:----------------------------------------------------------------|
|               |                      | This module includes a variety of polyps in different positions |
|               |                      | and uterine anatomies for comprehensive training in polyp       |
|               |                      | removal using a resectoscope.                                   |
|               |                      | Accompanied by educational aids, trainees develop proficiency   |
|               |                      | in instrument handling and safe use of the loop electrode for   |
| Hysteroscopic |                      |                                                                 |
|               | effective resection. |                                                                 |
| Polypectomy   |                      |                                                                 |
|               |                      | During the procedure, trainees practice visualizing anatomical  |
| module        |                      |                                                                 |
|               |                      | landmarks, managing irrigation fluid, tracking uterine fluid    |
|               |                      | deficiency, and handling complications such as controlling      |
|               |                      | bleeding and preventing perforation.                            |
|               | Objectives           |                                                                 |
|               | •                    | Establish uterine distension and visualize left and right       |

[TABLE]
| landmarks, managing irrigation fluid, tracking uterine fluid   |                                                           |
|:---------------------------------------------------------------|:----------------------------------------------------------|
| deficiency, and handling complications such as controlling     |                                                           |
| bleeding and preventing perforation.                           |                                                           |
| Objectives                                                     |                                                           |
| •                                                              | Establish uterine distension and visualize left and right |
|                                                                | tubal orifices                                            |
| •                                                              | Achieve a clear endoscopic field while using irrigation   |
|                                                                | fluid                                                     |
| •                                                              | Safely handle the loop electrode to avoid uterine         |
|                                                                | perforation                                               |
| •                                                              | Effective resection of polyps                             |
| •                                                              | Identify bleeding sources and coagulate them accurately   |
|                                                                | with the loop electrode                                   |

[OCR_TABLE]
Chapter 3

[OCR]
Chapter 3 HYST Mentor Library of Modules and Courses

This module includes a variety of polyps in different positions
and uterine anatomies for comprehensive training in polyp
removal using a resectoscope.

Accompanied by educational aids, trainees develop proficiency
in instrument handling and safe use of the loop electrode for

Hysteroscopic effective resection.

Polypectomy ° ; ; ; . ;
module During the procedure, trainees practice visualizing anatomical

landmarks, managing irrigation fluid, tracking uterine fluid
deficiency, and handling complications such as controlling
bleeding and preventing perforation.

Objectives

e Establish uterine distension and visualize left and right
tubal orifices

° Achieve a clear endoscopic field while using irrigation
fluid

e Safely handle the loop electrode to avoid uterine
perforation

e Effective resection of polyps

e Identify bleeding sources and coagulate them accurately

with the loop electrode

Hysteroscopic | This module includes a variety of myomas in different positions

Myomectomy | and uterine anatomies for comprehensive training in myoma
module removal using a resectoscope.

Accompanied by educational aids, trainees develop proficiency

in instrument handling and safe use of the loop electrode for

effective resection.

During the procedure, trainees practice visualizing anatomical
landmarks, managing irrigation fluid, tracking uterine fluid
deficiency, and handling complications such as controlling
bleeding and preventing perforation.

Objectives

e Establish uterine distension and visualize left and right
tubal orifices

° Achieve a clear endoscopic field while using irrigation
fluid

surgicalscience Page 22


# Page 31

Chapter 3 
 HYST Mentor Library of Modules and Courses
 
Page 23
 
• 
Safely handle the loop electrode to avoid uterine 
perforation 
• 
Effective resection of myomas 
• 
Identify bleeding sources and coagulate them accurately 
with the loop electrode 
 
 
 
 
 


[TABLE]
|    | HYST Mentor Library of Modules and Courses              |
|:---|:--------------------------------------------------------|
| •  | Safely handle the loop electrode to avoid uterine       |
|    | perforation                                             |
| •  | Effective resection of myomas                           |
| •  | Identify bleeding sources and coagulate them accurately |
|    | with the loop electrode                                 |

[OCR]
Chapter 3 HYST Mentor Library of Modules and Courses

e Safely handle the loop electrode to avoid uterine
perforation

e Effective resection of myomas

e Identify bleeding sources and coagulate them accurately

with the loop electrode

surgicalscience Page 23


# Page 32

Chapter 4 
 Getting Started
 
Page 24
 
Chapter 4 Getting Started 
Workflow 
The following chapters will describe how to use the simulator. To get started on any 
simulation case or task, follow this workflow. 
1.  Log in to MentorLearn on the simulator (see page 26). 
2.  Start a simulation case or task (see page 31). 
3.  Perform the simulation case. 
4.  Learn more about the HYST modules main features and controls: 
a. How to use angled optics (see page 36) and tool options (see page 45). 
b. How to use simulation aids for diagnostic hysteroscopy (see page 42) and 
simulation aids for clinical procedures (see page 46). 
c. How to use the patient discomfort scale (on page 43). 
d. How to use the fluid management system (on page 48). 
e. How to use resectoscope (see page 49). 
f. 
How to use scope’s camera (see page 52). 
5.  When the case is completed, review your performance report and learning curve 
graphs (see Viewing Performance Reports on page 55). 
 


[TABLE]
| Chapter 4                                                                            | Getting Started   |
|:-------------------------------------------------------------------------------------|:------------------|
| Chapter 4  Getting Started                                                           |                   |
| Workflow                                                                             |                   |
| The following chapters will describe how to use the simulator. To get started on any |                   |
| simulation case or task, follow this workflow.                                       |                   |
| 1.   Log in to MentorLearn on the simulator (see page 26).                           |                   |
| 2.   Start a simulation case or task (see page 31).                                  |                   |
| 3.   Perform the simulation case.                                                    |                   |
| 4.   Learn more about the HYST modules main features and controls:                   |                   |

[TABLE]
| 1.   Log in to MentorLearn on the simulator (see page 26).                         |                                                                              |
|:-----------------------------------------------------------------------------------|:-----------------------------------------------------------------------------|
| 2.   Start a simulation case or task (see page 31).                                |                                                                              |
| 3.   Perform the simulation case.                                                  |                                                                              |
| 4.   Learn more about the HYST modules main features and controls:                 |                                                                              |
|                                                                                    | a.  How to use angled optics (see page 36) and tool options (see page 45).   |
|                                                                                    | b.  How to use simulation aids for diagnostic hysteroscopy (see page 42) and |
|                                                                                    | simulation aids for clinical procedures (see page 46).                       |
|                                                                                    | c.  How to use the patient discomfort scale (on page 43).                    |
|                                                                                    | d.  How to use the fluid management system (on page 48).                     |
|                                                                                    | e.  How to use resectoscope (see page 49).                                   |
| f.                                                                                 | How to use scope’s camera (see page 52).                                     |
| 5.   When the case is completed, review your performance report and learning curve |                                                                              |
|                                                                                    | graphs (see Viewing Performance Reports on page 55).                         |

[OCR]
Chapter 4

Getting Started

| Chapter 4 Getting Started
Workflow

The following chapters will describe how to use the simulator. To get started on any
simulation case or task, follow this workflow.

1.

2.
3.
4.

Log in to MentorLearn on the simulator (see page 26).

Start a simulation case or task (see page 31).

Perform the simulation case.
Learn more about the HYST modules main features and controls:

a.
b.

c.
d.
e
f.

How to use angled optics (see page 36) and tool options (see page 45).
How to use simulation aids for diagnostic hysteroscopy (see page 42) and

simulation aids for clinical procedures (see page 46).
How to use the patient discomfort scale (on page 43).
How to use the fluid management system (on page 48).
How to use resectoscope (see page 49).

How to use scope’s camera (see page 52).

When the case is completed, review your performance report and learning curve
graphs (see Viewing Performance Reports on page 55).

surgicalscience Page 24


# Page 33

Chapter 5 
 MentorLearn
 
Page 25
 
Chapter 5 MentorLearn 
MentorLearn overview 
MentorLearn® is a web-based simulator curricula management system, providing the 
optimal solution for managing training and education needs for the Surgical Science line 
of simulators.  
This easy-to-use system facilitates performing the administrative tasks of a simulator-
based curriculum, running a training course or workshop. The system includes a library of 
ready-to-use simulator-based courses and a platform to design new training courses. 
Courses may include online didactic content, proficiency based hands-on training, and 
performance review and assessment. For more information regarding using MentorLearn, 
refer to the MentorLearn Guide for Learners. 
MentorLearn workflow 
All HYST Mentor modules, including simulation tasks and cases, are accessed from 
MentorLearn, Surgical Science's web-based simulation curricula management system. 
When you want to perform a hands-on training task or case, you open it from 
MentorLearn. MentorLearn opens the HYST Mentor task or case for you, closes it when 
you finish the case or task, and shows you a report of your performance afterwards. This 
is the workflow for performing hands-on training: 
• 
Log in to MentorLearn on the simulator (see page 26). 
• 
Start a hands-on case or task from MentorLearn (see Starting a simulation case or 
task on page 31). MentorLearn opens it for you to begin the hands-on simulation. 
• 
Perform the case or task using the HYST Mentor simulator. When you finish the 
case or task, MentorLearn closes it and displays a performance report. 
• 
Review your performance (see Viewing Performance Reports on page 55). 
 


[TABLE]
| Chapter 5                                                                               | MentorLearn                                                                               |
|:----------------------------------------------------------------------------------------|:------------------------------------------------------------------------------------------|
| Chapter 5  MentorLearn                                                                  |                                                                                           |
| MentorLearn overview                                                                    |                                                                                           |
| MentorLearn® is a web-based simulator curricula management system, providing the        |                                                                                           |
|                                                                                         | optimal solution for managing training and education needs for the Surgical Science line  |
| of simulators.                                                                          |                                                                                           |
| This easy-to-use system facilitates performing the administrative tasks of a simulator- |                                                                                           |
|                                                                                         | based curriculum, running a training course or workshop. The system includes a library of |
| ready-to-use simulator-based courses and a platform to design new training courses.     |                                                                                           |
| Courses may include online didactic content, proficiency based hands-on training, and   |                                                                                           |
|                                                                                         | performance review and assessment. For more information regarding using MentorLearn,      |
| refer to the MentorLearn Guide for Learners.                                            |                                                                                           |
| MentorLearn workflow                                                                    |                                                                                           |
| All HYST Mentor modules, including simulation tasks and cases, are accessed from        |                                                                                           |
| MentorLearn, Surgical Science's web-based simulation curricula management system.       |                                                                                           |
| When you want to perform a hands-on training task or case, you open it from             |                                                                                           |
|                                                                                         | MentorLearn. MentorLearn opens the HYST Mentor task or case for you, closes it when       |
|                                                                                         | you finish the case or task, and shows you a report of your performance afterwards. This  |
| is the workflow for performing hands-on training:                                       |                                                                                           |

[TABLE]
| When you want to perform a hands-on training task or case, you open it from              |                                                                                   |
|:-----------------------------------------------------------------------------------------|:----------------------------------------------------------------------------------|
| MentorLearn. MentorLearn opens the HYST Mentor task or case for you, closes it when      |                                                                                   |
| you finish the case or task, and shows you a report of your performance afterwards. This |                                                                                   |
| is the workflow for performing hands-on training:                                        |                                                                                   |
| •                                                                                        | Log in to MentorLearn on the simulator (see page 26).                             |
| •                                                                                        | Start a hands-on case or task from MentorLearn (see Starting a simulation case or |
|                                                                                          | task on page 31). MentorLearn opens it for you to begin the hands-on simulation.  |
| •                                                                                        | Perform the case or task using the HYST Mentor simulator. When you finish the     |
|                                                                                          | case or task, MentorLearn closes it and displays a performance report.            |
| •                                                                                        | Review your performance (see Viewing Performance Reports on page 55).             |

[OCR_TABLE]
SIS ESN

[OCR]
Chapter 5 MentorLearn

| Chapter 5 MentorLearn

MentorLearn overview

MentorLearn® is a web-based simulator curricula management system, providing the
optimal solution for managing training and education needs for the Surgical Science line
of simulators.

This easy-to-use system facilitates performing the administrative tasks of a simulator-
based curriculum, running a training course or workshop. The system includes a library of
ready-to-use simulator-based courses and a platform to design new training courses.
Courses may include online didactic content, proficiency based hands-on training, and
performance review and assessment. For more information regarding using MentorLearn,
refer to the MentorLearn Guide for Learners.

MentorLearn workflow

All HYST Mentor modules, including simulation tasks and cases, are accessed from
MentorLearn, Surgical Science's web-based simulation curricula management system.

When you want to perform a hands-on training task or case, you open it from
MentorLearn. MentorLearn opens the HYST Mentor task or case for you, closes it when
you finish the case or task, and shows you a report of your performance afterwards. This
is the workflow for performing hands-on training:

e Log in to MentorLearn on the simulator (see page 26).

e Start a hands-on case or task from MentorLearn (see Starting a simulation case or
task on page 31). MentorLearn opens it for you to begin the hands-on simulation.

. Perform the case or task using the HYST Mentor simulator. When you finish the
case or task, MentorLearn closes it and displays a performance report.

. Review your performance (see Viewing Performance Reports on page 55).

surgicalscience Page 25


# Page 34

Chapter 5 
 MentorLearn
 
Page 26
 
Logging in to MentorLearn on the simulator 
In order to access functionality on a simulator, you need to first enter the MentorLearn 
system. You require a login name and password to login. When you log in, your Library 
screen is displayed. For more information regarding using MentorLearn, refer to the 
MentorLearn Guide for Learners or MentorLearn Guide for Administrators. 
Note: If you are entering the application for the first time, contact your system administrator and 
ask him to create your user profile.  
To log in: 
 
1. Press Login.  
The Login screen is displayed. 


[TABLE]
| Chapter 5                                                                                     |
|  MentorLearn                                                                                  |
|:----------------------------------------------------------------------------------------------|
| Logging in to MentorLearn on the simulator                                                    |
| In order to access functionality on a simulator, you need to first enter the MentorLearn      |
| system. You require a login name and password to login. When you log in, your Library         |
| screen is displayed. For more information regarding using MentorLearn, refer to the           |
| MentorLearn Guide for Learners or MentorLearn Guide for Administrators.                       |
| Note:                                                                                         |
| If you are entering the application for the first time, contact your system administrator and |
| ask him to create your user profile.                                                          |
| To log in:                                                                                    |

[OCR]
Chapter 5 MentorLearn

Logging in to MentorLearn on the simulator

In order to access functionality on a simulator, you need to first enter the MentorLearn
system. You require a login name and password to login. When you log in, your Library
screen is displayed. For more information regarding using MentorLearn, refer to the
MentorLearn Guide for Learners or MentorLearn Guide for Administrators.

Note: If you are entering the application for the first time, contact your system administrator and
ask him to create your user profile.

To log in:

Register to use the system

Select Language

English

Select Theme

Light

1. Press Login.
The Login screen is displayed.

surgicalscience Page 26


# Page 35

Chapter 5 
 MentorLearn
 
Page 27
 
 
2. In Login Name, enter your login name. The login name is case sensitive. 
3. In Password, enter your password. Your password is case sensitive. 
4. Press Login. 
MentorLearn opens and displays your Library screen. Your first name and last name 
appear in the top right corner of the screen. 


[TABLE]
| Chapter 5                                                                         |
|  MentorLearn                                                                      |
|:----------------------------------------------------------------------------------|
| In Login Name, enter your login name. The login name is case sensitive.           |
| 2.                                                                                |
| In Password, enter your password. Your password is case sensitive.                |
| 3.                                                                                |
| 4.  Press Login.                                                                  |
| MentorLearn opens and displays your Library screen. Your first name and last name |
| appear in the top right corner of the screen.                                     |
| Page 27                                                                           |

[OCR_TABLE]
| SUI

[OCR]
Chapter 5 MentorLearn

surgicalscience | simbionix simulators

Login Name

BhattieWy

Password

LOGIN

Forgot Password?

LOGIN AS A GUEST

RETURN TO MAIN PAGE

2. In Login Name, enter your login name. The login name is case sensitive.
3. In Password, enter your password. Your password is case sensitive.
4. Press Login.

MentorLearn opens and displays your Library screen. Your first name and last name
appear in the top right corner of the screen.

surgicalscience Page 27


# Page 36

Chapter 5 
 MentorLearn
 
Page 28
 
When you log in to MentorLearn, the MentorLearn menu appears on the left side of 
the screen. 
 
The menu gives you structured access to the MentorLearn functionality. Press any 
menu option to open the associated screen in MentorLearn. Press 
 above the 
MentorLearn menu to hide it. 
Note: The buttons that appear on the MentorLearn menu are dependent on your user-
type. 
Working locally and on a cloud site 
The cloud configuration is possible only if there is access to the internet. If there is 
temporarily no internet access but you need to use the simulators, you can switch to 
working locally on the simulator.  
When you switch to work locally, MentorLearn switches from the cloud database to a 
local database, meaning:  
• 
Group, user, and assigned course information is not saved to the local simulator. If 
necessary, groups and users must be redefined on each local simulator, and 
training must be reassigned. 
• 
Any data that is created during the time you are working locally is not saved to the 
cloud database after the simulator is switched back to the cloud site. Any reports or 
information on how a user performed a simulator case will not be available, new 
users and groups, and so on, are maintained in the local database and are not 
available when you are in a cloud site. 
 


[TABLE]
| Note: The buttons that appear on the MentorLearn menu are dependent on your user-        |
|:-----------------------------------------------------------------------------------------|
| type.                                                                                    |
| Working locally and on a cloud site                                                      |
| The cloud configuration is possible only if there is access to the internet. If there is |
| temporarily no internet access but you need to use the simulators, you can switch to     |
| working locally on the simulator.                                                        |
| When you switch to work locally, MentorLearn switches from the cloud database to a       |
| local database, meaning:                                                                 |

[TABLE]
| working locally on the simulator.                                                  |                                                                                       |
|:-----------------------------------------------------------------------------------|:--------------------------------------------------------------------------------------|
| When you switch to work locally, MentorLearn switches from the cloud database to a |                                                                                       |
| local database, meaning:                                                           |                                                                                       |
| •                                                                                  | Group, user, and assigned course information is not saved to the local simulator. If  |
|                                                                                    | necessary, groups and users must be redefined on each local simulator, and            |
|                                                                                    | training must be reassigned.                                                          |
| •                                                                                  | Any data that is created during the time you are working locally is not saved to the  |
|                                                                                    | cloud database after the simulator is switched back to the cloud site. Any reports or |
|                                                                                    | information on how a user performed a simulator case will not be available, new       |
|                                                                                    | users and groups, and so on, are maintained in the local database and are not         |
|                                                                                    | available when you are in a cloud site.                                               |

[OCR_TABLE]
Librar

[OCR]
Chapter 5 MentorLearn

When you log in to MentorLearn, the MentorLearn menu appears on the left side of
he screen.

Library
My Curricula
Reports

My Profile

The menu gives you structured access to the MentorLearn functionality. Press any

menu option to open the associated screen in MentorLearn. Press =| above the
MentorLearn menu to hide it.

Note: The buttons that appear on the MentorLearn menu are dependent on your user-
type.

Working locally and on a cloud site

The cloud configuration is possible only if there is access to the internet. If there is
temporarily no internet access but you need to use the simulators, you can switch to
working locally on the simulator.

When you switch to work locally, MentorLearn switches from the cloud database to a
local database, meaning:

Group, user, and assigned course information is not saved to the local simulator. If
necessary, groups and users must be redefined on each local simulator, and
training must be reassigned.

Any data that is created during the time you are working locally is not saved to the
cloud database after the simulator is switched back to the cloud site. Any reports or
information on how a user performed a simulator case will not be available, new
users and groups, and so on, are maintained in the local database and are not
available when you are in a cloud site.

surgicalscience Page 28


# Page 37

Chapter 5 
 MentorLearn
 
Page 29
 
To switch from working on the MentorLearn cloud site to working locally: 
1.  Open MentorLearn on the simulator. MentorLearn is redirected to work locally with the 
selected simulator. The 
 icon on the top of any screen changes to the 
 icon.  
Note: It is recommended that you switch back to cloud mode as soon as the internet connection is 
restored. 
 
To switch from working locally to working on the MentorLearn cloud site: 
1.  Open the web browser and go to http://Your-site-name.mentorlearn.com    
MentorLearn is redirected to work with the MentorLearn cloud database. The 
 
icon on the top of any screen changes to the 
 icon. 
Accessing a module or course within My Curricula or 
Library 
This section describes how users train using MentorLearn. 
• 
To access training courses and modules that you have been assigned, press My 
Curricula on the MentorLearn menu (left pane). 
 
Figure 4-1: My Curricula screen 
• 
To access all the training courses and modules available in the library, press Library 
on the MentorLearn menu (left pane). 


[TABLE]
| Chapter 5                                                                                        |
|  MentorLearn                                                                                     |
|:-------------------------------------------------------------------------------------------------|
| To switch from working on the MentorLearn cloud site to working locally:                         |
| 1.   Open MentorLearn on the simulator. MentorLearn is redirected to work locally with the       |
| selected simulator. The                                                                          |
|  icon on the top of any screen changes to the                                                    |
|  icon.                                                                                           |
| Note: It is recommended that you switch back to cloud mode as soon as the internet connection is |
| restored.                                                                                        |
| T                                                                                                |
| o switch from working locally to working on the MentorLearn cloud site:                          |
| 1.   Open the web browser and go to http://Your-site-name.mentorlearn.com                        |
| MentorLearn is redirected to work with the MentorLearn cloud database. The                       |
| icon on the top of any screen changes to the                                                     |
|  icon.                                                                                           |
| Accessing a module or course within My Curricula or                                              |
| Library                                                                                          |
| This section describes how users train using MentorLearn.                                        |
| To access training courses and modules that you have been assigned, press My                     |
| •                                                                                                |
| Curricula on the MentorLearn menu (left pane).                                                   |
| F                                                                                                |
| i                                                                                                |
| gure 4-1: My Curricula screen                                                                    |
| To access all the training courses and modules available in the library, press Library           |
| •                                                                                                |
| on the MentorLearn menu (left pane).                                                             |
| Page 29                                                                                          |

[OCR]
Chapter 5 MentorLearn

To switch from working on the MentorLearn cloud site to working locally:
1. Open MentorLearn on the simulator. MentorLearn is redirected to work locally with the

selected simulator. The & icon on the top of any screen changes to the Q icon.

Note: It is recommended that you switch back to cloud mode as soon as the internet connection is
restored.

To switch from working locally to working on the MentorLearn cloud site:
1. Open the web browser and go to http://Your-site-name.mentorlearn.com

MentorLearn is redirected to work with the MentorLearn cloud database. The Q
icon on the top of any screen changes to the ® icon.

Accessing a module or course within My Curricula or
Library

This section describes how users train using MentorLearn.

e To access training courses and modules that you have been assigned, press My
Curricula on the MentorLearn menu (left pane).

First Year Residents

iy > | diagnostic Hysteroscopy .
an

FS | systeroscopic Polypectomy
g

P iil Hysteroscopic Myomectomy ¥

Figure 4-1: My Curricula screen

. To access all the training courses and modules available in the library, press Library
on the MentorLearn menu (left pane).

surgicalscience Page 29


# Page 38

Chapter 5 
 MentorLearn
 
Page 30
 
 
Figure 4-2: HYST Mentor Library screen  
On the Library screen, MentorLearn displays the list of modules and courses. They are 
categorized as Simbionix Modules, Standard Courses (ready-to-use courses provided by 
experienced educators in collaboration with Surgical Science), and Customized Courses 
(courses you and other educators at your center have created). 
Easy Access to courses and modules in the Library 
 
To easily access courses and modules in 
the Library, press the Easy Access arrow 
on the top right side of the screen and 
select an option from the list. 
To search for a specific module or group 
of modules, press the Search button, 
enter a term and press the Search button 
again. To clear the search results, press 
one of the easy access options. 
 
Open a module or course and perform in a hands-on simulation case. For more 
information, see Starting a simulation case or task on page 31. 
 
1.  To open a module or course, press its row. The module opens, displaying a 
description of the module, its learning objectives, and the educational content of the 
module. 


[TABLE]
| F                                                                                     |
| i                                                                                     |
| gure 4-2: HYST Mentor Library screen                                                  |
|:--------------------------------------------------------------------------------------|
| On the Library screen, MentorLearn displays the list of modules and courses. They are |
| categorized as Simbionix Modules, Standard Courses (ready-to-use courses provided by  |
| experienced educators in collaboration with Surgical Science), and Customized Courses |
| (courses you and other educators at your center have created).                        |
| Easy Access to courses and modules in the Library                                     |

[TABLE]
| Easy Access to courses and modules in the Library   |
|:----------------------------------------------------|
| To easily access courses and modules in             |
| the Library, press the Easy Access arrow            |
| on the top right side of the screen and             |
| select an option from the list.                     |
| To search for a specific module or group            |
| of modules, press the Search button,                |
| enter a term and press the Search button            |
| again. To clear the search results, press           |
| one of the easy access options.                     |

[OCR]
Chapter 5 MentorLearn

HYST Mentor Q displays ~ @ O i

Simbionix Modules

Basic Sklls and Diagnostic Hysteroscopy

PVP? oiacnostc Hysterosco S
| Diagnostic Hy PY

Therapeutic Hysteroscopy

PAZ] tyeterosconie Potyectomny ¥

Figure 4-2: HYST Mentor Library screen

On the Library screen, MentorLearn displays the list of modules and courses. They are
categorized as Simbionix Modules, Standard Courses (ready-to-use courses provided by
experienced educators in collaboration with Surgical Science), and Customized Courses
(courses you and other educators at your center have created).

Easy Access to courses and modules in the Library

To easily access courses and modules in

Q_DisplayAll ~ the Library, press the Easy Access arrow
on the top right side of the screen and
select an option from the list.

To search for a specific module or group
of modules, press the Search button,
Customized Courses enter a term and press the Search button
again. To clear the search results, press
one of the easy access options.

Display All

Standard Courses

Modules

Open a module or course and perform in a hands-on simulation case. For more
information, see Starting a simulation case or task on page 31.

1. To open a module or course, press its row. The module opens, displaying a
description of the module, its learning objectives, and the educational content of the
module.

surgicalscience Page 30


# Page 39

Chapter 5 
 MentorLearn
 
Page 31
 
 
Figure 4-3: Opening a module 
 
Starting a simulation case or task 
To open a case or task: 
1.  From the MentorLearn menu, press one of the following menu options: 
o 
Library - lists all the courses and modules in the HYST Mentor library. If other 
simulator libraries are listed, select Library > HYST Mentor. 
o 
My Curricula - lists all your assigned courses and modules. 
2.  Press the Expand arrow 
 on the right side of the screen to display more details 
about the module or course. 


[TABLE]
| Chapter 5                                                                | MentorLearn                                                                      |
|:-------------------------------------------------------------------------|:---------------------------------------------------------------------------------|
| F                                                                        |                                                                                  |
| i                                                                        |                                                                                  |
| gure 4-3: Opening a module                                               |                                                                                  |
| Starting a simulation case or task                                       |                                                                                  |
| To open a case or task:                                                  |                                                                                  |
| 1.   From the MentorLearn menu, press one of the following menu options: |                                                                                  |
|                                                                          | Library - lists all the courses and modules in the HYST Mentor library. If other |
| o                                                                        |                                                                                  |
|                                                                          | simulator libraries are listed, select Library > HYST Mentor.                    |
|                                                                          | My Curricula - lists all your assigned courses and modules.                      |
| o                                                                        |                                                                                  |
| 2.   Press the Expand arrow                                              | on the right side of the screen to display more details                          |
| about the module or course.                                              |                                                                                  |
|                                                                          | Page 31                                                                          |

[OCR]
Chapter 5 MentorLearn

€ _HYSTMentor > Diagnostic Hysteroscopy

Diagnostic Hysteroscopy

Curriculum Deseription
‘The Diagnostic Hysteroscopy module offers @ comprehensive learning experience across diverse clinical scenarios of hysteroscopy, including anatomical variations and various pathologies.
‘Accompanied by comprehensive educational aids, trainees develop proficiency in instrument handling while navigating through the cervical canal into the uterus, using cameras and angled
‘optics. During the procedure, trainees practice visualizing anatomical landmarks, managing ivigation fluid and fuid deficiencies, and managing complications such as controlling bleeding and
preventing perforation. Throughout the procedure, trainees can monitor the patients discomfort scale to ensure optimal care.

objectives
+ To safely navigate the scope through the cervical canal into the uterus
+ Toestablish uterine distension and left and right tubal orifice visualization
+ Achieve a clear endoscopic field while using iigation fluid
+ To accurately identify uterine anatomy and detect visible pathologies

v More.

Diagnostic Hysteroscopy Assignment
Hands-On

PP] Diagnostics Case 1
attempts 4

ae

te

Diagnostics Case 3
attempte:4

Fe.
Mog) sitempts:4
Pr] Diagnostics Case 5
patempte 8

ae

Figure 4-3: Opening a module

Starting a simulation case or task

To open a case or task:
1. From the MentorLearn menu, press one of the following menu options:
° Library - lists all the courses and modules in the HYST Mentor library. If other

simulator libraries are listed, select Library > HYST Mentor.
° My Curricula - lists all your assigned courses and modules.

v

2. Press the Expand arrow on the right side of the screen to display more details

about the module or course.

surgicalscience Page 31


# Page 40

Chapter 5 
 MentorLearn
 
Page 32
 
 
 
3.  Open the module or course you want by pressing its row. 
The details include a description and the objectives of the module or course. 
 
4.  Under Hands-on, select the case or task you want to perform, and press its row. The 
task description or patient file opens. 


[TABLE]
| Chapter 5                                                                     | MentorLearn                                                                              |
|:------------------------------------------------------------------------------|:-----------------------------------------------------------------------------------------|
| 3.   Open the module or course you want by pressing its row.                  |                                                                                          |
| The details include a description and the objectives of the module or course. |                                                                                          |
|                                                                               | 4.   Under Hands-on, select the case or task you want to perform, and press its row. The |
| task description or patient file opens.                                       |                                                                                          |
|                                                                               | Page 32                                                                                  |

[OCR]
Chapter 5 MentorLearn

y i) © | viagnostic Hysteroscopy
Les}

Description
‘The Diagnostic Hysteroscopy module offers a comprehensive leaming experience across diverse clinical scenarios of hysteroscopy, including anatomical variations and various pathologies.
‘Accompanied by comprehensive educational zids, trainees develop proficiency in instrument handling while navigating through the cervical canal into the uterus, using cameras and angled
‘optics. During the procedure, trainees practice visualizing anatomical landmarks, managing irigation fluid and fuid deficiencies, and menaging complications such as controlling bleeding and
preventing perforation. Throughout the procedure, trainees can monitor the patient's ciscamfort scale to ensure optimal care

Objectives
Safely navigate the scope through the cervical canal into the uterus Establish uterine distension and left and right tubal ostia visualization Achiave a clear endoscopic field while using
lirigation Nuid Accurately identify uterine anatomy and detect visible pathologies

3. Open the module or course you want by pressing its row.
The details include a description and the objectives of the module or course.

€ _HYSTMemtor Hysteroscopie Polypectomy

Hysteroscopic Polypectomy

Curriculum Deseription
‘This module includes @ variety of polyps indifferent positions and uterine anatomies for comprehensive training in polyp removal using a resectoscope.

‘Accompanied by educational aids, trainees develop proficiency in instrument handling and safe use of the loop electrode for effective resection.

During the procedure, trainees practice visualizing anatomical landmarks, managing itigation fuid, tracking uterine deficiency, and handling complications such as controling bleeding and

preventing perforation

Objectives
+ Establish uterine distension and visualize left and right tubal orifices
+ Achieve a clear endoscopic field while using irigation fluid
+ Safely handle the loop electrode to avoid uterine perforation
+ Effective resection of polyps:
+ Identity bleeding sources and coagulate them accurately withthe loop electrode

Hysteroscopic Polypectomy Assignment

Case 1
Attempts: 49

Case 2
Attempts: 17,

Case3
Attempts: 8

Case 4
Attempts: 8

4. Under Hands-on, select the case or task you want to perform, and press its row. The
task description or patient file opens.

surgicalscience Page 32


# Page 41

Chapter 5 
 MentorLearn
 
Page 33
 
 
Figure 4-4: Task/Case description 
5.  Press 
. The simulation case begins. 
When you have completed the simulation case, you are returned to MentorLearn, and 
a report of your performance is displayed. 
6.  If at any time you wish to choose another case, module, or course or another 
MentorLearn Library, press that item in the browse sequence hierarchy above the 
middle pane. 
 
 


[TABLE]
| F                                                                                 |
| i                                                                                 |
| gure 4-4: Task/Case description                                                   |
|:----------------------------------------------------------------------------------|
| 5.   Press                                                                        |
| . The simulation case begins.                                                     |
| When you have completed the simulation case, you are returned to MentorLearn, and |
| a report of your performance is displayed.                                        |
| 6.                                                                                |
| If at any time you wish to choose another case, module, or course or another      |
| MentorLearn Library, press that item in the browse sequence hierarchy above the   |
| middle pane.                                                                      |

[OCR]
Chapter 5 MentorLearn

Diagnostics Case 2 6

Perform a diagnostic hysteroscopy:

* Insert the scope into the vaginal region and advance to the cervical external OS.

+ Navigate through the cervical canal, managing irrigation fluid, and monitor patient
discomfort.

+ Fully inspect the uterine cavity, visualizing the right and left tubal ostia.

+ Screen for anatomical variations, pathologies and any findings.

Figure 4-4: Task/Case description

5. Press > J The simulation case begins.

When you have completed the simulation case, you are returned to MentorLearn, and
a report of your performance is displayed.

6. If at any time you wish to choose another case, module, or course or another
MentorLearn Library, press that item in the browse sequence hierarchy above the
middle pane.

€- HYSTMentor > Diagnostic Hysteroscopy > Diagnostics Case2

surgicalscience Page 33


# Page 42

Chapter 6 
 Display Modes
 
Page 34
 
Chapter 6 Display Modes 
The HYST Mentor modules consists of two display modes: 
• 
Diagnostic Hysteroscopy display mode  
• 
Clinical Procedure display mode  
Diagnostic Hysteroscopy display mode 
Diagnostic Hysteroscopy display mode shows the real-time simulated resectoscope view, 
showing a realistic display of the anatomy as moved through the vaginal region, 
visualizing the cervical external OS, the cervix and the uterus. The simulated scene 
changes responsively when you move or rotate the resectoscope. The simulation will 
start once resectoscope is inserted into the vaginal region. . 
 
Figure 6-1: Diagnostic Hysteroscopy display mode 
1 
Endoscopic View 
2 
Elapsed Time Indicator 
3 
Camera Angle Options 


[TABLE]
| Chapter 6                                                                            | Display Modes                                                                         |
|:-------------------------------------------------------------------------------------|:--------------------------------------------------------------------------------------|
| Chapter 6  Display Modes                                                             |                                                                                       |
| The HYST Mentor modules consists of two display modes:                               |                                                                                       |
| Diagnostic Hysteroscopy display mode                                                 |                                                                                       |
| •                                                                                    |                                                                                       |
| Clinical Procedure display mode                                                      |                                                                                       |
| •                                                                                    |                                                                                       |
| Diagnostic Hysteroscopy display mode                                                 |                                                                                       |
|                                                                                      | Diagnostic Hysteroscopy display mode shows the real-time simulated resectoscope view, |
| showing a realistic display of the anatomy as moved through the vaginal region,      |                                                                                       |
| visualizing the cervical external OS, the cervix and the uterus. The simulated scene |                                                                                       |
| changes responsively when you move or rotate the resectoscope. The simulation will   |                                                                                       |
| start once resectoscope is inserted into the vaginal region. .                       |                                                                                       |
| F                                                                                    |                                                                                       |
| i                                                                                    |                                                                                       |
| gure 6-1: Diagnostic Hysteroscopy display mode                                       |                                                                                       |
| 1                                                                                    |                                                                                       |
| Endoscopic View                                                                      |                                                                                       |
| 2                                                                                    |                                                                                       |
| Elapsed Time Indicator                                                               |                                                                                       |
| 3                                                                                    |                                                                                       |
| Camera Angle Options                                                                 |                                                                                       |
|                                                                                      | Page 34                                                                               |

[OCR]
Chapter 6 Display Modes

Chapter 6 Display Modes

The HYST Mentor modules consists of two display modes:

e Diagnostic Hysteroscopy display mode
e Clinical Procedure display mode

Diagnostic Hysteroscopy display mode

Diagnostic Hysteroscopy display mode shows the real-time simulated resectoscope view,
showing a realistic display of the anatomy as moved through the vaginal region,
visualizing the cervical external OS, the cervix and the uterus. The simulated scene
changes responsively when you move or rotate the resectoscope. The simulation will
start once resectoscope is inserted into the vaginal region. .

surgjealscionce

Figure 6-17: Diagnostic Hysteroscopy display mode
1 Endoscopic View
2 Elapsed Time Indicator

3 Camera Angle Options

surgical Page 34


# Page 43

Chapter 6 
 Display Modes
 
Page 35
 
4 
Hysteroscope Indicators 
5 
Simulation Aids 
6 
Patient Discomfort Scale 
7 
3D External View 
8 
Check Fluid Button 
9 
Screen Layout Options 
10 
External View Options 
11 
General Buttons 
Screen display layout 
The screen display ⑦ is by default split into 2 panes: External View and Endoscopy View. 
You can use the different layout options to display one view or both views simultaneously.  
 
Endoscopic View – full screen of endoscopy view  
 
Normal View (default) – split screen of external view 
and endoscopy view 
 
External View – full screen of external view  


[TABLE]
|   Chapter 6 |                          |
|------------:|:-------------------------|
|           4 | Hysteroscope Indicators  |
|           5 | Simulation Aids          |
|           6 | Patient Discomfort Scale |
|           7 | 3D External View         |
|           8 | Check Fluid Button       |
|           9 | Screen Layout Options    |
|          10 | External View Options    |
|          11 | General Buttons          |

[OCR]
Chapter 6 Display Modes

4 Hysteroscope Indicators
5 Simulation Aids

6 Patient Discomfort Scale
7 3D External View

8 Check Fluid Button

9 Screen Layout Options
10 External View Options

11. General Buttons

Screen display layout

The screen display (7) is by default split into 2 panes: External View and Endoscopy View.
You can use the different layout options to display one view or both views simultaneously.

| Endoscopic View - full screen of endoscopy view

Normal View (default) — split screen of external view
and endoscopy view

iJ External View - full screen of external view

surgicalscience Page 35


# Page 44

Chapter 6 
 Display Modes
 
Page 36
 
Endoscopic View 
The Endoscopic View ① shows the real-time simulated view of the resectoscope view 
during the procedure you are performing, showing a realistic display of the anatomy. The 
simulated scene changes responsively when you move or rotate the resectoscope. 
Elapsed Time indicator  
Elapsed Time indicator ➁ shows you how much time has elapsed since the beginning of 
the procedure (from the first time the camera is inserted into the portal). 
 
Figure 6-2: Endoscopic View  
Camera angle options ③ 
HYST Mentor gives you the option to train using the degree of angled optics used in the 
clinical practice. 
The virtual endoscopic optical system includes several available angles: 0°, 12°, and 30°. 


[TABLE]
| Chapter 6                                                                         | Display Modes                                                                            |
|:----------------------------------------------------------------------------------|:-----------------------------------------------------------------------------------------|
| Endoscopic View                                                                   |                                                                                          |
| The Endoscopic View ① shows the real-time simulated view of the resectoscope view |                                                                                          |
|                                                                                   | during the procedure you are performing, showing a realistic display of the anatomy. The |
| simulated scene changes responsively when you move or rotate the resectoscope.    |                                                                                          |
| Elapsed Time indicator                                                            |                                                                                          |
|                                                                                   | Elapsed Time indicator ➁ shows you how much time has elapsed since the beginning of      |
| the procedure (from the first time the camera is inserted into the portal).       |                                                                                          |

[OCR]
Chapter 6 Display Modes

Endoscopic View

The Endoscopic View @ shows the real-time simulated view of the resectoscope view
during the procedure you are performing, showing a realistic display of the anatomy. The
simulated scene changes responsively when you move or rotate the resectoscope.

Elapsed Time indicator

Elapsed Time indicator (2) shows you how much time has elapsed since the beginning of
the procedure (from the first time the camera is inserted into the portal).

Figure 6-2: Endoscopic View

Camera angle options @)

HYST Mentor gives you the option to train using the degree of angled optics used in the
clinical practice.

The virtual endoscopic optical system includes several available angles: 0°, 12°, and 30°.

surgicalscience Page 36


# Page 45

Chapter 6 
 Display Modes
 
Page 37
 
• 
Press 0° for a straight view. This camera option does not work with angled optics. 
  
• 
Press 12° for a slightly flexed view. This camera option works with 12° angled option; 
it makes it easier to visualize angles and corners. 
 


[TABLE]
| Chapter 6                                                                               |
|  Display Modes                                                                          |
|:----------------------------------------------------------------------------------------|
| Press 0° for a straight view. This camera option does not work with angled optics.      |
| •                                                                                       |
| Press 12° for a slightly flexed view. This camera option works with 12° angled option;  |
| •                                                                                       |
| it makes it easier to visualize angles and corners.                                     |
| Page 37                                                                                 |

[OCR]
Chapter 6 Display Modes

e Press 0° for a straight view. This camera option does not work with angled optics.

e Press 12° for a slightly flexed view. This camera option works with 12° angled option;
it makes it easier to visualize angles and corners.

surgical Page 37


# Page 46

Chapter 6 
 Display Modes
 
Page 38
 
• 
Press 30° for an even more flexed view than the 12° camera option. This camera 
option works with 30° angled option. 
 
To change the camera angle, select an angle on the left pane. 
For more information about working with the camera, see Camera on page 19. 
The Zoom percentage is displayed below the camera angles. 
Hysteroscope Indicators 
Inflow and Outflow Valves ④ 
Trainees and proctors can monitor on screen the inflow and outflow valve status of the 
resectoscope. Real-time indication of the valve changes made by the trainee is displayed 
on screen. 
 


[TABLE]
| To change the camera angle, select an angle on the left pane.                            |
|:-----------------------------------------------------------------------------------------|
| For more information about working with the camera, see Camera on page 19.               |
| The Zoom percentage is displayed below the camera angles.                                |
| Hysteroscope Indicators                                                                  |
| Inflow and Outflow Valves ④                                                              |
| Trainees and proctors can monitor on screen the inflow and outflow valve status of the   |
| resectoscope. Real-time indication of the valve changes made by the trainee is displayed |
| on screen.                                                                               |

[OCR]
Chapter 6 Display Modes

e Press 30° for an even more flexed view than the 12° camera option. This camera
option works with 30° angled option.

To change the camera angle, select an angle on the left pane.
For more information about working with the camera, see Camera on page 19.

The Zoom percentage is displayed below the camera angles.

Hysteroscope Indicators

Inflow and Outflow Valves ()

Trainees and proctors can monitor on screen the inflow and outflow valve status of the
resectoscope. Real-time indication of the valve changes made by the trainee is displayed
on screen.

Hysteroscope

surgicalscience Page 38


# Page 47

Chapter 6 
 Display Modes
 
Page 39
 
External View 
 
Figure 6-3: External View 
When the simulation begins, an external view ⑦ of the anatomy and instruments is 
displayed. It realistically shows scope navigation and manipulation during the procedure 
within the relevant anatomy.  
External View controls ⑧ 
In order to manipulate the External View, you have to first unlink it from the Internal View. 
To unlink the External and Internal Views: 
1. Press the Link 
 button.   
2. Press the button again to link the views. 
 


[TABLE]
| Chapter 6                                                                                | Display Modes                                                                                 |
|:-----------------------------------------------------------------------------------------|:----------------------------------------------------------------------------------------------|
| External View                                                                            |                                                                                               |
| F                                                                                        |                                                                                               |
| i                                                                                        |                                                                                               |
| gure 6-3: External View                                                                  |                                                                                               |
| When the simulation begins, an external view ⑦ of the anatomy and instruments is         |                                                                                               |
| displayed. It realistically shows scope navigation and manipulation during the procedure |                                                                                               |
| within the relevant anatomy.                                                             |                                                                                               |
| External View controls ⑧                                                                 |                                                                                               |
|                                                                                          | In order to manipulate the External View, you have to first unlink it from the Internal View. |
| To unlink the External and Internal Views:                                               |                                                                                               |
| 1.                                                                                       |                                                                                               |
| Press the Link                                                                           |                                                                                               |
|  button.                                                                                 |                                                                                               |
| 2.                                                                                       |                                                                                               |
| Press the button again to link the views.                                                |                                                                                               |
|                                                                                          | Page 39                                                                                       |

[OCR]
Chapter 6 Display Modes

External View

Figure 6-3: External View

When the simulation begins, an external view (7) of the anatomy and instruments is

displayed. It realistically shows scope navigation and manipulation during the procedure
within the relevant anatomy.

External View controls

In order to manipulate the External View, you have to first unlink it from the Internal View.

To unlink the External and Internal Views:

1. Press the Link button.

2. Press the button again to link the views.

surgicalscience Page 39


# Page 48

Chapter 6 
 Display Modes
 
Page 40
 
You can manipulate the External View using the navigational buttons on the top of the 
screen. 
 To rotate: 
1.  Press the Rotate button to select. 
2.  Click and drag the mouse in different directions to turn the anatomical atlas 3-
dimentionally around that point. 
OR 
Slide your finger in different directions on the screen to turn the anatomical atlas 3-
dimentionally around that point. 
 To zoom: 
1.  Press the Zoom button to select. 
2.  Tap and slide your finger up to zoom in or down to zoom out. 
OR 
Click and drag the mouse up to zoom in and down to zoom out.  
 To pan: 
1.  Press the Pan button to select. 
2.  Slide with your finger on the screen to move the anatomical atlas up, down, right and 
left. 
OR 
Click and drag the mouse up, down, right, and left. 
 To reset: 
1.  Press the Reset button to reset the anatomical atlas to its default display. 
 To lock:  
1.  Press the Lock button to synchronize the movement of the anatomy and the selected 
tools. 


[TABLE]
| Chapter 6                                                                             | Display Modes                                                                              |
|:--------------------------------------------------------------------------------------|:-------------------------------------------------------------------------------------------|
| You can manipulate the External View using the navigational buttons on the top of the |                                                                                            |
| screen.                                                                               |                                                                                            |
| To rotate:                                                                            |                                                                                            |
| 1.   Press the Rotate button to select.                                               |                                                                                            |
| 2.   Click and drag the mouse in different directions to turn the anatomical atlas 3- |                                                                                            |
| dimentionally around that point.                                                      |                                                                                            |
| OR                                                                                    |                                                                                            |
|                                                                                       | Slide your finger in different directions on the screen to turn the anatomical atlas 3-    |
| dimentionally around that point.                                                      |                                                                                            |
| To zoom:                                                                              |                                                                                            |
| 1.   Press the Zoom button to select.                                                 |                                                                                            |
| 2.   Tap and slide your finger up to zoom in or down to zoom out.                     |                                                                                            |
| OR                                                                                    |                                                                                            |
| Click and drag the mouse up to zoom in and down to zoom out.                          |                                                                                            |
| To pan:                                                                               |                                                                                            |
| 1.   Press the Pan button to select.                                                  |                                                                                            |
|                                                                                       | 2.   Slide with your finger on the screen to move the anatomical atlas up, down, right and |
| left.                                                                                 |                                                                                            |
| OR                                                                                    |                                                                                            |
| Click and drag the mouse up, down, right, and left.                                   |                                                                                            |
| To reset:                                                                             |                                                                                            |
| 1.   Press the Reset button to reset the anatomical atlas to its default display.     |                                                                                            |
| To lock:                                                                              |                                                                                            |
|                                                                                       | 1.   Press the Lock button to synchronize the movement of the anatomy and the selected     |
| tools.                                                                                |                                                                                            |
|                                                                                       | Page 40                                                                                    |

[OCR]
Chapter 6 Display Modes

You can manipulate the External View using the navigational buttons on the top of the
screen.

ge To rotate:

Press the Rotate button to select.

2. Click and drag the mouse in different directions to turn the anatomical atlas 3-
dimentionally around that point.
OR

Slide your finger in different directions on the screen to turn the anatomical atlas 3-
dimentionally around that point.

a. To zoom:

Press the Zoom button to select.
2. Tap and slide your finger up to zoom in or down to zoom out.

OR
Click and drag the mouse up to zoom in and down to zoom out.

Ga To pan:

Press the Pan button to select.
2. Slide with your finger on the screen to move the anatomical atlas up, down, right and
left.

OR
Click and drag the mouse up, down, right, and left.

ie To reset:

Press the Reset button to reset the anatomical atlas to its default display.

Q
To lock:

1. Press the Lock button to synchronize the movement of the anatomy and the selected
tools.

surgicalscience Page 40


# Page 49

Chapter 6 
 Display Modes
 
Page 41
 
 Cross section view 
View different cross sections of the anatomy. 
Virtual instructor 
The Virtual Instructor ⑨ displays at the bottom or middle of the screen: 
• 
 - a warning each time performance is compromised or might lead to an unsafe 
situation. 
• 
 - a notification each time a complication has occurred.  
 
The Virtual Instructor also displays comments that are not alerts, aiding the training 
process. 
General buttons 
The general buttons (10) appear on the bottom right of the screen and include the 
following functions: 
 
The Mute button turns the sound on and off. 
 
The Case File button opens the current virtual patient’s 
case file or the task instructions.  
 
The Finish button ends the current simulation and 
returns to the performance section. Once exiting the 
case, it is not possible to continue the same simulation 
session. The button appears on the top right of the 
screen. 
 


[TABLE]
| The general buttons (10) appear on the bottom right of the screen and include the   |
|:------------------------------------------------------------------------------------|
| following functions:                                                                |
| The Mute button turns the sound on and off.                                         |
| The Case File button opens the current virtual patient’s                            |
| case file or the task instructions.                                                 |
| The Finish button ends the current simulation and                                   |
| returns to the performance section. Once exiting the                                |
| case, it is not possible to continue the same simulation                            |
| session. The button appears on the top right of the                                 |
| screen.                                                                             |

[OCR]
Chapter 6 Display Modes

©] Cross section view

View different cross sections of the anatomy.

Virtual instructor
The Virtual Instructor (©) displays at the bottom or middle of the screen:

. (w) - a warning each time performance is compromised or might lead to an unsafe
situation.

. IN - anotification each time a complication has occurred.

The Virtual Instructor also displays comments that are not alerts, aiding the training
process.

General buttons

The general buttons (10) appear on the bottom right of the screen and include the
following functions:

)) The Mute button turns the sound on and off.

[=] The Case File button opens the current virtual patient’s
case file or the task instructions.

The Finish button ends the current simulation and
returns to the performance section. Once exiting the
case, it is not possible to continue the same simulation
session. The button appears on the top right of the
screen.

surgicalscience Page 41


# Page 50

Chapter 6 
 Display Modes
 
Page 42
 
Simulation Aids 
There are 2 simulation aids ⑤: 
• 
Visualization Progress Bar 
• 
Clear View 
Visualization progress bar 
 Visualization Progress Bar 
The Visualization progress bar shows the percentage of the uterus that was visualized. 
 
Figure 6-4: Visualization progress bar 
Clearing the simulation view 
 Clear View 
Press this button to clear the view of blood and murky fluid. 


[TABLE]
| Chapter 6                                                     |                                                                                        | Display Modes   |
|:--------------------------------------------------------------|:---------------------------------------------------------------------------------------|:----------------|
| Simulation Aids                                               |                                                                                        |                 |
| There are 2 simulation aids ⑤:                                |                                                                                        |                 |
| Visualization Progress Bar                                    |                                                                                        |                 |
| •                                                             |                                                                                        |                 |
| Clear View                                                    |                                                                                        |                 |
| •                                                             |                                                                                        |                 |
| Visualization progress bar                                    |                                                                                        |                 |
|                                                               | Visualization Progress Bar                                                             |                 |
|                                                               | The Visualization progress bar shows the percentage of the uterus that was visualized. |                 |
| F                                                             |                                                                                        |                 |
| i                                                             |                                                                                        |                 |
| gure 6-4: Visualization progress bar                          |                                                                                        |                 |
| Clearing the simulation view                                  |                                                                                        |                 |
| Clear View                                                    |                                                                                        |                 |
| Press this button to clear the view of blood and murky fluid. |                                                                                        |                 |
|                                                               |                                                                                        | Page 42         |

[OCR]
Chapter 6 Display Modes

Simulation Aids

There are 2 simulation aids G):

e Visualization Progress Bar
e =©Clear View

Visualization progress bar

| Visualization Progress Bar| Visualization Progress Bar

The Visualization progress bar shows the percentage of the uterus that was visualized.

Figure 6-4: Visualization progress bar

Clearing the simulation view

+
a
Clear View

Press this button to clear the view of blood and murky fluid.

surgicalscience Page 42


# Page 51

Chapter 6 
 Display Modes
 
Page 43
 
  
 
Figure 6-5: View clouded with blood and tissue and view cleared 
Patient Discomfort Scale 
As you move the resectoscope through the different parts of the anatomy, the discomfort 
level of the patient changes. Navigation of the scope at different angles, its impact on the 
uterine walls or perforation change the patient discomfort level too. ⑥ 
 
Figure 6-6: Patient Discomfort Scale 
The discomfort level range is from minor to severe. 


[TABLE]
| Chapter 6                                                               | Display Modes                                                                                |
|:------------------------------------------------------------------------|:---------------------------------------------------------------------------------------------|
| F                                                                       |                                                                                              |
| i                                                                       |                                                                                              |
| gure 6-5: View clouded with blood and tissue and view cleared           |                                                                                              |
| Patient Discomfort Scale                                                |                                                                                              |
|                                                                         | As you move the resectoscope through the different parts of the anatomy, the discomfort      |
|                                                                         | level of the patient changes. Navigation of the scope at different angles, its impact on the |
| uterine walls or perforation change the patient discomfort level too. ⑥ |                                                                                              |
| F                                                                       |                                                                                              |
| i                                                                       |                                                                                              |
| gure 6-6: Patient Discomfort Scale                                      |                                                                                              |
| The discomfort level range is from minor to severe.                     |                                                                                              |
|                                                                         | Page 43                                                                                      |

[OCR]
Chapter 6 Display Modes

Figure 6-5: View clouded with blood and tissue and view cleared

Patient Discomfort Scale

As you move the resectoscope through the different parts of the anatomy, the discomfort
level of the patient changes. Navigation of the scope at different angles, its impact on the
uterine walls or perforation change the patient discomfort level too. ©

Patient Discomfort Scale

Figure 6-6: Patient Discomfort Scale

The discomfort level range is from minor to severe.

surgicalscience Page 43


# Page 52

Chapter 6 
 Display Modes
 
Page 44
 
Therapeutic Hysteroscopy display mode 
Therapeutic Hysteroscopy display mode shows the real-time simulated endoscopy view, 
showing a realistic display of the anatomy as moving through the vaginal region, 
visualizing the cervical external OS, the cervix and the uterus. The simulated scene 
changes responsively when you move or rotate the resectoscope. The simulation starts 
once the resectoscope is inserted into the vaginal region. Use of the resectoscope’s 
working element extends the loop in the simulation and allows the trainee to perform 
myomectomy and polypectomy. 
 
Figure 6-7: Therapeutic hysteroscopy display mode 
1 
Endoscopic View 
2 
Elapsed Time Indicator 
3 
Select Tools button 
4 
Camera Angle Options 
5 
Hystero-Resectoscope Options 
6 
Simulation Aids 
7 
3D External View 
8 
Screen Layout Options 


[TABLE]
| Chapter 6                                                                            | Display Modes                                                                        |
|:-------------------------------------------------------------------------------------|:-------------------------------------------------------------------------------------|
| Therapeutic Hysteroscopy display mode                                                |                                                                                      |
|                                                                                      | Therapeutic Hysteroscopy display mode shows the real-time simulated endoscopy view,  |
| showing a realistic display of the anatomy as moving through the vaginal region,     |                                                                                      |
| visualizing the cervical external OS, the cervix and the uterus. The simulated scene |                                                                                      |
|                                                                                      | changes responsively when you move or rotate the resectoscope. The simulation starts |
| once the resectoscope is inserted into the vaginal region. Use of the resectoscope’s |                                                                                      |
| working element extends the loop in the simulation and allows the trainee to perform |                                                                                      |
| myomectomy and polypectomy.                                                          |                                                                                      |

[TABLE]
| F   |   gure 6-7: Therapeutic hysteroscopy display mode |                              |
| i   |                                                   |                              |
|:----|--------------------------------------------------:|:-----------------------------|
|     |                                                 1 | Endoscopic View              |
|     |                                                 2 | Elapsed Time Indicator       |
|     |                                                 3 | Select Tools button          |
|     |                                                 4 | Camera Angle Options         |
|     |                                                 5 | Hystero-Resectoscope Options |
|     |                                                 6 | Simulation Aids              |
|     |                                                 7 | 3D External View             |
|     |                                                 8 | Screen Layout Options        |

[OCR_TABLE]
Chapter 6

[OCR]
Chapter 6 Display Modes

Therapeutic Hysteroscopy display mode

Therapeutic Hysteroscopy display mode shows the real-time simulated endoscopy view,
showing a realistic display of the anatomy as moving through the vaginal region,
visualizing the cervical external OS, the cervix and the uterus. The simulated scene
changes responsively when you move or rotate the resectoscope. The simulation starts
once the resectoscope is inserted into the vaginal region. Use of the resectoscope’s
working element extends the loop in the simulation and allows the trainee to perform
myomectomy and polypectomy.

surgical:

Figure 6-7: Therapeutic hysteroscopy display mode
Endoscopic View

Elapsed Time Indicator

Select Tools button

Camera Angle Options
Hystero-Resectoscope Options
Simulation Aids

3D External View

ON Oo BRB WYN A

Screen Layout Options

surgicalscience Page 44


# Page 53

Chapter 6 
 Display Modes
 
Page 45
 
9 
External View Options 
10 
Fluid Management System 
11 
General Buttons 
The following features are similar to the Diagnostic Hysteroscopy display mode; for a 
detailed explanation, see: 
• 
Camera angle options ③on page 36. 
• 
External View on page 39.  
• 
External View controls ⑧on page 39. 
• 
Screen display layout on page 35.  
• 
General buttons on page 41. 
Hystero-resectoscope options ⑤ 
Tools menu options  
The physical insertion of tools into the simulator is simulated using the real adapted 
resectoscope. You have the option of resecting with either a Monopolar loop or a Bipolar 
loop. The Tool Options are available on the left pane. 
Note: It is recommended to select the tool prior to beginning the procedure.  
To select a tool: 
1.  Before inserting the resectoscope, press Select Tool 
. 
2.  Choose a tool: 
  Press this button to work with the monopolar loop for 
cutting/coagulating with electricity.  
  Press this button to work with the bipolar loop for cutting/coagulating 
with electricity.  
On the left pane, the tool is selected. 
Note: The Select Tool is disabled while the scope is in use. 


[TABLE]
|                                                                                       | 11   | General Buttons                     |
|:--------------------------------------------------------------------------------------|:-----|:------------------------------------|
| The following features are similar to the Diagnostic Hysteroscopy display mode; for a |      |                                     |
| detailed explanation, see:                                                            |      |                                     |
| •                                                                                     |      | Camera angle options ③on page 36.   |
| •                                                                                     |      | External View on page 39.           |
| •                                                                                     |      | External View controls ⑧on page 39. |
| •                                                                                     |      | Screen display layout on page 35.   |
| •                                                                                     |      | General buttons on page 41.         |

[OCR_TABLE]
Cha

[OCR]
Chapter 6 Display Modes

9 External View Options
10 Fluid Management System
11. General Buttons

The following features are similar to the Diagnostic Hysteroscopy display mode; for a
detailed explanation, see:

Camera angle options @on page 36.
External View on page 39.

External View controls @)on page 39.
Screen display layout on page 35.
General buttons on page 41.

Hystero-resectoscope options ()

Tools menu options

The physical insertion of tools into the simulator is simulated using the real adapted
resectoscope. You have the option of resecting with either a Monopolar loop or a Bipolar
loop. The Tool Options are available on the left pane.

Note: It is recommended to select the tool prior to beginning the procedure.

To select a tool:

1. Before inserting the resectoscope, press Select Tool Select Tool :
2. Choose a tool:

Press this button to work with the monopolar loop for
cutting/coagulating with electricity.

Press this button to work with the bipolar loop for cutting/coagulating
with electricity.

On the left pane, the tool is selected.

Note: The Select Tool is disabled while the scope is in use.

surgicalscience Page 45


# Page 54

Chapter 6 
 Display Modes
 
Page 46
 
3.  To switch the tool, pull the scope out, press Select Tool and select another tool. 
Applying electricity 
Electricity can be used to cut/resect or coagulate the pathology. 
• 
To cut - apply electricity by pressing on the Electricity (middle) footswitch when 
retracting the working channel or pulling the entire resectoscope.  
• 
To coagulate - apply electricity by pressing on the Electricity (right) footswitch when 
retracting the working channel or pulling the entire resectoscope. 
WARNING: Never extend or push when applying electricity. 
Inflow and Outflow Valves 
For the Therapeutic Hysteroscopy cases, the cervix should be wide open and the uterus 
distended for the resectoscope to pass. The inflow valve should be fully open and the 
outflow valve partially closed. The uterus size will increase. 
Note: If the outflow valve is completely open, the uterus will not expand and the resectoscope 
cannot be advanced and there is a risk of perforation. 
For a detailed explanation, see Inflow and Outflow Valves on page 38. 
Simulation Aids 
There are 3 simulation aids ⑥: 
• 
Resection Map 
• 
Pathology Removal Bar 
• 
Clear View 
Resection map 
  Resection Map 
Press this button to show the resection map. Different colors on the map show the 
optimal place for resection. 
Press this button again to hide the resection map. 


[TABLE]
| Applying electricity                                              |                                                                                         |
|:------------------------------------------------------------------|:----------------------------------------------------------------------------------------|
| Electricity can be used to cut/resect or coagulate the pathology. |                                                                                         |
| •                                                                 | To cut - apply electricity by pressing on the Electricity (middle) footswitch when      |
|                                                                   | retracting the working channel or pulling the entire resectoscope.                      |
| •                                                                 | To coagulate - apply electricity by pressing on the Electricity (right) footswitch when |
|                                                                   | retracting the working channel or pulling the entire resectoscope.                      |
|                                                                   | WARNING: Never extend or push when applying electricity.                                |

[OCR_TABLE]
Chaoter 6

[OCR]
Chapter 6 Display Modes

3. To switch the tool, pull the scope out, press Select Tool and select another tool.

Applying electricity

Electricity can be used to cut/resect or coagulate the pathology.

e¢ To cut - apply electricity by pressing on the Electricity (middle) footswitch when
retracting the working channel or pulling the entire resectoscope.

e¢ To coagulate - apply electricity by pressing on the Electricity (right) footswitch when
retracting the working channel or pulling the entire resectoscope.

WARNING: Never extend or push when applying electricity.

Inflow and Outflow Valves

For the Therapeutic Hysteroscopy cases, the cervix should be wide open and the uterus
distended for the resectoscope to pass. The inflow valve should be fully open and the
outflow valve partially closed. The uterus size will increase.

Note: If the outflow valve is completely open, the uterus will not expand and the resectoscope
cannot be advanced and there is a risk of perforation.

For a detailed explanation, see Inflow and Outflow Valves on page 38.

Simulation Aids

There are 3 simulation aids ©:

e Resection Map
e Pathology Removal Bar
e =©Clear View

Resection map

Resection Map

Press this button to show the resection map. Different colors on the map show the
optimal place for resection.

Press this button again to hide the resection map.

surgicalscience Page 46


# Page 55

Chapter 6 
 Display Modes
 
Page 47
 
  
 
Figure 6-8: Default View and Show Resection View 
Use the colors and zones on the Resection map to direct you where to continue resecting 
and which areas to avoid.   
 
  
Figure 6-9: Resection zones on Resection Map 
• 
Green – Resect 
• 
Yellow/orange – Getting closer to endometrium 
• 
Red – Endometrium. Do not resect. 
Pathology removal bar 
 Pathology Removal Bar 
The pathology removal shows the percentage of the polyp or myoma that has been 
resected. 


[TABLE]
| Chapter 6                                                                      | Display Modes                                                                           |
|:-------------------------------------------------------------------------------|:----------------------------------------------------------------------------------------|
| F                                                                              |                                                                                         |
| i                                                                              |                                                                                         |
| gure 6-8: Default View and Show Resection View                                 |                                                                                         |
|                                                                                | Use the colors and zones on the Resection map to direct you where to continue resecting |
| and which areas to avoid.                                                      |                                                                                         |
| F                                                                              |                                                                                         |
| i                                                                              |                                                                                         |
| gure 6-9: Resection zones on Resection Map                                     |                                                                                         |
| Green – Resect                                                                 |                                                                                         |
| •                                                                              |                                                                                         |
| Yellow/orange – Getting closer to endometrium                                  |                                                                                         |
| •                                                                              |                                                                                         |
| Red – Endometrium. Do not resect.                                              |                                                                                         |
| •                                                                              |                                                                                         |
| Pathology removal bar                                                          |                                                                                         |
| Pathology Removal Bar                                                          |                                                                                         |
| The pathology removal shows the percentage of the polyp or myoma that has been |                                                                                         |
| resected.                                                                      |                                                                                         |
|                                                                                | Page 47                                                                                 |

[OCR]
Chapter 6 Display Modes

Figure 6-8: Default View and Show Resection View

Use the colors and zones on the Resection map to direct you where to continue resecting
and which areas to avoid.

Figure 6-9: Resection zones on Resection Map

. Green — Resect
. Yellow/orange — Getting closer to endometrium
. Red — Endometrium. Do not resect.

Pathology removal bar

|e Pata Removal a | Pathology Removal Bar

The pathology removal shows the percentage of the polyp or myoma that has been
resected.

surgical Page 47


# Page 56

Chapter 6 
 Display Modes
 
Page 48
 
 
Figure 6-10: Pathology removal bar 
Clearing the simulation view 
  Clear View 
Press this button to clear the view of blood and murky fluid.  
Fluid management system 
The Fluid Management System panel (10) allows you to track the inflow and uterine deficit 
status and set the pump pressure..  
1.  Click the Check Fluids button on the upper toolbar to display the Fluid Management 
System panel. 
 
2.  To set the pressure, click the plus (+) sign to increase the pressure (mmHg) and the 
minus (-) sign to decrease it. 
The rate of fluid inflow will be reflected in the Total Inflow and Deficient values. 
Note: When the Deficit number approaches its limit, the number turns red and a 
warning is displayed: “Fluid deficit is approaching limit.”  
 
For the monopolar tool, the limit is 800 ml and for the bipolar tool, 2300 ml. 
The window will close after 20sec automatically. 


[TABLE]
| Chapter 6                          |                                                                                           | Display Modes   |
|:-----------------------------------|:------------------------------------------------------------------------------------------|:----------------|
| F                                  |                                                                                           |                 |
| i                                  |                                                                                           |                 |
| gure 6-10: Pathology removal bar   |                                                                                           |                 |
| Clearing the simulation view       |                                                                                           |                 |
|                                    | Clear View                                                                                |                 |
|                                    | Press this button to clear the view of blood and murky fluid.                             |                 |
| Fluid management system            |                                                                                           |                 |
|                                    | The Fluid Management System panel (10) allows you to track the inflow and uterine deficit |                 |
| status and set the pump pressure.. |                                                                                           |                 |
|                                    | 1.   Click the Check Fluids button on the upper toolbar to display the Fluid Management   |                 |
| System panel.                      |                                                                                           |                 |
|                                    | 2.   To set the pressure, click the plus (+) sign to increase the pressure (mmHg) and the |                 |
| minus (-) sign to decrease it.     |                                                                                           |                 |
|                                    | The rate of fluid inflow will be reflected in the Total Inflow and Deficient values.      |                 |
|                                    | Note: When the Deficit number approaches its limit, the number turns red and a            |                 |
|                                    | warning is displayed: “Fluid deficit is approaching limit.”                               |                 |
|                                    | For the monopolar tool, the limit is 800 ml and for the bipolar tool, 2300 ml.            |                 |
|                                    | The window will close after 20sec automatically.                                          |                 |
|                                    |                                                                                           | Page 48         |

[OCR]
Chapter 6 Display Modes

Figure 6-10: Pathology removal bar

Clearing the simulation view

+
a
Clear View

Press this button to clear the view of blood and murky fluid.

Fluid management system
The Fluid Management System panel (10) allows you to track the inflow and uterine deficit
status and set the pump pressure..

1. Click the Check Fluids button on the upper toolbar to display the Fluid Management
System panel.

Fluid Management System

2. To set the pressure, click the plus (+) sign to increase the pressure (mmHg) and the
minus (-) sign to decrease it.

The rate of fluid inflow will be reflected in the Total Inflow and Deficient values.

Note: When the Deficit number approaches its limit, the number turns red and a
warning is displayed: “Fluid deficit is approaching limit.”
For the monopolar tool, the limit is 800 ml and for the bipolar tool, 2300 ml.

The window will close after 20sec automatically.

surgicalscience Page 48


# Page 57

Chapter 7 
 Working with Resectoscope
 
Page 49
 
Chapter 7 Working with Resectoscope 
The resectoscope hardware is used for the following HYST Mentor modules: 
• 
Diagnostic Hysteroscopy – in this module the scope is used as a hysteroscope.  
• 
Hysteroscopic Myomectomy 
• 
Hysteroscopic Polypectomy 
Tools menu 
The physical insertion of tools into the simulator is simulated using the real adapted 
resectoscope. In the therapeutic modules, you have the option of resecting with either a 
Monopolar loop or a Bipolar loop. The Tool Options are available on the Left pane. 
 
Figure 7-1: Tools Menu with sub-menu of options 


[TABLE]
| Chapter 7                                                                                |
|  Working with Resectoscope                                                               |
|:-----------------------------------------------------------------------------------------|
| Chapter 7  Working with Resectoscope                                                     |
| The resectoscope hardware is used for the following HYST Mentor modules:                 |
| Diagnostic Hysteroscopy – in this module the scope is used as a hysteroscope.            |
| •                                                                                        |
| Hysteroscopic Myomectomy                                                                 |
| •                                                                                        |
| Hysteroscopic Polypectomy                                                                |
| •                                                                                        |
| Tools menu                                                                               |
| The physical insertion of tools into the simulator is simulated using the real adapted   |
| resectoscope. In the therapeutic modules, you have the option of resecting with either a |
| Monopolar loop or a Bipolar loop. The Tool Options are available on the Left pane.       |
| F                                                                                        |
| i                                                                                        |
| gure 7-1: Tools Menu with sub-menu of options                                            |
| Page 49                                                                                  |

[OCR]
Chapter 7 Working with Resectoscope

| Chapter 7 Working with Resectoscope

The resectoscope hardware is used for the following HYST Mentor modules:

. Diagnostic Hysteroscopy — in this module the scope is used as a hysteroscope.
e Hysteroscopic Myomectomy

e Hysteroscopic Polypectomy

Tools menu

The physical insertion of tools into the simulator is simulated using the real adapted
resectoscope. In the therapeutic modules, you have the option of resecting with either a
Monopolar loop or a Bipolar loop. The Tool Options are available on the Left pane.

Select Tool
Camera

ANGLES

0° eo 30°

Hystero-Resectoscope

Figure 7-1: Tools Menu with sub-menu of options

surgicalscience Page 49


# Page 58

Chapter 7 
 Working with Resectoscope
 
Page 50
 
Selecting a tool 
To select a tool: 
1.  Before inserting the resectoscope, press Select Tool 
. 
2.  Choose a tool: 
  Press this button to work with the monopolar loop for 
cutting/coagulating with electricity.  
  Press this button to work with the bipolar loop for cutting/coagulating 
with electricity.  
On the left pane, the tool is selected. 
Note: The Select Tool button is disabled while the scope is in use. 
3.  To switch the tool, pull the scope out, press Select Tool and select another tool. 
Applying electricity 
Electricity can be used to cut/resect or coagulate the pathology. 
• 
To cut - apply electricity by pressing on the Electricity (middle) footswitch when 
retracting the working channel or pulling the entire resectoscope.  
• 
To coagulate - apply electricity by pressing on the Electricity (right) footswitch when 
retracting the working channel or pulling the entire resectoscope. 
WARNING: Never extend or push when applying electricity. 
Aligning the resectoscope 
To align the resectoscope:  
1.  Align the scope so that the camera button and the working element handles are 
parallel.  


[TABLE]
| Chapter 7                                                                                |
|  Working with Resectoscope                                                               |
|:-----------------------------------------------------------------------------------------|
| Selecting a tool                                                                         |
| To select a tool:                                                                        |
| 1.   Before inserting the resectoscope, press Select Tool                                |
| .                                                                                        |
| 2.   Choose a tool:                                                                      |
| Press this button to work with the monopolar loop for                                    |
| cutting/coagulating with electricity.                                                    |
| Press this button to work with the bipolar loop for cutting/coagulating                  |
| with electricity.                                                                        |
| On the left pane, the tool is selected.                                                  |
| Note: The Select Tool button is disabled while the scope is in use.                      |
| 3.   To switch the tool, pull the scope out, press Select Tool and select another tool.  |
| Applying electricity                                                                     |
| Electricity can be used to cut/resect or coagulate the pathology.                        |
| To cut - apply electricity by pressing on the Electricity (middle) footswitch when       |
| •                                                                                        |
| retracting the working channel or pulling the entire resectoscope.                       |
| To coagulate - apply electricity by pressing on the Electricity (right) footswitch when  |
| •                                                                                        |
| retracting the working channel or pulling the entire resectoscope.                       |
| WARNING: Never extend or push when applying electricity.                                 |
| Aligning the resectoscope                                                                |
| To align the resectoscope:                                                               |
| 1.   Align the scope so that the camera button and the working element handles are       |
| parallel.                                                                                |
| Page 50                                                                                  |

[OCR]
Chapter 7 Working with Resectoscope

Selecting a tool

To select a tool:

1. Before inserting the resectoscope, press Select Tool Select Tool .
2. Choose a tool:

Press this button to work with the monopolar loop for
cutting/coagulating with electricity.

Press this button to work with the bipolar loop for cutting/coagulating
with electricity.

On the left pane, the tool is selected.

Note: The Select Tool button is disabled while the scope is in use.

3. To switch the tool, pull the scope out, press Select Tool and select another tool.

Applying electricity

Electricity can be used to cut/resect or coagulate the pathology.

¢ To cut - apply electricity by pressing on the Electricity (middle) footswitch when
retracting the working channel or pulling the entire resectoscope.

¢ To coagulate - apply electricity by pressing on the Electricity (right) footswitch when
retracting the working channel or pulling the entire resectoscope.

WARNING: Never extend or push when applying electricity.

Aligning the resectoscope

To align the resectoscope:

1. Align the scope so that the camera button and the working element handles are
parallel.

surgicalscience Page 50


# Page 59

Chapter 7 
 Working with Resectoscope
 
Page 51
 
 
Figure 7-2: Working element parallel to camera button 
2.  Insert the scope into the vaginal region on the cartridge. 
The arrow should be positioned at the top of the simulation screen (12 o’clock). 
 
Figure 7-3: Align Scope screen for resectoscope 


[TABLE]
| Chapter 7                                                                        | Working with Resectoscope   |
|:---------------------------------------------------------------------------------|:----------------------------|
| F                                                                                |                             |
| i                                                                                |                             |
| gure 7-2: Working element parallel to camera button                              |                             |
| 2.                                                                               |                             |
| Insert the scope into the vaginal region on the cartridge.                       |                             |
| The arrow should be positioned at the top of the simulation screen (12 o’clock). |                             |
| F                                                                                |                             |
| i                                                                                |                             |
| gure 7-3: Align Scope screen for resectoscope                                    |                             |
|                                                                                  | Page 51                     |

[OCR]
Chapter 7 Working with Resectoscope

Figure 7-2: Working element parallel to camera button

2. Insert the scope into the vaginal region on the cartridge.

The arrow should be positioned at the top of the simulation screen (12 o’clock).

Figure 7-3: Align Scope screen for resectoscope

surgicalscience Page 51


# Page 60

Chapter 7 
 Working with Resectoscope
 
Page 52
 
Inserting and positioning the camera 
The case starts with a camera view displayed on the screen. However, the camera may 
need to be manipulated to display the correct view of the anatomy. 
To position the camera: 
1.  Move the camera handle to adjust the operative view seen on the screen. 
2.  Rotating it rotates the horizon too. Change the camera angle, if necessary, to see 
behind objects. 
 
3.  You can now: 
o 
Move the camera handle to adjust the operative view seen on the screen. 
o 
Rotate the camera (using the rotatable handle). 
Note: Currently, the button on the scope handle is not functionable. 
Taking snapshots 
Press the middle button to take snapshots during the simulation.  
A sound is emitted as the snapshot is taken. 
Focusing the simulation display 
Use the focus wheel in front of the camera to adjust the focus of the simulation display 
(Endoscopic View).  


[TABLE]
| Chapter 7                                                                               | Working with Resectoscope                                                           |
|:----------------------------------------------------------------------------------------|:------------------------------------------------------------------------------------|
| Inserting and positioning the camera                                                    |                                                                                     |
|                                                                                         | The case starts with a camera view displayed on the screen. However, the camera may |
| need to be manipulated to display the correct view of the anatomy.                      |                                                                                     |
| To position the camera:                                                                 |                                                                                     |
| 1.   Move the camera handle to adjust the operative view seen on the screen.            |                                                                                     |
| 2.   Rotating it rotates the horizon too. Change the camera angle, if necessary, to see |                                                                                     |
| behind objects.                                                                         |                                                                                     |
| 3.   You can now:                                                                       |                                                                                     |

[OCR]
Chapter 7 Working with Resectoscope

Inserting and positioning the camera

The case starts with a camera view displayed on the screen. However, the camera may
need to be manipulated to display the correct view of the anatomy.
To position the camera:

1. Move the camera handle to adjust the operative view seen on the screen.
2. Rotating it rotates the horizon too. Change the camera angle, if necessary, to see
behind objects.

3. You can now:

° Move the camera handle to adjust the operative view seen on the screen.
° Rotate the camera (using the rotatable handle).

Note: Currently, the button on the scope handle is not functionable.

Taking snapshots

Press the middle button to take snapshots during the simulation.

A sound is emitted as the snapshot is taken.

Focusing the simulation display

Use the focus wheel in front of the camera to adjust the focus of the simulation display
(Endoscopic View).

surgicalscience Page 52


# Page 61

Chapter 7 
 Working with Resectoscope
 
Page 53
 
   
   
Figure 7-4: View out of focus and view in focus 
Zooming the simulation display 
Use the zoom ring in front of the camera to zoom in or out of the simulation display 
(Internal View). The zoom percentage is displayed under the angled optics. 
 
Figure 7-5: Zoom percentage 
Ending the case or task 
Press X in the upper right corner of the screen to end the current simulation. A message is 
displayed asking you if you are sure you want to finish.  


[TABLE]
| Chapter 7                                                                            | Working with Resectoscope                                                                   |
|:-------------------------------------------------------------------------------------|:--------------------------------------------------------------------------------------------|
| F                                                                                    |                                                                                             |
| i                                                                                    |                                                                                             |
| gure 7-4: View out of focus and view in focus                                        |                                                                                             |
| Zooming the simulation display                                                       |                                                                                             |
| Use the zoom ring in front of the camera to zoom in or out of the simulation display |                                                                                             |
| (Internal View). The zoom percentage is displayed under the angled optics.           |                                                                                             |
| F                                                                                    |                                                                                             |
| i                                                                                    |                                                                                             |
| gure 7-5: Zoom percentage                                                            |                                                                                             |
| Ending the case or task                                                              |                                                                                             |
|                                                                                      | Press X in the upper right corner of the screen to end the current simulation. A message is |
| displayed asking you if you are sure you want to finish.                             |                                                                                             |
|                                                                                      | Page 53                                                                                     |

[OCR]
Chapter 7 Working with Resectoscope

Figure 7-4: View out of focus and view in focus

Zooming the simulation display

Use the zoom ring in front of the camera to zoom in or out of the simulation display
(Internal View). The zoom percentage is displayed under the angled optics.

ANGLES

;0°

Ea

Figure 7-5: Zoom percentage

Ending the case or task

Press X in the upper right corner of the screen to end the current simulation. A message is
displayed asking you if you are sure you want to finish.

surgical Page 53


# Page 62

Chapter 7 
 Working with Resectoscope
 
Page 54
 
• 
Press Yes – to end the case or task. Your performance is saved and can be viewed 
on the Reports page. 
• 
Press No – to return to the previous screen. Your performance will not be saved. 
 


[TABLE]
| Chapter 7                                                                         |
|  Working with Resectoscope                                                        |
|:----------------------------------------------------------------------------------|
| Press Yes – to end the case or task. Your performance is saved and can be viewed  |
| •                                                                                 |
| on the Reports page.                                                              |
| Press No – to return to the previous screen. Your performance will not be saved.  |
| •                                                                                 |
| Page 54                                                                           |

[OCR]
Chapter 7 Working with Resectoscope

. Press Yes — to end the case or task. Your performance is saved and can be viewed
on the Reports page.
. Press No - to return to the previous screen. Your performance will not be saved.

surgicalscience Page 54


# Page 63

Chapter 8 
 Viewing Performance Reports
 
Page 55
 
Chapter 8 Viewing Performance Reports 
Overview 
Performance reports are displayed after each simulation case or task, allowing you to 
monitor and track your training progress. 
Note: MentorLearn produces reports for simulation cases only; reports are not produced relating to 
the completion of any didactic material included in a course. 
When you press Finish to end a task or case, your performance report is displayed 
automatically. All of your reports are listed on the MentorLearn Reports screen. 
Viewing reports 
To view performance reports: 
1.  Press Reports on the MentorLearn menu to access the Reports screen. 
 


[TABLE]
| Chapter 8                                                                             | Viewing Performance Reports                                                                        |
|:--------------------------------------------------------------------------------------|:---------------------------------------------------------------------------------------------------|
| Chapter 8  Viewing Performance Reports                                                |                                                                                                    |
| Overview                                                                              |                                                                                                    |
| Performance reports are displayed after each simulation case or task, allowing you to |                                                                                                    |
| monitor and track your training progress.                                             |                                                                                                    |
|                                                                                       | Note: MentorLearn produces reports for simulation cases only; reports are not produced relating to |
| the completion of any didactic material included in a course.                         |                                                                                                    |
| When you press Finish to end a task or case, your performance report is displayed     |                                                                                                    |
| automatically. All of your reports are listed on the MentorLearn Reports screen.      |                                                                                                    |
| Viewing reports                                                                       |                                                                                                    |
| To view performance reports:                                                          |                                                                                                    |
| 1.   Press Reports on the MentorLearn menu to access the Reports screen.              |                                                                                                    |

[OCR]
Chapter 8 Viewing Performance Reports

| Chapter 8 Viewing Performance Reports

Overview

Performance reports are displayed after each simulation case or task, allowing you to
monitor and track your training progress.

Note: MentorLearn produces reports for simulation cases only; reports are not produced relating to
the completion of any didactic material included in a course.

When you press Finish to end a task or case, your performance report is displayed
automatically. All of your reports are listed on the MentorLearn Reports screen.

Viewing reports

To view performance reports:
1. Press Reports on the MentorLearn menu to access the Reports screen.

HYST Mentor

oOo * Group Name Module/Course case: bate
o* Main, Library Assignments Client Administrator copic Polypectomy Case? Aug 5,2024, 9:27:35 4M
oOo * Main, Library Assignments Client Administrator Case2 Aug 5, 2024, 9:22:19 AM
o Main, Library Assignments Client Administrator Hysteroscoplc Case2 Aug 5, 2024, 9:17:15 AM
iyomectomy
o* Main, Library Assignments Client Administrator case Aug 5, 2024, 9:00:26 AM
o * Main, Library Assignments Client Administrator case3 Aug 5, 2024, 9:06:06 AM
o * ‘Main, Library Assignments Client Acministrator cases Aug 1, 2024, 4:13:32 PM
o* Main, Library Assignments Client Administrator case Aug 1, 2024, 81215 M
o * Main, Library Assignments case1 Aug 1, 2024, 09:22PM
o * Main, Library Assignments Client Administrator Hysteroscopic Polypectomy Case 2 Aug 1, 2024, 4:07:48 PM
o* Main, Library Assignments Client Admin Hysteroscopic Polypectomy Case 1 Aug 1, 2024, 4:03:11 PM
o * Main, Library Assignments Client Administrator Diagnostic Hysteroscopy Diagnostics Case 1 Aug 1, 2024, 3:57:00 PM
oO x ‘Main, Library Assignments Client Administrator cases ‘Aug 1, 2024, 12:19:01 PM
o* Main, Library Assignments Client Administrator case Aug 1, 2024, 12°13:40 PM

surgicalscience Page 55


# Page 64

Chapter 8 
 Viewing Performance Reports
 
Page 56
 
2.  The entries in the reports table appear in chronological order – the most recently 
performed sessions appear at the top of the list. Each row in the reports table 
represents a single session, meaning that if a user completed a particular simulation 
case three times, three entries (rows) for that case are displayed. 
3.  To display a shorter, more focused list of sessions in the Reports table, use the search 
at the top of the table or define a filter in the right pane. To restore the full, unfiltered 
list of reports, clear the selected checkbox(es). 
4.  To bookmark a report, press
to the left of its name. You can then easily return to 
the report when needed. To remove the bookmark, press the star 
 again. If 
desired you can filter only starred reports or only unstarred reports. On the right pane, 
select the Starred check box to view only those starred reports. Clear the check box 
to view all the reports. 
Note: When you exit MentorLearn, those bookmarked reports are saved and will be 
displayed the next time you open MentorLearn. 
5.  To scroll through the list of reports, use the Next and Previous arrows at the bottom 
of the Reports screen.  
6.  To open a single-case report, press its row in the Reports table. 
 
Figure 8-1: Single-case report 


[TABLE]
| Chapter 8                                                                                     |
|  Viewing Performance Reports                                                                  |
|:----------------------------------------------------------------------------------------------|
| 2.   The entries in the reports table appear in chronological order – the most recently       |
| performed sessions appear at the top of the list. Each row in the reports table               |
| represents a single session, meaning that if a user completed a particular simulation         |
| case three times, three entries (rows) for that case are displayed.                           |
| 3.   To display a shorter, more focused list of sessions in the Reports table, use the search |
| at the top of the table or define a filter in the right pane. To restore the full, unfiltered |
| list of reports, clear the selected checkbox(es).                                             |
| 4.   To bookmark a report, press                                                              |
| to the left of its name. You can then easily return to                                        |
| the report when needed. To remove the bookmark, press the star                                |
|  again. If                                                                                    |
| desired you can filter only starred reports or only unstarred reports. On the right pane,     |
| select the Starred check box to view only those starred reports. Clear the check box          |
| to view all the reports.                                                                      |

[OCR]
Chapter 8 Viewing Performance Reports

2. The entries in the reports table appear in chronological order — the most recently
performed sessions appear at the top of the list. Each row in the reports table
represents a single session, meaning that if a user completed a particular simulation
case three times, three entries (rows) for that case are displayed.

3. To display a shorter, more focused list of sessions in the Reports table, use the search
at the top of the table or define a filter in the right pane. To restore the full, unfiltered
list of reports, clear the selected checkbox(es).

4. To bookmark a report, press Kio the left of its name. You can then easily return to

the report when needed. To remove the bookmark, press the star * again. If
desired you can filter only starred reports or only unstarred reports. On the right pane,
select the Starred check box to view only those starred reports. Clear the check box
to view all the reports.

Note: When you exit MentorLearn, those bookmarked reports are saved and will be
displayed the next time you open MentorLearn.

5. To scroll through the list of reports, use the Next and Previous arrows at the bottom
of the Reports screen.
6. To open a single-case report, press its row in the Reports table.

1—

3 wieo 2 WW 7

Ergonomics

Educational Aids

Resection

Fluid Management & Bleeding

Figure 8-1: Single-case report

surgicalscience Page 56


# Page 65

Chapter 8 
 Viewing Performance Reports
 
Page 57
 
1 
Report Header displays information about the report, 
including the user who performed the case, the name of 
the case performed, and the module that contains the 
performed case. 
The session number is displayed in the report header. 
2 
Scoreboard displays information about your total score 
for the task/case. For more information, see 
Understanding the scoreboard on page 63.  
3 
Video options display options for viewing, downloading 
and deleting the recorded video of your simulation 
performance. For more information, see Viewing 
recorded videos on page 59.  
4 
Metric column: the metrics included in the report. The 
available categories and metrics vary between simulators 
and simulation modules and cases. 
If a report has benchmarks, metrics with a defined skill 
level appear in the Benchmark section at the top of the 
list.  
Press the Up arrow at the end of the metric’s row to hide 
the associated metrics; press the Down arrow at the end 
of the metric category’s row to display the metrics. 
5 
Result column: the result of the metrics as recorded 
during the user's performance of a simulation case. Press 
a result to display additional information. For a detailed 
explanation, see Viewing additional information on page 
58. 
6 
Score column: The score as calculated on a normalized 
scale of 1-5. For a detailed explanation, see 
Understanding benchmarks and rating scales on page 65. 
7 
Learning Curve Graph for a selected metric: a colorful 
graph is displayed on the right side of the Report screen 
if the user has completed two or more sessions of the 
specific simulation case. For a detailed explanation of the 
graph, see Understanding learning curve graphs on page 
65. 


[TABLE]
| 1   | Report Header displays information about the report,        |
|:----|:------------------------------------------------------------|
|     | including the user who performed the case, the name of      |
|     | the case performed, and the module that contains the        |
|     | performed case.                                             |
|     | The session number is displayed in the report header.       |
| 2   | Scoreboard displays information about your total score      |
|     | for the task/case. For more information, see                |
|     | Understanding the scoreboard on page 63.                    |
| 3   | Video options display options for viewing, downloading      |
|     | and deleting the recorded video of your simulation          |
|     | performance. For more information, see Viewing              |
|     | recorded videos on page 59.                                 |
| 4   | Metric column: the metrics included in the report. The      |
|     | available categories and metrics vary between simulators    |
|     | and simulation modules and cases.                           |
|     | If a report has benchmarks, metrics with a defined skill    |
|     | level appear in the Benchmark section at the top of the     |
|     | list.                                                       |
|     | Press the Up arrow at the end of the metric’s row to hide   |
|     | the associated metrics; press the Down arrow at the end     |
|     | of the metric category’s row to display the metrics.        |
| 5   | Result column: the result of the metrics as recorded        |
|     | during the user's performance of a simulation case. Press   |
|     | a result to display additional information. For a detailed  |
|     | explanation, see Viewing additional information on page     |
|     | 58.                                                         |
| 6   | Score column: The score as calculated on a normalized       |
|     | scale of 1-5. For a detailed explanation, see               |
|     | Understanding benchmarks and rating scales on page 65.      |
| 7   | Learning Curve Graph for a selected metric: a colorful      |
|     | graph is displayed on the right side of the Report screen   |
|     | if the user has completed two or more sessions of the       |
|     | specific simulation case. For a detailed explanation of the |
|     | graph, see Understanding learning curve graphs on page      |
|     | 65.                                                         |

[OCR]
Chapter 8

Viewing Performance Reports

Report Header displays information about the report,
including the user who performed the case, the name of
the case performed, and the module that contains the
performed case.

The session number is displayed in the report header.
Scoreboard displays information about your total score

for the task/case. For more information, see
Understanding the scoreboard on page 63.

Video options display options for viewing, downloading
and deleting the recorded video of your simulation
performance. For more information, see Viewing
recorded videos on page 59.

Metric column: the metrics included in the report. The
available categories and metrics vary between simulators
and simulation modules and cases.

If a report has benchmarks, metrics with a defined skill
level appear in the Benchmark section at the top of the
list.

Press the Up arrow at the end of the metric’s row to hide
the associated metrics; press the Down arrow at the end
of the metric category’s row to display the metrics.

Result column: the result of the metrics as recorded
during the user's performance of a simulation case. Press
a result to display additional information. For a detailed
explanation, see Viewing additional information on page
58.

Score column: The score as calculated on a normalized
scale of 1-5. For a detailed explanation, see
Understanding benchmarks and rating scales on page 65.

Learning Curve Graph for a selected metric: a colorful
graph is displayed on the right side of the Report screen
if the user has completed two or more sessions of the
specific simulation case. For a detailed explanation of the
graph, see Understanding learning curve graphs on page
65.

surgicalscience Page 57


# Page 66

Chapter 8 
 Viewing Performance Reports
 
Page 58
 
Additional information if available such as a snapshot is 
displayed under the graph. 
8 
Print: press 
 to print the report to print the report. The 
button is located in the upper left corner of the screen. 
 
Viewing additional information 
1.  Press a metric’s result or click Additional Info to display details about the metric such 
as how it is measured or a captured snapshot.  
 
2.  Double-click the captured snapshot to display it in a separate window. 


[TABLE]
| Chapter 8   |                                                                                                | Viewing Performance Reports                  |
|:------------|:-----------------------------------------------------------------------------------------------|:---------------------------------------------|
|             | Additional information if available such as a snapshot is                                      |                                              |
|             | displayed under the graph.                                                                     |                                              |
| 8           |                                                                                                |                                              |
|             | Print: press                                                                                   | to print the report to print the report. The |
|             | button is located in the upper left corner of the screen.                                      |                                              |
|             | Viewing additional information                                                                 |                                              |
|             | 1.   Press a metric’s result or click Additional Info to display details about the metric such |                                              |
|             | as how it is measured or a captured snapshot.                                                  |                                              |
|             | 2.   Double-click the captured snapshot to display it in a separate window.                    |                                              |
|             |                                                                                                | Page 58                                      |

[OCR]
Chapter 8 Viewing Performance Reports

Additional information if available such as a snapshot is
displayed under the graph.

Print: press Eto print the report to print the report. The
button is located in the upper left corner of the screen.

Viewing additional information

1. Press a metric’s result or click Additional Info to display details about the metric such
as how it is measured or a captured snapshot.

‘Snapshot taken during procedure

Video

General

Ergonomics

Educational Aids

Resection

Fluid Management and Bleeding

2. Double-click the captured snapshot to display it in a separate window.

surgicalscience Page 58


# Page 67

Chapter 8 
 Viewing Performance Reports
 
Page 59
 
 
Figure 8-2: Snapshot viewed from single report 
Viewing recorded videos 
You can view a video of your simulation performance. You can download the video to 
review your performance at a later time or delete the recorded video. 
To view the performance video: 
1.  In the Video section of the report, press Video.  
The recorded video of your simulation case performance is displayed. 
2.  Double-click it to display in a separate window. 


[TABLE]
|                                                                                    | F                                                                    |
|                                                                                    | i                                                                    |
|                                                                                    | gure 8-2: Snapshot viewed from single report                         |
|:-----------------------------------------------------------------------------------|:---------------------------------------------------------------------|
| Viewing recorded videos                                                            |                                                                      |
| You can view a video of your simulation performance. You can download the video to |                                                                      |
| review your performance at a later time or delete the recorded video.              |                                                                      |
| To view the performance video:                                                     |                                                                      |
| 1.                                                                                 | In the Video section of the report, press Video.                     |
|                                                                                    | The recorded video of your simulation case performance is displayed. |
| 2.   Double-click it to display in a separate window.                              |                                                                      |

[OCR]
Chapter 8 Viewing Performance Reports

Figure 8-2: Snapshot viewed from single report

Viewing recorded videos

You can view a video of your simulation performance. You can download the video to
review your performance at a later time or delete the recorded video.

To view the performance video:
1. In the Video section of the report, press Video.

The recorded video of your simulation case performance is displayed.
2. Double-click it to display in a separate window.

surgicalscience Page 59


# Page 68

Chapter 8 
 Viewing Performance Reports
 
Page 60
 
 
 
Figure 8-3: Recorded video viewed from single report 
3.  Use the buttons under the video to play, pause, or view in full screen. 
4.  Press outside the video to close it and return to the single report. 


[TABLE]
| Chapter 8                                                                    | Viewing Performance Reports   |
|:-----------------------------------------------------------------------------|:------------------------------|
| F                                                                            |                               |
| i                                                                            |                               |
| gure 8-3: Recorded video viewed from single report                           |                               |
| 3.   Use the buttons under the video to play, pause, or view in full screen. |                               |
| 4.   Press outside the video to close it and return to the single report.    |                               |
|                                                                              | Page 60                       |

[OCR]
Chapter 8 Viewing Performance Reports

Client Administrator [ seresrcase | Procedure Time

surgealscience

Figure 8-3: Recorded video viewed from single report

3. Use the buttons under the video to play, pause, or view in full screen.
4. Press outside the video to close it and return to the single report.

surgical Page 60


# Page 69

Chapter 8 
 Viewing Performance Reports
 
Page 61
 
To download the performance video: 
1.  Press 
 in the top left corner of the screen and select Video>Download. 
OR 
Press 
 under the video and select Download Video. 
2.  Browse to select the file location where you want the video to be downloaded. 
3.  Press Save. 
The video is downloaded to the selected location. 
To delete the performance video: 
1.  Press 
 and select Video>Delete.  
The recorded video is deleted. 
Note: A message will appear when there is no more storage space for the recorded videos on your 
local drive. It is recommended to download those videos you wish to save to another drive on 
the computer or to an external drive (e.g. flash drive, or external hard disk) and then delete 
them.  
Enabling complications 
Using the options in MentorLearn’s course settings, you can enable the following 
simulation complications: 
• 
Random Electric failure – when enabled the monopolar/bipolar loop does not cut or 
coagulation when the user presses the pedal. 
• 
Random Light failure – when enabled, the light turns off. 
Each complication will occur once: 
• 
Diagnostic cases – within the first 2 minutes from case start. 
• 
Polypectomy/Myomectomy cases – will occur during resection (randomly before 
70% of the pathology is resected) 
You can fix these complication failures by: 
• 
Clicking the Fix Light failure on the Complications Management panel. 
• 
Clicking the Fix the Electric failure on the Complications Management panel. 


[TABLE]
| Chapter 8                                                                                        |
|  Viewing Performance Reports                                                                     |
|:-------------------------------------------------------------------------------------------------|
| To download the performance video:                                                               |
| 1.   Press                                                                                       |
|  in the top left corner of the screen and select Video>Download.                                 |
| OR                                                                                               |
| Press                                                                                            |
|  under the video and select Download Video.                                                      |
| 2.   Browse to select the file location where you want the video to be downloaded.               |
| 3.   Press Save.                                                                                 |
| The video is downloaded to the selected location.                                                |
| To delete the performance video:                                                                 |
| 1.   Press                                                                                       |
|  and select Video>Delete.                                                                        |
| The recorded video is deleted.                                                                   |
| Note:  A message will appear when there is no more storage space for the recorded videos on your |
| local drive. It is recommended to download those videos you wish to save to another drive on     |
| the computer or to an external drive (e.g. flash drive, or external hard disk) and then delete   |
| them.                                                                                            |
| Enabling complications                                                                           |
| Using the options in MentorLearn’s course settings, you can enable the following                 |
| simulation complications:                                                                        |
| Random Electric failure – when enabled the monopolar/bipolar loop does not cut or                |
| •                                                                                                |
| coagulation when the user presses the pedal.                                                     |
| Random Light failure – when enabled, the light turns off.                                        |
| •                                                                                                |
| Each complication will occur once:                                                               |
| Diagnostic cases – within the first 2 minutes from case start.                                   |
| •                                                                                                |
| Polypectomy/Myomectomy cases – will occur during resection (randomly before                      |
| •                                                                                                |
| 70% of the pathology is resected)                                                                |
| You can fix these complication failures by:                                                      |
| Clicking the Fix Light failure on the Complications Management panel.                            |
| •                                                                                                |
| Clicking the Fix the Electric failure on the Complications Management panel.                     |
| •                                                                                                |
| Page 61                                                                                          |

[OCR]
Chapter 8 Viewing Performance Reports

To download the performance video:

1. Press A in the top left corner of the screen and select Video>Download.
OR

Press | | under the video and select Download Video.

Browse to select the file location where you want the video to be downloaded.
Press Save.

wr

The video is downloaded to the selected location.

To delete the performance video:

1. Press 3 | and select Video>Delete.

The recorded video is deleted.

Note: A message will appear when there is no more storage space for the recorded videos on your
local drive. It is recommended to download those videos you wish to save to another drive on
the computer or to an external drive (e.g. flash drive, or external hard disk) and then delete
them.

Enabling complications

Using the options in MentorLearn’s course settings, you can enable the following
simulation complications:

. Random Electric failure - when enabled the monopolar/bipolar loop does not cut or
coagulation when the user presses the pedal.
. Random Light failure - when enabled, the light turns off.

Each complication will occur once:

. Diagnostic cases — within the first 2 minutes from case start.
. Polypectomy/Myomectomy cases -— will occur during resection (randomly before
70% of the pathology is resected)

You can fix these complication failures by:

. Clicking the Fix Light failure on the Complications Management panel.
. Clicking the Fix the Electric failure on the Complications Management panel.

surgicalscience Page 61


# Page 70

Chapter 8 
 Viewing Performance Reports
 
Page 62
 
 
To enable these complications: 
Under Edit Metrics Filters for the specified course’s settings, move the slider to turn on 
(enable) the Electric failure and Light failure complications. 
 
 


[TABLE]
| Chapter 8                                                      | Viewing Performance Reports                                                                |
|:---------------------------------------------------------------|:-------------------------------------------------------------------------------------------|
| To enable these complications:                                 |                                                                                            |
|                                                                | Under Edit Metrics Filters for the specified course’s settings, move the slider to turn on |
| (enable) the Electric failure and Light failure complications. |                                                                                            |
|                                                                | Page 62                                                                                    |

[OCR]
Chapter 8

Viewing Performance Reports

Complications Management

me

To enable these complications:

Under Edit Metrics Filters for

(enable) the Electric failure and Light failure complications.

he specified course’s settings, move the slider to turn on

Hysteroscopic Polypectomy

Course Settings:

Show course only to assigned »

learners

Always display (default) ¥
Default ~
Edit Metrics Filters >

Electric failure

Light failure

Record video @

Completion Instructions

Perform in case order »
Start assignments manually B

Perform case once BD

Hysteroscopic Polypectomy

Course Settings:

Show course only to assigned »

learners

Always display (default) .
Default .
Edit Metrics Filters >

Electric failure

Light failure

Record video = )

Completion Instructions:

Perform in case order »
Start assignments manually BD

Perform case once i

surgicalscience

Page 62


# Page 71

Chapter 8 
 Viewing Performance Reports
 
Page 63
 
The complications will occur randomly in the simulation of the specified course. 
Browsing between sessions 
Use the Previous and Next arrows to browse between different report sessions. 
MentorLearn allows you to browse between the sessions performed of the same case 
within a certain course/module. Therefore, if a learner performed a case independently 3 
times for a module listed in the Library and then performed the same case an additional 
two times within the framework of a course, these sessions will not be linked together. 
The learner would need to browse separately between the sessions performed in the 
module and sessions performed within the framework of the course. 
Understanding the scoreboard 
The benchmark scoreboard displays a summary of your performance in a clear and 
colorful way.  
 
Figure 8-4: Case benchmark scoreboard 
It includes the following components: 
• 
Proficient: shows if you reached the required skill level or not for the simulation 
case.  
• 
Best Score: is calculated as a weighted average of the scores for each of the 
benchmark metrics. In the above report, 86% = the average score of the metrics for 
the case/task (e.g. total time, total path, accuracy rate, horizontal view). The best 
score is displayed in a percentage.  


[TABLE]
| Chapter 8                                                                         | Viewing Performance Reports                                                              |
|:----------------------------------------------------------------------------------|:-----------------------------------------------------------------------------------------|
| The complications will occur randomly in the simulation of the specified course.  |                                                                                          |
| Browsing between sessions                                                         |                                                                                          |
| Use the Previous and Next arrows to browse between different report sessions.     |                                                                                          |
|                                                                                   | MentorLearn allows you to browse between the sessions performed of the same case         |
|                                                                                   | within a certain course/module. Therefore, if a learner performed a case independently 3 |
|                                                                                   | times for a module listed in the Library and then performed the same case an additional  |
|                                                                                   | two times within the framework of a course, these sessions will not be linked together.  |
| The learner would need to browse separately between the sessions performed in the |                                                                                          |
| module and sessions performed within the framework of the course.                 |                                                                                          |
| Understanding the scoreboard                                                      |                                                                                          |
| The benchmark scoreboard displays a summary of your performance in a clear and    |                                                                                          |
| colorful way.                                                                     |                                                                                          |

[TABLE]
| F                                     |                                                                                       |
| i                                     |                                                                                       |
| gure 8-4: Case benchmark scoreboard   |                                                                                       |
|:--------------------------------------|:--------------------------------------------------------------------------------------|
| It includes the following components: |                                                                                       |
| •                                     | Proficient: shows if you reached the required skill level or not for the simulation   |
|                                       | case.                                                                                 |
| •                                     | Best Score: is calculated as a weighted average of the scores for each of the         |
|                                       | benchmark metrics. In the above report, 86% = the average score of the metrics for    |
|                                       | the case/task (e.g. total time, total path, accuracy rate, horizontal view). The best |
|                                       | score is displayed in a percentage.                                                   |

[OCR_TABLE]
Chapter 8

[OCR_TABLE]
Zi VV Vit

[OCR]
Chapter 8 Viewing Performance Reports

The complications will occur randomly in the simulation of the specified course.

Browsing between sessions

Use the Previous and Next arrows to browse between different report sessions.

MentorLearn allows you to browse between the sessions performed of the same case
within a certain course/module. Therefore, if a learner performed a case independently 3
times for a module listed in the Library and then performed the same case an additional
two times within the framework of a course, these sessions will not be linked together.
The learner would need to browse separately between the sessions performed in the
module and sessions performed within the framework of the course.

Understanding the scoreboard

The benchmark scoreboard displays a summary of your performance in a clear and
colorful way.

Case proficiency Proficiency established b

eco
Yes 2 of 1 3
Proficient Non consecutive: Attempts

Figure 8-4: Case benchmark scoreboard
It includes the following components:
. Proficient: shows if you reached the required skill level or not for the simulation

case.
. Best Score: is calculated as a weighted average of the scores for each of the

benchmark metrics. In the above report, 86% = the average score of the metrics for
the case/task (e.g. total time, total path, accuracy rate, horizontal view). The best
score is displayed in a percentage.

surgicalscience Page 63


# Page 72

Chapter 8 
 Viewing Performance Reports
 
Page 64
 
o 
The default is that the benchmarks have the same weights. However, the 
best score can be customized so that certain metrics have more weight than 
others. 
o 
Some metrics may be set as critical (must pass) and if you don’t pass the 
metric, you receive a total score of “Failed”. For example, if a case/task must 
be performed with no complications and 2 complications occurred, your total 
score would be “Failed”:  
• 
Non-consecutive: indicates how many times you need to attain the required skill 
level to achieve proficiency. For example, if you are required to achieve the skill 
level once and you accomplished it, your score would be Non-consecutive: 1 of 1. 
• 
Consecutive: indicates how many consecutive times you are required to attain a 
skill level. For example, if you are required to achieve the skill level in two 
consecutive times and you succeeded the first time, the result would show 
Consecutive: 1 of 2. If you succeed in the next attempt, the score will show 
Consecutive: 2 of 2. If you failed at the second attempt, you would have to start 
again since the requirement is for 2 consecutive successful attempts. 
• 
Attempts: how many attempts/sessions/repetitions of this case you performed. 
 
The session components are displayed below the case/task components: 
 
Figure 8-5: Session benchmark scoreboard 
Proficient: shows if you reached the required skill level or not for this session of the 
case/task.  
Score: is calculated as a weighted average of the scores for each of the benchmark 
metrics for this session. In the above report, 86% = the average score of the metrics for 
the session (e.g. total time, total path, accuracy rate, horizontal view). The score is 
displayed in percentages.  


[TABLE]
| Viewing Performance Reports                                                     |
|:--------------------------------------------------------------------------------|
| The default is that the benchmarks have the same weights. However, the          |
| o                                                                               |
| best score can be customized so that certain metrics have more weight than      |
| others.                                                                         |
| Some metrics may be set as critical (must pass) and if you don’t pass the       |
| o                                                                               |
| metric, you receive a total score of “Failed”. For example, if a case/task must |
| be performed with no complications and 2 complications occurred, your total     |
| score would be “Failed”:                                                        |
| Non-consecutive: indicates how many times you need to attain the required skill |

[TABLE]
|    | Some metrics may be set as critical (must pass) and if you don’t pass the           |
|:---|:------------------------------------------------------------------------------------|
|    | o                                                                                   |
|    | metric, you receive a total score of “Failed”. For example, if a case/task must     |
|    | be performed with no complications and 2 complications occurred, your total         |
|    | score would be “Failed”:                                                            |
| •  | Non-consecutive: indicates how many times you need to attain the required skill     |
|    | level to achieve proficiency. For example, if you are required to achieve the skill |
|    | level once and you accomplished it, your score would be Non-consecutive: 1 of 1.    |
| •  | Consecutive: indicates how many consecutive times you are required to attain a      |
|    | skill level. For example, if you are required to achieve the skill level in two     |
|    | consecutive times and you succeeded the first time, the result would show           |
|    | Consecutive: 1 of 2. If you succeed in the next attempt, the score will show        |
|    | Consecutive: 2 of 2. If you failed at the second attempt, you would have to start   |
|    | again since the requirement is for 2 consecutive successful attempts.               |
| •  | Attempts: how many attempts/sessions/repetitions of this case you performed.        |

[TABLE]
| F                                                                                         |
| i                                                                                         |
| gure 8-5: Session benchmark scoreboard                                                    |
|:------------------------------------------------------------------------------------------|
| Proficient: shows if you reached the required skill level or not for this session of the  |
| case/task.                                                                                |
| Score: is calculated as a weighted average of the scores for each of the benchmark        |
| metrics for this session. In the above report, 86% = the average score of the metrics for |
| the session (e.g. total time, total path, accuracy rate, horizontal view). The score is   |
| displayed in percentages.                                                                 |

[OCR]
Chapter 8 Viewing Performance Reports

° The default is that the benchmarks have the same weights. However, the
best score can be customized so that certain metrics have more weight than
others.

° Some metrics may be set as critical (must pass) and if you don’t pass the

metric, you receive a total score of “Failed”. For example, if a case/task must
be performed with no complications and 2 complications occurred, your total
score would be “Failed”:

. Non-consecutive: indicates how many times you need to attain the required skill
level to achieve proficiency. For example, if you are required to achieve the skill
level once and you accomplished it, your score would be Non-consecutive: 1 of 1.

. Consecutive: indicates how many consecutive times you are required to attain a
skill level. For example, if you are required to achieve the skill level in two
consecutive times and you succeeded the first time, the result would show
Consecutive: 1 of 2. If you succeed in the next attempt, the score will show
Consecutive: 2 of 2. If you failed at the second attempt, you would have to start
again since the requirement is for 2 consecutive successful attempts.

. Attempts: how many attempts/sessions/repetitions of this case you performed.

The session components are displayed below the case/task components:

Session proficiency

86%

Yes
Proficient Score

Figure 8-5: Session benchmark scoreboard

Proficient: shows if you reached the required skill level or not for this session of the
case/task.

Score: is calculated as a weighted average of the scores for each of the benchmark
metrics for this session. In the above report, 86% = the average score of the metrics for
the session (e.g. total time, total path, accuracy rate, horizontal view). The score is
displayed in percentages.

surgicalscience Page 64


# Page 73

Chapter 8 
 Viewing Performance Reports
 
Page 65
 
Understanding benchmarks and rating scales 
Metrics with a defined skill level appear in the Benchmark section. Each metric is 
displayed on a rating scale showing at a quick glance if you have passed or failed the 
required level for this metric.  
 
Figure 8-6: Benchmark rating scale 
The rating scale includes the following components: 
• 
Proficiency (where the score = exactly 4) is exactly the value for which the area 
turns from yellow to green. If your result is exactly or better than the proficiency 
value, your score falls in the green area. 
 
• 
If you are not proficient, your score is in the orange-yellow area: 
 
• 
Scores are calculated on a normalized scale of 1-5: 
o 
<2 = poor 
o 
2.0 - <4.0 = average 
o 
4.0 - <4.5 = expert (score = 4 exactly when you reach proficiency) 
o 
> 4.5 = superior 
• 
Press the rating scale; additional information is displayed in the right pane. 
Understanding learning curve graphs 
If you have completed two or more sessions of the specific simulation case, the graph 
shows the learning curve for the selected metric.  


[TABLE]
| F                                                   |                                                                                      |
| i                                                   |                                                                                      |
| gure 8-6: Benchmark rating scale                    |                                                                                      |
|:----------------------------------------------------|:-------------------------------------------------------------------------------------|
| The rating scale includes the following components: |                                                                                      |
| •                                                   | Proficiency (where the score = exactly 4) is exactly the value for which the area    |
|                                                     | turns from yellow to green. If your result is exactly or better than the proficiency |
|                                                     | value, your score falls in the green area.                                           |
| •                                                   | If you are not proficient, your score is in the orange-yellow area:                  |
| •                                                   | Scores are calculated on a normalized scale of 1-5:                                  |

[OCR_TABLE]
NAatricne wy

[OCR]
Chapter 8

Viewing Performance Reports

Understanding benchmarks and rating scales

Metrics with a defined skill level appear in the Benchmark section. Each metric is
displayed on a rating scale showing at a quick glance if you have passed or failed the

required level for this metric.

Benchmarks

10 Hits

Number of correct hits

100 %

je using the 0° camera (%)

97.2%

126.6 em

Total time 00:00:51

Score: 5.00

Score: 5.00

Score: 4.50

core: 4.29

ore: 5.00

Figure 8-6: Benchmark rating scale

The rating scale includes the following components:

. Proficiency (where the score = exactly 4) is exactly the value for which the area
turns from yellow to green. If your result is exactly or better than the proficiency
. 97.2%
value, your score falls in the green area.
. If you are not proficient, your score is in the orange-yellow area:
2Hits
. Scores are calculated on a normalized scale of 1-5:
° <2 = poor
° 2.0 - <4.0 = average
° 4.0 - <4.5 = expert (score = 4 exactly when you reach proficiency)
° > 4.5 = superior

. Press the rating scale; additional information is displayed in the right pane.

Understanding learning curve graphs

If you have completed two or more sessions of the specific simulation case, the graph

shows the learning curve for the selected metric.

surgicalscience

Page 65


# Page 74

Chapter 8 
 Viewing Performance Reports
 
Page 66
 
Note: If benchmarks are defined, the graph is colored using the same color scheme as the rating 
scale. 
The y axis charts the results for the selected metric and the x axis charts the repetitions 
or attempts of this case. 
When benchmarks are defined, you can see your progress in attaining proficiency for the 
specific metric.  
Press a metric in order to display its graph. 
 
If the curve is the orange-yellow area, you haven’t achieved proficiency for this metric.  
If the curve is in the green area, you are proficient in this metric. 
 
Figure 8-7: Report's learning curve 
Exporting performance results 
Performance results can be exported to a file. The data is saved as CSV (comma 
separated values) file, which can be viewed using Microsoft® Excel®. 
To export data: 
1.  Press Reports on the MentorLearn menu to access the Reports screen. 
2.  Select the reports you want to export. 


[TABLE]
| Chapter 8                                                             | Viewing Performance Reports                                                                     |
|:----------------------------------------------------------------------|:------------------------------------------------------------------------------------------------|
|                                                                       | Note: If benchmarks are defined, the graph is colored using the same color scheme as the rating |
| scale.                                                                |                                                                                                 |
|                                                                       | The y axis charts the results for the selected metric and the x axis charts the repetitions     |
| or attempts of this case.                                             |                                                                                                 |
|                                                                       | When benchmarks are defined, you can see your progress in attaining proficiency for the         |
| specific metric.                                                      |                                                                                                 |
| Press a metric in order to display its graph.                         |                                                                                                 |
|                                                                       | If the curve is the orange-yellow area, you haven’t achieved proficiency for this metric.       |
| If the curve is in the green area, you are proficient in this metric. |                                                                                                 |

[OCR]
Chapter 8 Viewing Performance Reports

Note: If benchmarks are defined, the graph is colored using the same color scheme as the rating
scale.

The y axis charts the results for the selected metric and the x axis charts the repetitions
or attempts of this case.

When benchmarks are defined, you can see your progress in attaining proficiency for the
specific metric.

Press a metric in order to display its graph.

Number of correct hits 10Hits [MN — Score:5.00

If the curve is the orange-yellow area, you haven't achieved proficiency for this metric.

If the curve is in the green area, you are proficient in this metric.

Number of correct hits

Hits

*Only the sessions in which the event occurred are displayed

Figure 8-7: Report's learning curve

Exporting performance results

Performance results can be exported to a file. The data is saved as CSV (comma
separated values) file, which can be viewed using Microsoft® Excel®.

To export data:
1. Press Reports on the MentorLearn menu to access the Reports screen.
2. Select the reports you want to export.

surgicalscience Page 66


# Page 75

Chapter 8 
 Viewing Performance Reports
 
Page 67
 
3.  Press 
 and select Reports>Export Performance.  
 
Figure 8-8: Export Performance window 
4.  In the Export Performance window, define the format of the report as well as the time 
period that should be included in the exported file and press Export. 
5.  Select a location where MentorLearn will save the exported file, and then press Save. 
MentorLearn generates the performance data and saves the exported file in the 
specified location. 


[TABLE]
| Chapter 8                                                                                  |
|  Viewing Performance Reports                                                               |
|:-------------------------------------------------------------------------------------------|
| 3.   Press                                                                                 |
|  and select Reports>Export Performance.                                                    |
| F                                                                                          |
| i                                                                                          |
| gure 8-8: Export Performance window                                                        |
| 4.                                                                                         |
| In the Export Performance window, define the format of the report as well as the time      |
| period that should be included in the exported file and press Export.                      |
| 5.   Select a location where MentorLearn will save the exported file, and then press Save. |
| MentorLearn generates the performance data and saves the exported file in the              |
| specified location.                                                                        |
| Page 67                                                                                    |

[OCR]
Chapter 8 Viewing Performance Reports

3. Press Ly and select Reports>Export Performance.

Export Performance x

2 selected sessions

rows export

D Export time in seconds

1/24/2021 ia]

CANCEL EXPORT

Figure 8-8: Export Performance window

4. In the Export Performance window, define the format of the report as well as the time
period that should be included in the exported file and press Export.
5. Select a location where MentorLearn will save the exported file, and then press Save.

MentorLearn generates the performance data and saves the exported file in the
specified location.

surgicalscience Page 67


# Page 76

Chapter 9 
 Technical Support
 
Page 68
 
Chapter 9 Technical Support 
SURGICAL SCIENCE SUPPORT POLICY 
Surgical Science assigns the highest priority to customer support. We are committed to 
doing our utmost to provide our clients with reliable support and assistance 24 hours a 
day, 7 days a week. This support is available in real time via telephone or email. 
Surgical Science Call Center 
Customer service 24/7: +1-216-270-2020 
email: support@surgicalscience.com 
 


[TABLE]
| Chapter 9                                                                          | Technical Support                                                                       |
|:-----------------------------------------------------------------------------------|:----------------------------------------------------------------------------------------|
| Chapter 9  Technical Support                                                       |                                                                                         |
| SURGICAL SCIENCE SUPPORT POLICY                                                    |                                                                                         |
|                                                                                    | Surgical Science assigns the highest priority to customer support. We are committed to  |
|                                                                                    | doing our utmost to provide our clients with reliable support and assistance 24 hours a |
| day, 7 days a week. This support is available in real time via telephone or email. |                                                                                         |
| Surgical Science Call Center                                                       |                                                                                         |
| Customer service 24/7: +1-216-270-2020                                             |                                                                                         |
| email: support@surgicalscience.com                                                 |                                                                                         |

[OCR]
Chapter 9 Technical Support

| Chapter 9 Technical Support
SURGICAL SCIENCE SUPPORT POLICY

Surgical Science assigns the highest priority to customer support. We are committed to
doing our utmost to provide our clients with reliable support and assistance 24 hours a
day, 7 days a week. This support is available in real time via telephone or email.

Surgical Science Call Center

Customer service 24/7: +1-216-270-2020

email: support@surgicalscience.com

surgicalscience Page 68


# Page 77

Chapter 10 
 End-User Software License Agreement
 
Page 69
 
Chapter 10 End-User Software License 
Agreement 
HYST Mentor® 
1.  DEFINITIONS 
This End-User License Agreement ("Agreement") is a legal agreement between you 
(either an individual or a single entity) and Surgical Science Sweden AB ("Surgical 
Science") for HYST Mentor® or such upgrade or future versions thereof identified in the 
Particulars or the License Key Issue Note, which includes computer software and may 
include associated media, printed materials, and electronic documentation ("Software"). 
 
11.  GRANT 
Surgical Science hereby grants to you a non-exclusive, non-transferable license to install 
and use one copy of the Software, or any prior version for the same operating system in 
accordance with the applicable license type (the type of license in your case can be 
found in the order form / invoice as well as in the License Key Issue Note from Surgical 
Science). The License hereby granted is subject to the following conditions. 
 
111.  CONDITIONS 
1  EXTENT OF LICENSE 
1.1  If you have acquired a hardware identity-based license you may install and use one 
copy of the Software, or any prior version for the same operating system on the single 
computer for which the License Key is issued. 
1.2  If you have acquired a hardware key ("dongle") based node locked license you may 
install and use one copy of the Software, or any prior version for the same operating 
system on the single computer to which the Hardware Key, for which the License Key is 
issued, is attached. Note that you are not obligated to remove the installed Software from 
the computer even if the Hardware Key is removed. However, you are not entitled to use 
the Software on that computer unless the Hardware key is reattached. 


[TABLE]
| Chapter 10           |                                                                                            | End-User Software License Agreement   |
|:---------------------|:-------------------------------------------------------------------------------------------|:--------------------------------------|
|                      | Chapter 10 End-User Software License                                                       |                                       |
|                      | Agreement                                                                                  |                                       |
| HYST Mentor®         |                                                                                            |                                       |
| 1.  DEFINITIONS      |                                                                                            |                                       |
|                      | This End-User License Agreement ("Agreement") is a legal agreement between you             |                                       |
|                      | (either an individual or a single entity) and Surgical Science Sweden AB ("Surgical        |                                       |
|                      | Science") for HYST Mentor® or such upgrade or future versions thereof identified in the    |                                       |
|                      | Particulars or the License Key Issue Note, which includes computer software and may        |                                       |
|                      | include associated media, printed materials, and electronic documentation ("Software").    |                                       |
| 1                    |                                                                                            |                                       |
| 1.  GRANT            |                                                                                            |                                       |
|                      | Surgical Science hereby grants to you a non-exclusive, non-transferable license to install |                                       |
|                      | and use one copy of the Software, or any prior version for the same operating system in    |                                       |
|                      | accordance with the applicable license type (the type of license in your case can be       |                                       |
|                      | found in the order form / invoice as well as in the License Key Issue Note from Surgical   |                                       |
|                      | Science). The License hereby granted is subject to the following conditions.               |                                       |
| 1                    |                                                                                            |                                       |
| 11.  CONDITIONS      |                                                                                            |                                       |
| 1  EXTENT OF LICENSE |                                                                                            |                                       |
|                      | 1.1  If you have acquired a hardware identity-based license you may install and use one    |                                       |
|                      | copy of the Software, or any prior version for the same operating system on the single     |                                       |
|                      | computer for which the License Key is issued.                                              |                                       |
|                      | 1.2  If you have acquired a hardware key ("dongle") based node locked license you may      |                                       |
|                      | install and use one copy of the Software, or any prior version for the same operating      |                                       |
|                      | system on the single computer to which the Hardware Key, for which the License Key is      |                                       |
|                      | issued, is attached. Note that you are not obligated to remove the installed Software from |                                       |
|                      | the computer even if the Hardware Key is removed. However, you are not entitled to use     |                                       |
|                      | the Software on that computer unless the Hardware key is reattached.                       |                                       |
|                      |                                                                                            | Page 69                               |

[OCR]
Chapter 10 End-User Software License Agreement

Chapter 10 End-User Software License
Agreement

HYST Mentor®

1. DEFINITIONS

This End-User License Agreement ("Agreement") is a legal agreement between you
(either an individual or a single entity) and Surgical Science Sweden AB ("Surgical
Science") for HYST Mentor® or such upgrade or future versions thereof identified in the
Particulars or the License Key Issue Note, which includes computer software and may
include associated media, printed materials, and electronic documentation ("Software").

11. GRANT

Surgical Science hereby grants to you a non-exclusive, non-transferable license to install
and use one copy of the Software, or any prior version for the same operating system in
accordance with the applicable license type (the type of license in your case can be
found in the order form / invoice as well as in the License Key Issue Note from Surgical
Science). The License hereby granted is subject to the following conditions.

11. CONDITIONS

1 EXTENT OF LICENSE

-1 If you have acquired a hardware identity-based license you may install and use one
copy of the Software, or any prior version for the same operating system on the single
computer for which the License Key is issued.

1.2 If you have acquired a hardware key ("dongle") based node locked license you may
install and use one copy of the Software, or any prior version for the same operating
system on the single computer to which the Hardware Key, for which the License Key is
issued, is attached. Note that you are not obligated to remove the installed Software from
the computer even if the Hardware Key is removed. However, you are not entitled to use
the Software on that computer unless the Hardware key is reattached.

surgicalscience Page 69


# Page 78

Chapter 10 
 End-User Software License Agreement
 
Page 70
 
1.3  If you have acquired a floating license, you may install one copy of the Software or 
any prior version for the same operating system on any number of computers and 
simultaneously use no more than the number of Software permitted in the License Key 
Issue Note. The rights of installation and use of Software is restricted to the site defined 
in the License Key Issue Note. 
1.4  If the Software is labeled as an upgrade, you must be properly licensed to use a 
product identified by Surgical Science as being eligible for the upgrade in order to use the 
Software. Software labeled as an upgrade replaces and/or supplements the product that 
formed the basis for your eligibility for the upgrade. You may use the resulting upgraded 
product only in accordance with the terms of this Agreement. 
1.5  If the Software is labeled as an upgrade, you must be properly licensed to use a 
product identified by Surgical Science as being eligible for the upgrade in order to use the 
Software. Software labeled as an upgrade replaces and/or supplements the product that 
formed the basis for your eligibility for the upgrade. You may use the resulting upgraded 
product only in accordance with the terms of this Agreement. 
1.6  This license is personal to you and you shall not assign or transfer any interest in it or 
grant any right under it to any third party or seek to exercise this license for the benefit or 
on the data of any third party. 
2  CONFIDENCE OF THE SOFTWARE AND COPYRIGHT 
2.1  The Software, all associated documentation, and all copies are secret and 
confidential to Surgical Science and shall be retained under the effective control of you 
during the period of this Agreement. Disclosures shall be limited to those members of 
your staff (including temporary staff) who need access to the Software to enable you to 
exercise this license. You shall take all measures necessary to maintain confidence and 
secrecy in the Software during the period of this license and after its termination, 
however such termination may arise. 
2.2  All title and copyrights and patents in and to the Software (including but not limited to 
any images, photographs, animations, video, audio, music, text, techniques and "applets" 
incorporated into the Software), the accompanying printed materials, and any copies of 
the Software are owned by Surgical Science or its suppliers. The Software is protected by 
copyright laws and patents laws as well as by international treaty provisions. Therefore, 
you must treat the Software like any other copyrighted or patented material. You may not 
copy the printed materials accompanying the Software. 


[TABLE]
| Chapter 10                                                                            | End-User Software License Agreement                                                             |
|:--------------------------------------------------------------------------------------|:------------------------------------------------------------------------------------------------|
|                                                                                       | 1.3  If you have acquired a floating license, you may install one copy of the Software or       |
| any prior version for the same operating system on any number of computers and        |                                                                                                 |
| simultaneously use no more than the number of Software permitted in the License Key   |                                                                                                 |
|                                                                                       | Issue Note. The rights of installation and use of Software is restricted to the site defined    |
| in the License Key Issue Note.                                                        |                                                                                                 |
| 1.4  If the Software is labeled as an upgrade, you must be properly licensed to use a |                                                                                                 |
|                                                                                       | product identified by Surgical Science as being eligible for the upgrade in order to use the    |
|                                                                                       | Software. Software labeled as an upgrade replaces and/or supplements the product that           |
|                                                                                       | formed the basis for your eligibility for the upgrade. You may use the resulting upgraded       |
| product only in accordance with the terms of this Agreement.                          |                                                                                                 |
| 1.5  If the Software is labeled as an upgrade, you must be properly licensed to use a |                                                                                                 |
|                                                                                       | product identified by Surgical Science as being eligible for the upgrade in order to use the    |
|                                                                                       | Software. Software labeled as an upgrade replaces and/or supplements the product that           |
|                                                                                       | formed the basis for your eligibility for the upgrade. You may use the resulting upgraded       |
| product only in accordance with the terms of this Agreement.                          |                                                                                                 |
|                                                                                       | 1.6  This license is personal to you and you shall not assign or transfer any interest in it or |
|                                                                                       | grant any right under it to any third party or seek to exercise this license for the benefit or |
| on the data of any third party.                                                       |                                                                                                 |
| 2  CONFIDENCE OF THE SOFTWARE AND COPYRIGHT                                           |                                                                                                 |
| 2.1  The Software, all associated documentation, and all copies are secret and        |                                                                                                 |
|                                                                                       | confidential to Surgical Science and shall be retained under the effective control of you       |
| during the period of this Agreement. Disclosures shall be limited to those members of |                                                                                                 |
|                                                                                       | your staff (including temporary staff) who need access to the Software to enable you to         |
|                                                                                       | exercise this license. You shall take all measures necessary to maintain confidence and         |
| secrecy in the Software during the period of this license and after its termination,  |                                                                                                 |
| however such termination may arise.                                                   |                                                                                                 |
|                                                                                       | 2.2  All title and copyrights and patents in and to the Software (including but not limited to  |
|                                                                                       | any images, photographs, animations, video, audio, music, text, techniques and "applets"        |
|                                                                                       | incorporated into the Software), the accompanying printed materials, and any copies of          |
|                                                                                       | the Software are owned by Surgical Science or its suppliers. The Software is protected by       |
|                                                                                       | copyright laws and patents laws as well as by international treaty provisions. Therefore,       |
|                                                                                       | you must treat the Software like any other copyrighted or patented material. You may not        |
| copy the printed materials accompanying the Software.                                 |                                                                                                 |

[OCR_TABLE]
Chapter 10

[OCR_TABLE]
any prior vel
simultaneou

[OCR_TABLE]
Issue Note. T
in the | irane

[OCR]
Chapter 10 End-User Software License Agreement

1.3 If you have acquired a floating license, you may install one copy of the Software or
any prior version for the same operating system on any number of computers and
simultaneously use no more than the number of Software permitted in the License Key
Issue Note. The rights of installation and use of Software is restricted to the site defined
in the License Key Issue Note.

1.4 If the Software is labeled as an upgrade, you must be properly licensed to use a
product identified by Surgical Science as being eligible for the upgrade in order to use the
Software. Software labeled as an upgrade replaces and/or supplements the product that
formed the basis for your eligibility for the upgrade. You may use the resulting upgraded
product only in accordance with the terms of this Agreement.

1.5 If the Software is labeled as an upgrade, you must be properly licensed to use a
product identified by Surgical Science as being eligible for the upgrade in order to use the
Software. Software labeled as an upgrade replaces and/or supplements the product that
formed the basis for your eligibility for the upgrade. You may use the resulting upgraded
product only in accordance with the terms of this Agreement.

1.6 This license is personal to you and you shall not assign or transfer any interest in it or
grant any right under it to any third party or seek to exercise this license for the benefit or
on the data of any third party.

2 CONFIDENCE OF THE SOFTWARE AND COPYRIGHT

2.1 The Software, all associated documentation, and all copies are secret and
confidential to Surgical Science and shall be retained under the effective control of you
during the period of this Agreement. Disclosures shall be limited to those members of
your staff (including temporary staff) who need access to the Software to enable you to
exercise this license. You shall take all measures necessary to maintain confidence and
secrecy in the Software during the period of this license and after its termination,
however such termination may arise.

2.2 All title and copyrights and patents in and to the Software (including but not limited to
any images, photographs, animations, video, audio, music, text, techniques and "applets"
incorporated into the Software), the accompanying printed materials, and any copies of
the Software are owned by Surgical Science or its suppliers. The Software is protected by
copyright laws and patents laws as well as by international treaty provisions. Therefore,
you must treat the Software like any other copyrighted or patented material. You may not
copy the printed materials accompanying the Software.

surgicalscience Page 70


# Page 79

Chapter 10 
 End-User Software License Agreement
 
Page 71
 
3  OWNERSHIP OF SOFTWARE 
3.1  Subject to the rights granted to you by this Agreement, you acknowledge that all and 
any proprietary rights in the software (including but not limited to copyrights, patents, 
trademarks and trade secrets) and in all associated documentation and other material 
related to the Software in each case now existing or to be developed by Surgical Science 
shall remain the sole property of Surgical Science. 
3.2  Usage Data. You acknowledge and agree that Surgical Science may derive or create 
data and information about the use of the Software by you and your users ("Usage Data") 
and Surgical Science may use and disclose Usage Data to its third-party service providers 
in order to improve the Software. Personal data related to any identifiable individual is not 
collected by Surgical Science. 
4  SUPPORT SERVICES 
4.1  Surgical Science may provide you with support services related to the Software 
("Support Services"). Use of Support Services is governed by the Surgical Science 
policies and programs described in the user manual, in "online" documentation, and/or in 
other Surgical Science-provided materials. Any supplemental software provided to you as 
part of the Support Services shall be considered part of the Software and subject to the 
terms and conditions of this Agreement. With respect to technical information you provide 
to Surgical Science as part of the Support Services, Surgical Science may use such 
information for its business purposes, including for product support and development. 
Surgical Science will not utilize such technical information in a form that personally 
identifies you. 
5  INTEGRITY OF THE SOFTWARE 
5.1  You shall not, directly or indirectly in any form or manner, copy, distribute, reproduce, 
incorporate or allow unauthorized use or access to the Software or modify, decompile, 
reverse engineer, disassemble or otherwise attempt to derive a source code or similar 
information from Software, except as explicitly permitted under this Agreement. 
5.2  The Software is licensed as a single product. Its component parts may not be 
separated for use on more than one computer. 


[TABLE]
| Chapter 10                                                                                | End-User Software License Agreement                                                            |
|:------------------------------------------------------------------------------------------|:-----------------------------------------------------------------------------------------------|
| 3  OWNERSHIP OF SOFTWARE                                                                  |                                                                                                |
|                                                                                           | 3.1  Subject to the rights granted to you by this Agreement, you acknowledge that all and      |
| any proprietary rights in the software (including but not limited to copyrights, patents, |                                                                                                |
| trademarks and trade secrets) and in all associated documentation and other material      |                                                                                                |
|                                                                                           | related to the Software in each case now existing or to be developed by Surgical Science       |
| shall remain the sole property of Surgical Science.                                       |                                                                                                |
|                                                                                           | 3.2  Usage Data. You acknowledge and agree that Surgical Science may derive or create          |
|                                                                                           | data and information about the use of the Software by you and your users ("Usage Data")        |
|                                                                                           | and Surgical Science may use and disclose Usage Data to its third-party service providers      |
|                                                                                           | in order to improve the Software. Personal data related to any identifiable individual is not  |
| collected by Surgical Science.                                                            |                                                                                                |
| 4  SUPPORT SERVICES                                                                       |                                                                                                |
| 4.1  Surgical Science may provide you with support services related to the Software       |                                                                                                |
| ("Support Services"). Use of Support Services is governed by the Surgical Science         |                                                                                                |
|                                                                                           | policies and programs described in the user manual, in "online" documentation, and/or in       |
|                                                                                           | other Surgical Science-provided materials. Any supplemental software provided to you as        |
|                                                                                           | part of the Support Services shall be considered part of the Software and subject to the       |
|                                                                                           | terms and conditions of this Agreement. With respect to technical information you provide      |
| to Surgical Science as part of the Support Services, Surgical Science may use such        |                                                                                                |
| information for its business purposes, including for product support and development.     |                                                                                                |
| Surgical Science will not utilize such technical information in a form that personally    |                                                                                                |
| identifies you.                                                                           |                                                                                                |
| 5  INTEGRITY OF THE SOFTWARE                                                              |                                                                                                |
|                                                                                           | 5.1  You shall not, directly or indirectly in any form or manner, copy, distribute, reproduce, |
| incorporate or allow unauthorized use or access to the Software or modify, decompile,     |                                                                                                |
| reverse engineer, disassemble or otherwise attempt to derive a source code or similar     |                                                                                                |
| information from Software, except as explicitly permitted under this Agreement.           |                                                                                                |
| 5.2  The Software is licensed as a single product. Its component parts may not be         |                                                                                                |
| separated for use on more than one computer.                                              |                                                                                                |

[OCR_TABLE]
ci lV

[OCR_TABLE]
3 OWNERS?

[OCR_TABLE]
Vet VUNCV' |

ee eee oe

[OCR]
Chapter 10 End-User Software License Agreement

3 OWNERSHIP OF SOFTWARE

3.1 Subject to the rights granted to you by this Agreement, you acknowledge that all and
any proprietary rights in the software (including but not limited to copyrights, patents,
trademarks and trade secrets) and in all associated documentation and other material
related to the Software in each case now existing or to be developed by Surgical Science
shall remain the sole property of Surgical Science.

3.2 Usage Data. You acknowledge and agree that Surgical Science may derive or create
data and information about the use of the Software by you and your users ("Usage Data")
and Surgical Science may use and disclose Usage Data to its third-party service providers
in order to improve the Software. Personal data related to any identifiable individual is not
collected by Surgical Science.

4 SUPPORT SERVICES

4.1 Surgical Science may provide you with support services related to the Software
("Support Services"). Use of Support Services is governed by the Surgical Science
policies and programs described in the user manual, in "online" documentation, and/or in
other Surgical Science-provided materials. Any supplemental software provided to you as
part of the Support Services shall be considered part of the Software and subject to the
terms and conditions of this Agreement. With respect to technical information you provide
to Surgical Science as part of the Support Services, Surgical Science may use such
information for its business purposes, including for product support and development.
Surgical Science will not utilize such technical information in a form that personally
identifies you.

5 INTEGRITY OF THE SOFTWARE

5.1 You shall not, directly or indirectly in any form or manner, copy, distribute, reproduce,
incorporate or allow unauthorized use or access to the Software or modify, decompile,
reverse engineer, disassemble or otherwise attempt to derive a source code or similar
information from Software, except as explicitly permitted under this Agreement.

5.2 The Software is licensed as a single product. Its component parts may not be
separated for use on more than one computer.

surgicalscience Page 71


# Page 80

Chapter 10 
 End-User Software License Agreement
 
Page 72
 
5.3  You shall ensure that all copies of and extracts from the Software and its associated 
documentation made or disclosed by you carry Surgical Science’ copyright notice in the 
form shown on the original, or such other copyright notices as Surgical Science may 
specify from time to time and shall ensure that no such notice is deleted. 
6  RIGHT OF ACCESS 
6.1  For the purpose only of verifying your compliance with these conditions, you hereby 
irrevocable grants permission for Surgical Science and its authorized representatives 
during normal business hours to enter the premises from time to time wholly or partly 
occupied by you and in each case there to access, operate, and inspect computer 
equipment and to access, inspect and take copies of documents and records (including 
magnetic and other media). Surgical Science shall exercise this right only for the above 
purpose and shall observe strict confidence in all information which it obtains as a result 
of such inspections except to the extent that disclosure to third parties is necessary for 
the purposes of protecting Surgical Science’ rights in the Software. 
7  WARRANTY AND LIMITATION OF LIABILITY 
7.1  Surgical Science warrants that (i) the Software will perform substantially in 
accordance with the accompanying written materials for a period of ninety (90) days from 
the date of receipt, and (ii) any Support Services provided by Surgical Science shall be 
substantially as described in applicable written materials provided to you by Surgical 
Science, and Surgical Science support engineers will make commercially reasonable 
efforts to solve any problem issues. Some jurisdictions do not allow limitations on duration 
of an implied warranty, so the above limitation may not apply to you. To the extent 
allowed by applicable law, implied warranties on the Software, if any, are limited to ninety 
(90) days. 
The above said warranty is void if failure of the Software has resulted from accident, 
abuse, or misapplication. Any replacement Software will be warranted for the remainder 
of the original warranty period or thirty (30) days, whichever is longer. Neither these 
remedies nor any Support Services offered by Surgical Science are available without 
proof of purchase from an authorized source. 
7.2  To the maximum extent permitted by applicable law, Surgical Science and its 
suppliers disclaim all other warranties and conditions, either express or implied, including, 
but not limited to, implied warranties of fitness for a particular purpose, title, and non-
infringement, with regard to the Software, and the provision of or failure to provide 
Support Services. 


[TABLE]
| Chapter 10                                                                                  | End-User Software License Agreement                                                           |
|:--------------------------------------------------------------------------------------------|:----------------------------------------------------------------------------------------------|
|                                                                                             | 5.3  You shall ensure that all copies of and extracts from the Software and its associated    |
|                                                                                             | documentation made or disclosed by you carry Surgical Science’ copyright notice in the        |
| form shown on the original, or such other copyright notices as Surgical Science may         |                                                                                               |
| specify from time to time and shall ensure that no such notice is deleted.                  |                                                                                               |
| 6  RIGHT OF ACCESS                                                                          |                                                                                               |
|                                                                                             | 6.1  For the purpose only of verifying your compliance with these conditions, you hereby      |
| irrevocable grants permission for Surgical Science and its authorized representatives       |                                                                                               |
| during normal business hours to enter the premises from time to time wholly or partly       |                                                                                               |
| occupied by you and in each case there to access, operate, and inspect computer             |                                                                                               |
|                                                                                             | equipment and to access, inspect and take copies of documents and records (including          |
|                                                                                             | magnetic and other media). Surgical Science shall exercise this right only for the above      |
|                                                                                             | purpose and shall observe strict confidence in all information which it obtains as a result   |
|                                                                                             | of such inspections except to the extent that disclosure to third parties is necessary for    |
| the purposes of protecting Surgical Science’ rights in the Software.                        |                                                                                               |
| 7  WARRANTY AND LIMITATION OF LIABILITY                                                     |                                                                                               |
| 7.1  Surgical Science warrants that (i) the Software will perform substantially in          |                                                                                               |
|                                                                                             | accordance with the accompanying written materials for a period of ninety (90) days from      |
| the date of receipt, and (ii) any Support Services provided by Surgical Science shall be    |                                                                                               |
| substantially as described in applicable written materials provided to you by Surgical      |                                                                                               |
| Science, and Surgical Science support engineers will make commercially reasonable           |                                                                                               |
|                                                                                             | efforts to solve any problem issues. Some jurisdictions do not allow limitations on duration  |
| of an implied warranty, so the above limitation may not apply to you. To the extent         |                                                                                               |
|                                                                                             | allowed by applicable law, implied warranties on the Software, if any, are limited to ninety  |
| (90) days.                                                                                  |                                                                                               |
| The above said warranty is void if failure of the Software has resulted from accident,      |                                                                                               |
|                                                                                             | abuse, or misapplication. Any replacement Software will be warranted for the remainder        |
| of the original warranty period or thirty (30) days, whichever is longer. Neither these     |                                                                                               |
| remedies nor any Support Services offered by Surgical Science are available without         |                                                                                               |
| proof of purchase from an authorized source.                                                |                                                                                               |
| 7.2  To the maximum extent permitted by applicable law, Surgical Science and its            |                                                                                               |
|                                                                                             | suppliers disclaim all other warranties and conditions, either express or implied, including, |
| but not limited to, implied warranties of fitness for a particular purpose, title, and non- |                                                                                               |
| infringement, with regard to the Software, and the provision of or failure to provide       |                                                                                               |
| Support Services.                                                                           |                                                                                               |

[OCR_TABLE]
ci lV

[OCR_TABLE]
Se wu vi lit
documentati
form shown <

[OCR_TABLE]
specify from

[OCR]
Chapter 10 End-User Software License Agreement

5.3 You shall ensure that all copies of and extracts from the Software and its associated
documentation made or disclosed by you carry Surgical Science’ copyright notice in the
form shown on the original, or such other copyright notices as Surgical Science may
specify from time to time and shall ensure that no such notice is deleted.

6 RIGHT OF ACCESS

6.1 For the purpose only of verifying your compliance with these conditions, you hereby
irrevocable grants permission for Surgical Science and its authorized representatives
during normal business hours to enter the premises from time to time wholly or partly
occupied by you and in each case there to access, operate, and inspect computer
equipment and to access, inspect and take copies of documents and records (including
magnetic and other media). Surgical Science shall exercise this right only for the above
purpose and shall observe strict confidence in all information which it obtains as a result
of such inspections except to the extent that disclosure to third parties is necessary for
the purposes of protecting Surgical Science’ rights in the Software.

7 WARRANTY AND LIMITATION OF LIABILITY

7.1 Surgical Science warrants that (i) the Software will perform substantially in
accordance with the accompanying written materials for a period of ninety (90) days from
the date of receipt, and (ii) any Support Services provided by Surgical Science shall be
substantially as described in applicable written materials provided to you by Surgical
Science, and Surgical Science support engineers will make commercially reasonable
efforts to solve any problem issues. Some jurisdictions do not allow limitations on duration
of an implied warranty, so the above limitation may not apply to you. To the extent
allowed by applicable law, implied warranties on the Software, if any, are limited to ninety
(90) days.

The above said warranty is void if failure of the Software has resulted from accident,
abuse, or misapplication. Any replacement Software will be warranted for the remainder
of the original warranty period or thirty (30) days, whichever is longer. Neither these
remedies nor any Support Services offered by Surgical Science are available without
proof of purchase from an authorized source.

7.2 To the maximum extent permitted by applicable law, Surgical Science and its
suppliers disclaim all other warranties and conditions, either express or implied, including,
but not limited to, implied warranties of fitness for a particular purpose, title, and non-
infringement, with regard to the Software, and the provision of or failure to provide
Support Services.

surgicalscience Page 72


# Page 81

Chapter 10 
 End-User Software License Agreement
 
Page 73
 
7.3  To the maximum extent permitted by applicable law, in no event shall Surgical 
Science or its suppliers be liable for any special, incidental, indirect, or consequential 
damages whatsoever (including, without limitation, damages for loss of business profits, 
business interruption or loss of business information) arising out of the use of or inability 
to use the Software or the provision of or failure to provide Support Services. However, if 
you have entered into a Surgical Science Support Services agreement, Surgical Science’ 
entire liability regarding Support Services shall be governed by the terms of that 
agreement. 
7.4  Surgical Science’ entire liability under any provision of this Agreement and your 
exclusive remedy shall be, at Surgical Science’ sole discretion to, either (i) return of the 
amount actually paid by you for the Software, if any, or (ii) repair or replacement of the 
Software that does not meet Surgical Science’ warranty and which is returned to Surgical 
Science with a copy of your receipt. 
8  TERMINATION 
8.1  If this license is a Trial license, you shall be entitled to return the Software to Surgical 
Science on or before Trial Expiry Date specified in the License Key Issue Note and, in that 
event, this Agreement shall then terminate. Unless otherwise agreed under special 
conditions, no license fee or other charges shall be payable by you in respect of the trial. 
8.2  Unless terminated pursuant to 8.3 below this Agreement shall continue until the 
expiry date, if any, specified in the Particulars or the License Key Issue Note. 
8.3  This Agreement may be terminated by Surgical Science at any time by written notice 
of termination: 
8.3.1.  if you shall expressly or impliedly repudiate this license by refusing or threatening 
to refuse to observe any of the conditions to which this license is subject; or 
8.3.2  if you shall fail to make payment of any amount due to and invoiced by Surgical 
Science or to observe any of the conditions to which this license is subject and, after your 
attention has been drawn by notice to such failure, shall fail to remedy the matter to 
Surgical Science's reasonable satisfaction within thirty days of the giving or such notice; 
or 
8.3.3  if you shall have a receiver or administrative receiver or administrator appointed or 
shall enter into liquidation whether compulsory or voluntary or if you or any member of 
your partnership shall be unable to pay its debts as and when they fall due or any 
judgment or execution or other process issued in respect of any judgment against you is 
unsatisfied for fourteen days. 


[TABLE]
| Chapter 10                                                                                 | End-User Software License Agreement                                                               |
|:-------------------------------------------------------------------------------------------|:--------------------------------------------------------------------------------------------------|
| 7.3  To the maximum extent permitted by applicable law, in no event shall Surgical         |                                                                                                   |
| Science or its suppliers be liable for any special, incidental, indirect, or consequential |                                                                                                   |
|                                                                                            | damages whatsoever (including, without limitation, damages for loss of business profits,          |
|                                                                                            | business interruption or loss of business information) arising out of the use of or inability     |
|                                                                                            | to use the Software or the provision of or failure to provide Support Services. However, if       |
|                                                                                            | you have entered into a Surgical Science Support Services agreement, Surgical Science’            |
| entire liability regarding Support Services shall be governed by the terms of that         |                                                                                                   |
| agreement.                                                                                 |                                                                                                   |
| 7.4  Surgical Science’ entire liability under any provision of this Agreement and your     |                                                                                                   |
|                                                                                            | exclusive remedy shall be, at Surgical Science’ sole discretion to, either (i) return of the      |
|                                                                                            | amount actually paid by you for the Software, if any, or (ii) repair or replacement of the        |
|                                                                                            | Software that does not meet Surgical Science’ warranty and which is returned to Surgical          |
| Science with a copy of your receipt.                                                       |                                                                                                   |
| 8  TERMINATION                                                                             |                                                                                                   |
|                                                                                            | 8.1  If this license is a Trial license, you shall be entitled to return the Software to Surgical |
|                                                                                            | Science on or before Trial Expiry Date specified in the License Key Issue Note and, in that       |
| event, this Agreement shall then terminate. Unless otherwise agreed under special          |                                                                                                   |
|                                                                                            | conditions, no license fee or other charges shall be payable by you in respect of the trial.      |
| 8.2  Unless terminated pursuant to 8.3 below this Agreement shall continue until the       |                                                                                                   |
| expiry date, if any, specified in the Particulars or the License Key Issue Note.           |                                                                                                   |
|                                                                                            | 8.3  This Agreement may be terminated by Surgical Science at any time by written notice           |
| of termination:                                                                            |                                                                                                   |
|                                                                                            | 8.3.1.  if you shall expressly or impliedly repudiate this license by refusing or threatening     |
| to refuse to observe any of the conditions to which this license is subject; or            |                                                                                                   |
| 8.3.2  if you shall fail to make payment of any amount due to and invoiced by Surgical     |                                                                                                   |
|                                                                                            | Science or to observe any of the conditions to which this license is subject and, after your      |
| attention has been drawn by notice to such failure, shall fail to remedy the matter to     |                                                                                                   |
|                                                                                            | Surgical Science's reasonable satisfaction within thirty days of the giving or such notice;       |
| or                                                                                         |                                                                                                   |
|                                                                                            | 8.3.3  if you shall have a receiver or administrative receiver or administrator appointed or      |
|                                                                                            | shall enter into liquidation whether compulsory or voluntary or if you or any member of           |
| your partnership shall be unable to pay its debts as and when they fall due or any         |                                                                                                   |
|                                                                                            | judgment or execution or other process issued in respect of any judgment against you is           |
| unsatisfied for fourteen days.                                                             |                                                                                                   |

[OCR_TABLE]
7 a ee eee,

[OCR_TABLE]
METAMELY! TV

[OCR_TABLE]
72 Tothen

[OCR_TABLE]
tet! De

business inte

[OCR_TABLE]
to use the S¢

[OCR]
Chapter 10 End-User Software License Agreement

7.3 To the maximum extent permitted by applicable law, in no event shall Surgical
Science or its suppliers be liable for any special, incidental, indirect, or consequential
damages whatsoever (including, without limitation, damages for loss of business profits,
business interruption or loss of business information) arising out of the use of or inability
to use the Software or the provision of or failure to provide Support Services. However, if
you have entered into a Surgical Science Support Services agreement, Surgical Science’
entire liability regarding Support Services shall be governed by the terms of that
agreement.

7.4 Surgical Science’ entire liability under any provision of this Agreement and your
exclusive remedy shall be, at Surgical Science’ sole discretion to, either (i) return of the
amount actually paid by you for the Software, if any, or (ii) repair or replacement of the
Software that does not meet Surgical Science’ warranty and which is returned to Surgical
Science with a copy of your receipt.

8 TERMINATION

8.1 If this license is a Trial license, you shall be entitled to return the Software to Surgical
Science on or before Trial Expiry Date specified in the License Key Issue Note and, in that
event, this Agreement shall then terminate. Unless otherwise agreed under special
conditions, no license fee or other charges shall be payable by you in respect of the trial.

8.2 Unless terminated pursuant to 8.3 below this Agreement shall continue until the
expiry date, if any, specified in the Particulars or the License Key Issue Note.

8.3 This Agreement may be terminated by Surgical Science at any time by written notice
of termination:

8.3.1. if you shall expressly or impliedly repudiate this license by refusing or threatening
to refuse to observe any of the conditions to which this license is subject; or

8.3.2 if you shall fail to make payment of any amount due to and invoiced by Surgical
Science or to observe any of the conditions to which this license is subject and, after your
attention has been drawn by notice to such failure, shall fail to remedy the matter to
Surgical Science's reasonable satisfaction within thirty days of the giving or such notice;
or

8.3.3 if you shall have a receiver or administrative receiver or administrator appointed or
shall enter into liquidation whether compulsory or voluntary or if you or any member of
your partnership shall be unable to pay its debts as and when they fall due or any
judgment or execution or other process issued in respect of any judgment against you is
unsatisfied for fourteen days.

surgicalscience Page 73


# Page 82

Chapter 10 
 End-User Software License Agreement
 
Page 74
 
8.4  On expiry, surrender or other termination of this Agreement, however such 
termination may arise, you shall cease to load, store, copy or use the Software, shall 
delete the Software from the any computers on which the Software is installed or copied 
and at Surgical Science's option shall either surrender the Software and all documentation 
and other related materials to Surgical Science or shall destroy the Software with all 
documentation and other related materials and deliver to Surgical Science a certificate of 
comprehensive destruction. You shall continue after termination to observe and enforce 
confidence and secrecy in respect of the Software and its documentation and related 
materials for the benefit of Surgical Science, and however termination may occur it shall 
not prejudice any right of action or remedy which may have accrued prior to termination. 
9.  MISCELLANEOUS 
9.1  This Agreement is governed by Swedish law and any disputes arising out of or in 
connection to this Agreement shall be submitted to the exclusive jurisdiction of the 
Swedish courts. 
9.2  The headings to these Conditions are included for convenience only and do not 
affect their interpretation. 
9.3  Should you have any questions concerning this Agreement, or if you desire to contact 
Surgical Science for any reason, please contact Surgical Science (write or e-mail): 
Surgical Science Sweden AB, Drakegatan 7, SE-412 50 Göteborg, Sweden, 
[info@surgical-science.com]. 
 
 


[TABLE]
| Chapter 10                                                                             | End-User Software License Agreement                                                        |
|:---------------------------------------------------------------------------------------|:-------------------------------------------------------------------------------------------|
| 8.4  On expiry, surrender or other termination of this Agreement, however such         |                                                                                            |
| termination may arise, you shall cease to load, store, copy or use the Software, shall |                                                                                            |
|                                                                                        | delete the Software from the any computers on which the Software is installed or copied    |
|                                                                                        | and at Surgical Science's option shall either surrender the Software and all documentation |
| and other related materials to Surgical Science or shall destroy the Software with all |                                                                                            |
|                                                                                        | documentation and other related materials and deliver to Surgical Science a certificate of |
|                                                                                        | comprehensive destruction. You shall continue after termination to observe and enforce     |
| confidence and secrecy in respect of the Software and its documentation and related    |                                                                                            |
|                                                                                        | materials for the benefit of Surgical Science, and however termination may occur it shall  |
|                                                                                        | not prejudice any right of action or remedy which may have accrued prior to termination.   |
| 9.  MISCELLANEOUS                                                                      |                                                                                            |
| 9.1  This Agreement is governed by Swedish law and any disputes arising out of or in   |                                                                                            |
| connection to this Agreement shall be submitted to the exclusive jurisdiction of the   |                                                                                            |
| Swedish courts.                                                                        |                                                                                            |
| 9.2  The headings to these Conditions are included for convenience only and do not     |                                                                                            |
| affect their interpretation.                                                           |                                                                                            |
|                                                                                        | 9.3  Should you have any questions concerning this Agreement, or if you desire to contact  |
| Surgical Science for any reason, please contact Surgical Science (write or e-mail):    |                                                                                            |
| Surgical Science Sweden AB, Drakegatan 7, SE-412 50 Göteborg, Sweden,                  |                                                                                            |
| [info@surgical-science.com].                                                           |                                                                                            |

[OCR_TABLE]
Chapter 10

[OCR_TABLE]
0.4 Ul CXpll

[OCR]
Chapter 10 End-User Software License Agreement

8.4 On expiry, surrender or other termination of this Agreement, however such
termination may arise, you shall cease to load, store, copy or use the Software, shall
delete the Software from the any computers on which the Software is installed or copied
and at Surgical Science's option shall either surrender the Software and all documentation
and other related materials to Surgical Science or shall destroy the Software with all
documentation and other related materials and deliver to Surgical Science a certificate of
comprehensive destruction. You shall continue after termination to observe and enforce
confidence and secrecy in respect of the Software and its documentation and related
materials for the benefit of Surgical Science, and however termination may occur it shall
not prejudice any right of action or remedy which may have accrued prior to termination.

9. MISCELLANEOUS

9.1 This Agreement is governed by Swedish law and any disputes arising out of or in
connection to this Agreement shall be submitted to the exclusive jurisdiction of the
Swedish courts.

9.2 The headings to these Conditions are included for convenience only and do not
affect their interpretation.

9.3 Should you have any questions concerning this Agreement, or if you desire to contact
Surgical Science for any reason, please contact Surgical Science (write or e-mail):
Surgical Science Sweden AB, Drakegatan 7, SE-412 50 Géteborg, Sweden,
[info@surgical-science.com].

surgicalscience Page 74


# Page 83

Index
 
Page 75
 
Index 
A 
Accessing a module or course • 29 
easy access buttons • 30 
Adjusting height • 14 
Adjusting platform height • 14 
Aligning the scopes 
resectoscope • 50 
Applying electricity • 46, 50 
B 
Benchmarks 
report graph • 65 
report rating scale • 65 
report scoreboard • 63 
Bipolar loop • 45, 50 
Bookmarking reports • 56 
C 
Camera • 19 
positioning the camera • 52 
Camera angles • 37 
Changing camera angle • 37 
Clear View • 42, 48 
Clearing the simulation view • 42, 48 
Cloud configuration • 28 
Complications • 61 
Connecting the scope • 9 
Consecutive times • 64 
Cross section view • 41 
D 
Diagnostic Hysteroscopy display mode • 
34 
general buttons • 41 
Diagnostic Hysteroscopy module • 21 
E 
Elapsed time indicator • 36 
Enabling complications • 61 
ENDO Mentor Suite 
HYST Mentor platform • 5 
Endoscopic View • 36 
Exporting performance results • 66 
External View • 39 
controls • 39, 45 
F 
Fluid management system • 48 
Focus wheel • 52 
Foot switch • 16, 17 
G 
General buttons • 41 
Getting started • 24 
GI-BRONCH interchangeable panel • 8 
H 
Hardware • 4 
Height elevation mechanism • 14 
How to use the simulator 
HYST Mentor • 34 
HYST display mode 


[TABLE]
|                                       | Index                                  |
|:--------------------------------------|:---------------------------------------|
|                                       |                                        |
| Index                                 | D                                      |
|                                       | Diagnostic Hysteroscopy display mode • |
|                                       | 34                                     |
| A                                     |                                        |
|                                       | general buttons • 41                   |
|                                       | Diagnostic Hysteroscopy module • 21    |
| Accessing a module or course • 29     |                                        |
| easy access buttons • 30              |                                        |
| Adjusting height • 14                 |                                        |
|                                       | E                                      |
| Adjusting platform height • 14        |                                        |
| Aligning the scopes                   |                                        |
|                                       | Elapsed time indicator • 36            |
| resectoscope • 50                     |                                        |
|                                       | Enabling complications • 61            |
| Applying electricity • 46, 50         |                                        |
|                                       | ENDO Mentor Suite                      |
|                                       | HYST Mentor platform • 5               |
|                                       | Endoscopic View • 36                   |
| B                                     |                                        |
|                                       | Exporting performance results • 66     |
|                                       | External View • 39                     |
| Benchmarks                            |                                        |
|                                       | controls • 39, 45                      |
| report graph • 65                     |                                        |
| report rating scale • 65              |                                        |
| report scoreboard • 63                |                                        |
| Bipolar loop • 45, 50                 | F                                      |
| Bookmarking reports • 56              |                                        |
|                                       | Fluid management system • 48           |
|                                       | Focus wheel • 52                       |
| C                                     | Foot switch • 16, 17                   |
| Camera • 19                           |                                        |
| positioning the camera • 52           | G                                      |
| Camera angles • 37                    |                                        |
| Changing camera angle • 37            | General buttons • 41                   |
| Clear View • 42, 48                   | Getting started • 24                   |
| Clearing the simulation view • 42, 48 | GI-BRONCH interchangeable panel • 8    |
| Cloud configuration • 28              |                                        |
| Complications • 61                    |                                        |
| Connecting the scope • 9              | H                                      |
| Consecutive times • 64                |                                        |
|                                       | Hardware • 4                           |
| Cross section view • 41               |                                        |
|                                       | Height elevation mechanism • 14        |
|                                       | How to use the simulator               |
|                                       | HYST Mentor • 34                       |
|                                       | HYST display mode                      |
|                                       | Page 75                                |

[OCR]
Index

| Index

A

Accessing a module or course « 29
easy access buttons « 30
Adjusting height « 14
Adjusting platform height « 14
Aligning the scopes
resectoscope « 50
Applying electricity « 46, 50

B

Benchmarks

report graph « 65

report rating scale « 65

report scoreboard « 63
Bipolar loop « 45, 50
Bookmarking reports « 56

c

Camera « 19

positioning the camera e 52
Camera angles « 37
Changing camera angle « 37
Clear View « 42, 48
Clearing the simulation view « 42, 48
Cloud configuration « 28
Complications « 61
Connecting the scope e 9
Consecutive times « 64
Cross section view « 41

D

Diagnostic Hysteroscopy display mode e
34
general buttons « 41

Diagnostic Hysteroscopy module « 21

E

Elapsed time indicator « 36
Enabling complications « 61
ENDO Mentor Suite

HYST Mentor platform « 5
Endoscopic View « 36
Exporting performance results « 66
External View « 39

controls « 39, 45

F

Fluid management system e« 48
Focus wheel e 52
Foot switch e 16, 17

G

General buttons « 41
Getting started « 24
GI-BRONCH interchangeable panel « 8

H

Hardware e 4
Height elevation mechanism e 14
How to use the simulator
HYST Mentor « 34
HYST display mode

surgicalscience

Page 75


# Page 84

Index
 
Page 76
 
diagnostic hysteroscopy • 34 
therapeutic hysteroscopy • 44 
HYST interchangeable panel • 6 
HYST Mentor 
how to use • 34 
Hysteroscopic Myomectomy module • 
22 
Hysteroscopic Polypectomy module • 22 
I 
Inflow valve • 38 
Inserting the camera • 52 
L 
Lateral working position • 12 
Logging into MentorLearn • 27 
M 
MentorLearn 
Library screen • 30 
overview • 25 
patient file • 32 
starting case or task • 31 
workflow • 25 
Modality extensions • 10 
Monopolar loop • 45, 50 
O 
Opening a module • 31 
Outflow valve 
for flow of fluids • 38 
P 
Panning 3D Map • 40 
Pathology progress bar • 47 
Patient Discomfort scale • 43 
Patient file • 32 
Positioning the camera • 52 
R 
Reports with benchmarks 
learning curve graph • 65 
rating scale • 65 
scoreboard • 63 
Resecting 
applying electricity • 46, 50 
areas to resect • 47 
Resection map • 46 
Resectoscope 
aligning • 50 
camera • 19 
Resectoscope • 18 
Resectoscope view • 36 
Resetting 3D Map • 40 
Rotating 3D Map • 40 
S 
Scope 
connectors • 10 
hangers • 9 
Scopes • 17 
Screen display layout • 35 
Selecting tools • 45 
Setting the pump pressure. • 48 
Simulation aids • 42, 46 
Simulation display • 34, 44 
Simulator 
hardware • 4 


[TABLE]
| diagnostic hysteroscopy • 34          |                               |
|:--------------------------------------|:------------------------------|
|                                       | P                             |
| therapeutic hysteroscopy • 44         |                               |
| HYST interchangeable panel • 6        |                               |
|                                       | Panning 3D Map • 40           |
| HYST Mentor                           |                               |
|                                       | Pathology progress bar • 47   |
| how to use • 34                       |                               |
|                                       | Patient Discomfort scale • 43 |
| Hysteroscopic Myomectomy module •     |                               |
|                                       | Patient file • 32             |
| 22                                    |                               |
|                                       | Positioning the camera • 52   |
| Hysteroscopic Polypectomy module • 22 |                               |

[TABLE]
|                               | R                             |
|:------------------------------|:------------------------------|
| I                             |                               |
|                               | Reports with benchmarks       |
| Inflow valve • 38             |                               |
|                               | learning curve graph • 65     |
| Inserting the camera • 52     |                               |
|                               | rating scale • 65             |
|                               | scoreboard • 63               |
|                               | Resecting                     |
| L                             |                               |
|                               | applying electricity • 46, 50 |
|                               | areas to resect • 47          |
| Lateral working position • 12 |                               |
|                               | Resection map • 46            |
| Logging into MentorLearn • 27 |                               |
|                               | Resectoscope                  |
|                               | aligning • 50                 |
|                               | camera • 19                   |
| M                             |                               |
|                               | Resectoscope • 18             |

[OCR_TABLE]
ST Men
10W to U:

[OCR]
Index

diagnostic hysteroscopy « 34
therapeutic hysteroscopy « 44
HYST interchangeable panel « 6
HYST Mentor
how to use « 34
Hysteroscopic Myomectomy module «
22
Hysteroscopic Polypectomy module e 22

/

Inflow valve « 38
Inserting the camera « 52

L

Lateral working position « 12
Logging into MentorLearn e 27

M

MentorLearn
Library screen « 30
overview e 25
patient file « 32
starting case or task « 31
workflow « 25
Modality extensions e 10
Monopolar loop « 45, 50

oO

Opening a module « 31
Outflow valve
for flow of fluids » 38

P

Panning 3D Map e 40
Pathology progress bar « 47
Patient Discomfort scale « 43
Patient file * 32

Positioning the camera e 52

R

Reports with benchmarks
learning curve graph e 65
rating scale « 65
scoreboard « 63

Resecting
applying electricity « 46, 50
areas to resect « 47

Resection map « 46

Resectoscope
aligning « 50
camera e 19

Resectoscope « 18

Resectoscope view e 36

Resetting 3D Map « 40

Rotating 3D Map e 40

Ss

Scope

connectors e 10

hangers « 9
Scopes « 17
Screen display layout « 35
Selecting tools « 45
Setting the pump pressure. « 48
Simulation aids « 42, 46
Simulation display « 34, 44
Simulator

hardware e 4

surgicalscience

Page 76


# Page 85

Index
 
Page 77
 
Single-case report • 56 
Snapshots • 52 
viewing • 58 
Starting a simulation case or task • 31 
Superior working position • 12 
Switching interchangeable panels • 8 
T 
Technical support • 68 
Therapeutic Hysteroscopy display mode 
• 44 
Tool tray • 15 
resectoscope • 16 
Tools 
selecting • 50 
selecting • 45 
working with resectoscope • 49 
Tools menu • 49 
options • 45 
Total score • 63, 64 
Tracking total inflow • 48 
Training with MentorLearn within a 
module or course • 29 
Turning on the simulator • 14 
U 
URO interchangeable panel • 7 
Uterine deficit status • 48 
V 
Vaginal region • 34 
Videos • 59 
Viewing 
additional information in report • 58 
performance reports • 55 
snapshots • 58 
videos • 59 
Virtual instructor • 41 
Visualization progress bar • 42 
W 
Workflow • 24 
Working 
locally • 28 
on the cloud site • 28 
Working locally configuration • 28 
Working positions • 12 
Z 
Zoom wheel • 53 
Zooming 
3D Map • 40 
 


[TABLE]
| Single-case report • 56                 | videos • 59                     |
|:----------------------------------------|:--------------------------------|
| Snapshots • 52                          | Virtual instructor • 41         |
| viewing • 58                            | Visualization progress bar • 42 |
| Starting a simulation case or task • 31 |                                 |
| Superior working position • 12          |                                 |
| Switching interchangeable panels • 8    | W                               |

[OCR]
Index

Single-case report « 56
Snapshots e 52

viewing « 58
Starting a simulation case or task « 31
Superior working position « 12
Switching interchangeable panels « 8

a

Technical support « 68
Therapeutic Hysteroscopy display mode
244

Tool tray « 15

resectoscope « 16

Tools

selecting * 50

selecting « 45

working with resectoscope « 49
Tools menu e 49

options « 45

Total score « 63, 64

Tracking total inflow « 48

Training with MentorLearn within a
module or course « 29

Turning on the simulator « 14

U

URO interchangeable panel « 7
Uterine deficit status « 48

V

Vaginal region « 34

Videos « 59

Viewing
additional information in report « 58
performance reports « 55
snapshots « 58

videos « 59
Virtual instructor « 41
Visualization progress bar « 42

WwW

Workflow « 24
Working
locally * 28
on the cloud site « 28
Working locally configuration « 28
Working positions « 12

Zz

Zoom wheel e 53
Zooming
3D Map e 40

surgicalscience

Page 77