

# Page 1

 
 
 
ENDO MENTOR SUITE® 
Service Guide 
 
 
 
November 2024 
 
 
04-ENDOSG-W1124-008 
 
 
 


[TABLE]
| E                   |
| NDO MENTOR SUITE®   |
|:--------------------|
| Service Guide       |
| N                   |
| ovember 2024        |
| 0                   |
|                     |
| 4-ENDOSG-W1124-008  |

[OCR]
ENDO MENTOR SUITE®

Service Guide

November 2024

04-ENDOSG-W1124-008

surgicalscience


# Page 2

Contents
 
Page ii
 
Contents 
 
Chapter 1 
Safety Precautions .................................................................. 1 
Chapter 2 
Introduction ............................................................................. 4 
About this guide .................................................................................................................. 4 
Chapter 3 
Product Description and Hardware Specifications ............. 5 
Simulator specifications ..................................................................................................... 7 
GI-BRONCH interchangeable cartridge ........................................................................ 9 
HYST interchangeable panel ......................................................................................... 10 
URO interchangeable panel........................................................................................... 11 
Scope hanger.................................................................................................................. 12 
Connecting the scope .................................................................................................... 14 
Extensions ....................................................................................................................... 15 
Height elevation mechanism ......................................................................................... 16 
Turning on the simulator ................................................................................................ 17 
Tool tray .......................................................................................................................... 17 
Foot switch ..................................................................................................................... 21 
Available scopes ................................................................................................................ 21 
GI scopes ........................................................................................................................ 21 
BRONCH scope ............................................................................................................. 24 
URO scopes ................................................................................................................... 25 


[TABLE]
| Contents   |                                                                                                                                         |
|:-----------|:----------------------------------------------------------------------------------------------------------------------------------------|
| C          | Safety Precautions .................................................................. 1                                                 |
| hapter 1   |                                                                                                                                         |
| Chapter 2  | Introduction ............................................................................. 4                                            |
|            | About this guide .................................................................................................................. 4   |
| Chapter 3  | Product Description and Hardware Specifications ............. 5                                                                         |
|            | Simulator specifications ..................................................................................................... 7        |
|            | GI-BRONCH interchangeable cartridge ........................................................................ 9                          |
|            | HYST interchangeable panel ......................................................................................... 10                 |
|            | URO interchangeable panel........................................................................................... 11                 |
|            | Scope hanger.................................................................................................................. 12       |
|            | Connecting the scope .................................................................................................... 14            |
|            | Extensions ....................................................................................................................... 15   |
|            | Height elevation mechanism ......................................................................................... 16                 |
|            | Turning on the simulator ................................................................................................ 17            |
|            | Tool tray .......................................................................................................................... 17 |
|            | Foot switch ..................................................................................................................... 21    |
|            | Available scopes ................................................................................................................ 21    |
|            | GI scopes ........................................................................................................................ 21   |
|            | BRONCH scope ............................................................................................................. 24           |
|            | URO scopes ................................................................................................................... 25       |

[OCR]
Contents

| Contents

Chapter 1 Safety Precautions ....... eeeeesescesesseesececseeeeeseseeceseeaeeneeneenes 1
Chapter 2 — INTFOGUCTION o.oo. eee ee eeeeeseceeeceseeeseceseeeseeeaeceaeeeaeeeaeceaeeeaeenaeeeee 4
ADOUt thiS QUIDE occ eeeeeeeeeseesceeeseeaceeeseeseseeseeseseesecsesaesecsceasseesesaesessceaceacaeeaseeseeeaesaeaes 4
Chapter 3. Product Description and Hardware Specifications ............. 5
Simulator SPeCIFICATIONS ..... eee eset eeeseeseeeeseeseeeesesaeseeseeseeaesecseceeseesesaeseeseeaceaeaeeaseesseeaeaeaes 7
GI-BRONCH interchangeable Cartridge 0.0... eee eeeeeseeseesceeceeesceecseeseseeseeseeecseeaeeaseees 9
HYST interchangeable panel..........csescsecsseseeesesseeeeseesceecseeseeecsesseeeeeeseeseeecseeeeeeeseeaeee 10
URO interchangeable Panel... eesesesecsseeeeesesseeeeeesceecseeeeeececseeeeeeseeaeeecseeeseesseeeeee 11
SCOPE NANGEM......eeeseeesescescesceecseeeesecsesseseesceseacsecseeecseesesseseeseeacacseeseeessesaeeeeseeaeeaseeeateess 12
CONNECTING the SCOPE... ee ecseneeeesetseeseseescesesecseeecseeseseeseesceacsecseceeeessesaeeaeseeseeaceeeateese 14
EXteNSiONS ...... ccc ecsececeesescsscscecseecessesesssscscsesssessesessessscsesscesessesssessssesseesessesesesesseeaeese 15
Height elevation MECHANISM...........seseeseeeeseeseeeeseeseeeescescccseeseeecseeaeeaeseeseeaeesseeeeeeeaeeaeee 16

Turning on the simulator...

TOOL tray oc eeeecesesceesesseeseesscsecssccsecsecsseeseessessscsecesecsesseeesecseseeecsscsesesecseseseesesaeseeseaseneeeaeegs 17
FOOt SWITCH oo. cece ceec cece ceescseseceescseseseescsesssesscsesssssscsesssesessesseessesesseesecsesseeseeeeeaeeee 21
Available SCOPES .......ceeeecescsseeeceeescecescescsecsecseeesseeaeeacscesceacsacseeaeecsesaeeassceaceasieeaeeeeeeeaeeatee 21
GI SCOPES oe. eeeeeseeeeeseesceccscesseccsecseseescescsacseeseacscesesecseescacsceseeaceecsecsesaesesaesaeseeaeeaeeeeaeees® 21
BRONCH SCODG 1.0... .eecessescseeseeeeeeeseesescesceacuccsceassecsecaeseeseesceacsecseeessesaesaesaeseeaeaeseeeseesseeass 24
URO SCOPES .....eeeeeescscesceceseeseeeeseesessesceseesesecseeeesecsecaesaescescsacsecaeeessessesaesaesceaceasseeeseesseeats 25

surgicalscience Page ii


# Page 3

Contents
 
Page iii
 
HYST Mentor and TURP module scope ...................................................................... 28 
Auxiliary tools and connectors ........................................................................................ 30 
Master Tool .................................................................................................................... 30 
GI wires ........................................................................................................................... 31 
URO tools ........................................................................................................................ 31 
BRONCH tools ................................................................................................................ 31 
Chapter 4 
Unpacking and Assembly..................................................... 34 
Unpacking instructions ..................................................................................................... 34 
Unpacking the crate ...................................................................................................... 34 
Setup instructions ............................................................................................................. 40 
Chapter 5 
Calibration ............................................................................. 46 
Performing calibration ...................................................................................................... 46 
GI Mentor calibration .................................................................................................... 47 
BRONCH Mentor calibration ......................................................................................... 60 
URO Mentor calibration ................................................................................................ 66 
TURP modules calibration ............................................................................................ 75 
HYST Mentor calibration .............................................................................................. 84 
Chapter 6 
Troubleshooting .................................................................... 94 
Chapter 7 
Technical Support ................................................................ 101 
SURGICAL SCIENCE SUPPORT POLICY .................................................................... 101 


[TABLE]
|           | Contents                                                                                                                                |
|:----------|:----------------------------------------------------------------------------------------------------------------------------------------|
|           | HYST Mentor and TURP module scope ...................................................................... 28                             |
|           | Auxiliary tools and connectors ........................................................................................ 30              |
|           | Master Tool .................................................................................................................... 30     |
|           | GI wires ........................................................................................................................... 31 |
|           | URO tools ........................................................................................................................ 31   |
|           | BRONCH tools ................................................................................................................ 31        |
| Chapter 4 | Unpacking and Assembly..................................................... 34                                                          |
|           | Unpacking instructions ..................................................................................................... 34         |
|           | Unpacking the crate ...................................................................................................... 34           |
|           | Setup instructions ............................................................................................................. 40     |
| Chapter 5 | Calibration ............................................................................. 46                                            |
|           | Performing calibration ...................................................................................................... 46        |
|           | GI Mentor calibration .................................................................................................... 47           |
|           | BRONCH Mentor calibration ......................................................................................... 60                  |
|           | URO Mentor calibration ................................................................................................ 66              |
|           | TURP modules calibration ............................................................................................ 75                |
|           | HYST Mentor calibration .............................................................................................. 84               |
| Chapter 6 | Troubleshooting .................................................................... 94                                                 |
| Chapter 7 | Technical Support ................................................................ 101                                                  |
|           | SURGICAL SCIENCE SUPPORT POLICY .................................................................... 101                                |

[OCR]
Contents

HYST Mentor and TURP MOdule SCOPE... eeeeseeeseeeesceecseeeceecseeseeeeseeseeecseeeeeeeseeaes 28
Auxiliary tools ANA CONNECHOSS .......eeeeseeceecsseseseescesceecscesceesseeseeaeeeseescsecaceaceeseeeeeeeeseeaes 30

Master TOO]... ccccecsecscescsesecssscsesscsescsesssscscsesssesscsesssesscsesseessssessessessesseesessesasesessssaegs 30

Gl wires

URO tOOIS wee cecsececeescsesssecscsessceesesesesecscsessecscsesscsescsessseescsssesensesesseesessssseesessesaeeee 31

BRONCH tol s ....... ccc ccssceecsscecscsesscecsesesseesscsesseesscsesssesecsesssesscsesssesessesssesessesseesesseeseeee 31

Chapter 4 Unpacking and Assembly

Unpacking instructions... eeseecsecseeeeeeceeeseseeseeseeecsecseeeesecsesaeseeseeaeacsecseeesesseeeeseeaees 34
Unpacking the Crate... eee esessesseeecscesseecseeseeecsecseseeseesceacsecaeeeeeeseseeeaeseeaeeaeseeeseesseeats 34
S@tUP INSTFUCTIONS .... eee eteeeeeeeseeseseescescsecseeneseesesaeseescacuacsecaeeessessesassaeaceacasseeaeeeeseeaes 40
Chapter 5 == Calibration wo... eee eeccsceeseceseeeseesseceseeescesseceaeeeaeeseeeeeeseeeaees 46
Performing Calibration ....... eee seseesseecseeseeeceeeseseescesceeesecseeeesessesaeeeseeacacseeaeeesseseeeaeseeaees 46
GI Mentor Calibration oo... cece cecesenscececsessessesesceseesessceneesesssesecsesssesessesaeeneneees 47
BRONCH Mentor Calibration... ccc cece cececeesesscesscsesssesscsesssesessesssesessesseeseesenaegs 60
URO Mentor Calibration oo... cece cece ceescsesececscsesssesscseesesscsesssssessesssesessesseeseneesaegs 66
TURP Modules Calibration oo... eee ees ce ceeenececeesessceceesesceseesesesesecsessesesseseeeneeeees 75

HYST Mentor calibration

Chapter 6 = TroubD@SNOOtING ........ eee eeeceeeeeesceeeeceseeesceeseeeaeeeseeeeeeeeeeeeaees 94
Chapter 7 = Technical SUPPOF th... eee eeeeeeeeeceneeeeeeeeeeseeeseeeeeeeeeeeaes 101
SURGICAL SCIENCE SUPPORT POLICY .....ssessssssssssssssseeesuscessneecsneeesnscesnscersneensneessnecs 101

surgicalscience Page iii


# Page 4

Contents
 
Page iv
 
Surgical Science Call Center ....................................................................................... 101 
Chapter 8 
End-User Software License Agreement ........................... 102 
ENDO Mentor Suite® .................................................................................................... 102 
1  EXTENT OF LICENSE ............................................................................................... 102 
2  CONFIDENCE OF THE SOFTWARE AND COPYRIGHT ......................................... 103 
3  OWNERSHIP OF SOFTWARE ................................................................................. 104 
4  SUPPORT SERVICES ............................................................................................... 104 
5  INTEGRITY OF THE SOFTWARE ............................................................................ 105 
6  RIGHT OF ACCESS .................................................................................................. 105 
7  WARRANTY AND LIMITATION OF LIABILITY ........................................................ 106 
8  TERMINATION ..........................................................................................................107 
9.  MISCELLANEOUS ................................................................................................... 108 
Index ............................................................................................................ 109 
 


[TABLE]
|                                                                                                                        | Contents                                                                                                                     |
|:-----------------------------------------------------------------------------------------------------------------------|:-----------------------------------------------------------------------------------------------------------------------------|
|                                                                                                                        | Surgical Science Call Center ....................................................................................... 101     |
| Chapter 8                                                                                                              | End-User Software License Agreement ........................... 102                                                          |
|                                                                                                                        | ENDO Mentor Suite® .................................................................................................... 102  |
|                                                                                                                        | 1  EXTENT OF LICENSE ............................................................................................... 102     |
|                                                                                                                        | 2  CONFIDENCE OF THE SOFTWARE AND COPYRIGHT ......................................... 103                                    |
|                                                                                                                        | 3  OWNERSHIP OF SOFTWARE ................................................................................. 104               |
|                                                                                                                        | 4  SUPPORT SERVICES ............................................................................................... 104      |
|                                                                                                                        | 5  INTEGRITY OF THE SOFTWARE ............................................................................ 105                |
|                                                                                                                        | 6  RIGHT OF ACCESS .................................................................................................. 105    |
|                                                                                                                        | 7  WARRANTY AND LIMITATION OF LIABILITY ........................................................ 106                         |
|                                                                                                                        | 8  TERMINATION ..........................................................................................................107 |
|                                                                                                                        | 9.  MISCELLANEOUS ................................................................................................... 108    |
| Index ............................................................................................................ 109 |                                                                                                                              |

[OCR]
Contents

Surgical Science Call Center... ee cessesesscescescsecseeeceecseseeeeesceaceecsecaeeeeseseeeaeeeeseeaeeees 101
Chapter 8 End-User Software License Agreemenrt.............cceeeeeeees 102
ENDO Mentor Suite? cece cescenecececsesececscsesscessssesssesessesssesessesssesessesseeseseeegs 102
1 EXTENT OF LICENSE... ceeecssesceceseesessesceaceecsecaeeecsecsesaeseesceaceacsecaeeesseeaesaeearseeacees 102
2 CONFIDENCE OF THE SOFTWARE AND COPYRIGHT..........cceeeseeseeseseeteeeeteeneeees 103
3 OWNERSHIP OF SOFTWARE ........cccsssescscesseseeecsesseseescesceecsecseeeeseesesaeeeseeaceeeseeateass 104

4 SUPPORT SERVICES

5 INTEGRITY OF THE SOFTWARE ....cccssccssesssscssecsssssssecssecssecssecssecssecsseceseceneeeseeesseeses 105
6 RIGHT OF ACCESS....secssessssecsssssssccsessssecssecsnecssecsuecsuscesscssscsssesssecsnecsucesuessneceseeessenses 105
7 WARRANTY AND LIMITATION OF LIABILITY ....cc.ssccssesssesssecsssscstecssccssecssecsseceneeeses 106
& TERMINATION ......csccsssssssssssssssecssecssecssecssecssecsucesscsssccuscessessuecsuesssecsuecssecsuessseceseeaseees 107
9. MISCELLANEOUS. .....cccssssssecssesssssssscsssecssecsnecssecsuecsuscesscesscesscessecsuecauecsuessneceseeenenses 108
MINOX oo. eeeeseeececseccescesseeesecesecesecsaecaeceseceaeceaeseaeceaeceseeeaeceaeceaeseaeceaeeeaeeeaeeeaeesaes 109

surgicalscience

Page iv


# Page 5

Figures
 
Page v 
 
Figures 
 
Figure 3-1: ENDO Mentor Suite ............................................................................................. 6 
Figure 3-2: GI-BRONCH interchangeable cartridge – lower orifice selected ................... 9 
Figure 3-3: HYST interchangeable cartridge ...................................................................... 10 
Figure 3-4: URO interchangeable  panel ............................................................................. 11 
Figure 3-4: Scope hanger – GI scopes, URO scopes ......................................................... 12 
Figure 3-5: Scope hanger – Bronchoscope ........................................................................ 13 
Figure 3-6: System and scope connectors ......................................................................... 14 
Figure 3-7: GI modality extension ........................................................................................ 15 
Figure 3-8: URO modality extension ................................................................................... 15 
Figure 3-9: GI extension fully opened (left), URO extension fully opened (right) ........... 16 
Figure 3-10: Height elevation mechanism – (from left to right) USB port, Height 
Elevation mechanism, On/Off button ................................................................................... 17 
Figure 3-11: Tool tray hanger with GI tools ......................................................................... 18 
Figure 3-12: Tool tray hanger with BRONCH tools ............................................................ 18 
Figure 3-13: Tool tray hanger with URO tools .................................................................... 19 
Figure 3-14: Resectoscope hung on the tool tray .............................................................. 19 
Figure 3-15: Tool connection outlets .................................................................................. 20 
Figure 3-16: Foot switch ....................................................................................................... 21 
Figure 3-16: Colonoscope ................................................................................................... 22 
Figure 3-17: Duodenoscope ................................................................................................ 23 
Figure 3-18: Bronchoscope ................................................................................................. 24 
Figure 3-19: Rigid Cystoscope ............................................................................................ 25 
Figure 3-20: Rigid Ureteroscope ........................................................................................ 26 
Figure 3-21: Flexible scope ................................................................................................. 27 
Figure 2-18: Resectoscope .................................................................................................. 28 


[TABLE]
| Figures                                                                                                                             |
|:------------------------------------------------------------------------------------------------------------------------------------|
| Figures                                                                                                                             |
| F                                                                                                                                   |
| igure 3-1: ENDO Mentor Suite ............................................................................................. 6        |
| Figure 3-2: GI-BRONCH interchangeable cartridge – lower orifice selected ................... 9                                      |
| Figure 3-3:  HYST interchangeable cartridge ...................................................................... 10               |
| Figure 3-4: URO interchangeable  panel ............................................................................. 11             |
| Figure 3-4: Scope hanger – GI scopes, URO scopes ......................................................... 12                       |
| Figure 3-5: Scope hanger – Bronchoscope ........................................................................ 13                 |
| Figure 3-6: System and scope connectors ......................................................................... 14                |
| Figure 3-7: GI modality extension ........................................................................................ 15       |
| Figure 3-8: URO modality extension ................................................................................... 15           |
| Figure 3-9: GI extension fully opened (left), URO extension fully opened (right) ........... 16                                     |
| Figure 3-10: Height elevation mechanism – (from left to right) USB port, Height                                                     |
| Elevation mechanism, On/Off button ................................................................................... 17           |
| Figure 3-11: Tool tray hanger with GI tools ......................................................................... 18            |
| Figure 3-12: Tool tray hanger with BRONCH tools ............................................................ 18                     |
| Figure 3-13: Tool tray hanger with URO tools .................................................................... 19                |
| Figure 3-14: Resectoscope hung on the tool tray .............................................................. 19                   |
| Figure 3-15: Tool connection outlets .................................................................................. 20          |
| Figure 3-16: Foot switch ....................................................................................................... 21 |
| Figure 3-16: Colonoscope ................................................................................................... 22     |
| Figure 3-17: Duodenoscope ................................................................................................ 23       |
| Figure 3-18: Bronchoscope ................................................................................................. 24      |
| Figure 3-19: Rigid Cystoscope ............................................................................................ 25       |
| Figure 3-20: Rigid Ureteroscope ........................................................................................ 26         |
| Figure 3-21: Flexible scope ................................................................................................. 27    |
| Figure 2-18: Resectoscope .................................................................................................. 28     |

[OCR]
Figures

| Figures

Figure 3-1: ENDO Mentor Suite... eeeeesceseesseceseeseseescesceecseescecseeeeseeseesceacecseeaseeseeeeeeneee 6
Figure 3-2: GI-BRONCH interchangeable cartridge — lower orifice selected ............. 9
Figure 3-3: HYST interchangeable Cartridge... eeeessceseeecseesceecsseeeeeeesseeereeseeaeteeeeeees 10
Figure 3-4: URO interchangeable Panel... eeeeseeeeceseesceecseesceecseeseeeeseeseeecseeseeecteeeeeees 11
Figure 3-4: Scope hanger — GI Scopes, URO SCOPES.........ssscseesseeceseeeeeeseesceeceeeseeeseeeeeeees 12
Figure 3-5: Scope hanger — BronchoSCope ..........esesssseseeseeseeeeseeeceecseeseeeeseesceecseeseeaseeeeeeees 13
Figure 3-6: SysteM and SCOPE CONNECHOSS........ eceesseeeeeseeseeceseeeseecseeeeeceseeaceesseeseeesseeeeeess 14
Figure 3-7: Gl modality Extension... eeeeseesseccseesesseeeeseesceecseesseecseeeeeeesesaeeeeseeaeeaeeeeeseess 15
Figure 3-8: URO modality Extension ......eeeeseeesseseeeeseeeeseseeseeecsecseeeseeesesaeeeeeeseeaeeeeeeees 15
Figure 3-9: GI extension fully opened (left), URO extension fully opened (right)........... 16
Figure 3-10: Height elevation mechanism — (from left to right) USB port, Height

Elevation mechanism, On/Off DUttON......... cee ccsessesteeeecteceseeseessesseceecesecseeesseseseeeeseeeseeeenee 17
Figure 3-11: Tool tray hanger With Gl tOOIS 0... eee eeeeeseesceeeeeeeseecseeeeeeeseeseeecseeseeaeseeneeees 18
Figure 3-12: Tool tray hanger with BRONCH tools ..........eeeeseseeeeeceseeeeeeeeeeeeeeseesceeeeeneeees 18
Figure 3-13: Tool tray hanger With URO tools 00... ce ecseseeeeecseeeceecseeeeseeseesceececseeeseeeeeeees 19

Figure 3-14: Resectoscope hung on the tool tray

Figure 3-15: Tool connection outlets

Figure 3-16: Foot switch...... 21
Figure 3-16: Colonoscope. ...

Figure 3-17: DUOAeNOSCOPE .......eeeeesseseeeseeseeceseesceecseesseeescescsacsacsceaceecseeseeasseeseeaceeseeaseeseeees 23
Figure 3-18: BronChOSCope .........cessssesssesesscesceeesceecseeseesesceseescaeseeaseecseesesasseeseseeeeseeeaseaseeees 24
Figure 3-19: Rigid CYStOSCOPC....... ee eeseeesesseeseeecseeeceecseeseseeseescacseeacecseeseeessesaesaeatseeaeasseees 25
Figure 3-20: Rigid UreterOSCOpe ........eeesseescsceseesceeeeeseeeeseescecseeaceecsecseeeeeesesaceesseeaseeseeees 26
Figure 3-21: FlExiDI€ SCOPE oe eee eeeeeeseeseeececeaceecseeseeseseeseescsacseesceecseeseeaeseeseeacsesseeaseeseeees 27
Figure 2-18: RESCCtOSCOPE.......seeeeecessseeeeseescesescesceecsecseeesseeseeacsaesceacacseeaseesseeaesaesatseeaceaeaeees 28

surgicalscience Page v


# Page 6

Figures
 
Page vi 
 
Figure 2-19: Resectoscope’s camera handle ..................................................................... 29 
Figure 3-22: Master Tool ..................................................................................................... 30 
Figure 3-24: Forceps ............................................................................................................ 31 
Figure 3-23: Syringe ............................................................................................................ 32 
Figure 4-1: Back simulator ports ......................................................................................... 42 
Figure 4-2: Cables connected to back simulator ports .................................................... 42 
Figure 4-3: System and scope connectors ........................................................................ 43 
Figure 4-4: Tool connection outlets ................................................................................... 44 
Figure 5-1: Endo Suite Setup main screen ......................................................................... 47 
 


[TABLE]
| Figures                                                                                                                              |
|:-------------------------------------------------------------------------------------------------------------------------------------|
| Figure 2-19: Resectoscope’s camera handle ..................................................................... 29                   |
| Figure 3-22: Master Tool ..................................................................................................... 30    |
| Figure 3-24: Forceps ............................................................................................................ 31 |
| Figure 3-23: Syringe ............................................................................................................ 32 |
| Figure 4-1: Back simulator ports ......................................................................................... 42        |
| Figure 4-2: Cables connected to back simulator ports .................................................... 42                         |
| Figure 4-3: System and scope connectors ........................................................................ 43                  |
| Figure 4-4: Tool connection outlets ................................................................................... 44           |
| Figure 5-1: Endo Suite Setup main screen ......................................................................... 47                |

[OCR]
Figures

Figure 2-19: Resectoscope’s Camera handle... eeeeeeseeseesseeeseeeceecseeeeeeeseeseeecseeaseeeaeees 29

Figure 3-22: Master Tool.. 130

Figure 3-24: Forceps ..
Figure 3-23: Syringe ...
Figure 4-1: Back simulator ports...
Figure 4-2: Cables connected to back simulator ports
Figure 4-3: System and scope connectors.
Figure 4-4: Tool connection outlets....

Figure 5-1: Endo Suite Setup main screen...

surgicalscience Page vi


# Page 7

Chapter 1 
 Safety Precautions
 
Page 1 
 
Chapter 1 Safety Precautions 
Before using the ENDO Mentor Suite simulator, please read these safety precautions 
to ensure proper use of the equipment. These items contain important notes to 
prevent injury to the operator and damage to the equipment. The following precautions 
apply to both the GI Mentor and the BRONCH Mentor which share the ENDO Mentor 
Suite platform. 
Two symbols are used to indicate specific types of warnings in addition to the general 
note table, which is clearly marked: 
 
 
A warning that indicates a prohibition. 
 
A general warning that emphasizes essential information about something 
that must be done.  
 
The following safety precautions must be adhered to upon setup and using the ENDO 
Mentor Suite simulator. Failure to follow these precautions may result in the removal of 
the warranty and may cause irreversible damage to the simulator or injury to 
operators. 
 
 
Read all the instructions and precautions fully before attempting to 
setup or use the ENDO Mentor Suite simulator. 
 
Follow all warnings and instructions marked on the ENDO Mentor 
Suite simulator.  
 
Do not attempt to open, check, alter, or fix any part of the ENDO 
Mentor Suite system, unless directly asked to do so during a support 
session with a Surgical Science representative. 
 
Unplug the ENDO Mentor Suite simulator when you know an 
electrical storm is approaching.  


[TABLE]
| Chapter 1                            |                                                                                        | Safety Precautions   |
|:-------------------------------------|:---------------------------------------------------------------------------------------|:---------------------|
| Chapter 1                            | Safety Precautions                                                                     |                      |
|                                      | Before using the ENDO Mentor Suite simulator, please read these safety precautions     |                      |
|                                      | to ensure proper use of the equipment. These items contain important notes to          |                      |
|                                      | prevent injury to the operator and damage to the equipment. The following precautions  |                      |
|                                      | apply to both the GI Mentor and the BRONCH Mentor which share the ENDO Mentor          |                      |
| Suite platform.                      |                                                                                        |                      |
|                                      | Two symbols are used to indicate specific types of warnings in addition to the general |                      |
| note table, which is clearly marked: |                                                                                        |                      |

[TABLE]
| the warranty and may cause irreversible damage to the simulator or injury to   |
|:-------------------------------------------------------------------------------|
| Read all the instructions and precautions fully before attempting to           |
| setup or use the ENDO Mentor Suite simulator.                                  |
| Follow all warnings and instructions marked on the ENDO Mentor                 |
| Suite simulator.                                                               |
| Do not attempt to open, check, alter, or fix any part of the ENDO              |
| Mentor Suite system, unless directly asked to do so during a support           |
| session with a Surgical Science representative.                                |
| Unplug the ENDO Mentor Suite simulator when you know an                        |
| electrical storm is approaching.                                               |

[OCR]
Chapter 1 Safety Precautions

| Chapter1 Safety Precautions

Before using the ENDO Mentor Suite simulator, please read these safety precautions
to ensure proper use of the equipment. These items contain important notes to
prevent injury to the operator and damage to the equipment. The following precautions
apply to both the GI Mentor and the BRONCH Mentor which share the ENDO Mentor
Suite platform.

Two symbols are used to indicate specific types of warnings in addition to the general
note table, which is clearly marked:

@ A warning that indicates a prohibition.

A general warning that emphasizes essential information about something
that must be done.

The following safety precautions must be adhered to upon setup and using the ENDO
Mentor Suite simulator. Failure to follow these precautions may result in the removal of
the warranty and may cause irreversible damage to the simulator or injury to
operators.

Read all the instructions and precautions fully before attempting to
setup or use the ENDO Mentor Suite simulator.

Follow all warnings and instructions marked on the ENDO Mentor
Suite simulator.

Mentor Suite system, unless directly asked to do so during a support

@ Do not attempt to open, check, alter, or fix any part of the ENDO
session with a Surgical Science representative.

Unplug the ENDO Mentor Suite simulator when you know an
electrical storm is approaching.

surgicalscience Page 1


# Page 8

Chapter 1 
 Safety Precautions
 
Page 2 
 
 
Before cleaning, unplug the ENDO Mentor Suite simulator from the 
wall outlet. Use a dry cloth without liquid. Do not use aerosol 
cleaners. 
 
Do not use the ENDO Mentor Suite near water.  
 
When not in use or upon moving, disconnect all scopes from the 
system side connector. Failing to do so may result in irreparable 
damage. 
 
When not in use or upon moving, make sure that the tool tray is at its 
original folded position. Failing to do so may result in damage to the 
system. 
 
Make sure scopes and wires are not protruding before closing the 
drawer. Failing to do so may result in irreparable damage to the 
scopes or wires. 
 
When placing the ENDO Mentor Suite in a room with additional 
simulators, other electrical systems, or large amounts of metal, 
ensure that these items are at least 1 meter away from the ENDO 
Mentor Suite simulator. Failing to do so may result in an improper 
functioning of the simulator. 
 
Do not move the interchangeable cartridge in any way while the 
scope is inserted into the cavity. Doing so may result in irreparable 
scope damage. 
 
The interchangeable cartridge must be inserted and locked in place 
properly before attempting scope introduction for all the modalities 
to work. 
 
The bronchoscope’s insertion tube should not be bent unnecessarily 
- neither by attaching it to the hanger clip, nor by leaving it within the 
mannequin when not being used. 
 
Do not leave the syringe, master tool, or any other instrument 
inserted in the scope’s working channel unnecessarily. 
 
Place the ENDO Mentor Suite on stable ground only. 


[TABLE]
| Safety Precautions                                                         |
|:---------------------------------------------------------------------------|
| Before cleaning, unplug the ENDO Mentor Suite simulator from the           |
| wall outlet. Use a dry cloth without liquid. Do not use aerosol            |
| cleaners.                                                                  |
| Do not use the ENDO Mentor Suite near water.                               |
| When not in use or upon moving, disconnect all scopes from the             |
| system side connector. Failing to do so may result in irreparable          |
| damage.                                                                    |
| When not in use or upon moving, make sure that the tool tray is at its     |
| original folded position. Failing to do so may result in damage to the     |
| system.                                                                    |
| Make sure scopes and wires are not protruding before closing the           |
| drawer. Failing to do so may result in irreparable damage to the           |
| scopes or wires.                                                           |
| When placing the ENDO Mentor Suite in a room with additional               |
| simulators, other electrical systems, or large amounts of metal,           |
| ensure that these items are at least 1 meter away from the ENDO            |
| Mentor Suite simulator. Failing to do so may result in an improper         |
| functioning of the simulator.                                              |
| Do not move the interchangeable cartridge in any way while the             |
| scope is inserted into the cavity. Doing so may result in irreparable      |
| scope damage.                                                              |
| The interchangeable cartridge must be inserted and locked in place         |
| properly before attempting scope introduction for all the modalities       |
| to work.                                                                   |
| The bronchoscope’s insertion tube should not be bent unnecessarily         |
| - neither by attaching it to the hanger clip, nor by leaving it within the |
| mannequin when not being used.                                             |
| Do not leave the syringe, master tool, or any other instrument             |
| inserted in the scope’s working channel unnecessarily.                     |
| Place the ENDO Mentor Suite on stable ground only.                         |

[OCR]
Chapter 1

Safety Precautions

a5

Before cleaning, unplug the ENDO Mentor Suite simulator from the
wall outlet. Use a dry cloth without liquid. Do not use aerosol
cleaners.

Do not use the ENDO Mentor Suite near water.

When not in use or upon moving, disconnect all scopes from the
system side connector. Failing to do so may result in irreparable
damage.

When not in use or upon moving, make sure that the tool tray is at its
original folded position. Failing to do so may result in damage to the
system.

Make sure scopes and wires are not protruding before closing the
drawer. Failing to do so may result in irreparable damage to the
scopes or wires.

When placing the ENDO Mentor Suite in a room with additional
simulators, other electrical systems, or large amounts of metal,
ensure that these items are at least 1 meter away from the ENDO
Mentor Suite simulator. Failing to do so may result in an improper
functioning of the simulator.

Do not move the interchangeable cartridge in any way while the
scope is inserted into the cavity. Doing so may result in irreparable
scope damage.

The interchangeable cartridge must be inserted and locked in place
properly before attempting scope introduction for all the modalities
to work.

The bronchoscope’s insertion tube should not be bent unnecessarily
- neither by attaching it to the hanger clip, nor by leaving it within the
mannequin when not being used.

Do not leave the syringe, master tool, or any other instrument
inserted in the scope’s working channel unnecessarily.

Place the ENDO Mentor Suite on stable ground only.

surgicalscience

Page 2


# Page 9

Chapter 1 
 Safety Precautions
 
Page 3 
 
 
To protect the ENDO Mentor Suite from overheating, the opening on 
the back of the platform should not be covered or blocked.  
 
The ENDO Mentor Suite should not be placed near a radiator or heat 
register. 
 
The ENDO Mentor Suite should be placed in a room with a 
temperature range between 5 and 30 degrees centigrade. Proper 
ventilation is crucial.  
 
Do not allow anything to rest on the power cord or position the ENDO 
Mentor Suite where a cord could be stepped on or pulled out 
accidentally. 
 
Do not overload wall outlets and extension cords. 
 
Never spill liquid of any kind on the simulator. 
 
Avoid placing or dropping anything on the ENDO Mentor Suite. It may 
cause a malfunction or irreparable damage. 
 
Power must be off when handling the system or disconnecting any 
internal part during a support session.  
 
Unplug the ENDO Mentor Suite from the wall outlet and contact 
Surgical Science support under the following conditions:  
• 
When any cord, especially the power supply cord, is damaged or 
frayed. 
• 
If liquid has been spilled into the ENDO Mentor Suite. 
• 
If something has been dropped on the ENDO Mentor Suite. 
 
When opening the system’s back panel and pulling out the computer 
drawer during support – please note that the monitor must be in the 
opposite (front) side of the system and the computer drawer must be 
pulled out cautiously to avoid equilibrium problems. 


[TABLE]
|                                         | Safety Precautions                                                   |
|:----------------------------------------|:---------------------------------------------------------------------|
|                                         | To protect the ENDO Mentor Suite from overheating, the opening on    |
|                                         | the back of the platform should not be covered or blocked.           |
|                                         | The ENDO Mentor Suite should not be placed near a radiator or heat   |
| register.                               |                                                                      |
|                                         | The ENDO Mentor Suite should be placed in a room with a              |
|                                         | temperature range between 5 and 30 degrees centigrade. Proper        |
| ventilation is crucial.                 |                                                                      |
|                                         | Do not allow anything to rest on the power cord or position the ENDO |
|                                         | Mentor Suite where a cord could be stepped on or pulled out          |
| accidentally.                           |                                                                      |
|                                         | Do not overload wall outlets and extension cords.                    |
|                                         | Never spill liquid of any kind on the simulator.                     |
|                                         | Avoid placing or dropping anything on the ENDO Mentor Suite. It may  |
|                                         | cause a malfunction or irreparable damage.                           |
|                                         | Power must be off when handling the system or disconnecting any      |
| internal part during a support session. |                                                                      |
|                                         | Unplug the ENDO Mentor Suite from the wall outlet and contact        |
|                                         | Surgical Science support under the following conditions:             |
| •                                       | When any cord, especially the power supply cord, is damaged or       |

[OCR]
Chapter 1

Safety Precautions

eeee oe ?ese

To protect the ENDO Mentor Suite from overheating, the opening on
the back of the platform should not be covered or blocked.

The ENDO Mentor Suite should not be placed near a radiator or heat
register.

The ENDO Mentor Suite should be placed in a room with a
temperature range between 5 and 30 degrees centigrade. Proper
ventilation is crucial.

Do not allow anything to rest on the power cord or position the ENDO
Mentor Suite where a cord could be stepped on or pulled out
accidentally.

Do not overload wall outlets and extension cords.

Never spill liquid of any kind on the simulator.

Avoid placing or dropping anything on the ENDO Mentor Suite. It may
cause a malfunction or irreparable damage.

Power must be off when handling the system or disconnecting any
internal part during a support session.

Unplug the ENDO Mentor Suite from the wall outlet and contact
Surgical Science support under the following conditions:

° When any cord, especially the power supply cord, is damaged or
frayed.

. If liquid has been spilled into the ENDO Mentor Suite.

. If something has been dropped on the ENDO Mentor Suite.

When opening the system’s back panel and pulling out the computer
drawer during support — please note that the monitor must be in the
opposite (front) side of the system and the computer drawer must be
pulled out cautiously to avoid equilibrium problems.

surgicalscience

Page 3


# Page 10

Chapter 2 
 Introduction
 
Page 4 
 
Chapter 2 Introduction 
ENDO Mentor Suite® is a multidisciplinary platform that provides hands-on practice of 
multiple GI, bronchoscopy, endourology and basic endoscopic, bronchoscopic skills 
and hysteroscopy procedures for single trainees or an entire team.   
 
 
About this guide 
This guide describes:  
• 
Product specifications 
• 
Packaging instructions 
• 
Assembly instructions 
• 
Calibration 
• 
Troubleshooting 
 


[TABLE]
| A                     | bout this guide        |
|:----------------------|:-----------------------|
| This guide describes: |                        |
| •                     | Product specifications |
| •                     | Packaging instructions |
| •                     | Assembly instructions  |
| •                     | Calibration            |
| •                     | Troubleshooting        |

[OCR]
Chapter 2 Introduction

| Chapter 2 Introduction

ENDO Mentor Suite® is a multidisciplinary platform that provides hands-on practice of
multiple GI, bronchoscopy, endourology and basic endoscopic, bronchoscopic skills
and hysteroscopy procedures for single trainees or an entire team.

About this guide
This guide describes:

Product specifications
Packaging instructions
Assembly instructions
Calibration
Troubleshooting

surgicalscience Page 4


# Page 11

Chapter 3 
 Product Description and Hardware Specifications
 
Page 5 
 
Chapter 3 Product Description and Hardware 
Specifications  
The ENDO Mentor Suite platform consists of:  
• 
Wheeled hardware unit  
• 
One or more scopes according to system configuration 
(Colonoscope/Duodenoscope/Bronchoscope/Rigid Scopes and Flexible 
Scope for Endourology/Resectoscope for Endourology and Hysteroscopy) 
• 
Interchangeable cartridge for inserting scopes 
• 
Set of tools according to system configuration 
• 
Triple foot switch 
• 
Wireless keyboard and mouse 
  


[TABLE]
|                                             | Specifications                                                       |
|:--------------------------------------------|:---------------------------------------------------------------------|
| The ENDO Mentor Suite platform consists of: |                                                                      |
| •                                           | Wheeled hardware unit                                                |
| •                                           | One or more scopes according to system configuration                 |
|                                             | (Colonoscope/Duodenoscope/Bronchoscope/Rigid Scopes and Flexible     |
|                                             | Scope for Endourology/Resectoscope for Endourology and Hysteroscopy) |
| •                                           | Interchangeable cartridge for inserting scopes                       |
| •                                           | Set of tools according to system configuration                       |
| •                                           | Triple foot switch                                                   |
| •                                           | Wireless keyboard and mouse                                          |

[OCR_TABLE]
Chapter 3

[OCR]
Chapter 3 Product Description and Hardware Specifications

| Chapter 3 Product Description and Hardware

Specifications
The ENDO Mentor Suite platform consists of:
° Wheeled hardware unit
e One or more scopes according to system configuration

(Colonoscope/Duodenoscope/Bronchoscope/Rigid Scopes and Flexible
Scope for Endourology/Resectoscope for Endourology and Hysteroscopy)
Interchangeable cartridge for inserting scopes

Set of tools according to system configuration

Triple foot switch

Wireless keyboard and mouse

surgicalscience Page 5


# Page 12

Chapter 3 
 Product Description and Hardware Specifications
 
Page 6 
 
 
Figure 3-1: ENDO Mentor Suite 
1 
27” touch screen 
2 
Interchangeable cartridge 
3 
Wireless keyboard and mouse 
4 
Scope hanger 
5 
Scope connectors 
6 
Elevation mechanism 
7 
Computer activation button 
8 
Rotating tool tray 


[TABLE]
| F   |   gure 3-1: ENDO Mentor Suite |                             |
| i   |                               |                             |
|:----|------------------------------:|:----------------------------|
|     |                             1 | 27” touch screen            |
|     |                             2 | Interchangeable cartridge   |
|     |                             3 | Wireless keyboard and mouse |
|     |                             4 | Scope hanger                |
|     |                             5 | Scope connectors            |
|     |                             6 | Elevation mechanism         |
|     |                             7 | Computer activation button  |
|     |                             8 | Rotating tool tray          |

[OCR]
Chapter 3 Product Description and Hardware Specifications

SIMBIONIX

Figure 3-1: ENDO Mentor Suite

27” touch screen
Interchangeable cartridge
Wireless keyboard and mouse
Scope hanger

Scope connectors

Elevation mechanism

Computer activation button

ON Oo BRB WYN A

Rotating tool tray

surgicalscience Page 6


# Page 13

Chapter 3 
 Product Description and Hardware Specifications
 
Page 7 
 
9 
Upper drawer for Bronchoscope, 2 URO rigid scopes and wires 
(tools are stored in this drawer when shipped) 
10 
Lower drawer for Colonoscope, Duodenoscope, URO, HYST and 
GI-BRONCH interchangeable cartridges 
11 
Foot switch 
12 
Power switch, foot switch connector and USB outlet (on back 
panel) 
Simulator specifications 
The following section lists the platform component specifications* and package list. 
Check your ENDO Mentor Suite package for the following items: 
Simulation processing computer and tracking 
• 
Simulator PC with Windows 10 64-bit operating system 
• 
Electromagnetic tracking system 
Haptic system 
• 
High end technological Haptic (force feedback) to provide realistic 
sensations that mimic the look and feel of an actual procedure 
Characteristics 
• 
Stainless steel support 
• 
Elevation mechanism 
• 
Scope hanger for holding 3 scopes 
• 
Tool tray for hanging simulation tools and resectoscope 
• 
Interchangeable cartridges 
• 
Instruments and accessories 
• 
Wireless keyboard and mouse 
• 
Triple foot switch for activation of fluoroscopy 
Simulator dimensions 
• 
Length: 130-186 cm*, Weight: 57-87 cm*, Height: 135-180 cm** 
• 
Weight – 225 kg 


[TABLE]
| Chapter 3   | Product Description and Hardware Specifications             |
|:------------|:------------------------------------------------------------|
| 9           | Upper drawer for Bronchoscope, 2 URO rigid scopes and wires |
|             | (tools are stored in this drawer when shipped)              |
| 10          | Lower drawer for Colonoscope, Duodenoscope, URO, HYST and   |
|             | GI-BRONCH interchangeable cartridges                        |
| 11          | Foot switch                                                 |
| 12          | Power switch, foot switch connector and USB outlet (on back |
|             | panel)                                                      |

[TABLE]
| The following section lists the platform component specifications* and package list.   |                                                                     |
|:---------------------------------------------------------------------------------------|:--------------------------------------------------------------------|
| Check your ENDO Mentor Suite package for the following items:                          |                                                                     |
| Simulation processing computer and tracking                                            |                                                                     |
| •                                                                                      | Simulator PC with Windows 10 64-bit operating system                |
| •                                                                                      | Electromagnetic tracking system                                     |
| Haptic system                                                                          |                                                                     |
| •                                                                                      | High end technological Haptic (force feedback) to provide realistic |
|                                                                                        | sensations that mimic the look and feel of an actual procedure      |
| Characteristics                                                                        |                                                                     |
| •                                                                                      | Stainless steel support                                             |
| •                                                                                      | Elevation mechanism                                                 |
| •                                                                                      | Scope hanger for holding 3 scopes                                   |
| •                                                                                      | Tool tray for hanging simulation tools and resectoscope             |
| •                                                                                      | Interchangeable cartridges                                          |
| •                                                                                      | Instruments and accessories                                         |
| •                                                                                      | Wireless keyboard and mouse                                         |
| •                                                                                      | Triple foot switch for activation of fluoroscopy                    |
| Simulator dimensions                                                                   |                                                                     |
| •                                                                                      | Length: 130-186 cm*, Weight: 57-87 cm*, Height: 135-180 cm**        |
| •                                                                                      | Weight – 225 kg                                                     |

[OCR]
Chapter 3 Product Description and Hardware Specifications

9 Upper drawer for Bronchoscope, 2 URO rigid scopes and wires
(tools are stored in this drawer when shipped)

10 Lower drawer for Colonoscope, Duodenoscope, URO, HYST and
GI-BRONCH interchangeable cartridges

11 Foot switch

12 Power switch, foot switch connector and USB outlet (on back
panel)

Simulator specifications

The following section lists the platform component specifications* and package list.
Check your ENDO Mentor Suite package for the following items:

Simulation processing computer and tracking

e Simulator PC with Windows 10 64-bit operating system
e Electromagnetic tracking system

Haptic system

e High end technological Haptic (force feedback) to provide realistic
sensations that mimic the look and feel of an actual procedure

Characteristics

Stainless steel support

Elevation mechanism

Scope hanger for holding 3 scopes

Tool tray for hanging simulation tools and resectoscope
Interchangeable cartridges

Instruments and accessories

e Wireless keyboard and mouse

e Triple foot switch for activation of fluoroscopy

Simulator dimensions

e Length: 130-186 cm*, Weight: 57-87 cm*, Height: 135-180 cm**
e Weight - 225 kg

surgicalscience Page 7


# Page 14

Chapter 3 
 Product Description and Hardware Specifications
 
Page 8 
 
*With/without modality extensions and taking into consideration folded in tool tray 
and monitor arm 
**Height adjustment: simulator body elevation plus monitor arm positions. Height 
is measured from the top of the monitor when in working position. 
Monitor 
• 
27” LED Monitor with a FHD resolution (1920X1080) 
Accessories  
• 
Scopes for simulation 
• 
Simulation tools – Master tool, forceps, syringe, EBUS needle, wires 
Cables  
• 
USB cable (for touch screen only) 
• 
Video (DP HDMI) cable 
• 
Power cable  
Documentation  
• 
One of the ENDO Mentor Suite User Guides – GI Mentor, BRONCH Mentor, 
URO Mentor or HYST Mentor 
• 
MentorLearn User Guide for Client Administrators, MentorLearn User Guide 
for Learners 
Electrical  
• 
One power cable  
• 
110-240 V~, 50/60 Hz, 10A 
Environment:  
• 
Operating temperature: range 10°C to 40°C 
• 
Relative Humidity: Maximum 90%  


[TABLE]
|               | **Height adjustment: simulator body elevation plus monitor arm positions. Height   |
|:--------------|:-----------------------------------------------------------------------------------|
|               | is measured from the top of the monitor when in working position.                  |
| Monitor       |                                                                                    |
| •             | 27” LED Monitor with a FHD resolution (1920X1080)                                  |
| Accessories   |                                                                                    |
| •             | Scopes for simulation                                                              |
| •             | Simulation tools – Master tool, forceps, syringe, EBUS needle, wires               |
| Cables        |                                                                                    |
| •             | USB cable (for touch screen only)                                                  |
| •             | Video (DP HDMI) cable                                                              |
| •             | Power cable                                                                        |
| Documentation |                                                                                    |
| •             | One of the ENDO Mentor Suite User Guides – GI Mentor, BRONCH Mentor,               |
|               | URO Mentor or HYST Mentor                                                          |
| •             | MentorLearn User Guide for Client Administrators, MentorLearn User Guide           |
|               | for Learners                                                                       |
| Electrical    |                                                                                    |
| •             | One power cable                                                                    |
| •             | 110-240 V~, 50/60 Hz, 10A                                                          |
| Environment:  |                                                                                    |
| •             | Operating temperature: range 10°C to 40°C                                          |
| •             | Relative Humidity: Maximum 90%                                                     |

[OCR]
Chapter 3 Product Description and Hardware Specifications

*With/without modality extensions and taking into consideration folded in tool tray
and monitor arm

**Height adjustment: simulator body elevation plus monitor arm positions. Height
is measured from the top of the monitor when in working position.

Monitor

e 27” LED Monitor with a FHD resolution (1920X1080)
Accessories

e Scopes for simulation

e Simulation tools — Master tool, forceps, syringe, EBUS needle, wires
Cables

e USB cable (for touch screen only)

e Video (DP HDMI) cable
e Power cable

Documentation

e One of the ENDO Mentor Suite User Guides — GI Mentor, BRONCH Mentor,
URO Mentor or HYST Mentor

e MentorLearn User Guide for Client Administrators, MentorLearn User Guide
for Learners

Electrical

e One power cable
e 110-240 V~, 50/60 Hz, 10A

Environment:

e Operating temperature: range 10°C to 40°C
e Relative Humidity: Maximum 90%

surgicalscience Page 8


# Page 15

Chapter 3 
 Product Description and Hardware Specifications
 
Page 9 
 
Packing: 
• 
1 wooden crate  
*Surgical Science reserves the right to change the ENDO Mentor Suite specifications 
with no prior notice. 
GI-BRONCH interchangeable cartridge   
 
Figure 3-2: GI-BRONCH interchangeable cartridge – lower orifice selected 
Two symbols of the upper GI and lower GI tracts are displayed on the GI-BRONCH 
interchangeable cartridge indicating the relevant GI tract segment. Depending on the 
module selected, the LED will light up on the cartridge to designate the GI tract that 
will be used for procedure. 


[TABLE]
| Chapter 3                   |                                                                                        | Product Description and Hardware Specifications   |
|:----------------------------|:---------------------------------------------------------------------------------------|:--------------------------------------------------|
| Packing:                    |                                                                                        |                                                   |
| •                           | 1 wooden crate                                                                         |                                                   |
|                             | *Surgical Science reserves the right to change the ENDO Mentor Suite specifications    |                                                   |
| with no prior notice.       |                                                                                        |                                                   |
|                             | GI-BRONCH interchangeable cartridge                                                    |                                                   |
| F                           | gure 3-2: GI-BRONCH interchangeable cartridge – lower orifice selected                 |                                                   |
| i                           |                                                                                        |                                                   |
|                             | Two symbols of the upper GI and lower GI tracts are displayed on the GI-BRONCH         |                                                   |
|                             | interchangeable cartridge indicating the relevant GI tract segment. Depending on the   |                                                   |
|                             | module selected, the LED will light up on the cartridge to designate the GI tract that |                                                   |
| will be used for procedure. |                                                                                        |                                                   |
|                             |                                                                                        | Page 9                                            |

[OCR]
Chapter 3 Product Description and Hardware Specifications

Packing:

e 1 wooden crate

*Surgical Science reserves the right to change the ENDO Mentor Suite specifications
with no prior notice.

GI-BRONCH interchangeable cartridge

Figure 3-2: GI-BRONCH interchangeable cartridge — lower orifice selected

Two symbols of the upper GI and lower Gl tracts are displayed on the GI-BRONCH
interchangeable cartridge indicating the relevant GI tract segment. Depending on the
module selected, the LED will light up on the cartridge to designate the Gl tract that
will be used for procedure.

surgicalscience Page 9


# Page 16

Chapter 3 
 Product Description and Hardware Specifications
 
Page 10 
 
HYST interchangeable panel 
 
Figure 3-3: HYST interchangeable cartridge 
 


[TABLE]
| Chapter 3                                | Product Description and Hardware Specifications   |
|:-----------------------------------------|:--------------------------------------------------|
| HYST interchangeable panel               |                                                   |
| F                                        |                                                   |
| i                                        |                                                   |
| gure 3-3: HYST interchangeable cartridge |                                                   |
|                                          | Page 10                                           |

[OCR]
Chapter 3 Product Description and Hardware Specifications

HYST interchangeable panel

Figure 3-3: HYST interchangeable cartridge

surgicalscience Page 10


# Page 17

Chapter 3 
 Product Description and Hardware Specifications
 
Page 11 
 
URO interchangeable panel  
 
Figure 3-4: URO interchangeable  panel 
Note:  An adaptor should be placed on the penis part of the cartridge for the TURP modules. 
1.  Insert your right hand in the groove on the bottom of the interchangeable cartridge 
and your left hand into the edge on the top of the cartridge and gently free the 
cartridge. You should hear a click. 
2.  Pull the cartridge horizontally out. Store it in its designated cavity in the lower 
drawer. 
3.  Insert the desired cartridge with one hand in the groove and the other on the top 
of the cartridge, push it horizontally into place. You should hear a click. 
 
Note: The cartridge must be properly positioned prior to introducing the scopes. 


[TABLE]
| F                                                                                        |                                                                                             |
| i                                                                                        |                                                                                             |
| gure 3-4: URO interchangeable  panel                                                     |                                                                                             |
|:-----------------------------------------------------------------------------------------|:--------------------------------------------------------------------------------------------|
|                                                                                          | Note:  An adaptor should be placed on the penis part of the cartridge for the TURP modules. |
| 1.                                                                                       | Insert your right hand in the groove on the bottom of the interchangeable cartridge         |
|                                                                                          | and your left hand into the edge on the top of the cartridge and gently free the            |
|                                                                                          | cartridge. You should hear a click.                                                         |
| 2.   Pull the cartridge horizontally out. Store it in its designated cavity in the lower |                                                                                             |
|                                                                                          | drawer.                                                                                     |
| 3.                                                                                       | Insert the desired cartridge with one hand in the groove and the other on the top           |
|                                                                                          | of the cartridge, push it horizontally into place. You should hear a click.                 |

[OCR]
Chapter 3 Product Description and Hardware Specifications

URO interchangeable panel

4

Figure 3-4: URO interchangeable panel

Note: An adaptor should be placed on the penis part of the cartridge for the TURP modules.

1. Insert your right hand in the groove on the bottom of the interchangeable cartridge
and your left hand into the edge on the top of the cartridge and gently free the
cartridge. You should hear a click.

2. Pull the cartridge horizontally out. Store it in its designated cavity in the lower
drawer.

3. Insert the desired cartridge with one hand in the groove and the other on the top
of the cartridge, push it horizontally into place. You should hear a click.

Note: The cartridge must be properly positioned prior to introducing the scopes.

surgicalscience Page 11


# Page 18

Chapter 3 
 Product Description and Hardware Specifications
 
Page 12 
 
Scope hanger 
 
Figure 3-5: Scope hanger – GI scopes, URO scopes  


[TABLE]
| Chapter 3                                      | Product Description and Hardware Specifications   |
|:-----------------------------------------------|:--------------------------------------------------|
| Scope hanger                                   |                                                   |
| F                                              |                                                   |
| i                                              |                                                   |
| gure 3-5: Scope hanger – GI scopes, URO scopes |                                                   |
|                                                | Page 12                                           |

[OCR]
Chapter 3 Product Description and Hardware Specifications

Scope hanger

Figure 3-5: Scope hanger — G/ scopes, URO scopes

surgicalscience Page 12


# Page 19

Chapter 3 
 Product Description and Hardware Specifications
 
Page 13 
 
 
Figure 3-6: Scope hanger – Bronchoscope 
• 
The GI scope hangers come with a clip for hanging the scope insertion 
tube as shown above. This prevents the tip from hitting the floor. 
• 
The scope hanger units are generic, the bronchoscope can fit in any 
hanger. 
Note: The flexible ureteroscope and bronchoscope are simulated by the same 
scope. 
 
Note: The resectoscope is hung on the tool tray and not on the scope hanger. 


[TABLE]
| Chapter 3                             | Product Description and Hardware Specifications                              |
|:--------------------------------------|:-----------------------------------------------------------------------------|
| F                                     |                                                                              |
| i                                     |                                                                              |
| gure 3-6: Scope hanger – Bronchoscope |                                                                              |
| •                                     | The GI scope hangers come with a clip for hanging the scope insertion        |
|                                       | tube as shown above. This prevents the tip from hitting the floor.           |
| •                                     | The scope hanger units are generic, the bronchoscope can fit in any          |
|                                       | hanger.                                                                      |
|                                       | Note: The flexible ureteroscope and bronchoscope are simulated by the same   |
|                                       | scope.                                                                       |
|                                       | Note: The resectoscope is hung on the tool tray and not on the scope hanger. |
|                                       | Page 13                                                                      |

[OCR]
Chapter 3 Product Description and Hardware Specifications

Figure 3-6: Scope hanger — Bronchoscope

e The GI scope hangers come with a clip for hanging the scope insertion
tube as shown above. This prevents the tip from hitting the floor.

e The scope hanger units are generic, the bronchoscope can fit in any
hanger.

Note: The flexible ureteroscope and bronchoscope are simulated by the same
scope.

Note: The resectoscope is hung on the tool tray and not on the scope hanger.

surgicalscience Page 13


# Page 20

Chapter 3 
 Product Description and Hardware Specifications
 
Page 14 
 
Connecting the scope 
The GI scopes and BRONCH scope are connected to socket C at the front of the 
system.  
The rigid URO scopes are connected to sockets A and B; the BRONCH scope is used 
as a flexible URO scope and is connected to socket C. 
The resectoscope, used in TURP modules and HYST Mentor, is connected to socket C 
at the front of the system. 
To connect the scope:  
1.  Fit the scope connector exactly in the prongs and recesses of the system 
connector.  
2.  Turn the external dial on the scope connector to the right until you hear a click. 
To disconnect the scope: 
1.  Turn the dial to the left and remove the scope connector. 
Note: Bumping against the scope connector while connected may result in damage to both the 
scope and the system. 
 
Figure 3-7: System and scope connectors 


[TABLE]
| Chapter 3                                                                               | Product Description and Hardware Specifications                                             |
|:----------------------------------------------------------------------------------------|:--------------------------------------------------------------------------------------------|
| Connecting the scope                                                                    |                                                                                             |
| The GI scopes and BRONCH scope are connected to socket C at the front of the            |                                                                                             |
| system.                                                                                 |                                                                                             |
|                                                                                         | The rigid URO scopes are connected to sockets A and B; the BRONCH scope is used             |
| as a flexible URO scope and is connected to socket C.                                   |                                                                                             |
|                                                                                         | The resectoscope, used in TURP modules and HYST Mentor, is connected to socket C            |
| at the front of the system.                                                             |                                                                                             |
| To connect the scope:                                                                   |                                                                                             |
| 1.   Fit the scope connector exactly in the prongs and recesses of the system           |                                                                                             |
| connector.                                                                              |                                                                                             |
| 2.   Turn the external dial on the scope connector to the right until you hear a click. |                                                                                             |
| To disconnect the scope:                                                                |                                                                                             |
| 1.   Turn the dial to the left and remove the scope connector.                          |                                                                                             |
|                                                                                         | Note:  Bumping against the scope connector while connected may result in damage to both the |
| scope and the system.                                                                   |                                                                                             |

[OCR]
Chapter 3 Product Description and Hardware Specifications

Connecting the scope

The GI scopes and BRONCH scope are connected to socket C at the front of the
system.

The rigid URO scopes are connected to sockets A and B; the BRONCH scope is used
as a flexible URO scope and is connected to socket C.

The resectoscope, used in TURP modules and HYST Mentor, is connected to socket C

at the front of the system.

To connect the scope:

1. Fit the scope connector exactly in the prongs and recesses of the system
connector.

2. Turn the external dial on the scope connector to the right until you hear a click.

To disconnect the scope:

1. Turn the dial to the left and remove the scope connector.

Note: Bumping against the scope connector while connected may result in damage to both the
scope and the system.

Figure 3-7: System and scope connectors

surgicalscience Page 14


# Page 21

Chapter 3 
 Product Description and Hardware Specifications
 
Page 15 
 
Extensions 
The GI and URO modules require an extension for performing certain procedures. The 
GI modality extension is on the left side of the ENDO Mentor Suite and the URO 
modality extension is on the back of the simulator. 
 
Figure 3-8: GI modality extension 
 
Figure 3-9: URO modality extension 
 


[TABLE]
| Chapter 3                                                                          | Product Description and Hardware Specifications   |
|:-----------------------------------------------------------------------------------|:--------------------------------------------------|
| Extensions                                                                         |                                                   |
| The GI and URO modules require an extension for performing certain procedures. The |                                                   |
| GI modality extension is on the left side of the ENDO Mentor Suite and the URO     |                                                   |
| modality extension is on the back of the simulator.                                |                                                   |
| F                                                                                  |                                                   |
| i                                                                                  |                                                   |
| gure 3-8: GI modality extension                                                    |                                                   |
| F                                                                                  |                                                   |
| i                                                                                  |                                                   |
| gure 3-9: URO modality extension                                                   |                                                   |
|                                                                                    | Page 15                                           |

[OCR]
Chapter 3 Product Description and Hardware Specifications

Extensions

The Gl and URO modules require an extension for performing certain procedures. The
Gl modality extension is on the left side of the ENDO Mentor Suite and the URO
modality extension is on the back of the simulator.

Figure 3-8: Gl modality extension

Figure 3-9: URO modality extension

surgicalscience Page 15


# Page 22

Chapter 3 
 Product Description and Hardware Specifications
 
Page 16 
 
To open the extension:  
1.  Press gently the modality extension. It will pop out.  
 
 
2.  Pull it to its full length. 
 
 
Figure 3-10: GI extension fully opened (left), URO extension fully opened (right) 
To close the extension: 
1.  Push the extension until it fits back in place. 
Height elevation mechanism 
The height of the ENDO Mentor Suite platform can be adjusted.  


[TABLE]
| Chapter 3                                                                       | Product Description and Hardware Specifications   |
|:--------------------------------------------------------------------------------|:--------------------------------------------------|
| To open the extension:                                                          |                                                   |
| 1.   Press gently the modality extension. It will pop out.                      |                                                   |
| 2.   Pull it to its full length.                                                |                                                   |
| F                                                                               |                                                   |
| i                                                                               |                                                   |
| gure 3-10: GI extension fully opened (left), URO extension fully opened (right) |                                                   |
| To close the extension:                                                         |                                                   |
| 1.   Push the extension until it fits back in place.                            |                                                   |
| Height elevation mechanism                                                      |                                                   |
| The height of the ENDO Mentor Suite platform can be adjusted.                   |                                                   |
|                                                                                 | Page 16                                           |

[OCR]
Chapter 3 Product Description and Hardware Specifications

To open the extension:
1. Press gently the modality extension. It will pop out.

2. Pull it to its full length.

4 |r a

Figure 3-10: GI extension fully opened (left), URO extension fully opened (right)

To close the extension:
1. Push the extension until it fits back in place.

Height elevation mechanism

The height of the ENDO Mentor Suite platform can be adjusted.

surgicalscience Page 16


# Page 23

Chapter 3 
 Product Description and Hardware Specifications
 
Page 17 
 
 
Figure 3-11: Height elevation mechanism – (from left to right) USB port, Height Elevation 
mechanism, On/Off button 
Use the Up and Down arrows on the Height Elevation panel to find the desired height.  
Note: The USB port can be used for example for connecting an external hard drive. 
Turning on the simulator 
1.  Make sure the On/Off Power switch on the back of the simulator is turned on. 
2.  Use the button to the right of the Height Elevation mechanism to turn on the ENDO 
Mentor Suite computer. 
Tool tray 
The rotating tool tray holds all the tools for the ENDO Mentor Suite system: 
• 
Master Tool – URO Mentor, BRONCH Mentor, GI Mentor 
• 
URO forceps – URO Mentor 
• 
Syringe – BRONCH Mentor 
• 
EBUS needle – BRONCH Mentor 
• 
Red and blue wires – GI Mentor 
• 
Resectoscope – HYST Mentor and URO Mentor (TURP modules),  
Note: When not being used or upon moving the system, the tool tray must be stored in its 
original position to avoid damage. 


[TABLE]
| F                                                                                         |
| i                                                                                         |
| gure 3-11: Height elevation mechanism – (from left to right) USB port, Height Elevation   |
|:------------------------------------------------------------------------------------------|
| mechanism, On/Off button                                                                  |
| Use the Up and Down arrows on the Height Elevation panel to find the desired height.      |
| Note: The USB port can be used for example for connecting an external hard drive.         |
| Turning on the simulator                                                                  |
| 1.   Make sure the On/Off Power switch on the back of the simulator is turned on.         |
| 2.   Use the button to the right of the Height Elevation mechanism to turn on the ENDO    |
| Mentor Suite computer.                                                                    |
| Tool tray                                                                                 |
| The rotating tool tray holds all the tools for the ENDO Mentor Suite system:              |

[TABLE]
| Tool tray                                                                                 |                                                           |
|:------------------------------------------------------------------------------------------|:----------------------------------------------------------|
| The rotating tool tray holds all the tools for the ENDO Mentor Suite system:              |                                                           |
| •                                                                                         | Master Tool – URO Mentor, BRONCH Mentor, GI Mentor        |
| •                                                                                         | URO forceps – URO Mentor                                  |
| •                                                                                         | Syringe – BRONCH Mentor                                   |
| •                                                                                         | EBUS needle – BRONCH Mentor                               |
| •                                                                                         | Red and blue wires – GI Mentor                            |
| •                                                                                         | Resectoscope – HYST Mentor and URO Mentor (TURP modules), |
| Note:  When not being used or upon moving the system, the tool tray must be stored in its |                                                           |
|                                                                                           | original position to avoid damage.                        |

[OCR]
Chapter 3 Product Description and Hardware Specifications

Figure 3-11: Height elevation mechanism - (from left to right) USB port, Height Elevation
mechanism, On/Off button

Use the Up and Down arrows on the Height Elevation panel to find the desired height.

Note: The USB port can be used for example for connecting an external hard drive.

Turning on the simulator

1. Make sure the On/Off Power switch on the back of the simulator is turned on.
2. Use the button to the right of the Height Elevation mechanism to turn on the ENDO
Mentor Suite computer.

Tool tray

The rotating tool tray holds all the tools for the ENDO Mentor Suite system:

Master Tool - URO Mentor, BRONCH Mentor, GI Mentor

URO forceps — URO Mentor

Syringe - BRONCH Mentor

EBUS needle - BRONCH Mentor

Red and blue wires — GI Mentor

Resectoscope —- HYST Mentor and URO Mentor (TURP modules),

Note: When not being used or upon moving the system, the tool tray must be stored in its
original position to avoid damage.

surgicalscience Page 17


# Page 24

Chapter 3 
 Product Description and Hardware Specifications
 
Page 18 
 
 
Figure 3-12: Tool tray hanger with GI tools  
 
Figure 3-13: Tool tray hanger with BRONCH tools  


[TABLE]
| Chapter 3                                     | Product Description and Hardware Specifications   |
|:----------------------------------------------|:--------------------------------------------------|
| F                                             |                                                   |
| i                                             |                                                   |
| gure 3-12: Tool tray hanger with GI tools     |                                                   |
| F                                             |                                                   |
| i                                             |                                                   |
| gure 3-13: Tool tray hanger with BRONCH tools |                                                   |
|                                               | Page 18                                           |

[OCR]
Chapter 3 Product Description and Hardware Specifications

Figure 3-12: Tool tray hanger with GI tools

~J

Figure 3-13: Tool tray hanger with BRONCH tools

surgicalscience Page 18


# Page 25

Chapter 3 
 Product Description and Hardware Specifications
 
Page 19 
 
 
Figure 3-14: Tool tray hanger with URO tools  
Note: The resectoscope is positioned on the tool tray so that the camera handle is above the 
TURP/HYST Mentor scope clip. 
 
Figure 3-15: Resectoscope hung on the tool tray 


[TABLE]
| Chapter 3                                                                                    | Product Description and Hardware Specifications   |
|:---------------------------------------------------------------------------------------------|:--------------------------------------------------|
| F                                                                                            |                                                   |
| i                                                                                            |                                                   |
| gure 3-14: Tool tray hanger with URO tools                                                   |                                                   |
| Note: The resectoscope is positioned on the tool tray so that the camera handle is above the |                                                   |
| TURP/HYST Mentor scope clip.                                                                 |                                                   |
| F                                                                                            |                                                   |
| i                                                                                            |                                                   |
| gure 3-15: Resectoscope hung on the tool tray                                                |                                                   |
|                                                                                              | Page 19                                           |

[OCR]
Chapter 3 Product Description and Hardware Specifications

Figure 3-14: Tool tray hanger with URO tools

Note: The resectoscope is positioned on the tool tray so that the camera handle is above the
TURP/HYST Mentor scope clip.

J j
Figure 3-15: Resectoscope hung on the tool tray

surgicalscience Page 19


# Page 26

Chapter 3 
 Product Description and Hardware Specifications
 
Page 20 
 
The tool connectors are on the side of the platform under the tool tray. Use the labeled 
outlets to connect the tool cables as shown below. 
 
Figure 3-16: Tool connection outlets 
1 
Master tool 
2 
URO forceps 
3 
Syringe 
4 
EBUS needle 
The red and blue wires do not need to be connected to a tool outlet as they are 
wireless; the white wire needs no connection as it is already connected to the Master 
Tool. 
When not in use, the wires can be stored either in the upper drawer or on the tool tray. 


[TABLE]
| Chapter 3   |                                                                                          | Product Description and Hardware Specifications   |
|:------------|:-----------------------------------------------------------------------------------------|:--------------------------------------------------|
|             | The tool connectors are on the side of the platform under the tool tray. Use the labeled |                                                   |
|             | outlets to connect the tool cables as shown below.                                       |                                                   |
| F           | gure 3-16: Tool connection outlets                                                       |                                                   |
| i           |                                                                                          |                                                   |
| 1           | Master tool                                                                              |                                                   |
| 2           | URO forceps                                                                              |                                                   |
| 3           | Syringe                                                                                  |                                                   |
| 4           | EBUS needle                                                                              |                                                   |
|             | The red and blue wires do not need to be connected to a tool outlet as they are          |                                                   |
|             | wireless; the white wire needs no connection as it is already connected to the Master    |                                                   |
| Tool.       |                                                                                          |                                                   |
|             | When not in use, the wires can be stored either in the upper drawer or on the tool tray. |                                                   |
|             |                                                                                          | Page 20                                           |

[OCR]
Chapter 3 Product Description and Hardware Specifications

The tool connectors are on the side of the platform under the tool tray. Use the labeled
outlets to connect the tool cables as shown below.

Figure 3-16: Tool connection outlets

1 Master tool
2 URO forceps
3 Syringe

4 EBUS needle

The red and blue wires do not need to be connected to a tool outlet as they are
wireless; the white wire needs no connection as it is already connected to the Master
Tool.

When not in use, the wires can be stored either in the upper drawer or on the tool tray.

surgicalscience Page 20


# Page 27

Chapter 3 
 Product Description and Hardware Specifications
 
Page 21 
 
Foot switch 
A triple foot switch is provided with the platform and utilized in some of the modules 
for actions such as application of electrosurgical current (left foot switch) or 
application of X-ray (right foot switch).  
The foot switch is utilized in the TURP modules and HYST Mentor for electrosurgical 
current: cutting (middle foot switch) and coagulation (right foot switch). 
 
Figure 3-17: Foot switch 
Available scopes 
 
Make sure the scopes are not protruding before closing the drawer. 
Failing to do so may result in irreparable damage to the scopes. 
 
GI scopes 
Two scope types are available with the GI Mentor procedures. Both are real scopes 
that were modified for simulation purposes: 
• 
Colonoscope – used also for gastroscopy 
• 
Duodenoscope – used for the ERCP and EUS modules 


[TABLE]
| Chapter 3                                                                        | Product Description and Hardware Specifications                                        |
|:---------------------------------------------------------------------------------|:---------------------------------------------------------------------------------------|
| Foot switch                                                                      |                                                                                        |
|                                                                                  | A triple foot switch is provided with the platform and utilized in some of the modules |
| for actions such as application of electrosurgical current (left foot switch) or |                                                                                        |
| application of X-ray (right foot switch).                                        |                                                                                        |
|                                                                                  | The foot switch is utilized in the TURP modules and HYST Mentor for electrosurgical    |
| current: cutting (middle foot switch) and coagulation (right foot switch).       |                                                                                        |

[OCR]
Chapter 3 Product Description and Hardware Specifications

Foot switch

A triple foot switch is provided with the platform and utilized in some of the modules
for actions such as application of electrosurgical current (left foot switch) or
application of X-ray (right foot switch).

The foot switch is utilized in the TURP modules and HYST Mentor for electrosurgical
current: cutting (middle foot switch) and coagulation (right foot switch).

Figure 3-17: Foot switch

Available scopes

Make sure the scopes are not protruding before closing the drawer.
Failing to do so may result in irreparable damage to the scopes.

Gl scopes

Two scope types are available with the GI Mentor procedures. Both are real scopes
that were modified for simulation purposes:

. Colonoscope — used also for gastroscopy
e Duodenoscope - used for the ERCP and EUS modules

surgicalscience Page 21


# Page 28

Chapter 3 
 Product Description and Hardware Specifications
 
Page 22 
 
Colonoscope 
The colonoscope, a forward viewing endoscope, is an actual scope modified for 
simulation purposes.  
 
 
 
1 – Working Channel  
2 – Up-Down 
Directional Knob  
3 – Right-Left 
Directional Knob 
4 – Lock/Free Switch 
for Up-Down 
Movement  
5 – Lock/Free Switch 
for Right-Left 
Movement 
6 – Suction Button  
7 – Insufflation and 
Irrigation Button 
Figure 3-18: Colonoscope 


[TABLE]
| 1                    |
|  – Working Channel   |
|:---------------------|
| 2 – Up-Down          |
| Directional Knob     |
| 3 – Right-Left       |
| Directional Knob     |
| 4 – Lock/Free Switch |
| for Up-Down          |
| Movement             |
| 5 – Lock/Free Switch |
| for Right-Left       |
| Movement             |
| 6 – Suction Button   |
| 7 – Insufflation and |
| Irrigation Button    |

[OCR]
Chapter 3 Product Description and Hardware Specifications

Colonoscope

The colonoscope, a forward viewing endoscope, is an actual scope modified for
simulation purposes.

1 - Working Channel

2 - Up-Down
Directional Knob
3 - Right-Left

Directional Knob

4 - Lock/Free Switch
for Up-Down
Movement

5 - Lock/Free Switch
for Right-Left
Movement

6 - Suction Button

7 - Insufflation and
Irrigation Button

Figure 3-18: Colonoscope

surgicalscience Page 22


# Page 29

Chapter 3 
 Product Description and Hardware Specifications
 
Page 23 
 
Duodenoscope 
The duodenoscope,  a side viewing scope, is an actual scope modified for simulation 
purposes.  
 
 
 
1 – Working 
Channel for Master 
Tool  
2 – Working 
Channel for Red 
Wire  
3 – Working 
Channel for Blue 
Wire  
4 – Up-Down 
Directional Knob  
5 – Right-Left 
Directional Knob  
6 – Tool Elevation 
Lever 
7 – Lock/Free 
Switch for Up-
Down Movement  
8 – Lock/Free 
Switch for Right-
Left Movement  
9 – Suction Button 
10 – Insufflation 
and Irrigation 
Button 
Figure 3-19: Duodenoscope 


[TABLE]
| 1                  |
|  – Working         |
|:-------------------|
| Channel for Master |
| Tool               |
| 2 – Working        |
| Channel for Red    |
| Wire               |
| 3 – Working        |
| Channel for Blue   |
| Wire               |
| 4 – Up-Down        |
| Directional Knob   |
| 5 – Right-Left     |
| Directional Knob   |
| 6 – Tool Elevation |
| Lever              |
| 7 – Lock/Free      |
| Switch for Up-     |
| Down Movement      |
| 8 – Lock/Free      |
| Switch for Right-  |
| Left Movement      |
| 9 – Suction Button |
| 10 – Insufflation  |
| and Irrigation     |
| Button             |

[OCR]
Chapter 3 Product Description and Hardware Specifications

Duodenoscope

The duodenoscope, a side viewing scope, is an actual scope modified for simulation
purposes.

1 - Working
Channel for Master
Tool

2 - Working
Channel for Red
Wire

3 - Working
Channel for Blue
Wire

4 -Up-Down
Directional Knob
5 - Right-Left
Directional Knob

6 - Tool Elevation
Lever

7 - Lock/Free
Switch for Up-
Down Movement

8 - Lock/Free
Switch for Right-
Left Movement

9 - Suction Button

10 — Insufflation
and Irrigation
Button

Figure 3-19: Duodenoscope

surgicalscience Page 23


# Page 30

Chapter 3 
 Product Description and Hardware Specifications
 
Page 24 
 
BRONCH scope 
Bronchoscope 
The bronchoscope, used with the BRONCH Mentor, is an actual bronchoscope 
modified for simulation purposes.  
 
 
 
1 – Working Channel  
2 – Up-Down 
(Flex/Extend) Lever 
3 – V Button  
4 – C Button 
5 – Freeze Button 
6 – Suction Button  
7 – Insertion Tube 
 
Figure 3-20: Bronchoscope         
Note: The flexible scope simulates both the flexible cystoscope and the flexible ureteroscope 
and is the same scope used for bronchoscopic procedures. 


[TABLE]
| 1                    |
|  – Working Channel   |
|:---------------------|
| 2 – Up-Down          |
| (Flex/Extend) Lever  |
| 3 – V Button         |
| 4 – C Button         |
| 5 – Freeze Button    |
| 6 – Suction Button   |
| 7 – Insertion Tube   |

[OCR]
Chapter 3 Product Description and Hardware Specifications

BRONCH scope

Bronchoscope

The bronchoscope, used with the BRONCH Mentor, is an actual bronchoscope
modified for simulation purposes.

1 - Working Channel

£&

2 - Up-Down
5 (Flex/Extend) Lever
6 3-V Button

4-C Button

5 — Freeze Button
6 - Suction Button

7 - Insertion Tube

Figure 3-20: Bronchoscope

Note: The flexible scope simulates both the flexible cystoscope and the flexible ureteroscope
and is the same scope used for bronchoscopic procedures.

surgicalscience Page 24


# Page 31

Chapter 3 
 Product Description and Hardware Specifications
 
Page 25 
 
URO scopes 
Rigid Cystoscope 
The rigid cystoscope is used for endoscopy of the urinary bladder via the urethra for 
diagnostic or therapeutic purposes. It allows the user to view stones, strictures and 
abnormal tissues, polyps, tumors or cancer of the urethra or bladder.  
 
Figure 3-21: Rigid Cystoscope 
 


[TABLE]
| Chapter 3                                                             | Product Description and Hardware Specifications                                       |
|:----------------------------------------------------------------------|:--------------------------------------------------------------------------------------|
| URO scopes                                                            |                                                                                       |
| Rigid Cystoscope                                                      |                                                                                       |
|                                                                       | The rigid cystoscope is used for endoscopy of the urinary bladder via the urethra for |
|                                                                       | diagnostic or therapeutic purposes. It allows the user to view stones, strictures and |
| abnormal tissues, polyps, tumors or cancer of the urethra or bladder. |                                                                                       |

[OCR]
Chapter 3 Product Description and Hardware Specifications

URO scopes

Rigid Cystoscope

The rigid cystoscope is used for endoscopy of the urinary bladder via the urethra for
diagnostic or therapeutic purposes. It allows the user to view stones, strictures and
abnormal tissues, polyps, tumors or cancer of the urethra or bladder.

Figure 3-21: Rigid Cystoscope

surgicalscience Page 25


# Page 32

Chapter 3 
 Product Description and Hardware Specifications
 
Page 26 
 
Rigid Ureteroscope 
The rigid ureteroscope is used to examine the upper urinary tract. It is passed through 
the urethra and bladder and then into the ureter and allows the user to view kidney 
stones and abnormal tissues, polyps, tumors or cancer of the kidney or ureter. 
 
Figure 3-22: Rigid Ureteroscope 


[TABLE]
| Chapter 3                                                                           | Product Description and Hardware Specifications                                         |
|:------------------------------------------------------------------------------------|:----------------------------------------------------------------------------------------|
| Rigid Ureteroscope                                                                  |                                                                                         |
|                                                                                     | The rigid ureteroscope is used to examine the upper urinary tract. It is passed through |
| the urethra and bladder and then into the ureter and allows the user to view kidney |                                                                                         |
| stones and abnormal tissues, polyps, tumors or cancer of the kidney or ureter.      |                                                                                         |
| F                                                                                   |                                                                                         |
| i                                                                                   |                                                                                         |
| gure 3-22: Rigid Ureteroscope                                                       |                                                                                         |
|                                                                                     | Page 26                                                                                 |

[OCR]
Chapter 3 Product Description and Hardware Specifications

Rigid Ureteroscope

The rigid ureteroscope is used to examine the upper urinary tract. It is passed through
the urethra and bladder and then into the ureter and allows the user to view kidney
stones and abnormal tissues, polyps, tumors or cancer of the kidney or ureter.

Figure 3-22: Rigid Ureteroscope

surgicalscience Page 26


# Page 33

Chapter 3 
 Product Description and Hardware Specifications
 
Page 27 
 
Flexible Scope 
The flexible scope is used as both a cystoscope and ureteroscope. Its flexible middle 
tube allows the user to reach difficult parts of the urethra, bladder and urinary tract. 
 
Figure 3-23: Flexible scope 


[TABLE]
| Chapter 3                                                                                | Product Description and Hardware Specifications                                       |
|:-----------------------------------------------------------------------------------------|:--------------------------------------------------------------------------------------|
| Flexible Scope                                                                           |                                                                                       |
|                                                                                          | The flexible scope is used as both a cystoscope and ureteroscope. Its flexible middle |
| tube allows the user to reach difficult parts of the urethra, bladder and urinary tract. |                                                                                       |
| F                                                                                        |                                                                                       |
| i                                                                                        |                                                                                       |
| gure 3-23: Flexible scope                                                                |                                                                                       |
|                                                                                          | Page 27                                                                               |

[OCR]
Chapter 3 Product Description and Hardware Specifications

Flexible Scope

The flexible scope is used as both a cystoscope and ureteroscope. Its flexible middle
tube allows the user to reach difficult parts of the urethra, bladder and urinary tract.

Figure 3-23: Flexible scope

surgicalscience Page 27


# Page 34

Chapter 3 
 Product Description and Hardware Specifications
 
Page 28 
 
HYST Mentor and TURP module scope 
Resectoscope 
 
 
Figure 3-24: Resectoscope  
1 
Camera handle 
2 
Camera buttons 
3 
Zoom ring 
4 
Focus ring 
5 
Working element 
6 
Outflow valve 
7 
Outflow tube 
8 
Inflow valve 
9 
Inflow tube 
 


[TABLE]
| F   |   gure 3-24: Resectoscope |                 |
| i   |                           |                 |
|:----|--------------------------:|:----------------|
|     |                         1 | Camera handle   |
|     |                         2 | Camera buttons  |
|     |                         3 | Zoom ring       |
|     |                         4 | Focus ring      |
|     |                         5 | Working element |
|     |                         6 | Outflow valve   |
|     |                         7 | Outflow tube    |
|     |                         8 | Inflow valve    |
|     |                         9 | Inflow tube     |

[OCR]
Chapter 3 Product Description and Hardware Specifications

HYST Mentor and TURP module scope

Resectoscope

Figure 3-24; Resectoscope

=

Camera handle
Camera buttons
Zoom ring

Focus ring
Working element
Outflow valve
Outflow tube

Inflow valve

oon OoOuntR WD

Inflow tube

surgicalscience Page 28


# Page 35

Chapter 3 
 Product Description and Hardware Specifications
 
Page 29 
 
Camera 
Resectoscope simulates the use of an endoscopic camera with a camera handle and a 
menu of camera angles. You can manipulate the camera exactly as you would 
manipulate a real endoscopic camera. When the camera is inserted, the screen 
displays a simulated image of the operative field and the image changes responsively 
when you move the camera robot inward and outward and side to side or rotate the 
camera. 
 
Figure 3-25: Resectoscope’s camera handle 
1 
Camera handle. Use the camera handle to hold the 
endoscopic camera. Once the scope is inserted, you can roll 
the camera in all directions. It is advisable to select an 
appropriate camera angle from the camera menu before use.  
2 
Middle button. Press the button to save images during 
procedure. 


[TABLE]
| Chapter 3                                                                    | Product Description and Hardware Specifications                                      |
|:-----------------------------------------------------------------------------|:-------------------------------------------------------------------------------------|
| Camera                                                                       |                                                                                      |
|                                                                              | Resectoscope simulates the use of an endoscopic camera with a camera handle and a    |
| menu of camera angles. You can manipulate the camera exactly as you would    |                                                                                      |
| manipulate a real endoscopic camera. When the camera is inserted, the screen |                                                                                      |
|                                                                              | displays a simulated image of the operative field and the image changes responsively |
|                                                                              | when you move the camera robot inward and outward and side to side or rotate the     |
| camera.                                                                      |                                                                                      |

[TABLE]
| F   | gure 3-25: Resectoscope’s camera handle                     |
| i   |                                                             |
|:----|:------------------------------------------------------------|
| 1   | Camera handle. Use the camera handle to hold the            |
|     | endoscopic camera. Once the scope is inserted, you can roll |
|     | the camera in all directions. It is advisable to select an  |
|     | appropriate camera angle from the camera menu before use.   |
| 2   | Middle button. Press the button to save images during       |
|     | procedure.                                                  |

[OCR_TABLE]
MmlhA A KRFEAr OD

[OCR_TABLE]
menu <

[OCR]
Chapter 3 Product Description and Hardware Specifications

Camera

Resectoscope simulates the use of an endoscopic camera with a camera handle and a
menu of camera angles. You can manipulate the camera exactly as you would
manipulate a real endoscopic camera. When the camera is inserted, the screen
displays a simulated image of the operative field and the image changes responsively
when you move the camera robot inward and outward and side to side or rotate the
camera.

Figure 3-25: Resectoscope’s camera handle

1 Camera handle. Use the camera handle to hold the
endoscopic camera. Once the scope is inserted, you can roll
the camera in all directions. It is advisable to select an
appropriate camera angle from the camera menu before use.

2 Middle button. Press the button to save images during
procedure.

surgicalscience Page 29


# Page 36

Chapter 3 
 Product Description and Hardware Specifications
 
Page 30 
 
3 
Zoom ring. Turn the Zoom ring clockwise to zoom in (subject 
appears closer) and counterclockwise to zoom out (subject 
appears farther away). 
4 
Focus ring. Turn the Focus ring to achieve the sharpest 
possible image. 
Auxiliary tools and connectors 
The ENDO Mentor Suite has the following tools and wires: 
Master Tool 
The Master Tool is used to simulate most of the tools in the ENDO Mentor Suite 
modules – GI Mentor, BRONCH Mentor and URO Mentor. 
 
Figure 3-26: Master Tool 
To select a virtual tool using the Master Tool: 
1.  Insert the Master Tool slowly into the working channel until the Tools menu 
appears.  
The Tools menu opens with pictures of all available tools.  
To work with Master Tool handle: 
• 
Pull the Master Tool handle back to open, inflate, or fill the tool. 
• 
Push the Master Tool handle forward to close, deflate, or inject using the 
tool.  


[TABLE]
| Chapter 3   | Product Description and Hardware Specifications             |
|:------------|:------------------------------------------------------------|
| 3           | Zoom ring. Turn the Zoom ring clockwise to zoom in (subject |
|             | appears closer) and counterclockwise to zoom out (subject   |
|             | appears farther away).                                      |
| 4           | Focus ring. Turn the Focus ring to achieve the sharpest     |
|             | possible image.                                             |

[TABLE]
| 4                                                                              | Focus ring. Turn the Focus ring to achieve the sharpest   |
|:-------------------------------------------------------------------------------|:----------------------------------------------------------|
|                                                                                | possible image.                                           |
| Auxiliary tools and connectors                                                 |                                                           |
| The ENDO Mentor Suite has the following tools and wires:                       |                                                           |
| Master Tool                                                                    |                                                           |
| The Master Tool is used to simulate most of the tools in the ENDO Mentor Suite |                                                           |
| modules – GI Mentor, BRONCH Mentor and URO Mentor.                             |                                                           |

[OCR]
Chapter 3 Product Description and Hardware Specifications

3 Zoom ring. Turn the Zoom ring clockwise to zoom in (subject
appears closer) and counterclockwise to zoom out (subject
appears farther away).

4 Focus ring. Turn the Focus ring to achieve the sharpest
possible image.

Auxiliary tools and connectors

The ENDO Mentor Suite has the following tools and wires:

Master Tool

The Master Tool is used to simulate most of the tools in the ENDO Mentor Suite
modules — GI Mentor, BRONCH Mentor and URO Mentor.

\e)

Figure 3-26: Master Tool

To select a virtual tool using the Master Tool:

1. Insert the Master Tool slowly into the working channel until the Tools menu
appears.

The Tools menu opens with pictures of all available tools.

To work with Master Tool handle:

e Pull the Master Tool handle back to open, inflate, or fill the tool.
e Push the Master Tool handle forward to close, deflate, or inject using the
tool.

surgicalscience Page 30


# Page 37

Chapter 3 
 Product Description and Hardware Specifications
 
Page 31 
 
GI wires 
The GI Mentor uses 3 wires (red, white and blue) in the ERCP modules, in addition to 
the Master Tool. 
A blue wire and a red wire are used in the ERCP modules. The duodenoscope allows 
for working simultaneously with three tools and wires, inserted through three separate 
openings. Each colored wire is inserted into its color marked opening and simulates a 
different tool or wire during the ERCP procedure.  
URO tools 
The URO Mentor has two basic tools: Master Tool and forceps. 
Forceps 
 
Figure 3-27: Forceps 
To work with forceps handle: 
• 
Slide the knob on the forceps handle forward to open the tool. 
• 
Slide the knob on the forceps handle backwards to the tool.  
BRONCH tools 
The BRONCH Mentor has two tools as part of the basic modules:  
a master tool and a syringe. The master tool is used to simulate all the bronchoscopic 
tools and the syringe is used to simulate the delivery of fluids in the working channel. 


[TABLE]
| Chapter 3                                                    | Product Description and Hardware Specifications                                        |
|:-------------------------------------------------------------|:---------------------------------------------------------------------------------------|
| GI wires                                                     |                                                                                        |
|                                                              | The GI Mentor uses 3 wires (red, white and blue) in the ERCP modules, in addition to   |
| the Master Tool.                                             |                                                                                        |
|                                                              | A blue wire and a red wire are used in the ERCP modules. The duodenoscope allows       |
|                                                              | for working simultaneously with three tools and wires, inserted through three separate |
|                                                              | openings. Each colored wire is inserted into its color marked opening and simulates a  |
| different tool or wire during the ERCP procedure.            |                                                                                        |
| URO tools                                                    |                                                                                        |
| The URO Mentor has two basic tools: Master Tool and forceps. |                                                                                        |
| Forceps                                                      |                                                                                        |

[OCR_TABLE]
Chaoter 3

[OCR]
Chapter 3 Product Description and Hardware Specifications

Gl wires

The GI Mentor uses 3 wires (red, white and blue) in the ERCP modules, in addition to
the Master Tool.

A blue wire and a red wire are used in the ERCP modules. The duodenoscope allows
for working simultaneously with three tools and wires, inserted through three separate
openings. Each colored wire is inserted into its color marked opening and simulates a
different tool or wire during the ERCP procedure.

URO tools

The URO Mentor has two basic tools: Master Tool and forceps.

Forceps

Figure 3-27: Forceps

To work with forceps handle:

° Slide the knob on the forceps handle forward to open the tool.
e Slide the knob on the forceps handle backwards to the tool.

BRONCH tools

The BRONCH Mentor has two tools as part of the basic modules:
a master tool and a syringe. The master tool is used to simulate all the bronchoscopic
tools and the syringe is used to simulate the delivery of fluids in the working channel.

surgicalscience Page 31


# Page 38

Chapter 3 
 Product Description and Hardware Specifications
 
Page 32 
 
Additional tools, such as the EBUS needle, which is part of the EBUS Module, are 
described in their relevant module literature. 
Syringe 
 
Figure 3-28: Syringe 
The syringe can be utilized for several purposes:  
• 
Administering saline and other fluids. 
• 
Retrieving saline. 
• 
Applying and releasing vacuum for needle aspirations. 
To work with syringe: 
• 
Pull the syringe piston back to fill, apply vacuum for needle aspiration, or 
retrieve saline during BAL. 
• 
Push the syringe piston forward to inject or release vacuum for needle 
aspiration. 
Note:  To administer a second dosage, remove the syringe from the working channel, retract the 
piston so the syringe is ‘filled’, and reinsert it into the scope’s working channel. 


[TABLE]
| F   | gure 3-28: Syringe                                |                                                                              |
| i   |                                                   |                                                                              |
|:----|:--------------------------------------------------|:-----------------------------------------------------------------------------|
|     | The syringe can be utilized for several purposes: |                                                                              |
|     | •                                                 | Administering saline and other fluids.                                       |
|     | •                                                 | Retrieving saline.                                                           |
|     | •                                                 | Applying and releasing vacuum for needle aspirations.                        |
|     | To work with syringe:                             |                                                                              |
|     | •                                                 | Pull the syringe piston back to fill, apply vacuum for needle aspiration, or |
|     |                                                   | retrieve saline during BAL.                                                  |
|     | •                                                 | Push the syringe piston forward to inject or release vacuum for needle       |
|     |                                                   | aspiration.                                                                  |

[OCR_TABLE]
described

[OCR]
Chapter 3 Product Description and Hardware Specifications

Additional tools, such as the EBUS needle, which is part of the EBUS Module, are
described in their relevant module literature.

Syringe

Figure 3-28: Syringe

The syringe can be utilized for several purposes:

e Administering saline and other fluids.

e Retrieving saline.

e Applying and releasing vacuum for needle aspirations.

To work with syringe:

° Pull the syringe piston back to fill, apply vacuum for needle aspiration, or
retrieve saline during BAL.

e Push the syringe piston forward to inject or release vacuum for needle
aspiration.

Note: To administer a second dosage, remove the syringe from the working channel, retract the
piston so the syringe is ‘filled’, and reinsert it into the scope’s working channel.

surgicalscience Page 32


# Page 39

Chapter 3 
 Product Description and Hardware Specifications
 
Page 33 
 
EBUS needle 
The EBUS Needle is a real EBUS needle modified to fit the simulation needs. All original 
functionality is maintained, except for the stylet which is virtual. 
1 – Cable connects to the fourth socket of the 
tool tray (furthest from system). 
 
2 – Needle controls account for needle 
motion out and in of the sheath. The secure 
lock slider provides extra safety in securing 
the needle, optional length adjustment and 
motion stopper. 
The gray mechanical stopper sets the 
maximum needle length and cannot be 
removed. 
Note: The needle click-locked state is at the 
upper most position of the needle handle. 
When in this position, the needle is 
completely inside the sheath. 
A mechanical click divides this position from 
the rest of the sheath. 
3 – Sheath controls are used to set the 
measurement of sheath protrusion out of the 
working channel and fix it. 
4 – Fixation to working channel by inserting 
and fixating the EBUS Needle to the scope’s 
working channel using the slide lock. 
Note: The slide lock must be released when 
inserting the needle and then fit and locked 
to the adapter. 
a – The adapter should be thrust over the 
scope’s working channel extension prior to 
starting an EBUS case. 
 
 


[TABLE]
| EBUS needle                                                                              |
|:-----------------------------------------------------------------------------------------|
| The EBUS Needle is a real EBUS needle modified to fit the simulation needs. All original |
| functionality is maintained, except for the stylet which is virtual.                     |
| 1 – Cable connects to the fourth socket of the                                           |
| tool tray (furthest from system).                                                        |
| 2 – Needle controls account for needle                                                   |
| motion out and in of the sheath. The secure                                              |
| lock slider provides extra safety in securing                                            |
| the needle, optional length adjustment and                                               |
| motion stopper.                                                                          |
| The gray mechanical stopper sets the                                                     |
| maximum needle length and cannot be                                                      |
| removed.                                                                                 |
| Note: The needle click-locked state is at the                                            |
| upper most position of the needle handle.                                                |
| When in this position, the needle is                                                     |
| completely inside the sheath.                                                            |
| A mechanical click divides this position from                                            |
| the rest of the sheath.                                                                  |
| 3 – Sheath controls are used to set the                                                  |
| measurement of sheath protrusion out of the                                              |
| working channel and fix it.                                                              |
| 4 – Fixation to working channel by inserting                                             |
| and fixating the EBUS Needle to the scope’s                                              |
| working channel using the slide lock.                                                    |
| Note: The slide lock must be released when                                               |
| inserting the needle and then fit and locked                                             |
| to the adapter.                                                                          |
| a – The adapter should be thrust over the                                                |
| scope’s working channel extension prior to                                               |
| starting an EBUS case.                                                                   |

[OCR]
Chapter 3 Product Description and Hardware Specifications

EBUS needle

The EBUS Needle is a real EBUS needle modified to fit the simulation needs. All original
functionality is maintained, except for the stylet which is virtual.

1- Cable connects to the fourth socket of the
tool tray (furthest from system). @

2 —-Needle controls account for needle
motion out and in of the sheath. The secure
lock slider provides extra safety in securing
the needle, optional length adjustment and
motion stopper.

The gray mechanical stopper sets the
maximum needle length and cannot be @
removed.

Note: The needle click-locked state is at the k ?
upper most position of the needle handle. 1

When in this position, the needle is
completely inside the sheath.

A mechanical click divides this position from
the rest of the sheath.

|
3 - Sheath controls are used to set the 8) ‘|
measurement of sheath protrusion out of the f=]
working channel and fix it.

4 - Fixation to working channel by inserting 5
and fixating the EBUS Needle to the scope’s os
working channel using the slide lock.

Note: The slide lock must be released when }
inserting the needle and then fit and locked @ i} a

to the adapter.

a- The adapter should be thrust over the
scope’s working channel extension prior to
starting an EBUS case.

surgicalscience Page 33


# Page 40

Chapter 4 
 Unpacking and Assembly
 
Page 34 
 
Chapter 4 Unpacking and Assembly  
The ENDO Mentor Suite simulator is a high-quality precision hardware, which requires 
careful packing prior to shipping to help assure a long and trouble-free life. Follow 
these simple instructions when unpacking the simulator. 
Unpacking instructions 
Follow these simple instructions for unpacking your ENDO Mentor Suite simulator.  
Note: These instructions can be used in the opposite order for packing the simulator when it 
needs to be shipped. 
Unpacking the crate 
1.  Unlock the top of the crate by opening the latches.  
2.  On the crate’s top, open the foot switch container by opening its latches. 
 
3.  Remove the foot switch and ramp locking screws. Remove the nylon wrapping 
around the foot switch. 


[TABLE]
| Chapter 4                                                                                     | Unpacking and Assembly                                                               |
|:----------------------------------------------------------------------------------------------|:-------------------------------------------------------------------------------------|
| Chapter 4  Unpacking and Assembly                                                             |                                                                                      |
|                                                                                               | The ENDO Mentor Suite simulator is a high-quality precision hardware, which requires |
| careful packing prior to shipping to help assure a long and trouble-free life. Follow         |                                                                                      |
| these simple instructions when unpacking the simulator.                                       |                                                                                      |
| Unpacking instructions                                                                        |                                                                                      |
| Follow these simple instructions for unpacking your ENDO Mentor Suite simulator.              |                                                                                      |
| Note:  These instructions can be used in the opposite order for packing the simulator when it |                                                                                      |
| needs to be shipped.                                                                          |                                                                                      |
| Unpacking the crate                                                                           |                                                                                      |
| 1.   Unlock the top of the crate by opening the latches.                                      |                                                                                      |
| 2.   On the crate’s top, open the foot switch container by opening its latches.               |                                                                                      |

[OCR]
Chapter 4 Unpacking and Assembly

| Chapter 4 Unpacking and Assembly

The ENDO Mentor Suite simulator is a high-quality precision hardware, which requires
careful packing prior to shipping to help assure a long and trouble-free life. Follow
these simple instructions when unpacking the simulator.

Unpacking instructions

Follow these simple instructions for unpacking your ENDO Mentor Suite simulator.

Note: These instructions can be used in the opposite order for packing the simulator when it
needs to be shipped.

Unpacking the crate

=

Unlock the top of the crate by opening the latches.
2. On the crate’s top, open the foot switch container by opening its latches.

3. Remove the foot switch and ramp locking screws. Remove the nylon wrapping
around the foot switch.

surgicalscience Page 34


# Page 41

Chapter 4 
 Unpacking and Assembly
 
Page 35 
 
 
4.  Remove the front side (narrow side) of crate. 
5.  Take the anti-static mat and documentation out of the crate. 
Remove the platform side lock from its slot. 
 


[TABLE]
| Chapter 4                                                         | Unpacking and Assembly   |
|:------------------------------------------------------------------|:-------------------------|
| 4.   Remove the front side (narrow side) of crate.                |                          |
| 5.   Take the anti-static mat and documentation out of the crate. |                          |
| Remove the platform side lock from its slot.                      |                          |
|                                                                   | Page 35                  |

[OCR]
Chapter 4 Unpacking and Assembly

4. Remove the front side (narrow side) of crate.
5. Take the anti-static mat and documentation out of the crate.

Remove the platform side lock from its slot.

surgicalscience Page 35


# Page 42

Chapter 4 
 Unpacking and Assembly
 
Page 36 
 
Important: Before removing the sides of the crate and the ENDO Mentor Suite 
simulator from the crate, lock the crate wheels. The best practice is to add a 
wooden block next to each wheel to ensure the crate doesn’t move while 
unloading the simulator. 
6.  Remove the other 3 sides of the crate by opening their latches. 
7.  Place the front side of the crate against the bottom of the crate to create a ramp.  
Note: The word, RAMP is written on the front side to designate it is the correct 
side to use.  
8.  Attach and lock the ramp into place by inserting the two locking screws into the 
two holes on the front side of the crate.  
 
 
 


[TABLE]
| Chapter 4   |                                                                                          | Unpacking and Assembly   |
|:------------|:-----------------------------------------------------------------------------------------|:-------------------------|
|             | Important: Before removing the sides of the crate and the ENDO Mentor Suite              |                          |
|             | simulator from the crate, lock the crate wheels. The best practice is to add a           |                          |
|             | wooden block next to each wheel to ensure the crate doesn’t move while                   |                          |
|             | unloading the simulator.                                                                 |                          |
|             | 6.   Remove the other 3 sides of the crate by opening their latches.                     |                          |
|             | 7.   Place the front side of the crate against the bottom of the crate to create a ramp. |                          |
|             | Note: The word, RAMP is written on the front side to designate it is the correct         |                          |
|             | side to use.                                                                             |                          |
|             | 8.   Attach and lock the ramp into place by inserting the two locking screws into the    |                          |
|             | two holes on the front side of the crate.                                                |                          |
|             |                                                                                          | Page 36                  |

[OCR]
Chapter 4 Unpacking and Assembly

Important: Before removing the sides of the crate and the ENDO Mentor Suite
simulator from the crate, lock the crate wheels. The best practice is to add a
wooden block next to each wheel to ensure the crate doesn’t move while
unloading the simulator.

6. Remove the other 3 sides of the crate by opening their latches.
7. Place the front side of the crate against the bottom of the crate to create a ramp.

Note: The word, RAMP is written on the front side to designate it is the correct
side to use.

8. Attach and lock the ramp into place by inserting the two locking screws into the
two holes on the front side of the crate.

surgicalscience Page 36


# Page 43

Chapter 4 
 Unpacking and Assembly
 
Page 37 
 
9. To release the blue straps, pull and hold the release handle on the ratchet and 
open the rachet completely.  
 
The strap will pop loose. Pull the ratchet to loosen and unthread the blue straps 
from the ratchets. 
 
10. Loosen the blue straps that fasten the simulator body to the floor of the crate. Pull 
the straps away from the simulator body. 
Note: Make sure the ratchet handles and blue straps are out of the way when 
wheeling out the simulator. 


[TABLE]
| Chapter 4                                                                                  |
|  Unpacking and Assembly                                                                    |
|:-------------------------------------------------------------------------------------------|
| 9.                                                                                         |
| To release the blue straps, pull and hold the release handle on the ratchet and            |
| open the rachet completely.                                                                |
| The strap will pop loose. Pull the ratchet to loosen and unthread the blue straps          |
| from the ratchets.                                                                         |
| 10.  Loosen the blue straps that fasten the simulator body to the floor of the crate. Pull |
| the straps away from the simulator body.                                                   |
| Note: Make sure the ratchet handles and blue straps are out of the way when                |
| wheeling out the simulator.                                                                |
| Page 37                                                                                    |

[OCR]
Chapter 4 Unpacking and Assembly

9. To release the blue straps, pull and hold the release handle on the ratchet and
open the rachet completely.

The strap will pop loose. Pull the ratchet to loosen and unthread the blue straps
from the ratchets.

10. Loosen the blue straps that fasten the simulator body to the floor of the crate. Pull
the straps away from the simulator body.

Note: Make sure the ratchet handles and blue straps are out of the way when
wheeling out the simulator.

surgicalscience Page 37


# Page 44

Chapter 4 
 Unpacking and Assembly
 
Page 38 
 
 
11. Release the brakes (push lever up) on the 4 simulator body wheels and gently roll 
the simulator body out of the crate. It is recommended that 2 people roll the 
simulator down the ramp until all 4 wheels are on the floor.  
 
12.  Remove the blue nylon wrapping around the simulator. 
13.  Straighten the monitor so that it is in its working position. 


[TABLE]
| Chapter 4                                                                              | Unpacking and Assembly   |
|:---------------------------------------------------------------------------------------|:-------------------------|
| 11.  Release the brakes (push lever up) on the 4 simulator body wheels and gently roll |                          |
| the simulator body out of the crate. It is recommended that 2 people roll the          |                          |
| simulator down the ramp until all 4 wheels are on the floor.                           |                          |
| 12.  Remove the blue nylon wrapping around the simulator.                              |                          |
| 13.  Straighten the monitor so that it is in its working position.                     |                          |
|                                                                                        | Page 38                  |

[OCR]
Chapter 4 Unpacking and Assembly

11. Release the brakes (push lever up) on the 4 simulator body wheels and gently roll
the simulator body out of the crate. It is recommended that 2 people roll the
simulator down the ramp until all 4 wheels are on the floor.

fey < =

12. Remove the blue nylon wrapping around the simulator.
13. Straighten the monitor so that it is in its working position.

surgicalscience Page 38


# Page 45

Chapter 4 
 Unpacking and Assembly
 
Page 39 
 
 
14.  Remove the protective foam around the monitor and monitor arm and back pole. 
 
15.  Remove the protective nylon on the top of the simulator. 


[TABLE]
| Chapter 4                                                                         | Unpacking and Assembly   |
|:----------------------------------------------------------------------------------|:-------------------------|
| 14.  Remove the protective foam around the monitor and monitor arm and back pole. |                          |
| 15.  Remove the protective nylon on the top of the simulator.                     |                          |
|                                                                                   | Page 39                  |

[OCR]
Chapter 4 Unpacking and Assembly

14. Remove the protective foam around the monitor and monitor arm and back pole.

=

15. Remove the protective nylon on the top of the simulator.

surgical Page 39


# Page 46

Chapter 4 
 Unpacking and Assembly
 
Page 40 
 
Setup instructions 
The assembly of the ENDO Mentor Suite consists of the following steps: 
• 
Positioning the simulator  
• 
Connecting the foot switch, LAN and power cables 
• 
Connecting the tools and scopes 
• 
Turning on the system 
Positioning the simulator components 
Note: When placing the ENDO Mentor Suite in a room with additional simulators, other electrical 
systems, or large amounts of metal, ensure that these items are at least 10 inches away 
from the ENDO Mentor Suite simulator. Failing to do so may result in an improper 
functioning of the simulator. 
 
1.  Take the keyboard and mouse out from the top drawer and place on the top of the 
simulator body. 
2.  Take the tool tray bar out of the drawer and attach it to its designated place on the 
right side of the simulator. 
 
3.  Take the tools out of the top drawer and hang them on the tool tray. 


[TABLE]
| Chapter 4                            |                                                                                                  | Unpacking and Assembly   |
|:-------------------------------------|:-------------------------------------------------------------------------------------------------|:-------------------------|
| Setup instructions                   |                                                                                                  |                          |
|                                      | The assembly of the ENDO Mentor Suite consists of the following steps:                           |                          |
| •                                    | Positioning the simulator                                                                        |                          |
| •                                    | Connecting the foot switch, LAN and power cables                                                 |                          |
| •                                    | Connecting the tools and scopes                                                                  |                          |
| •                                    | Turning on the system                                                                            |                          |
| Positioning the simulator components |                                                                                                  |                          |
|                                      | Note:  When placing the ENDO Mentor Suite in a room with additional simulators, other electrical |                          |
|                                      | systems, or large amounts of metal, ensure that these items are at least 10 inches away          |                          |
|                                      | from the ENDO Mentor Suite simulator. Failing to do so may result in an improper                 |                          |
|                                      | functioning of the simulator.                                                                    |                          |
| 1                                    | .   Take the keyboard and mouse out from the top drawer and place on the top of the              |                          |
| simulator body.                      |                                                                                                  |                          |
|                                      | 2.   Take the tool tray bar out of the drawer and attach it to its designated place on the       |                          |
| right side of the simulator.         |                                                                                                  |                          |
|                                      | 3.   Take the tools out of the top drawer and hang them on the tool tray.                        |                          |
|                                      |                                                                                                  | Page 40                  |

[OCR]
Chapter 4 Unpacking and Assembly

Setup instructions
The assembly of the ENDO Mentor Suite consists of the following steps:

Positioning the simulator

Connecting the foot switch, LAN and power cables
Connecting the tools and scopes

Turning on the system

Positioning the simulator components

Note: When placing the ENDO Mentor Suite in a room with additional simulators, other electrical
systems, or large amounts of metal, ensure that these items are at least 10 inches away
from the ENDO Mentor Suite simulator. Failing to do so may result in an improper
functioning of the simulator.

1. Take the keyboard and mouse out from the top drawer and place on the top of the
simulator body.

2. Take the tool tray bar out of the drawer and attach it to its designated place on the
right side of the simulator.

3. Take the tools out of the top drawer and hang them on the tool tray.

surgicalscience Page 40


# Page 47

Chapter 4 
 Unpacking and Assembly
 
Page 41 
 
 
4.  Take the interchangeable cartridge to be used out of the bottom drawer and slide 
it into place (see page 10). 
 
5.  Take the scope to be used out of the bottom drawer and hang on the scope 
hanger (see page 12). 


[TABLE]
| Chapter 4                                                                             | Unpacking and Assembly   |
|:--------------------------------------------------------------------------------------|:-------------------------|
| 4.   Take the interchangeable cartridge to be used out of the bottom drawer and slide |                          |
| it into place (see page 10).                                                          |                          |
| 5.   Take the scope to be used out of the bottom drawer and hang on the scope         |                          |
| hanger (see page 12).                                                                 |                          |
|                                                                                       | Page 41                  |

[OCR]
Chapter 4 Unpacking and Assembly

4. Take the interchangeable cartridge to be used out of the bottom drawer and slide
it into place (see page 10).

5. Take the scope to be used out of the bottom drawer and hang on the scope
hanger (see page 12).

surgicalscience Page 41


# Page 48

Chapter 4 
 Unpacking and Assembly
 
Page 42 
 
Connecting the foot switch, power and LAN cables 
 
Figure 4-1: Back simulator ports 
(Left to right): 1 – Foot switch 2 – LAN (Internet), 3 – Power, 4 – ON/OFF switch,    5 – Power 
indicator 
1.  Connect the foot switch connector to its port (1) 
2.  Connect the LAN (Internet) cable to its port (2). 
3.  Connect the power cable connector to its port (3). 
 
Figure 4-2: Cables connected to back simulator ports 
Connecting the scopes 
The GI scopes and BRONCH scope are connected to socket C at the front of the 
system.  
The rigid URO scopes are connected to sockets A and B; the BRONCH scope is used 
as a flexible URO scope and is connected to socket C. 


[TABLE]
| Chapter 4                                                                                       | Unpacking and Assembly   |
|:------------------------------------------------------------------------------------------------|:-------------------------|
| Connecting the foot switch, power and LAN cables                                                |                          |
| F                                                                                               |                          |
| i                                                                                               |                          |
| gure 4-1: Back simulator ports                                                                  |                          |
| (Left to right): 1 – Foot switch 2 – LAN (Internet), 3 – Power, 4 – ON/OFF switch,    5 – Power |                          |
| i                                                                                               |                          |
| ndicator                                                                                        |                          |
| 1.   Connect the foot switch connector to its port (1)                                          |                          |
| 2.   Connect the LAN (Internet) cable to its port (2).                                          |                          |
| 3.   Connect the power cable connector to its port (3).                                         |                          |
| F                                                                                               |                          |
| i                                                                                               |                          |
| gure 4-2: Cables connected to back simulator ports                                              |                          |
| Connecting the scopes                                                                           |                          |
| The GI scopes and BRONCH scope are connected to socket C at the front of the                    |                          |
| system.                                                                                         |                          |
| The rigid URO scopes are connected to sockets A and B; the BRONCH scope is used                 |                          |
| as a flexible URO scope and is connected to socket C.                                           |                          |
|                                                                                                 | Page 42                  |

[OCR]
Chapter 4 Unpacking and Assembly

Connecting the foot switch, power and LAN cables

Figure 4-1: Back simulator ports

(Left to right): 1- Foot switch 2 - LAN (Internet), 3 - Power, 4- ON/OFF switch, 5- Power
indicator

1. Connect the foot switch connector to its port (1)
2. Connect the LAN (Internet) cable to its port (2).
3. Connect the power cable connector to its port (3).

Figure 4-2: Cables connected to back simulator ports

Connecting the scopes
The GI scopes and BRONCH scope are connected to socket C at the front of the
system.

The rigid URO scopes are connected to sockets A and B; the BRONCH scope is used
as a flexible URO scope and is connected to socket C.

surgicalscience Page 42


# Page 49

Chapter 4 
 Unpacking and Assembly
 
Page 43 
 
The resectoscope, used in TURP modules, is connected to socket C at the front of the 
system. 
To connect the scope:  
1.  Fit the scope connector exactly in the prongs and recesses of the system 
connector.  
2.  Turn the external dial on the scope connector to the right until you hear a click. 
To disconnect the scope: 
1.  Turn the dial to the left and remove the scope connector. 
Note: Bumping against the scope connector while connected may result in damage to both the 
scope and the system. 
 
Figure 4-3: System and scope connectors 
Connecting the tools 
The tool connectors are on the side of the platform under the tool tray. Use the labeled 
outlets to connect the tool cables as shown below. 


[TABLE]
| Chapter 4                                                                               | Unpacking and Assembly                                                                      |
|:----------------------------------------------------------------------------------------|:--------------------------------------------------------------------------------------------|
|                                                                                         | The resectoscope, used in TURP modules, is connected to socket C at the front of the        |
| system.                                                                                 |                                                                                             |
| To connect the scope:                                                                   |                                                                                             |
| 1.   Fit the scope connector exactly in the prongs and recesses of the system           |                                                                                             |
| connector.                                                                              |                                                                                             |
| 2.   Turn the external dial on the scope connector to the right until you hear a click. |                                                                                             |
| To disconnect the scope:                                                                |                                                                                             |
| 1.   Turn the dial to the left and remove the scope connector.                          |                                                                                             |
|                                                                                         | Note:  Bumping against the scope connector while connected may result in damage to both the |
| scope and the system.                                                                   |                                                                                             |

[OCR]
Chapter 4 Unpacking and Assembly

The resectoscope, used in TURP modules, is connected to socket C at the front of the

system.

To connect the scope:

1. Fit the scope connector exactly in the prongs and recesses of the system
connector.

2. Turn the external dial on the scope connector to the right until you hear a click.

To disconnect the scope:

1. Turn the dial to the left and remove the scope connector.

Note: Bumping against the scope connector while connected may result in damage to both the
scope and the system.

Figure 4-3: System and scope connectors

Connecting the tools

The tool connectors are on the side of the platform under the tool tray. Use the labeled
outlets to connect the tool cables as shown below.

surgicalscience Page 43


# Page 50

Chapter 4 
 Unpacking and Assembly
 
Page 44 
 
 
Figure 4-4: Tool connection outlets 
1 
Master tool 
2 
URO forceps 
3 
Syringe 
4 
EBUS needle 
Turning on the system 
WARNING! 
Before turning on the system: 
 
• 
Verify that all the components are properly 
connected and switched off including the screen 
monitor. 
 
• 
Make sure that the simulator is at least 10 inches 
away from additional simulators, other electrical 
systems and cables, or large amounts of metal. 
 
1.  Turn on the power using the On/Off Power switch (4) on the back of the simulator. 
The Power indicator (5) is lit. 
2.  Use the button to the right of the Height Elevation mechanism to turn on the ENDO 
Mentor Suite computer. 


[TABLE]
| Turning on the system   |                                                     |
|:------------------------|:----------------------------------------------------|
| WARNING!                | Before turning on the system:                       |
|                         | Verify that all the components are properly         |
|                         | •                                                   |
|                         | connected and switched off including the screen     |
|                         | monitor.                                            |
|                         | Make sure that the simulator is at least 10 inches  |
|                         | •                                                   |
|                         | away from additional simulators, other electrical   |
|                         | systems and cables, or large amounts of metal.      |

[OCR]
Chapter 4 Unpacking and Assembly

Figure 4-4: Tool connection outlets
1
2
3
4

Turning on the system

Master tool
URO forceps
Syringe
EBUS needle

WARNING! Before turning on the system:

. Verify that all the components are properly
connected and switched off including the screen
monitor.

. Make sure that the simulator is at least 10 inches

away from additional simulators, other electrical
systems and cables, or large amounts of metal.

1. Turn on the power using the On/Off Power switch (4) on the back of the simulator.
The Power indicator (5) is lit.

2. Use the button to the right of the Height Elevation mechanism to turn on the ENDO
Mentor Suite computer.

surgicalscience Page 44


# Page 51

Chapter 4 
 Unpacking and Assembly
 
Page 45 
 
3.  Use the Up and Down arrows on the Height Elevation panel to find the desired 
height (see page 16). 
 
 


[TABLE]
| Chapter 4                                                                         | Unpacking and Assembly   |
|:----------------------------------------------------------------------------------|:-------------------------|
| 3.   Use the Up and Down arrows on the Height Elevation panel to find the desired |                          |
| height (see page 16).                                                             |                          |
|                                                                                   | Page 45                  |

[OCR]
Chapter 4 Unpacking and Assembly

3. Use the Up and Down arrows on the Height Elevation panel to find the desired
height (see page 16).

surgicalscience Page 45


# Page 52

Chapter 5 
 Calibration
 
Page 46 
 
Chapter 5 Calibration 
The ENDO Mentor Suite simulator is shipped fully calibrated. However, if problems 
arise which require calibration, the EndoSetup software application can be used to 
perform calibration on all tools that are to be used with the system. 
Performing calibration 
1.  Click the EndoSetup 
 icon on the Desktop.  
2.  Select the connected platform to be calibrated. 
 
The Endo Suite Setup Main screen is displayed. 


[TABLE]
| Chapter 5                                            |                                                                                    | Calibration   |
|:-----------------------------------------------------|:-----------------------------------------------------------------------------------|:--------------|
| Chapter 5  Calibration                               |                                                                                    |               |
|                                                      | The ENDO Mentor Suite simulator is shipped fully calibrated. However, if problems  |               |
|                                                      | arise which require calibration, the EndoSetup software application can be used to |               |
|                                                      | perform calibration on all tools that are to be used with the system.              |               |
| Performing calibration                               |                                                                                    |               |
| 1.   Click the EndoSetup                             | icon on the Desktop.                                                               |               |
| 2.   Select the connected platform to be calibrated. |                                                                                    |               |

[OCR]
Chapter 5 Calibration

| Chapter 5 Calibration

The ENDO Mentor Suite simulator is shipped fully calibrated. However, if problems
arise which require calibration, the EndoSetup software application can be used to
perform calibration on all tools that are to be used with the system.

Performing calibration

1. Click the EndoSetup icon on the Desktop.
2. Select the connected platform to be calibrated.

Select Platform

The Endo Suite Setup Main screen is displayed.

surgicalscience Page 46


# Page 53

Chapter 5 
 Calibration
 
Page 47 
 
 
Figure 5-1: Endo Suite Setup main screen 
You can change the platform inside the software.  
a. Choose the platform you want to calibrate from Select Platform list. 
 
 
3.  The following information is listed on the Information pane (left side of the screen): 
• 
Status of all the hardware components connected to the system (GBU 
board, Switchboard, Ascension and sensors). 
• 
Graphic card, Operating System and Hardware dll versions. 
• 
Registry folder. 
• 
Advance settings (password protected) for advanced users. 
GI Mentor calibration 
1.  Select the GI platform from the Select Platform list. 


[TABLE]
| 3.   The following information is listed on the Information pane (left side of the screen):   |                                                                    |
|:----------------------------------------------------------------------------------------------|:-------------------------------------------------------------------|
| •                                                                                             | Status of all the hardware components connected to the system (GBU |
|                                                                                               | board, Switchboard, Ascension and sensors).                        |
| •                                                                                             | Graphic card, Operating System and Hardware dll versions.          |
| •                                                                                             | Registry folder.                                                   |
| •                                                                                             | Advance settings (password protected) for advanced users.          |

[OCR]
Chapter 5

Calibration

Endo Suite |

SIMBIONIX

‘Scope Channels Calibration
Main Wire (white)
Pushing Wire (blue)

Guide Wire (red)

a

‘Scope Buttons,
Pushed
Optic
Optic Press

‘Suction

Figure 5-7: Endo Suite Setup main screen

Calibrate

Calibrate

Calibrate

You can change the platform inside the software.

a. Choose the platform you want to calibrate from Select Platform list.

Select Platform: (USGI

Channel:

3. The following information is listed on the Information pane (left side of the screen):

e Status of all the hardware components connected to the system (GBU
board, Switchboard, Ascension and sensors).

e Graphic card, Operating System and Hardware dll versions.

e Registry folder.

e Advance settings (password protected) for advanced users.

GI Mentor calibration

1. Select the GI platform from the Select Platform list.

surgicalscience

Page 47


# Page 54

Chapter 5 
 Calibration
 
Page 48 
 
Colonoscope 
Scope tab 
The Scope tab is used to verify that when the GI wires are inserted in the scope 
channels, the system identifies them. If not, the channels need to be calibrated. In 
addition, the tab is used to verify if the scope buttons are identified when pressed. 
1.  Select the Scope tab. 
 
2.  Connect the Colonoscope to its port (C). 
The Colonoscope’s channel (C) is selected from the Channel list.  
3.  Insert each of the wires into its scope channel and verify that the Inside box is 
filled green. 
 


[TABLE]
| Chapter 5                                                                             | Calibration   |
|:--------------------------------------------------------------------------------------|:--------------|
| Colonoscope                                                                           |               |
| Scope tab                                                                             |               |
| The Scope tab is used to verify that when the GI wires are inserted in the scope      |               |
| channels, the system identifies them. If not, the channels need to be calibrated. In  |               |
| addition, the tab is used to verify if the scope buttons are identified when pressed. |               |
| 1.   Select the Scope tab.                                                            |               |

[OCR]
Chapter 5

Calibration

Colonoscope

Scope tab

The Scope tab is used to verify that when the Gl wires are inserted in the scope
channels, the system identifies them. If not, the channels need to be calibrated. In
addition, the tab is used to verify if the scope buttons are identified when pressed.

1. Select the Scope tab.

Suction
F
c

v

Scope Tools ‘Ascension General
Scope Channels Calibration
Inside
Main Wire (white) | ] Calibrate
Pushing Wire (blue) | ] Calibrate
Guide Wire (red) [ | Calibrate
Scope Buttons
Pushed
Optic
Optic Press

Roll Calibration

2. Connect the Colonoscope to its port (C).

The Colonoscope’s channel (C) is selected from the Channel list.

3. Insert each of the wires into its scope channel and verify that the Inside box is

filled green.
Scope Tools Ascension General
Scope Channels Calibration
Inside
Main Wire (white) I | |

surgicalscience

Page 48


# Page 55

Chapter 5 
 Calibration
 
Page 49 
 
4.  If not, the channel needs to be calibrated. Click the Calibrate button for the 
specific channel. 
The Colonoscope – Main Channel Calibration window is displayed for the specific 
channel.  
5.  Remove the wire from the channel and press Start.  
 
6.  Insert the wire all the way into the channel. 
 
The Channel bar fills up. 
7.  Click Save. 
8.  Repeat steps 4-8 for all the colonoscope’s channels.  
9.  Check each of the colonoscope’s buttons by pressing each button (Suction, F, C 
and V buttons). 
The Pushed box should be filled green. 


[TABLE]
| Chapter 5                                                                           |
|  Calibration                                                                        |
|:------------------------------------------------------------------------------------|
| 4.                                                                                  |
| If not, the channel needs to be calibrated. Click the Calibrate button for the      |
| specific channel.                                                                   |
| The Colonoscope – Main Channel Calibration window is displayed for the specific     |
| channel.                                                                            |
| 5.   Remove the wire from the channel and press Start.                              |
| 6.                                                                                  |
| Insert the wire all the way into the channel.                                       |
| The Channel bar fills up.                                                           |
| 7.   Click Save.                                                                    |
| 8.   Repeat steps 4-8 for all the colonoscope’s channels.                           |
| 9.   Check each of the colonoscope’s buttons by pressing each button (Suction, F, C |
| and V buttons).                                                                     |
| The Pushed box should be filled green.                                              |
| Page 49                                                                             |

[OCR]
Chapter 5 Calibration

6.

© NI

If not, the channel needs to be calibrated. Click the Calibrate button for the
specific channel.

The Colonoscope — Main Channel Calibration window is displayed for the specific
channel.
Remove the wire from the channel and press Start.

Colonscope - Main Channel Calibration

Insert the wire all the way into the channel.

Colonscope - Main Channel Calibration

The Channel bar fills up.

Click Save.

Repeat steps 4-8 for all the colonoscope’s channels.

Check each of the colonoscope’s buttons by pressing each button (Suction, F, C
and V buttons).

The Pushed box should be filled green.

surgicalscience Page 49


# Page 56

Chapter 5 
 Calibration
 
Page 50 
 
 
Advance settings 
The Out value is the value greater than the MAX calibrated value. This means that 
when you extract the wire from the scope channel, it will be considered Out and the 
Inside box will not be filled. You can calibrate this value in the Advance Settings mode. 
Note: The Advance Settings are password protected; access is only for advanced users. 
To display the Advance Settings: 
1.  Click to select the Advance Settings check box on the bottom of the Information 
pane (left side of screen). 
To calibrate: 
1.  Insert the wire into the channel you want to calibrate all the way. 
2.  Press the Calibrate button and then OK. 
3.  To override this value, select to mark the Override check box and enter a different 
value in the Out Value Calibration box. 
 
Tools tab 
The Tools tab is used to calibrate the tool handles. The Master Tool (GIB MT) is the 
only tool used with the GI Mentor simulation modules.  


[TABLE]
| Advance settings                                                                       |                                                                                           |
|:---------------------------------------------------------------------------------------|:------------------------------------------------------------------------------------------|
|                                                                                        | The Out value is the value greater than the MAX calibrated value. This means that         |
|                                                                                        | when you extract the wire from the scope channel, it will be considered Out and the       |
|                                                                                        | Inside box will not be filled. You can calibrate this value in the Advance Settings mode. |
| Note:  The Advance Settings are password protected; access is only for advanced users. |                                                                                           |
| To display the Advance Settings:                                                       |                                                                                           |
|                                                                                        | 1.   Click to select the Advance Settings check box on the bottom of the Information      |
|                                                                                        | pane (left side of screen).                                                               |
| To calibrate:                                                                          |                                                                                           |
| 1.                                                                                     | Insert the wire into the channel you want to calibrate all the way.                       |
| 2.   Press the Calibrate button and then OK.                                           |                                                                                           |
|                                                                                        | 3.   To override this value, select to mark the Override check box and enter a different  |
|                                                                                        | value in the Out Value Calibration box.                                                   |

[OCR]
Chapter 5 Calibration

Scope Buttons
Pushed

Optic

Optic Press

Suction fel
F

Cc

Vv

Advance settings

The Out value is the value greater than the MAX calibrated value. This means that
when you extract the wire from the scope channel, it will be considered Out and the
Inside box will not be filled. You can calibrate this value in the Advance Settings mode.

Note: The Advance Settings are password protected; access is only for advanced users.

To display the Advance Settings:

1. Click to select the Advance Settings check box on the bottom of the Information
pane (left side of screen).

To calibrate:

1. Insert the wire into the channel you want to calibrate all the way.

2. Press the Calibrate button and then OK.

3. To override this value, select to mark the Override check box and enter a different
value in the Out Value Calibration box.

@ Qut Value Calibration [] Override
Main Wire (white) 3026 u [Caibrte| mm (@) [200 =
Tools tab

The Tools tab is used to calibrate the tool handles. The Master Tool (GIB MT) is the
only tool used with the GI Mentor simulation modules.

surgicalscience Page 50


# Page 57

Chapter 5 
 Calibration
 
Page 51 
 
1.  Select the Tools tab. 
 
2.  Make sure the Master Tool is connected to its port on the right side of the 
simulator. 
3.  Click Calibrate.  
The Master Tool Handle Calibration window is displayed. 
4.  Click Start. 
 
5.  Open and close the Master Tool a few times. 


[TABLE]
| Chapter 5                                                                        | Calibration   |
|:---------------------------------------------------------------------------------|:--------------|
| 1.   Select the Tools tab.                                                       |               |
| 2.   Make sure the Master Tool is connected to its port on the right side of the |               |
| simulator.                                                                       |               |
| 3.   Click Calibrate.                                                            |               |
| The Master Tool Handle Calibration window is displayed.                          |               |
| 4.   Click Start.                                                                |               |
| 5.   Open and close the Master Tool a few times.                                 |               |
|                                                                                  | Page 51       |

[OCR]
Chapter 5 Calibration

1. Select the Tools tab.

a Ce ee

Tool Handles Calibration

EBUS Sheath il Calibrate
EBUS Needle I Calibrate
Syringe I Calibrate
Forceps I Calibrate
Mt ee |

2. Make sure the Master Tool is connected to its port on the right side of the
simulator.

3. Click Calibrate.
The Master Tool Handle Calibration window is displayed.

4. Click Start.

Master Tool Handle Calibration

5. Open and close the Master Tool a few times.

surgicalscience Page 51


# Page 58

Chapter 5 
 Calibration
 
Page 52 
 
The progress bar should fill to the specific tool range. 
 
6.  Click Save. 
Ascension tab 
The Ascension tab checks the insertion of the scope in the upper and lower GI 
positions.  
1.  Select the Ascension tab. 
 


[TABLE]
| 6.   Click Save.                                                              |
|:------------------------------------------------------------------------------|
| Ascension tab                                                                 |
| The Ascension tab checks the insertion of the scope in the upper and lower GI |
| positions.                                                                    |
| 1.   Select the Ascension tab.                                                |

[OCR]
Chapter 5

Calibration

The progress bar should fill to the specific tool range.

Master Tool Handle Calibration

6. Click Save.

Ascension tab

The Ascension tab checks the insertion of the scope in the upper and lower Gl

positions.

1. Select the Ascension tab.

Sensor

X97 ¥:612:-15

Upper GI Position Calibration

Calibration: (-9.83, 6.51, -0.80)

Insert the scope 30 cm insdie and press Calibrate

leo

Calibrate

Hemisphere
RIGHT

Quality

Insert the scope 25 cm insdie and press Calibrate

Calibration: (-11.14, -5.79, -1.62)

Calibrate

surgicalscience

Page 52


# Page 59

Chapter 5 
 Calibration
 
Page 53 
 
2.  For the Upper GI Position, slowly insert the scope 30 cm (as marked on the scope). 
The Sensor progress bar should fill and at 30 cm, the check box should be filled 
(green). 
3.  If it isn’t filled, click Calibrate.  
4.  Check at 30 cm that the check box is now filled. 
5.  Repeat steps 2-4 for the Lower GI Position but insert the scope only 25 cm. 
6.  Verify the sensor quality for the actual sensor position.  
• 
0-2 = Good 
• 
4-5 = Satisfactory 
• 
10 = Poor 
Advance settings 
The Hemisphere settings is the transmitter hemisphere selection and is set in the 
Advance Settings. Call Surgical Science Technical Support to configure this setting. 
General tab 
The General tab is used to calibrate the haptic force feedback. In addition, it is used to 
check the functionality of the foot pedal, drawer, and LEDs.  
1.  Select the General tab. 
 


[TABLE]
| Chapter 5                                                                        | Calibration                                                                             |
|:---------------------------------------------------------------------------------|:----------------------------------------------------------------------------------------|
|                                                                                  | 2.   For the Upper GI Position, slowly insert the scope 30 cm (as marked on the scope). |
| The Sensor progress bar should fill and at 30 cm, the check box should be filled |                                                                                         |
| (green).                                                                         |                                                                                         |
| 3.                                                                               |                                                                                         |
| If it isn’t filled, click Calibrate.                                             |                                                                                         |
| 4.   Check at 30 cm that the check box is now filled.                            |                                                                                         |
| 5.   Repeat steps 2-4 for the Lower GI Position but insert the scope only 25 cm. |                                                                                         |
| 6.   Verify the sensor quality for the actual sensor position.                   |                                                                                         |

[OCR_TABLE]
Pe ee

[OCR]
Chapter 5 Calibration

2. For the Upper Gl Position, slowly insert the scope 30 cm (as marked on the scope).

The Sensor progress bar should fill and at 30 cm, the check box should be filled
(green).

If it isn’t filled, click Calibrate.

Check at 30 cm that the check box is now filled.

Repeat steps 2-4 for the Lower GI Position but insert the scope only 25 cm.
Verify the sensor quality for the actual sensor position.

e 0-2 = Good

e 4-5 = Satisfactory
° 10 = Poor

OP w

Advance settings

The Hemisphere settings is the transmitter hemisphere selection and is set in the
Advance Settings. Call Surgical Science Technical Support to configure this setting.
General tab

The General tab is used to calibrate the haptic force feedback. In addition, it is used to
check the functionality of the foot pedal, drawer, and LEDs.

1. Select the General tab.

Scope Tools Ascension General Roll Calibration
Force Feedback Pedals
Calibrated Time Examination Left
Middle
Calibrated Full 1.76 sec Half 0.88 sec Empty 2 sec
Right
Dynamic u 0.00 sec Apply
Drawers
Ga
URO
Leds
O Upper GI
@ Lower GI
O Tum off

surgicalscience Page 53


# Page 60

Chapter 5 
 Calibration
 
Page 54 
 
Force feedback 
GI Mentor and BRONCH Mentor use a pump that inflates and deflates at set intervals 
of time. The pump creates friction on the scope preventing it from advancing. 
1.  To calibrate, press Apply and then Full. 
You should feel a strong force feedback when trying to remove or advance the 
scope. 
2.  Click Half. 
You should feel half of the force feedback when trying to remove or advance the 
scope. 
3.  Click Empty. 
You should feel no force feedback on the scope. 
Advance Settings 
You can calibrate the time intervals for inflating and deflating the pump. 
The values are from 0 to 1, where 0 =0ms, 1=1000ms and 0.2=200ms. 
If the time interval is 1000ms: 
• 
The Full button will inflate the pump for 1000ms.  
• 
The Half button will inflate the pump for 500ms.  
• 
The Empty button will open the value for the deflate time. 
1.  Click to select the Advance Settings check box in the Information pane.  
The Force Feedback Advance Settings are displayed. 


[TABLE]
| Chapter 5                                                                          | Calibration                                                                     |
|:-----------------------------------------------------------------------------------|:--------------------------------------------------------------------------------|
| Force feedback                                                                     |                                                                                 |
| GI Mentor and BRONCH Mentor use a pump that inflates and deflates at set intervals |                                                                                 |
| of time. The pump creates friction on the scope preventing it from advancing.      |                                                                                 |
| 1.   To calibrate, press Apply and then Full.                                      |                                                                                 |
|                                                                                    | You should feel a strong force feedback when trying to remove or advance the    |
| scope.                                                                             |                                                                                 |
| 2.   Click Half.                                                                   |                                                                                 |
|                                                                                    | You should feel half of the force feedback when trying to remove or advance the |
| scope.                                                                             |                                                                                 |
| 3.   Click Empty.                                                                  |                                                                                 |
| You should feel no force feedback on the scope.                                    |                                                                                 |
| Advance Settings                                                                   |                                                                                 |
| You can calibrate the time intervals for inflating and deflating the pump.         |                                                                                 |
| The values are from 0 to 1, where 0 =0ms, 1=1000ms and 0.2=200ms.                  |                                                                                 |
| If the time interval is 1000ms:                                                    |                                                                                 |

[OCR]
Chapter 5 Calibration

Force feedback

Gl Mentor and BRONCH Mentor use a pump that inflates and deflates at set intervals
of time. The pump creates friction on the scope preventing it from advancing.

1. To calibrate, press Apply and then Full.

You should feel a strong force feedback when trying to remove or advance the

scope.
2. Click Half.
You should feel half of the force feedback when trying to remove or advance the
scope.
3. Click Empty.

You should feel no force feedback on the scope.

Advance Settings
You can calibrate the time intervals for inflating and deflating the pump.

The values are from 0 to 1, where 0 =Oms, 1=1000ms and 0.2=200ms.
If the time interval is 1000ms:

e The Full button will inflate the pump for 1000ms.
e The Half button will inflate the pump for 500ms.
e The Empty button will open the value for the deflate time.

1. Click to select the Advance Settings check box in the Information pane.
The Force Feedback Advance Settings are displayed.

surgicalscience Page 54


# Page 61

Chapter 5 
 Calibration
 
Page 55 
 
 
2.  Move the slider to configure the Inflate Time and Deflate Time for the pump. 
3.  Click Save. 
These new time intervals will replace those configured registry values for inflating 
and deflating the pump. 
4.  Click Restore if you want to revert back to the inflating and deflating time intervals 
as defined in the registry. 
Pedals 
Press each of the pedals. Check that its check box is filled (green). 
Drawers 
Pull out the GI Mentor drawer (left side of simulator). Check that its check box is filled 
(green). 
LEDs 
1.  Click the Lower GI LED option. Check that the lower GI option on the GI-BRONCH 
interchangeable cartridge lights up. 
2.  Click the Upper GI LED option. Check that the upper GI option on the GI-BRONCH 
interchangeable cartridge lights up. 


[TABLE]
| Chapter 5                                                                                   | Calibration                                                                          |
|:--------------------------------------------------------------------------------------------|:-------------------------------------------------------------------------------------|
| 2.   Move the slider to configure the Inflate Time and Deflate Time for the pump.           |                                                                                      |
| 3.   Click Save.                                                                            |                                                                                      |
|                                                                                             | These new time intervals will replace those configured registry values for inflating |
| and deflating the pump.                                                                     |                                                                                      |
| 4.   Click Restore if you want to revert back to the inflating and deflating time intervals |                                                                                      |
| as defined in the registry.                                                                 |                                                                                      |
| Pedals                                                                                      |                                                                                      |
| Press each of the pedals. Check that its check box is filled (green).                       |                                                                                      |
| Drawers                                                                                     |                                                                                      |
| Pull out the GI Mentor drawer (left side of simulator). Check that its check box is filled  |                                                                                      |
| (green).                                                                                    |                                                                                      |
| LEDs                                                                                        |                                                                                      |
| 1.   Click the Lower GI LED option. Check that the lower GI option on the GI-BRONCH         |                                                                                      |
| interchangeable cartridge lights up.                                                        |                                                                                      |
| 2.   Click the Upper GI LED option. Check that the upper GI option on the GI-BRONCH         |                                                                                      |
| interchangeable cartridge lights up.                                                        |                                                                                      |
|                                                                                             | Page 55                                                                              |

[OCR]
Chapter 5 Calibration

Force Feedback

Calibrated Time Examination

Calibrated Full 176 sec Half 0.88 sec Empty = 1.12sec

Dynamic u 0.00 sec Apply

Time Invervals Calibration (in seconds)

Inflate Time u 1.76 sec
Save Restore
Deflate Time t 1.12 sec
Hardware
Pump Motor
O On
© Of

Move the slider to configure the Inflate Time and Deflate Time for the pump.
Click Save.

These new time intervals will replace those configured registry values for inflating
and deflating the pump.

4. Click Restore if you want to revert back to the inflating and deflating time intervals
as defined in the registry.

oN

Pedals
Press each of the pedals. Check that its check box is filled (green).

Drawers

Pull out the GI Mentor drawer (left side of simulator). Check that its check box is filled
(green).

LEDs

1. Click the Lower GI LED option. Check that the lower GI option on the GI-BRONCH
interchangeable cartridge lights up.

2. Click the Upper GI LED option. Check that the upper GI option on the GI-BRONCH
interchangeable cartridge lights up.

surgicalscience Page 55


# Page 62

Chapter 5 
 Calibration
 
Page 56 
 
Roll calibration tab 
Roll calibration is only done for the GI Mentor scopes. It fixes the alignment of the 
scope to the simulator.  
Both scopes need to be calibrated and every time a colonoscope or duodenoscope is 
replaced, it should be calibrated. 
To calibrate: 
1.  Select the Roll Calibration tab. 
 
 
2.  Position the scope aligned to the simulator as shown in the picture. Rotate the U/D 
knob upward, keeping the L/R knob in its initial position. 
3.  Position the scope aligned to the simulator as shown in the picture below. 


[TABLE]
| Chapter 5                                                                             | Calibration   |
|:--------------------------------------------------------------------------------------|:--------------|
| Roll calibration tab                                                                  |               |
| Roll calibration is only done for the GI Mentor scopes. It fixes the alignment of the |               |
| scope to the simulator.                                                               |               |
| Both scopes need to be calibrated and every time a colonoscope or duodenoscope is     |               |
| replaced, it should be calibrated.                                                    |               |
| To calibrate:                                                                         |               |
| 1.   Select the Roll Calibration tab.                                                 |               |

[OCR]
Chapter 5

Calibration

Roll calibration tab

Roll calibration is only done for the GI Mentor scopes. It fixes the alignment of the
scope to the simulator.

Both scopes need to be calibrated and every time a colonoscope or duodenoscope is
replaced, it should be calibrated.

To calibrate:

1.

Select the Roll Calibration tab.

Roll Calibration

Roll Calibration

Step 1
Rotate the U/D dial upwards while keeping the L/R dial in neutral position
Then place the scope on the simulator as shown in the image. with the tip pointing up:

fy

Step 2
While holding the scope. return the dials to neutral position:

Calibrate
ae Roll Angle: -79.56

Position the scope aligned to the simulator as shown in the picture. Rota
knob upward, keeping the L/R knob in its initial position.

e the U/D

Position the scope aligned to the simulator as shown in the picture below.

surgicalscience

Page 56


# Page 63

Chapter 5 
 Calibration
 
Page 57 
 
 
The scope’s tip should reflect this movement (on the circle illustration). 
4.  Holding the scope steady, return the U/D knob to its initial position as shown in the 
picture below. 
 
The scope’s tip should reflect this movement (12 o’clock on the circle illustration). 
5.  Click Calibrate. 
The scope is now aligned to the simulator. 
Duodenoscope 
Only the calibration on the Scope tab is different than the colonoscope. The options on 
the Tools, Ascension and General tabs do not need to be calibrated if they were done 
for the colonoscope. 
The Roll Calibration needs to be calibrated for the duodenoscope in the same way as 
the colonoscope. 
Scope tab 
The Scope tab calibration for the Duodenoscope is similar to the Colonoscope with the 
addition of Levers calibration and additional wires for the Scope Channel Calibration. 


[TABLE]
| Chapter 5                                                                              | Calibration                                                                                |
|:---------------------------------------------------------------------------------------|:-------------------------------------------------------------------------------------------|
| The scope’s tip should reflect this movement (on the circle illustration).             |                                                                                            |
|                                                                                        | 4.   Holding the scope steady, return the U/D knob to its initial position as shown in the |
| picture below.                                                                         |                                                                                            |
|                                                                                        | The scope’s tip should reflect this movement (12 o’clock on the circle illustration).      |
| 5.   Click Calibrate.                                                                  |                                                                                            |
| The scope is now aligned to the simulator.                                             |                                                                                            |
| Duodenoscope                                                                           |                                                                                            |
|                                                                                        | Only the calibration on the Scope tab is different than the colonoscope. The options on    |
| the Tools, Ascension and General tabs do not need to be calibrated if they were done   |                                                                                            |
| for the colonoscope.                                                                   |                                                                                            |
| The Roll Calibration needs to be calibrated for the duodenoscope in the same way as    |                                                                                            |
| the colonoscope.                                                                       |                                                                                            |
| Scope tab                                                                              |                                                                                            |
|                                                                                        | The Scope tab calibration for the Duodenoscope is similar to the Colonoscope with the      |
| addition of Levers calibration and additional wires for the Scope Channel Calibration. |                                                                                            |
|                                                                                        | Page 57                                                                                    |

[OCR]
Chapter 5 Calibration

The scope’s tip should reflect this movement (on the circle illustration).

4. Holding the scope steady, return the U/D knob to its initial position as shown in the
picture below.

The scope’s tip should reflect this movement (12 o’clock on the circle illustration).
5. Click Calibrate.

The scope is now aligned to the simulator.

Duodenoscope

Only the calibration on the Scope tab is different than the colonoscope. The options on
the Tools, Ascension and General tabs do not need to be calibrated if they were done
for the colonoscope.

The Roll Calibration needs to be calibrated for the duodenoscope in the same way as
the colonoscope.
Scope tab

The Scope tab calibration for the Duodenoscope is similar to the Colonoscope with the
addition of Levers calibration and additional wires for the Scope Channel Calibration.

surgicalscience Page 57


# Page 64

Chapter 5 
 Calibration
 
Page 58 
 
1.  Select the Scope tab. 
 
2.  Connect the Duodenoscope to its port (C). 
The Duodenoscope’s channel (C) is selected from the Channel list.  
3.  Insert each of the wires into its scope channel and verify that the Inside box is 
filled green. 
 
4.  If not, the channel needs to be calibrated. Click the Calibrate button for the 
specific channel. 
The Duodenoscope Channel Calibration window is displayed for the specific 
channel.  
5.  Remove the wire from the channel and press Start.  


[TABLE]
| Chapter 5                                                                         |
|  Calibration                                                                      |
|:----------------------------------------------------------------------------------|
| 1.   Select the Scope tab.                                                        |
| 2.   Connect the Duodenoscope to its port (C).                                    |
| The Duodenoscope’s channel (C) is selected from the Channel list.                 |
| 3.                                                                                |
| Insert each of the wires into its scope channel and verify that the Inside box is |
| filled green.                                                                     |
| 4.                                                                                |
| If not, the channel needs to be calibrated. Click the Calibrate button for the    |
| specific channel.                                                                 |
| The Duodenoscope Channel Calibration window is displayed for the specific         |
| channel.                                                                          |
| 5.   Remove the wire from the channel and press Start.                            |
| Page 58                                                                           |

[OCR]
Chapter 5 Calibration

1. Select the Scope tab.
scope |_ Toots] Ascension J Gonerat_ J Rot\catbraton II

Scope Channels Calibration

Inside

Main Wire (white) ]
Pushing Wire (blue) i | Calibrate

Guide Wire (red) ] Calibrate

Scope Buttons Lever Calibration
Pushed

Optic
Optic Press
Suction

F

c

v

2. Connect the Duodenoscope to its port (C).

The Duodenoscope’s channel (C) is selected from the Channel list.
3. Insert each of the wires into its scope channel and verify that the Inside box is

filled green.
Scope Channels Calibration
Inside
Main Wire (white) I Ei

4. If not, the channel needs to be calibrated. Click the Calibrate button for the
specific channel.

The Duodenoscope Channel Calibration window is displayed for the specific
channel.

5. Remove the wire from the channel and press Start.

surgicalscience Page 58


# Page 65

Chapter 5 
 Calibration
 
Page 59 
 
 
6.  Insert the wire all the way into the channel. 
 
The Channel bar fills up. 
7.  Click Save. 
8.  Repeat steps 4-8 for all the colonoscope’s channels.  
9.  Check each of the colonoscope’s buttons by pressing each button (Suction, F, C 
and V buttons). 
The Pushed box should be filled green. 
10.  To calibrate the scope lever, click Calibrate.  
The Duodenoscope Lever Calibration window is displayed.  


[TABLE]
| Chapter 5                                                                           | Calibration   |
|:------------------------------------------------------------------------------------|:--------------|
| 6.                                                                                  |               |
| Insert the wire all the way into the channel.                                       |               |
| The Channel bar fills up.                                                           |               |
| 7.   Click Save.                                                                    |               |
| 8.   Repeat steps 4-8 for all the colonoscope’s channels.                           |               |
| 9.   Check each of the colonoscope’s buttons by pressing each button (Suction, F, C |               |
| and V buttons).                                                                     |               |
| The Pushed box should be filled green.                                              |               |
| 10.  To calibrate the scope lever, click Calibrate.                                 |               |
| The Duodenoscope Lever Calibration window is displayed.                             |               |
|                                                                                     | Page 59       |

[OCR]
Chapter 5 Calibration

Duodenoscope - Guide Channel Calibration (Red)

6. Insert the wire all the way into the channel.
Duodenoscope - Guide Channel Calibration (Red)

The Channel bar fills up.

7. Click Save.

8. Repeat steps 4-8 for all the colonoscope’s channels.

9. Check each of the colonoscope’s buttons by pressing each button (Suction, F, C
and V buttons).
The Pushed box should be filled green.

10. To calibrate the scope lever, click Calibrate.

The Duodenoscope Lever Calibration window is displayed.

surgicalscience Page 59


# Page 66

Chapter 5 
 Calibration
 
Page 60 
 
 
11.  Click Start. 
12.  Move the duodenoscope’s lever up and down a few times. 
The progress bar should be completed filled. 
 
13.  Click Save. 
BRONCH Mentor calibration 
1.  Select the BRONCH platform from the Select Platform list. 
Scope tab 
The Scope tab is used to verify that when the BRONCH wire and handles are inserted 
in the scope channels, the system identifies them. If not, the channels need to be 
calibrated. In addition, the tab is used to verify if the scope buttons are identified when 
pressed. 
1.  Select the Scope tab. 
2.  Connect the Bronchoscope to its port (C). 


[TABLE]
| Chapter 5                                                                          | Calibration                                                                                 |
|:-----------------------------------------------------------------------------------|:--------------------------------------------------------------------------------------------|
| 11.   Click Start.                                                                 |                                                                                             |
| 12.  Move the duodenoscope’s lever up and down a few times.                        |                                                                                             |
| The progress bar should be completed filled.                                       |                                                                                             |
| 13.  Click Save.                                                                   |                                                                                             |
| BRONCH Mentor calibration                                                          |                                                                                             |
| 1.   Select the BRONCH platform from the Select Platform list.                     |                                                                                             |
| Scope tab                                                                          |                                                                                             |
| The Scope tab is used to verify that when the BRONCH wire and handles are inserted |                                                                                             |
| in the scope channels, the system identifies them. If not, the channels need to be |                                                                                             |
|                                                                                    | calibrated. In addition, the tab is used to verify if the scope buttons are identified when |
| pressed.                                                                           |                                                                                             |
| 1.   Select the Scope tab.                                                         |                                                                                             |
| 2.   Connect the Bronchoscope to its port (C).                                     |                                                                                             |
|                                                                                    | Page 60                                                                                     |

[OCR]
Chapter 5 Calibration

Duodenoscope - Lever Calibration

11. Click Start.
12. Move the duodenoscope’s lever up and down a few times.

The progress bar should be completed filled.

Duodenoscope - Lever Calibration

13. Click Save.

BRONCH Mentor calibration

1. Select the BRONCH platform from the Select Platform list.
Scope tab

The Scope tab is used to verify that when the BRONCH wire and handles are inserted
in the scope channels, the system identifies them. If not, the channels need to be
calibrated. In addition, the tab is used to verify if the scope buttons are identified when
pressed.

1. Select the Scope tab.
2. Connect the Bronchoscope to its port (C).

surgicalscience Page 60


# Page 67

Chapter 5 
 Calibration
 
Page 61 
 
The Bronchoscope’s channel (C) is selected from the Channel list.  
3.  Insert the white wire into its scope channel and verify that the Inside box is filled 
green. 
 
4.  If not, the channel needs to be calibrated. Click the Calibrate button for the 
specific channel. 
The Bronchoscope Channel Calibration window is displayed for the specific 
channel.  
5.  Remove the wire from the channel and press Start.  
 
6.  Insert the wire all the way into the channel. 
 
The Channel bar fills up. 
7.  Click Save. 


[TABLE]
| Chapter 5                                                                             |
|  Calibration                                                                          |
|:--------------------------------------------------------------------------------------|
| The Bronchoscope’s channel (C) is selected from the Channel list.                     |
| 3.                                                                                    |
| Insert the white wire into its scope channel and verify that the Inside box is filled |
| green.                                                                                |
| 4.                                                                                    |
| If not, the channel needs to be calibrated. Click the Calibrate button for the        |
| specific channel.                                                                     |
| The Bronchoscope Channel Calibration window is displayed for the specific             |
| channel.                                                                              |
| 5.   Remove the wire from the channel and press Start.                                |
| 6.                                                                                    |
| Insert the wire all the way into the channel.                                         |
| The Channel bar fills up.                                                             |
| 7.   Click Save.                                                                      |
| Page 61                                                                               |

[OCR]
Chapter 5

Calibration

6.

7.

The Bronchoscope’s channel (C) is selected from the Channel list.

Insert the white wire into its scope channel and verify that the Inside box is filled

green.
Scope
Scope Channels Calibration
Inside
Main Wire (white) I B

If not, the channel needs to be calibrated. Click the Calibrate button for the
specific channel.

The Bronchoscope Channel Calibration window is displayed for the specific
channel.

Remove the wire from the channel and press Start.

Bronchoscope - Main Channel Calibration

Insert the wire all the way into the channel.
Bronchoscope - Main Channel Calibration

The Channel bar fills up.
Click Save.

surgicalscience

Page 61


# Page 68

Chapter 5 
 Calibration
 
Page 62 
 
8.  Repeat steps 4-8 for the EBUS Needle’s channel and the Syringe Channel when 
inserting the EBUS needle and syringe into their respective channels.  
9.  Check each of the bronchoscope’s buttons by pressing each button (Suction, F, C 
and V buttons). 
The Pushed box should be filled green. 
 
Advance settings 
The Advance Settings calibration for the bronchoscope. To calibrate, see  Advance 
settings on page 50. 
Tools tab 
The Tools tab is used to calibrate the tool handles: Master Tool (GIB MT), EBUS 
Needle, EBUS Sheath and Syringe.  
1.  Select the Tools tab. 


[TABLE]
| Chapter 5                                                                            | Calibration   |
|:-------------------------------------------------------------------------------------|:--------------|
| 8.   Repeat steps 4-8 for the EBUS Needle’s channel and the Syringe Channel when     |               |
| inserting the EBUS needle and syringe into their respective channels.                |               |
| 9.   Check each of the bronchoscope’s buttons by pressing each button (Suction, F, C |               |
| and V buttons).                                                                      |               |
| The Pushed box should be filled green.                                               |               |
| Advance settings                                                                     |               |
| The Advance Settings calibration for the bronchoscope. To calibrate, see  Advance    |               |
| settings on page 50.                                                                 |               |
| Tools tab                                                                            |               |
| The Tools tab is used to calibrate the tool handles: Master Tool (GIB MT), EBUS      |               |
| Needle, EBUS Sheath and Syringe.                                                     |               |
| 1.   Select the Tools tab.                                                           |               |
|                                                                                      | Page 62       |

[OCR]
Chapter 5

Calibration

8. Repeat steps 4-8 for the EBUS Needle’s channel and the Syringe Channel when

inserting the EBUS needle and syringe into their respective channels.

9. Check each of the bronchoscope’s buttons by pressing each button (Suction, F, C

and V buttons).
The Pushed box should be filled green.

Scope Buttons

Optic

Optic Press
Suction

F

Cc

Vv

Pushed

Advance settings

The Advance Settings calibration for the bronchoscope. To calibrate, see Advance

settings on page 50.
Tools tab

The Tools tab is used to calibrate the tool handles: Master Tool (GIB MT), EBUS

Needle, EBUS Sheath and Syringe.
1. Select the Tools tab.

surgicalscience

Page 62


# Page 69

Chapter 5 
 Calibration
 
Page 63 
 
 
2.  Make sure the Master Tool is connected to its port on the right side of the 
simulator. 
3.  Click Calibrate.  
The Master Tool Handle Calibration window is displayed. 
4.  Click Start. 
 
5.  Open and close the Master Tool a few times. 
The progress bar should fill to the specific tool range. 


[TABLE]
| Chapter 5                                                                        | Calibration   |
|:---------------------------------------------------------------------------------|:--------------|
| 2.   Make sure the Master Tool is connected to its port on the right side of the |               |
| simulator.                                                                       |               |
| 3.   Click Calibrate.                                                            |               |
| The Master Tool Handle Calibration window is displayed.                          |               |
| 4.   Click Start.                                                                |               |
| 5.   Open and close the Master Tool a few times.                                 |               |
| The progress bar should fill to the specific tool range.                         |               |
|                                                                                  | Page 63       |

[OCR]
Chapter 5 Calibration

Tools
Tool Handles Calibration
EBUS Sheath I Calibrate
EBUS Needle 1 Calibrate
‘Syringe | Calibrate
Forceps I Calibrate
ie Mt re |

2. Make sure the Master Tool is connected to its port on the right side of the
simulator.

3. Click Calibrate.
The Master Tool Handle Calibration window is displayed.

4. Click Start.

Master Tool Handle Calibration

5. Open and close the Master Tool a few times.
The progress bar should fill to the specific tool range.

surgicalscience Page 63


# Page 70

Chapter 5 
 Calibration
 
Page 64 
 
 
6.  Click Save. 
7.  Repeat steps 2-6 for the EBUS needle, EBUS sheath and the syringe.  
Ascension tab 
The Ascension tab checks the insertion functionality of the bronchoscope.  
1.  Select the Ascension tab. 
 
2.  On the GI-BRONCH interchangeable cartridge, position the tip of the 
bronchoscope in the niche on the top of the oral-nasal orifice. 


[TABLE]
| 6.   Click Save.                                                          |
|:--------------------------------------------------------------------------|
| 7.   Repeat steps 2-6 for the EBUS needle, EBUS sheath and the syringe.   |
| Ascension tab                                                             |
| The Ascension tab checks the insertion functionality of the bronchoscope. |
| 1.   Select the Ascension tab.                                            |

[OCR]
Chapter 5

Calibration

Master Tool Handle Calibration

6. Click Save.

7. Repeat steps 2-6 for the EBUS needle, EBUS sheath and the syringe.

Ascension tab

The Ascension tab checks the insertion functionality of the bronchoscope.

1. Select the Ascension tab.

[Scope Fests asconsion JL Genera Ret atiroion

Sensor

Hemisphere
—
X: 24.0 Y:-14.5 Z:-143

Place the tip of the Bronchoscope in the niche on top of the nose and press Calibrate.

Calibrate

2. On the GI-BRONCH interchangeable cartridge, position the tip of the

bronchoscope in the niche on the top of the oral-nasal orifice.

surgicalscience

Page 64


# Page 71

Chapter 5 
 Calibration
 
Page 65 
 
The Sensor progress bar should fill and the check box should be filled (green). 
3.  If it isn’t filled, click Calibrate.  
4.  Check that the check box is now filled. 
5.  Verify the sensor quality for the actual sensor position.  
• 
0-2 = Good 
• 
4-5 = Satisfactory 
• 
10 = Poor 
Advance settings 
The Hemisphere settings is the transmitter hemisphere selection and is set in the 
Advance Settings. Call Surgical Science Technical Support to configure this setting. 
General tab 
The General tab is used to calibrate the haptic force feedback. In addition, it is used to 
check the functionality of the foot pedals and LED.  
The calibration is performed in the same way as for the GI Mentor (see General tab on 
page 53). 
1.  Select the General tab. 
 


[TABLE]
| Chapter 5                                                                                  | Calibration   |
|:-------------------------------------------------------------------------------------------|:--------------|
| The Sensor progress bar should fill and the check box should be filled (green).            |               |
| 3.                                                                                         |               |
| If it isn’t filled, click Calibrate.                                                       |               |
| 4.   Check that the check box is now filled.                                               |               |
| 5.   Verify the sensor quality for the actual sensor position.                             |               |
| 0-2 = Good                                                                                 |               |
| •                                                                                          |               |
| 4-5 = Satisfactory                                                                         |               |
| •                                                                                          |               |
| 10 = Poor                                                                                  |               |
| •                                                                                          |               |
| Advance settings                                                                           |               |
| The Hemisphere settings is the transmitter hemisphere selection and is set in the          |               |
| Advance Settings. Call Surgical Science Technical Support to configure this setting.       |               |
| General tab                                                                                |               |
| The General tab is used to calibrate the haptic force feedback. In addition, it is used to |               |
| check the functionality of the foot pedals and LED.                                        |               |
| The calibration is performed in the same way as for the GI Mentor (see General tab on      |               |
| page 53).                                                                                  |               |
| 1.   Select the General tab.                                                               |               |
|                                                                                            | Page 65       |

[OCR]
Chapter 5 Calibration

The Sensor progress bar should fill and the check box should be filled (green).
If it isn’t filled, click Calibrate.

Check that the check box is now filled.

Verify the sensor quality for the actual sensor position.

e 0-2 = Good

e 4-5 = Satisfactory
° 10 = Poor

APH

Advance settings

The Hemisphere settings is the transmitter hemisphere selection and is set in the
Advance Settings. Call Surgical Science Technical Support to configure this setting.

General tab
The General tab is used to calibrate the haptic force feedback. In addition, it is used to
check the functionality of the foot pedals and LED.

The calibration is performed in the same way as for the GI Mentor (see General tab on
page 53).

1. Select the General tab.

Select Platform Channel

Force Feedback Pedals
Calibrated Time Examination Left
Middle
Calibrated Full | 2.95sec Half | 1.48sec Empty | 1.50sec
Right
Dynamic u 0.00 sec Apply
Drawers
Gl
URO
Leds
@© Bronch
O Tum off

surgicalscience Page 65


# Page 72

Chapter 5 
 Calibration
 
Page 66 
 
Roll calibration tab 
There is no roll calibration for the bronchoscope.  
URO Mentor calibration 
1.  Select the URO platform from the Select Platform list. 
There are 3 scopes that need to be calibrated, each are connected to a different 
port. 
• 
Rigid Ureteroscope – port A 
• 
Rigid Cystoscope – port B 
• 
Flexible Ureteroscope – port C 
Scope tab 
The Scope tab is used to verify that when the URO wires are inserted in the scope 
channels, the system identifies them. If not, the channels need to be calibrated. In 
addition, the tab is used to verify that the scope buttons are identified when pressed. 
1.  Select the Scope tab. 


[TABLE]
| Chapter 5                  |                                                                                         | Calibration   |
|:---------------------------|:----------------------------------------------------------------------------------------|:--------------|
| Roll calibration tab       |                                                                                         |               |
|                            | There is no roll calibration for the bronchoscope.                                      |               |
| URO Mentor calibration     |                                                                                         |               |
|                            | 1.   Select the URO platform from the Select Platform list.                             |               |
|                            | There are 3 scopes that need to be calibrated, each are connected to a different        |               |
| port.                      |                                                                                         |               |
| •                          | Rigid Ureteroscope – port A                                                             |               |
| •                          | Rigid Cystoscope – port B                                                               |               |
| •                          | Flexible Ureteroscope – port C                                                          |               |
| Scope tab                  |                                                                                         |               |
|                            | The Scope tab is used to verify that when the URO wires are inserted in the scope       |               |
|                            | channels, the system identifies them. If not, the channels need to be calibrated. In    |               |
|                            | addition, the tab is used to verify that the scope buttons are identified when pressed. |               |
| 1.   Select the Scope tab. |                                                                                         |               |
|                            |                                                                                         | Page 66       |

[OCR]
Chapter 5 Calibration

Roll calibration tab

There is no roll calibration for the bronchoscope.

URO Mentor calibration

1. Select the URO platform from the Select Platform list.
There are 3 scopes that need to be calibrated, each are connected to a different
port.

e Rigid Ureteroscope — port A
e Rigid Cystoscope - port B
e Flexible Ureteroscope — port C

Scope tab
The Scope tab is used to verify that when the URO wires are inserted in the scope

channels, the system identifies them. If not, the channels need to be calibrated. In
addition, the tab is used to verify that the scope buttons are identified when pressed.

1. Select the Scope tab.

surgicalscience Page 66


# Page 73

Chapter 5 
 Calibration
 
Page 67 
 
 
2.  Select the relevant scope channel from the Channel list: 
• 
Rigid Ureteroscope – Channel A 
 
• 
Rigid Cystoscope – Channel B 
 
• 
Flexible Ureteroscope – Channel C 
 
3.  Insert the relevant wire into its scope’s channel and verify that the Inside box is 
filled green. 


[TABLE]
| Chapter 5                                                                           |
|  Calibration                                                                        |
|:------------------------------------------------------------------------------------|
| 2.   Select the relevant scope channel from the Channel list:                       |
| Rigid Ureteroscope – Channel A                                                      |
| •                                                                                   |
| Rigid Cystoscope – Channel B                                                        |
| •                                                                                   |
| Flexible Ureteroscope – Channel C                                                   |
| •                                                                                   |
| 3.                                                                                  |
| Insert the relevant wire into its scope’s channel and verify that the Inside box is |
| filled green.                                                                       |
| Page 67                                                                             |

[OCR]
Chapter 5 Calibration

Select Platform Channel

Scope Channels Calibration
Inside
Main Wire (white) _

Uretero Wire (long) ] Calibrate

Cysto Wire (short) 1 Calibrate

Scope Buttons
Pushed
Optic

Optic Press

Suction Ba
F

c

v

2. Select the relevant scope channel from the Channel list:

e Rigid Ureteroscope — Channel A

Select Platform Channet:

Rigid Ureteroscope

Scope Channels Calibration

e Rigid Cystoscope — Channel B
Select Platform: Channel

Scope Channels Calibration

3. Insert the relevant wire into its scope’s channel and verify that the Inside box is
filled green.
surgicalscience

Page 67


# Page 74

Chapter 5 
 Calibration
 
Page 68 
 
• 
Rigid Ureteroscope – Uretero Wire (long wire) 
 
• 
Rigid Cystoscope – Cysto Wire (short wire) 
 
• 
Flexible Ureteroscope – Main Wire (white wire) 
 
4.  If not, the channel needs to be calibrated. Click the Calibrate button for the 
specific channel. 
The Rigid Cystoscope - Main Channel Calibration window is displayed for the 
specific channel.  
5.  Remove the wire from the channel and press Start.  


[TABLE]
| Chapter 5                                                                      |
|  Calibration                                                                   |
|:-------------------------------------------------------------------------------|
| Rigid Ureteroscope – Uretero Wire (long wire)                                  |
| •                                                                              |
| Rigid Cystoscope – Cysto Wire (short wire)                                     |
| •                                                                              |
| Flexible Ureteroscope – Main Wire (white wire)                                 |
| •                                                                              |
| 4.                                                                             |
| If not, the channel needs to be calibrated. Click the Calibrate button for the |
| specific channel.                                                              |
| The Rigid Cystoscope - Main Channel Calibration window is displayed for the    |
| specific channel.                                                              |
| 5.   Remove the wire from the channel and press Start.                         |
| Page 68                                                                        |

[OCR]
Chapter 5 Calibration

e Rigid Ureteroscope — Uretero Wire (long wire)

Scope
Scope Channels Calibration

Inside
| Calibrate

Main Wire (white) 4095 1

Uretero Wire (long) 1475 I HB Calibrate

e Rigid Cystoscope — Cysto Wire (short wire)
Scope

Scope Channels Calibration

Inside
Main Wire (white) 4095 | Calibrate
Uretero Wire (long) 4095 ] Calibrate
Cysto Wire (short) = 1285 I Hi “Calibrate

e Flexible Ureteroscope — Main Wire (white wire)

Scope

Scope Channels Calibration

Inside

Main Wire (white) I | |

4. If not, the channel needs to be calibrated. Click the Calibrate button for the
specific channel.
The Rigid Cystoscope - Main Channel Calibration window is displayed for the
specific channel.

5. Remove the wire from the channel and press Start.

surgicalscience Page 68


# Page 75

Chapter 5 
 Calibration
 
Page 69 
 
 
6.  Insert the wire all the way into the channel. 
 
The Channel bar fills up. 
7.  Click Save. 
8.  Repeat steps 5-8 for the Rigid Ureteroscope and Flexible Ureteroscope.  
9.  Check the Flexible Ureteroscope’s buttons by pressing each button (Suction, F, C 
and V buttons). 
The Pushed box should be filled green. 
Note: There is no scope button for the Rigid Ureteroscope and Rigid Cystoscope. 


[TABLE]
| Chapter 5                                                                             | Calibration   |
|:--------------------------------------------------------------------------------------|:--------------|
| 6.                                                                                    |               |
| Insert the wire all the way into the channel.                                         |               |
| The Channel bar fills up.                                                             |               |
| 7.   Click Save.                                                                      |               |
| 8.   Repeat steps 5-8 for the Rigid Ureteroscope and Flexible Ureteroscope.           |               |
| 9.   Check the Flexible Ureteroscope’s buttons by pressing each button (Suction, F, C |               |
| and V buttons).                                                                       |               |
| The Pushed box should be filled green.                                                |               |
| Note: There is no scope button for the Rigid Ureteroscope and Rigid Cystoscope.       |               |
|                                                                                       | Page 69       |

[OCR]
Chapter 5 Calibration

Rigid Cystoscope - Main Channel Calibration

6. Insert the wire all the way into the channel.

Rigid Cystoscope - Main Channel Calibration

The Channel bar fills up.

Click Save.

Repeat steps 5-8 for the Rigid Ureteroscope and Flexible Ureteroscope.

Check the Flexible Ureteroscope’s buttons by pressing each button (Suction, F, C
and V buttons).

The Pushed box should be filled green.

© @N

Note: There is no scope button for the Rigid Ureteroscope and Rigid Cystoscope.

surgicalscience Page 69


# Page 76

Chapter 5 
 Calibration
 
Page 70 
 
 
Advance settings 
The Advance Settings calibration for the bronchoscope. To calibrate, see  Advance 
settings on page 50. 
Tools tab 
The Tools tab is used to calibrate the tool handles: Master Tool (GIB MT) and Forceps.  
1.  Select the Tools tab. 


[TABLE]
| Advance settings                                                                       |
|:---------------------------------------------------------------------------------------|
| The Advance Settings calibration for the bronchoscope. To calibrate, see  Advance      |
| settings on page 50.                                                                   |
| Tools tab                                                                              |
| The Tools tab is used to calibrate the tool handles: Master Tool (GIB MT) and Forceps. |
| 1.   Select the Tools tab.                                                             |

[OCR]
Chapter 5 Calibration

Scope Buttons
Pushed

Optic

Optic Press

Suction fel
F

Cc

Vv

Advance settings

The Advance Settings calibration for the bronchoscope. To calibrate, see Advance
settings on page 50.

Tools tab

The Tools tab is used to calibrate the tool handles: Master Tool (GIB MT) and Forceps.
1. Select the Tools tab.

surgicalscience Page 70


# Page 77

Chapter 5 
 Calibration
 
Page 71 
 
 
2.  Make sure the Master Tool is connected to its port on the right side of the 
simulator. 
3.  Click Calibrate.  
The Master Tool Handle Calibration window is displayed. 
4.  Click Start. 
 
5.  Open and close the Master Tool a few times. 
The progress bar should fill to the specific tool range. 


[TABLE]
| Chapter 5                                                                        | Calibration   |
|:---------------------------------------------------------------------------------|:--------------|
| 2.   Make sure the Master Tool is connected to its port on the right side of the |               |
| simulator.                                                                       |               |
| 3.   Click Calibrate.                                                            |               |
| The Master Tool Handle Calibration window is displayed.                          |               |
| 4.   Click Start.                                                                |               |
| 5.   Open and close the Master Tool a few times.                                 |               |
| The progress bar should fill to the specific tool range.                         |               |
|                                                                                  | Page 71       |

[OCR]
Chapter 5

Calibration

ee ee a a |

Tool Handles Calibration

EBUS Sheath

EBUS Needle

Forceps

GIBMT

I Calibrate

L Calibrate

| Calibrate

[ Calibrate
re |

2. Make sure the Master Tool is connected to its port on the right side of the

simulator.
3. Click Calibrate.

The Master Tool Handle Calibration window is displayed.

4. Click Start.

Master Tool Handle Calibration

5. Open and close the Master Tool a few times.

The progress bar should fill to the specific tool range.

surgicalscience

Page 71


# Page 78

Chapter 5 
 Calibration
 
Page 72 
 
 
6.  Click Save. 
7.  Repeat steps 2-6 for the Forceps tool. 
Ascension tab 
The Ascension tab checks the insertion functionality of each of the URO Mentor 
scopes in the simulator.  
1.  Select the Ascension tab. 
 
2.  Position the scope at the base of the simulated penis. 


[TABLE]
| 6.   Click Save.                                                               |
|:-------------------------------------------------------------------------------|
| 7.   Repeat steps 2-6 for the Forceps tool.                                    |
| Ascension tab                                                                  |
| The Ascension tab checks the insertion functionality of each of the URO Mentor |
| scopes in the simulator.                                                       |
| 1.   Select the Ascension tab.                                                 |

[OCR]
Chapter 5 Calibration

Master Tool Handle Calibration

6. Click Save.
7. Repeat steps 2-6 for the Forceps tool.

Ascension tab

The Ascension tab checks the insertion functionality of each of the URO Mentor
scopes in the simulator.

1. Select the Ascension tab.

Ascension

Sensor

Hemisphere Quality

X-25.1 ¥:145 Z:120

URO Position Calibration

Hold the Flexible Ureteroscope on top of the penis and press Calibrate.

Calibrate

2. Position the scope at the base of the simulated penis.

surgicalscience Page 72


# Page 79

Chapter 5 
 Calibration
 
Page 73 
 
The Sensor progress bar should fill and the check box should be filled (green). 
 
3.  If it isn’t filled, click Calibrate.  
 


[TABLE]
| Chapter 5                                                                       | Calibration   |
|:--------------------------------------------------------------------------------|:--------------|
| The Sensor progress bar should fill and the check box should be filled (green). |               |
| 3.                                                                              |               |
| If it isn’t filled, click Calibrate.                                            |               |
|                                                                                 | Page 73       |

[OCR]
Chapter 5

Calibration

The Sensor progress bar should fill and the check box should be filled (green).

Sensor

Hemisphere Quality

FRONT 128

X00 ¥:0.0 2:00

URO Position Calibration

Hold the Flexible Ureteroscope on top of the penis and press Calibrate

If it isn’t filled, click Calibrate.

Ascension

Hemisphere Quality

FRONT 1

K64Y25 214

URO Position Calibration

Hold the Flexible Ureteroscope on top of the penis and press Calibrate.

surgicalscience

Page 73


# Page 80

Chapter 5 
 Calibration
 
Page 74 
 
4.  Check that the check box is now filled. 
5.  Repeat steps 2-4 for all the scopes. 
6.  Verify the sensor quality for the actual sensor position for each scope.  
• 
0-2 = Good 
• 
4-5 = Satisfactory 
• 
10 = Poor 
Advance settings 
The Hemisphere settings is the transmitter hemisphere selection and is set in the 
Advance Settings. Call Surgical Science Technical Support to configure this setting. 
General tab 
The General tab is used to check the functionality of the foot pedal, drawer, and LEDs.  
1.  Select the General tab. 
 
Force feedback 
There is no haptic force feedback for the URO Mentor. 
Pedals 
Press each of the pedals. Check that its check box is filled (green). 


[TABLE]
| Chapter 5                                    |                                                                                         | Calibration   |
|:---------------------------------------------|:----------------------------------------------------------------------------------------|:--------------|
| 4.   Check that the check box is now filled. |                                                                                         |               |
| 5.   Repeat steps 2-4 for all the scopes.    |                                                                                         |               |
|                                              | 6.   Verify the sensor quality for the actual sensor position for each scope.           |               |
| •                                            | 0-2 = Good                                                                              |               |
| •                                            | 4-5 = Satisfactory                                                                      |               |
| •                                            | 10 = Poor                                                                               |               |
| Advance settings                             |                                                                                         |               |
|                                              | The Hemisphere settings is the transmitter hemisphere selection and is set in the       |               |
|                                              | Advance Settings. Call Surgical Science Technical Support to configure this setting.    |               |
| General tab                                  |                                                                                         |               |
|                                              | The General tab is used to check the functionality of the foot pedal, drawer, and LEDs. |               |
| 1.   Select the General tab.                 |                                                                                         |               |
| Force feedback                               |                                                                                         |               |
|                                              | There is no haptic force feedback for the URO Mentor.                                   |               |
| Pedals                                       |                                                                                         |               |
|                                              | Press each of the pedals. Check that its check box is filled (green).                   |               |
|                                              |                                                                                         | Page 74       |

[OCR]
Chapter 5 Calibration

4. Check that the check box is now filled.
5. Repeat steps 2-4 for all the scopes.
6. Verify the sensor quality for the actual sensor position for each scope.

° 0-2 = Good

e 4-5 = Satisfactory

° 10 = Poor
Advance settings

The Hemisphere settings is the transmitter hemisphere selection and is set in the
Advance Settings. Call Surgical Science Technical Support to configure this setting.

General tab

The General tab is used to check the functionality of the foot pedal, drawer, and LEDs.
1. Select the General tab.

Scope Tools Ascension General | | Roll Calibration ll

Pedals

Left
Middle
Right

Drawers

HB uro

Leds

@ uRO
O Tum off

Force feedback
There is no haptic force feedback for the URO Mentor.

Pedals
Press each of the pedals. Check that its check box is filled (green).

surgicalscience Page 74


# Page 81

Chapter 5 
 Calibration
 
Page 75 
 
Drawers 
Pull out the URO Mentor drawer (right side of simulator). Check that its check box is 
filled (green). 
LEDs 
Click the URO option on the General tab. Check that the URO LED on the URO Mentor 
interchangeable cartridge lights up. 
Roll calibration tab 
There is no roll calibration for the URO Mentor scopes. 
TURP modules calibration 
1.  Select the TURP platform from the Select Platform list. 
There is one scope, resectoscope that needs to be calibrated, which is connected 
to port C. 
Scope tab 
The Scope tab is used to calibrate the components of the resectoscope handle – 
working element and Inflow and Outflow valves. In addition, the tab is used to verify 
the camera’s buttons and the Focus and Zoom rings . 
1.  Select the Scope tab. 


[TABLE]
| Chapter 5                                                                             | Calibration   |
|:--------------------------------------------------------------------------------------|:--------------|
| Drawers                                                                               |               |
| Pull out the URO Mentor drawer (right side of simulator). Check that its check box is |               |
| filled (green).                                                                       |               |
| LEDs                                                                                  |               |
| Click the URO option on the General tab. Check that the URO LED on the URO Mentor     |               |
| interchangeable cartridge lights up.                                                  |               |
| Roll calibration tab                                                                  |               |
| There is no roll calibration for the URO Mentor scopes.                               |               |
| TURP modules calibration                                                              |               |
| 1.   Select the TURP platform from the Select Platform list.                          |               |

[OCR]
Chapter 5 Calibration

Drawers

Pull out the URO Mentor drawer (right side of simulator). Check that its check box is
filled (green).

LEDs

Click the URO option on the General tab. Check that the URO LED on the URO Mentor
interchangeable cartridge lights up.

Roll calibration tab

There is no roll calibration for the URO Mentor scopes.

TURP modules calibration

1. Select the TURP platform from the Select Platform list.

There is one scope, resectoscope that needs to be calibrated, which is connected
to port C.

Scope tab
The Scope tab is used to calibrate the components of the resectoscope handle —

working element and Inflow and Outflow valves. In addition, the tab is used to verify
the camera’s buttons and the Focus and Zoom rings .

1. Select the Scope tab.

surgicalscience Page 75


# Page 82

Chapter 5 
 Calibration
 
Page 76 
 
 
2.  Connect the Resectoscope to its port (C). 
The Resectoscope’s channel (C) is selected from the Channel list.  
3.  Click Calibrate in the Handle row. 
4.  In the Resectoscope Tool Handle Calibration window, click Start.  
 
5.  Open and Close the working element.  
The line moves from right to left (showing the minimum to maximum values). 


[TABLE]
| Chapter 5                                                                  | Calibration   |
|:---------------------------------------------------------------------------|:--------------|
| 2.   Connect the Resectoscope to its port (C).                             |               |
| The Resectoscope’s channel (C) is selected from the Channel list.          |               |
| 3.   Click Calibrate in the Handle row.                                    |               |
| 4.                                                                         |               |
| In the Resectoscope Tool Handle Calibration window, click Start.           |               |
| 5.   Open and Close the working element.                                   |               |
| The line moves from right to left (showing the minimum to maximum values). |               |
|                                                                            | Page 76       |

[OCR]
Chapter 5 Calibration

Select Platfom: gy Channel

Resectoscope Calibration
Camera

2. Connect the Resectoscope to its port (C).

The Resectoscope’s channel (C) is selected from the Channel list.

3. Click Calibrate in the Handle row.
4. Inthe Resectoscope Tool Handle Calibration window, click Start.

Resectoscope Tool Handle Calibration

5. Open and Close the working element.

The line moves from right to left (showing the minimum to maximum values).

surgicalscience Page 76


# Page 83

Chapter 5 
 Calibration
 
Page 77 
 
6.  Click Save and then Close. 
7.  Click Calibrate in the Valve In row. 
8.  In the Resectoscope Valve Calibration window, click Start.  
 
9.  Open and Close the inflow valve.  
The line moves from right to left (showing the minimum to maximum values). 
10.  Click Save and then Close. 
11.  Click Calibrate in the Valve Out row. 
12.  In the Resectoscope Valve Calibration window, click Start.  
 
13.  Open and Close the outflow valve.  
The line moves from right to left (showing the minimum to maximum values). 
14.  Click Save and then Close. 
Resectoscope Camera 
1.  Under Camera, click Calibrate in the Zoom row. 
2.  In the Resectoscope Zoom Calibration window, click Start. 


[TABLE]
| Chapter 5                                                                  | Calibration   |
|:---------------------------------------------------------------------------|:--------------|
| 6.   Click Save and then Close.                                            |               |
| 7.   Click Calibrate in the Valve In row.                                  |               |
| 8.                                                                         |               |
| In the Resectoscope Valve Calibration window, click Start.                 |               |
| 9.   Open and Close the inflow valve.                                      |               |
| The line moves from right to left (showing the minimum to maximum values). |               |
| 10.  Click Save and then Close.                                            |               |
| 11.   Click Calibrate in the Valve Out row.                                |               |
| 12.  In the Resectoscope Valve Calibration window, click Start.            |               |
| 13.  Open and Close the outflow valve.                                     |               |
| The line moves from right to left (showing the minimum to maximum values). |               |
| 14.  Click Save and then Close.                                            |               |
| Resectoscope Camera                                                        |               |
| 1.   Under Camera, click Calibrate in the Zoom row.                        |               |
| 2.                                                                         |               |
| In the Resectoscope Zoom Calibration window, click Start.                  |               |
|                                                                            | Page 77       |

[OCR]
Chapter 5

Calibration

OND

10.
11.
12.

13.

14.

Click Save and then Close.
Click Calibrate in the Valve In row.
In the Resectoscope Valve Calibration window, click Start.

Resectoscope Tool Handle Calibration

Open and Close the inflow valve.

The line moves from right to left (showing the minimum to maximum values).

Click Save and then Close.
Click Calibrate in the Valve Out row.
In the Resectoscope Valve Calibration window, click Start.

Resectoscope Valve Calibration

Open and Close the outflow valve.

The line moves from right to left (showing the minimum to maximum values).
Click Save and then Close.

Resectoscope Camera

1.
2.

Under Camera, click Calibrate in the Zoom row.
In the Resectoscope Zoom Calibration window, click Start.

surgicalscience

Page 77


# Page 84

Chapter 5 
 Calibration
 
Page 78 
 
 
3.  Turn the Zoom ring all the way in one direction and then all the way in the opposite 
direction. 
The line moves from right to left (showing the minimum to maximum values). 
4.  Click Save and the Close. 
5.  Under Camera, click Calibrate in the Focus row. 
6.  In the Resectoscope Focus Calibration window, click Start. 
7.  Turn the Focus ring all the way in one direction and then all the way in the opposite 
direction. 
The line moves from right to left (showing the minimum to maximum values). 
8.  Click Save and the Close. 
9.  Click Calibrate in the Roll row.  
10.  Click Start. 
 
11.  Roll the camera handle a complete roll (360 degrees). 
12.  Click Save and Close. 


[TABLE]
| 3.   Turn the Zoom ring all the way in one direction and then all the way in the opposite   |                                                                            |
|:--------------------------------------------------------------------------------------------|:---------------------------------------------------------------------------|
|                                                                                             | direction.                                                                 |
|                                                                                             | The line moves from right to left (showing the minimum to maximum values). |
| 4.   Click Save and the Close.                                                              |                                                                            |
| 5.   Under Camera, click Calibrate in the Focus row.                                        |                                                                            |
| 6.                                                                                          | In the Resectoscope Focus Calibration window, click Start.                 |
| 7.   Turn the Focus ring all the way in one direction and then all the way in the opposite  |                                                                            |
|                                                                                             | direction.                                                                 |
|                                                                                             | The line moves from right to left (showing the minimum to maximum values). |
| 8.   Click Save and the Close.                                                              |                                                                            |
| 9.   Click Calibrate in the Roll row.                                                       |                                                                            |
| 10.  Click Start.                                                                           |                                                                            |

[OCR]
Chapter 5 Calibration

NOE

-
see

11.
12.

Resectoscope Zoom Calibration

Turn the Zoom ring all the way in one direction and then all the way in the opposite
direction.

The line moves from right to left (showing the minimum to maximum values).

Click Save and the Close.

Under Camera, click Calibrate in the Focus row.

In the Resectoscope Focus Calibration window, click Start.

Turn the Focus ring all the way in one direction and then all the way in the opposite
direction.

The line moves from right to left (showing the minimum to maximum values).

Click Save and the Close.
Click Calibrate in the Roll row.

. Click Start.

Roll the camera handle a complete roll (360 degrees).
Click Save and Close.

surgicalscience Page 78


# Page 85

Chapter 5 
 Calibration
 
Page 79 
 
13.  Align the camera so that its buttons are facing up.  
The clock should point to 0 degrees. 
14.  Click Reset Camera. 
15.  Check each of the camera’s buttons. 
When the button is pushed, the box should light up. 
 
Tools tab 
There are no tools for the TURP modules so there is no need to calibrate tools in the 
Tools tab.  
Ascension tab 
The Ascension tab checks the insertion functionality of each of the TURP Mentor 
scope in the simulator.  
1.  Select the Ascension tab. 
 


[TABLE]
| Chapter 5                                                                             | Calibration   |
|:--------------------------------------------------------------------------------------|:--------------|
| 13.  Align the camera so that its buttons are facing up.                              |               |
| The clock should point to 0 degrees.                                                  |               |
| 14.  Click Reset Camera.                                                              |               |
| 15.  Check each of the camera’s buttons.                                              |               |
| When the button is pushed, the box should light up.                                   |               |
| Tools tab                                                                             |               |
| There are no tools for the TURP modules so there is no need to calibrate tools in the |               |
| Tools tab.                                                                            |               |
| Ascension tab                                                                         |               |
| The Ascension tab checks the insertion functionality of each of the TURP Mentor       |               |
| scope in the simulator.                                                               |               |
| 1.   Select the Ascension tab.                                                        |               |
|                                                                                       | Page 79       |

[OCR]
Chapter 5 Calibration

13. Align the camera so that its buttons are facing up.

The clock should point to 0 degrees.

14. Click Reset Camera.
15. Check each of the camera’s buttons.

When the button is pushed, the box should light up.

<b
=

Tools tab

There are no tools for the TURP modules so there is no need to calibrate tools in the
Tools tab.

Ascension tab

The Ascension tab checks the insertion functionality of each of the TURP Mentor
scope in the simulator.

1. Select the Ascension tab.

surgicalscience Page 79


# Page 86

Chapter 5 
 Calibration
 
Page 80 
 
 
2.  Position the scope on the top of the simulated penis. 
3.  Click Calibrate.  
4.     To verify calibration, insert the scope into the penis until passed the calibration point. 
Check that the check box is    now filled. 
4.  Verify the sensor quality for the actual sensor position for each scope.  
• 
0-2 = Good 
• 
4-5 = Satisfactory 
• 
10 = Poor 
Advance settings 
The Hemisphere settings is the transmitter hemisphere selection and is set in the 
Advance Settings. Call Surgical Science Technical Support to configure this setting. 
General tab 
The general tab is used to check the functionality of the foot pedals and LED.  
The calibration is performed in the same way as for the GI Mentor (see General tab on 
page 53). 


[TABLE]
| 2.   Position the scope on the top of the simulated penis.                                        |
|:--------------------------------------------------------------------------------------------------|
| 3.   Click Calibrate.                                                                             |
| 4.     To verify calibration, insert the scope into the penis until passed the calibration point. |
| Check that the check box is    now filled.                                                        |
| 4.   Verify the sensor quality for the actual sensor position for each scope.                     |

[OCR]
Chapter 5 Calibration

Select Platform: |iUSaam Channel: RA]

Sensor
Hemisphere Guay
Inches: X: 13.67 Y: -0.37 2:-254 me: X: 347.14 Y: -9.38 Z: -64.52
TURP - Resectoscope Position Calibration
Hold the Resectoscope on top of the penis and press Calibrate Oo

Calibrate

2. Position the scope on the top of the simulated penis.
3. Click Calibrate.
4. To verify calibration, insert the scope into the penis until passed the calibration point.
Check that the check box is _ now filled.
4. Verify the sensor quality for the actual sensor position for each scope.
° 0-2 = Good
e 4-5 = Satisfactory
° 10 = Poor

Advance settings

The Hemisphere settings is the transmitter hemisphere selection and is set in the
Advance Settings. Call Surgical Science Technical Support to configure this setting.

General tab

The general tab is used to check the functionality of the foot pedals and LED.

The calibration is performed in the same way as for the GI Mentor (see General tab on
page 53).

surgicalscience Page 80


# Page 87

Chapter 5 
 Calibration
 
Page 81 
 
1.  Select the General tab. 
 
Roll calibration tab 
Roll calibration is for the TURP scope. It fixes the alignment of the scope to the 
simulator.  
Resectoscope needs to be calibrated and every time it is replaced, it should be 
calibrated. 
To calibrate: 
1.  Select the Roll Calibration tab. 


[TABLE]
| Chapter 5                                                                          | Calibration   |
|:-----------------------------------------------------------------------------------|:--------------|
| 1.   Select the General tab.                                                       |               |
| Roll calibration tab                                                               |               |
| Roll calibration is for the TURP scope. It fixes the alignment of the scope to the |               |
| simulator.                                                                         |               |
| Resectoscope needs to be calibrated and every time it is replaced, it should be    |               |
| calibrated.                                                                        |               |
| To calibrate:                                                                      |               |
| 1.   Select the Roll Calibration tab.                                              |               |
|                                                                                    | Page 81       |

[OCR]
Chapter 5

Calibration

1. Select the General tab.

Scope Tools Ascension
Force Feedback

Calibrated Time Examination

Calibrated

Dynamic

General

Sensor Roll Angle
Pedals
OF ter
Middle
Right
Drawers
Gi
L_] uro
Leds
c
c
@ URO
© Tum off

Roll calibration tab

Roll calibration is for the TURP scope. It fixes the alignment of the scope to the

simulator.

Resectoscope needs to be calibrated and every time it is replaced, it should be

calibrated.

To calibrate:
1. Select the Roll Calibration tab.

surgicalscience

Page 81


# Page 88

Chapter 5 
 Calibration
 
Page 82 
 
 
2.  Align the scope so that the working element is parallel to the camera button as 
shown in the next picture below. 
 
The angle is displayed offset as shown in the picture below. 


[TABLE]
| Chapter 5                                                                            | Calibration   |
|:-------------------------------------------------------------------------------------|:--------------|
| 2.   Align the scope so that the working element is parallel to the camera button as |               |
| shown in the next picture below.                                                     |               |
| The angle is displayed offset as shown in the picture below.                         |               |
|                                                                                      | Page 82       |

[OCR]
Chapter 5

Calibration

Roll Calibration

Calibrate

Roll Angle: -138.10

Sensor Roll Angle

2. Align the scope so that the working element is parallel to the camera button as
shown in the next picture below.

The angle is displayed offset as shown in the picture below.

surgicalscience

Page 82


# Page 89

Chapter 5 
 Calibration
 
Page 83 
 
 
 
3.  Click Calibrate. 
The Sensor Roll Angle is reset and the yellow mark is at 0 degrees. 


[TABLE]
| Chapter 5                                                           | Calibration   |
|:--------------------------------------------------------------------|:--------------|
| 3                                                                   |               |
| .   Click Calibrate.                                                |               |
| The Sensor Roll Angle is reset and the yellow mark is at 0 degrees. |               |
|                                                                     | Page 83       |

[OCR]
Chapter 5 Calibration
Sensor Roll Angle
Roll Calibration
Calibrate
Roll Angle: -138.10
3. Click Calibrate.
The Sensor Roll Angle is reset and the yellow mark is at 0 degrees.
surgicalscience Page 83


# Page 90

Chapter 5 
 Calibration
 
Page 84 
 
 
The scope is now aligned to the simulator. 
HYST Mentor calibration 
1.  Select the HYST platform from the Select Platform list. 
There is one scope, resectoscope that needs to be calibrated, which is connected 
to port C. 
Scope tab 
The Scope tab is used to calibrate the components of the resectoscope handle – 
working element and Inflow and Outflow valves. In addition, the tab is used to verify 
the camera’s buttons and the Focus and Zoom rings. 
1.  Select the Scope tab. 


[TABLE]
| Chapter 5                                                                             | Calibration                                                                      |
|:--------------------------------------------------------------------------------------|:---------------------------------------------------------------------------------|
| The scope is now aligned to the simulator.                                            |                                                                                  |
| HYST Mentor calibration                                                               |                                                                                  |
| 1.   Select the HYST platform from the Select Platform list.                          |                                                                                  |
|                                                                                       | There is one scope, resectoscope that needs to be calibrated, which is connected |
| to port C.                                                                            |                                                                                  |
| Scope tab                                                                             |                                                                                  |
| The Scope tab is used to calibrate the components of the resectoscope handle –        |                                                                                  |
| working element and Inflow and Outflow valves. In addition, the tab is used to verify |                                                                                  |
| the camera’s buttons and the Focus and Zoom rings.                                    |                                                                                  |
| 1.   Select the Scope tab.                                                            |                                                                                  |
|                                                                                       | Page 84                                                                          |

[OCR]
Chapter 5 Calibration

‘Scope Tools ‘Ascension General Sensor Roll Angle

Roll Calibration

Roll Angle: -.29

The scope is now aligned to the simulator.

HYST Mentor calibration

1. Select the HYST platform from the Select Platform list.

There is one scope, resectoscope that needs to be calibrated, which is connected
to port C.

Scope tab
The Scope tab is used to calibrate the components of the resectoscope handle —

working element and Inflow and Outflow valves. In addition, the tab is used to verify
the camera’s buttons and the Focus and Zoom rings.

1. Select the Scope tab.

surgicalscience Page 84


# Page 91

Chapter 5 
 Calibration
 
Page 85 
 
 
2.  Connect the Resectoscope to its port (C). 
The Resectoscope’s channel (C) is selected from the Channel list.  
3.  Click Calibrate in the Handle row. 
4.  In the Resectoscope Tool Handle Calibration window, click Start.  
 
5.  Open and Close the working element.  
The line moves from right to left (showing the minimum to maximum values). 


[TABLE]
| Chapter 5                                                                  | Calibration   |
|:---------------------------------------------------------------------------|:--------------|
| 2.   Connect the Resectoscope to its port (C).                             |               |
| The Resectoscope’s channel (C) is selected from the Channel list.          |               |
| 3.   Click Calibrate in the Handle row.                                    |               |
| 4.                                                                         |               |
| In the Resectoscope Tool Handle Calibration window, click Start.           |               |
| 5.   Open and Close the working element.                                   |               |
| The line moves from right to left (showing the minimum to maximum values). |               |
|                                                                            | Page 85       |

[OCR]
Chapter 5 Calibration

Select Platfom: IVE Channel: [ia]

Handle Ca Calibrate
Velveln ? Calibrate
Valve Out 2 Calibrate
Camera

Zoom (+-) | Calibrate
= rn

a
Roll(2sensors) {i Calibrate
Reset Camera

2. Connect the Resectoscope to its port (C).

The Resectoscope’s channel (C) is selected from the Channel list.

3. Click Calibrate in the Handle row.
4. Inthe Resectoscope Tool Handle Calibration window, click Start.

Resectoscope Tool Handle Calibration

3858

5. Open and Close the working element.

The line moves from right to left (showing the minimum to maximum values).

surgicalscience Page 85


# Page 92

Chapter 5 
 Calibration
 
Page 86 
 
6.  Click Save and then Close. 
7.  Click Calibrate in the Valve In row. 
8.  In the Resectoscope Valve Calibration window, click Start.  
 
9.  Open and Close the inflow valve.  
The line moves from right to left (showing the minimum to maximum values). 
10.  Click Save and then Close. 
11.  Click Calibrate in the Valve Out row. 
12.  In the Resectoscope Valve Calibration window, click Start.  
 
13.  Open and Close the outflow valve.  
The line moves from right to left (showing the minimum to maximum values). 
14.  Click Save and then Close. 
Resectoscope Camera 
1.  Under Camera, click Calibrate in the Zoom row. 
2.  In the Resectoscope Zoom Calibration window, click Start. 


[TABLE]
| Chapter 5                                                                  | Calibration   |
|:---------------------------------------------------------------------------|:--------------|
| 6.   Click Save and then Close.                                            |               |
| 7.   Click Calibrate in the Valve In row.                                  |               |
| 8.                                                                         |               |
| In the Resectoscope Valve Calibration window, click Start.                 |               |
| 9.   Open and Close the inflow valve.                                      |               |
| The line moves from right to left (showing the minimum to maximum values). |               |
| 10.  Click Save and then Close.                                            |               |
| 11.   Click Calibrate in the Valve Out row.                                |               |
| 12.  In the Resectoscope Valve Calibration window, click Start.            |               |
| 13.  Open and Close the outflow valve.                                     |               |
| The line moves from right to left (showing the minimum to maximum values). |               |
| 14.  Click Save and then Close.                                            |               |
| Resectoscope Camera                                                        |               |
| 1.   Under Camera, click Calibrate in the Zoom row.                        |               |
| 2.                                                                         |               |
| In the Resectoscope Zoom Calibration window, click Start.                  |               |
|                                                                            | Page 86       |

[OCR]
Chapter 5 Calibration

Click Save and then Close.
Click Calibrate in the Valve In row.
In the Resectoscope Valve Calibration window, click Start.

OND

Resectoscope Tool Handle Calibration

9. Open and Close the inflow valve.

The line moves from right to left (showing the minimum to maximum values).

10. Click Save and then Close.
11. Click Calibrate in the Valve Out row.
12. In the Resectoscope Valve Calibration window, click Start.

Resectoscope Valve Calibration

13. Open and Close the outflow valve.

The line moves from right to left (showing the minimum to maximum values).
14. Click Save and then Close.
Resectoscope Camera

1. Under Camera, click Calibrate in the Zoom row.
2. Inthe Resectoscope Zoom Calibration window, click Start.

surgicalscience Page 86


# Page 93

Chapter 5 
 Calibration
 
Page 87 
 
 
3.  Turn the Zoom ring all the way in one direction and then all the way in the opposite 
direction. 
The line moves from right to left (showing the minimum to maximum values). 
4.  Click Save and the Close. 
5.  Under Camera, click Calibrate in the Focus row. 
6.  In the Resectoscope Focus Calibration window, click Start. 
7.  Turn the Focus ring all the way in one direction and then all the way in the opposite 
direction. 
The line moves from right to left (showing the minimum to maximum values). 
8.  Click Save and the Close. 
9.  Click Calibrate in the Roll row.  
10.  Click Start. 
 
11.  Roll the camera handle a complete roll (360 degrees). 
12.  Click Save and Close. 


[TABLE]
| 3.   Turn the Zoom ring all the way in one direction and then all the way in the opposite   |                                                                            |
|:--------------------------------------------------------------------------------------------|:---------------------------------------------------------------------------|
|                                                                                             | direction.                                                                 |
|                                                                                             | The line moves from right to left (showing the minimum to maximum values). |
| 4.   Click Save and the Close.                                                              |                                                                            |
| 5.   Under Camera, click Calibrate in the Focus row.                                        |                                                                            |
| 6.                                                                                          | In the Resectoscope Focus Calibration window, click Start.                 |
| 7.   Turn the Focus ring all the way in one direction and then all the way in the opposite  |                                                                            |
|                                                                                             | direction.                                                                 |
|                                                                                             | The line moves from right to left (showing the minimum to maximum values). |
| 8.   Click Save and the Close.                                                              |                                                                            |
| 9.   Click Calibrate in the Roll row.                                                       |                                                                            |
| 10.  Click Start.                                                                           |                                                                            |

[OCR]
Chapter 5 Calibration

NOE

-
see

11.
12.

Resectoscope Zoom Calibration

Turn the Zoom ring all the way in one direction and then all the way in the opposite
direction.

The line moves from right to left (showing the minimum to maximum values).

Click Save and the Close.

Under Camera, click Calibrate in the Focus row.

In the Resectoscope Focus Calibration window, click Start.

Turn the Focus ring all the way in one direction and then all the way in the opposite
direction.

The line moves from right to left (showing the minimum to maximum values).

Click Save and the Close.
Click Calibrate in the Roll row.

. Click Start.

Roll the camera handle a complete roll (360 degrees).
Click Save and Close.

surgicalscience Page 87


# Page 94

Chapter 5 
 Calibration
 
Page 88 
 
13.  Align the camera so that its buttons are facing up.  
The clock should point to 0 degrees. 
14.  Click Reset Camera. 
15.  Check each of the camera’s buttons. 
When the button is pushed, the box should light up. 
 
Tools tab 
There are no tools for the HYST Mentor so there is no need to calibrate tools in the 
Tools tab.  
Ascension tab 
The Ascension tab checks the insertion functionality of each of the HYST Mentor 
scope in the simulator.  
1.  Select the Ascension tab. 


[TABLE]
| Chapter 5                                                                            | Calibration   |
|:-------------------------------------------------------------------------------------|:--------------|
| 13.  Align the camera so that its buttons are facing up.                             |               |
| The clock should point to 0 degrees.                                                 |               |
| 14.  Click Reset Camera.                                                             |               |
| 15.  Check each of the camera’s buttons.                                             |               |
| When the button is pushed, the box should light up.                                  |               |
| Tools tab                                                                            |               |
| There are no tools for the HYST Mentor so there is no need to calibrate tools in the |               |
| Tools tab.                                                                           |               |
| Ascension tab                                                                        |               |
| The Ascension tab checks the insertion functionality of each of the HYST Mentor      |               |
| scope in the simulator.                                                              |               |
| 1.   Select the Ascension tab.                                                       |               |
|                                                                                      | Page 88       |

[OCR]
Chapter 5 Calibration

13. Align the camera so that its buttons are facing up.

The clock should point to 0 degrees.

14. Click Reset Camera.
15. Check each of the camera’s buttons.

When the button is pushed, the box should light up.

<b
=

Tools tab

There are no tools for the HYST Mentor so there is no need to calibrate tools in the
Tools tab.

Ascension tab

The Ascension tab checks the insertion functionality of each of the HYST Mentor
scope in the simulator.

1. Select the Ascension tab.

surgicalscience Page 88


# Page 95

Chapter 5 
 Calibration
 
Page 89 
 
 
2.  Position the scope tip at the designated calibration hole to the left of the anatomy. 
Keep the scope parallel to the floor. 
3.  Press Calibrate.  
4.     To verify calibration, insert the scope into the penis until passed the calibration 
point. Check that the check box is now filled. 
4.  Verify the sensor quality for the actual sensor position for each scope.  
• 
0-2 = Good 
• 
4-5 = Satisfactory 
• 
10 = Poor 
Advance settings 
The Hemisphere settings is the transmitter hemisphere selection and is set in the 
Advance Settings. Call Surgical Science Technical Support to configure this setting. 
General tab 
 The general tab is used to check the functionality of the foot pedals and LED.  
The calibration is performed in the same way as for the GI Mentor (see General tab on 
page 53). 


[TABLE]
| 2.   Position the scope tip at the designated calibration hole to the left of the anatomy.   |
|:---------------------------------------------------------------------------------------------|
| Keep the scope parallel to the floor.                                                        |
| 3.   Press Calibrate.                                                                        |
| 4.     To verify calibration, insert the scope into the penis until passed the calibration   |
| point. Check that the check box is now filled.                                               |
| 4.   Verify the sensor quality for the actual sensor position for each scope.                |

[OCR]
Chapter 5 Calibration

Scope I Tools I Ascension
Sensor
Hemisphere Cnr
Inches: X: 3.76 Y: 13.10 Z:-1.85 mm: X: 95.44 Y: 332.74 Z: -46.99

HYST - Resectoscope Position Calibration—

Place the tip of the Resectoscop in the niche and press Calibrate.

Calibrate

2. Position the scope tip at the designated calibration hole to the left of the anatomy.
Keep the scope parallel to the floor.

3. Press Calibrate.

4. To verify calibration, insert the scope into the penis until passed the calibration

point. Check that the check box is now filled.

4. Verify the sensor quality for the actual sensor position for each scope.

e 0-2 = Good
e 4-5 = Satisfactory
° 10 = Poor

Advance settings

The Hemisphere settings is the transmitter hemisphere selection and is set in the
Advance Settings. Call Surgical Science Technical Support to configure this setting.

General tab

The general tab is used to check the functionality of the foot pedals and LED.

The calibration is performed in the same way as for the GI Mentor (see General tab on
page 53).

surgicalscience Page 89


# Page 96

Chapter 5 
 Calibration
 
Page 90 
 
1.  Select the General tab. 
.  
Roll calibration tab 
Roll calibration is for the HYST scope. It fixes the alignment of the scope to the 
simulator.  
Resectoscope needs to be calibrated and every time it is replaced, it should be 
calibrated. 
To calibrate: 
1.  Select the Roll Calibration tab. 


[TABLE]
| Chapter 5                                                                          | Calibration   |
|:-----------------------------------------------------------------------------------|:--------------|
| 1.   Select the General tab.                                                       |               |
|                                                                                    | .             |
| Roll calibration tab                                                               |               |
| Roll calibration is for the HYST scope. It fixes the alignment of the scope to the |               |
| simulator.                                                                         |               |
| Resectoscope needs to be calibrated and every time it is replaced, it should be    |               |
| calibrated.                                                                        |               |
| To calibrate:                                                                      |               |
| 1.   Select the Roll Calibration tab.                                              |               |
|                                                                                    | Page 90       |

[OCR]
Chapter 5

Calibration

1.

Rol

Select the General tab.

‘Scope
Force Feedback

Calibrated Time Examination

Calibrated

Tools

Dynamic

General

Sensor Roll Angle
Pedals
Left
Middle
Right
Drawers
Gl
URO
Leds
a
A
.
@ URO
© Tum off

calibration tab

Roll calibration is for the HYST scope. It fixes the alignment of the scope to the
simulator.

Resectoscope needs to be calibrated and every time it is replaced, it should be
calibrated.

To calibrate:

1.

Select the Roll Calibration tab.

surgicalscience

Page 90


# Page 97

Chapter 5 
 Calibration
 
Page 91 
 
 
2.  Align the scope so that the working element is parallel to the camera button as 
shown in the next picture below. 
 
The angle is displayed offset as shown in the picture below. 


[TABLE]
| Chapter 5                                                                            | Calibration   |
|:-------------------------------------------------------------------------------------|:--------------|
| 2.   Align the scope so that the working element is parallel to the camera button as |               |
| shown in the next picture below.                                                     |               |
| The angle is displayed offset as shown in the picture below.                         |               |
|                                                                                      | Page 91       |

[OCR]
Chapter 5 Calibration

Sensor Roll Angle

Roll Calibration

Calibrate

Rall Angle: -.70

2. Align the scope so that the working element is parallel to the camera button as
shown in the next picture below.

The angle is displayed offset as shown in the picture below.

surgicalscience Page 91


# Page 98

Chapter 5 
 Calibration
 
Page 92 
 
 
 
3.  Click Calibrate. 
The Sensor Roll Angle is reset and the yellow mark is at 0 degrees. 
 


[TABLE]
| Chapter 5                                                           | Calibration   |
|:--------------------------------------------------------------------|:--------------|
| 3                                                                   |               |
| .   Click Calibrate.                                                |               |
| The Sensor Roll Angle is reset and the yellow mark is at 0 degrees. |               |
|                                                                     | Page 92       |

[OCR]
Chapter 5 Calibration
Sensor Roll Angle
Roll Calibration
Calibrate
Roll Angle: -138.10
3. Click Calibrate.
The Sensor Roll Angle is reset and the yellow mark is at 0 degrees.
Sensor Roll Angle
Roll Calibration
Roll Angle: -29
surgicalscience Page 92


# Page 99

Chapter 5 
 Calibration
 
Page 93 
 
The scope is now aligned to the simulator. 
 
 


[TABLE]
| Chapter 5                                  | Calibration   |
|:-------------------------------------------|:--------------|
| The scope is now aligned to the simulator. |               |
|                                            | Page 93       |

[OCR]
Chapter 5 Calibration

The scope is now aligned to the simulator.

‘Sensor Roll Angle

Roll Calibration

Roll Angle: -29

surgicalscience Page 93


# Page 100

Chapter 6 
 Troubleshooting
 
Page 94 
 
Chapter 6 Troubleshooting 
The following tables list some problems and questions that may arise when working 
with the ENDO Mentor Suite simulator along with suggested solutions. In addition, 
common troubleshooting tips are also provided, listing possible malfunctions and 
suggesting remedial procedures for them. 
Symptom / 
Message 
Probable Cause 
Suggested Remedy 
Main power supply 
button doesn’t light 
up. 
1. The AC power cable is 
unplugged from the wall 
socket. 
2. There is a problem with 
the AC cable. 
3. The system’s fuses 
“blew”. 
4. The power button light 
is burned out. 
1. Plug the power cable into 
the wall socket correctly. 
2. Remove the fuse 
compartment and replace 
the fuses. 
3. If the problem persists, 
contact Surgical Science 
Support to replace the 
power button. 
4. Open the back cover and 
check that all the cables are 
properly connected to the 
computer. 
The monitor doesn’t 
work. 
1. The monitor’s power 
supply cable is not 
plugged in. 
2. All cables are plugged 
in correctly and the 
computer is running but 
the monitor doesn’t work. 
1. Plug the power cable into 
the monitor’s rear panel. 
2. Turn on the monitor by 
pressing the monitor’s 
On/Off button. 
3. Open the back cover and 
check  that all the cables are 
properly connected to the 
computer. 
The touch on the 
monitor isn’t 
working. 
1. The ELO driver isn’t 
installed. 
2. The touch USB cable is 
disconnected. 
1. Install the ELO driver. 
2. Connect the touch cable 
to its port. 


[TABLE]
| Chapter 6                                                                         | Troubleshooting   |
|:----------------------------------------------------------------------------------|:------------------|
| Chapter 6  Troubleshooting                                                        |                   |
| The following tables list some problems and questions that may arise when working |                   |
| with the ENDO Mentor Suite simulator along with suggested solutions. In addition, |                   |
| common troubleshooting tips are also provided, listing possible malfunctions and  |                   |
| suggesting remedial procedures for them.                                          |                   |

[TABLE]
| Symptom /            | Probable Cause             | Suggested Remedy               |
|:---------------------|:---------------------------|:-------------------------------|
| Message              |                            |                                |
| Main power supply    | 1. The AC power cable is   | 1. Plug the power cable into   |
| button doesn’t light | unplugged from the wall    | the wall socket correctly.     |
| up.                  | socket.                    |                                |
|                      |                            | 2. Remove the fuse             |
|                      | 2. There is a problem with | compartment and replace        |
|                      | the AC cable.              | the fuses.                     |
|                      | 3. The system’s fuses      | 3. If the problem persists,    |
|                      | “blew”.                    | contact Surgical Science       |
|                      |                            | Support to replace the         |
|                      | 4. The power button light  |                                |
|                      |                            | power button.                  |
|                      | is burned out.             |                                |
|                      |                            | 4. Open the back cover and     |
|                      |                            | check that all the cables are  |
|                      |                            | properly connected to the      |
|                      |                            | computer.                      |
| The monitor doesn’t  | 1. The monitor’s power     | 1. Plug the power cable into   |
| work.                | supply cable is not        | the monitor’s rear panel.      |
|                      | plugged in.                |                                |
|                      |                            | 2. Turn on the monitor by      |
|                      | 2. All cables are plugged  | pressing the monitor’s         |
|                      | in correctly and the       | On/Off button.                 |
|                      | computer is running but    |                                |
|                      |                            | 3. Open the back cover and     |
|                      | the monitor doesn’t work.  |                                |
|                      |                            | check  that all the cables are |
|                      |                            | properly connected to the      |
|                      |                            | computer.                      |
| The touch on the     | 1. The ELO driver isn’t    | 1. Install the ELO driver.     |
| monitor isn’t        | installed.                 |                                |
|                      |                            | 2. Connect the touch cable     |
| working.             |                            |                                |
|                      | 2. The touch USB cable is  | to its port.                   |
|                      | disconnected.              |                                |

[OCR]
Chapter 6

Troubleshooting

| Chapter 6 Troubleshooting

The following tables list some problems and questions that may arise when working
with the ENDO Mentor Suite simulator along with suggested solutions. In addition,
common troubleshooting tips are also provided, listing possible malfunctions and
suggesting remedial procedures for them.

Symptom /
Message

Probable Cause

Suggested Remedy

Main power supply
button doesn’t light
up.

1. The AC power cable is
unplugged from the wall
socket.

2. There is a problem with
the AC cable.

3. The system's fuses
“blew”.

4. The power button light
is burned out.

1. Plug the power cable into
the wall socket correctly.
2. Remove the fuse
compartment and replace
the fuses.

3. If the problem persists,
contact Surgical Science
Support to replace the
power button.

4. Open the back cover and
check that all the cables are
properly connected to the
computer.

The monitor doesn’t
work.

1. The monitor's power
supply cable is not
plugged in.

2. All cables are plugged
in correctly and the
computer is running but
the monitor doesn’t work.

1. Plug the power cable into
the monitor's rear panel.

2. Turn on the monitor by
pressing the monitor's
On/Off button.

3. Open the back cover and
check that all the cables are
properly connected to the
computer.

The touch on the
monitor isn’t
working.

1. The ELO driver isn’t
installed.

2. The touch USB cable is
disconnected.

1. Install the ELO driver.

2. Connect the touch cable
to its port.

surgicalscience

Page 94


# Page 101

Chapter 6 
 Troubleshooting
 
Page 95 
 
The keyboard/ 
mouse USB set 
doesn’t work. 
1. The USB dongle is not 
connected to the USB 
port. 
2. No batteries or the 
battery charge is low. 
3. The set is not turned 
on. 
1. Check that the USB 
dongle is connected to one 
of the back USB ports.  
If problem persists, open the 
mouse and verify that the 
dongle is located inside. 
2. Replace the batteries. 
3. Turn on the wireless set. 
The computer is 
turned on but I can’t 
see the Login 
screen. 
The monitor doesn’t work. 
1. Plug the power cable into 
the monitor’s rear panel. 
2. Turn on the monitor by 
pressing the monitor’s 
On/Off button. 
3. Open the back cover and 
check  that all the cables are 
properly connected to the 
computer. 
I received the 
message: “The 
password is 
incorrect”. 
The password was typed 
incorrectly. 
Check the password and 
enter it again using the 
upper- and lower-case 
letters, as required. 
The sound doesn’t 
work. 
1. The sound cable is not 
plugged in 
2. If sound is muted. 
1. Open the back cover and 
check that all the cables are 
properly connected to the 
computer. 
2. On the Sound Settings, 
make sure that the “Mute” 
button is not turned on. If it 
is, turn it off. 
The elevation 
mechanism isn't 
responding. 
1. There is a problem with 
the elevation mechanism 
switch.  
2. There is a problem with 
one or more of the 
electrical motors. 
1. Contact Surgical Science 
Support. 


[TABLE]
| Chapter 6             |                            | Troubleshooting                |
|:----------------------|:---------------------------|:-------------------------------|
| The keyboard/         | 1. The USB dongle is not   | 1. Check that the USB          |
| mouse USB set         | connected to the USB       | dongle is connected to one     |
| doesn’t work.         | port.                      | of the back USB ports.         |
|                       | 2. No batteries or the     | If problem persists, open the  |
|                       | battery charge is low.     | mouse and verify that the      |
|                       |                            | dongle is located inside.      |
|                       | 3. The set is not turned   |                                |
|                       | on.                        | 2. Replace the batteries.      |
|                       |                            | 3. Turn on the wireless set.   |
| The computer is       | The monitor doesn’t work.  | 1. Plug the power cable into   |
| turned on but I can’t |                            | the monitor’s rear panel.      |
| see the Login         |                            |                                |
|                       |                            | 2. Turn on the monitor by      |
| screen.               |                            |                                |
|                       |                            | pressing the monitor’s         |
|                       |                            | On/Off button.                 |
|                       |                            | 3. Open the back cover and     |
|                       |                            | check  that all the cables are |
|                       |                            | properly connected to the      |
|                       |                            | computer.                      |
| I received the        | The password was typed     | Check the password and         |
| message: “The         | incorrectly.               | enter it again using the       |
| password is           |                            | upper- and lower-case          |
| incorrect”.           |                            | letters, as required.          |
| The sound doesn’t     | 1. The sound cable is not  | 1. Open the back cover and     |
| work.                 | plugged in                 | check that all the cables are  |
|                       |                            | properly connected to the      |
|                       | 2. If sound is muted.      |                                |
|                       |                            | computer.                      |
|                       |                            | 2. On the Sound Settings,      |
|                       |                            | make sure that the “Mute”      |
|                       |                            | button is not turned on. If it |
|                       |                            | is, turn it off.               |
| The elevation         | 1. There is a problem with | 1. Contact Surgical Science    |
| mechanism isn't       | the elevation mechanism    | Support.                       |
| responding.           | switch.                    |                                |

[OCR]
Chapter 6

Troubleshooting

The keyboard/
mouse USB set
doesn’t work.

1. The USB dongle is not
connected to the USB
port.

2. No batteries or the
battery charge is low.

3. The set is not turned
on.

1. Check that the USB
dongle is connected to one
of the back USB ports.

If problem persists, open the
mouse and verify that the
dongle is located inside.

2. Replace the batteries.
3. Turn on the wireless set.

The computer is
turned on but | can’t
see the Login
screen.

The monitor doesn’t work.

1. Plug the power cable into
the monitor's rear panel.

2. Turn on the monitor by
pressing the monitor's
On/Off button.

3. Open the back cover and
check that all the cables are
properly connected to the
computer.

| received the
message: “The
password is
incorrect”.

The password was typed
incorrectly.

Check the password and
enter it again using the
upper- and lower-case
letters, as required.

The sound doesn’t
work.

1. The sound cable is not
plugged in
2. If sound is muted.

1. Open the back cover and
check that all the cables are
properly connected to the
computer.

2. On the Sound Settings,
make sure that the “Mute”
button is not turned on. If it
is, turn it off.

The elevation
mechanism isn't
responding.

1. There is a problem with
the elevation mechanism
switch.

2. There is a problem with
one or more of the
electrical motors.

1. Contact Surgical Science
Support.

surgicalscience

Page 95


# Page 102

Chapter 6 
 Troubleshooting
 
Page 96 
 
No scope movement 
in the procedure 
1. The scope is not 
calibrated. 
2. The scope tracking 
sensor is not functioning 
properly or there is 
something wrong with the 
sensor. 
3. The scope connection 
port is damaged.  
4. The Ascension 
transmitter is not working. 
5. There is magnetic 
interference in the 
simulator’s location. 
1. Do the following: 
a. Verify the sensor is 
working and tracking using 
the Ascension Diagnostic 
Cubes application. 
b. If the Cubes application 
shows the sensor is tracking, 
calibrate the Scope Insertion 
using the Calibration 
software. See Scope tab on 
page 60. 
c. See #5. 
2. Calibrate the sensor. See 
Ascension tab on page 52. 
3. Contact Surgical Science 
support. 
4. Check that the transmitter 
was switched for the 
module. (There are two 
transmitters – one for the GI-
BRONCH and one for the 
URO which should switch 
automatically for the 
appropriate module).  
If problem persists, contact 
Surgical Science Support. 
5. Make sure the simulator is 
at least 10 inches away from 
additional simulators, other 
electrical systems or 
electrical cables, or large 
amounts of metal. 
 


[TABLE]
| Chapter 6         |                             | Troubleshooting                |
|:------------------|:----------------------------|:-------------------------------|
| No scope movement | 1. The scope is not         | 1. Do the following:           |
| in the procedure  | calibrated.                 |                                |
|                   |                             | a. Verify the sensor is        |
|                   | 2. The scope tracking       | working and tracking using     |
|                   | sensor is not functioning   | the Ascension Diagnostic       |
|                   | properly or there is        | Cubes application.             |
|                   | something wrong with the    |                                |
|                   |                             | b. If the Cubes application    |
|                   | sensor.                     |                                |
|                   |                             | shows the sensor is tracking,  |
|                   | 3. The scope connection     | calibrate the Scope Insertion  |
|                   | port is damaged.            | using the Calibration          |
|                   |                             | software. See Scope tab on     |
|                   | 4. The Ascension            |                                |
|                   |                             | page 60.                       |
|                   | transmitter is not working. |                                |
|                   |                             | c. See #5.                     |
|                   | 5. There is magnetic        |                                |
|                   | interference in the         | 2. Calibrate the sensor. See   |
|                   | simulator’s location.       | Ascension tab on page 52.      |
|                   |                             | 3. Contact Surgical Science    |
|                   |                             | support.                       |
|                   |                             | 4. Check that the transmitter  |
|                   |                             | was switched for the           |
|                   |                             | module. (There are two         |
|                   |                             | transmitters – one for the GI- |
|                   |                             | BRONCH and one for the         |
|                   |                             | URO which should switch        |
|                   |                             | automatically for the          |
|                   |                             | appropriate module).           |
|                   |                             | If problem persists, contact   |
|                   |                             | Surgical Science Support.      |
|                   |                             | 5. Make sure the simulator is  |
|                   |                             | at least 10 inches away from   |
|                   |                             | additional simulators, other   |
|                   |                             | electrical systems or          |
|                   |                             | electrical cables, or large    |
|                   |                             | amounts of metal.              |

[OCR]
Chapter 6

Troubleshooting

No scope movement
in the procedure

1. The scope is not
calibrated.

2. The scope tracking
sensor is not functioning
properly or there is
something wrong with the
sensor.

3. The scope connection
port is damaged.

4. The Ascension
transmitter is not working.
5. There is magnetic
interference in the
simulator’s location.

1. Do the following:

a. Verify the sensor is
working and tracking using
the Ascension Diagnostic
Cubes application.

b. If the Cubes application
shows the sensor is tracking,
calibrate the Scope Insertion
using the Calibration
software. See Scope tab on
page 60.

c. See #5.

2. Calibrate the sensor. See
Ascension tab on page 52.

3. Contact Surgical Science
support.

4. Check that the transmitter
was switched for the
module. (There are two
transmitters — one for the GI-
BRONCH and one for the
URO which should switch
automatically for the
appropriate module).

If problem persists, contact
Surgical Science Support.

5. Make sure the simulator is
at least 10 inches away from
additional simulators, other
electrical systems or
electrical cables, or large
amounts of metal.

surgicalscience

Page 96


# Page 103

Chapter 6 
 Troubleshooting
 
Page 97 
 
When rotating the 
scope’s dials, the 
movement of the 
scope on the screen 
doesn’t correlate 
with the rotation of 
the scope’s dials. 
There is a problem with 
the scope’s roll 
movement. 
Calibrate the scope’s roll 
movement. See Roll 
calibration tab on page 56. 
The URO rigid 
scopes are not 
recognized in the 
URO cases. 
The scopes are not 
connected to the correct 
port. 
Switch between the rigid 
scope ports: Rigid 
Ureteroscope – port A and 
Rigid Cystoscope – port B. 
The foot switch   is 
not responding. 
1. The foot switch cable is 
not connected correctly. 
2. The foot switch pedals 
are not functioning 
properly. 
1. Disconnect and re-
connect the foot switch 
cable to its socket.  
2. Check if the foot switch 
pedals are working using the 
Calibration software. See 
General tab on page 53. 
3. If the foot switch pedals 
aren’t recognized/working, 
contact Surgical Science 
Support. 
The WiFi connection 
is not working. 
1. There is a problem with 
the router. 
2.  The WiFi dongle is 
disconnected (in the case 
that you are using one). 
1. Check the router.  
2. Connect the dongle to its 
port. 


[TABLE]
| Chapter 6            |                             | Troubleshooting             |
|:---------------------|:----------------------------|:----------------------------|
| When rotating the    | There is a problem with     | Calibrate the scope’s roll  |
| scope’s dials, the   | the scope’s roll            | movement. See Roll          |
| movement of the      | movement.                   | calibration tab on page 56. |
| scope on the screen  |                             |                             |
| doesn’t correlate    |                             |                             |
| with the rotation of |                             |                             |
| the scope’s dials.   |                             |                             |
| The URO rigid        | The scopes are not          | Switch between the rigid    |
| scopes are not       | connected to the correct    | scope ports: Rigid          |
| recognized in the    | port.                       | Ureteroscope – port A and   |
| URO cases.           |                             | Rigid Cystoscope – port B.  |
| The foot switch   is | 1. The foot switch cable is | 1. Disconnect and re-       |
| not responding.      | not connected correctly.    | connect the foot switch     |
|                      |                             | cable to its socket.        |
|                      | 2. The foot switch pedals   |                             |

[OCR]
Chapter 6

Troubleshooting

When rotating the
scope’s dials, the
movement of the
scope on the screen
doesn’t correlate
with the rotation of
the scope’s dials.

There is a problem with
the scope’s roll
movement.

Calibrate the scope’s roll
movement. See Roll
calibration tab on page 56.

The URO rigid
scopes are not
recognized in the
URO cases.

The scopes are not
connected to the correct
port.

Switch between the rigid
scope ports: Rigid
Ureteroscope - port A and
Rigid Cystoscope — port B.

The foot switch is
not responding.

1. The foot switch cable is
not connected correctly.
2. The foot switch pedals
are not functioning
properly.

1. Disconnect and re-
connect the foot switch
cable to its socket.

2. Check if the foot switch
pedals are working using the
Calibration software. See
General tab on page 53.

3. If the foot switch pedals
aren't recognized/working,
contact Surgical Science
Support.

The WiFi connection
is not working.

1. There is a problem with
the router.

2. The WiFi dongle is
disconnected (in the case
that you are using one).

1. Check the router.

2. Connect the dongle to its
port.

surgicalscience

Page 97


# Page 104

Chapter 6 
 Troubleshooting
 
Page 98 
 
Peripheral device 
(tools) doesn’t work. 
1. The device is not 
connected correctly to 
the switchboard.  
2. The peripheral device 
is not calibrated. 
3. The peripheral device 
is not functioning properly 
or there is something 
wrong with peripheral 
device. 
4. The switchboard is not 
functioning properly or 
there is something wrong 
with switchboard. 
1. Connect the device 
correctly to the 
simulator/switchboard. 
Open the Calibration 
application. On the left side 
of the screen, check that 
GBU Board and Switchboard 
are connected (“Connected” 
should appear by them). 
2. Calibrate the peripheral 
device. See Tools tab on 
page 50. 
3. If the problem persists, 
contact Surgical Science 
Support. 
4. If the problem persists, 
contact Surgical Science 
Support. 
I cannot see tool 
insertion in 
procedure. 
1. The device is not 
connected correctly to 
the switchboard.  
2. The peripheral device 
is not calibrated. 
3. The peripheral device 
isn’t working properly or 
there is something wrong 
with the device. 
4. There is something 
wrong with the scope 
channel or it isn’t working 
properly. 
1. Connect the device 
correctly to the 
simulator/switchboard. 
2. Calibrate the peripheral 
device channel insertion. 
See Tools tab on page 50. 
3. If the problem persists, 
contact Surgical Science 
Support. 
4. If the problem persists, 
contact Surgical Science 
Support. 


[TABLE]
| Chapter 6             |                             | Troubleshooting               |
|:----------------------|:----------------------------|:------------------------------|
| Peripheral device     | 1. The device is not        | 1. Connect the device         |
| (tools) doesn’t work. | connected correctly to      | correctly to the              |
|                       | the switchboard.            | simulator/switchboard.        |
|                       | 2. The peripheral device    | Open the Calibration          |
|                       | is not calibrated.          | application. On the left side |
|                       |                             | of the screen, check that     |
|                       | 3. The peripheral device    |                               |
|                       |                             | GBU Board and Switchboard     |
|                       | is not functioning properly |                               |
|                       |                             | are connected (“Connected”    |
|                       | or there is something       |                               |
|                       |                             | should appear by them).       |
|                       | wrong with peripheral       |                               |
|                       | device.                     | 2. Calibrate the peripheral   |
|                       |                             | device. See Tools tab on      |
|                       | 4. The switchboard is not   |                               |
|                       |                             | page 50.                      |
|                       | functioning properly or     |                               |
|                       | there is something wrong    | 3. If the problem persists,   |
|                       | with switchboard.           | contact Surgical Science      |
|                       |                             | Support.                      |
|                       |                             | 4. If the problem persists,   |
|                       |                             | contact Surgical Science      |
|                       |                             | Support.                      |
| I cannot see tool     | 1. The device is not        | 1. Connect the device         |
| insertion in          | connected correctly to      | correctly to the              |
| procedure.            | the switchboard.            | simulator/switchboard.        |
|                       | 2. The peripheral device    | 2. Calibrate the peripheral   |
|                       | is not calibrated.          | device channel insertion.     |
|                       |                             | See Tools tab on page 50.     |
|                       | 3. The peripheral device    |                               |
|                       | isn’t working properly or   | 3. If the problem persists,   |
|                       | there is something wrong    | contact Surgical Science      |
|                       | with the device.            | Support.                      |
|                       | 4. There is something       | 4. If the problem persists,   |
|                       | wrong with the scope        | contact Surgical Science      |
|                       | channel or it isn’t working | Support.                      |
|                       | properly.                   |                               |

[OCR]
Chapter 6

Troubleshooting

Peripheral device

(tools) doesn’t work.

1. The device is not
connected correctly to
the switchboard.

2. The peripheral device
is not calibrated.

3. The peripheral device
is not functioning properly
or there is something
wrong with peripheral
device.

4. The switchboard is not
functioning properly or
there is something wrong
with switchboard.

1. Connect the device
correctly to the
simulator/switchboard.

Open the Calibration
application. On the left side
of the screen, check that
GBU Board and Switchboard
are connected (“Connected”
should appear by them).

2. Calibrate the peripheral
device. See Tools tab on
page 50.
3. If the problem persists,
contact Surgical Science
Support.
4. If the problem persists,
contact Surgical Science
Support.

| cannot see tool
insertion in
procedure.

1. The device is not
connected correctly to
the switchboard.

2. The peripheral device
is not calibrated.

3. The peripheral device
isn’t working properly or
there is something wrong
with the device.

4. There is something
wrong with the scope
channel or it isn’t working
properly.

1. Connect the device
correctly to the
simulator/switchboard.

2. Calibrate the peripheral
device channel insertion.
See Tools tab on page 50.

3. If the problem persists,
contact Surgical Science
Support.

4. If the problem persists,
contact Surgical Science
Support.

surgicalscience

Page 98


# Page 105

Chapter 6 
 Troubleshooting
 
Page 99 
 
The scope 
button/buttons do 
not respond 
1. The scope button is 
damaged. 
2. The scope connection 
port is damaged. 
1. Check the functionality of 
the scope buttons in 
calibration program. See 
Scope tab on page 48. 
If the buttons aren’t 
functioning, contact Surgical 
Science support. 
2. If either the scope buttons 
or connection port are 
damaged, contact Surgical 
Science Support. 
 
The scope’s wheels 
do not respond 
1. The scope wheel is 
damaged. 
2. The scope connection 
port is damaged. 
1. Check the functionality of 
the scope wheel in 
calibration program. See 
Scope tab on page 48. 
If wheels aren’t functioning, 
contact Surgical Science 
support. 
2. If either the scope wheels 
or connection port are 
damaged, contact Surgical 
Science Support. 
 
The resectoscope’s 
inflow/outflow valves 
do not respond 
1. The scope valve(s) are 
damaged. 
2. The scope connection 
port is damaged. 
1. Check the functionality of 
the scope inflow/outflow 
valves in calibration 
program. See TURP modules’ 
Scope tab on page 48. 
If wheels aren’t functioning, 
contact Surgical Science 
support. 
2. If either the scope wheels 
or connection port are 
damaged, contact Surgical 
Science Support. 
 


[TABLE]
| Chapter 6             |                           | Troubleshooting                |
|:----------------------|:--------------------------|:-------------------------------|
| The scope             | 1. The scope button is    | 1. Check the functionality of  |
| button/buttons do     | damaged.                  | the scope buttons in           |
| not respond           |                           | calibration program. See       |
|                       | 2. The scope connection   |                                |
|                       |                           | Scope tab on page 48.          |
|                       | port is damaged.          |                                |
|                       |                           | If the buttons aren’t          |
|                       |                           | functioning, contact Surgical  |
|                       |                           | Science support.               |
|                       |                           | 2. If either the scope buttons |
|                       |                           | or connection port are         |
|                       |                           | damaged, contact Surgical      |
|                       |                           | Science Support.               |
| The scope’s wheels    | 1. The scope wheel is     | 1. Check the functionality of  |
| do not respond        | damaged.                  | the scope wheel in             |
|                       |                           | calibration program. See       |
|                       | 2. The scope connection   |                                |
|                       |                           | Scope tab on page 48.          |
|                       | port is damaged.          |                                |
|                       |                           | If wheels aren’t functioning,  |
|                       |                           | contact Surgical Science       |
|                       |                           | support.                       |
|                       |                           | 2. If either the scope wheels  |
|                       |                           | or connection port are         |
|                       |                           | damaged, contact Surgical      |
|                       |                           | Science Support.               |
| The resectoscope’s    | 1. The scope valve(s) are | 1. Check the functionality of  |
| inflow/outflow valves | damaged.                  | the scope inflow/outflow       |
| do not respond        |                           | valves in calibration          |
|                       | 2. The scope connection   |                                |
|                       |                           | program. See TURP modules’     |
|                       | port is damaged.          |                                |
|                       |                           | Scope tab on page 48.          |
|                       |                           | If wheels aren’t functioning,  |
|                       |                           | contact Surgical Science       |
|                       |                           | support.                       |
|                       |                           | 2. If either the scope wheels  |
|                       |                           | or connection port are         |
|                       |                           | damaged, contact Surgical      |
|                       |                           | Science Support.               |

[OCR]
Chapter 6 Troubleshooting

The scope 1. The scope button is 1. Check the functionality of

button/buttons do damaged. the scope buttons in

not respond 2. The scope connection | Calibration program. See
port is damaged. Scope tab on page 48.

If the buttons aren't
functioning, contact Surgical
Science support.

2. If either the scope buttons
or connection port are
damaged, contact Surgical
Science Support.

The scope’s wheels 1. The scope wheel is 1. Check the functionality of
do not respond damaged. the scope wheel in
2. The scope connection | Calibration program. See
port is damaged. Scope tab on page 48.

If wheels aren't functioning,
contact Surgical Science
support.

2. If either the scope wheels
or connection port are
damaged, contact Surgical
Science Support.

The resectoscope’s 1. The scope valve(s) are | 1. Check the functionality of

inflow/outflow valves | damaged. the scope inflow/outflow
do not respond 2. The scope connection _| Valves in calibration
port is damaged. program. See TURP modules’

Scope tab on page 48.

If wheels aren't functioning,
contact Surgical Science
support.

2. If either the scope wheels
or connection port are
damaged, contact Surgical
Science Support.

surgicalscience Page 99


# Page 106

Chapter 6 
 Troubleshooting
 
Page 100 
 
The system is 
powered on but I can 
see “No Signal” 
message on the 
monitor. 
1. The PC is not turned 
ON. 
2. The graphic board is 
not connected or is 
malfunctioning.  
3. The signal cable is 
damaged or not 
functioning properly. 
1. Open the back cover and 
check that all cables are 
properly connected to the 
computer.  
2. Verify that all cables are 
connected to the monitor. 
If problem persists, contact 
Surgical Science support. 
3. Contact Surgical Science 
support. 
The Anatomy 
interchangeable 
cartridge is not 
recognized or one of 
the indicator lights is 
not working. 
The interchangeable 
cartridge is not 
recognized or one of the 
indicator lights is not 
working. 
Verify that the 
interchangeable cartridge is 
recognized and/or the 
indicator lights up using the 
Calibration software. See 
General tab on page 53. 
If there is a problem, contact 
Surgical Science support. 
 


[TABLE]
| Chapter 6               |                          | Troubleshooting                |
|:------------------------|:-------------------------|:-------------------------------|
| The system is           | 1. The PC is not turned  | 1. Open the back cover and     |
| powered on but I can    | ON.                      | check that all cables are      |
| see “No Signal”         |                          | properly connected to the      |
|                         | 2. The graphic board is  |                                |
| message on the          |                          | computer.                      |
|                         | not connected or is      |                                |
| monitor.                |                          |                                |
|                         | malfunctioning.          | 2. Verify that all cables are  |
|                         |                          | connected to the monitor.      |
|                         | 3. The signal cable is   |                                |
|                         | damaged or not           | If problem persists, contact   |
|                         | functioning properly.    | Surgical Science support.      |
|                         |                          | 3. Contact Surgical Science    |
|                         |                          | support.                       |
| The Anatomy             | The interchangeable      | Verify that the                |
| interchangeable         | cartridge is not         | interchangeable cartridge is   |
| cartridge is not        | recognized or one of the | recognized and/or the          |
| recognized or one of    | indicator lights is not  | indicator lights up using the  |
| the indicator lights is | working.                 | Calibration software. See      |
| not working.            |                          | General tab on page 53.        |
|                         |                          | If there is a problem, contact |
|                         |                          | Surgical Science support.      |

[OCR]
Chapter 6 Troubleshooting

The system is 1. The PC is not turned 1. Open the back cover and
powered on but I can | ON. check that all cables are
see “No Signal” 2. The graphic board is properly connected to the
message on the not connected or is computer.
monitor. malfunctioning. 2. Verify that all cables are
3. The signal cable is connected to the monitor.
damaged or not If problem persists, contact
functioning properly. Surgical Science support.
3. Contact Surgical Science
support.
The Anatomy The interchangeable Verify that the
interchangeable cartridge is not interchangeable cartridge is
cartridge is not recognized or one of the recognized and/or the
recognized or one of | indicator lights is not indicator lights up using the
the indicator lights is | working. Calibration software. See
not working. General tab on page 53.
If there is a problem, contact
Surgical Science support.

surgicalscience Page 100


# Page 107

Chapter 7 
 Technical Support
 
Page 101 
 
Chapter 7 Technical Support  
SURGICAL SCIENCE SUPPORT POLICY 
Surgical Science assigns the highest priority to customer support. We are committed 
to doing our utmost to provide our clients with reliable support and assistance 24 
hours a day, 7 days a week. This support is available in real time via telephone or 
email. 
Surgical Science Call Center 
Customer service 24/7: +1-216-270-2020 
email: support@surgicalscience.com 
 


[TABLE]
| Chapter 7                                                                           | Technical Support   |
|:------------------------------------------------------------------------------------|:--------------------|
| Chapter 7  Technical Support                                                        |                     |
| SURGICAL SCIENCE SUPPORT POLICY                                                     |                     |
| Surgical Science assigns the highest priority to customer support. We are committed |                     |
| to doing our utmost to provide our clients with reliable support and assistance 24  |                     |
| hours a day, 7 days a week. This support is available in real time via telephone or |                     |
| email.                                                                              |                     |
| Surgical Science Call Center                                                        |                     |
| Customer service 24/7: +1-216-270-2020                                              |                     |
| email: support@surgicalscience.com                                                  |                     |

[OCR_TABLE]
Chapter 7

[OCR]
Chapter 7 Technical Support

| Chapter 7 Technical Support
SURGICAL SCIENCE SUPPORT POLICY

Surgical Science assigns the highest priority to customer support. We are committed
to doing our utmost to provide our clients with reliable support and assistance 24
hours a day, 7 days a week. This support is available in real time via telephone or
email.

Surgical Science Call Center

Customer service 24/7: +1-216-270-2020

email: support@surgicalscience.com

surgicalscience Page 101


# Page 108

End-User Software License Agreement
 
Page 102 
 
Chapter 8 End-User Software License 
Agreement 
ENDO Mentor Suite® 
1.  DEFINITIONS 
This End-User License Agreement ("Agreement") is a legal agreement between you 
(either an individual or a single entity) and Surgical Science Sweden AB ("Surgical 
Science") for ENDO Mentor Suite® or such upgrade or future versions thereof 
identified in the Particulars or the License Key Issue Note, which includes computer 
software and may include associated media, printed materials, and electronic 
documentation ("Software"). 
 
11.  GRANT 
Surgical Science hereby grants to you a non-exclusive, non-transferable license to 
install and use one copy of the Software, or any prior version for the same operating 
system in accordance with the applicable license type (the type of license in your case 
can be found in the order form / invoice as well as in the License Key Issue Note from 
Surgical Science). The License hereby granted is subject to the following conditions. 
 
111.  CONDITIONS 
1  EXTENT OF LICENSE 
1.1  If you have acquired a hardware identity-based license you may install and use one 
copy of the Software, or any prior version for the same operating system on the single 
computer for which the License Key is issued. 


[TABLE]
| End-User Software License Agreement                                                     |
|:----------------------------------------------------------------------------------------|
| Chapter 8  End-User Software License                                                    |
| Agreement                                                                               |
| ENDO Mentor Suite®                                                                      |
| 1.  DEFINITIONS                                                                         |
| This End-User License Agreement ("Agreement") is a legal agreement between you          |
| (either an individual or a single entity) and Surgical Science Sweden AB ("Surgical     |
| Science") for ENDO Mentor Suite® or such upgrade or future versions thereof             |
| identified in the Particulars or the License Key Issue Note, which includes computer    |
| software and may include associated media, printed materials, and electronic            |
| documentation ("Software").                                                             |
| 1                                                                                       |
| 1.  GRANT                                                                               |
| Surgical Science hereby grants to you a non-exclusive, non-transferable license to      |
| install and use one copy of the Software, or any prior version for the same operating   |
| system in accordance with the applicable license type (the type of license in your case |
| can be found in the order form / invoice as well as in the License Key Issue Note from  |
| Surgical Science). The License hereby granted is subject to the following conditions.   |
| 1                                                                                       |
| 11.  CONDITIONS                                                                         |
| 1  EXTENT OF LICENSE                                                                    |
| 1.1  If you have acquired a hardware identity-based license you may install and use one |
| copy of the Software, or any prior version for the same operating system on the single  |
| computer for which the License Key is issued.                                           |
| Page 102                                                                                |

[OCR_TABLE]
' Cnapt

[OCR]
End-User Software License Agreement

| Chapter 8 End-User Software License
Agreement

ENDO Mentor Suite”

1. DEFINITIONS

This End-User License Agreement ("Agreement") is a legal agreement between you
(either an individual or a single entity) and Surgical Science Sweden AB ("Surgical
Science") for ENDO Mentor Suite® or such upgrade or future versions thereof
identified in the Particulars or the License Key Issue Note, which includes computer
software and may include associated media, printed materials, and electronic
documentation ("Software").

11. GRANT

Surgical Science hereby grants to you a non-exclusive, non-transferable license to
install and use one copy of the Software, or any prior version for the same operating
system in accordance with the applicable license type (the type of license in your case
can be found in the order form / invoice as well as in the License Key Issue Note from
Surgical Science). The License hereby granted is subject to the following conditions.

111. CONDITIONS
1 EXTENT OF LICENSE

1.1 If you have acquired a hardware identity-based license you may install and use one
copy of the Software, or any prior version for the same operating system on the single
computer for which the License Key is issued.

surgicalscience Page 102


# Page 109

End-User Software License Agreement
 
Page 103 
 
1.2  If you have acquired a hardware key ("dongle") based node locked license you 
may install and use one copy of the Software, or any prior version for the same 
operating system on the single computer to which the Hardware Key, for which the 
License Key is issued, is attached. Note that you are not obligated to remove the 
installed Software from the computer even if the Hardware Key is removed. However, 
you are not entitled to use the Software on that computer unless the Hardware key is 
reattached. 
1.3  If you have acquired a floating license, you may install one copy of the Software or 
any prior version for the same operating system on any number of computers and 
simultaneously use no more than the number of Software permitted in the License Key 
Issue Note. The rights of installation and use of Software is restricted to the site 
defined in the License Key Issue Note. 
1.4  If the Software is labeled as an upgrade, you must be properly licensed to use a 
product identified by Surgical Science as being eligible for the upgrade in order to use 
the Software. Software labeled as an upgrade replaces and/or supplements the 
product that formed the basis for your eligibility for the upgrade. You may use the 
resulting upgraded product only in accordance with the terms of this Agreement. 
1.5  If the Software is labeled as an upgrade, you must be properly licensed to use a 
product identified by Surgical Science as being eligible for the upgrade in order to use 
the Software. Software labeled as an upgrade replaces and/or supplements the 
product that formed the basis for your eligibility for the upgrade. You may use the 
resulting upgraded product only in accordance with the terms of this Agreement. 
1.6  This license is personal to you and you shall not assign or transfer any interest in it 
or grant any right under it to any third party or seek to exercise this license for the 
benefit or on the data of any third party. 
2  CONFIDENCE OF THE SOFTWARE AND COPYRIGHT 
2.1  The Software, all associated documentation, and all copies are secret and 
confidential to Surgical Science and shall be retained under the effective control of you 
during the period of this Agreement. Disclosures shall be limited to those members of 
your staff (including temporary staff) who need access to the Software to enable you 
to exercise this license. You shall take all measures necessary to maintain confidence 
and secrecy in the Software during the period of this license and after its termination, 
however such termination may arise. 


[TABLE]
| End-User Software License Agreement                                                          |
|:---------------------------------------------------------------------------------------------|
| 1.2  If you have acquired a hardware key ("dongle") based node locked license you            |
| may install and use one copy of the Software, or any prior version for the same              |
| operating system on the single computer to which the Hardware Key, for which the             |
| License Key is issued, is attached. Note that you are not obligated to remove the            |
| installed Software from the computer even if the Hardware Key is removed. However,           |
| you are not entitled to use the Software on that computer unless the Hardware key is         |
| reattached.                                                                                  |
| 1.3  If you have acquired a floating license, you may install one copy of the Software or    |
| any prior version for the same operating system on any number of computers and               |
| simultaneously use no more than the number of Software permitted in the License Key          |
| Issue Note. The rights of installation and use of Software is restricted to the site         |
| defined in the License Key Issue Note.                                                       |
| 1.4  If the Software is labeled as an upgrade, you must be properly licensed to use a        |
| product identified by Surgical Science as being eligible for the upgrade in order to use     |
| the Software. Software labeled as an upgrade replaces and/or supplements the                 |
| product that formed the basis for your eligibility for the upgrade. You may use the          |
| resulting upgraded product only in accordance with the terms of this Agreement.              |
| 1.5  If the Software is labeled as an upgrade, you must be properly licensed to use a        |
| product identified by Surgical Science as being eligible for the upgrade in order to use     |
| the Software. Software labeled as an upgrade replaces and/or supplements the                 |
| product that formed the basis for your eligibility for the upgrade. You may use the          |
| resulting upgraded product only in accordance with the terms of this Agreement.              |
| 1.6  This license is personal to you and you shall not assign or transfer any interest in it |
| or grant any right under it to any third party or seek to exercise this license for the      |
| benefit or on the data of any third party.                                                   |
| 2  CONFIDENCE OF THE SOFTWARE AND COPYRIGHT                                                  |
| 2.1  The Software, all associated documentation, and all copies are secret and               |
| confidential to Surgical Science and shall be retained under the effective control of you    |
| during the period of this Agreement. Disclosures shall be limited to those members of        |
| your staff (including temporary staff) who need access to the Software to enable you         |
| to exercise this license. You shall take all measures necessary to maintain confidence       |
| and secrecy in the Software during the period of this license and after its termination,     |
| however such termination may arise.                                                          |

[OCR_TABLE]
1.2 If you |

[OCR_TABLE]
License Ke
inetallad Cc

[OCR]
End-User Software License Agreement

1.2 If you have acquired a hardware key ("dongle") based node locked license you
may install and use one copy of the Software, or any prior version for the same
operating system on the single computer to which the Hardware Key, for which the
License Key is issued, is attached. Note that you are not obligated to remove the
installed Software from the computer even if the Hardware Key is removed. However,
you are not entitled to use the Software on that computer unless the Hardware key is
reattached.

1.3 If you have acquired a floating license, you may install one copy of the Software or
any prior version for the same operating system on any number of computers and
simultaneously use no more than the number of Software permitted in the License Key
Issue Note. The rights of installation and use of Software is restricted to the site
defined in the License Key Issue Note.

1.4 If the Software is labeled as an upgrade, you must be properly licensed to use a
product identified by Surgical Science as being eligible for the upgrade in order to use
the Software. Software labeled as an upgrade replaces and/or supplements the
product that formed the basis for your eligibility for the upgrade. You may use the
resulting upgraded product only in accordance with the terms of this Agreement.

1.5 If the Software is labeled as an upgrade, you must be properly licensed to use a
product identified by Surgical Science as being eligible for the upgrade in order to use
the Software. Software labeled as an upgrade replaces and/or supplements the
product that formed the basis for your eligibility for the upgrade. You may use the
resulting upgraded product only in accordance with the terms of this Agreement.

1.6 This license is personal to you and you shall not assign or transfer any interest in it
or grant any right under it to any third party or seek to exercise this license for the
benefit or on the data of any third party.

2 CONFIDENCE OF THE SOFTWARE AND COPYRIGHT

2.1 The Software, all associated documentation, and all copies are secret and
confidential to Surgical Science and shall be retained under the effective control of you
during the period of this Agreement. Disclosures shall be limited to those members of
your staff (including temporary staff) who need access to the Software to enable you
to exercise this license. You shall take all measures necessary to maintain confidence
and secrecy in the Software during the period of this license and after its termination,
however such termination may arise.

surgicalscience Page 103


# Page 110

End-User Software License Agreement
 
Page 104 
 
2.2  All title and copyrights and patents in and to the Software (including but not 
limited to any images, photographs, animations, video, audio, music, text, techniques 
and "applets" incorporated into the Software), the accompanying printed materials, 
and any copies of the Software are owned by Surgical Science or its suppliers. The 
Software is protected by copyright laws and patents laws as well as by international 
treaty provisions. Therefore, you must treat the Software like any other copyrighted or 
patented material. You may not copy the printed materials accompanying the 
Software. 
3  OWNERSHIP OF SOFTWARE 
3.1  Subject to the rights granted to you by this Agreement, you acknowledge that all 
and any proprietary rights in the software (including but not limited to copyrights, 
patents, trademarks and trade secrets) and in all associated documentation and other 
material related to the Software in each case now existing or to be developed by 
Surgical Science shall remain the sole property of Surgical Science. 
3.2  Usage Data. You acknowledge and agree that Surgical Science may derive or 
create data and information about the use of the Software by you and your users 
("Usage Data") and Surgical Science may use and disclose Usage Data to its third-
party service providers in order to improve the Software. Personal data related to any 
identifiable individual is not collected by Surgical Science. 
4  SUPPORT SERVICES 
4.1  Surgical Science may provide you with support services related to the Software 
("Support Services"). Use of Support Services is governed by the Surgical Science 
policies and programs described in the user manual, in "online" documentation, and/or 
in other Surgical Science-provided materials. Any supplemental software provided to 
you as part of the Support Services shall be considered part of the Software and 
subject to the terms and conditions of this Agreement. With respect to technical 
information you provide to Surgical Science as part of the Support Services, Surgical 
Science may use such information for its business purposes, including for product 
support and development. Surgical Science will not utilize such technical information in 
a form that personally identifies you. 


[TABLE]
| End-User Software License Agreement                                                      |
|:-----------------------------------------------------------------------------------------|
| 2.2  All title and copyrights and patents in and to the Software (including but not      |
| limited to any images, photographs, animations, video, audio, music, text, techniques    |
| and "applets" incorporated into the Software), the accompanying printed materials,       |
| and any copies of the Software are owned by Surgical Science or its suppliers. The       |
| Software is protected by copyright laws and patents laws as well as by international     |
| treaty provisions. Therefore, you must treat the Software like any other copyrighted or  |
| patented material. You may not copy the printed materials accompanying the               |
| Software.                                                                                |
| 3  OWNERSHIP OF SOFTWARE                                                                 |
| 3.1  Subject to the rights granted to you by this Agreement, you acknowledge that all    |
| and any proprietary rights in the software (including but not limited to copyrights,     |
| patents, trademarks and trade secrets) and in all associated documentation and other     |
| material related to the Software in each case now existing or to be developed by         |
| Surgical Science shall remain the sole property of Surgical Science.                     |
| 3.2  Usage Data. You acknowledge and agree that Surgical Science may derive or           |
| create data and information about the use of the Software by you and your users          |
| ("Usage Data") and Surgical Science may use and disclose Usage Data to its third-        |
| party service providers in order to improve the Software. Personal data related to any   |
| identifiable individual is not collected by Surgical Science.                            |
| 4  SUPPORT SERVICES                                                                      |
| 4.1  Surgical Science may provide you with support services related to the Software      |
| ("Support Services"). Use of Support Services is governed by the Surgical Science        |
| policies and programs described in the user manual, in "online" documentation, and/or    |
| in other Surgical Science-provided materials. Any supplemental software provided to      |
| you as part of the Support Services shall be considered part of the Software and         |
| subject to the terms and conditions of this Agreement. With respect to technical         |
| information you provide to Surgical Science as part of the Support Services, Surgical    |
| Science may use such information for its business purposes, including for product        |
| support and development. Surgical Science will not utilize such technical information in |
| a form that personally identifies you.                                                   |

[OCR_TABLE]
2.2 All title

[OCR_TABLE]
and "apple
and any co

[OCR]
End-User Software License Agreement

2.2 All title and copyrights and patents in and to the Software (including but not
limited to any images, photographs, animations, video, audio, music, text, techniques
and "applets" incorporated into the Software), the accompanying printed materials,
and any copies of the Software are owned by Surgical Science or its suppliers. The
Software is protected by copyright laws and patents laws as well as by international
treaty provisions. Therefore, you must treat the Software like any other copyrighted or
patented material. You may not copy the printed materials accompanying the
Software.

3 OWNERSHIP OF SOFTWARE

3.1 Subject to the rights granted to you by this Agreement, you acknowledge that all
and any proprietary rights in the software (including but not limited to copyrights,
patents, trademarks and trade secrets) and in all associated documentation and other
material related to the Software in each case now existing or to be developed by
Surgical Science shall remain the sole property of Surgical Science.

3.2 Usage Data. You acknowledge and agree that Surgical Science may derive or
create data and information about the use of the Software by you and your users
("Usage Data") and Surgical Science may use and disclose Usage Data to its third-
party service providers in order to improve the Software. Personal data related to any
identifiable individual is not collected by Surgical Science.

4 SUPPORT SERVICES

4.1 Surgical Science may provide you with support services related to the Software
("Support Services"). Use of Support Services is governed by the Surgical Science
policies and programs described in the user manual, in "online" documentation, and/or
in other Surgical Science-provided materials. Any supplemental software provided to
you as part of the Support Services shall be considered part of the Software and
subject to the terms and conditions of this Agreement. With respect to technical
information you provide to Surgical Science as part of the Support Services, Surgical
Science may use such information for its business purposes, including for product
support and development. Surgical Science will not utilize such technical information in
a form that personally identifies you.

surgicalscience Page 104


# Page 111

End-User Software License Agreement
 
Page 105 
 
5  INTEGRITY OF THE SOFTWARE 
5.1  You shall not, directly or indirectly in any form or manner, copy, distribute, 
reproduce, incorporate or allow unauthorized use or access to the Software or modify, 
decompile, reverse engineer, disassemble or otherwise attempt to derive a source 
code or similar information from Software, except as explicitly permitted under this 
Agreement. 
5.2  The Software is licensed as a single product. Its component parts may not be 
separated for use on more than one computer. 
5.3  You shall ensure that all copies of and extracts from the Software and its 
associated documentation made or disclosed by you carry Surgical Science’ copyright 
notice in the form shown on the original, or such other copyright notices as Surgical 
Science may specify from time to time and shall ensure that no such notice is deleted. 
6  RIGHT OF ACCESS 
6.1  For the purpose only of verifying your compliance with these conditions, you 
hereby irrevocable grants permission for Surgical Science and its authorized 
representatives during normal business hours to enter the premises from time to time 
wholly or partly occupied by you and in each case there to access, operate, and 
inspect computer equipment and to access, inspect and take copies of documents and 
records (including magnetic and other media). Surgical Science shall exercise this right 
only for the above purpose and shall observe strict confidence in all information which 
it obtains as a result of such inspections except to the extent that disclosure to third 
parties is necessary for the purposes of protecting Surgical Science’ rights in the 
Software. 


[TABLE]
| End-User Software License Agreement                                                      |
|:-----------------------------------------------------------------------------------------|
| 5  INTEGRITY OF THE SOFTWARE                                                             |
| 5.1  You shall not, directly or indirectly in any form or manner, copy, distribute,      |
| reproduce, incorporate or allow unauthorized use or access to the Software or modify,    |
| decompile, reverse engineer, disassemble or otherwise attempt to derive a source         |
| code or similar information from Software, except as explicitly permitted under this     |
| Agreement.                                                                               |
| 5.2  The Software is licensed as a single product. Its component parts may not be        |
| separated for use on more than one computer.                                             |
| 5.3  You shall ensure that all copies of and extracts from the Software and its          |
| associated documentation made or disclosed by you carry Surgical Science’ copyright      |
| notice in the form shown on the original, or such other copyright notices as Surgical    |
| Science may specify from time to time and shall ensure that no such notice is deleted.   |
| 6  RIGHT OF ACCESS                                                                       |
| 6.1  For the purpose only of verifying your compliance with these conditions, you        |
| hereby irrevocable grants permission for Surgical Science and its authorized             |
| representatives during normal business hours to enter the premises from time to time     |
| wholly or partly occupied by you and in each case there to access, operate, and          |
| inspect computer equipment and to access, inspect and take copies of documents and       |
| records (including magnetic and other media). Surgical Science shall exercise this right |
| only for the above purpose and shall observe strict confidence in all information which  |
| it obtains as a result of such inspections except to the extent that disclosure to third |
| parties is necessary for the purposes of protecting Surgical Science’ rights in the      |
| Software.                                                                                |

[OCR_TABLE]
5 INTEGRI

[OCR]
End-User Software License Agreement

5 INTEGRITY OF THE SOFTWARE

5.1 You shall not, directly or indirectly in any form or manner, copy, distribute,
reproduce, incorporate or allow unauthorized use or access to the Software or modify,
decompile, reverse engineer, disassemble or otherwise attempt to derive a source
code or similar information from Software, except as explicitly permitted under this
Agreement.

5.2 The Software is licensed as a single product. Its component parts may not be
separated for use on more than one computer.

5.3 You shall ensure that all copies of and extracts from the Software and its
associated documentation made or disclosed by you carry Surgical Science’ copyright
notice in the form shown on the original, or such other copyright notices as Surgical
Science may specify from time to time and shall ensure that no such notice is deleted.

6 RIGHT OF ACCESS

6.1 For the purpose only of verifying your compliance with these conditions, you
hereby irrevocable grants permission for Surgical Science and its authorized
representatives during normal business hours to enter the premises from time to time
wholly or partly occupied by you and in each case there to access, operate, and
inspect computer equipment and to access, inspect and take copies of documents and
records (including magnetic and other media). Surgical Science shall exercise this right
only for the above purpose and shall observe strict confidence in all information which
it obtains as a result of such inspections except to the extent that disclosure to third
parties is necessary for the purposes of protecting Surgical Science’ rights in the
Software.

surgicalscience Page 105


# Page 112

End-User Software License Agreement
 
Page 106 
 
7  WARRANTY AND LIMITATION OF LIABILITY 
7.1  Surgical Science warrants that (i) the Software will perform substantially in 
accordance with the accompanying written materials for a period of ninety (90) days 
from the date of receipt, and (ii) any Support Services provided by Surgical Science 
shall be substantially as described in applicable written materials provided to you by 
Surgical Science, and Surgical Science support engineers will make commercially 
reasonable efforts to solve any problem issues. Some jurisdictions do not allow 
limitations on duration of an implied warranty, so the above limitation may not apply to 
you. To the extent allowed by applicable law, implied warranties on the Software, if 
any, are limited to ninety (90) days. 
The above said warranty is void if failure of the Software has resulted from accident, 
abuse, or misapplication. Any replacement Software will be warranted for the 
remainder of the original warranty period or thirty (30) days, whichever is longer. 
Neither these remedies nor any Support Services offered by Surgical Science are 
available without proof of purchase from an authorized source. 
7.2  To the maximum extent permitted by applicable law, Surgical Science and its 
suppliers disclaim all other warranties and conditions, either express or implied, 
including, but not limited to, implied warranties of fitness for a particular purpose, title, 
and non-infringement, with regard to the Software, and the provision of or failure to 
provide Support Services. 
7.3  To the maximum extent permitted by applicable law, in no event shall Surgical 
Science or its suppliers be liable for any special, incidental, indirect, or consequential 
damages whatsoever (including, without limitation, damages for loss of business 
profits, business interruption or loss of business information) arising out of the use of 
or inability to use the Software or the provision of or failure to provide Support 
Services. However, if you have entered into a Surgical Science Support Services 
agreement, Surgical Science’ entire liability regarding Support Services shall be 
governed by the terms of that agreement. 
7.4  Surgical Science’ entire liability under any provision of this Agreement and your 
exclusive remedy shall be, at Surgical Science’ sole discretion to, either (i) return of the 
amount actually paid by you for the Software, if any, or (ii) repair or replacement of the 
Software that does not meet Surgical Science’ warranty and which is returned to 
Surgical Science with a copy of your receipt. 


[TABLE]
| End-User Software License Agreement                                                           |
|:----------------------------------------------------------------------------------------------|
| 7  WARRANTY AND LIMITATION OF LIABILITY                                                       |
| 7.1  Surgical Science warrants that (i) the Software will perform substantially in            |
| accordance with the accompanying written materials for a period of ninety (90) days           |
| from the date of receipt, and (ii) any Support Services provided by Surgical Science          |
| shall be substantially as described in applicable written materials provided to you by        |
| Surgical Science, and Surgical Science support engineers will make commercially               |
| reasonable efforts to solve any problem issues. Some jurisdictions do not allow               |
| limitations on duration of an implied warranty, so the above limitation may not apply to      |
| you. To the extent allowed by applicable law, implied warranties on the Software, if          |
| any, are limited to ninety (90) days.                                                         |
| The above said warranty is void if failure of the Software has resulted from accident,        |
| abuse, or misapplication. Any replacement Software will be warranted for the                  |
| remainder of the original warranty period or thirty (30) days, whichever is longer.           |
| Neither these remedies nor any Support Services offered by Surgical Science are               |
| available without proof of purchase from an authorized source.                                |
| 7.2  To the maximum extent permitted by applicable law, Surgical Science and its              |
| suppliers disclaim all other warranties and conditions, either express or implied,            |
| including, but not limited to, implied warranties of fitness for a particular purpose, title, |
| and non-infringement, with regard to the Software, and the provision of or failure to         |
| provide Support Services.                                                                     |
| 7.3  To the maximum extent permitted by applicable law, in no event shall Surgical            |
| Science or its suppliers be liable for any special, incidental, indirect, or consequential    |
| damages whatsoever (including, without limitation, damages for loss of business               |
| profits, business interruption or loss of business information) arising out of the use of     |
| or inability to use the Software or the provision of or failure to provide Support            |
| Services. However, if you have entered into a Surgical Science Support Services               |
| agreement, Surgical Science’ entire liability regarding Support Services shall be             |
| governed by the terms of that agreement.                                                      |
| 7.4  Surgical Science’ entire liability under any provision of this Agreement and your        |
| exclusive remedy shall be, at Surgical Science’ sole discretion to, either (i) return of the  |
| amount actually paid by you for the Software, if any, or (ii) repair or replacement of the    |
| Software that does not meet Surgical Science’ warranty and which is returned to               |
| Surgical Science with a copy of your receipt.                                                 |

[OCR_TABLE]
7 WARRAT

[OCR_TABLE]
IA Qiyirnin

[OCR_TABLE]
fe —h—e ws

accordanc

[OCR]
End-User Software License Agreement

7 WARRANTY AND LIMITATION OF LIABILITY

7.1 Surgical Science warrants that (i) the Software will perform substantially in
accordance with the accompanying written materials for a period of ninety (90) days
from the date of receipt, and (ii) any Support Services provided by Surgical Science
shall be substantially as described in applicable written materials provided to you by
Surgical Science, and Surgical Science support engineers will make commercially
reasonable efforts to solve any problem issues. Some jurisdictions do not allow
limitations on duration of an implied warranty, so the above limitation may not apply to
you. To the extent allowed by applicable law, implied warranties on the Software, if
any, are limited to ninety (90) days.

The above said warranty is void if failure of the Software has resulted from accident,
abuse, or misapplication. Any replacement Software will be warranted for the
remainder of the original warranty period or thirty (30) days, whichever is longer.
Neither these remedies nor any Support Services offered by Surgical Science are
available without proof of purchase from an authorized source.

7.2 To the maximum extent permitted by applicable law, Surgical Science and its
suppliers disclaim all other warranties and conditions, either express or implied,
including, but not limited to, implied warranties of fitness for a particular purpose, title,
and non-infringement, with regard to the Software, and the provision of or failure to
provide Support Services.

7.3 To the maximum extent permitted by applicable law, in no event shall Surgical
Science or its suppliers be liable for any special, incidental, indirect, or consequential
damages whatsoever (including, without limitation, damages for loss of business
profits, business interruption or loss of business information) arising out of the use of
or inability to use the Software or the provision of or failure to provide Support
Services. However, if you have entered into a Surgical Science Support Services
agreement, Surgical Science’ entire liability regarding Support Services shall be
governed by the terms of that agreement.

7.4 Surgical Science’ entire liability under any provision of this Agreement and your
exclusive remedy shall be, at Surgical Science’ sole discretion to, either (i) return of the
amount actually paid by you for the Software, if any, or (ii) repair or replacement of the
Software that does not meet Surgical Science’ warranty and which is returned to
Surgical Science with a copy of your receipt.

surgicalscience Page 106


# Page 113

End-User Software License Agreement
 
Page 107 
 
8  TERMINATION 
8.1  If this license is a Trial license, you shall be entitled to return the Software to 
Surgical Science on or before Trial Expiry Date specified in the License Key Issue Note 
and, in that event, this Agreement shall then terminate. Unless otherwise agreed under 
special conditions, no license fee or other charges shall be payable by you in respect 
of the trial. 
8.2  Unless terminated pursuant to 8.3 below this Agreement shall continue until the 
expiry date, if any, specified in the Particulars or the License Key Issue Note. 
8.3  This Agreement may be terminated by Surgical Science at any time by written 
notice of termination: 
8.3.1.  if you shall expressly or impliedly repudiate this license by refusing or 
threatening to refuse to observe any of the conditions to which this license is subject; 
or 
8.3.2  if you shall fail to make payment of any amount due to and invoiced by Surgical 
Science or to observe any of the conditions to which this license is subject and, after 
your attention has been drawn by notice to such failure, shall fail to remedy the matter 
to Surgical Science's reasonable satisfaction within thirty days of the giving or such 
notice; or 
8.3.3  if you shall have a receiver or administrative receiver or administrator appointed 
or shall enter into liquidation whether compulsory or voluntary or if you or any member 
of your partnership shall be unable to pay its debts as and when they fall due or any 
judgment or execution or other process issued in respect of any judgment against you 
is unsatisfied for fourteen days. 
8.4  On expiry, surrender or other termination of this Agreement, however such 
termination may arise, you shall cease to load, store, copy or use the Software, shall 
delete the Software from the any computers on which the Software is installed or 
copied and at Surgical Science's option shall either surrender the Software and all 
documentation and other related materials to Surgical Science or shall destroy the 
Software with all documentation and other related materials and deliver to Surgical 
Science a certificate of comprehensive destruction. You shall continue after 
termination to observe and enforce confidence and secrecy in respect of the Software 
and its documentation and related materials for the benefit of Surgical Science, and 
however termination may occur it shall not prejudice any right of action or remedy 
which may have accrued prior to termination. 


[TABLE]
| End-User Software License Agreement                                                       |
|:------------------------------------------------------------------------------------------|
| 8  TERMINATION                                                                            |
| 8.1  If this license is a Trial license, you shall be entitled to return the Software to  |
| Surgical Science on or before Trial Expiry Date specified in the License Key Issue Note   |
| and, in that event, this Agreement shall then terminate. Unless otherwise agreed under    |
| special conditions, no license fee or other charges shall be payable by you in respect    |
| of the trial.                                                                             |
| 8.2  Unless terminated pursuant to 8.3 below this Agreement shall continue until the      |
| expiry date, if any, specified in the Particulars or the License Key Issue Note.          |
| 8.3  This Agreement may be terminated by Surgical Science at any time by written          |
| notice of termination:                                                                    |
| 8.3.1.  if you shall expressly or impliedly repudiate this license by refusing or         |
| threatening to refuse to observe any of the conditions to which this license is subject;  |
| or                                                                                        |
| 8.3.2  if you shall fail to make payment of any amount due to and invoiced by Surgical    |
| Science or to observe any of the conditions to which this license is subject and, after   |
| your attention has been drawn by notice to such failure, shall fail to remedy the matter  |
| to Surgical Science's reasonable satisfaction within thirty days of the giving or such    |
| notice; or                                                                                |
| 8.3.3  if you shall have a receiver or administrative receiver or administrator appointed |
| or shall enter into liquidation whether compulsory or voluntary or if you or any member   |
| of your partnership shall be unable to pay its debts as and when they fall due or any     |
| judgment or execution or other process issued in respect of any judgment against you      |
| is unsatisfied for fourteen days.                                                         |
| 8.4  On expiry, surrender or other termination of this Agreement, however such            |
| termination may arise, you shall cease to load, store, copy or use the Software, shall    |
| delete the Software from the any computers on which the Software is installed or          |
| copied and at Surgical Science's option shall either surrender the Software and all       |
| documentation and other related materials to Surgical Science or shall destroy the        |
| Software with all documentation and other related materials and deliver to Surgical       |
| Science a certificate of comprehensive destruction. You shall continue after              |
| termination to observe and enforce confidence and secrecy in respect of the Software      |
| and its documentation and related materials for the benefit of Surgical Science, and      |
| however termination may occur it shall not prejudice any right of action or remedy        |
| which may have accrued prior to termination.                                              |

[OCR_TABLE]
Q TERMIN

[OCR_TABLE]
8.1 If this |
Surgical Sc

[OCR]
End-User Software License Agreement

8 TERMINATION

8.1 If this license is a Trial license, you shall be entitled to return the Software to
Surgical Science on or before Trial Expiry Date specified in the License Key Issue Note
and, in that event, this Agreement shall then terminate. Unless otherwise agreed under
special conditions, no license fee or other charges shall be payable by you in respect
of the trial.

8.2 Unless terminated pursuant to 8.3 below this Agreement shall continue until the
expiry date, if any, specified in the Particulars or the License Key Issue Note.

8.3 This Agreement may be terminated by Surgical Science at any time by written
notice of termination:

8.3.1. if you shall expressly or impliedly repudiate this license by refusing or
threatening to refuse to observe any of the conditions to which this license is subject;
or

8.3.2 if you shall fail to make payment of any amount due to and invoiced by Surgical
Science or to observe any of the conditions to which this license is subject and, after
your attention has been drawn by notice to such failure, shall fail to remedy the matter
to Surgical Science's reasonable satisfaction within thirty days of the giving or such
notice; or

8.3.3 if you shall have a receiver or administrative receiver or administrator appointed
or shall enter into liquidation whether compulsory or voluntary or if you or any member
of your partnership shall be unable to pay its debts as and when they fall due or any
judgment or execution or other process issued in respect of any judgment against you
is unsatisfied for fourteen days.

8.4 On expiry, surrender or other termination of this Agreement, however such
termination may arise, you shall cease to load, store, copy or use the Software, shall
delete the Software from the any computers on which the Software is installed or
copied and at Surgical Science's option shall either surrender the Software and all
documentation and other related materials to Surgical Science or shall destroy the
Software with all documentation and other related materials and deliver to Surgical
Science a certificate of comprehensive destruction. You shall continue after
termination to observe and enforce confidence and secrecy in respect of the Software
and its documentation and related materials for the benefit of Surgical Science, and
however termination may occur it shall not prejudice any right of action or remedy
which may have accrued prior to termination.

surgicalscience Page 107


# Page 114

End-User Software License Agreement
 
Page 108 
 
9.  MISCELLANEOUS 
9.1  This Agreement is governed by Swedish law and any disputes arising out of or in 
connection to this Agreement shall be submitted to the exclusive jurisdiction of the 
Swedish courts. 
9.2  The headings to these Conditions are included for convenience only and do not 
affect their interpretation. 
9.3  Should you have any questions concerning this Agreement, or if you desire to 
contact Surgical Science for any reason, please contact Surgical Science (write or e-
mail): Surgical Science Sweden AB, Drakegatan 7, SE-412 50 Göteborg, Sweden, 
[info@surgical-science.com]. 
 


[TABLE]
| End-User Software License Agreement                                                   |
|:--------------------------------------------------------------------------------------|
| 9.  MISCELLANEOUS                                                                     |
| 9.1  This Agreement is governed by Swedish law and any disputes arising out of or in  |
| connection to this Agreement shall be submitted to the exclusive jurisdiction of the  |
| Swedish courts.                                                                       |
| 9.2  The headings to these Conditions are included for convenience only and do not    |
| affect their interpretation.                                                          |
| 9.3  Should you have any questions concerning this Agreement, or if you desire to     |
| contact Surgical Science for any reason, please contact Surgical Science (write or e- |
| mail): Surgical Science Sweden AB, Drakegatan 7, SE-412 50 Göteborg, Sweden,          |
| [info@surgical-science.com].                                                          |

[OCR]
End-User Software License Agreement

9. MISCELLANEOUS

9.1 This Agreement is governed by Swedish law and any disputes arising out of or in
connection to this Agreement shall be submitted to the exclusive jurisdiction of the
Swedish courts.

9.2 The headings to these Conditions are included for convenience only and do not
affect their interpretation.

9.3 Should you have any questions concerning this Agreement, or if you desire to
contact Surgical Science for any reason, please contact Surgical Science (write or e-
mail): Surgical Science Sweden AB, Drakegatan 7, SE-412 50 Géteborg, Sweden,
[info@surgical-science.com].

surgicalscience Page 108


# Page 115

Index
 
Page 109 
 
Index 
A 
Adjusting platform height, 16 
Assembly, 34 
C 
Calibration, 46 
Ascension tab 
BRONCH Mentor, 64 
GI Mentor, 52 
HYST Mentor, 88 
TURP modules, 79 
URO Mentor, 72 
BRONCH Mentor, 60 
Duodenoscope Lever, 59 
General tab 
BRONCH Mentor, 65 
GI Mentor, 53 
HYST Mentor, 89 
URO Mentor, 74 
GI Mentor, 47 
HYST Mentor, 84 
Roll Calibration tab 
BRONCH Mentor, 66 
GI Mentor, 56 
HYST Mentor, 90 
TURP modules, 81 
URO Mentor, 75 
Scope tab 
BRONCH Mentor, 60 
GI Mentor, 48 
HYST Mentor, 84 
TURP modules, 75 
URO Mentor, 66 
Tools tab 
BRONCH Mentor, 62 
GI Mentor, 50 
URO Mentor, 70 
TURP modules, 75 
URO Mentor, 66 
Camera, 29 
Colonoscope, 22 
Connecting the scope, 14 
Cystoscope 
flexible, 27 
rigid, 25 
D 
Duodenoscope, 23 
E 
EBUS needle, 33 
ENDO Mentor Suite 
assembly, 34 
calibration, 46 
checking for problems, 46 
components, 6 
platform, 5 
setup, 34 
troubleshooting, 94 
F 
Flexible cystoscope, 27 
Flexible ureteroscope, 27 
Foot, 21 
Foot switch, 21 
Forceps, 31 
G 
GI interchangeable panel, 9 
GI wires, 31 
H 
Hardware, 5 
Height elevation mechanism, 17 


[TABLE]
|                        | rigid, 25                      |
|:-----------------------|:-------------------------------|
| C                      |                                |
| Calibration, 46        | D                              |
| Ascension tab          |                                |
|                        | Duodenoscope, 23               |
| BRONCH Mentor, 64      |                                |
| GI Mentor, 52          |                                |
| HYST Mentor, 88        | E                              |
| TURP modules, 79       |                                |
|                        | EBUS needle, 33                |
| URO Mentor, 72         |                                |
|                        | ENDO Mentor Suite              |
| BRONCH Mentor, 60      |                                |
|                        | assembly, 34                   |
| Duodenoscope Lever, 59 |                                |
|                        | calibration, 46                |
| General tab            |                                |
|                        | checking for problems, 46      |
| BRONCH Mentor, 65      |                                |
|                        | components, 6                  |
| GI Mentor, 53          |                                |
|                        | platform, 5                    |
| HYST Mentor, 89        |                                |
|                        | setup, 34                      |
| URO Mentor, 74         |                                |
|                        | troubleshooting, 94            |
| GI Mentor, 47          |                                |
| HYST Mentor, 84        |                                |
| Roll Calibration tab   | F                              |
| BRONCH Mentor, 66      |                                |
|                        | Flexible cystoscope, 27        |
| GI Mentor, 56          |                                |
|                        | Flexible ureteroscope, 27      |
| HYST Mentor, 90        |                                |
|                        | Foot, 21                       |
| TURP modules, 81       |                                |
|                        | Foot switch, 21                |
| URO Mentor, 75         |                                |
|                        | Forceps, 31                    |
| Scope tab              |                                |
| BRONCH Mentor, 60      |                                |
|                        |                                |
| GI Mentor, 48          | G                              |
| HYST Mentor, 84        |                                |
|                        | GI interchangeable panel, 9    |
| TURP modules, 75       |                                |
|                        | GI wires, 31                   |
| URO Mentor, 66         |                                |
| Tools tab              |                                |
|                        |                                |
| BRONCH Mentor, 62      | H                              |
| GI Mentor, 50          |                                |
| URO Mentor, 70         | Hardware, 5                    |
| TURP modules, 75       | Height elevation mechanism, 17 |

[OCR]
Index

| Index

A

Adjusting platform height, 16

Assembly, 34

Cc

Calibration, 46

Ascension tab

BRONCH Mentor, 64

Gl Mentor, 52
HYST Mentor, 88
TURP modules, 79
URO Mentor, 72
BRONCH Mentor, 60
Duodenoscope Lever, 59
General tab
BRONCH Mentor, 65
GI Mentor, 53
HYST Mentor, 89
URO Mentor, 74
Gl Mentor, 47
HYST Mentor, 84
Roll Calibration tab

BRONCH Mentor, 66
Gl Mentor, 56
HYST Mentor, 90
TURP modules, 81
URO Mentor, 75
Scope tab
BRONCH Mentor, 60
Gl Mentor, 48
HYST Mentor, 84
TURP modules, 75
U
le)

RO Mentor, 66

Tools tab

BRONCH Mentor, 62
Gl Mentor, 50

URO Mentor, 70
TURP modules, 75
URO Mentor, 66

Camera, 29
Colonoscope, 22
Connecting the scope, 14

Cystoscope
flexible, 27
rigid, 25
D
Duodenoscope, 23
E

EBUS needle, 33

ENDO Mentor Suite
assembly, 34
calibration, 46
checking for problems, 46
components, 6
platform, 5
setup, 34
troubleshooting, 94

F

Flexible cystoscope, 27
Flexible ureteroscope, 27
Foot, 21

Foot switch, 21

Forceps, 31

G

Gl interchangeable panel, 9
Gl wires, 31

H

Hardware, 5

Height elevation mechanism, 17

surgicalscience

Page 109


# Page 116

Index
 
Page 110 
 
M 
Master tool, 30 
Modality extensions, 15 
P 
Package components, 7 
Packaging instructions, 34 
R 
Resectoscope 
camera, 29 
Resectoscope, 28 
Rigid cystoscope, 25 
Rigid ureteroscope, 26 
S 
Scope 
connectors, 14 
hanger, 13 
Scopes, 24 
colonoscope, 22 
duodenoscope, 23 
Setup, 34 
turning on system, 44 
Setup instructions, 40 
Simulator 
hardware, 5 
Specifications, 7 
Syringe, 32 
T 
Tool tray, 17 
connection outlets, 20, 44 
Troubleshooting, 94 
Turning on the simulator, 17 
U 
Unpacking instructions, 34 
Ureteroscope 
flexible, 27 
rigid, 26 
URO interchangeable panel, 11 
 


[TABLE]
|                            | colonoscope, 22               |
|:---------------------------|:------------------------------|
| M                          |                               |
|                            | duodenoscope, 23              |
| Master tool, 30            | Setup, 34                     |
| Modality extensions, 15    | turning on system, 44         |
|                            | Setup instructions, 40        |
|                            | Simulator                     |
| P                          |                               |
|                            | hardware, 5                   |
| Package components, 7      | Specifications, 7             |
| Packaging instructions, 34 | Syringe, 32                   |
| R                          | T                             |
| Resectoscope               | Tool tray, 17                 |
| camera, 29                 | connection outlets, 20, 44    |
| Resectoscope, 28           | Troubleshooting, 94           |
| Rigid cystoscope, 25       | Turning on the simulator, 17  |
| Rigid ureteroscope, 26     |                               |
|                            | U                             |
| S                          |                               |
|                            | Unpacking instructions, 34    |
| Scope                      | Ureteroscope                  |
| connectors, 14             | flexible, 27                  |
| hanger, 13                 | rigid, 26                     |
| Scopes, 24                 | URO interchangeable panel, 11 |

[OCR]
Index

M

Master tool, 30
Modality extensions, 15

P

Package components, 7
Packaging instructions, 34

R

Resectoscope
camera, 29
Resectoscope, 28
Rigid cystoscope, 25
Rigid ureteroscope, 26

S

Scope
connectors, 14
hanger, 13

Scopes, 24

colonoscope, 22

duodenoscope, 23
Setup, 34

turning on system, 44
Setup instructions, 40
Simulator

hardware, 5
Specifications, 7
Syringe, 32

T

Tool tray, 17

connection outlets, 20, 44
Troubleshooting, 94
Turning on the simulator, 17

U
Unpacking instructions, 34
Ureteroscope
flexible, 27
rigid, 26

URO interchangeable panel, 11

surgicalscience

Page 110