

# Page 1

Hysteroscopic Myomectomy 
Proctor Book 
Overview 
This module includes a variety of myomas in different positions and uterine 
anatomies for comprehensive training in myoma removal using a resectoscope.  
Accompanied by educational aids, trainees develop proficiency in instrument 
handling and safe use of the loop electrode for effective resection.  
During the procedure, trainees practice visualizing anatomical landmarks, 
managing irrigation fluid, tracking uterine fluid deficiency, and handling 
complications such as controlling bleeding and preventing perforation. 
 
Unique Features: 
• 
Complete virtual patient environment with realistic anatomy 
• 
Virtual training for monopolar and bipolar resectoscopes 
• 
Different angled optics 
• 
Presents real time fluid management system display, allowing trainees to 
track uterine fluid deficit effectively 
• 
Resection Assist educational aid with colored map visualization and 
planning of cutting regions 
• 
Progress bar tracking of percentage of pathology resected 
• 
Clear view mode – simulated environment enabled clearing view to help 
diagnose bleeding sources 
• 
On-screen warning and complication messages  
• 
Proctor preset for random electric and light failure  
• 
Performance review provides feedback of safety measures and 
complication handling for post-procedure debriefing 
 


[TABLE]
| Hysteroscopic Myomectomy                                                    |
|:----------------------------------------------------------------------------|
| Proctor Book                                                                |
| Overview                                                                    |
| This module includes a variety of myomas in different positions and uterine |
| anatomies for comprehensive training in myoma removal using a resectoscope. |
| Accompanied by educational aids, trainees develop proficiency in instrument |
| handling and safe use of the loop electrode for effective resection.        |
| During the procedure, trainees practice visualizing anatomical landmarks,   |
| managing irrigation fluid, tracking uterine fluid deficiency, and handling  |
| complications such as controlling bleeding and preventing perforation.      |

[TABLE]
| U                 |                                                                          |
| nique Features:   |                                                                          |
|:------------------|:-------------------------------------------------------------------------|
| •                 | Complete virtual patient environment with realistic anatomy              |
| •                 | Virtual training for monopolar and bipolar resectoscopes                 |
| •                 | Different angled optics                                                  |
| •                 | Presents real time fluid management system display, allowing trainees to |
|                   | track uterine fluid deficit effectively                                  |
| •                 | Resection Assist educational aid with colored map visualization and      |
|                   | planning of cutting regions                                              |
| •                 | Progress bar tracking of percentage of pathology resected                |
| •                 | Clear view mode – simulated environment enabled clearing view to help    |
|                   | diagnose bleeding sources                                                |
| •                 | On-screen warning and complication messages                              |
| •                 | Proctor preset for random electric and light failure                     |
| •                 | Performance review provides feedback of safety measures and              |
|                   | complication handling for post-procedure debriefing                      |

[OCR_TABLE]
Hyste
Proctc

[OCR]
Hysteroscopic Myomectomy
Proctor Book

Overview

This module includes a variety of myomas in different positions and uterine
anatomies for comprehensive training in myoma removal using a resectoscope.

Accompanied by educational aids, trainees develop proficiency in instrument
handling and safe use of the loop electrode for effective resection.

During the procedure, trainees practice visualizing anatomical landmarks,

managing irrigation fluid, tracking uterine fluid deficiency, and handling
complications such as controlling bleeding and preventing perforation.

Unique Features:

° Complete virtual patient environment with realistic anatomy

° Virtual training for monopolar and bipolar resectoscopes

° Different angled optics

° Presents real time fluid management system display, allowing trainees to
track uterine fluid deficit effectively

° Resection Assist educational aid with colored map visualization and
planning of cutting regions

° Progress bar tracking of percentage of pathology resected

° Clear view mode — simulated environment enabled clearing view to help
diagnose bleeding sources

. On-screen warning and complication messages

° Proctor preset for random electric and light failure

° Performance review provides feedback of safety measures and

complication handling for post-procedure debriefing

surgicalscience


# Page 2

Hysteroscopic Myomectomy 
Proctor Book 
 
Page 2 
 
Acknowledgements 
This module was created in collaboration with: 
• 
Noam Smorgick MD, Shamir Medical Center, Tel Aviv University, Israel 
• 
Antoni Sierant, MD, Postgraduate Medical Education Center CMKP, 
Warsaw, Poland 
Case Description 
Case 
Description 
Case 1  
Anteverted uterus, small size myoma on the right 
posterior wall  
Case 2 
Arcuate uterus, medium size myoma on the left wall  
Case 3 
Anteverted uterus, large myoma on anterior wall. 
Heavy bleeding  
Case 4 
Retroverted uterus, medium size myoma on anterior 
wall 
 
 
 
 
 
 
 
 
 
 
 
 
 


[TABLE]
| Case Description   |      |                                                    |
|:-------------------|:-----|:---------------------------------------------------|
|                    | Case | Description                                        |
|                    |      | Anteverted uterus, small size myoma on the right   |
| Case 1             |      |                                                    |
|                    |      | posterior wall                                     |
| Case 2             |      | Arcuate uterus, medium size myoma on the left wall |
|                    |      | Anteverted uterus, large myoma on anterior wall.   |
| Case 3             |      |                                                    |
|                    |      | Heavy bleeding                                     |
|                    |      | Retroverted uterus, medium size myoma on anterior  |
| Case 4             |      |                                                    |
|                    |      | wall                                               |

[OCR]
Hysteroscopic Myomectomy
Proctor Book

Acknowledgements

This module was created in collaboration with:

. Noam Smorgick MD, Shamir Medical Center, Tel Aviv University, Israel
. Antoni Sierant, MD, Postgraduate Medical Education Center CMKP,

Warsaw, Poland

Case Description

Case Description
Case 1 Anteverted uterus, small size myoma on the right
posterior wall
Case 2 Arcuate uterus, medium size myoma on the left wall
Anteverted uterus, large myoma on anterior wall.
Case 3 a
Heavy bleeding
Retroverted uterus, medium size myoma on anterior
Case 4 wall

surgicalscience

Page 2


# Page 3

Hysteroscopic Myomectomy 
Proctor Book 
 
Page 3 
 
Module-Specific Hardware 
Device 
Physical Hardware 
Resectoscope / 
Hysteroscope 
 
 
Keyboard Shortcuts 
Shortcut Key 
Description 
CTRL+F 
Freeze the hysteroscope location to enable a live 
screen view without the need to manually hold the 
scope 
 
 
 
 
 
 
 
 
 


[TABLE]
|                          |                   |       |                                                   | Hysteroscopic Myomectomy   |
|:-------------------------|:------------------|:------|:--------------------------------------------------|:---------------------------|
|                          |                   |       |                                                   | Proctor Book               |
| Module-Specific Hardware |                   |       |                                                   |                            |
|                          | Device            |       | Physical Hardware                                 |                            |
|                          | Resectoscope /    |       |                                                   |                            |
|                          | Hysteroscope      |       |                                                   |                            |
| K                        | eyboard Shortcuts |       |                                                   |                            |
|                          | Shortcut Key      |       | Description                                       |                            |
|                          |                   |       | Freeze the hysteroscope location to enable a live |                            |
|                          | CTRL+F            |       |                                                   |                            |
|                          |                   |       | screen view without the need to manually hold the |                            |
|                          |                   | scope |                                                   |                            |
|                          |                   |       |                                                   | Page 3                     |

[OCR]
Hysteroscopic Myomectomy
Proctor Book

Module-Specific Hardware

Device Physical Hardware

Resectoscope /

Hysteroscope
Keyboard Shortcuts
Shortcut Key Description
Freeze the hysteroscope location to enable a live
CTRL+F screen view without the need to manually hold the
scope

surgicalscience Page 3


# Page 4

Hysteroscopic Myomectomy 
Proctor Book 
 
Page 4 
 
Performance Report 
Device 
Physical Hardware 
Time & Economy 
Procedure time 
Total procedure time, measured from scope 
entrance until exit from case (hh:mm:ss) 
Ergonomics 
Working angle 00 /120 / 300 
Percentage of time trainee worked with angle 
Educational Aids 
Percent time worked in Clear 
View mode 
Measures percentage of time the Clear View 
mode was turned on 
Snapshots taken during 
procedure 
Presents the snapshots taken during the 
procedure 
Resection 
Percent pathology resected 
Measures the percentage of myoma resected 
Fluid Management & Bleeding 
Percent time worked in low 
visibility 
Measures the percentage of time during 
procedure trainee worked in low visibility 
Remaining bleeders  
Indicates if any bleeders remained open 
(Yes/No)  
Total time uterus collapsed 
Measures the total time the uterus was 
deflated and collapsed during procedure (sec) 
Number of times fluid 
balance was checked 
Indicates the number of times the fluid 
balance was checked during procedure   
 
 


[TABLE]
| Performance Report           |                                               |
|:-----------------------------|:----------------------------------------------|
| Device                       | Physical Hardware                             |
| Time & Economy               |                                               |
| Procedure time               | Total procedure time, measured from scope     |
|                              | entrance until exit from case (hh:mm:ss)      |
| Ergonomics                   |                                               |
| Working angle 00 /120 / 300  | Percentage of time trainee worked with angle  |
| Educational Aids             |                                               |
| Percent time worked in Clear | Measures percentage of time the Clear View    |
| View mode                    | mode was turned on                            |
| Snapshots taken during       | Presents the snapshots taken during the       |
| procedure                    | procedure                                     |
| Resection                    |                                               |
| Percent pathology resected   | Measures the percentage of myoma resected     |
| Fluid Management & Bleeding  |                                               |
| Percent time worked in low   | Measures the percentage of time during        |
| visibility                   | procedure trainee worked in low visibility    |
| Remaining bleeders           | Indicates if any bleeders remained open       |
|                              | (Yes/No)                                      |
| Total time uterus collapsed  | Measures the total time the uterus was        |
|                              | deflated and collapsed during procedure (sec) |
| Number of times fluid        | Indicates the number of times the fluid       |
| balance was checked          | balance was checked during procedure          |

[OCR]
Hysteroscopic Myomectomy
Proctor Book

Performance Report

Device

Physical Hardware

Time & Economy

Procedure time

Total procedure time, measured from scope
entrance until exit from case (hh:mm:ss)

Ergonomics

Working angle 0°/12°/ 30°

Percentage of time trainee worked with angle

Educational Aids

Percent time worked in Clear
View mode

Measures percentage of time the Clear View
mode was turned on

Snapshots taken during
procedure

Presents the snapshots taken during the
procedure

Resection

Percent pathology resected

Measures the percentage of myoma resected

Fluid Management & Bleeding

Percent time worked in low
visibility

Measures the percentage of time during
procedure trainee worked in low visibility

Remaining bleeders

Indicates if any bleeders remained open
(Yes/No)

Total time uterus collapsed

Measures the total time the uterus was
deflated and collapsed during procedure (sec)

Number of times fluid
balance was checked

Indicates the number of times the fluid
balance was checked during procedure

surgicalscience

Page 4


# Page 5

Hysteroscopic Myomectomy 
Proctor Book 
 
Page 5 
 
Safety 
Substantial contacts with the 
uterine walls 
Presents the number of incidents the 
hysteroscope hit the uterine walls 
Substantial contacts with the 
cervical wall 
Presents the number of incidents the 
hysteroscope hit the cervical wall  
Endometrial perforation 
incident 
Indicates if an endometrial perforation 
occurred during procedure (Yes/No)  
 
 
Visualization 
Percent visualization of 
uterus 
Measures the percentage of uterus visualized 
during the procedure 
Left tubal ostium 
Indicates if the left tubal ostium was visualized 
(Yes/No)  
Right tubal ostium 
Indicates if the right tubal ostium was 
visualized (Yes/No) 
Total path of camera  
Measures the total distance that was traveled 
with the camera during the procedure (mm) 
 
 
 
 
 
 
 
 


[TABLE]
|                               | Hysteroscopic Myomectomy                          |
|:------------------------------|:--------------------------------------------------|
|                               | Proctor Book                                      |
| Safety                        |                                                   |
| Substantial contacts with the | Presents the number of incidents the              |
| uterine walls                 | hysteroscope hit the uterine walls                |
| Substantial contacts with the | Presents the number of incidents the              |
| cervical wall                 | hysteroscope hit the cervical wall                |
| Endometrial perforation       | Indicates if an endometrial perforation           |
| incident                      | occurred during procedure (Yes/No)                |
| Visualization                 |                                                   |
| Percent visualization of      | Measures the percentage of uterus visualized      |
| uterus                        | during the procedure                              |
| Left tubal ostium             | Indicates if the left tubal ostium was visualized |
|                               | (Yes/No)                                          |
| Right tubal ostium            | Indicates if the right tubal ostium was           |
|                               | visualized (Yes/No)                               |
| Total path of camera          | Measures the total distance that was traveled     |
|                               | with the camera during the procedure (mm)         |

[OCR]
Hysteroscopic Myomectomy
Proctor Book

Safety

Substantial contacts with the
uterine walls

Presents the number of incidents the
hysteroscope hit the uterine walls

Substantial contacts with the
cervical wall

Presents the number of incidents the
hysteroscope hit the cervical wall

Endometrial perforation
incident

Indicates if an endometrial perforation
occurred during procedure (Yes/No)

Visualization

Percent visualization of
uterus

Measures the percentage of uterus visualized
during the procedure

Left tubal ostium

Indicates if the left tubal ostium was visualized
(Yes/No)

Right tubal ostium

Indicates if the right tubal ostium was
visualized (Yes/No)

Total path of camera

Measures the total distance that was traveled
with the camera during the procedure (mm)

surgicalscience

Page 5


# Page 6

Hysteroscopic Myomectomy 
Proctor Book 
 
Page 6 
 
Main Features and Controls 
Feature 
Button 
Description 
Patient file 
 
Review the case objectives 
Sound  
 
Mute the sound 
3D map 
 
Dynamic external view of the 
uterus and current position of 
the hysteroscope during the 
procedure 
3D slicer 
 
Slice through the external view 
3D anatomy using a scroll bar 
Camera angle 
 
Selection of camera angle  
00, 120 or 300 
Tool selection 
 
 
Select monopolar or bipolar 
loop 
Resection Assist 
mode  
 
Color height map indicating 
areas remained to resect  
Visualization 
progress bar 
  
Percent of uterus visualized 
Clear View mode 
 
Clear the view for helping 
diagnose bleeding sources 
 
 
 
 
 
 


[TABLE]
| Main Features and Controls   |        |                                |
|:-----------------------------|:-------|:-------------------------------|
| Feature                      | Button | Description                    |
| Patient file                 |        | Review the case objectives     |
| Sound                        |        | Mute the sound                 |
| 3D map                       |        | Dynamic external view of the   |
|                              |        | uterus and current position of |
|                              |        | the hysteroscope during the    |
|                              |        | procedure                      |

[OCR]
Hysteroscopic Myomectomy
Proctor Book

Main Features and Controls

Feature Button Description

Patient file al Review the case objectives

Sound Mute the sound

3D map Dynamic external view of the
uterus and current position of
the hysteroscope during the
procedure

3D slicer Slice through the external view

3D anatomy using a scroll bar

Camera angle

|
ANGLES
0 12 30°

Selection of camera angle
0°, 12° or 30°

Tool selection

Select monopolar or bipolar
loop

Resection Assist
mode

Color height map indicating
areas remained to resect

Visualization
progress bar

Percent of uterus visualized

Clear View mode

Clear the view for helping
diagnose bleeding sources

surgicalscience

Page 6


# Page 7

Hysteroscopic Myomectomy 
Proctor Book 
 
Page 7 
 
Check Fluid 
 
 
Opens Fluid Management 
System for pressure set and 
fluid inflow and deficit tracking 
Fix light failure 
 
Available when preset failure 
enabled. Press to fix light 
failure 
Fix electric 
failure 
 
Available when preset failure 
enabled. Press to fix electric 
failure 
 


[TABLE]
|                   | Hysteroscopic Myomectomy          |
|:------------------|:----------------------------------|
|                   | Proctor Book                      |
| Check Fluid       | Opens Fluid Management            |
|                   | System for pressure set and       |
|                   | fluid inflow and deficit tracking |
| Fix light failure | Available when preset failure     |
|                   | enabled. Press to fix light       |
|                   | failure                           |
| Fix electric      | Available when preset failure     |
| failure           | enabled. Press to fix electric    |
|                   | failure                           |

[OCR]
Hysteroscopic Myomectomy
Proctor Book

Check Fluid Ea Opens Fluid Management
System for pressure set and
fluid inflow and deficit tracking

Fix light failure Available when preset failure
enabled. Press to fix light
failure
Fix electric Available when preset failure
failure enabled. Press to fix electric
failure

surgicalscience Page 7