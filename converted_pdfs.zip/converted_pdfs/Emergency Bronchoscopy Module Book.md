

# Page 1

Emergency Bronchoscopy Module
1
BRONCH Mentor
Introduction
The BRONCH Mentor Emergency Bronchoscopy Module provides a 
comprehensive clinical setting for hands-on practice of emergency and ICU 
scenarios within the controlled environment of the simulation. The Emergency 
module offers trainees and practitioners the opportunity to encounter these 
critical and stressful situations where they can perform or even err, without 
consequences.
The patient scenarios included in the module feature endobronchial bleeding, 
foreign body aspiration (pediatric and adult) and therapeutic aspiration of 
excessive pulmonary secretions (bronchoscopic pulmonary toilet).
Consulted on the development of this module:
Septimu Murgu, MD, The University of Chicago, Chicago IL, USA
Momen M. Wahidi, MD, MBA, Duke University, Durham NC, USA
David Feller-Kopman, MD, Johns Hopkins Hospital, Baltimore MD, USA
Michael S. Machuzak, MD, Cleveland Clinic, Cleveland OH, USA
Hervé Dutau, MD, Hôpital Nord, Marseille, France


[TABLE]
| Emergency Bronchoscopy Module                                                 |
|:------------------------------------------------------------------------------|
| Introduction                                                                  |
| The BRONCH Mentor Emergency Bronchoscopy Module provides a                    |
| comprehensive clinical setting for hands-on practice of emergency and ICU     |
| scenarios within the controlled environment of the simulation. The Emergency  |
| module offers trainees and practitioners the opportunity to encounter these   |
| critical and stressful situations where they can perform or even err, without |
| consequences.                                                                 |
| The patient scenarios included in the module feature endobronchial bleeding,  |
| foreign body aspiration (pediatric and adult) and therapeutic aspiration of   |
| excessive pulmonary secretions (bronchoscopic pulmonary toilet).              |

[OCR_TABLE]
Eme

[OCR]
Emergency Bronchoscopy Module

Introduction

The BRONCH Mentor Emergency Bronchoscopy Module provides a
comprehensive clinical setting for hands-on practice of emergency and ICU
scenarios within the controlled environment of the simulation. The Emergency
module offers trainees and practitioners the opportunity to encounter these
critical and stressful situations where they can perform or even err, without
consequences.

The patient scenarios included in the module feature endobronchial bleeding,
foreign body aspiration (pediatric and adult) and therapeutic aspiration of
excessive pulmonary secretions (bronchoscopic pulmonary toilet).

Consulted on the development of this module:

Septimu Murgu, MD, The University of Chicago, Chicago IL, USA
Momen M. Wahidi, MD, MBA, Duke University, Durham NC, USA

David Feller-Kopman, MD, Johns Hopkins Hospital, Baltimore MD, USA
Michael S. Machuzak, MD, Cleveland Clinic, Cleveland OH, USA

Hervé Dutau, MD, H6pital Nord, Marseille, France

surgical BRONCH Mentor


# Page 2

Emergency Bronchoscopy Module
2
BRONCH Mentor
Educational Goals
	
 Learning by practicing bronchoscopic emergencies which are stressful 
and rarely encountered in a controlled environment, allowing for gradual 
acquisition of knowledge and skills.
	
 Practicing in a true-to-life environment where operational or clinical mistakes 
can be made and learnt from. 
	
 Gaining experience in all aspects of endobronchial bleeding and foreign body 
aspiration cases prior to encountering such cases in the real world.
	
 Gaining experience in therapeutic aspiration (bronchoscopic pulmonary 
toilet) prior to performing on real patients.
 
Learning Objectives
	
 To assess the clinical scenario and apply therapeutic methods accordingly.
	
 To maintain the virtual patient’s condition, avoiding respiratory or 
hemodynamic deterioration while applying therapeutic measures.
	
 To practice the complete workflow of inspection, diagnosis and treatment of 
endobronchial bleeding situations.
	
 To practice the complete workflow of inspection, diagnosis and treatment of 
foreign body aspiration situations.
	
 To practice the complete workflow of inspection, diagnosis and performance 
of therapeutic aspiration of excessive pulmonary secretions and the  
incidental findings they may conceal. 
	
 To gain experience in foreign body removal using a selection of tools. 
	
 To gain experience in safely and efficiently solving endobronchial bleeding 
situations using a variety of methods and tools. 
	
 To gain experience in therapeutic aspiration procedures using a selection of 
scopes and methods. 


[TABLE]
| Educational Goals                                                        |
|:-------------------------------------------------------------------------|
|  Learning by practicing bronchoscopic emergencies which are stressful                                                                          |
| and rarely encountered in a controlled environment, allowing for gradual |
| acquisition of knowledge and skills.                                     |
|  Practicing in a true-to-life environment where operational or clinical mistakes                                                                          |
| can be made and learnt from.                                             |
|  Gaining experience in all aspects of endobronchial bleeding and foreign body                                                                          |
| aspiration cases prior to encountering such cases in the real world.     |
|  Gaining experience in therapeutic aspiration (bronchoscopic pulmonary                                                                          |
| toilet) prior to performing on real patients.                            |

[OCR]
Emergency Bronchoscopy Module

Educational Goals

= Learning by practicing bronchoscopic emergencies which are stressful
and rarely encountered in a controlled environment, allowing for gradual
acquisition of knowledge and skills.

= Practicing in a true-to-life environment where operational or clinical mistakes
can be made and learnt from.

= Gaining experience in all aspects of endobronchial bleeding and foreign body
aspiration cases prior to encountering such cases in the real world.

= Gaining experience in therapeutic aspiration (bronchoscopic pulmonary
toilet) prior to performing on real patients.

Learning Objectives

= To assess the clinical scenario and apply therapeutic methods accordingly.

= To maintain the virtual patient's condition, avoiding respiratory or
hemodynamic deterioration while applying therapeutic measures.

= To practice the complete workflow of inspection, diagnosis and treatment of
endobronchial bleeding situations.

= To practice the complete workflow of inspection, diagnosis and treatment of
foreign body aspiration situations.

= To practice the complete workflow of inspection, diagnosis and performance
of therapeutic aspiration of excessive pulmonary secretions and the
incidental findings they may conceal.

= To gain experience in foreign body removal using a selection of tools.

= To gain experience in safely and efficiently solving endobronchial bleeding
situations using a variety of methods and tools.

= To gain experience in therapeutic aspiration procedures using a selection of
scopes and methods.

surgical BRONCH Mentor


# Page 3

Emergency Bronchoscopy Module
3
BRONCH Mentor
General Screen Layout and Features
1 - Main View
	
 Displaying the scope’s video (WLB).
	
 Upon ‘Freeze’, a small video display appears in the upper left corner and over 
the frozen main view.
	
 Elapsed time is indicated in the upper right corner.
Note: Patient safety related alerts are displayed over the main view.
4
4
6
5
2
3
1
a
e
c
b
d
g
f
2 - Main view controls


[TABLE]
| Emergency Bronchoscopy Module                                         |
|:----------------------------------------------------------------------|
| General Screen Layout and Features                                    |
| 4                                                                     |
| 1                                                                     |
| 2                                                                     |
| 6                                                                     |
| 4                                                                     |
| 5                                                                     |
| 3                                                                     |
| 1 - Main View                                                         |
|  Displaying the scope’s video (WLB).                                                                       |
|  Upon ‘Freeze’, a small video display appears in the upper left corner and over                                                                       |
| the frozen main view.                                                 |
|  Elapsed time is indicated in the upper right corner.                                                                       |
| Note: Patient safety related alerts are displayed over the main view. |
| 2 - Main view controls                                                |
| cb                                                                    |
| a                                                                     |
| gf                                                                    |
| d                                                                     |
| e                                                                     |
| 3                                                                     |
| BRONCH Mentor                                                         |

[OCR]
Emergency Bronchoscopy Module

General Screen Layout and Features

1- Main View
= Displaying the scope’s video (WLB).

= Upon ‘Freeze’, a small video display appears in the upper left corner and over
the frozen main view.

= Elapsed time is indicated in the upper right corner.

Note: Patient safety related alerts are displayed over the main view.

2 - Main view controls

surgicalscience BRONCH Mentor


# Page 4

Emergency Bronchoscopy Module
4
BRONCH Mentor
	 a. Full Screen enlarges the main view display as a ‘procedure 
restricted’ view, removing all aids that are unavailable during an actual 
bronchoscopic procedure.
	 b. Compass dynamically displays, over the main view, an anatomical 
compass indicating body coordinates (Anterior, Posterior, Left and 
Right).
	 c. Labels display the bronchial segments labels over the main view. Two 
labeling conventions are available: descriptive-numeric and advanced-
numeric which labels the sub-segments one level deeper within the 
lungs.
	 d. Stop Breathing stops the virtual patient’s breathing, allowing for 
easier performance of diagnostic and therapeutic maneuvers.
	 e. Reposition turns the virtual patient 45 degrees to the right or to the 
left, to maintain lung patency of at least one lung. This button is available 
only for the endobronchial bleeding cases.
	 f. Switch Scope allows for selection of a wider Therapeutic scope (with 
both a wider diameter insertion tube and a wider working channel) or a 
narrower Diagnostic scope (with both a narrower diameter insertion tube 
and a narrower working channel). Note that this button is enabled only 
when the scope is completely out.
	 g. Suction Trap simulates connecting a suction trap to collect sample. 
Once a trap is connected, the amount of retrieved fluid is apparent. 
Note: The Reposition button is disabled in Virtual Patient cases where 
repositioning the virtual patient is irrelevant.
3 – Patient Management Region
The advanced modules allow for selection of patient management 
regiment prior to starting the simulated case. 
When general anesthesia is selected the virtual patient is deemed 
anesthetized and no patient management is required. 
When moderate sedation is selected, patient management is as described 
below (the same as all other clinical modules).


[TABLE]
|  a. Full Screen enlarges the main view display as a ‘procedure                                                                               |
|:------------------------------------------------------------------------------|
| restricted’ view, removing all aids that are unavailable during an actual     |
| bronchoscopic procedure.                                                      |
|  b. Compass dynamically displays, over the main view, an anatomical                                                                               |
| compass indicating body coordinates (Anterior, Posterior, Left and            |
| Right).                                                                       |
|  c. Labels display the bronchial segments labels over the main view. Two                                                                               |
| labeling conventions are available: descriptive-numeric and advanced-         |
| numeric which labels the sub-segments one level deeper within the             |
| lungs.                                                                        |
|  d. Stop Breathing stops the virtual patient’s breathing, allowing for                                                                               |
| easier performance of diagnostic and therapeutic maneuvers.                   |
|  e. Reposition turns the virtual patient 45 degrees to the right or to the                                                                               |
| left, to maintain lung patency of at least one lung. This button is available |
| only for the endobronchial bleeding cases.                                    |
|  f. Switch Scope allows for selection of a wider Therapeutic scope (with                                                                               |
| both a wider diameter insertion tube and a wider working channel) or a        |
| narrower Diagnostic scope (with both a narrower diameter insertion tube       |
| and a narrower working channel). Note that this button is enabled only        |
| when the scope is completely out.                                             |
|  g. Suction Trap simulates connecting a suction trap to collect sample.                                                                               |
| Once a trap is connected, the amount of retrieved fluid is apparent.          |

[TABLE]
| Note: The Reposition button is disabled in Virtual Patient cases where   |
|:-------------------------------------------------------------------------|
| repositioning the virtual patient is irrelevant.                         |
| 3 – Patient Management Region                                            |
| The advanced modules allow for selection of patient management           |
| regiment prior to starting the simulated case.                           |
| When general anesthesia is selected the virtual patient is deemed        |
| anesthetized and no patient management is required.                      |
| When moderate sedation is selected, patient management is as described   |
| below (the same as all other clinical modules).                          |

[OCR_TABLE]
bror

[OCR]
Emergency Bronchoscopy Module

= a. Full Screen enlarges the main view display as a ‘procedure
restricted’ view, removing all aids that are unavailable during an actual
bronchoscopic procedure.

= b. Compass dynamically displays, over the main view, an anatomical
compass indicating body coordinates (Anterior, Posterior, Left and
Right).

= c. Labels display the bronchial segments labels over the main view. Two
labeling conventions are available: descriptive-numeric and advanced-
numeric which labels the sub-segments one level deeper within the
lungs.

= d. Stop Breathing stops the virtual patient’s breathing, allowing for
easier performance of diagnostic and therapeutic maneuvers.

= e. Reposition turns the virtual patient 45 degrees to the right or to the
left, to maintain lung patency of at least one lung. This button is available
only for the endobronchial bleeding cases.

= f. Switch Scope allows for selection of a wider Therapeutic scope (with
both a wider diameter insertion tube and a wider working channel) or a
narrower Diagnostic scope (with both a narrower diameter insertion tube
and a narrower working channel). Note that this button is enabled only
when the scope is completely out.

= g. Suction Trap simulates connecting a suction trap to collect sample.
Once a trap is connected, the amount of retrieved fluid is apparent.

Note: The Reposition button is disabled in Virtual Patient cases where
repositioning the virtual patient is irrelevant.

3- Patient Management Region

The advanced modules allow for selection of patient management
regiment prior to starting the simulated case.

When general anesthesia is selected the virtual patient is deemed
anesthetized and no patient management is required.

When moderate sedation is selected, patient management is as described
below (the same as all other clinical modules).

surgical BRONCH Mentor


# Page 5

Emergency Bronchoscopy Module
5
BRONCH Mentor
The Patient Management Region incorporates patient monitoring 
and management that is complementary to the bronchoscopy and 
is not performed via the bronchoscope. The virtual patient reacts to 
the implementation of sedatives and other actions as reflected in the 
consciousness level and vital signs values.
The Patient Management options include:
a. Moderate Sedation administration allows for the selection of 
benzodiazepines, narcotics, or reversal agents from the list and for the 
setting and administering of the desired dosage. The affect on the virtual 
patient occurs according to each drug time to affect, and varies each 
time the case is run. All administered sedatives are registered and the 
current total is constantly displayed.
b. Vital Signs monitoring via the constantly updating values of heart 
rate, blood pressure, respiratory rate, SpO2 and ECG. The vital signs 
values vary according to patient and treatment, and may go as low or 
high as severe hemodynamic complications, requiring the stopping of the 
procedure.
c. Consciousness Level monitoring using the 1 to 6 Ramsey scale, allows 
for ongoing inspection of patient condition and adaptation of moderate 
sedation regime accordingly.
d. Oxygen Supplement administration allows for administering 0 to 10 L/
min oxygen supplement, affecting the SpO2 level. 
a
c
d
b
Note: As the Patient Management is part of the actual procedure, all the 
above segments are also available in Full Screen mode.
Note: The Patient Management was designed to provide a real opportunity 
for team training, providing each team member with his designated role to 
actively perform during the simulation. 


[TABLE]
|                                                                            | c   | d   |
|:---------------------------------------------------------------------------|:----|:----|
| The Patient Management Region incorporates patient monitoring              |     |     |
| and management that is complementary to the bronchoscopy and               |     |     |
| is not performed via the bronchoscope. The virtual patient reacts to       |     |     |
| the implementation of sedatives and other actions as reflected in the      |     |     |
| consciousness level and vital signs values.                                |     |     |
| The Patient Management options include:                                    |     |     |
| a. Moderate Sedation administration allows for the selection of            |     |     |
| benzodiazepines, narcotics, or reversal agents from the list and for the   |     |     |
| setting and administering of the desired dosage. The affect on the virtual |     |     |
| patient occurs according to each drug time to affect, and varies each      |     |     |
| time the case is run. All administered sedatives are registered and the    |     |     |
| current total is constantly displayed.                                     |     |     |
| b. Vital Signs monitoring via the constantly updating values of heart      |     |     |
| rate, blood pressure, respiratory rate, SpO2 and ECG. The vital signs      |     |     |
| values vary according to patient and treatment, and may go as low or       |     |     |
| high as severe hemodynamic complications, requiring the stopping of the    |     |     |
| procedure.                                                                 |     |     |
| c. Consciousness Level monitoring using the 1 to 6 Ramsey scale, allows    |     |     |
| for ongoing inspection of patient condition and adaptation of moderate     |     |     |
| sedation regime accordingly.                                               |     |     |
| d. Oxygen Supplement administration allows for administering 0 to 10 L/    |     |     |
| min oxygen supplement, affecting the SpO2 level.                           |     |     |

[OCR]
Emergency Bronchoscopy Module

Fentanyl to

100 meq
8 mg

50 meg
Oxygen OUmin >

id
The Patient Management Region incorporates patient monitoring
and management that is complementary to the bronchoscopy and
is not performed via the bronchoscope. The virtual patient reacts to
the implementation of sedatives and other actions as reflected in the
consciousness level and vital signs values.

4mg

The Patient Management options include:

a. Moderate Sedation administration allows for the selection of
benzodiazepines, narcotics, or reversal agents from the list and for the
setting and administering of the desired dosage. The affect on the virtual
patient occurs according to each drug time to affect, and varies each
time the case is run. All administered sedatives are registered and the
current total is constantly displayed.

b. Vital Signs monitoring via the constantly updating values of heart
rate, blood pressure, respiratory rate, SpO2 and ECG. The vital signs
values vary according to patient and treatment, and may go as low or
high as severe hemodynamic complications, requiring the stopping of the
procedure.

c. Consciousness Level monitoring using the 1 to 6 Ramsey scale, allows
for ongoing inspection of patient condition and adaptation of moderate
sedation regime accordingly.

d. Oxygen Supplement administration allows for administering 0 to 10 L/
min oxygen supplement, affecting the SpO2 level.

Note: As the Patient Management is part of the actual procedure, all the
above segments are also available in Full Screen mode.

Note: The Patient Management was designed to provide a real opportunity
for team training, providing each team member with his designated role to
actively perform during the simulation.

surgical BRONCH Mentor


# Page 6

Emergency Bronchoscopy Module
6
BRONCH Mentor
4 - Complementary displays 
Selection from the menu opened using the arrow button on the left. Upon 
selection, the controls for each display are available to the right. 
Optional displays:
	 3D-Map – an external dynamic 3D visualization of the scope within the 
bronchial tree. Controls such as zoom, pan, rotate and more are available to 
its right.
	 Anatomy Atlas – a static display of the chest anatomy divided into layers of 
organs and anatomical structures. Controls such as layers filtering, zoom, 
pan, rotate and more are available to its right.
	 Imaging Results / CT Browser – shows relevant images for the virtual 
patient such as X-rays, CT scan slices, or an actual CT scan. Controls such 
as plane orientation selection (Axial, Coronal and Sagittal) are available for 
the actual CT scans.
Note: Once a control type is selected, the touch screen itself is used for the 
actual manipulation of the display.
5 - Virtual instructor  
The Virtual Instructor provides real-time warnings, comments, and tips 
regarding procedure performance efficiency as well as mild patient condition 
notices.
6 -Tool panel
The master tool and the syringe are used in this module to simulate all tools. 
Following the master tool insertion into the scope’s working channel and 
menu selection of the desired endoscopic tool, the simulated tool appears 
inside the anatomy and its tool panel is displayed.
Note: The syringe, along with its tool panel, becomes active in the simulation 
upon inserting the syringe into the working channel.
Note: Tool type availability changes according to the Virtual Patient case.


[TABLE]
| 4 - Complementary displays                                                     |
|:-------------------------------------------------------------------------------|
| Selection from the menu opened using the arrow button on the left. Upon        |
| selection, the controls for each display are available to the right.           |
| Optional displays:                                                             |
|  3D-Map – an external dynamic 3D visualization of the scope within the                                                                                |
| bronchial tree. Controls such as zoom, pan, rotate and more are available to   |
| its right.                                                                     |
|  Anatomy Atlas – a static display of the chest anatomy divided into layers of                                                                                |
| organs and anatomical structures. Controls such as layers filtering, zoom,     |
| pan, rotate and more are available to its right.                               |
|  Imaging Results / CT Browser – shows relevant images for the virtual                                                                                |
| patient such as X-rays, CT scan slices, or an actual CT scan. Controls such    |
| as plane orientation selection (Axial, Coronal and Sagittal) are available for |
| the actual CT scans.                                                           |

[TABLE]
| Note: Once a control type is selected, the touch screen itself is used for the   |
|:---------------------------------------------------------------------------------|
| actual manipulation of the display.                                              |
| 5 - Virtual instructor                                                           |
| The Virtual Instructor provides real-time warnings, comments, and tips           |
| regarding procedure performance efficiency as well as mild patient condition     |
| notices.                                                                         |
| 6 -Tool panel                                                                    |
| The master tool and the syringe are used in this module to simulate all tools.   |
| Following the master tool insertion into the scope’s working channel and         |
| menu selection of the desired endoscopic tool, the simulated tool appears        |
| inside the anatomy and its tool panel is displayed.                              |

[OCR_TABLE]
Calacti

[OCR]
Emergency Bronchoscopy Module

4- Complementary displays

Selection from the menu opened using the arrow button on the left. Upon
selection, the controls for each display are available to the right.

Optional displays:

= 3D-Map - an external dynamic 3D visualization of the scope within the
bronchial tree. Controls such as zoom, pan, rotate and more are available to
its right.

= Anatomy Atlas — a static display of the chest anatomy divided into layers of
organs and anatomical structures. Controls such as layers filtering, zoom,
pan, rotate and more are available to its right.

= Imaging Results / CT Browser - shows relevant images for the virtual
patient such as X-rays, CT scan slices, or an actual CT scan. Controls such
as plane orientation selection (Axial, Coronal and Sagittal) are available for
the actual CT scans.

Note: Once a control type is selected, the touch screen itself is used for the
actual manipulation of the display.

5 - Virtual instructor

The Virtual Instructor provides real-time warnings, comments, and tips
regarding procedure performance efficiency as well as mild patient condition
notices.

6 -Tool panel

The master tool and the syringe are used in this module to simulate all tools.
Following the master tool insertion into the scope’s working channel and
menu selection of the desired endoscopic tool, the simulated tool appears
inside the anatomy and its tool panel is displayed.

Note: Tool type availability changes according to the Virtual Patient case.

Note: The syringe, along with its tool panel, becomes active in the simulation
upon inserting the syringe into the working channel.

surgical BRONCH Mentor


# Page 7

Emergency Bronchoscopy Module
7
BRONCH Mentor
The Forceps tool panel (1) displays the 
selected forceps type. 
The Basket tool panel (2) and the Balloon 
tool panel (3) display the selected Basket/
Balloon.  
 
Both Forceps, Basket and Balloon 
tool panels allow for virtual activation, 
overpowering the master tool handle to 
facilitate easier solo training.  
 
These tool panels indicate whether Virtual 
Activation is on and if so, what the current 
tool state is. 
Note: Virtual tool activation can be 
controlled via touch screen, foot switch or 
scope buttons.
1
2
3


[TABLE]
|    | The Forceps tool panel (1) displays the      |
|:---|:---------------------------------------------|
| 1  |                                              |
|    | selected forceps type.                       |
|    | The Basket tool panel (2) and the Balloon    |
|    | tool panel (3) display the selected Basket/  |
|    | Balloon.                                     |
|    | B                                            |
|    | oth Forceps, Basket and Balloon              |
|    | tool panels allow for virtual activation,    |
|    | overpowering the master tool handle to       |
|    | facilitate easier solo training.             |
|    | T                                            |
|    | hese tool panels indicate whether Virtual    |
| 2  |                                              |
|    | Activation is on and if so, what the current |
|    | tool state is.                               |

[OCR_TABLE]
Eme

[OCR]
Emergency Bronchoscopy Module &3

The Forceps tool panel (1) displays the
selected forceps type.

The Basket tool panel (2) and the Balloon
‘ool panel (3) display the selected Basket/
Balloon.

Both Forceps, Basket and Balloon

‘ool panels allow for virtual activation,
overpowering the master tool handle to
acilitate easier solo training.

These tool panels indicate whether Virtual
Activation is on and if so, what the current
ool state is.

Note: Virtual tool activation can be
controlled via touch screen, foot switch or
scope buttons.

surgical BRONCH Mentor


# Page 8

Emergency Bronchoscopy Module
8
BRONCH Mentor
The Electrocautery Probe tool panel 
(4) displays the following choices and 
indications:
a. Mode selection: Cut, Coagulation or 
Blend. Note that for this module only the 
Coagulation mode is available.  
b. Output Intensity selection: 20W, 25W, 
30W, 35W or 40W. 
c. Indication of the continuous duration of 
applying electricity and the total time.
 
The APC Probe (Argon Plasma Coagulation) 
tool panel (5) displays the following choices 
and indications:
a. Mode selection: Continuous or Pulsed. 
Note that for this module only the 
Continuous mode is available.  
b. Gas Flow selection: 0.4 L/Min or 0.8 
L/Min (complying with different APC 
manufacturers). 
c. Output Intensity selection: 20W, 25W, 
30W, 35W or 40W. 
d. Indication of the continuous duration of 
applying electricity and the total time.
a
b
c
d
5
4
a
b
c


[TABLE]
|    | The Electrocautery Probe tool panel         |
|:---|:--------------------------------------------|
| 4  |                                             |
|    | (4) displays the following choices and      |
|    | indications:                                |
| a  | a. Mode selection: Cut, Coagulation or      |
|    | Blend. Note that for this module only the   |
|    | Coagulation mode is available.              |
|    | b. Output Intensity selection: 20W, 25W,    |
|    | 30W, 35W or 40W.                            |
| b  |                                             |
|    | c. Indication of the continuous duration of |
|    | applying electricity and the total time.    |

[OCR]
Emergency Bronchoscopy Module &3

The Electrocautery Probe tool panel
(4) displays the following choices and
indications:

Electrocautery Probe °

a. Mode selection: Cut, Coagulation or
Blend. Note that for this module only the
Coagulation mode is available.

b. Output Intensity selection: 20W, 25W,
30W, 35W or 40W.

c. Indication of the continuous duration of
applying electricity and the total time.

The APC Probe (Argon Plasma Coagulation)
tool panel (5) displays the following choices
and indications:

a. Mode selection: Continuous or Pulsed.
Note that for this module only the
Continuous mode is available.

b. Gas Flow selection: 0.4 L/Min or 0.8
L/Min (complying with different APC
manufacturers).

c. Output Intensity selection: 20W, 25W,
30W, 35W or 40W.

d. Indication of the continuous duration of
applying electricity and the total time.

surgical BRONCH Mentor


# Page 9

Emergency Bronchoscopy Module
9
BRONCH Mentor
The Syringe tool panel (6) displays the 
following choices:
a. Selection of agent to be used (agents 
availability may change per different 
cases/patient management regiments). 
b. Properties of the currently selected 
agent.  
c. Selection of syringe size.
 
d. The syringe’s dynamic animation, 
indicating its current state. 
e. The accumulating amount of injected 
and retrieved agents is displayed 
whenever the syringe is active.
Note: The syringe needs to be open when inserted into the working channel.
Note: The same physical syringe 
simulates different size syringes, 
according to the size selection. The size 
selection may change per the selected 
agent.
a
b
c
d
e
6
7 - General Buttons
	 Mute button toggles the system sound on and off.
	 Case File button opens the current virtual patient’s case file.
	 Help button opens the online help (availability is per software version).
	 Finish button ends the current simulation, allowing for saving its 
performance metrics. 


[TABLE]
| 6   | The Syringe tool panel (6) displays the   |
|:----|:------------------------------------------|
|     | following choices:                        |
|     | a. Selection of agent to be used (agents  |
|     | availability may change per different     |
| a   |                                           |
|     | cases/patient management regiments).      |
| b   | b. Properties of the currently selected   |
|     | agent.                                    |
| c   |                                           |
|     | c. Selection of syringe size.             |

[TABLE]
| b   | b. Properties of the currently selected   |
|:----|:------------------------------------------|
|     | agent.                                    |
| c   |                                           |
|     | c. Selection of syringe size.             |
|     | Note: The same physical syringe           |
| d   | simulates different size syringes,        |
|     | according to the size selection. The size |
|     | selection may change per the selected     |
| e   | agent.                                    |

[TABLE]
| and retrieved agents is displayed                                          |
|:---------------------------------------------------------------------------|
| whenever the syringe is active.                                            |
| Note: The syringe needs to be open when inserted into the working channel. |
| 7 - General Buttons                                                        |
|  Mute button toggles the system sound on and off.                                                                            |
|  Case File button opens the current virtual patient’s case file.                                                                            |
|  Help button opens the online help (availability is per software version).                                                                            |
|  Finish button ends the current simulation, allowing for saving its                                                                            |
| performance metrics.                                                       |

[OCR]
Emergency Bronchoscopy Module

The Syringe tool panel (6) displays the
following choices:

a. Selection of agent to be used (agents
availability may change per different
cases/patient management regiments).
b. Properties of the currently selected
agent.

c. Selection of syringe size.

Note: The same physical syringe
simulates different size syringes,
according to the size selection. The size
selection may change per the selected
agent.

d. The syringe’s dynamic animation,
indicating its current state.

e. The accumulating amount of injected
and retrieved agents is displayed
whenever the syringe is active.

Note: The syringe needs to be open when inserted into the working channel.

7 - General Buttons

Mute button toggles the system sound on and off.

Case File button opens the current virtual patient's case file.

Help button opens the online help (availability is per software version).

Finish button ends the current simulation, allowing for saving its
performance metrics.

surgical BRONCH Mentor


# Page 10

Emergency Bronchoscopy Module
10
BRONCH Mentor
Patient History and Condition
A 53 YO woman with a history of recurrent lower respiratory tract infections 
had a bronchoscopy that showed erythematous right lower lobe bronchial 
mucosa. The patient stopped taking Clopidogrel (Plavix) two days prior to 
the diagnostic bronchoscopy. Three biopsies were performed resulting in 
persistent mucosal hemorrhage.
Vital Signs Measured
	
 BP: 136/75
	
 HR: 92
	
 RR: 16
Available Test Results 
	
 PT- 14.2 sec. (11 - 13.5)
	
 PTT - 37 sec. (25 – 35 sec.)
	
 Platelet count - 150,000 per mcL (150,000 - 400,000)
	
 CBC :
•	RBC – 5.2 million/mcL (4.7 - 6.1)
•	WBC - 9,800 cells/mcL (4,500 - 10,000)
•	Hematocrit -  38.4 %  (36.1 - 44.3)
•	Hemoglobin  - 13.5 gm/dL (12.1 - 15.1)
Case Summary
A virtual patient with mucosal hemorrhage after performing biopsies during a 
diagnostic bronchoscopy; Use methods of choice to contain  
the bleeding while maintaining patient stability.
Case 1
1


[TABLE]
|                                                                              |
|:-----------------------------------------------------------------------------|
| Case 1                                                                       |
| 1                                                                            |
| Patient History and Condition                                                |
| A 53 YO woman with a history of recurrent lower respiratory tract infections |
| had a bronchoscopy that showed erythematous right lower lobe bronchial       |
| mucosa. The patient stopped taking Clopidogrel (Plavix) two days prior to    |
| the diagnostic bronchoscopy. Three biopsies were performed resulting in      |
| persistent mucosal hemorrhage.                                               |
| Vital Signs Measured                                                         |
|  BP: 136/75                                                                              |
|  HR: 92                                                                              |
|  RR: 16                                                                              |
| Available Test Results                                                       |
|  PT- 14.2 sec. (11 - 13.5)                                                                              |
|  PTT - 37 sec. (25 – 35 sec.)                                                                              |
|  Platelet count - 150,000 per mcL (150,000 - 400,000)                                                                              |
|  CBC :                                                                              |

[OCR]
Emergency Bronchoscopy Module

Case 1

Patient History and Condition

A 53 YO woman with a history of recurrent lower respiratory tract infections
had a bronchoscopy that showed erythematous right lower lobe bronchial
mucosa. The patient stopped taking Clopidogrel (Plavix) two days prior to
the diagnostic bronchoscopy. Three biopsies were performed resulting in
persistent mucosal hemorrhage.

Vital Signs Measured

= BP: 136/75

= HR: 92

= RR: 16

Available Test Results

= PT- 14.2 sec. (11 - 13.5)

PTT - 37 sec. (25 - 35 sec.)

Platelet count - 150,000 per mcL (150,000 - 400,000)
= CBC:

« RBC - 5.2 million/mcL (4.7 - 6.1)

« WBC - 9,800 cells/mcL (4,500 - 10,000)
« Hematocrit - 38.4 % (36.1 - 44.3)

« Hemoglobin - 13.5 gm/dL (12.1 - 15.1)

Case Summary

A virtual patient with mucosal hemorrhage after performing biopsies during a
diagnostic bronchoscopy; Use methods of choice to contain
the bleeding while maintaining patient stability.

surgical BRONCH Mentor


# Page 11

Emergency Bronchoscopy Module
11
BRONCH Mentor
Patient History and Condition
A 7 YO girl, weighing 31 kg (68.3 lb), was helping her mother prepare 
dinner yesterday (pot roast, mashed potatoes and peas) when she started 
coughing. Upon examination, patient presents with intractable cough, 
bilateral wheezing sounds, and a fever of 37.8°C (100°F). A chest X-Ray 
showed no findings.
Vital Signs Measured
	
 BP: 130/85
	
 HR: 112
	
 RR: 22
Case Summary
A pediatric case of foreign bodies aspiration. Perform a complete 
evaluation and extract the foreign bodies while maintaining patient 
stability.
2
Case 2


[TABLE]
|                                                                         |
|:------------------------------------------------------------------------|
| Case 2                                                                  |
| 2                                                                       |
| Patient History and Condition                                           |
| A 7 YO girl, weighing 31 kg (68.3 lb), was helping her mother prepare   |
| dinner yesterday (pot roast, mashed potatoes and peas) when she started |
| coughing. Upon examination, patient presents with intractable cough,    |
| bilateral wheezing sounds, and a fever of 37.8°C (100°F). A chest X-Ray |
| showed no findings.                                                     |
| Vital Signs Measured                                                    |
|  BP: 130/85                                                                         |
|  HR: 112                                                                         |
|  RR: 22                                                                         |
| Case Summary                                                            |
| A pediatric case of foreign bodies aspiration. Perform a complete       |
| evaluation and extract the foreign bodies while maintaining patient     |
| stability.                                                              |

[OCR]
Emergency Bronchoscopy Module

Case 2

Patient History and Condition

A7 YO girl, weighing 31 kg (68.3 Ib), was helping her mother prepare
dinner yesterday (pot roast, mashed potatoes and peas) when she started
coughing. Upon examination, patient presents with intractable cough,
bilateral wheezing sounds, and a fever of 37.8°C (100°F). A chest X-Ray
showed no findings.

Vital Signs Measured
= BP: 130/85

= HR: 112

= RR: 22

Case Summary

A pediatric case of foreign bodies aspiration. Perform a complete
evaluation and extract the foreign bodies while maintaining patient
stability.

pra?

surgicalscience BRONCH Mentor


# Page 12

Emergency Bronchoscopy Module
12
BRONCH Mentor
Patient History and Condition
A 68 YO male weighing 94 kg. Patient is a smoker for over 40 years, 
with chronic cough for as long as he remembers. Patient is complaining 
of coughing small amounts of blood in the last week and a half.
Vital Signs Measured
	
 BP: 132/80
	
 HR: 112
	
 RR: 18
Case Summary
A virtual patient with bleeding tumors in major airways. Assess 
and operate to contain the bleeding using methods of choice while 
maintaining airway patency and patient stability.   
Case 3
3


[TABLE]
|                                                                        |
|:-----------------------------------------------------------------------|
| Case 3                                                                 |
| 3                                                                      |
| Patient History and Condition                                          |
| A 68 YO male weighing 94 kg. Patient is a smoker for over 40 years,    |
| with chronic cough for as long as he remembers. Patient is complaining |
| of coughing small amounts of blood in the last week and a half.        |
| Vital Signs Measured                                                   |
|  BP: 132/80                                                                        |
|  HR: 112                                                                        |
|  RR: 18                                                                        |
| Case Summary                                                           |
| A virtual patient with bleeding tumors in major airways. Assess        |
| and operate to contain the bleeding using methods of choice while      |
| maintaining airway patency and patient stability.                      |

[OCR]
Emergency Bronchoscopy Module

Case 3

Patient History and Condition

A 68 YO male weighing 94 kg. Patient is a smoker for over 40 years,
with chronic cough for as long as he remembers. Patient is complaining
of coughing small amounts of blood in the last week and a half.

Vital Signs Measured
= BP: 132/80

= HR: 112

= RR: 18

Case Summary

A virtual patient with bleeding tumors in major airways. Assess
and operate to contain the bleeding using methods of choice while
maintaining airway patency and patient stability.

surgical BRONCH Mentor


# Page 13

Emergency Bronchoscopy Module
13
BRONCH Mentor
Patient History and Condition
A 78 YO male weighing 112 kg was trying to replace a refill in his Mont 
Blanc ballpoint pen when he inadvertently aspirated one of its parts held 
between his teeth. Patient is very anxious and presents with intractable 
cough. A chest X-Ray showed a radio-opaque object in the right lower 
lobe.
Vital Signs Measured
	
 BP: 138/85
	
 HR: 100
	
 RR: 20
Case Summary
A virtual patient with aspirated metal spring that is visible on CXR. 
Locate and extract the aspirated foreign body while maintaining patient 
stability.
4
Case 4


[TABLE]
|                                                                           |
|:--------------------------------------------------------------------------|
| Case 4                                                                    |
| 4                                                                         |
| Patient History and Condition                                             |
| A 78 YO male weighing 112 kg was trying to replace a refill in his Mont   |
| Blanc ballpoint pen when he inadvertently aspirated one of its parts held |
| between his teeth. Patient is very anxious and presents with intractable  |
| cough. A chest X-Ray showed a radio-opaque object in the right lower      |
| lobe.                                                                     |
| Vital Signs Measured                                                      |
|  BP: 138/85                                                                           |
|  HR: 100                                                                           |
|  RR: 20                                                                           |
| Case Summary                                                              |
| A virtual patient with aspirated metal spring that is visible on CXR.     |
| Locate and extract the aspirated foreign body while maintaining patient   |
| stability.                                                                |

[OCR]
Emergency Bronchoscopy Module

Case 4

Patient History and Condition

A 78 YO male weighing 112 kg was trying to replace a refill in his Mont
Blanc ballpoint pen when he inadvertently aspirated one of its parts held
between his teeth. Patient is very anxious and presents with intractable
cough. A chest X-Ray showed a radio-opaque object in the right lower
lobe.

Vital Signs Measured

= BP: 138/85

= HR: 100
= RR: 20

Case Summary

A virtual patient with aspirated metal spring that is visible on CXR.
Locate and extract the aspirated foreign body while maintaining patient
stability.

surgical BRONCH Mentor


# Page 14

Emergency Bronchoscopy Module
14
BRONCH Mentor
Patient History and Condition
AA 53 YO female was admitted 3 days ago after a car accident, and 
was diagnosed with a concussion, broken arm and 3 fractured ribs. 
Patient has asthma and since this morning, complains about difficulty in 
breathing. A CXR showed right and left lower lobes atelectasis.
Vital Signs Measured
	
 BP: 100/70
	
 HR: 98
	
 RR: 22
Case Summary
A virtual patient with mucus filled right middle and lower lobes and left 
lower lobe. Perform therapeutic aspiration to restore airway patency 
while maintaining patient stability. Suction trap samples can be taken.
Case 5
5


[TABLE]
|                                                                           |
|:--------------------------------------------------------------------------|
| Case 5                                                                    |
| 5                                                                         |
| Patient History and Condition                                             |
| AA 53 YO female was admitted 3 days ago after a car accident, and         |
| was diagnosed with a concussion, broken arm and 3 fractured ribs.         |
| Patient has asthma and since this morning, complains about difficulty in  |
| breathing. A CXR showed right and left lower lobes atelectasis.           |
| Vital Signs Measured                                                      |
|  BP: 100/70                                                                           |
|  HR: 98                                                                           |
|  RR: 22                                                                           |
| Case Summary                                                              |
| A virtual patient with mucus filled right middle and lower lobes and left |
| lower lobe. Perform therapeutic aspiration to restore airway patency      |
| while maintaining patient stability. Suction trap samples can be taken.   |

[OCR]
Emergency Bronchoscopy Module &3

Case 5

Patient History and Condition

AA 53 YO female was admitted 3 days ago after a car accident, and
was diagnosed with a concussion, broken arm and 3 fractured ribs.
Patient has asthma and since this morning, complains about difficulty in
breathing. A CXR showed right and left lower lobes atelectasis.

Vital Signs Measured

= BP: 100/70

= HR: 98

= RR: 22

Case Summary

A virtual patient with mucus filled right middle and lower lobes and left
lower lobe. Perform therapeutic aspiration to restore airway patency
while maintaining patient stability. Suction trap samples can be taken.

surgical BRONCH Mentor


# Page 15

Emergency Bronchoscopy Module
15
BRONCH Mentor
Patient History and Condition
A 64 YO man with long term history of smoking (1 pack per day for 40 
years) and COPD presents with respiratory distress and mild hypoxemia. 
A CXR showed right lower lobe and right middle lobe atelectasis. 
Vital Signs Measured
	
 BP: 135/92 
	
 HR: 94
	
 RR: 16
	
 SpO2:  90%
Case Summary
A virtual patient with mucus filled right lower and middle lobes. Perform 
therapeutic aspiration to restore airway patency while maintaining 
patient stability. Following the mucus evacuation a tumor becomes 
visible. Forceps biopsy and suction trap samples can be taken.
6
Case 6


[TABLE]
|                                                                           |
|:--------------------------------------------------------------------------|
| Case 6                                                                    |
| 6                                                                         |
| Patient History and Condition                                             |
| A 64 YO man with long term history of smoking (1 pack per day for 40      |
| years) and COPD presents with respiratory distress and mild hypoxemia.    |
| A CXR showed right lower lobe and right middle lobe atelectasis.          |
| Vital Signs Measured                                                      |
|  BP: 135/92                                                                           |
|  HR: 94                                                                           |
|  RR: 16                                                                           |
|  SpO2:  90%                                                                           |
| Case Summary                                                              |
| A virtual patient with mucus filled right lower and middle lobes. Perform |
| therapeutic aspiration to restore airway patency while maintaining        |
| patient stability. Following the mucus evacuation a tumor becomes         |
| visible. Forceps biopsy and suction trap samples can be taken.            |

[OCR]
Emergency Bronchoscopy Module &3

Case 6

Patient History and Condition

A 64 YO man with long term history of smoking (1 pack per day for 40
years) and COPD presents with respiratory distress and mild hypoxemia.
A CXR showed right lower lobe and right middle lobe atelectasis.

Vital Signs Measured
= BP: 135/92

= HR: 94

= RR: 16

= SpO2: 90%
Case Summary

A virtual patient with mucus filled right lower and middle lobes. Perform
therapeutic aspiration to restore airway patency while maintaining
patient stability. Following the mucus evacuation a tumor becomes
visible. Forceps biopsy and suction trap samples can be taken.

at

surgical BRONCH Mentor