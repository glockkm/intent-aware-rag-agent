

# Page 1

Essential EBUS Module
1
BRONCH Mentor
Introduction
The Essential EBUS Module is designed to provide a solution for EBUS training. 
It offers a hands-on environment, incorporating both designated tasks and 
complete clinical cases.
The Essential EBUS designated tasks are aimed at:
	 Learning to interpret the ultrasound image and identify relevant 
landmarks, demonstrating the interrelations between lymph node stations 
and vascular structures under the IASLC classification map (2009). 
	 Learning and practicing the correct workflow of the complete EBUS-TBNA 
procedure, following step-by-step instructions; receive immediate feedback 
as to the safety and efficacy of each sampling attempt.  
The Essential EBUS clinical cases offer a comprehensive training environment, 
where the most extensive clinical environment is provided within a supporting 
educational setting:
	 Realistic EBUS-TBNA experience  –  featuring side-viewing scope, realistic 
ultrasound display with transducer-tissue contact dependency, pulsating 
blood vessels, lymph node echogenecity diversity, doppler, adjustable gain/
contrast and depth, complete EBUS needle functionality, and biopsy result 
per sampled lymph node.
	 Comprehensive patient environment – featuring realistic anatomy and 
physiology, choice of moderate sedation / general anesthesia, advanced 
patient management and a corresponding CT scan for each case.  
	 Didactic options enhancing trainee understanding of the environment 
and the procedure such as organ labeling, real-time guidance, external 
visualization, tutorial movies, captured performance objectives, and more.
Consulted on the development of this module:
J.T. Annema, MD PhD, Leiden University Medical Center, The Netherlands
Eric S Edell, MD, Mayo Clinic, Rochester, MN, USA
David Feller-Kopman, MD, Johns Hopkins Hospital, Baltimore, MD, USA
Felix JF Herth, MD PhD, Thoraxklinik, Heidelberg, Germany


[TABLE]
| Introduction                                                                   |
|:-------------------------------------------------------------------------------|
| The Essential EBUS Module is designed to provide a solution for EBUS training. |
| It offers a hands-on environment, incorporating both designated tasks and      |
| complete clinical cases.                                                       |
| The Essential EBUS designated tasks are aimed at:                              |
|  Learning to interpret the ultrasound image and identify relevant                                                                                |
| landmarks, demonstrating the interrelations between lymph node stations        |
| and vascular structures under the IASLC classification map (2009).             |
|  Learning and practicing the correct workflow of the complete EBUS-TBNA                                                                                |
| procedure, following step-by-step instructions; receive immediate feedback     |

[OCR]
Essential EBUS Module

Introduction

The Essential EBUS Module is designed to provide a solution for EBUS training.
It offers a hands-on environment, incorporating both designated tasks and
complete clinical cases.

The Essential EBUS designated tasks are aimed at:

= Learning to interpret the ultrasound image and identify relevant
landmarks, demonstrating the interrelations between lymph node stations
and vascular structures under the IASLC classification map (2009).

= Learning and practicing the correct workflow of the complete EBUS-TBNA
procedure, following step-by-step instructions; receive immediate feedback
as to the safety and efficacy of each sampling attempt.

The Essential EBUS clinical cases offer a comprehensive training environment,
where the most extensive clinical environment is provided within a supporting
educational setting:

= Realistic EBUS-TBNA experience - featuring side-viewing scope, realistic
ultrasound display with transducer-tissue contact dependency, pulsating
blood vessels, lymph node echogenecity diversity, doppler, adjustable gain/
contrast and depth, complete EBUS needle functionality, and biopsy result
per sampled lymph node.

= Comprehensive patient environment — featuring realistic anatomy and
physiology, choice of moderate sedation / general anesthesia, advanced
patient management and a corresponding CT scan for each case.

= Didactic options enhancing trainee understanding of the environment
and the procedure such as organ labeling, real-time guidance, external
visualization, tutorial movies, captured performance objectives, and more.

Consulted on the development of this module:

J.T. Annema, MD PhD, Leiden University Medical Center, The Netherlands
Eric S Edell, MD, Mayo Clinic, Rochester, MN, USA

David Feller-Kopman, MD, Johns Hopkins Hospital, Baltimore, MD, USA
Felix JF Herth, MD PhD, Thoraxklinik, Heidelberg, Germany

surgical BRONCH Mentor


# Page 2

Essential EBUS Module
2
BRONCH Mentor
Educational Goals
	
 Learning and practicing the complete workflow of EBUS-TBNA 
performance, from scope introduction, through patient management, 
to obtaining a tissue sample from the desired location and reaching a 
diagnosis.
	
 Developing methodical habits to safely and efficiently demonstrate lymph 
node stations using EBUS, and obtain tissue samples, while maintaining 
patient safety and avoiding the risk of damaging expensive equipment.
	
 Following a structured hands-on curriculum to enhance the advancement 
along the steep learning curve of EBUS-TBNA performance.
	
 Practicing in a true to life environment, where operational or clinical 
mistakes can be made and learnt from.
	
 Training in all aspects of the EBUS procedure to acquire confidence and 
reach level of competence prior to performing on real patients. 
 
Learning Objectives
	
 To gain experience in introducing and navigating the side viewing 
bronchoscope.
	
 To master EBUS scope positioning, securing needle access into the desired 
lymph node.
	
 To become familiar with the endobronchial ultrasound image and its 
characteristics.
	
 To become familiar with the bronchial-vascular-nodal interrelations, 
defining lymph node classification according to the IASLC map of 2009.
	
 To gain experience in ultrasound demonstration of relevant vascular 
landmarks.
	
 To master ultrasound recognition of lymph node stations 2R, 2L, 4R, 4L, 7, 
10R, 10L, 11Rs, 11Ri and 11L.
	
 To practice safe and efficient EBUS needle manipulation, avoiding risk to 
patient or equipment.
	
 To practice, step by step, the complete workflow of EBUS-TBNA.
	
 To sample a wide range of lymph node stations, in a variety of virtual 
patients.


[TABLE]
| Educational Goals                                                      |
|:-----------------------------------------------------------------------|
|  Learning and practicing the complete workflow of EBUS-TBNA                                                                        |
| performance, from scope introduction, through patient management,      |
| to obtaining a tissue sample from the desired location and reaching a  |
| diagnosis.                                                             |
|  Developing methodical habits to safely and efficiently demonstrate lymph                                                                        |
| node stations using EBUS, and obtain tissue samples, while maintaining |
| patient safety and avoiding the risk of damaging expensive equipment.  |
|  Following a structured hands-on curriculum to enhance the advancement                                                                        |
| along the steep learning curve of EBUS-TBNA performance.               |
|  Practicing in a true to life environment, where operational or clinical                                                                        |
| mistakes can be made and learnt from.                                  |
|  Training in all aspects of the EBUS procedure to acquire confidence and                                                                        |
| reach level of competence prior to performing on real patients.        |

[OCR]
Essential EBUS Module

Educational Goals

= Learning and practicing the complete workflow of EBUS-TBNA
performance, from scope introduction, through patient management,
to obtaining a tissue sample from the desired location and reaching a
diagnosis.

= Developing methodical habits to safely and efficiently demonstrate lymph
node stations using EBUS, and obtain tissue samples, while maintaining
patient safety and avoiding the risk of damaging expensive equipment.

= Following a structured hands-on curriculum to enhance the advancement
along the steep learning curve of EBUS-TBNA performance.

= Practicing in a true to life environment, where operational or clinical
mistakes can be made and learnt from.

= Training in all aspects of the EBUS procedure to acquire confidence and
reach level of competence prior to performing on real patients.

Learning Objectives
= To gain experience in introducing and navigating the side viewing
bronchoscope.

= To master EBUS scope positioning, securing needle access into the desired
lymph node.

= To become familiar with the endobronchial ultrasound image and its
characteristics.

= To become familiar with the bronchial-vascular-nodal interrelations,
defining lymph node classification according to the IASLC map of 2009.

= To gain experience in ultrasound demonstration of relevant vascular
landmarks.

= To master ultrasound recognition of lymph node stations 2R, 2L, 4R, AL, 7,
10R, 10L, 11Rs, 11Ri and 11L.

= To practice safe and efficient EBUS needle manipulation, avoiding risk to
patient or equipment.

= To practice, step by step, the complete workflow of EBUS-TBNA.

= To sample a wide range of lymph node stations, in a variety of virtual
patients.

surgical BRONCH Mentor


# Page 3

Essential EBUS Module
3
BRONCH Mentor
Screen Layout and Features
1 - Main View
	
 The scope’s video is displayed upon starting; the ultrasound display 
appears when ‘View US’ is selected. 
	
 A small video display appears by default when the US is on. It can be 
hidden by pressing the button in the upper left corner.
	
 The green dot next to the ultrasound slice signifies the needle entry 
point. 
	
 Elapsed time and ultrasound depth are indicated.
Note: In Full Screen mode, you cannot switch off the overlay video display.
1
5
6
7
3
2
a
e
c
g
b
f
d
h
i
4
4


[TABLE]
| 7                                                                           |
|:----------------------------------------------------------------------------|
| 1 - Main View                                                               |
|  The scope’s video is displayed upon starting; the ultrasound display                                                                             |
| appears when ‘View US’ is selected.                                         |
|  A small video display appears by default when the US is on. It can be                                                                             |
| hidden by pressing the button in the upper left corner.                     |
|  The green dot next to the ultrasound slice signifies the needle entry                                                                             |
| point.                                                                      |
|  Elapsed time and ultrasound depth are indicated.                                                                             |
| Note: In Full Screen mode, you cannot switch off the overlay video display. |

[OCR]
Essential EBUS Module

Screen Layout and Features

FAFSA Pikiriel P|

1- Main View

= The scope’s video is displayed upon starting; the ultrasound display
appears when ‘View US’ is selected.

= A small video display appears by default when the US is on. It can be
hidden by pressing the button in the upper left corner.

= The green dot next to the ultrasound slice signifies the needle entry
point.

= Elapsed time and ultrasound depth are indicated.

Note: In Full Screen mode, you cannot switch off the overlay video display.

surgicalscience BRONCH Mentor


# Page 4

Essential EBUS Module
4
BRONCH Mentor
2 - Main View Controls
a,b - Full Screen, Stop Breathing are as in Diagnostic Module.
c - View US switches the ultrasound view on. Enabled after entering trachea.
d - Rotate US rotates the ultrasound view 90° clockwise each time the button 
is pressed.
e - Balloon inflates a simulated balloon around the scope’s tip enhancing the 
wall contact of the transducer.
f - Labels switches labeling on: when pressed, touch the screen to label each 
structure displayed on the ultrasound view. The label disappears once the 
labeled structure is not displayed anymore in the labeled location.
g - Doppler applies power doppler: press inside the doppler region and drag to 
move it on the ultrasound screen.
h - Gain/Contrast adjusts ultrasound display: when pressed, touch the screen 
and drag to adjust the gain (horizontal drag) and the contrast (vertical drag).
i - Depth  changes ultrasound depth: press and select the desired depth. Press 
the button again to close the depth selection control.
 
3 - Complementary Displays
Selection from the menu opened using the arrow button on the left.  
Upon selection, the controls for each display are available to the right.  
	 Scope’s Video (available only for the upper display)
	 3D-Map (buttons and activation are the same as for Anatomy Atlas in 
Diagnostic Bronchoscopy).
	 CT Browser
•	Affiliated buttons: CT plane orientation selection (Axial/Coronal/
Sagittal) 
•	Activation: touch the screen and drag vertically to browse CT slices. 
	 Lymph Node Classification Drawing (according to IASLC 2009)
	 Tutorial Movies
•	Affiliated buttons: Next/Previous chapter, Play, Pause, Stop 
Note: The ‘Doppler’ and the ‘Gain/Contrast’ buttons are mutually exclusive  
when pressed.


[TABLE]
| 2 - Main View Controls                                                          |
|:--------------------------------------------------------------------------------|
| a,b - Full Screen, Stop Breathing are as in Diagnostic Module.                  |
| c - View US switches the ultrasound view on. Enabled after entering trachea.    |
| d - Rotate US rotates the ultrasound view 90° clockwise each time the button    |
| is pressed.                                                                     |
| e - Balloon inflates a simulated balloon around the scope’s tip enhancing the   |
| wall contact of the transducer.                                                 |
| f - Labels switches labeling on: when pressed, touch the screen to label each   |
| structure displayed on the ultrasound view. The label disappears once the       |
| labeled structure is not displayed anymore in the labeled location.             |
| g - Doppler applies power doppler: press inside the doppler region and drag to  |
| move it on the ultrasound screen.                                               |
| h - Gain/Contrast adjusts ultrasound display: when pressed, touch the screen    |
| and drag to adjust the gain (horizontal drag) and the contrast (vertical drag). |
| i - Depth  changes ultrasound depth: press and select the desired depth. Press  |
| the button again to close the depth selection control.                          |
| Note: The ‘Doppler’ and the ‘Gain/Contrast’ buttons are mutually exclusive      |
| 3                                                                               |
| when pressed.                                                                   |

[OCR]
Essential EBUS Module

2 - Main View Controls
a,b - Full Screen, Stop Breathing are as in Diagnostic Module.
c - View US switches the ultrasound view on. Enabled after entering trachea.

d - Rotate US rotates the ultrasound view 90° clockwise each time the button
is pressed.

e - Balloon inflates a simulated balloon around the scope’s tip enhancing the
wall contact of the transducer.

f - Labels switches labeling on: when pressed, touch the screen to label each
structure displayed on the ultrasound view. The label disappears once the
labeled structure is not displayed anymore in the labeled location.

g - Doppler applies power doppler: press inside the doppler region and drag to
move it on the ultrasound screen.

h - Gain/Contrast adjusts ultrasound display: when pressed, touch the screen
and drag to adjust the gain (horizontal drag) and the contrast (vertical drag).

i- Depth changes ultrasound depth: press and select the desired depth. Press
the button again to close the depth selection control.

Note: The ‘Doppler’ and the ‘Gain/Contrast’ buttons are mutually exclusive
when pressed.

3 - Complementary Displays
Selection from the menu opened using the arrow button on the left.
Upon selection, the controls for each display are available to the right.

= Scope’s Video (available only for the upper display)

3D-Map (buttons and activation are the same as for Anatomy Atlas in
Diagnostic Bronchoscopy).

CT Browser

« Affiliated buttons: CT plane orientation selection (Axial/Coronal/
Sagittal)

¢ Activation: touch the screen and drag vertically to browse CT slices.

Lymph Node Classification Drawing (according to IASLC 2009)

Tutorial Movies

¢ Affiliated buttons: Next/Previous chapter, Play, Pause, Stop

surgical BRONCH Mentor


# Page 5

Essential EBUS Module
5
BRONCH Mentor
4 - EBUS Needle Tool Panel
a - Lock indicates the state of the EBUS needle 
hardware: whether at the click-locked position or not.
b - Stylet removal is performed virtually: 
press the ‘Stylet Out’ on the screen or use the C 
scope button or left foot switch to remove the stylet. 
Use the same controls for ‘Stylet In’.
Note: Whenever the EBUS needle is inserted into the 
working channel, the stylet is considered in.
c - Attach Syringe is optional. After pressing ‘Attach 
Syringe’ on the screen, the actual syringe is used 
to apply ‘Vacuum On’ by opening the syringe and 
‘Vacuum Off’ by closing the syringe.
Note: This module comes with designated EBUS needle hardware.
a
c
b
5 - Patient Management 
When moderate sedation is selected, patient management is the same as in 
Diagnostic Bronchoscopy. When general anesthesia is selected, the virtual 
patient is considered anesthetized, and no patient management is required.
6 - Virtual Instructor
Same as in Diagnostic Bronchoscopy.
7 - General Buttons 
Same as in Diagnostic Bronchoscopy.


[TABLE]
| 4 - EBUS Needle Tool Panel                                                 |
|:---------------------------------------------------------------------------|
| a - Lock indicates the state of the EBUS needle                            |
| hardware: whether at the click-locked position or not.                     |
| a                                                                          |
| b - Stylet removal is performed virtually:                                 |
| press the ‘Stylet Out’ on the screen or use the C                          |
| b                                                                          |
| scope button or left foot switch to remove the stylet.                     |
| Use the same controls for ‘Stylet In’.                                     |
| Note: Whenever the EBUS needle is inserted into the                        |
| working channel, the stylet is considered in.                              |
| c                                                                          |
| c - Attach Syringe is optional. After pressing ‘Attach                     |
| Syringe’ on the screen, the actual syringe is used                         |
| to apply ‘Vacuum On’ by opening the syringe and                            |
| ‘Vacuum Off’ by closing the syringe.                                       |
| 5 - Patient Management                                                     |
| When moderate sedation is selected, patient management is the same as in   |
| Diagnostic Bronchoscopy. When general anesthesia is selected, the virtual  |
| patient is considered anesthetized, and no patient management is required. |
| 6 - Virtual Instructor                                                     |
| Same as in Diagnostic Bronchoscopy.                                        |
| 7 - General Buttons                                                        |
| Same as in Diagnostic Bronchoscopy.                                        |
| Note: This module comes with designated EBUS needle hardware.              |

[OCR]
Essential EBUS Module

4 - EBUS Needle Tool Panel

a - Lock indicates the state of the EBUS needle
hardware: whether at the click-locked position or not.

b - Stylet removal is performed virtually: a
press the ‘Stylet Out’ on the screen or use the C
scope button or left foot switch to remove the stylet.
Use the same controls for ‘Stylet In’.

Note: Whenever the EBUS needle is inserted into the
working channel, the stylet is considered in.

c - Attach Syringe is optional. After pressing ‘Attach
Syringe’ on the screen, the actual syringe is used

to apply ‘Vacuum On’ by opening the syringe and
‘Vacuum Off’ by closing the syringe.

5 - Patient Management

When moderate sedation is selected, patient management is the same as in
Diagnostic Bronchoscopy. When general anesthesia is selected, the virtual
patient is considered anesthetized, and no patient management is required.

6 - Virtual Instructor
Same as in Diagnostic Bronchoscopy.
7 - General Buttons

Same as in Diagnostic Bronchoscopy.

Note: This module comes with designated EBUS needle hardware.

surgical BRONCH Mentor


# Page 6

Essential EBUS Module
6
BRONCH Mentor
Unique Tools
The EBUS Needle hardware is a real EBUS needle modified to fit simulation 
needs. All original functionality is maintained, except for the stylet which is 
virtual.
1 - Cable connects to the fourth socket of the 
tool tray (furthest from system).
2 - Needle controls account for needle motion 
out and in of its sheath. The secure lock slider 
provides extra safety in securing the needle, 
optional length adjustment and motion stopper. 
The grey mechanical stopper sets the maximum 
needle length and cannot be removed.
Note: The needle click-locked state is at the 
upper most position of the needle handle. When 
in this position, the needle is completely inside 
the sheath.  
A mechanical click divides this position from the 
rest of the motion range.
3 - Sheath controls are used to set the 
measurement of sheath protrusion out of the 
working channel and fix it.
4 - Fixation to working channel by inserting and 
fixating the EBUS Needle to the scope’s working 
channel using the slide lock.
Note: The slide lock must be released when 
inserting the needle and then fit and locked to 
the adapter. 
 
a - The adapter should be thrust over the 
scope’s working channel extension prior to 
starting an EBUS case.
1
2
3
4
a


[TABLE]
| Unique Tools                                                                    |    |
|:--------------------------------------------------------------------------------|:---|
| The EBUS Needle hardware is a real EBUS needle modified to fit simulation       |    |
| needs. All original functionality is maintained, except for the stylet which is |    |
| virtual.                                                                        |    |
| 1 - Cable connects to the fourth socket of the                                  |    |
| tool tray (furthest from system).                                               |    |
| 1                                                                               |    |
| 2 - Needle controls account for needle motion                                   |    |
| out and in of its sheath. The secure lock slider                                |    |
| provides extra safety in securing the needle,                                   |    |
| optional length adjustment and motion stopper.                                  |    |
| The grey mechanical stopper sets the maximum                                    |    |
| needle length and cannot be removed.                                            |    |
| 2                                                                               |    |
| Note: The needle click-locked state is at the                                   |    |
| upper most position of the needle handle. When                                  |    |
| in this position, the needle is completely inside                               |    |
| the sheath.                                                                     |    |
| A mechanical click divides this position from the                               |    |
| rest of the motion range.                                                       |    |
| 3 - Sheath controls are used to set the                                         |    |
| 3                                                                               |    |
| measurement of sheath protrusion out of the                                     |    |
| working channel and fix it.                                                     |    |
| 4 - Fixation to working channel by inserting and                                |    |
| fixating the EBUS Needle to the scope’s working                                 |    |
| channel using the slide lock.                                                   |    |
| Note: The slide lock must be released when                                      |    |
|                                                                                 | a  |
| inserting the needle and then fit and locked to                                 |    |
| the adapter.                                                                    |    |
| a                                                                               |    |
| 4                                                                               |    |
| - The adapter should be thrust over the                                         |    |
| scope’s working channel extension prior to                                      |    |
| starting an EBUS case.                                                          |    |

[OCR]
Essential EBUS Module

Unique Tools

The EBUS Needle hardware is a real EBUS needle modified to fit simulation
needs. All original functionality is maintained, except for the stylet which is

virtual.

1- Cable connects to the fourth socket of the

tool tray (furthest from system).

2 - Needle controls account for needle motion
out and in of its sheath. The secure lock slider
provides extra safety in securing the needle,

optional length adjustment and mo’

The grey mechanical stopper sets

ion stopper.

he maximum

needle length and cannot be removed.

Note: The needle click-locked state is at the
upper most position of the needle handle. When

in this position, the needle is comp
the sheath.

jetely inside

A mechanical click divides this position from the

rest of the motion range.

3 - Sheath controls are used to se
measurement of sheath protrusion
working channel and fix it.

the
out of the

4 - Fixation to working channel by inserting and
fixating the EBUS Needle to the scope’s working

channel using the slide lock.

Note: The slide lock must be released when

inserting the needle and then fit an
the adapter.

d locked to

a - The adapter should be thrust over the

scope’s working channel extension
starting an EBUS case.

surgical

prior to

o 4

o

BRONCH Mentor


# Page 7

Essential EBUS Module
7
BRONCH Mentor
Goal
Learn and practice video-based scope orientation and ultrasound-based 
recognition of EBUS-TBNA accessible lymph node stations, demonstrating 
bronchial - vascular - nodal interrelations according to the IASLC classification 
(2009). 
Method
Practice mediastinal landmark recognition including optimal scope positioning, 
structure recognition using ultrasound, and selection of corresponding CT 
image. Each captured landmark consists of labeled ultrasound view capture, 
LN station name according to IASLC classification, and a corresponding 
CT slice demonstrating the anatomical location of that lymph node station. 
Performance assessment includes the accuracy of scope positioning and 
correct matching of CT slice for each lymph node station captured, and the 
completeness of capturing all EBUS-TBNA accessible mediastinal lymph node 
stations. 
Four peripheral lesions, either surrounding the airway or adjacent to it, can be 
visualized, labeled and captured in the same manner.
Task 1 - Landmark Recognition, Educational En-
vironment
1


[TABLE]
| Task 1 - Landmark Recognition, Educational En-                                    |
| 1                                                                                 |
|:----------------------------------------------------------------------------------|
| vironment                                                                         |
| Goal                                                                              |
| Learn and practice video-based scope orientation and ultrasound-based             |
| recognition of EBUS-TBNA accessible lymph node stations, demonstrating            |
| bronchial - vascular - nodal interrelations according to the IASLC classification |
| (2009).                                                                           |
| Method                                                                            |
| Practice mediastinal landmark recognition including optimal scope positioning,    |
| structure recognition using ultrasound, and selection of corresponding CT         |
| image. Each captured landmark consists of labeled ultrasound view capture,        |
| LN station name according to IASLC classification, and a corresponding            |
| CT slice demonstrating the anatomical location of that lymph node station.        |
| Performance assessment includes the accuracy of scope positioning and             |
| correct matching of CT slice for each lymph node station captured, and the        |
| completeness of capturing all EBUS-TBNA accessible mediastinal lymph node         |
| stations.                                                                         |
| Four peripheral lesions, either surrounding the airway or adjacent to it, can be  |
| visualized, labeled and captured in the same manner.                              |

[OCR]
Essential EBUS Module fy

Task 1 - Landmark Recognition, Educational En-
vironment

Goal

Learn and practice video-based scope orientation and ultrasound-based
recognition of EBUS-TBNA accessible lymph node stations, demonstrating
bronchial - vascular - nodal interrelations according to the IASLC classification
(2009).

Method

Practice mediastinal landmark recognition including optimal scope positioning,
structure recognition using ultrasound, and selection of corresponding CT
image. Each captured landmark consists of labeled ultrasound view capture,
LN station name according to IASLC classification, and a corresponding

CT slice demonstrating the anatomical location of that lymph node station.
Performance assessment includes the accuracy of scope positioning and
correct matching of CT slice for each lymph node station captured, and the
completeness of capturing all EBUS-TBNA accessible mediastinal lymph node
stations.

Four peripheral lesions, either surrounding the airway or adjacent to it, can be
visualized, labeled and captured in the same manner.

surgical BRONCH Mentor


# Page 8

Essential EBUS Module
8
BRONCH Mentor
Task Performance
Use the scope video to navigate to the desired landmark and label the relevant 
structures on the ultrasound display, by touching the structure on the screen. 
Then freeze the image using scope’s ‘Freeze’ button.  Once you have a frozen 
ultrasound image, you can mark the correct lymph node station name and the 
correct anatomical location on the CT scan (using either axial or coronal plane). 
Having captured an ultrasound image, matching name and CT slice, the 
landmark can be viewed and saved using the ‘Save’ button to the right of the 
landmarks list. Saved landmarks can be browsed and optionally discarded and 
recaptured.  
External 3D map view, video clip tutorials and IASLC classification drawing are 
available upon selection in the right side windows. 
Additionally, two peripheral lesions can be found in the MLB (RB4, RB5) 
and two in the Lingula (LB4, LB5). To capture peripheral lesions, switch to 
a forward viewing scope using left side button  (enabled when the scope is 
completely withdrawn), then navigate to the designated bronchial segments 
and use the master tool as a radial EBUS probe, with or without a balloon to 
visualize, label and capture.
The task is completed once you have captured and saved all of the landmarks 
in the list: 2R, 2L, 4R, 4L, 7, 10R, 10L, 11Rs, 11Ri and 11L, and optionally the 
radial EBUS landmarks.
Note: Light blue labels indicate this structure is a defining structure for this 
lymph node station or the lymph node itself. Once you have marked a CT 
slice, it will remain selected unless you mark a different slice. 
Task 1 - Landmark Recognition, Educational 
Environment
1


[TABLE]
| Task 1 - Landmark Recognition, Educational                                        |
|:----------------------------------------------------------------------------------|
| Environment                                                                       |
| 1                                                                                 |
| Task Performance                                                                  |
| Use the scope video to navigate to the desired landmark and label the relevant    |
| structures on the ultrasound display, by touching the structure on the screen.    |
| Then freeze the image using scope’s ‘Freeze’ button.  Once you have a frozen      |
| ultrasound image, you can mark the correct lymph node station name and the        |
| correct anatomical location on the CT scan (using either axial or coronal plane). |
| Having captured an ultrasound image, matching name and CT slice, the              |
| landmark can be viewed and saved using the ‘Save’ button to the right of the      |
| landmarks list. Saved landmarks can be browsed and optionally discarded and       |
| recaptured.                                                                       |
| External 3D map view, video clip tutorials and IASLC classification drawing are   |
| available upon selection in the right side windows.                               |
| Additionally, two peripheral lesions can be found in the MLB (RB4, RB5)           |
| and two in the Lingula (LB4, LB5). To capture peripheral lesions, switch to       |
| a forward viewing scope using left side button  (enabled when the scope is        |
| completely withdrawn), then navigate to the designated bronchial segments         |
| and use the master tool as a radial EBUS probe, with or without a balloon to      |
| visualize, label and capture.                                                     |
| The task is completed once you have captured and saved all of the landmarks       |
| in the list: 2R, 2L, 4R, 4L, 7, 10R, 10L, 11Rs, 11Ri and 11L, and optionally the  |
| radial EBUS landmarks.                                                            |

[OCR_TABLE]
mw

[OCR]
Essential EBUS Module fy

Task Performance

Use the scope video to navigate to the desired landmark and label the relevant
structures on the ultrasound display, by touching the structure on the screen.
Then freeze the image using scope’s ‘Freeze’ button. Once you have a frozen
ultrasound image, you can mark the correct lymph node station name and the
correct anatomical location on the CT scan (using either axial or coronal plane).
Having captured an ultrasound image, matching name and CT slice, the
landmark can be viewed and saved using the ‘Save’ button to the right of the
landmarks list. Saved landmarks can be browsed and optionally discarded and
recaptured.

External 3D map view, video clip tutorials and IASLC classification drawing are
available upon selection in the right side windows.

Additionally, two peripheral lesions can be found in the MLB (RB4, RB5)

and two in the Lingula (LB4, LB5). To capture peripheral lesions, switch to

a forward viewing scope using left side button (enabled when the scope is

completely withdrawn), then navigate to the designated bronchial segments
and use the master tool as a radial EBUS probe, with or without a balloon to
visualize, label and capture.

The task is completed once you have captured and saved all of the landmarks
in the list: 2R, 2L, 4R, 4L, 7, 10R, 10L, 11Rs, 11Ri and 11L, and optionally the
radial EBUS landmarks.

Note: Light blue labels indicate this structure is a defining structure for this
lymph node station or the lymph node itself. Once you have marked a CT
slice, it will remain selected unless you mark a different slice.

surgical BRONCH Mentor


# Page 9

Essential EBUS Module
9
BRONCH Mentor
Goal
Assess your mastering of EBUS-TBNA accessible lymph nodes acquisition, 
including optimal scope positioning, identification of  vascular and nodal 
structures in the ultrasound view and  demonstrating bronchial - vascular - 
nodal interrelations according to the IASLC classification (2009). 
Method
Practice mediastinal landmark recognition including optimal scope positioning, 
labeling of the structures visualized on the ultrasound view, and selecting 
corresponding CT image. Practice in an unaided environment which otherwise 
resembles Task 1. Performance assessment includes the correctness of 
labeling the defining structures, accuracy of scope positioning and correct 
matching of CT slice for each lymph node station captured, as well as the 
completeness of capturing all EBUS-TBNA accessible mediastinal lymph node 
stations.  
Task 2 - Landmark Recognition, Task Environment
2


[TABLE]
|                                                                                |
|:-------------------------------------------------------------------------------|
| Task 2 - Landmark Recognition, Task Environment                                |
| 2                                                                              |
| Goal                                                                           |
| Assess your mastering of EBUS-TBNA accessible lymph nodes acquisition,         |
| including optimal scope positioning, identification of  vascular and nodal     |
| structures in the ultrasound view and  demonstrating bronchial - vascular -    |
| nodal interrelations according to the IASLC classification (2009).             |
| Method                                                                         |
| Practice mediastinal landmark recognition including optimal scope positioning, |
| labeling of the structures visualized on the ultrasound view, and selecting    |
| corresponding CT image. Practice in an unaided environment which otherwise     |
| resembles Task 1. Performance assessment includes the correctness of           |
| labeling the defining structures, accuracy of scope positioning and correct    |
| matching of CT slice for each lymph node station captured, as well as the      |
| completeness of capturing all EBUS-TBNA accessible mediastinal lymph node      |
| stations.                                                                      |

[OCR]
Essential EBUS Module fy

Task 2 - Landmark Recognition, Task Environment

Goal

Assess your mastering of EBUS-TBNA accessible lymph nodes acquisition,
including optimal scope positioning, identification of vascular and nodal
structures in the ultrasound view and demonstrating bronchial - vascular -
nodal interrelations according to the IASLC classification (2009).

Method

Practice mediastinal landmark recognition including optimal scope positioning,
labeling of the structures visualized on the ultrasound view, and selecting
corresponding CT image. Practice in an unaided environment which otherwise
resembles Task 1. Performance assessment includes the correctness of
labeling the defining structures, accuracy of scope positioning and correct
matching of CT slice for each lymph node station captured, as well as the
completeness of capturing all EBUS-TBNA accessible mediastinal lymph node
stations.

surgical BRONCH Mentor


# Page 10

Essential EBUS Module
10
BRONCH Mentor
Task Performance
Use the scope video to navigate to the desired landmark and label the relevant 
structures on the ultrasound display in the following manner: touch inside a 
structure to open a menu and display question marks in the relevant structure. 
Select its correct name from the menu using scope buttons, foot switch or 
touching the screen. If correct, the structure will be labeled; otherwise try 
again. After three incorrect trials, the structure will automatically be labeled. 
Following structure labeling, restore optimal scope position and then freeze 
the image using scope’s ‘Freeze’ button.  Once you have a frozen ultrasound 
image, mark the correct lymph node station name and the correct anatomical 
location on the CT scan (using either the axial or coronal plane).  
Having captured a labeled ultrasound image, matching name and CT slice, the 
landmark can be viewed and saved using the ‘Save’ button to the right of the 
landmarks list. Saved landmarks can be browsed and optionally discarded and 
recaptured. 
The task is completed once you have captured and saved all of the landmarks 
in the list: 2R, 2L, 4R, 4L, 7, 10R, 10L, 11Rs, 11Ri and 11L.
Task 2 - Landmark Recognition, Task Environment
2


[TABLE]
| Essential EBUS Module                                                             |
|:----------------------------------------------------------------------------------|
| Task 2 - Landmark Recognition, Task Environment                                   |
| 2                                                                                 |
| Task Performance                                                                  |
| Use the scope video to navigate to the desired landmark and label the relevant    |
| structures on the ultrasound display in the following manner: touch inside a      |
| structure to open a menu and display question marks in the relevant structure.    |
| Select its correct name from the menu using scope buttons, foot switch or         |
| touching the screen. If correct, the structure will be labeled; otherwise try     |
| again. After three incorrect trials, the structure will automatically be labeled. |
| Following structure labeling, restore optimal scope position and then freeze      |
| the image using scope’s ‘Freeze’ button.  Once you have a frozen ultrasound       |
| image, mark the correct lymph node station name and the correct anatomical        |
| location on the CT scan (using either the axial or coronal plane).                |
| Having captured a labeled ultrasound image, matching name and CT slice, the       |
| landmark can be viewed and saved using the ‘Save’ button to the right of the      |
| landmarks list. Saved landmarks can be browsed and optionally discarded and       |
| recaptured.                                                                       |
| The task is completed once you have captured and saved all of the landmarks       |
| in the list: 2R, 2L, 4R, 4L, 7, 10R, 10L, 11Rs, 11Ri and 11L.                     |
| 10                                                                                |
| BRONCH Mentor                                                                     |

[OCR_TABLE]
mw

[OCR]
Essential EBUS Module

Task Performance

Use the scope video to navigate to the desired landmark and label the relevant
structures on the ultrasound display in the following manner: touch inside a
structure to open a menu and display question marks in the relevant structure.
Select its correct name from the menu using scope buttons, foot switch or
touching the screen. If correct, the structure will be labeled; otherwise try
again. After three incorrect trials, the structure will automatically be labeled.
Following structure labeling, restore optimal scope position and then freeze
the image using scope’s ‘Freeze’ button. Once you have a frozen ultrasound
image, mark the correct lymph node station name and the correct anatomical
location on the CT scan (using either the axial or coronal plane).

Having captured a labeled ultrasound image, matching name and CT slice, the
landmark can be viewed and saved using the ‘Save’ button to the right of the
landmarks list. Saved landmarks can be browsed and optionally discarded and
recaptured.

The task is completed once you have captured and saved all of the landmarks
in the list: 2R, 2L, 4R, 4L, 7, 10R, 10L, 11Rs, 11Ri and 11L.

Landmark correctly captured and matched

Landmark: 4L
Scope postion was correct

CT was corresponded correctly.

Aortic arch: was labeled correctly at 1st attempt
Pulmonary artery: was labeled correctly at 1st attempt.
4L: was labeled correctly at 1st sttemet

Close

surgical BRONCH Mentor


# Page 11

Essential EBUS Module
11
BRONCH Mentor
Goal
Acquire the necessary skills and know-how to perform a complete EBUS-TBNA 
procedure, with emphasis on obtaining a proper tissue sample while attaining 
to patient safety and equipment safety.
Method
Follow detailed step-by-step instructions to obtain a tissue sample from two 
optional lymph node stations, receiving immediate feedback about the quality 
and the efficacy of the maneuver. 
Task Performance
Use the scope video to navigate to one of the colored regions corresponding 
to lymph node station 4L or lymph node station 7. Then, following step-by-
step instructions, visualize the lymph node and local blood vessels on the 
ultrasound view and perform the complete workflow to obtain a sample using 
the EBUS needle. A sampling attempt is complete upon fully withdrawing the 
EBUS needle. Immediate feedback about the quality and the efficacy of the 
maneuver will be displayed upon completion of each sampling attempt.
Task 3 - EBUS-TBNA Step by Step
Note: The OK button is used to confirm certain steps, using the right foot 
switch, the scope’s ‘C’ button or touching the screen.
3


[TABLE]
|                                                                              |
|:-----------------------------------------------------------------------------|
| Task 3 - EBUS-TBNA Step by Step                                              |
| 3                                                                            |
| Goal                                                                         |
| Acquire the necessary skills and know-how to perform a complete EBUS-TBNA    |
| procedure, with emphasis on obtaining a proper tissue sample while attaining |
| to patient safety and equipment safety.                                      |
| Method                                                                       |
| Follow detailed step-by-step instructions to obtain a tissue sample from two |
| optional lymph node stations, receiving immediate feedback about the quality |
| and the efficacy of the maneuver.                                            |
| Task Performance                                                             |
| Use the scope video to navigate to one of the colored regions corresponding  |
| to lymph node station 4L or lymph node station 7. Then, following step-by-   |
| step instructions, visualize the lymph node and local blood vessels on the   |
| ultrasound view and perform the complete workflow to obtain a sample using   |
| the EBUS needle. A sampling attempt is complete upon fully withdrawing the   |
| EBUS needle. Immediate feedback about the quality and the efficacy of the    |
| maneuver will be displayed upon completion of each sampling attempt.         |

[OCR]
Essential EBUS Module fy

Task 3 - EBUS-TBNA Step by Step

Goal

Acquire the necessary skills and know-how to perform a complete EBUS-TBNA
procedure, with emphasis on obtaining a proper tissue sample while attaining
to patient safety and equipment safety.

Method

Follow detailed step-by-step instructions to obtain a tissue sample from two
optional lymph node stations, receiving immediate feedback about the quality
and the efficacy of the maneuver.

Task Performance

Use the scope video to navigate to one of the colored regions corresponding
to lymph node station 4L or lymph node station 7. Then, following step-by-
step instructions, visualize the lymph node and local blood vessels on the
ultrasound view and perform the complete workflow to obtain a sample using
the EBUS needle. A sampling attempt is complete upon fully withdrawing the
EBUS needle. Immediate feedback about the quality and the efficacy of the
maneuver will be displayed upon completion of each sampling attempt.

Note: The OK button is used to confirm certain steps, using the right foot
switch, the scope’s ‘C’ button or touching the screen.

surgical BRONCH Mentor


# Page 12

Essential EBUS Module
12
BRONCH Mentor
Patient History and Condition
A 73 YO male, with complaints of a cough, weight loss and hoarseness. The 
patient is a former smoker: ~20 cigarettes daily for 35 years. He stopped 
smoking 11 years ago. A CT scan showed an intrapulmonary mass in the left 
lower lobe of 36 X 24 mm. It also showed enlarged lymph node stations: 4L 
(left lower paratracheal) - short axis 13 mm, 7 (subcarinal) - short axis 18 mm, 
and 11L (left interlobar) - short axis 17 mm.  
A previously performed bronchoscopy did not establish a final diagnosis.
Case 4
This case was developed with: J.T. Annema, MD PhD and M.K. Ninaber, MD
Leiden University Medical Center, The Netherlands
Case Summary
Enlarged lymph node stations 4L, 7 and 11L. 
Perform sampling according to the current recommendations. 
Biopsy results – all lymph node stations are malignant.
4


[TABLE]
|                                                                                  |
|:---------------------------------------------------------------------------------|
| Case 4                                                                           |
| 4                                                                                |
| Patient History and Condition                                                    |
| A 73 YO male, with complaints of a cough, weight loss and hoarseness. The        |
| patient is a former smoker: ~20 cigarettes daily for 35 years. He stopped        |
| smoking 11 years ago. A CT scan showed an intrapulmonary mass in the left        |
| lower lobe of 36 X 24 mm. It also showed enlarged lymph node stations: 4L        |
| (left lower paratracheal) - short axis 13 mm, 7 (subcarinal) - short axis 18 mm, |
| and 11L (left interlobar) - short axis 17 mm.                                    |
| A previously performed bronchoscopy did not establish a final diagnosis.         |

[OCR_TABLE]
an ee & *‘

[OCR]
Essential EBUS Module A

Case 4

Patient History and Condition

A 73 YO male, with complaints of a cough, weight loss and hoarseness. The
patient is a former smoker: ~20 cigarettes daily for 35 years. He stopped
smoking 11 years ago. A CT scan showed an intrapulmonary mass in the left
lower lobe of 36 X 24 mm. It also showed enlarged lymph node stations: 4L
(left lower paratracheal) - short axis 13 mm, 7 (subcarinal) - short axis 18 mm,
and 11L (left interlobar) - short axis 17 mm.

A previously performed bronchoscopy did not establish a final diagnosis.

Case Summary

Enlarged lymph node stations 4L, 7 and 11L.
Perform sampling according to the current recommendations.
Biopsy results — all lymph node stations are malignant.

This case was developed with: J.T. Annema, MD PhD and M.K. Ninaber, MD
Leiden University Medical Center, The Netherlands

surgical BRONCH Mentor


# Page 13

Essential EBUS Module
13
BRONCH Mentor
Patient History and Condition
A 72 YO male was diagnosed with Squamous cell carcinoma of the right upper 
lobe. The CT scan showed enlarged lymph node stations: 2R (right upper 
paratracheal), 4R (right lower paratracheal), 7 (subcarinal) and 10R (right hilar).
Case 5
This case was developed with: J.T. Annema, MD PhD and M.K. Ninaber, MD
Leiden University Medical Center, The Netherlands
Case Summary
Enlarged lymph node stations: 2R, 4R, 7 and 10R.  
Ultrasound demonstrates lymph node stations diversity in terms of 
echogenecity and edge sharpness.  
Perform sampling according to the current recommendations. 
Biopsy results – 4R and 10R are malignant, 2R and 7 are benign.
5


[TABLE]
| Essential EBUS Module                                                               |
|:------------------------------------------------------------------------------------|
| Case 5                                                                              |
| 5                                                                                   |
| Patient History and Condition                                                       |
| A 72 YO male was diagnosed with Squamous cell carcinoma of the right upper          |
| lobe. The CT scan showed enlarged lymph node stations: 2R (right upper              |
| paratracheal), 4R (right lower paratracheal), 7 (subcarinal) and 10R (right hilar). |
| Case Summary                                                                        |
| Enlarged lymph node stations: 2R, 4R, 7 and 10R.                                    |
| Ultrasound demonstrates lymph node stations diversity in terms of                   |
| echogenecity and edge sharpness.                                                    |
| Perform sampling according to the current recommendations.                          |
| Biopsy results – 4R and 10R are malignant, 2R and 7 are benign.                     |
| This case was developed with: J.T. Annema, MD PhD and M.K. Ninaber, MD              |
| Leiden University Medical Center, The Netherlands                                   |
| 13                                                                                  |
| BRONCH Mentor                                                                       |

[OCR]
Essential EBUS Module A

Case 5

Patient History and Condition

A 72 YO male was diagnosed with Squamous cell carcinoma of the right upper
lobe. The CT scan showed enlarged lymph node stations: 2R (right upper
paratracheal), 4R (right lower paratracheal), 7 (subcarinal) and 10R (right hilar).

Case Summary

Enlarged lymph node stations: 2R, 4R, 7 and 10R.

Ultrasound demonstrates lymph node stations diversity in terms of
echogenecity and edge sharpness.

Perform sampling according to the current recommendations.
Biopsy results — 4R and 10R are malignant, 2R and 7 are benign.

This case was developed with: J.T. Annema, MD PhD and M.K. Ninaber, MD
Leiden University Medical Center, The Netherlands

surgical BRONCH Mentor


# Page 14

Essential EBUS Module
14
BRONCH Mentor
Patient History and Condition
A 35 year old female exhibiting symptoms of cough, fatigue and 
conjunctivitis. Patient is otherwise healthy. 
The CT scan of the chest showed bilateral enlarged mediastinal, hilar 
and interlobar lymph nodes.
Case 6
This case was developed with: J.T. Annema, MD PhD and M.K. Ninaber, MD
Leiden University Medical Center, The Netherlands
Case Summary
Enlarged lymph nodes or lymph node clusters in multiple stations: 2R, 
4R, 10R, 11Rs, 11Ri, 7, 4L, 10L and 11L.  
Perform sampling according to the current recommendations. 
Biopsy results indicating sarcoidosis.
6


[TABLE]
|                                                                       |
|:----------------------------------------------------------------------|
| Case 6                                                                |
| 6                                                                     |
| Patient History and Condition                                         |
| A 35 year old female exhibiting symptoms of cough, fatigue and        |
| conjunctivitis. Patient is otherwise healthy.                         |
| The CT scan of the chest showed bilateral enlarged mediastinal, hilar |
| and interlobar lymph nodes.                                           |

[OCR]
Essential EBUS Module A

Case 6

Patient History and Condition

A 35 year old female exhibiting symptoms of cough, fatigue and
conjunctivitis. Patient is otherwise healthy.

The CT scan of the chest showed bilateral enlarged mediastinal, hilar
and interlobar lymph nodes.

Case Summary

Enlarged lymph nodes or lymph node clusters in multiple stations: 2R,
AR, 10R, 11Rs, 11Ri, 7, 4L, 10L and 11L.

Perform sampling according to the current recommendations.

Biopsy results indicating sarcoidosis.

This case was developed with: J.T. Annema, MD PhD and M.K. Ninaber, MD
Leiden University Medical Center, The Netherlands

surgical BRONCH Mentor