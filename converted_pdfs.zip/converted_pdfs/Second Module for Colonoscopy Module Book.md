

# Page 1

Lower Gastrointestinal 
Endoscopy (Colonoscopy)
Second Module -
1
GI Mentor
The module is designed for trainees who have just begun the “hands-on” 
phase of learning and training in Colonoscopy.
The module objectives are:
	
 Performing a complete survey of the Lower GI tract with a forward viewing 
video-endoscope.
	
 Recognition of typical lesions and abnormalities.
	
 Performing diagnostic and therapeutic procedures in “patients” with 
different colon anatomies and pathologies.
The module consists of 10 cases. The cases were created by Prof. Florent, 
Hôpital Saint-Antoine, Paris, France.


[TABLE]
| Endoscopy (Colonoscopy)                                                   |
|:--------------------------------------------------------------------------|
| The module is designed for trainees who have just begun the “hands-on”    |
| phase of learning and training in Colonoscopy.                            |
| The module objectives are:                                                |
|  Performing a complete survey of the Lower GI tract with a forward viewing                                                                           |
| video-endoscope.                                                          |
|  Recognition of typical lesions and abnormalities.                                                                           |
|  Performing diagnostic and therapeutic procedures in “patients” with                                                                           |
| different colon anatomies and pathologies.                                |
| The module consists of 10 cases. The cases were created by Prof. Florent, |
| Hôpital Saint-Antoine, Paris, France.                                     |

[OCR]
The module is designed for trainees who have just begun the “hands-on”
phase of learning and training in Colonoscopy.

The module objectives are:

= Performing a complete survey of the Lower Gl tract with a forward viewing
video-endoscope.

= Recognition of typical lesions and abnormalities.

= Performing diagnostic and therapeutic procedures in “patients” with
different colon anatomies and pathologies.

The module consists of 10 cases. The cases were created by Prof. Florent,
H6pital Saint-Antoine, Paris, France.

surgical GI Mentor


# Page 2

Lower Gastrointestinal 
Endoscopy (Colonoscopy)
Second Module -
2
GI Mentor
1
Medical History: 
Mr. COCHET, 59 years of age, was hospitalized for diarrhea that developed 
during the past 3 months, with a weight loss of 5 kg. Physical and rectal 
examinations were normal. The patient’s medical history includes a 
cholecystectomy, which was performed 10 years ago, for cholelithiasis. 
This patient is not taking any medication.
Biological Tests: 
RBC: 
 
4.3 × 10¹²/L 
(4.5 × 10¹²) 
Hemoglobin: 
10.7 g/dL 
(N > 14) 
Hematocrit: 
35% 
 
(40 - 48) 
Serum iron: 
5.6 µmol/L 
(10.7 - 26.9) 
Platelets: 
235 × 10⁹/L 
(100 - 300 × 10⁹) 
Inspection of the stools reveals occult bleeding.
Comments: 
The patient has a pedunculated polyp in the sigmoid colon, 12 mm in 
diameter. It is not necessary to perform a biopsy, but rather a polypectomy via 
diathermic snare halfway between the head of the polyp and the wall of the 
colon, in order to eliminate the risk of perforation. The polyp will be removed 
by means of a blended current (cutting/coagulating) or a cutting current. Given 
the diameter of the stalk, the risk of post-polypectomy hemorrhage is low. 
A colonoscopic follow-up should be performed in 3 to 5 years, according to the 
recommendations prevailing at that time.
Anatomy
Case 1 
Pedunculated polyp


[TABLE]
|                                                                                 |                                                                                |    |
|:--------------------------------------------------------------------------------|:-------------------------------------------------------------------------------|:---|
| 1                                                                               | Case 1                                                                         |    |
| Medical History:                                                                |                                                                                |    |
| Mr. COCHET, 59 years of age, was hospitalized for diarrhea that developed       |                                                                                |    |
| during the past 3 months, with a weight loss of 5 kg. Physical and rectal       |                                                                                |    |
| examinations were normal. The patient’s medical history includes a              |                                                                                |    |
| cholecystectomy, which was performed 10 years ago, for cholelithiasis.          |                                                                                |    |
| This patient is not taking any medication.                                      |                                                                                |    |
| Biological Tests:                                                               |                                                                                |    |
| RBC:                                                                            | 4.3	×	10¹²/L                                                                                | (4.5	×	10¹²)    |
| Hemoglobin:                                                                     | 10.7	g/dL                                                                                | (N	>	14)    |
| Hematocrit:                                                                     | 35%                                                                            | (40	-	48)    |
| Serum	iron:                                                                                 | 5.6	µmol/L                                                                                | (10.7	-	26.9)    |
| Platelets:                                                                      | 235	×	10⁹/L                                                                                | (100	-	300	×	10⁹)    |
| Inspection of the stools reveals occult bleeding.                               |                                                                                |    |
| Comments:                                                                       |                                                                                |    |
| The	patient	has	a	pedunculated	polyp	in	the	sigmoid	colon,	12	mm	in                                                                                 |                                                                                |    |
| diameter. It is not necessary to perform a biopsy, but rather a polypectomy via |                                                                                |    |
| diathermic snare halfway between the head of the polyp and the wall of the      |                                                                                |    |
| colon, in order to eliminate the risk of perforation. The polyp will be removed |                                                                                |    |
| by	means	of	a	blended	current	(cutting/coagulating)	or	a	cutting	current.	Given                                                                                 |                                                                                |    |
|                                                                                 | the diameter of the stalk, the risk of post-polypectomy hemorrhage is low.     |    |
|                                                                                 | A colonoscopic follow-up should be performed in 3 to 5 years, according to the |    |
|                                                                                 | recommendations prevailing at that time.                                       |    |

[OCR_TABLE]
mw Te

Engl,

[OCR]
Second Module -
Lower Gastrointestinal

Endoscopy (Colonoscopy) Wl

Case 1

Medical History:

Mr. COCHET, 59 years of age, was hospitalized for diarrhea that developed
during the past 3 months, with a weight loss of 5 kg. Physical and rectal
examinations were normal. The patient’s medical history includes a
cholecystectomy, which was performed 10 years ago, for cholelithiasis.
This patient is not taking any medication.

Biological Tests:

RBC: 4.3 x 10"/L (4.5 x 10")
Hemoglobin: 10.7 g/dL (N > 14)
Hematocrit: 35% (40 - 48)

Serum iron: 5.6 umol/L (10.7 - 26.9)
Platelets: 235 x 109/L (100 - 300 x 10°)

Inspection of the stools reveals occult bleeding.

Comments:

The patient has a pedunculated polyp in the sigmoid colon, 12 mm in

diameter. It is not necessary to perform a biopsy, but rather a polypectomy via
diathermic snare halfway between the head of the polyp and the wall of the
colon, in order to eliminate the risk of perforation. The polyp will be removed
by means of a blended current (cutting/coagulating) or a cutting current. Given
the diameter of the stalk, the risk of post-polypectomy hemorrhage is low.

A colonoscopic follow-up should be performed in 3 to 5 years, according to the
recommendations prevailing at that time.

Anatomy Pedunculated polyp

surgical GI Mentor


# Page 3

Lower Gastrointestinal 
Endoscopy (Colonoscopy)
Second Module -
3
GI Mentor
2
Medical History: 
Mr. FAVRE, 72 years of age, was hospitalized for bloody diarrhea, which 
developed during the past 5 days. Three months ago, he suffered from a 
stroke and has since been treated with aspirin, 250 mg/day. He smokes 30 
cigarettes per day and has been smoking for more than 40 years. Examination 
of the abdomen reveals a tender intumescence in the left iliac fossa. Rectal 
examination is normal and painless but produces red/black blood. The hernial 
orifices are free; the pre-hepatic dullness is preserved. The remainder of the 
physical examination is normal, except for a murmur 3/6 at the aortic valve 
radiating to the carotids. BP: 170/100 mmHg. Pulse: Regular, rate of 86/min.
Biological Tests: 
RBC: 
 
 
3.7 × 10¹²/L 
(4.5 × 10¹²) 
Hemoglobin: 
 
9.2 g/dL 
(N > 14) 
Leukocytes: 
 
12.7 × 10⁹/L 
(5 - 10 × 10⁹) 
Polymorphonuclears: 
85% 
 
(30 - 80) 
Platelets: 
 
300 × 10⁹/L 
(100 - 300 × 10⁹)
Comments: 
This is a case of ischemic colitis, as suggested by the surface, appearance, 
and topography of the lesions. The existence of lesions of different ages is 
not rare and does not undermine the diagnosis. The histological examination is 
not indispensable; it would show deposits of hemosiderin and an inflammatory 
reaction. Aside from basic intensive care measures, there is no specific 
treatment. Anticoagulants are not indicated in this case.
Case 2 
Anatomy
lschaemic colitis
lschaemic colitis


[TABLE]
|                                                                                |                        |
|:-------------------------------------------------------------------------------|:-----------------------|
| Case 2                                                                         |                        |
| 2                                                                              |                        |
| Medical History:                                                               |                        |
| Mr.	FAVRE,	72	years	of	age,	was	hospitalized	for	bloody	diarrhea,	which                                                                                |                        |
| developed during the past 5 days. Three months ago, he suffered from a         |                        |
| stroke	and	has	since	been	treated	with	aspirin,	250	mg/day.	He	smokes	30                                                                                |                        |
| cigarettes	per	day	and	has	been	smoking	for	more	than	40	years.	Examination                                                                                |                        |
| of the abdomen reveals a tender intumescence in the left iliac fossa. Rectal   |                        |
| examination	is	normal	and	painless	but	produces	red/black	blood.	The	hernial                                                                                |                        |
| orifices are free; the pre-hepatic dullness is preserved. The remainder of the |                        |
| physical	examination	is	normal,	except	for	a	murmur	3/6	at	the	aortic	valve                                                                                |                        |
| radiating	to	the	carotids.	BP:	170/100	mmHg.	Pulse:	Regular,	rate	of	86/min.                                                                                |                        |
| Biological Tests:                                                              |                        |
| RBC:                                                                           | 3.7	×	10¹²/L	                        |
|                                                                                | (4.5	×	10¹²)                        |
| Hemoglobin:                                                                    | 9.2	g/dL		                        |
|                                                                                | (N	>	14)                        |
| Leukocytes:                                                                    | 12.7	×	10⁹/L	                        |
|                                                                                | (5	-	10	×	10⁹)                        |
| Polymorphonuclears:                                                            | 85%	                        |
|                                                                                | 	                        |
|                                                                                | (30	-	80)                        |
| Platelets:                                                                     | 300	×	10⁹/L	                        |
|                                                                                | (100	-	300	×	10⁹)                        |
| Comments:                                                                      |                        |
| This is a case of ischemic colitis, as suggested by the surface, appearance,   |                        |
| and topography of the lesions. The existence of lesions of different ages is   |                        |
| not rare and does not undermine the diagnosis. The histological examination is |                        |
| not indispensable; it would show deposits of hemosiderin and an inflammatory   |                        |
| reaction. Aside from basic intensive care measures, there is no specific       |                        |
| treatment. Anticoagulants are not indicated in this case.                      |                        |
| Anatomy                                                                        | lschaemic c olitis     |
|                                                                                | l scha emi c co lit is |

[OCR_TABLE]
we '

Ende

[OCR]
Second Module -
Lower Gastrointestinal

Endoscopy (Colonoscopy) Wl

Case 2

Medical History:

Mr. FAVRE, 72 years of age, was hospitalized for bloody diarrhea, which
developed during the past 5 days. Three months ago, he suffered from a
stroke and has since been treated with aspirin, 250 mg/day. He smokes 30
cigarettes per day and has been smoking for more than 40 years. Examination
of the abdomen reveals a tender intumescence in the left iliac fossa. Rectal
examination is normal and painless but produces red/black blood. The hernial
orifices are free; the pre-hepatic dullness is preserved. The remainder of the
physical examination is normal, except for a murmur 3/6 at the aortic valve
radiating to the carotids. BP: 170/100 mmHg. Pulse: Regular, rate of 86/min.

Biological Tests:

RBC: 3.7 x 107/L (4.5 x 10")
Hemoglobin: 9.2 g/dL (N > 14)
Leukocytes: 12.7 x 109/L (5 - 10 x 10°)
Polymorphonuclears: 85% (30 - 80)
Platelets: 300 x 109/L (100 - 300 x 10°)
Comments:

This is a case of ischemic colitis, as suggested by the surface, appearance,
and topography of the lesions. The existence of lesions of different ages is
not rare and does not undermine the diagnosis. The histological examination is
not indispensable; it would show deposits of hemosiderin and an inflammatory
reaction. Aside from basic intensive care measures, there is no specific
treatment. Anticoagulants are not indicated in this case.

Anatomy Ischaemic colitis Ischaemic colitis

surgical GI Mentor


# Page 4

Lower Gastrointestinal 
Endoscopy (Colonoscopy)
Second Module -
4
GI Mentor
3
Medical History: 
Ms. CARRE, 32 years of age, suffers from diarrhea (7 stools per day), weight 
loss, fever of 38°C, and diffuse cramping abdominal pain. These symptoms 
began 2 months ago. This patient has no previous medical history. She 
smokes 20 cigarettes per day and does not drink alcohol. She is taking oral 
contraceptives. Physical examination of the abdomen revealed a mass in the 
left iliac fossa.
Biological Tests: 
RBC: 
 
 
5.2 × 10¹²/L 
(4.5 × 10¹²) 
Hemoglobin: 
 
10.5 g/dL 
(N > 12) 
Leukocytes: 
 
14.5 × 10⁹/L 
(5 - 10 × 10⁹) 
Polynuclear basophiles: 90% 
 
(50 - 80) 
Platelets: 
 
750 × 10⁹/L 
(100 - 300 × 10⁹) 
CRP: 
 
 
7N 
ESR: 
 
 
80 mm/1 hour 
(N < 30) 
Coproculture and parasitological examinations of the stools were normal.
Comments: 
This is a moderately severe attack of ulcerative colitis. It is necessary to take 
biopsies in order to rule out amoebic or viral colitis. It is also necessary to 
examine the terminal ileum, in order to check for endoscopic signs suggesting 
Crohn’s disease. An endoscopic examination of the upper digestive tract and 
an intestinal transit time test should be performed for this purpose.
Case 3
Anatomy
Ulcerative colitis


[TABLE]
|                                                                                   |        |    |    |
|:----------------------------------------------------------------------------------|:-------|:---|:---|
| 3                                                                                 | Case 3 |    |    |
| Medical History:                                                                  |        |    |    |
|                                                                                   | Ms.	CARRE,	32	years	of	age,	suffers	from	diarrhea	(7	stools	per	day),	weight        |    |    |
|                                                                                   | loss,	fever	of	38°C,	and	diffuse	cramping	abdominal	pain.	These	symptoms        |    |    |
|                                                                                   | began	2	months	ago.	This	patient	has	no	previous	medical	history.	She        |    |    |
| smokes	20	cigarettes	per	day	and	does	not	drink	alcohol.	She	is	taking	oral                                                                                   |        |    |    |
| contraceptives. Physical examination of the abdomen revealed a mass in the        |        |    |    |
| left iliac fossa.                                                                 |        |    |    |
| Biological Tests:                                                                 |        |    |    |
| RBC:                                                                              |        | 5.2	×	10¹²/L    | (4.5	×	10¹²)    |
| Hemoglobin:                                                                       |        | 10.5	g/dL    | (N	>	12)    |
| Leukocytes:                                                                       |        | 14.5	×	10⁹/L    | (5	-	10	×	10⁹)    |
| Polynuclear	basophiles:	 90%                                                                                   |        |    | (50	-	80)    |
| Platelets:                                                                        |        | 750	×	10⁹/L    | (100	-	300	×	10⁹)    |
| CRP:                                                                              |        | 7N |    |
| ESR:                                                                              |        | 80	mm/1	hour    | (N	<	30)    |
| Coproculture and parasitological examinations of the stools were normal.          |        |    |    |
| Comments:                                                                         |        |    |    |
| This is a moderately severe attack of ulcerative colitis. It is necessary to take |        |    |    |
| biopsies in order to rule out amoebic or viral colitis. It is also necessary to   |        |    |    |
| examine the terminal ileum, in order to check for endoscopic signs suggesting     |        |    |    |
| Crohn’s disease. An endoscopic examination of the upper digestive tract and       |        |    |    |
| an intestinal transit time test should be performed for this purpose.             |        |    |    |

[OCR_TABLE]
nw Te

Ende

[OCR]
Case 3

Medical History:

Ms. CARRE, 32 years of age, suffers from diarrhea (7 stools per day), weight
loss, fever of 38°C, and diffuse cramping abdominal pain. These symptoms
began 2 months ago. This patient has no previous medical history. She
smokes 20 cigarettes per day and does not drink alcohol. She is taking oral
contraceptives. Physical examination of the abdomen revealed a mass in the
eft iliac fossa.

Biological Tests:

RBC: 5.2 x 107/L (4.5 x 10")
Hemoglobin: 10.5 g/dL (N > 12)
Leukocytes: 14.5 x 109/L (5 - 10 x 10°)
Polynuclear basophiles: 90% (50 - 80)
Platelets: 750 x 109/L (100 - 300 x 109)
CRP: 7N

ESR: 80 mm/1 hour — (N < 30)

Coproculture and parasitological examinations of the stools were normal.

Comments:

This is a moderately severe attack of ulcerative colitis. It is necessary to take
biopsies in order to rule out amoebic or viral colitis. It is also necessary to
examine the terminal ileum, in order to check for endoscopic signs suggesting
Crohn’s disease. An endoscopic examination of the upper digestive tract and
an intestinal transit time test should be performed for this purpose.

Anatomy Ulcerative colitis

surgical GI Mentor


# Page 5

Lower Gastrointestinal 
Endoscopy (Colonoscopy)
Second Module -
5
GI Mentor
4
Medical History: 
Mr. FOUQUET, 21 years of age, was admitted to Intensive Care Unit for 
massive re-rectorrhage. This has been his 5th episode of rectal bleeding.
The last episode was 7 years ago at the age of 14. Medical history includes 
splenectomy due to trauma at the age of 5. Blood pressure on admission: 
80/50 mmHg, pulse 135/min. Examination of the abdomen shows no particular 
abnormalities. Rectal examination produces bright red blood. No endoscopic 
examination has been performed.
Biological Tests: 
Hemoglobin: 
7.5 g/dL  
(N > 14) 
MCV: 
 
70 µ³ 
 
(85 - 95) 
Platelets: 
24.5 × 10⁹/L 
(100 - 300 × 10⁹) 
Leukocytes: 
13.5 × 10⁹/L 
(5 - 10 × 10⁹) 
After fluid resuscitation and lavage of the colon with PEG solution, a 
colonoscopy is performed.
Comments: 
This is a congenital angiomatosis of the colon. The only possible treatment, 
given to the lesions which extend over the entire area of the colon, is total 
colectomy. No medical or endoscopic treatment is effective. Biopsies should 
not be performed, due to the risk of bleeding from vascular lesions.
Case 4
Anatomy
Diffuse angiomatosis


[TABLE]
|                                                                               |                                                                      |    |
|:------------------------------------------------------------------------------|:---------------------------------------------------------------------|:---|
| 4                                                                             | Case 4                                                               |    |
| Medical History:                                                              |                                                                      |    |
| Mr.	FOUQUET,	21	years	of	age,	was	admitted	to	Intensive	Care	Unit	for                                                                               |                                                                      |    |
| massive re-rectorrhage. This has been his 5th episode of rectal bleeding.     |                                                                      |    |
| The	last	episode	was	7	years	ago	at	the	age	of	14.	Medical	history	includes                                                                               |                                                                      |    |
| splenectomy due to trauma at the age of 5. Blood pressure on admission:       |                                                                      |    |
| 80/50	mmHg,	pulse	135/min.	Examination	of	the	abdomen	shows	no	particular                                                                               |                                                                      |    |
| abnormalities.	Rectal	examination	produces	bright	red	blood.	No	endoscopic                                                                               |                                                                      |    |
| examination has been performed.                                               |                                                                      |    |
| Biological Tests:                                                             |                                                                      |    |
| Hemoglobin:                                                                   | 7.5	g/dL                                                                      | (N	>	14)    |
| MCV:                                                                          | 70	µ³                                                                      | (85	-	95)    |
| Platelets:                                                                    | 24.5	×	10⁹/L                                                                      | (100	-	300	×	10⁹)    |
| Leukocytes:                                                                   | 13.5	×	10⁹/L                                                                      | (5	-	10	×	10⁹)    |
| After fluid resuscitation and lavage of the colon with PEG solution, a        |                                                                      |    |
| colonoscopy is performed.                                                     |                                                                      |    |
| Comments:                                                                     |                                                                      |    |
| This is a congenital angiomatosis of the colon. The only possible treatment,  |                                                                      |    |
| given to the lesions which extend over the entire area of the colon, is total |                                                                      |    |
| colectomy.	No	medical	or	endoscopic	treatment	is	effective.	Biopsies	should                                                                               |                                                                      |    |
|                                                                               | not be performed, due to the risk of bleeding from vascular lesions. |    |

[OCR_TABLE]
we '

Ende

[OCR]
Case 4

Medical History:

Mr. FOUQUET, 21 years of age, was admitted to Intensive Care Unit for
massive re-rectorrhage. This has been his 5th episode of rectal bleeding.

The last episode was 7 years ago at the age of 14. Medical history includes
splenectomy due to trauma at the age of 5. Blood pressure on admission:
80/50 mmHg, pulse 135/min. Examination of the abdomen shows no particular
abnormalities. Rectal examination produces bright red blood. No endoscopic
examination has been performed.

Biological Tests:

Hemoglobin: 7.5 g/dL (N > 14)
MCV: 70 yp? (85 - 95)
Platelets: 24.5 x 109/L (100 - 300 x 109)

Leukocytes: 13.5 x 109/L (5 - 10 x 10°)
After fluid resuscitation and lavage of the colon with PEG solution, a
colonoscopy is performed.

Comments:

This is a congenital angiomatosis of the colon. The only possible treatment,
given to the lesions which extend over the entire area of the colon, is total
colectomy. No medical or endoscopic treatment is effective. Biopsies should
not be performed, due to the risk of bleeding from vascular lesions.

Anatomy Diffuse angiomatosis

surgical GI Mentor


# Page 6

Lower Gastrointestinal 
Endoscopy (Colonoscopy)
Second Module -
6
GI Mentor
5
Medical History 
Mr. ADDA, 42 years of age, a marketing director, is suffering from severe pain 
in the left flank radiating toward the pubis, fever of 40°C. This patient has no 
previous medical history. He has smoked 20 cigarettes per day for the past 20 
years and has consumed an average of 50 g of alcohol daily. Anti-spasmodic 
medication was ineffective. There are no urinary signs. Physical examination 
shows tenderness in the left lumbar and iliac fossa. Otherwise, the examination 
is normal. Abdominal US, chest X-ray, and EKG are normal. The pain persisted 
and 24 hours later the patient presented diarrhea composed of liquid stools 
with phlegm and blood. Coproculture and parasitological examination of the 
stools were performed, followed by a semi-urgent colonoscopy.
Biological Tests 
Hemoglobin: 
14.8 g/dL 
(N>14) 
Leukocytes: 
12.5 × 10⁹/L 
(5-10 × 10⁹) 
Platelets: 
345 × 10⁹/L 
(100-300 × 10⁹) 
ALT: 
 
25 IU 
 
(N<40) 
AST: 
 
26 IU 
 
(N<45) 
Alk. Phos: 
57 IU 
 
(N<100) 
Urine protein:	
0 
HLM: normal 
S Amylase: normal
Case 5
Anatomy
Diverticulum
Diverticulitis


[TABLE]
|                                                                                 |        |         |
|:--------------------------------------------------------------------------------|:-------|:--------|
| 5                                                                               | Case 5 |         |
| Medical History                                                                 |        |         |
| Mr.	ADDA,	42	years	of	age,	a	marketing	director,	is	suffering	from	severe	pain                                                                                 |        |         |
| in	the	left	flank	radiating	toward	the	pubis,	fever	of	40°C.	This	patient	has	no                                                                                 |        |         |
| previous	medical	history.	He	has	smoked	20	cigarettes	per	day	for	the	past	20                                                                                 |        |         |
| years and has consumed an average of 50 g of alcohol daily. Anti-spasmodic      |        |         |
| medication was ineffective. There are no urinary signs. Physical examination    |        |         |
| shows tenderness in the left lumbar and iliac fossa. Otherwise, the examination |        |         |
| is normal. Abdominal US, chest X-ray, and EKG are normal. The pain persisted    |        |         |
| and	24	hours	later	the	patient	presented	diarrhea	composed	of	liquid	stools                                                                                 |        |         |
| with phlegm and blood. Coproculture and parasitological examination of the      |        |         |
| stools were performed, followed by a semi-urgent colonoscopy.                   |        |         |
| Biological Tests                                                                |        |         |
| Hemoglobin:                                                                     | 14.8	g/dL        | (N>14)  |
| Leukocytes:                                                                     | 12.5	×	10⁹/L        | (5-10	×	10⁹)         |
| Platelets:                                                                      | 345	×	10⁹/L        | (100-300	×	10⁹)         |
| ALT:                                                                            | 25	IU        | (N<40)  |
| AST:                                                                            | 26	IU        | (N<45)  |
| Alk.	Phos:                                                                                 | 57	IU        | (N<100) |
| Urine protein:                                                                  | 0      |         |
| HLM:	normal                                                                                 |        |         |
| S Amylase: normal                                                               |        |         |

[OCR_TABLE]
Endc

[OCR]
Second Module -
Lower Gastrointestinal

Endoscopy (Colonoscopy) Wl

Case 5

Medical History

Mr. ADDA, 42 years of age, a marketing director, is suffering from severe pain
in the left flank radiating toward the pubis, fever of 40°C. This patient has no
previous medical history. He has smoked 20 cigarettes per day for the past 20
years and has consumed an average of 50 g of alcohol daily. Anti-spasmodic
medication was ineffective. There are no urinary signs. Physical examination

shows tenderness in the left lumbar and iliac fossa. Otherwise, the examination
is normal. Abdominal US, chest X-ray, and EKG are normal. The pain persisted
and 24 hours later the patient presented diarrhea composed of liquid stools
with phlegm and blood. Coproculture and parasitological examination of the
stools were performed, followed by a semi-urgent colonoscopy.

Biological Tests

Hemoglobin: 14.8 g/dL (N>14)

Leukocytes: 12.5 x 109/L (5-10 x 10°)

Platelets: 345 x 109/L (100-300 x 10°)

ALT: 25 1U (N<40)

AST: 26 IU (N<45)

Alk. Phos: 57 IU (N<100)

Urine protein: 0

HLM: normal

S Amylase: normal

Anatomy Diverticulum Diverticulitis

surgical GI Mentor


# Page 7

Lower Gastrointestinal 
Endoscopy (Colonoscopy)
Second Module -
7
GI Mentor
5
Case 5
Comments 
Radiography of the abdomen without preparation showed only a transverse 
air-trapping, without dilatation, pneumoperitoneum, or liquid level. This is 
a case of acute colonic diverticulitis. No biopsies were performed. Under 
antibiotic treatment, the course of the disease was uncomplicated; the patient 
underwent an operation 3 months later.  
The indication for surgery was linked to the severity of this first attack of 
diverticulitis and to the patient’s profession (he had to do a lot of traveling, 
including to places with poor medical facilities).
Colonoscopy is contraindicated in cases of suspected diverticulitis, as it can 
induce perforation. Abdominal CT scan should be performed first because it is 
sensitive and specific and induces no risk to the patient.


[TABLE]
|                                                                                  |
|:---------------------------------------------------------------------------------|
| Case 5                                                                           |
| 5                                                                                |
| Comments                                                                         |
| Radiography of the abdomen without preparation showed only a transverse          |
| air-trapping,	without	dilatation,	pneumoperitoneum,	or	liquid	level.	This	is                                                                                  |
| a	case	of	acute	colonic	diverticulitis.	No	biopsies	were	performed.	Under                                                                                  |
| antibiotic treatment, the course of the disease was uncomplicated; the patient   |
| underwent an operation 3 months later.                                           |
| The indication for surgery was linked to the severity of this first attack of    |
| diverticulitis and to the patient’s profession (he had to do a lot of traveling, |
| including	to	places	with	poor	medical	facilities).                                                                                  |
| Colonoscopy is contraindicated in cases of suspected diverticulitis, as it can   |
| induce perforation. Abdominal CT scan should be performed first because it is    |
| sensitive and specific and induces no risk to the patient.                       |

[OCR_TABLE]
Ende

[OCR]
Case 5

Comments

Radiography of the abdomen without preparation showed only a transverse
air-trapping, without dilatation, pneumoperitoneum, or liquid level. This is

a case of acute colonic diverticulitis. No biopsies were performed. Under
antibiotic treatment, the course of the disease was uncomplicated; the patient
underwent an operation 3 months later.

The indication for surgery was linked to the severity of this first attack of
diverticulitis and to the patient’s profession (he had to do a lot of traveling,
including to places with poor medical facilities).

Colonoscopy is contraindicated in cases of suspected diverticulitis, as it can
induce perforation. Abdominal CT scan should be performed first because it is
sensitive and specific and induces no risk to the patient.

surgical GI Mentor


# Page 8

Lower Gastrointestinal 
Endoscopy (Colonoscopy)
Second Module -
8
GI Mentor
6
Case 6
Anatomy
Medical History 
Mrs. BAUDIN, 72 years of age, was referred for colonoscopy as part of 
a work-up for diarrhea and abdominal pain that developed over the past 
month. Patient’s medical history includes a total hysterectomy followed by 
pelvic radiotherapy for cancer of the cervix uteri 3 years earlier. The diarrhea 
consists of 7 to 10 stools per day, with phlegm and at times a bit of red blood. 
She claims to have lost 6 kg since the onset of the diarrhea, her weight is 
45 kg and her height 1.68 m. The physical examination shows a prominence 
of the right iliac fossa; rectal examination is normal. There was no hepato-
splenomegaly and no peripheral lymphadenopathy.
Biological Tests 
Hemoglobin: 
10.6 g/dL 
(N>12) 
MCV: 
 
88 μ³ 
 
(85-95) 
Leukocytes: 
11.8 × 10⁹/L 
(5-10 × 10⁹) 
	
	
with 90% polymorphonuclear neutrophils 
Creatinine: normal 
Blood electrolytes: normal except for hypokalemia 3.4 mEq/L
Pseudomembranous 
colitis	


[TABLE]
|                                                                                  |                                        |         |
|:---------------------------------------------------------------------------------|:---------------------------------------|:--------|
| 6                                                                                | Case 6                                 |         |
| Medical History                                                                  |                                        |         |
| Mrs.	BAUDIN,	72	years	of	age,	was	referred	for	colonoscopy	as	part	of                                                                                  |                                        |         |
| a work-up for diarrhea and abdominal pain that developed over the past           |                                        |         |
| month. Patient’s medical history includes a total hysterectomy followed by       |                                        |         |
| pelvic radiotherapy for cancer of the cervix uteri 3 years earlier. The diarrhea |                                        |         |
| consists of 7 to 10 stools per day, with phlegm and at times a bit of red blood. |                                        |         |
| She claims to have lost 6 kg since the onset of the diarrhea, her weight is      |                                        |         |
| 45	kg	and	her	height	1.68	m.	The	physical	examination	shows	a	prominence                                                                                  |                                        |         |
| of the right iliac fossa; rectal examination is normal. There was no hepato-     |                                        |         |
| splenomegaly and no peripheral lymphadenopathy.                                  |                                        |         |
| Biological Tests                                                                 |                                        |         |
| Hemoglobin:                                                                      | 10.6	g/dL                                        | (N>12)  |
| MCV:                                                                             | 88	μ³                                        | (85-95) |
| Leukocytes:                                                                      | 11.8	×	10⁹/L                                        | (5-10	×	10⁹)         |
|                                                                                  | with 90% polymorphonuclear neutrophils |         |
| Creatinine: normal                                                               |                                        |         |
| Blood	electrolytes:	normal	except	for	hypokalemia	3.4	mEq/L                                                                                  |                                        |         |

[OCR_TABLE]
Ende

[OCR]
Case 6

Medical History

Mrs. BAUDIN, 72 years of age, was referred for colonoscopy as part of

a work-up for diarrhea and abdominal pain that developed over the past
month. Patient’s medical history includes a total hysterectomy followed by
pelvic radiotherapy for cancer of the cervix uteri 3 years earlier. The diarrhea
consists of 7 to 10 stools per day, with phlegm and at times a bit of red blood.
She claims to have lost 6 kg since the onset of the diarrhea, her weight is

45 kg and her height 1.68 m. The physical examination shows a prominence
of the right iliac fossa; rectal examination is normal. There was no hepato-
splenomegaly and no peripheral lymphadenopathy.

Biological Tests
Hemoglobin: 10.6 g/dL (N>12)
MCV: 88 ue (85-95)
Leukocytes: 11.8 x 109/L (5-10 x 10°)
with 90% polymorphonuclear neutrophils
Creatinine: normal
Blood electrolytes: normal except for hypokalemia 3.4 mEq/L

Pseudomembranous
Anatomy colitis

surgical GI Mentor


# Page 9

Lower Gastrointestinal 
Endoscopy (Colonoscopy)
Second Module -
9
GI Mentor
Comments 
This is a case of pseudomembranous colitis associated with Clostridium 
difficile. This illness manifests after taking antibiotics (betalactamines). It is 
necessary to check if the patient took antibiotics recently (she took amoxicillin 
3 weeks ago for bronchitis), and to take a stool sample for Clostridium difficile 
toxin in order to confirm the diagnosis. It is necessary to take biopsies at the 
level of the lesions of the healthy mucosa for anatomical and pathological 
examination. The endoscopic picture is typical; in practice, there is no 
differential diagnosis.
Direct culture of the bacterium in the stools is difficult. 
Treatment is based on stopping the above-mentioned antibiotics. Treatment 
with an antibiotic effective on Clostridium difficile: Flagyl® (metronidazole) at 
a dose of 500 mg 2 times per day for 7 to 14 days, or vancomycin taken orally 
(125 to 250 mg) 3 times per day, the latter treatment is very expensive.
Supplementary treatment with Ultralevure® in order to reduce the risk of 
relapse is usually given.
These lesions disappeared completely after treatment.
It is impossible to discuss the diagnosis after the colonoscopy because this 
aspect is very specific and confirmed by looking for the toxin in the stools, 
using the ELISA technique (less than 6 hours).
6
Case 6


[TABLE]
|                                                                                   |
|:----------------------------------------------------------------------------------|
| Case 6                                                                            |
| 6                                                                                 |
| Comments                                                                          |
| This is a case of pseudomembranous colitis associated with Clostridium            |
| difficile.	This	illness	manifests	after	taking	antibiotics	(betalactamines).	It	is                                                                                   |
| necessary to check if the patient took antibiotics recently (she took amoxicillin |
| 3	weeks	ago	for	bronchitis),	and	to	take	a	stool	sample	for	Clostridium	difficile                                                                                   |
| toxin in order to confirm the diagnosis. It is necessary to take biopsies at the  |
| level of the lesions of the healthy mucosa for anatomical and pathological        |
| examination. The endoscopic picture is typical; in practice, there is no          |
| differential diagnosis.                                                           |
| Direct culture of the bacterium in the stools is difficult.                       |
| Treatment is based on stopping the above-mentioned antibiotics. Treatment         |
| with	an	antibiotic	effective	on	Clostridium	difficile:	Flagyl®	(metronidazole)	at                                                                                   |
| a	dose	of	500	mg	2	times	per	day	for	7	to	14	days,	or	vancomycin	taken	orally                                                                                   |
| (125	to	250	mg)	3	times	per	day,	the	latter	treatment	is	very	expensive.                                                                                   |
| Supplementary treatment with Ultralevure® in order to reduce the risk of          |
| relapse is usually given.                                                         |
| These lesions disappeared completely after treatment.                             |
| It is impossible to discuss the diagnosis after the colonoscopy because this      |
| aspect is very specific and confirmed by looking for the toxin in the stools,     |
| using	the	ELISA	technique	(less	than	6	hours).                                                                                   |

[OCR_TABLE]
Ende

[OCR]
Case 6

Comments

This is a case of pseudomembranous colitis associated with Clostridium

difficile. This illness manifests aft
necessary to check if the patient
3 weeks ago for bronchitis), and

er taking antibiotics (betalactamines). It is
took antibiotics recently (she took amoxicillin
‘0 take a stool sample for Clostridium difficile

toxin in order to confirm the diagnosis. It is necessary to take biopsies at the

level of the lesions of the healthy
examination. The endoscopic pic
differential diagnosis.

Direct culture of the bacterium in
Treatment is based on stopping t

mucosa for anatomical and pathological
ure is typical; in practice, there is no

the stools is difficult.
he above-mentioned antibiotics. Treatment

with an antibiotic effective on Clostridium difficile: Flagyl® (metronidazole) at
a dose of 500 mg 2 times per day for 7 to 14 days, or vancomycin taken orally

(125 to 250 mg) 3 times per day,

Supplementary treatment with UI
relapse is usually given.

he latter treatment is very expensive.

ralevure® in order to reduce the risk of

These lesions disappeared completely after treatment.

It is impossible to discuss the diagnosis after the colonoscopy because this

aspect is very specific and confir

med by looking for the toxin in the stools,

using the ELISA technique (less than 6 hours).

surgical

GI Mentor


# Page 10

Lower Gastrointestinal 
Endoscopy (Colonoscopy)
Second Module -
10
GI Mentor
7
Medical History 
Mrs. CAMUS, 78 years of age, was hospitalized for diarrhea, which developed 
over a 3-month period. The diarrhea consists of 7 to 10 emissions per day 
including 2 at night, with emission of liquid stool and sometimes also with 
fecal emission of the phlegm type. Imodium® produced no improvement.
Medical history includes a total hysterectomy for hemorrhagic fibroma, at the 
age of 55. For the last 5 years, she has been treated for goiter with thyroid 
insufficiency with Levothyrox®. Physical and rectal examinations are normal.  
A rigid rectoscopy performed to a depth of 20 cm was normal.
Biological Tests 
Hemoglobin: 
 
11.7 g/dL 
(N>12) 
Leukocytes: 
 
7.5 × 10⁹/L 
(5-10 × 10⁹) 
	
	
	
of which 76% polymorphonuclear neutrophils 
Platelets: 
 
230 × 10⁹/L 
(100-300 × 10⁹) 
Prothrombin Time: 
95% 
 
(N>75) 
Sodium:  
 
137 mEq/L 
(135-142) 
Potassium: 
 
2.5 mEq/L 
(3.5-4.7) 
Alkaline reserve:  
24 mEq/L 
(N=23) 
Coproculture and parasitological examination of stools were normal. 
Tests for occult bleeding were positive.
Comments 
A polypectomy was performed endoscopically without complication. The potassium 
level and the intestinal transit time normalized. Anatomical and pathological 
examination of the lesion confirmed that this was a benign villous tumor.
Case 7
Anatomy
Benign tumor


[TABLE]
|                                                                                |                                            |           |
|:-------------------------------------------------------------------------------|:-------------------------------------------|:----------|
| Case 7                                                                         |                                            |           |
| 7                                                                              |                                            |           |
| Medical History                                                                |                                            |           |
| Mrs.	CAMUS,	78	years	of	age,	was	hospitalized	for	diarrhea,	which	developed                                                                                |                                            |           |
| over a 3-month period. The diarrhea consists of 7 to 10 emissions per day      |                                            |           |
| including	2	at	night,	with	emission	of	liquid	stool	and	sometimes	also	with                                                                                |                                            |           |
| fecal emission of the phlegm type. Imodium® produced no improvement.           |                                            |           |
| Medical history includes a total hysterectomy for hemorrhagic fibroma, at the  |                                            |           |
| age of 55. For the last 5 years, she has been treated for goiter with thyroid  |                                            |           |
| insufficiency with Levothyrox®. Physical and rectal examinations are normal.   |                                            |           |
| A	rigid	rectoscopy	performed	to	a	depth	of	20	cm	was	normal.                                                                                |                                            |           |
| Biological Tests                                                               |                                            |           |
| Hemoglobin:                                                                    | 11.7	g/dL                                            | (N>12)    |
| Leukocytes:                                                                    | 7.5	×	10⁹/L                                            | (5-10	×	10⁹)           |
|                                                                                | of which 76% polymorphonuclear neutrophils |           |
| Platelets:                                                                     | 230	×	10⁹/L                                            | (100-300	×	10⁹)           |
| Prothrombin	Time:                                                                                | 95%                                        | (N>75)    |
| Sodium:                                                                        | 137	mEq/L                                            | (135-142) |
| Potassium:                                                                     | 2.5	mEq/L                                            | (3.5-4.7) |
| Alkaline	reserve:                                                                                | 24	mEq/L                                            | (N=23)    |
| Coproculture and parasitological examination of stools were normal.            |                                            |           |
| Tests for occult bleeding were positive.                                       |                                            |           |
| Comments                                                                       |                                            |           |
| A polypectomy was performed endoscopically without complication. The potassium |                                            |           |
| level and the intestinal transit time normalized. Anatomical and pathological  |                                            |           |
| examination of the lesion confirmed that this was a benign villous tumor.      |                                            |           |
| Anatomy                                                                        | Ben ign tumor                              |           |

[OCR_TABLE]
we

End

[OCR]
Second Module -
Lower Gastrointestinal

Endoscopy (Colonoscopy) Wl

Case 7

Medical History

Mrs. CAMUS, 78 years of age, was hospitalized for diarrhea, which developed
over a 3-month period. The diarrhea consists of 7 to 10 emissions per day
including 2 at night, with emission of liquid stool and sometimes also with
fecal emission of the phlegm type. Imodium® produced no improvement.
Medical history includes a total hysterectomy for hemorrhagic fibroma, at the
age of 55. For the last 5 years, she has been treated for goiter with thyroid
insufficiency with Levothyrox®. Physical and rectal examinations are normal.
A rigid rectoscopy performed to a depth of 20 cm was normal.

Biological Tests

Hemoglobin: 11.7 g/dL N>12)
Leukocytes: 7.5 x 109/L 5-10 x 10°)
of which 76% polymorphonuclear neutrophils
Platelets: 230 x 109/L 100-300 x 10°)
Prothrombin Time: 95% N>75)
Sodium: 137 mEq/L 135-142)
Potassium: 2.5 mEq/L 3.5-4.7)
Alkaline reserve: 24 mEq/L N=23)
Coproculture and parasitological examination of stools were normal.
Tests for occult bleeding were positive.
Comments
A polypectomy was performed endoscopically without complication. The potassium

level and the intestinal transit time normalized. Anatomical and pathological
examination of the lesion confirmed that this was a benign villous tumor.

Anatomy Benign tumor

surgical GI Mentor


# Page 11

Lower Gastrointestinal 
Endoscopy (Colonoscopy)
Second Module -
11
GI Mentor
8
Medical History 
Miss SIMON, 19 years of age, is suffering from bloody diarrhea which developed 
over the past 2 months. She has no particular medical history. Treatment with 
Smecta® and Imodium® did not result in any improvement.Pentasa® prescribed 
by her attending physician was ineffective. Physical examination shows a thin 
patient (45 kg, 167 cm). There is a definite cutaneo-muscular pallor. BP: 100/60 
mmHg, pulse: 105/min. Palpation of the abdomen was tender throughout; rectal 
examination is normal, but with blood on the palpating finger.
Biological Tests 
Hemoglobin: 
8.7 g/dL  
 
(N>12) 
MCV: 
 
75 μ³ 
 
 
(85-97) 
Leukocytes: 
6.5 × 10⁹/L 
 
(5-10 × 10⁹) 
	
	
of which 65% are polymorphonuclear neutrophils 
PT: 
 
95% 
 
 
(N>75) 
Platelets: 
550 × 10⁹/L 
 
(100-300 × 10⁹) 
Serum iron: 
5.0 μmol/L 
 
(10.7-26.9) 
Siderophilin saturation coefficient: 15% 
(N=33) 
Parasitological examination of the stools and coproculture were normal.
Case 8
Anatomy
Ulcerative colitis


[TABLE]
|                                                                         |                                                                               |             |
|:------------------------------------------------------------------------|:------------------------------------------------------------------------------|:------------|
| 8                                                                       | Case 8                                                                        |             |
| Medical History                                                         |                                                                               |             |
|                                                                         | Miss	SIMON,	19	years	of	age,	is	suffering	from	bloody	diarrhea	which	developed                                                                               |             |
|                                                                         | over	the	past	2	months.	She	has	no	particular	medical	history.	Treatment	with                                                                               |             |
|                                                                         | Smecta® and Imodium® did not result in any improvement.Pentasa® prescribed    |             |
|                                                                         | by her attending physician was ineffective. Physical examination shows a thin |             |
|                                                                         | patient	(45	kg,	167	cm).	There	is	a	definite	cutaneo-muscular	pallor.	BP:	100/60                                                                               |             |
| mmHg,	pulse:	105/min.	Palpation	of	the	abdomen	was	tender	throughout;	rectal                                                                         |                                                                               |             |
| examination is normal, but with blood on the palpating finger.          |                                                                               |             |
| Biological Tests                                                        |                                                                               |             |
| Hemoglobin:                                                             | 8.7	g/dL                                                                               | (N>12)      |
| MCV:                                                                    | 75	μ³                                                                               | (85-97)     |
| Leukocytes:                                                             | 6.5	×	10⁹/L                                                                               | (5-10	×	10⁹)             |
|                                                                         | of which 65% are polymorphonuclear neutrophils                                |             |
| PT:                                                                     | 95%                                                                           | (N>75)      |
| Platelets:                                                              | 550	×	10⁹/L                                                                               | (100-300	×	10⁹)             |
| Serum	iron:                                                                         | 5.0	μmol/L                                                                               | (10.7-26.9) |
| Siderophilin	saturation	coefficient:	15%                                                                         |                                                                               | (N=33)      |
| Parasitological examination of the stools and coproculture were normal. |                                                                               |             |

[OCR_TABLE]
Endc

[OCR]
Case 8

Medical History

Miss SIMON, 19 years of age, is suffering from bloody diarrhea which developed
over the past 2 months. She has no particular medical history. Treatment with
Smecta® and Imodium® did not result in any improvement.Pentasa® prescribed
by her attending physician was ineffective. Physical examination shows a thin
patient (45 kg, 167 cm). There is a definite cutaneo-muscular pallor. BP: 100/60
mmbg, pulse: 105/min. Palpation of the abdomen was tender throughout; rectal
examination is normal, but with blood on the palpating finger.

Biological Tests

Hemoglobin: 8.7 g/dL (N>12)
MCV: 75 y? (85-97)
Leukocytes: 6.5 x 109/L (5-10 x 10°)
of which 65% are polymorphonuclear neutrophils
PT: 95% (N>75)
Platelets: 550 x 109/L (100-300 x 109)
Serum iron: 5.0 mol/L (10.7-26.9)

Siderophilin saturation coefficient: 15%  (N=33)
Parasitological examination of the stools and coproculture were normal.

Anatomy Ulcerative colitis

surgical GI Mentor


# Page 12

Lower Gastrointestinal 
Endoscopy (Colonoscopy)
Second Module -
12
GI Mentor
Comments 
The lesions began 20 cm from the anus (the rectum and the rectosigmoid 
junction were normal). They extend into the cecum, with no interval of healthy 
mucosa.
This is a case of ulcerative colitis. The rectum is normal following enema of 
Pentasa®, which, due to its low volume, could progress no further than the 
rectum and the lower part of the sigmoid.
Biopsies of the colon (graduated), the rectum, and the terminal ileum should be 
performed for anatomical and pathological examination.
The mucosa of the ileum was normal; the appearance of the mucosa of the 
colon favors ulcerative colitis; there was no gigantocellular granuloma.
Treatment with Pentasa® 4 g/day, taken orally, and Tardyferon® was started.
The diarrhea and the rectorrhages decreased progressively and disappeared 
within 21 days. Maintenance treatment with Pentasa® 2 g/day was then 
initiated for an indeterminate period.
8
Case 8


[TABLE]
|                                                                               |
|:------------------------------------------------------------------------------|
| Case 8                                                                        |
| 8                                                                             |
| Comments                                                                      |
| The	lesions	began	20	cm	from	the	anus	(the	rectum	and	the	rectosigmoid                                                                               |
| junction	were	normal).	They	extend	into	the	cecum,	with	no	interval	of	healthy                                                                               |
| mucosa.                                                                       |
| This is a case of ulcerative colitis. The rectum is normal following enema of |
| Pentasa®, which, due to its low volume, could progress no further than the    |
| rectum and the lower part of the sigmoid.                                     |
| Biopsies	of	the	colon	(graduated),	the	rectum,	and	the	terminal	ileum	should	be                                                                               |
| performed for anatomical and pathological examination.                        |
| The mucosa of the ileum was normal; the appearance of the mucosa of the       |
| colon favors ulcerative colitis; there was no gigantocellular granuloma.      |
| Treatment	with	Pentasa®	4	g/day,	taken	orally,	and	Tardyferon®	was	started.                                                                               |
| The diarrhea and the rectorrhages decreased progressively and disappeared     |
| within	21	days.	Maintenance	treatment	with	Pentasa®	2	g/day	was	then                                                                               |
| initiated for an indeterminate period.                                        |

[OCR]
Case 8

Comments

The lesions began 20 cm from the anus (the rectum and the rectosigmoid
junction were normal). They extend into the cecum, with no interval of healthy
mucosa.

This is a case of ulcerative colitis. The rectum is normal following enema of
Pentasa®, which, due to its low volume, could progress no further than the
rectum and the lower part of the sigmoid.

Biopsies of the colon (graduated), the rectum, and the terminal ileum should be
performed for anatomical and pathological examination.

The mucosa of the ileum was normal; the appearance of the mucosa of the
colon favors ulcerative colitis; there was no gigantocellular granuloma.

Treatment with Pentasa® 4 g/day, taken orally, and Tardyferon® was started.

The diarrhea and the rectorrhages decreased progressively and disappeared
within 21 days. Maintenance treatment with Pentasa® 2 g/day was then
initiated for an indeterminate period.

surgical GI Mentor


# Page 13

Lower Gastrointestinal 
Endoscopy (Colonoscopy)
Second Module -
13
GI Mentor
9
Medical History 
Mr. MONET, 52 years of age, was hospitalized for severe general deterioration 
and weight loss of 8 kg in 1 month, a temperature of 39°C and bloody diarrhea 
with pain in the left iliac fossa. This patient has no previous medical history. He 
is a traveling salesman, and his last trip took place 6 weeks ago (Kenya, Mali).
He was vaccinated against yellow fever, cholera, and has been taking his  
anti-malarial prophylactic treatment with Savarine® during his stay in Africa 
and after his return. Physical examination shows a thin patient (61 kg, 185 
cm) with fever (38.5°C). Abdominal palpation shows tenderness of the 
left iliac fossa; rectal examination is normal. Plain films of the abdomen 
showed air distension of the small intestine, without pneumoperitoneum, and 
without dilation of the colon. Parasitological examination was negative and 
coproculture showed no pathogenic bacteria after 48 hours.
Biological Tests 
Hemoglobin: 
8.7 g/dL  
(N>14) 
MCV: 
 
79 μ³ 
 
(85-95) 
Leukocytes: 
12.7 × 10⁹/L 
(5-10 × 10⁹) 
 
 
of which 92% are polymorphonuclear neutrophils 
Platelets: 
450 × 10⁹/L 
(100-300 × 10⁹) 
ESR: 
 
90 mm/1 hour 
(N<30) 
A colonoscopy was performed without preparation or sedation, as well as 
graduated biopsies. No complication was observed following colonoscopy.
Case 9
Anatomy
Ulcerative colitis


[TABLE]
|                                                                               |                                                                                     |         |
|:------------------------------------------------------------------------------|:------------------------------------------------------------------------------------|:--------|
| 9                                                                             | Case 9                                                                              |         |
| Medical History                                                               |                                                                                     |         |
|                                                                               | Mr.	MONET,	52	years	of	age,	was	hospitalized	for	severe	general	deterioration                                                                                     |         |
|                                                                               | and	weight	loss	of	8	kg	in	1	month,	a	temperature	of	39°C	and	bloody	diarrhea                                                                                     |         |
|                                                                               | with pain in the left iliac fossa. This patient has no previous medical history. He |         |
|                                                                               | is	a	traveling	salesman,	and	his	last	trip	took	place	6	weeks	ago	(Kenya,	Mali).                                                                                     |         |
| He was vaccinated against yellow fever, cholera, and has been taking his      |                                                                                     |         |
| anti-malarial prophylactic treatment with Savarine® during his stay in Africa |                                                                                     |         |
| and	after	his	return.	Physical	examination	shows	a	thin	patient	(61	kg,	185                                                                               |                                                                                     |         |
| cm)	with	fever	(38.5°C).	Abdominal	palpation	shows	tenderness	of	the                                                                               |                                                                                     |         |
| left iliac fossa; rectal examination is normal. Plain films of the abdomen    |                                                                                     |         |
| showed air distension of the small intestine, without pneumoperitoneum, and   |                                                                                     |         |
| without dilation of the colon. Parasitological examination was negative and   |                                                                                     |         |
| coproculture	showed	no	pathogenic	bacteria	after	48	hours.                                                                               |                                                                                     |         |
| Biological Tests                                                              |                                                                                     |         |
| Hemoglobin:                                                                   | 8.7	g/dL                                                                                     | (N>14)  |
| MCV:                                                                          | 79	μ³                                                                                     | (85-95) |
| Leukocytes:                                                                   | 12.7	×	10⁹/L                                                                                     | (5-10	×	10⁹)         |
|                                                                               | of	which	92%	are	polymorphonuclear	neutrophils                                                                                     |         |
| Platelets:                                                                    | 450	×	10⁹/L                                                                                     | (100-300	×	10⁹)         |
| ESR:                                                                          | 90	mm/1	hour                                                                                     | (N<30)  |
|                                                                               | A colonoscopy was performed without preparation or sedation, as well as             |         |
|                                                                               | graduated	biopsies.	No	complication	was	observed	following	colonoscopy.                                                                                     |         |

[OCR]
Second Module -
Lower Gastrointestinal

Endoscopy (Colonoscopy) Wl

Case 9

Medical History

Mr. MONET, 52 years of age, was hospitalized for severe general deterioration
and weight loss of 8 kg in 1 month, a temperature of 39°C and bloody diarrhea
with pain in the left iliac fossa. This patient has no previous medical history. He
is a traveling salesman, and his last trip took place 6 weeks ago (Kenya, Mali).
He was vaccinated against yellow fever, cholera, and has been taking his
anti-malarial prophylactic treatment with Savarine® during his stay in Africa
and after his return. Physical examination shows a thin patient (61 kg, 185

cm) with fever (38.5°C). Abdominal palpation shows tenderness of the

left iliac fossa; rectal examination is normal. Plain films of the abdomen
showed air distension of the small intestine, without pneumoperitoneum, and
without dilation of the colon. Parasitological examination was negative and
coproculture showed no pathogenic bacteria after 48 hours.

Biological Tests

Hemoglobin: 8.7 g/dL (N>14)
MCV: 79 ys (85-95)
Leukocytes: 12.7 x 109/L (5-10 x 10°)
of which 92% are polymorphonuclear neutrophils
Platelets: 450 x 109/L (100-300 x 10°)
ESR: 90 mm/1 hour  (N<30)

A colonoscopy was performed without preparation or sedation, as well as
graduated biopsies. No complication was observed following colonoscopy.

Anatomy Ulcerative colitis

surgical GI Mentor


# Page 14

Lower Gastrointestinal 
Endoscopy (Colonoscopy)
Second Module -
14
GI Mentor
9
Case 9
Comments
Under total parenteral feeding and intravenous corticosteroid therapy, the 
patient’s clinical condition improved rapidly. A colonoscopy performed after 
10 days of treatment showed a very clear improvement of the lesions and the 
patient was discharged 2 weeks later with corticosteroid therapy (Cortancyl® 
50 mg/day) and Imurel® (Azathioprine 100 mg/day).
A follow-up examination was performed 3 months later, after stopping the 
corticosteroids; the colonoscopy was normal and hemoglobin 15.2 g/dL.


[TABLE]
| Second Module -                                                              |
|:-----------------------------------------------------------------------------|
| Lower Gastrointestinal                                                       |
| Endoscopy (Colonoscopy)                                                      |
| Case 9                                                                       |
| 9                                                                            |
| Comments                                                                     |
| Under total parenteral feeding and intravenous corticosteroid therapy, the   |
| patient’s clinical condition improved rapidly. A colonoscopy performed after |
| 10 days of treatment showed a very clear improvement of the lesions and the  |
| patient	was	discharged	2	weeks	later	with	corticosteroid	therapy	(Cortancyl®                                                                              |
| 50	mg/day)	and	Imurel®	(Azathioprine	100	mg/day).                                                                              |
| A follow-up examination was performed 3 months later, after stopping the     |
| corticosteroids;	the	colonoscopy	was	normal	and	hemoglobin	15.2	g/dL.                                                                              |
| 14                                                                           |
| GI Mentor                                                                    |

[OCR_TABLE]
Ende

[OCR]
Case 9

Comments

Under total parenteral feeding and intravenous corticosteroid therapy, the
patient’s clinical condition improved rapidly. A colonoscopy performed after
10 days of treatment showed a very clear improvement of the lesions and the
patient was discharged 2 weeks later with corticosteroid therapy (Cortancyl®
50 mg/day) and Imurel® (Azathioprine 100 mg/day).

A follow-up examination was performed 3 months later, after stopping the
corticosteroids; the colonoscopy was normal and hemoglobin 15.2 g/dL.

surgical GI Mentor


# Page 15

Lower Gastrointestinal 
Endoscopy (Colonoscopy)
Second Module -
15
GI Mentor
10
Medical History 
Mrs. RONAN, 43 years of age, suffered from diffuse abdominal pain associated 
with diarrhea composed of 5 to 8 stools per day, which developed over the 
past month. She lost 5 kg in 1 month (61 kg, 165 cm). Her temperature was 
37.8°C. The patient, who has 3 children, suffered from a severe pulmonary 
embolus after giving birth. She drinks no alcohol. Physical examination 
shows a patient in general good health. There is a rash of the polymorphic 
erythema type. Deep palpation of the left iliac fossa provokes a defense. Pelvic 
examinations are normal.
Biological Tests 
Hemoglobin:  
10.7 g/dL 
(N>12) 
ESR: 
 
95 mm  
(N<30) 
Leukocytes: 
12.5 × 10⁹/L 
(5-10 × 10⁹) 
 
 
with 87% polymorphonuclear neutrophils 
CRP: 
 
12 N 
Parasitological examination of the stools and coproculture were normal.
Comments 
Deep penetrating longitudinal ulcers running from the recto-sigmoid junction 
to the splenic flexure. Transverse and ascending colon were normal. Terminal 
ileum was normal. This was a severe form of Crohn’s disease. Treatment with 
oral corticosteroids (1 mg/kg/day) is indicated for a duration of 4 to 7 weeks. 
If the patient responds, a progressive reduction of the corticotherapy will be 
initiated. In case of complete response, it is not necessary to perform a follow-
up colonoscopy.
Case 10
Anatomy
Crohn’s disease


[TABLE]
|                          |                                                                                   |        |
|:-------------------------|:----------------------------------------------------------------------------------|:-------|
| 10                       | Case 10                                                                           |        |
| Medical History          |                                                                                   |        |
| Mrs.	RONAN,	43	years	of	age,	suffered	from	diffuse	abdominal	pain	associated                          |                                                                                   |        |
| with	diarrhea	composed	of	5	to	8	stools	per	day,	which	developed	over	the                          |                                                                                   |        |
| past	month.	She	lost	5	kg	in	1	month	(61	kg,	165	cm).	Her	temperature	was                          |                                                                                   |        |
|                          | 37.8°C.	The	patient,	who	has	3	children,	suffered	from	a	severe	pulmonary                                                                                   |        |
|                          | embolus after giving birth. She drinks no alcohol. Physical examination           |        |
|                          | shows a patient in general good health. There is a rash of the polymorphic        |        |
|                          | erythema type. Deep palpation of the left iliac fossa provokes a defense. Pelvic  |        |
| examinations are normal. |                                                                                   |        |
| Biological Tests         |                                                                                   |        |
| Hemoglobin:              | 10.7	g/dL                                                                                   | (N>12) |
| ESR:                     | 95	mm                                                                                   | (N<30) |
| Leukocytes:              | 12.5	×	10⁹/L                                                                                   | (5-10	×	10⁹)        |
|                          | with	87%	polymorphonuclear	neutrophils                                                                                   |        |
| CRP:                     | 12	N                                                                                   |        |
|                          | Parasitological examination of the stools and coproculture were normal.           |        |
| Comments                 |                                                                                   |        |
|                          | Deep penetrating longitudinal ulcers running from the recto-sigmoid junction      |        |
|                          | to the splenic flexure. Transverse and ascending colon were normal. Terminal      |        |
|                          | ileum was normal. This was a severe form of Crohn’s disease. Treatment with       |        |
|                          | oral	corticosteroids	(1	mg/kg/day)	is	indicated	for	a	duration	of	4	to	7	weeks.                                                                                   |        |
|                          | If the patient responds, a progressive reduction of the corticotherapy will be    |        |
|                          | initiated. In case of complete response, it is not necessary to perform a follow- |        |
| up colonoscopy.          |                                                                                   |        |
| Anatomy                  | Cr ohn’s disease                                                                  |        |

[OCR_TABLE]
Endc

[OCR]
Second Module -
Lower Gastrointestinal

Endoscopy (Colonoscopy) Wl

Case 10

Medical History
Mrs. RONAN, 43 years of age, suffered from diffuse abdominal pain associated
with diarrhea composed of 5 to 8 stools per day, which developed over the
past month. She lost 5 kg in 1 month (61 kg, 165 cm). Her temperature was
37.8°C. The patient, who has 3 children, suffered from a severe pulmonary
embolus after giving birth. She drinks no alcohol. Physical examination

shows a patient in general good health. There is a rash of the polymorphic
erythema type. Deep palpation of the left iliac fossa provokes a defense. Pelvic
examinations are normal.

Biological Tests
Hemoglobin: 10.7 g/dL (N>12)
ESR: 95 mm (N<30)
Leukocytes: 12.5 x 109/L (5-10 x 10°)

with 87% polymorphonuclear neutrophils
CRP: 12N
Parasitological examination of the stools and coproculture were normal.

Comments

Deep penetrating longitudinal ulcers running from the recto-sigmoid junction
to the splenic flexure. Transverse and ascending colon were normal. Terminal
ileum was normal. This was a severe form of Crohn's disease. Treatment with
oral corticosteroids (1 mg/kg/day) is indicated for a duration of 4 to 7 weeks.
If the patient responds, a progressive reduction of the corticotherapy will be
initiated. In case of complete response, it is not necessary to perform a follow-
up colonoscopy.

Anatomy Crohn’s disease

surgical GI Mentor