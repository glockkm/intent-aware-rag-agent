

# Page 1

Upper Gastrointestinal 
Endoscopy (Gastroscopy)
First Module -
1
GI Mentor
This module is intended for trainees who have just begun the “hands-on” 
phase of learning and training in Upper GI Endoscopy.
The module objectives are:
	
 Performing a complete survey of the Upper GI tract with a forward viewing 
video-endoscope.
	
 Performing diagnostic and therapeutic procedures in “patients” with major 
pathologies.
	
 Recognizing typical lesions.
	
 Performing basic therapeutic procedures.
The module consists of 10 cases. The cases are arranged hierarchically from a 
simple diagnostic procedure to a difficult case, involving all training objectives 
of this module.


[TABLE]
| Endoscopy (Gastroscopy)                                                            |
|:-----------------------------------------------------------------------------------|
| This module is intended for trainees who have just begun the “hands-on”            |
| phase of learning and training in Upper GI Endoscopy.                              |
| The module objectives are:                                                         |
|  Performing a complete survey of the Upper GI tract with a forward viewing                                                                                    |
| video-endoscope.                                                                   |
|  Performing diagnostic and therapeutic procedures in “patients” with major                                                                                    |
| pathologies.                                                                       |
|  Recognizing typical lesions.                                                                                    |
|  Performing basic therapeutic procedures.                                                                                    |
| The module consists of 10 cases. The cases are arranged hierarchically from a      |
| simple diagnostic procedure to a difficult case, involving all training objectives |
| of this module.                                                                    |

[OCR]
This module is intended for trainees who have just begun the “hands-on”
phase of learning and training in Upper GI Endoscopy.

The module objectives are:

= Performing a complete survey of the Upper GI tract with a forward viewing
video-endoscope.

Performing diagnostic and therapeutic procedures in “patients” with major
pathologies.

= Recognizing typical lesions.

= Performing basic therapeutic procedures.

The module consists of 10 cases. The cases are arranged hierarchically from a
simple diagnostic procedure to a difficult case, involving all training objectives
of this module.

surgical GI Mentor


# Page 2

Upper Gastrointestinal 
Endoscopy (Gastroscopy)
First Module -
2
GI Mentor
1
Anatomy: 
A normal upper GI tract with no findings.
Medical History: 
A 30-year-old male suffering from epigastric pain for the past 6 months. 
Physical examination does not show anything unusual. No response to 
omeprazole. 
He was referred for gastroscopy.
Biological Tests: 
Hgb: 
 
14 g/dL  
(12-18) 
Hct: 
 
48% 
 
(36-54) 
Alb: 
 
5.0 g/dL 
(3.5-5.5) 
Alk Phos: 
100 U/L  
(45-115) 
AST: 
 
26 U/L  
(0-35) 
ALT: 
 
30 U/L  
(6-45)
X-ray: 
Esophagus, stomach, duodenum, and proximal part of the jejunum are normal.
Take Home Message: 
Maneuvering the scope in a normal upper GI.
Anatomy
Normal tissue
Case 1 


[TABLE]
|                                                                            |                                                                          |           |
|:---------------------------------------------------------------------------|:-------------------------------------------------------------------------|:----------|
| 1                                                                          | Case 1                                                                   |           |
| Anatomy:                                                                   |                                                                          |           |
|                                                                            | A normal upper GI tract with no findings.                                |           |
| Medical History:                                                           |                                                                          |           |
|                                                                            | A 30-year-old male suffering from epigastric pain for the past 6 months. |           |
| Physical examination does not show anything unusual. No response to        |                                                                          |           |
| omeprazole.                                                                |                                                                          |           |
| He was referred for gastroscopy.                                           |                                                                          |           |
| Biological Tests:                                                          |                                                                          |           |
| Hgb:                                                                       | 14	g/dL                                                                          | (12-18)   |
| Hct:                                                                       | 48%                                                                      | (36-54)   |
| Alb:                                                                       | 5.0	g/dL                                                                          | (3.5-5.5) |
| Alk	Phos:                                                                            | 100	U/L                                                                          | (45-115)  |
| AST:                                                                       | 26	U/L                                                                          | (0-35)    |
| ALT:                                                                       | 30	U/L                                                                          | (6-45)    |
| X-ray:                                                                     |                                                                          |           |
| Esophagus, stomach, duodenum, and proximal part of the jejunum are normal. |                                                                          |           |
| Take Home Message:                                                         |                                                                          |           |
| Maneuvering the scope in a normal upper GI.                                |                                                                          |           |

[OCR_TABLE]
End

[OCR]
Case 1

Anatomy:
A normal upper Gl tract with no findings.

Medical History:

A 30-year-old male suffering from epigastric pain for the past 6 months.
Physical examination does not show anything unusual. No response to
omeprazole.

He was referred for gastroscopy.

Biological Tests:

Hgb: 14 g/dL (12-18)
Het: 48% (36-54)
Alb: 5.0 g/dL (3.5-5.5)
Alk Phos: 100 U/L (45-115)
AST: 26 U/L (0-35)
ALT: 30 U/L (6-45)
X-ray:

Esophagus, stomach, duodenum, and proximal part of the jejunum are normal.

Take Home Message:
Maneuvering the scope in a normal upper Gl.

Anatomy Normal tissue

surgical GI Mentor


# Page 3

Upper Gastrointestinal 
Endoscopy (Gastroscopy)
First Module -
3
GI Mentor
2
Anatomy: 
Diverticulum in the middle third of esophagus and hiatal hernia. No other 
findings.
Medical History: 
A 50-year-old female with occasional dysphagia. Weight is stable. 
She previously had esophageal manometry, which revealed diffused 
esophageal spasm. 
She was referred for gastroscopy.
Biological Tests: 
Hgb: 
12.5 g/dL 
(12-18) 
Hct: 
39% 
 
(36-54) 
Alb: 
4.9 g/dL 
(3.5-5.5) 
AST: 
23 U/L  
(0-35) 
ALT: 
18 U/L  
(6-45)
X-ray: 
In the middle third of the esophagus, there is a diverticulum filled with barium. 
The mucosa covering this diverticulum looks normal. The proximal part of the 
stomach is above the diaphragm with normal-looking mucosa. The rest of the 
stomach and duodenum are normal.
Take Home Message: 
Identify esophageal diverticula and hiatal hernia.
Case 2 
Anatomy
Diverticulum


[TABLE]
|                                                                                   |                                                                              |           |
|:----------------------------------------------------------------------------------|:-----------------------------------------------------------------------------|:----------|
| 2                                                                                 | Case 2                                                                       |           |
| Anatomy:                                                                          |                                                                              |           |
|                                                                                   | Diverticulum in the middle third of esophagus and hiatal hernia. No other    |           |
| findings.                                                                         |                                                                              |           |
| Medical History:                                                                  |                                                                              |           |
|                                                                                   | A	50-year-old	female	with	occasional	dysphagia.	Weight	is	stable.                                                                              |           |
|                                                                                   | She previously had esophageal manometry, which revealed diffused             |           |
| esophageal spasm.                                                                 |                                                                              |           |
| She was referred for gastroscopy.                                                 |                                                                              |           |
| Biological Tests:                                                                 |                                                                              |           |
| Hgb:                                                                              | 12.5	g/dL                                                                              | (12-18)   |
| Hct:                                                                              | 39%                                                                          | (36-54)   |
| Alb:                                                                              | 4.9	g/dL                                                                              | (3.5-5.5) |
| AST:                                                                              | 23	U/L                                                                              | (0-35)    |
| ALT:                                                                              | 18	U/L                                                                              | (6-45)    |
| X-ray:                                                                            |                                                                              |           |
| In the middle third of the esophagus, there is a diverticulum filled with barium. |                                                                              |           |
|                                                                                   | The mucosa covering this diverticulum looks normal. The proximal part of the |           |
|                                                                                   | stomach is above the diaphragm with normal-looking mucosa. The rest of the   |           |
|                                                                                   | stomach and duodenum are normal.                                             |           |
|                                                                                   | Take Home Message:                                                           |           |
|                                                                                   | Identify esophageal diverticula and hiatal hernia.                           |           |

[OCR]
Case 2

Anatomy:
Diverticulum in the middle third of esophagus and hiatal hernia. No other
findings.

Medical History:

A 50-year-old female with occasional dysphagia. Weight is stable.
She previously had esophageal manometry, which revealed diffused
esophageal spasm.

She was referred for gastroscopy.
Biological Tests:

Hgb: 12.5 g/dL (12-18)
Het: 39% (36-54)
Alb: 4.9 g/dL (3.5-5.5)
AST: 23 U/L (0-35)
ALT: 18 U/L (6-45)
X-ray:

n the middle third of the esophagus, there is a diverticulum filled with barium.
The mucosa covering this diverticulum looks normal. The proximal part of the
stomach is above the diaphragm with normal-looking mucosa. The rest of the
stomach and duodenum are normal.

Take Home Message:
Identify esophageal diverticula and hiatal hernia.

Anatomy Diverticulum

surgical GI Mentor


# Page 4

Upper Gastrointestinal 
Endoscopy (Gastroscopy)
First Module -
4
GI Mentor
3
Anatomy: 
J-shaped stomach, deformed duodenal bulb. No other findings.
Medical History: 
A 25-year-old female with transient dysphagia to solid and liquid food for the 
past 2 years. 
Occasionally, food will regurgitate, especially when lying down after a meal.
Esophageal manometry revealed non-specific motor abnormality. 
She was referred for gastroscopy.
Biological Tests: 
Hgb: 
12 g/dL  
(12-18) 
Hct: 
36% 
 
(36-54) 
Alb: 
4.7 g/dL  
(3.5-5.5) 
AST: 
31 U/L  
(0-35) 
ALT: 
37 U/L  
(6-45)
X-ray: 
The mucosa of the esophagus is normal with very impaired peristalsis. 
The stomach has the shape of a cascade with a deformity of the duodenal 
bulb. 
No active ulcer is seen in the duodenum.
Take Home Message: 
Moving through a difficult esophagus, stomach, and pylorus.
Case 3
Anatomy
Normal tissue


[TABLE]
|                                                                               |                                                                         |           |
|:------------------------------------------------------------------------------|:------------------------------------------------------------------------|:----------|
| 3                                                                             | Case 3                                                                  |           |
| Anatomy:                                                                      |                                                                         |           |
| J-shaped stomach, deformed duodenal bulb. No other findings.                  |                                                                         |           |
| Medical History:                                                              |                                                                         |           |
| A	25-year-old	female	with	transient	dysphagia	to	solid	and	liquid	food	for	the                                                                               |                                                                         |           |
| past	2	years.                                                                               |                                                                         |           |
| Occasionally, food will regurgitate, especially when lying down after a meal. |                                                                         |           |
| Esophageal manometry revealed non-specific motor abnormality.                 |                                                                         |           |
| She was referred for gastroscopy.                                             |                                                                         |           |
| Biological Tests:                                                             |                                                                         |           |
| Hgb:                                                                          | 12	g/dL                                                                         | (12-18)   |
| Hct:                                                                          | 36%                                                                     | (36-54)   |
| Alb:                                                                          | 4.7	g/dL                                                                         | (3.5-5.5) |
| AST:                                                                          | 31	U/L                                                                         | (0-35)    |
| ALT:                                                                          | 37	U/L                                                                         | (6-45)    |
| X-ray:                                                                        |                                                                         |           |
| The mucosa of the esophagus is normal with very impaired peristalsis.         |                                                                         |           |
|                                                                               | The stomach has the shape of a cascade with a deformity of the duodenal |           |
| bulb.                                                                         |                                                                         |           |
|                                                                               | No active ulcer is seen in the duodenum.                                |           |
|                                                                               | Take Home Message:                                                      |           |
|                                                                               | Moving through a difficult esophagus, stomach, and pylorus.             |           |

[OCR_TABLE]
Endc

[OCR]
Case 3

Anatomy:
J-shaped stomach, deformed duodenal bulb. No other findings.

Medical History:

A 25-year-old female with transient dysphagia to solid and liquid food for the
past 2 years.

Occasionally, food will regurgitate, especially when lying down after a meal.
Esophageal manometry revealed non-specific motor abnormality.

She was referred for gastroscopy.

Biological Tests:

Hgb: 12 g/dL (12-18)

Het: 36% (36-54)

Alb: 47 g/dl (3.5-5.5)

AST: 31 U/L (0-35)

ALT: 37 U/L (6-45)

X-ray:

The mucosa of the esophagus is normal with very impaired peristalsis.
The stomach has the shape of a cascade with a deformity of the duodenal

bulb.
No active ulcer is seen in the duodenum.

Take Home Message:
Moving through a difficult esophagus, stomach, and pylorus.

Anatomy Normal tissue

surgical GI Mentor


# Page 5

Upper Gastrointestinal 
Endoscopy (Gastroscopy)
First Module -
5
GI Mentor
4
Anatomy: 
Inflammation in the lower third of esophagus. Hiatal hernia. Duodenal ulcer.  
No other findings.
Medical History: 
A 54-year-old male complaining of epigastric pain and heartburn with radiation 
to the jaw. He was seen by a cardiologist, with no pathological findings.  
He smokes fifteen cigarettes per day. He responded well to therapy with 
proton pump inhibitors. He was referred for gastroscopy.
Biological Tests: 
Hgb: 
 
15 g/dL  
(12-18) 
Hct: 
 
47% 
 
(36-54) 
Alb: 
 
4.1 g/dL  
(3.5-5.5) 
Alk Phos: 
112 U/L  
(45-115) 
AST: 
 
28 U/L  
(0-35) 
ALT: 
 
16 U/L  
(6-45) 
Cholesterol: 
220 mg/dL 
(<200) 
Triglycerides: 
70 mg/dL 
(<160)
X-ray: 
There is reflux of barium from the stomach into the esophagus. 
A short segment of the proximal part of the stomach is above the diaphragm. 
The gastric mucosa looks normal. A crater filled with barium is seen in the 
duodenal bulb; the second part of the duodenum looks normal.
Take Home Message: 
Identify pathologies related to acid hypersecretion.
Case 4
Anatomy
Ulcer
Inflammation


[TABLE]
|                                                                              |                                                                             |           |                 |
|:-----------------------------------------------------------------------------|:----------------------------------------------------------------------------|:----------|:----------------|
| 4                                                                            | Case 4                                                                      |           |                 |
| Anatomy:                                                                     |                                                                             |           |                 |
| Inflammation in the lower third of esophagus. Hiatal hernia. Duodenal ulcer. |                                                                             |           |                 |
| No other findings.                                                           |                                                                             |           |                 |
| Medical History:                                                             |                                                                             |           |                 |
| A	54-year-old	male	complaining	of	epigastric	pain	and	heartburn	with	radiation                                                                              |                                                                             |           |                 |
| to the jaw. He was seen by a cardiologist, with no pathological findings.    |                                                                             |           |                 |
| He smokes fifteen cigarettes per day. He responded well to therapy with      |                                                                             |           |                 |
| proton pump inhibitors. He was referred for gastroscopy.                     |                                                                             |           |                 |
| Biological Tests:                                                            |                                                                             |           |                 |
| Hgb:                                                                         | 15	g/dL                                                                             | (12-18)   |                 |
| Hct:                                                                         | 47%                                                                         | (36-54)   |                 |
| Alb:                                                                         | 4.1	g/dL                                                                             | (3.5-5.5) |                 |
| Alk	Phos:                                                                              | 112	U/L                                                                             | (45-115)  |                 |
| AST:                                                                         | 28	U/L                                                                             | (0-35)    |                 |
| ALT:                                                                         | 16	U/L                                                                             | (6-45)    |                 |
| Cholesterol:                                                                 | 220	mg/dL                                                                             | (<200)    |                 |
| Triglycerides:                                                               | 70	mg/dL                                                                             | (<160)    |                 |
| X-ray:                                                                       |                                                                             |           |                 |
|                                                                              | There is reflux of barium from the stomach into the esophagus.              |           |                 |
|                                                                              | A short segment of the proximal part of the stomach is above the diaphragm. |           |                 |
|                                                                              | The gastric mucosa looks normal. A crater filled with barium is seen in the |           |                 |
|                                                                              | duodenal bulb; the second part of the duodenum looks normal.                |           |                 |
| Take Home Message:                                                           |                                                                             |           |                 |
|                                                                              | Identify pathologies related to acid hypersecretion.                        |           |                 |
| Anatomy                                                                      | Ulcer                                                                       |           | In fl ammat ion |

[OCR_TABLE]
Endo

[OCR]
First Module -
Upper Gastrointestinal
Endoscopy (Gastroscopy) I

Case 4

Anatomy:
Inflammation in the lower third of esophagus. Hiatal hernia. Duodenal ulcer.
No other findings.

Medical History:

A 54-year-old male complaining of epigastric pain and heartburn with radiation
to the jaw. He was seen by a cardiologist, with no pathological findings.

He smokes fifteen cigarettes per day. He responded well to therapy with
proton pump inhibitors. He was referred for gastroscopy.

Biological Tests:

Hgb: 15 g/dL 12-18)

Het: 47% 36-54)

Alb: 4.1 g/dL 3.5-5.5)

Alk Phos: 112 U/L 45-115)

AST: 28 U/L 0-35)

ALT: 16 U/L 6-45)

Cholesterol: 220 mg/dL <200)

Triglycerides: 70 mg/dL <160)

X-ray:

There is reflux of barium from the stomach into the esophagus.

A short segment of the proximal part of the stomach is above the diaphragm.
The gastric mucosa looks normal. A crater filled with barium is seen in the

duodenal bulb; the second part of the duodenum looks normal.

Take Home Message:
Identify pathologies related to acid hypersecretion.

Anatomy Ulcer Inflammation

surgical GI Mentor


# Page 6

Upper Gastrointestinal 
Endoscopy (Gastroscopy)
First Module -
6
GI Mentor
5
Anatomy: 
Esophagus with epiphrenic diverticulum. Stomach with tumor in antrum and 
sessile polyp in fundus.
Medical History: 
An 80-year-old male with a 10 kg weight loss during the past 4 months. He 
feels bloated following meals and once a day he has to vomit. He was referred 
for gastroscopy.
Biological Tests: 
Hgb: 
9.8 g/dL 
(12-18) 
Hct: 
32% 
 
(36-54) 
MCV: 
76 fl 
 
(86-98) 
MCH: 
24 pg/cell 
(28-33) 
Alb: 
3.5 g/dL 
(3.5-5.5)
X-ray: 
In the distal part of the esophagus next to the gastroesophageal junction, 
there is a diverticulum filled with barium. The mucosa is normal. The 
expansion of the stomach is impaired with a large space-occupying lesion in 
the antrum. There is an additional small lesion in the fundus. The duodenum 
looks normal.
Take Home Message: 
Training to perform a thorough examination. After the identification of a tumor 
in the antrum, retroflex is performed and a polyp is seen in the fundus of the 
stomach.
Case 5
Anatomy
Diverticulum
Sessile polyp
Tumor


[TABLE]
|                                                                                 |        |           |
|:--------------------------------------------------------------------------------|:-------|:----------|
| 5                                                                               | Case 5 |           |
| Anatomy:                                                                        |        |           |
| Esophagus with epiphrenic diverticulum. Stomach with tumor in antrum and        |        |           |
| sessile polyp in fundus.                                                        |        |           |
| Medical History:                                                                |        |           |
| An	80-year-old	male	with	a	10	kg	weight	loss	during	the	past	4	months.	He                                                                                 |        |           |
| feels bloated following meals and once a day he has to vomit. He was referred   |        |           |
| for gastroscopy.                                                                |        |           |
| Biological Tests:                                                               |        |           |
| Hgb:                                                                            | 9.8	g/dL        | (12-18)   |
| Hct:                                                                            | 32%    | (36-54)   |
| MCV:                                                                            | 76	fl        | (86-98)   |
| MCH:                                                                            | 24	pg/cell        | (28-33)   |
| Alb:                                                                            | 3.5	g/dL        | (3.5-5.5) |
| X-ray:                                                                          |        |           |
| In the distal part of the esophagus next to the gastroesophageal junction,      |        |           |
| there is a diverticulum filled with barium. The mucosa is normal. The           |        |           |
| expansion of the stomach is impaired with a large space-occupying lesion in     |        |           |
| the antrum. There is an additional small lesion in the fundus. The duodenum     |        |           |
| looks normal.                                                                   |        |           |
| Take Home Message:                                                              |        |           |
| Training to perform a thorough examination. After the identification of a tumor |        |           |
| in the antrum, retroflex is performed and a polyp is seen in the fundus of the  |        |           |
| stomach.                                                                        |        |           |

[OCR]
First Module -
Upper Gastrointestinal
Endoscopy (Gastroscopy) I

Case 5

Anatomy:
Esophagus with epiphrenic diverticulum. Stomach with tumor in antrum and
sessile polyp in fundus.

Medical History:

An 80-year-old male with a 10 kg weight loss during the past 4 months. He
feels bloated following meals and once a day he has to vomit. He was referred
for gastroscopy.

Biological Tests:

Hgb: 9.8 g/dL (12-18)
Het: 32% (36-54)
MCV: 76 fl (86-98)
MCH: 24 pg/cell (28-33)
Alb: 3.5 g/dL (3.5-5.5)
X-ray:

In the distal part of the esophagus next to the gastroesophageal junction,
there is a diverticulum filled with barium. The mucosa is normal. The
expansion of the stomach is impaired with a large space-occupying lesion in
the antrum. There is an additional small lesion in the fundus. The duodenum
looks normal.

Take Home Message:

Training to perform a thorough examination. After the identification of a tumor
in the antrum, retroflex is performed and a polyp is seen in the fundus of the
stomach.

Anatomy Diverticulum Sessile polyp Tumor

oo
_~
>

surgical GI Mentor


# Page 7

Upper Gastrointestinal 
Endoscopy (Gastroscopy)
First Module -
7
GI Mentor
6
Case 6
Anatomy
Bleeding ulcer
Varices
Anatomy: 
Varices in esophagus. J-shaped stomach with bleeding gastric ulcer in antrum.
Medical History: 
A 55-year-old female known to have chronic liver disease and cirrhosis due 
to viral Hepatitis C. She was admitted to the hospital because of upper GI 
bleeding. She was referred for gastroscopy.
Biological Tests: 
Hgb: 
8.5 g/dL 
(12-18) 
Hct: 
26% 
 
(36-54) 
Alb: 
2.8 g/dL 
(3.5-5.5) 
MCV: 
81 fl 
 
(86-98) 
MCH: 
34 pg/cell 
(28-33) 
AST: 
60 U/L  
(0-35) 
ALT: 
14 U/L  
(6-45)
X-ray: 
There are longitudinal filling defects in the distal part of the esophagus. The 
stomach has a normal mucosa except in the antrum where there is a disruption 
of the mucosa and the presence of a crater. The duodenal bulb looks normal.
Take Home Message: 
Perform a complete examination before starting therapy. Varices, which were 
seen at first, are not the site of bleeding. The bleeding is from a gastric ulcer, 
which should be treated.


[TABLE]
|                                                                                    |        |           |
|:-----------------------------------------------------------------------------------|:-------|:----------|
| 6                                                                                  | Case 6 |           |
| Anatomy:                                                                           |        |           |
| Varices in esophagus. J-shaped stomach with bleeding gastric ulcer in antrum.      |        |           |
| Medical History:                                                                   |        |           |
| A	55-year-old	female	known	to	have	chronic	liver	disease	and	cirrhosis	due                                                                                    |        |           |
| to viral Hepatitis C. She was admitted to the hospital because of upper GI         |        |           |
| bleeding. She was referred for gastroscopy.                                        |        |           |
| Biological Tests:                                                                  |        |           |
| Hgb:                                                                               | 8.5	g/dL        | (12-18)   |
| Hct:                                                                               | 26%    | (36-54)   |
| Alb:                                                                               | 2.8	g/dL        | (3.5-5.5) |
| MCV:                                                                               | 81	fl        | (86-98)   |
| MCH:                                                                               | 34	pg/cell        | (28-33)   |
| AST:                                                                               | 60	U/L        | (0-35)    |
| ALT:                                                                               | 14	U/L        | (6-45)    |
| X-ray:                                                                             |        |           |
| There are longitudinal filling defects in the distal part of the esophagus. The    |        |           |
| stomach has a normal mucosa except in the antrum where there is a disruption       |        |           |
| of the mucosa and the presence of a crater. The duodenal bulb looks normal.        |        |           |
| Take Home Message:                                                                 |        |           |
| Perform a complete examination before starting therapy. Varices, which were        |        |           |
| seen at first, are not the site of bleeding. The bleeding is from a gastric ulcer, |        |           |
| which should be treated.                                                           |        |           |

[OCR]
First Module -
Upper Gastrointestinal
Endoscopy (Gastroscopy) I

Case 6

Anatomy:
Varices in esophagus. J-shaped stomach with bleeding gastric ulcer in antrum.

Medical History:

A 55-year-old female known to have chronic liver disease and cirrhosis due
to viral Hepatitis C. She was admitted to the hospital because of upper Gl
bleeding. She was referred for gastroscopy.

Biological Tests:

Hgb: 8.5 g/dL (12-18)
Het: 26% (36-54)
Alb: 2.8 g/dL (3.5-5.5)
MCV: 81fl (86-98)
MCH: 34 pg/cell (28-33)
AST: 60 U/L (0-35)

LT: 14 U/L (6-45)

Al
X-ray:

There are longitudinal filling defects in the distal part of the esophagus. The
stomach has a normal mucosa except in the antrum where there is a disruption
of the mucosa and the presence of a crater. The duodenal bulb looks normal.

Take Home Message:

Perform a complete examination before starting therapy. Varices, which were
seen at first, are not the site of bleeding. The bleeding is from a gastric ulcer,
which should be treated.

Anatomy Bleeding ulcer Varices

surgical GI Mentor


# Page 8

Upper Gastrointestinal 
Endoscopy (Gastroscopy)
First Module -
8
GI Mentor
7
Anatomy: 
Esophagus with leiomyoma. Hiatal hernia. Pyloric stenosis (no passage to duodenum).
Medical History: 
A 50-year-old male with peptic ulcer disease for the past 20 years. Recently 
he has been experiencing fullness after consuming a small amount of food. He 
vomits once or twice a day, usually half an hour after having a meal. He was 
referred for gastroscopy.
Biological Tests: 
Hgb: 
 
14.8 g/dL 
(12-18) 
Hct: 
 
46% 
 
(36-54) 
Alb: 
 
4.2 g/dL 
(3.5-5.5) 
Alk Phos: 
89 U/L  
(45-115) 
AST: 
 
30 U/L  
(0-35) 
ALT: 
 
19 U/L  
(6-45)
X-ray: 
The esophagus looks normal except for a small filling defect in the middle part 
of the esophagus. There is slight reflux of barium from the stomach into the 
distal part of the esophagus. A small part of the proximal stomach is above the 
diaphragm. The stomach is enlarged with no passage of barium beyond the 
pylorus.
Take Home Message: 
Inability to pass to the duodenum because of pyloric stenosis, a careful search 
for other pathologies (like leiomyoma) should be performed.
Case 7
Anatomy
Leiomyoma


[TABLE]
|                                                                                     |                                                                                 |           |
|:------------------------------------------------------------------------------------|:--------------------------------------------------------------------------------|:----------|
| 7                                                                                   | Case 7                                                                          |           |
| Anatomy:                                                                            |                                                                                 |           |
| Esophagus with leiomyoma. Hiatal hernia. Pyloric stenosis (no passage to duodenum). |                                                                                 |           |
| Medical History:                                                                    |                                                                                 |           |
| A	50-year-old	male	with	peptic	ulcer	disease	for	the	past	20	years.	Recently                                                                                     |                                                                                 |           |
|                                                                                     | he has been experiencing fullness after consuming a small amount of food. He    |           |
|                                                                                     | vomits once or twice a day, usually half an hour after having a meal. He was    |           |
| referred for gastroscopy.                                                           |                                                                                 |           |
| Biological Tests:                                                                   |                                                                                 |           |
| Hgb:                                                                                | 14.8	g/dL                                                                                 | (12-18)   |
| Hct:                                                                                | 46%                                                                             | (36-54)   |
| Alb:                                                                                | 4.2	g/dL                                                                                 | (3.5-5.5) |
| Alk	Phos:                                                                                     | 89	U/L                                                                                 | (45-115)  |
| AST:                                                                                | 30	U/L                                                                                 | (0-35)    |
| ALT:                                                                                | 19	U/L                                                                                 | (6-45)    |
| X-ray:                                                                              |                                                                                 |           |
|                                                                                     | The esophagus looks normal except for a small filling defect in the middle part |           |
|                                                                                     | of the esophagus. There is slight reflux of barium from the stomach into the    |           |
|                                                                                     | distal part of the esophagus. A small part of the proximal stomach is above the |           |
|                                                                                     | diaphragm. The stomach is enlarged with no passage of barium beyond the         |           |
| pylorus.                                                                            |                                                                                 |           |
| Take Home Message:                                                                  |                                                                                 |           |
|                                                                                     | Inability to pass to the duodenum because of pyloric stenosis, a careful search |           |
|                                                                                     | for other pathologies (like leiomyoma) should be performed.                     |           |
| Anatomy                                                                             | Leiomyoma                                                                       |           |

[OCR_TABLE]
Endo

[OCR]
Case 7

Anatomy:
Esophagus with leiomyoma. Hiatal hernia. Pyloric stenosis (no passage to duodenum).

Medical History:

A 50-year-old male with peptic ulcer disease for the past 20 years. Recently
he has been experiencing fullness after consuming a small amount of food. He
vomits once or twice a day, usually half an hour after having a meal. He was
referred for gastroscopy.

Biological Tests:

Hgb: 14.8 g/dL (12-18)
Het: 46% (36-54)
Alb: 4.2 g/dL (3.5-5.5)
Alk Phos: 89 U/L (45-115)
AST: 30 U/L (0-35)
ALT: 19 U/L (6-45)
X-ray:

The esophagus looks normal except for a small filling defect in the middle part
of the esophagus. There is slight reflux of barium from the stomach into the
distal part of the esophagus. A small part of the proximal stomach is above the
diaphragm. The stomach is enlarged with no passage of barium beyond the
pylorus.

Take Home Message:
Inability to pass to the duodenum because of pyloric stenosis, a careful search
for other pathologies (like leiomyoma) should be performed.

Anatomy Leiomyoma

surgical GI Mentor


# Page 9

Upper Gastrointestinal 
Endoscopy (Gastroscopy)
First Module -
9
GI Mentor
8
Anatomy: 
Stomach with tumor in cardia.
Medical History: 
A 70-year-old female feeling weakness for the past 6 months. Blood tests 
reveal iron deficiency anemia. Colonoscopy was normal. She was referred for 
gastroscopy.
Biological Tests: 
Hgb: 
9.0 g/dL 
(12-18) 
Hct: 
30% 
 
(36-54) 
MCV: 
71 fl 
 
(86-98) 
MCH: 
24 pg/cell 
(28-33) 
Alb: 
2.3 g/dL 
(3.5-5.5)
X-ray: 
The esophagus is normal. The barium fills the stomach except for a small filling 
defect in the cardia, seen mainly when the patient is in the Trendelenburg 
position. The duodenum is normal.
Take Home Message: 
The importance of retroflexion is emphasized, since the tumor in the cardia can 
only be identified by retroflexion.
Case 8
Anatomy
Tumor


[TABLE]
|                                                                                  |        |           |
|:---------------------------------------------------------------------------------|:-------|:----------|
| 8                                                                                | Case 8 |           |
| Anatomy:                                                                         |        |           |
| Stomach with tumor in cardia.                                                    |        |           |
| Medical History:                                                                 |        |           |
| A 70-year-old female feeling weakness for the past 6 months. Blood tests         |        |           |
| reveal iron deficiency anemia. Colonoscopy was normal. She was referred for      |        |           |
| gastroscopy.                                                                     |        |           |
| Biological Tests:                                                                |        |           |
| Hgb:                                                                             | 9.0	g/dL        | (12-18)   |
| Hct:                                                                             | 30%    | (36-54)   |
| MCV:                                                                             | 71	fl        | (86-98)   |
| MCH:                                                                             | 24	pg/cell        | (28-33)   |
| Alb:                                                                             | 2.3	g/dL        | (3.5-5.5) |
| X-ray:                                                                           |        |           |
| The esophagus is normal. The barium fills the stomach except for a small filling |        |           |
| defect in the cardia, seen mainly when the patient is in the Trendelenburg       |        |           |
| position. The duodenum is normal.                                                |        |           |
| Take Home Message:                                                               |        |           |
| The importance of retroflexion is emphasized, since the tumor in the cardia can  |        |           |
| only be identified by retroflexion.                                              |        |           |

[OCR]
Case 8

Anatomy:
Stomach with tumor in cardia.

Medical History:

A 70-year-old female feeling weakness for the past 6 months. Blood tests
reveal iron deficiency anemia. Colonoscopy was normal. She was referred for
gastroscopy.

Biological Tests:

Hgb: 9.0 g/dL (12-18)
Het: 30% (36-54)
MCV: 71fl (86-98)
MCH: 24 pg/cell (28-33)
Alb: 2.3 g/dL (3.5-5.5)
X-ray:

The esophagus is normal. The barium fills the stomach except for a small filling
defect in the cardia, seen mainly when the patient is in the Trendelenburg
position. The duodenum is normal.

Take Home Message:
The importance of retroflexion is emphasized, since the tumor in the cardia can
only be identified by retroflexion.

Anatomy Tumor

surgical GI Mentor


# Page 10

Upper Gastrointestinal 
Endoscopy (Gastroscopy)
First Module -
10
GI Mentor
9
Anatomy: 
Esophagus with epiphrenic diverticulum. Polyp in antrum. J-shaped stomach. 
No other findings.
Medical History: 
A 50-year-old female with epigastric pain. She was referred for gastroscopy.
Biological Tests: 
Hgb: 
12.4 g/dL 
(12-18) 
Hct: 
36% 
 
(36-54) 
Alb: 
4.1 g/dL  
(3.5-5.5) 
AST: 
25 U/L  
(0-35) 
ALT: 
16 U/L  
(6-45)
X-ray: 
The esophagus looks normal except for the presence of a small diverticulum 
filled with barium. There is a small filling defect in the antrum in the shape of a 
pedunculated polyp. The duodenum looks normal.
Take Home Message: 
Resection and removal of polyp.
Case 9
Anatomy
Pedunculated polyp


[TABLE]
|                                                                                     |        |           |
|:------------------------------------------------------------------------------------|:-------|:----------|
| 9                                                                                   | Case 9 |           |
| Anatomy:                                                                            |        |           |
| Esophagus with epiphrenic diverticulum. Polyp in antrum. J-shaped stomach.          |        |           |
| No other findings.                                                                  |        |           |
| Medical History:                                                                    |        |           |
| A	50-year-old	female	with	epigastric	pain.	She	was	referred	for	gastroscopy.                                                                                     |        |           |
| Biological Tests:                                                                   |        |           |
| Hgb:                                                                                | 12.4	g/dL        | (12-18)   |
| Hct:                                                                                | 36%    | (36-54)   |
| Alb:                                                                                | 4.1	g/dL        | (3.5-5.5) |
| AST:                                                                                | 25	U/L        | (0-35)    |
| ALT:                                                                                | 16	U/L        | (6-45)    |
| X-ray:                                                                              |        |           |
| The esophagus looks normal except for the presence of a small diverticulum          |        |           |
| filled with barium. There is a small filling defect in the antrum in the shape of a |        |           |
| pedunculated polyp. The duodenum looks normal.                                      |        |           |
| Take Home Message:                                                                  |        |           |
| Resection and removal of polyp.                                                     |        |           |

[OCR]
Case 9

Anatomy:
Esophagus with epiphrenic diverticulum. Polyp in antrum. J-shaped stomach.
No other findings.

Medical History:
A 50-year-old female with epigastric pain. She was referred for gastroscopy.

Biological Tests:

Hgb: 2.4 g/dL (12-18)

Het: 36% (36-54)

Alb: 4.1 g/dL (3.5-5.5)

AST: 25 U/L (0-35)

ALT: 6 U/L (6-45)

X-ray:

The esophagus looks normal except for the presence of a small diverticulum
filled with barium. There is a small filling defect in the antrum in the shape of a
pedunculated polyp. The duodenum looks normal.

Take Home Message:
Resection and removal of polyp.

Anatomy Pedunculated polyp

surgical GI Mentor


# Page 11

Upper Gastrointestinal 
Endoscopy (Gastroscopy)
First Module -
11
GI Mentor
10
Anatomy: 
Diverticulum in the middle third of esophagus, Hiatal hernia, J-shaped 
stomach, AV malformation. Deformed duodenal bulb. Tumor of the papilla.
Medical History: 
A 75-year-old male with dysphagia and halitosis and a 7 kg weight-loss during 
the past 6 months. He was hospitalized because of pneumonia. He was treated 
with antibiotics and the fever subsided. In chest X-rays, there was evidence 
of emphysema and chronic obstructive pulmonary disease. A workup of 
dysphagia was initiated and he was referred for gastroscopy.
Biological Tests: 
Hgb: 
 
11.2 g/dL 
(12-18) 
Hct: 
 
35% 
 
(36-54) 
Alb: 
 
4.5 g/dL 
(3.5-5.5) 
Alk Phos: 
132 U/L  
(45-115)
X-ray: 
There is a small diverticulum filled with barium in the middle third of the 
esophagus. The proximal part of the stomach is above the diaphragm. The rest 
of the stomach is normal. There is deformity in the duodenal bulb but no ulcer 
is seen. In the second part of the duodenum there is a large filling defect next 
to the papilla.
Take Home Message: 
Clinical aspects of large esophageal diverticulum. Always perform a complete 
examination, looking for other pathologies.
Case 10
Anatomy
Diverticulum
AV malformation
Tumor


[TABLE]
|                                                                                  |         |           |
|:---------------------------------------------------------------------------------|:--------|:----------|
| 10                                                                               | Case 10 |           |
| Anatomy:                                                                         |         |           |
| Diverticulum in the middle third of esophagus, Hiatal hernia, J-shaped           |         |           |
| stomach, AV malformation. Deformed duodenal bulb. Tumor of the papilla.          |         |           |
| Medical History:                                                                 |         |           |
| A	75-year-old	male	with	dysphagia	and	halitosis	and	a	7	kg	weight-loss	during                                                                                  |         |           |
| the past 6 months. He was hospitalized because of pneumonia. He was treated      |         |           |
| with antibiotics and the fever subsided. In chest X-rays, there was evidence     |         |           |
| of emphysema and chronic obstructive pulmonary disease. A workup of              |         |           |
| dysphagia was initiated and he was referred for gastroscopy.                     |         |           |
| Biological Tests:                                                                |         |           |
| Hgb:                                                                             | 11.2	g/dL         | (12-18)   |
| Hct:                                                                             | 35%     | (36-54)   |
| Alb:                                                                             | 4.5	g/dL         | (3.5-5.5) |
| Alk	Phos:                                                                                  | 132	U/L         | (45-115)  |
| X-ray:                                                                           |         |           |
| There is a small diverticulum filled with barium in the middle third of the      |         |           |
| esophagus. The proximal part of the stomach is above the diaphragm. The rest     |         |           |
| of the stomach is normal. There is deformity in the duodenal bulb but no ulcer   |         |           |
| is seen. In the second part of the duodenum there is a large filling defect next |         |           |
| to the papilla.                                                                  |         |           |
| Take Home Message:                                                               |         |           |
| Clinical aspects of large esophageal diverticulum. Always perform a complete     |         |           |
| examination, looking for other pathologies.                                      |         |           |

[OCR_TABLE]
Endo

[OCR]
First Module -
Upper Gastrointestinal
Endoscopy (Gastroscopy) I

Case 10

Anatomy:
Diverticulum in the middle third of esophagus, Hiatal hernia, J-shaped
stomach, AV malformation. Deformed duodenal bulb. Tumor of the papilla.

Medical History:

A 75-year-old male with dysphagia and halitosis and a 7 kg weight-loss during
the past 6 months. He was hospitalized because of pneumonia. He was treated
with antibiotics and the fever subsided. In chest X-rays, there was evidence

of emphysema and chronic obstructive pulmonary disease. A workup of
dysphagia was initiated and he was referred for gastroscopy.

Biological Tests:

Hgb: 11.2 g/dL (12-18)
Het: 35% (36-54)
Alb: 4.5 g/dL (3.5-5.5)
Alk Phos: 132 U/L (45-115)
X-ray:

There is a small diverticulum filled with barium in the middle third of the
esophagus. The proximal part of the stomach is above the diaphragm. The rest
of the stomach is normal. There is deformity in the duodenal bulb but no ulcer
is seen. In the second part of the duodenum there is a large filling defect next
to the papilla.

Take Home Message:
Clinical aspects of large esophageal diverticulum. Always perform a complete
examination, looking for other pathologies.

Anatomy Diverticulum AV malformation Tumor

surgical GI Mentor