

# Page 1

Endoscopic Ultrasound (EUS)
Educational Module -
1
GI Mentor
The EUS Educational Module provides the opportunity for hands-
on practice of linear and radial EUS in an open environment.
This module offers:
	
 A high-end learning environment including real-time visualization of the 
Endoscopic view, External 3D map and the Ultrasound view.
	
 An open practice environment to study and rehearse EUS orientation and 
image recognition of over 30 different landmarks.
	
 Numerous on-screen optional visual aids and helpers to optimize the 
learning process.
	
 All landmarks incorporated in the EUS Tasks Module are available for 
training in an open environment. 
This Module was developed in collaboration with Dr. Marc Giovannini, Institut 
Paoli-Calmettes, Marseille, France. Dr. Darius Sorbi & Dr. David Fleischer, Mayo 
Clinic, Scottsdale, AZ, USA. Dr. Erwin Santo, Sourasky Medical Center, Tel-
Aviv, Israel. Dr. Yaakov Maor, Sheba Medical Center, Ramat-Gan, Israel. and 
Dr. Robert Hawes, MUSC, Charleston, SC, USA. Simbionix Ltd. (2003).


[TABLE]
| Endoscopic Ultrasound (EUS)                                    |
|:---------------------------------------------------------------|
| The EUS Educational Module provides the opportunity for hands- |
| on practice of linear and radial EUS in an open environment.   |
| This module offers:                                            |
|  A high-end learning environment including real-time visualization of the                                                                |
| Endoscopic view, External 3D map and the Ultrasound view.      |
|  An open practice environment to study and rehearse EUS orientation and                                                                |
| image recognition of over 30 different landmarks.              |
|  Numerous on-screen optional visual aids and helpers to optimize the                                                                |
| learning process.                                              |
|  All landmarks incorporated in the EUS Tasks Module are available for                                                                |
| training in an open environment.                               |

[OCR]
The EUS Educational Module provides the opportunity for hands-
on practice of linear and radial EUS in an open environment.

This module offers:

= A high-end learning environment including real-time visualization of the
Endoscopic view, External 3D map and the Ultrasound view.

= An open practice environment to study and rehearse EUS orientation and
image recognition of over 30 different landmarks.

= Numerous on-screen optional visual aids and helpers to optimize the
learning process.

= All landmarks incorporated in the EUS Tasks Module are available for
training in an open environment.

Filter

WEL FINISH

This Module was developed in collaboration with Dr. Marc Giovannini, Institut
Paoli-Calmettes, Marseille, France. Dr. Darius Sorbi & Dr. David Fleischer, Mayo
Clinic, Scottsdale, AZ, USA. Dr. Erwin Santo, Sourasky Medical Center, Tel-
Aviv, Israel. Dr. Yaakov Maor, Sheba Medical Center, Ramat-Gan, Israel. and
Dr. Robert Hawes, MUSC, Charleston, SC, USA. Simbionix Ltd. (2003).

surgical GI Mentor


# Page 2

Endoscopic Ultrasound (EUS)
Educational Module -
2
GI Mentor
This Module provides an open environment including the following 
features:
	
 Split screen for simultaneous views according to user’s choice.
	
 Flexible environment supporting switching between linear and radial EUS, 
flipping US direction, zooming, rotating 3D map and filtering the anatomical 
layers.
	
 Position and orientation of the US plane are dynamically displayed on the 
3D map.
	
 Automatic labeling on EUS view for anatomical structures identification.
	
 Coloring options on EUS view corresponding to the 3D map color index.
	
 Scope orientation instructions for each required landmark.
	
 Ultrasound image freeze allowing for caliper measurements, structure 
labeling by the user and saving images.


[TABLE]
| Educational Module -                                                         |
|:-----------------------------------------------------------------------------|
| Endoscopic Ultrasound (EUS)                                                  |
| This Module provides an open environment including the following             |
| features:                                                                    |
|  Split screen for simultaneous views according to user’s choice.                                                                              |
|  Flexible environment supporting switching between linear and radial EUS,                                                                              |
| flipping US direction, zooming, rotating 3D map and filtering the anatomical |
| layers.                                                                      |
|  Position and orientation of the US plane are dynamically displayed on the                                                                              |
| 3D map.                                                                      |
|  Automatic labeling on EUS view for anatomical structures identification.                                                                              |
|  Coloring options on EUS view corresponding to the 3D map color index.                                                                              |
|  Scope orientation instructions for each required landmark.                                                                              |
|  Ultrasound image freeze allowing for caliper measurements, structure                                                                              |
| labeling by the user and saving images.                                      |

[OCR]
This Module provides an open environment including the following
features:

= Split screen for simultaneous views according to user’s choice.

= Flexible environment supporting switching between linear and radial EUS,
flipping US direction, zooming, rotating 3D map and filtering the anatomical
layers.

= Position and orientation of the US plane are dynamically displayed on the
3D map.

= Automatic labeling on EUS view for anatomical structures identification.
= Coloring options on EUS view corresponding to the 3D map color index.
= Scope orientation instructions for each required landmark.

= Ultrasound image freeze allowing for caliper measurements, structure

labeling by the user and saving images.

FreeHand-Simulation

i

WELP FINISH

surgical GI Mentor