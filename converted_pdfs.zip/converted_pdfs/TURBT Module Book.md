

# Page 1

TURBT Proctor Book 
Overview 
This module provides hands-on training for clinical cases of transurethral 
resection of bladder tumors (TURBT). The cases simulate realistic scenarios 
involving tumors of varying sizes, shapes, and locations within the bladder.  
Accompanied by comprehensive educational aids, users can practice visualization 
of prostate and bladder anatomical landmarks, tumor resection and effective 
management of bleeding and irrigation.  
Unique Features: 
• 
Complete virtual patient environment with realistic anatomy 
• 
Virtual training for monopolar and bipolar resectoscopes 
• 
Different angled optics 
• 
Resection Assist educational aid with colored map visualization and 
planning of cutting regions 
• 
Progress bar tracking of percentage of pathology resected 
• 
Clear view mode – simulated environment enabled clearing view to help 
diagnose bleeding sources 
• 
On-screen warning and complication messages  
• 
Performance review provides feedback of safety measures and 
complication handling for post-procedure debriefing 
Acknowledgements 
This module was created in collaboration with: 
• 
Tiago Rodrigues, MD, PhD, Hospital Cruz Vermelha, Lisboa, Portugal 
• 
Ehud Gnessin, MD, Shamir Medical Center, Tel Aviv University, Israel 


[TABLE]
| TURBT Proctor Book                                                              |
|:--------------------------------------------------------------------------------|
| Overview                                                                        |
| This module provides hands-on training for clinical cases of transurethral      |
| resection of bladder tumors (TURBT). The cases simulate realistic scenarios     |
| involving tumors of varying sizes, shapes, and locations within the bladder.    |
| Accompanied by comprehensive educational aids, users can practice visualization |
| of prostate and bladder anatomical landmarks, tumor resection and effective     |
| management of bleeding and irrigation.                                          |
| Unique Features:                                                                |

[TABLE]
| management of bleeding and irrigation.   |                                                                       |
|:-----------------------------------------|:----------------------------------------------------------------------|
| Unique Features:                         |                                                                       |
| •                                        | Complete virtual patient environment with realistic anatomy           |
| •                                        | Virtual training for monopolar and bipolar resectoscopes              |
| •                                        | Different angled optics                                               |
| •                                        | Resection Assist educational aid with colored map visualization and   |
|                                          | planning of cutting regions                                           |
| •                                        | Progress bar tracking of percentage of pathology resected             |
| •                                        | Clear view mode – simulated environment enabled clearing view to help |
|                                          | diagnose bleeding sources                                             |
| •                                        | On-screen warning and complication messages                           |
| •                                        | Performance review provides feedback of safety measures and           |
|                                          | complication handling for post-procedure debriefing                   |

[OCR_TABLE]
| TURE

[OCR]
| TURBT Proctor Book

Overview

This module provides hands-on training for clinical cases of transurethral
resection of bladder tumors (TURBT). The cases simulate realistic scenarios
involving tumors of varying sizes, shapes, and locations within the bladder.

Accompanied by comprehensive educational aids, users can practice visualization
of prostate and bladder anatomical landmarks, tumor resection and effective
management of bleeding and irrigation.

Unique Features:

° Complete virtual patient environment with realistic anatomy

° Virtual training for monopolar and bipolar resectoscopes

° Different angled optics

° Resection Assist educational aid with colored map visualization and
planning of cutting regions

° Progress bar tracking of percentage of pathology resected

° Clear view mode — simulated environment enabled clearing view to help
diagnose bleeding sources

. On-screen warning and complication messages

° Performance review provides feedback of safety measures and

complication handling for post-procedure debriefing

Acknowledgements

This module was created in collaboration with:

. Tiago Rodrigues, MD, PhD, Hospital Cruz Vermelha, Lisboa, Portugal
. Ehud Gnessin, MD, Shamir Medical Center, Tel Aviv University, Israel

surgicalscience


# Page 2

TURBT Proctor Book 
 
 
Page 2 
 
Case Description 
Case 
Description 
Case 1  
Invasive papillary tumors: Right base, left lateral & 2 
small left posterolateral 
Case 2 
Non-invasive solid tumors: Right lateral & left lateral 
Case 3 
Invasive papillary tumors: Right lateral, posterior & left 
dome 
Case 4 
Invasive papillary tumor: Right base 
 
Module-Specific Hardware 
Device 
Physical Hardware 
Resectoscope 
 
 
Keyboard Shortcuts 
Shortcut Key 
Description 
CTRL+F 
Freeze the resectoscope location to enable a live 
screen view without the need to manually hold the 
scope 
 
 


[TABLE]
| Case Description   |      |                                                            |
|:-------------------|:-----|:-----------------------------------------------------------|
|                    | Case | Description                                                |
|                    |      | Invasive papillary tumors: Right base, left lateral & 2    |
| Case 1             |      |                                                            |
|                    |      | small left posterolateral                                  |
| Case 2             |      | Non-invasive solid tumors: Right lateral & left lateral    |
|                    |      | Invasive papillary tumors: Right lateral, posterior & left |
| Case 3             |      |                                                            |
|                    |      | dome                                                       |
| Case 4             |      | Invasive papillary tumor: Right base                       |

[OCR]
TURBT Proctor Book

Case Description

Case Description

Case 1 Invasive papillary tumors: Right base, left lateral & 2
small left posterolateral

Case 2 Non-invasive solid tumors: Right lateral & left lateral
Invasive papillary tumors: Right lateral, posterior & left

Case 3
dome

Case 4 Invasive papillary tumor: Right base

Module-Specific Hardware

Device

Physical Hardware

Resectoscope

Keyboard Shortcuts

Shortcut Key

Description

CTRL+F

Freeze the resectoscope location to enable a live
screen view without the need to manually hold the
scope

surgicalscience

Page 2


# Page 3

TURBT Proctor Book 
 
 
Page 3 
 
Performance Report 
Device 
Physical Hardware 
Time & Economy 
Procedure time 
Total procedure time, measured from scope 
entrance until exit from case (hh:mm:ss) 
Ergonomics 
Working angle 00 /120 / 300 
Percentage of time trainee worked with angle 
Educational Aids 
Percent time worked in Clear 
View mode 
Measures percentage of time the Clear View 
mode was turned on (%) 
Percent time worked with 
Resection Map mode 
Measures percentage of time Resection Map 
mode was turned on (%) 
Snapshots taken during 
procedure 
Presents the snapshots taken during the 
procedure  
Resection 
Total percentage of 
pathology removed 
Measures the percentage of tumor tissue 
resected (%) 
Resection during movement 
Measures the number of occurrences that 
resection was applied during scope movement 
(#) 
Active cutting towards the 
bladder wall 
Measures the number of occurrences that 
resection was done with loop movements in 
direction of the bladder wall (#) 
Percent of tumor resected 
Percentage of tissue resected per tumor (%) 
Tumor margin resected 
Indicates if the tumor margin was resected 
per tumor (Yes/No) 


[TABLE]
| Performance Report           |                                              |
|:-----------------------------|:---------------------------------------------|
| Device                       | Physical Hardware                            |
| Time & Economy               |                                              |
| Procedure time               | Total procedure time, measured from scope    |
|                              | entrance until exit from case (hh:mm:ss)     |
| Ergonomics                   |                                              |
| Working angle 00 /120 / 300  | Percentage of time trainee worked with angle |
| Educational Aids             |                                              |
| Percent time worked in Clear | Measures percentage of time the Clear View   |
| View mode                    | mode was turned on (%)                       |
| Percent time worked with     | Measures percentage of time Resection Map    |
| Resection Map mode           | mode was turned on (%)                       |
| Snapshots taken during       | Presents the snapshots taken during the      |
| procedure                    | procedure                                    |
| Resection                    |                                              |
| Total percentage of          | Measures the percentage of tumor tissue      |
| pathology removed            | resected (%)                                 |
| Resection during movement    | Measures the number of occurrences that      |
|                              | resection was applied during scope movement  |
|                              | (#)                                          |
| Active cutting towards the   | Measures the number of occurrences that      |
| bladder wall                 | resection was done with loop movements in    |
|                              | direction of the bladder wall (#)            |
| Percent of tumor resected    | Percentage of tissue resected per tumor (%)  |
| Tumor margin resected        | Indicates if the tumor margin was resected   |
|                              | per tumor (Yes/No)                           |

[OCR]
TURBT Proctor Book

Performance Report

Device

Physical Hardware

Time & Economy

Procedure time

Total procedure time, measured from scope
entrance until exit from case (hh:mm:ss)

Ergonomics

Working angle 0°/12°/ 30°

Percentage of time trainee worked with angle

Educational Aids

Percent time worked in Clear
View mode

Measures percentage of time the Clear View
mode was turned on (%)

Percent time worked with
Resection Map mode

Measures percentage of time Resection Map
mode was turned on (%)

Snapshots taken during
procedure

Presents the snapshots taken during the
procedure

Resection

Total percentage of
pathology removed

Measures the percentage of tumor tissue
resected (%)

Resection during movement

Measures the number of occurrences that
resection was applied during scope movement

(#)

Active cutting towards the
bladder wall

Measures the number of occurrences that
resection was done with loop movements in
direction of the bladder wall (#)

Percent of tumor resected

Percentage of tissue resected per tumor (%)

Tumor margin resected

Indicates if the tumor margin was resected
per tumor (Yes/No)

surgicalscience

Page 3


# Page 4

TURBT Proctor Book 
 
 
Page 4 
 
Bleeding Control 
Percent time worked in low 
visibility 
Measures the percentage of time during 
procedure trainee worked in low visibility (%) 
Time coagulation is applied 
without appropriate contact 
with the tissue 
Measures the total time coagulation is applied 
without contact with tissue (hh:mm:ss) 
Remaining bleeders  
Indicates if any bleeders remained open 
(Yes/No)  
Safety 
Cuts into ureteral orifices 
Measured the number of occurrences in 
which the trainee cuts into the ureteral 
orifices (#) 
Non-tumor bladder wall 
resections 
Presents the number of incidents the 
resectoscope cut in the bladder wall in a non-
tumor region (#) 
Bladder wall perforation 
Indicates if a bladder perforation occurred 
during procedure (Yes/No)  
Visualization 
Right urethral orifice 
Indicates if the right urethral orifice was 
visualized (Yes/No)  
Left urethral orifice 
Indicates if the left urethral orifice was 
visualized (Yes/No) 
Total path of camera  
Measures the total distance that was traveled 
with the camera during the procedure (cm) 
Bladder surface visualized 
Measures the percentage of bladder 
visualized during the procedure (%) 
 
 


[TABLE]
|                             | TURBT Proctor Book                             |
|:----------------------------|:-----------------------------------------------|
| Bleeding Control            |                                                |
| Percent time worked in low  | Measures the percentage of time during         |
| visibility                  | procedure trainee worked in low visibility (%) |
| Time coagulation is applied | Measures the total time coagulation is applied |
| without appropriate contact | without contact with tissue (hh:mm:ss)         |
| with the tissue             |                                                |
| Remaining bleeders          | Indicates if any bleeders remained open        |
|                             | (Yes/No)                                       |
| Safety                      |                                                |
| Cuts into ureteral orifices | Measured the number of occurrences in          |
|                             | which the trainee cuts into the ureteral       |
|                             | orifices (#)                                   |
| Non-tumor bladder wall      | Presents the number of incidents the           |
| resections                  | resectoscope cut in the bladder wall in a non- |
|                             | tumor region (#)                               |
| Bladder wall perforation    | Indicates if a bladder perforation occurred    |
|                             | during procedure (Yes/No)                      |
| Visualization               |                                                |
| Right urethral orifice      | Indicates if the right urethral orifice was    |
|                             | visualized (Yes/No)                            |
| Left urethral orifice       | Indicates if the left urethral orifice was     |
|                             | visualized (Yes/No)                            |
| Total path of camera        | Measures the total distance that was traveled  |
|                             | with the camera during the procedure (cm)      |
| Bladder surface visualized  | Measures the percentage of bladder             |
|                             | visualized during the procedure (%)            |

[OCR_TABLE]
visibility

[OCR]
TURBT Proctor Book

Bleeding Control

Percent time worked in low
visibility

Measures the percentage of time during
procedure trainee worked in low visibility (%)

Time coagulation is applied
without appropriate contact
with the tissue

Measures the total time coagulation is applied
without contact with tissue (hh:mm:ss)

Remaining bleeders

Indicates if any bleeders remained open
(Yes/No)

Safety

Cuts into ureteral orifices

Measured the number of occurrences in
which the trainee cuts into the ureteral
orifices (#)

Non-tumor bladder wall
resections

Presents the number of incidents the
resectoscope cut in the bladder wall in a non-
tumor region (#)

Bladder wall perforation

Indicates if a bladder perforation occurred
during procedure (Yes/No)

Visualization

Right urethral orifice

Indicates if the right urethral orifice was
visualized (Yes/No)

Left urethral orifice

Indicates if the left urethral orifice was
visualized (Yes/No)

Total path of camera

Measures the total distance that was traveled
with the camera during the procedure (cm)

Bladder surface visualized

Measures the percentage of bladder
visualized during the procedure (%)

surgicalscience

Page 4


# Page 5

TURBT Proctor Book 
 
 
Page 5 
 
Main Features and Controls 
Feature 
Button 
Description 
Patient file 
 
Review the case objectives 
Sound  
 
Mute the sound 
3D map 
 
Dynamic external view of the 
uterus and current position of 
the resectoscope during the 
procedure 
Screen Display 
Layout  
 
Choose full screen or split 
screen for the endoscopy view 
and external 3D view 
3D slicer 
 
Slice through the external view 
3D anatomy using a scroll bar 
Camera angle 
 
Selection of camera angle  
00, 120 or 300 
Tool selection 
 
 
Select monopolar or bipolar 
loop 
Resection Map  
 
Color height map indicating 
areas remained to resect  


[TABLE]
| Main Features and Controls   |        |                                |
|:-----------------------------|:-------|:-------------------------------|
| Feature                      | Button | Description                    |
| Patient file                 |        | Review the case objectives     |
| Sound                        |        | Mute the sound                 |
| 3D map                       |        | Dynamic external view of the   |
|                              |        | uterus and current position of |
|                              |        | the resectoscope during the    |
|                              |        | procedure                      |

[OCR]
TURBT Proctor Book

Main Features and Controls

Feature Button Description
Patient file | Review the case objectives
Sound Mute the sound
3D map Dynamic external view of the

uterus and current position of
the resectoscope during the
procedure

Screen Display Choose full screen or split

Layout screen for the endoscopy view
and external 3D view
3D slicer Slice through the external view

3D anatomy using a scroll bar

Selection of camera angle
0°, 12° or 30°

Camera angle

Select monopolar or bipolar
loop

Tool selection

Color height map indicating
areas remained to resect

Resection Map

surgicalscience Page 5


# Page 6

TURBT Proctor Book 
 
 
Page 6 
 
Resection 
Progress Bar 
  
Percent of tumor tissue 
resected 
Clear View  
 
Clear the view for helping 
diagnose bleeding sources 
 
 
 
 
 
 
 


[TABLE]
|              |                            | TURBT Proctor Book   |
|:-------------|:---------------------------|:---------------------|
| Resection    | Percent of tumor tissue    |                      |
| Progress Bar | resected                   |                      |
| Clear View   | Clear the view for helping |                      |
|              | diagnose bleeding sources  |                      |
|              |                            | Page 6               |

[OCR]
TURBT Proctor Book

Resection
Progress Bar

Percent of tumor tissue
resected

Clear View

+ 8
Fs

Clear the view for helping
diagnose bleeding sources

surgicalscience

Page 6