

# Page 1

Flexible Sigmoidoscopy
First Module -
1
GI Mentor
The Module has been developed to meet the growing need for training in 
flexible sigmoidoscopy.
The module objectives are to:
	
 Become familiar with flexible sigmoidoscopy and the indications for colon 
cancer screening
	
 Perform flexible sigmoidoscopy given difficult and unusual anatomies
	
 Recognize various common pathologies and perform biopsies as indicated
	
 Determine the appropriateness of flexible sigmoidoscopy for colon cancer 
screening in high-risk populations
	
 Make appropriate recommendations based on common endoscopic 
findings
The module consists of 10 cases which include all the above-indicated training 
objectives.
The cases were created in collaboration with Dr. Darius Sorbi and Dr. David 
Fleischer, Mayo Clinic, Scottsdale, AZ, USA.
Simbionix Ltd. (2002)


[TABLE]
| Flexible Sigmoidoscopy                                                         |
|:-------------------------------------------------------------------------------|
| The Module has been developed to meet the growing need for training in         |
| flexible sigmoidoscopy.                                                        |
| The module objectives are to:                                                  |
|  Become familiar with flexible sigmoidoscopy and the indications for colon                                                                                |
| cancer screening                                                               |
|  Perform flexible sigmoidoscopy given difficult and unusual anatomies                                                                                |
|  Recognize various common pathologies and perform biopsies as indicated                                                                                |
|  Determine the appropriateness of flexible sigmoidoscopy for colon cancer                                                                                |
| screening in high-risk populations                                             |
|  Make appropriate recommendations based on common endoscopic                                                                                |
| findings                                                                       |
| The module consists of 10 cases which include all the above-indicated training |
| objectives.                                                                    |
| The cases were created in collaboration with Dr. Darius Sorbi and Dr. David    |
| Fleischer, Mayo Clinic, Scottsdale, AZ, USA.                                   |
| Simbionix Ltd. (2002)                                                          |

[OCR]
First Module -
Flexible Sigmoidoscopy

The Module has been developed to meet the growing need for training in
flexible sigmoidoscopy.

The module objectives are to:

= Become familiar with flexible sigmoidoscopy and the indications for colon
cancer screening

= Perform flexible sigmoidoscopy given difficult and unusual anatomies
= Recognize various common pathologies and perform biopsies as indicated

= Determine the appropriateness of flexible sigmoidoscopy for colon cancer
screening in high-risk populations

= Make appropriate recommendations based on common endoscopic
findings

The module consists of 10 cases which include all the above-indicated training

objectives.

The cases were created in collaboration with Dr. Darius Sorbi and Dr. David
Fleischer, Mayo Clinic, Scottsdale, AZ, USA.

Simbionix Ltd. (2002)

surgical GI Mentor


# Page 2

Flexible Sigmoidoscopy
First Module -
2
GI Mentor
1
Anatomy: 
Normal anatomy with no pathology.
Medical History: 
A 60-year-old male with normal bowel habits referred for colon cancer 
screening. No family history of colon cancer.
Biological Tests: 
Hgb:	
14 g/dL	 (12-18) 
Hct:	
52%	
(36-54) 
Stool results for occult blood: Negative
Comments: 
Become familiar with flexible sigmoidoscopy and indications for colon 
cancer screening.
Anatomy
Case 1 


[TABLE]
|                                                                       |                  |
|:----------------------------------------------------------------------|:-----------------|
| 1                                                                     | Case 1           |
| Anatomy:                                                              |                  |
| Normal anatomy with no pathology.                                     |                  |
| Medical History:                                                      |                  |
| A 60-year-old male with normal bowel habits referred for colon cancer |                  |
| screening. No family history of colon cancer.                         |                  |
| Biological Tests:                                                     |                  |
| Hgb:                                                                  | 14 g/dL  (12-18) |
| Hct:                                                                  | 52%              |
|                                                                       | (36-54)          |
| Stool results for occult blood: Negative                              |                  |
| Comments:                                                             |                  |
| Become familiar with flexible sigmoidoscopy and indications for colon |                  |
| cancer screening.                                                     |                  |

[OCR]
First Module -
Flexible Sigmoidoscopy

Case 1

Anatomy:
Normal anatomy with no pathology.

Medical History:
A 60-year-old male with normal bowel habits referred for colon cancer
screening. No family history of colon cancer.

Biological Tests:

Hgb: 14 g/dL (12-18)

Het: 52% (36-54)

Stool results for occult blood: Negative

Comments:
Become familiar with flexible sigmoidoscopy and indications for colon
cancer screening.

Anatomy

surgical GI Mentor


# Page 3

Flexible Sigmoidoscopy
First Module -
3
GI Mentor
2
Anatomy: 
Redundant sigmoid colon with no pathology.
Medical History: 
A 75-year-old female with a long-standing history of constipation and laxative 
use referred for colon cancer screening. No family history of colon cancer. 
Barium X-ray to cecum performed two months prior to presentation, negative 
for polyps.
Biological Tests: 
Hgb:	
13.0 g/dL	
(12-18) 
Hct:	
39%	
	
(36-54) 
Alb:	
4.0 g/dL	
(3.5-5.5) 
TSH:	
2.0 mU/dL	
(0.2-3.0) 
Ca:	
10.0 mg/dL	
(9-10.5)
Comments: 
More difficult sigmoidoscopy in an elderly patient with a redundant sigmoid 
colon. Considering colonoscopy instead of flexible sigmoidoscopy and Barium 
X-ray for colon cancer screening.
Case 2 
Anatomy


[TABLE]
|                                                                             |                                                                                |           |
|:----------------------------------------------------------------------------|:-------------------------------------------------------------------------------|:----------|
| 2                                                                           | Case 2                                                                         |           |
| Anatomy:                                                                    |                                                                                |           |
|                                                                             | Redundant sigmoid colon with no pathology.                                     |           |
| Medical History:                                                            |                                                                                |           |
|                                                                             | A 75-year-old female with a long-standing history of constipation and laxative |           |
|                                                                             | use referred for colon cancer screening. No family history of colon cancer.    |           |
|                                                                             | Barium X-ray to cecum performed two months prior to presentation, negative     |           |
| for polyps.                                                                 |                                                                                |           |
| Biological Tests:                                                           |                                                                                |           |
| Hgb:                                                                        | 13.0 g/dL                                                                      | (12-18)   |
| Hct:                                                                        | 39%                                                                            | (36-54)   |
| Alb:                                                                        | 4.0 g/dL                                                                       | (3.5-5.5) |
| TSH:                                                                        | 2.0 mU/dL                                                                      | (0.2-3.0) |
| Ca:                                                                         | 10.0 mg/dL                                                                     | (9-10.5)  |
| Comments:                                                                   |                                                                                |           |
| More difficult sigmoidoscopy in an elderly patient with a redundant sigmoid |                                                                                |           |
| colon. Considering colonoscopy instead of flexible sigmoidoscopy and Barium |                                                                                |           |
| X-ray for colon cancer screening.                                           |                                                                                |           |

[OCR_TABLE]
A

[OCR]
First Module -
Flexible Sigmoidoscopy

Case 2

Anatomy:
Redundant sigmoid colon with no pathology.

Medical History:

A 75-year-old female with a long-standing history of constipation and laxative
use referred for colon cancer screening. No family history of colon cancer.
Barium X-ray to cecum performed two months prior to presentation, negative

for polyps.

Biological Tests:

Hgb: 13.0 g/dL (12-18)
Het: 39% (36-54)
Alb: 4.0 g/dL (3.5-5.5)
TSH: 2.0 mU/dL (0.2-3.0)
Ca: 10.0 mg/dL (9-10.5)
Comments:

More difficult sigmoidoscopy in an elderly patient with a redundant sigmoid
colon. Considering colonoscopy instead of flexible sigmoidoscopy and Barium
X-ray for colon cancer screening.

Anatomy

surgical GI Mentor


# Page 4

Flexible Sigmoidoscopy
First Module -
4
GI Mentor
3
Anatomy: 
Reversed splenic flexure and no pathology.
Medical History: 
A 45-year-old female referred for colon cancer screening. Family history 
significant for both parents and paternal grandfather having been diagnosed 
with colon cancer before the age of 50. Prior colonoscopy significant for a 
flat adenoma in the ascending colon.
Biological Tests: 
Hgb:	
12.1 g/dL	
(12-18) 
Hct:	
36%	
	
(36-54) 
Stool results for occult blood: Negative
Comments: 
More difficult sigmoidoscopy. Inappropriateness of flexible sigmoidoscopy 
for colon cancer screening in high-risk populations.
Case 3
Anatomy


[TABLE]
|                                                                             |           |         |
|:----------------------------------------------------------------------------|:----------|:--------|
| 3                                                                           | Case 3    |         |
| Anatomy:                                                                    |           |         |
| Reversed splenic flexure and no pathology.                                  |           |         |
| Medical History:                                                            |           |         |
| A 45-year-old female referred for colon cancer screening. Family history    |           |         |
| significant for both parents and paternal grandfather having been diagnosed |           |         |
| with colon cancer before the age of 50. Prior colonoscopy significant for a |           |         |
| flat adenoma in the ascending colon.                                        |           |         |
| Biological Tests:                                                           |           |         |
| Hgb:                                                                        | 12.1 g/dL | (12-18) |
| Hct:                                                                        | 36%       | (36-54) |
| Stool results for occult blood: Negative                                    |           |         |
| Comments:                                                                   |           |         |
| More difficult sigmoidoscopy. Inappropriateness of flexible sigmoidoscopy   |           |         |
| for colon cancer screening in high-risk populations.                        |           |         |

[OCR_TABLE]
rN

[OCR]
First Module -
Flexible Sigmoidoscopy

Case 3

Anatomy:
Reversed splenic flexure and no pathology.

Medical History:

A 45-year-old female referred for colon cancer screening. Family history
significant for both parents and paternal grandfather having been diagnosed
with colon cancer before the age of 50. Prior colonoscopy significant for a
flat adenoma in the ascending colon.

Biological Tests:

Hgb: 12.1. g/dL (12-18)

Het: 36% (36-54)

Stool results for occult blood: Negative

Comments:
More difficult sigmoidoscopy. Inappropriateness of flexible sigmoidoscopy
for colon cancer screening in high-risk populations.

Anatomy

surgical GI Mentor


# Page 5

Flexible Sigmoidoscopy
First Module -
5
GI Mentor
4
Anatomy: 
Normal anatomy. A sigmoid colon with few diverticula. Angiodysplasia in the 
descending colon and the sigmoid.
Medical History: 
A 72-year-old male with a history of irregular bowel habits for 30 years 
referred for the evaluation of rectal bleeding. No prior history of colon cancer 
screening.
Biological Tests: 
Hgb:	
10.9 g/dL	
(12-18) 
Hct:	
33%	
	
(36-54) 
Alb:	
4.5 g/dL	
(3.5-5.5) 
TSH:	
2.1 mU/dL	
(0.2-3.0) 
Stool results for occult blood: Negative
Comments: 
Difficult sigmoidoscopy in the presence of diverticulosis. Identifying potential 
sites of outlet bleeding. Inappropriateness of flexible sigmoidoscopy for the 
evaluation of elderly patients with hematochezia, anemia, and no prior colon 
cancer screening.
Case 4
Anatomy
Diverticulum
Angiodysplosio


[TABLE]
|                                                                                  |           |           |
|:---------------------------------------------------------------------------------|:----------|:----------|
| 4                                                                                | Case 4    |           |
| Anatomy:                                                                         |           |           |
| Normal anatomy. A sigmoid colon with few diverticula. Angiodysplasia in the      |           |           |
| descending colon and the sigmoid.                                                |           |           |
| Medical History:                                                                 |           |           |
| A 72-year-old male with a history of irregular bowel habits for 30 years         |           |           |
| referred for the evaluation of rectal bleeding. No prior history of colon cancer |           |           |
| screening.                                                                       |           |           |
| Biological Tests:                                                                |           |           |
| Hgb:                                                                             | 10.9 g/dL | (12-18)   |
| Hct:                                                                             | 33%       | (36-54)   |
| Alb:                                                                             | 4.5 g/dL  | (3.5-5.5) |
| TSH:                                                                             | 2.1 mU/dL | (0.2-3.0) |
| Stool results for occult blood: Negative                                         |           |           |
| Comments:                                                                        |           |           |
| Difficult sigmoidoscopy in the presence of diverticulosis. Identifying potential |           |           |
| sites of outlet bleeding. Inappropriateness of flexible sigmoidoscopy for the    |           |           |
| evaluation of elderly patients with hematochezia, anemia, and no prior colon     |           |           |
| cancer screening.                                                                |           |           |

[OCR]
Case 4

Anatomy:
Normal anatomy. A sigmoid colon with few diverticula. Angiodysplasia in the
descending colon and the sigmoid.

Medical History:
A 72-year-old male with a history of irregular bowel habits for 30 years
referred for the evaluation of rectal bleeding. No prior history of colon cancer

screening.

Biological Tests:

Hgb: 10.9 g/dL (12-18)
Het: 33% (36-54)
Alb: 4.5 g/dL (3.5-5.5)
TSH: = 2.1 mU/dL (0.2-3.0)

Stool results for occult blood: Negative

Comments:

Difficult sigmoidoscopy in the presence of diverticulosis. Identifying potential
sites of outlet bleeding. Inappropriateness of flexible sigmoidoscopy for the
evaluation of elderly patients with hematochezia, anemia, and no prior colon
cancer screening.

Anatomy Diverticulum Angiodysplosio

ri

surgicalscience GI Mentor


# Page 6

Flexible Sigmoidoscopy
First Module -
6
GI Mentor
5
Anatomy: 
Normal anatomy. A sigmoid colon with numerous diverticula. Internal 
hemorrhoids present.
Medical History: 
An 82-year-old male with a long-standing history of constipation referred for 
the evaluation of left lower quadrant abdominal pain.
Biological Tests: 
Hgb:	
14.1 g/dL	
(12-18) 
Hct:	
52%	
	
(36-54) 
Alb:	
4.0 g/dL	
(3.5-5.5) 
WBC:	
7.0 x 10⁹/L	
(4.0-10.8)
Comments: 
Difficult flexible sigmoidoscopy and increased risk of perforation in the 
presence of numerous diverticula.
Case 5
Anatomy
Hemorrhoids
Diverticula


[TABLE]
|                                                                               |                                                                           |            |
|:------------------------------------------------------------------------------|:--------------------------------------------------------------------------|:-----------|
| 5                                                                             | Case 5                                                                    |            |
| Anatomy:                                                                      |                                                                           |            |
| Normal anatomy. A sigmoid colon with numerous diverticula. Internal           |                                                                           |            |
| hemorrhoids present.                                                          |                                                                           |            |
| Medical History:                                                              |                                                                           |            |
| An 82-year-old male with a long-standing history of constipation referred for |                                                                           |            |
| the evaluation of left lower quadrant abdominal pain.                         |                                                                           |            |
| Biological Tests:                                                             |                                                                           |            |
| Hgb:                                                                          | 14.1 g/dL                                                                 | (12-18)    |
| Hct:                                                                          | 52%                                                                       | (36-54)    |
| Alb:                                                                          | 4.0 g/dL                                                                  | (3.5-5.5)  |
| WBC:                                                                          | 7.0 x 10⁹/L                                                               | (4.0-10.8) |
| Comments:                                                                     |                                                                           |            |
|                                                                               | Difficult flexible sigmoidoscopy and increased risk of perforation in the |            |
|                                                                               | presence of numerous diverticula.                                         |            |

[OCR]
Case 5

Anatomy:

Normal anatomy. A sigmoid colon with numerous diverticula. Internal
hemorrhoids present.

Medical History:

An 82-year-old male with a long-standing history of constipation referred for
he evaluation of left lower quadrant abdominal pain.

Biological Tests:

Hgb: 14.1 g/dL (12-18)
Het: 52% (36-54)
Alb: 4.0 g/dL (3.5-5.5)
WBC: 7.0 x 109/L (4.0-10.8)
Comments:

Difficult flexible sigmoidoscopy and increased risk of perforation in the
presence of numerous diverticula.

Anatomy Hemorrhoids Diverticula

+e

surgicalscience GI Mentor


# Page 7

Flexible Sigmoidoscopy
First Module -
7
GI Mentor
6
Case 6
Anatomy
Anatomy: 
Sharp angulation in the sigmoid colon and the splenic flexure. No pathology.
Medical History: 
A 60-year-old female with irregular bowel habits and diffuse abdominal pain 
relieved with defecation referred for flexible sigmoidoscopy. Past medical 
history significant for hysterectomy and open cholecystectomy.
Biological Tests: 
Hgb:	
12.8 g/dL	
(12-18) 
Hct:	
39%	
	
(36-54) 
Liver panel within normal limits 
Urinalysis within normal limits
Comments: 
Difficult flexible sigmoidoscopy in a patient with a prior history of abdominal 
surgery.


[TABLE]
|                                                                                 |           |         |
|:--------------------------------------------------------------------------------|:----------|:--------|
| 6                                                                               | Case 6    |         |
| Anatomy:                                                                        |           |         |
| Sharp angulation in the sigmoid colon and the splenic flexure. No pathology.    |           |         |
| Medical History:                                                                |           |         |
| A 60-year-old female with irregular bowel habits and diffuse abdominal pain     |           |         |
| relieved with defecation referred for flexible sigmoidoscopy. Past medical      |           |         |
| history significant for hysterectomy and open cholecystectomy.                  |           |         |
| Biological Tests:                                                               |           |         |
| Hgb:                                                                            | 12.8 g/dL | (12-18) |
| Hct:                                                                            | 39%       | (36-54) |
| Liver panel within normal limits                                                |           |         |
| Urinalysis within normal limits                                                 |           |         |
| Comments:                                                                       |           |         |
| Difficult flexible sigmoidoscopy in a patient with a prior history of abdominal |           |         |
| surgery.                                                                        |           |         |

[OCR]
First Module -
Flexible Sigmoidoscopy

Case 6

Anatomy:
Sharp angulation in the sigmoid colon and the splenic flexure. No pathology.

Medical History:

A 60-year-old female with irregular bowel habits and diffuse abdominal pain
relieved with defecation referred for flexible sigmoidoscopy. Past medical
history significant for hysterectomy and open cholecystectomy.

Biological Tests:

Hgb: 12.8 g/dL (12-18)
Het: 39% (36-54)
Liver panel within normal limits
Urinalysis within normal limits

Comments:
Difficult flexible sigmoidoscopy in a patient with a prior history of abdominal
surgery.

Anatomy

surgical GI Mentor


# Page 8

Flexible Sigmoidoscopy
First Module -
8
GI Mentor
7
Anatomy: 
A redundant sigmoid with extensive pseudomembranes and a few diverticula.
Medical History: 
A 58-year-old male with abdominal pain and diarrhea referred for flexible 
sigmoidoscopy. Recent history of pneumonia treated with antibiotics.
Biological Tests: 
Hgb:	
16.0 g/dL	
(12-16) 
Hct:	
48%	
	
(36-54) 
Alb:	
3.5 g/dL	
(3.5-5.5) 
TSH:	
1.9 mU/dL	
(0.2-3.0) 
Stool results for fecal leukocytes: Negative 
Stool results for pathogenic bacteria: Negative
Comments: 
Performing sigmoidoscopy in a difficult colon. Identifying pseudomembranes. 
Practicing biopsy for diarrhea.
Case 7
Anatomy
Pseudomembranes
Diverticulum


[TABLE]
|                                                                           |                                                                             |           |
|:--------------------------------------------------------------------------|:----------------------------------------------------------------------------|:----------|
| 7                                                                         | Case 7                                                                      |           |
| Anatomy:                                                                  |                                                                             |           |
| A redundant sigmoid with extensive pseudomembranes and a few diverticula. |                                                                             |           |
| Medical History:                                                          |                                                                             |           |
| A 58-year-old male with abdominal pain and diarrhea referred for flexible |                                                                             |           |
| sigmoidoscopy. Recent history of pneumonia treated with antibiotics.      |                                                                             |           |
| Biological Tests:                                                         |                                                                             |           |
| Hgb:                                                                      | 16.0 g/dL                                                                   | (12-16)   |
| Hct:                                                                      | 48%                                                                         | (36-54)   |
| Alb:                                                                      | 3.5 g/dL                                                                    | (3.5-5.5) |
| TSH:                                                                      | 1.9 mU/dL                                                                   | (0.2-3.0) |
|                                                                           | Stool results for fecal leukocytes: Negative                                |           |
|                                                                           | Stool results for pathogenic bacteria: Negative                             |           |
| Comments:                                                                 |                                                                             |           |
|                                                                           | Performing sigmoidoscopy in a difficult colon. Identifying pseudomembranes. |           |
|                                                                           | Practicing biopsy for diarrhea.                                             |           |

[OCR]
Case 7

Anatomy:
A redundant sigmoid with extensive pseudomembranes and a few diverticula.

Medical History:
A 58-year-old male with abdominal pain and diarrhea referred for flexible
sigmoidoscopy. Recent history of pneumonia treated with antibiotics.

Biological Tests:

Hgb: 16.0 g/dL (12-16)

Hct: 48% (36-54)
Alb: 3.5 g/dL (3.5-5.5)
TSH: 1.9 mU/dL (0.2-3.0)

Stool results for fecal leukocytes: Negative
Stool results for pathogenic bacteria: Negative

Comments:
Performing sigmoidoscopy in a difficult colon. Identifying pseudomembranes.
Practicing biopsy for diarrhea.

Anatomy Pseudomembranes_ Diverticulum

surgicalscience GI Mentor


# Page 9

Flexible Sigmoidoscopy
First Module -
9
GI Mentor
8
Anatomy: 
Normal anatomy. Sigmoid colon with a stricture. Descending colon with 
ulceration and pseudopolyps.
Medical History: 
A 36-year-old male with history of hematochezia and weight loss referred for 
flexible sigmoidoscopy.
Biological Tests: 
Hgb:	
	
	
9.8 g/dL	
(12-18) 
Hct:	
	
	
30%	
	
(36-54) 
Alb:	
	
	
3.1 g/dL		
(3.5-5.5) 
Serum B12:	
	
100 ng/L	
(200-700) 
Sedimentation rate:	
60 mm/h	
(0-30) 
WBC:	
	
	
12 x 10⁹/L	
(6-11)
Comments: 
Difficult sigmoidoscopy in a patient with inflammatory bowel disease.
Case 8
Anatomy
Ulceration and 
Pseudopolyps


[TABLE]
|                              |                                                                              |           |
|:-----------------------------|:-----------------------------------------------------------------------------|:----------|
| Case 8                       |                                                                              |           |
| 8                            |                                                                              |           |
| Anatomy:                     |                                                                              |           |
|                              | Normal anatomy. Sigmoid colon with a stricture. Descending colon with        |           |
| ulceration and pseudopolyps. |                                                                              |           |
| Medical History:             |                                                                              |           |
|                              | A 36-year-old male with history of hematochezia and weight loss referred for |           |
| flexible sigmoidoscopy.      |                                                                              |           |
| Biological Tests:            |                                                                              |           |
| Hgb:                         | 9.8 g/dL                                                                     | (12-18)   |
| Hct:                         | 30%                                                                          | (36-54)   |
| Alb:                         | 3.1 g/dL                                                                     | (3.5-5.5) |
| Serum B12:                   | 100 ng/L                                                                     | (200-700) |
| Sedimentation rate:          | 60 mm/h                                                                      | (0-30)    |
| WBC:                         | 12 x 10⁹/L                                                                   | (6-11)    |
| Comments:                    |                                                                              |           |
|                              | Difficult sigmoidoscopy in a patient with inflammatory bowel disease.        |           |

[OCR]
First Module -
Flexible Sigmoidoscopy

Case 8

Anatomy:
Normal anatomy. Sigmoid colon with a stricture. Descending colon with
ulceration and pseudopolyps.

Medical History:
A 36-year-old male with history of hematochezia and weight loss referred for
flexible sigmoidoscopy.

Biological Tests:

Hgb: 9.8 g/dL (12-18)
Het: 30% (36-54)
Alb: 3.1 g/dL (3.5-5.5)
Serum B12: 100 ng/L (200-700)
Sedimentation rate: 60 mm/h (0-30)
WBC: 12 x 109/L (6-11)
Comments:

Difficult sigmoidoscopy in a patient with inflammatory bowel disease.

Ulceration and
Anatomy Pseudopolyps

surgical GI Mentor


# Page 10

Flexible Sigmoidoscopy
First Module -
10
GI Mentor
9
Anatomy: 
Redundant sigmoid colon with a few diverticula and a few polyps.
Medical History: 
A 65-year-old male with a history of constipation for 30 years referred for 
colon cancer screening. No family history of colon cancer.
Biological Tests: 
Hgb:	
	
14 g/dL	 	
(12-18) 
Hct:	
	
52%	
	
(36-54) 
Stool results for occult blood: Negative
Comments: 
Performing sigmoidoscopy in a patient with redundant sigmoid. Identifying 
adenomatous polyps and making appropriate recommendations.
Case 9
Anatomy
Polyp
Diverticulum


[TABLE]
|                                                                             |                                                                           |         |
|:----------------------------------------------------------------------------|:--------------------------------------------------------------------------|:--------|
| 9                                                                           | Case 9                                                                    |         |
| Anatomy:                                                                    |                                                                           |         |
| Redundant sigmoid colon with a few diverticula and a few polyps.            |                                                                           |         |
| Medical History:                                                            |                                                                           |         |
| A 65-year-old male with a history of constipation for 30 years referred for |                                                                           |         |
| colon cancer screening. No family history of colon cancer.                  |                                                                           |         |
| Biological Tests:                                                           |                                                                           |         |
| Hgb:                                                                        | 14 g/dL                                                                   | (12-18) |
| Hct:                                                                        | 52%                                                                       | (36-54) |
|                                                                             | Stool results for occult blood: Negative                                  |         |
| Comments:                                                                   |                                                                           |         |
|                                                                             | Performing sigmoidoscopy in a patient with redundant sigmoid. Identifying |         |
|                                                                             | adenomatous polyps and making appropriate recommendations.                |         |

[OCR]
Case 9

Anatomy:
Redundant sigmoid colon with a few diverticula and a few polyps.

Medical History:
A 65-year-old male with a history of constipation for 30 years referred for
colon cancer screening. No family history of colon cancer.

Biological Tests:

Hgb: 14 g/dL (12-18)
Het: 52% (36-54)
Stool results for occult blood: Negative

Comments:
Performing sigmoidoscopy in a patient with redundant sigmoid. Identifying
adenomatous polyps and making appropriate recommendations.

Anatomy Polyp Diverticulum

surgicalscience GI Mentor


# Page 11

Flexible Sigmoidoscopy
First Module -
11
GI Mentor
10
Anatomy: 
Redundant sigmoid with a few diverticula, tumor, and rectal angiodysplasia.
Medical History: 
A 76-year-old male with a change in bowel habits. Last colonoscopy 12 years 
ago revealed multiple polyps. Medical history significant for prostate cancer for 
which he underwent radiation therapy several years ago.
Biological Tests: 
Hgb:	
9.8 g/dL	
(12-18) 
Hct:	
30%	
	
(36-54) 
Stool results for occult blood: Positive
X-ray: 
Barium fills the colon to mid sigmoid. Mass suspected.
Comments: 
Performing sigmoidoscopy in a patient with obstructing sigmoid cancer. 
Identify changes induced by radiation.
Case 10
Anatomy
Angiodysplosio
Diverticulum
Tumor


[TABLE]
|                                                                        |                                                                                   |         |
|:-----------------------------------------------------------------------|:----------------------------------------------------------------------------------|:--------|
| 10                                                                     | Case 10                                                                           |         |
| Anatomy:                                                               |                                                                                   |         |
|                                                                        | Redundant sigmoid with a few diverticula, tumor, and rectal angiodysplasia.       |         |
| Medical History:                                                       |                                                                                   |         |
|                                                                        | A 76-year-old male with a change in bowel habits. Last colonoscopy 12 years       |         |
|                                                                        | ago revealed multiple polyps. Medical history significant for prostate cancer for |         |
|                                                                        | which he underwent radiation therapy several years ago.                           |         |
| Biological Tests:                                                      |                                                                                   |         |
| Hgb:                                                                   | 9.8 g/dL                                                                          | (12-18) |
| Hct:                                                                   | 30%                                                                               | (36-54) |
| Stool results for occult blood: Positive                               |                                                                                   |         |
| X-ray:                                                                 |                                                                                   |         |
| Barium fills the colon to mid sigmoid. Mass suspected.                 |                                                                                   |         |
| Comments:                                                              |                                                                                   |         |
| Performing sigmoidoscopy in a patient with obstructing sigmoid cancer. |                                                                                   |         |
| Identify changes induced by radiation.                                 |                                                                                   |         |

[OCR]
Case 10

Anatomy:
Redundant sigmoid with a few diverticula, tumor, and rectal angiodysplasia.

Medical History:

A 76-year-old male with a change in bowel habits. Last colonoscopy 12 years
ago revealed multiple polyps. Medical history significant for prostate cancer for
which he underwent radiation therapy several years ago.

Biological Tests:

Hgb: 9.8 g/dL (12-18)

Het: 30% (36-54)
Stool results for occult blood: Positive

X-ray:
Barium fills the colon to mid sigmoid. Mass suspected.

Comments:
Performing sigmoidoscopy in a patient with obstructing sigmoid cancer.
Identify changes induced by radiation.

Anatomy Angiodysplosio Diverticulum Tumor

surgicalscience GI Mentor