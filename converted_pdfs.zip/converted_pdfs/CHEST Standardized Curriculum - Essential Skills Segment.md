

# Page 1

The CHEST Standardized Curriculum for Essential Bronchoscopic Skills and 
Diagnostic Bronchoscopy - Essential Skills Segment
Description
The CHEST Curriculum for the BRONCH Mentor is aimed at providing learners with the educational opportunity to 
learn and demonstrate fundamental bronchoscopic skills, as well as clinical knowledge and informed decision 
making. 
The Essential Skills segment of the curriculum provides designated skill tasks to accelerate the trainee's learning 
curve while acquiring and integrating fundamental bronchoscopic capabilities. 
This segment provides constructive and didactic training environments, aimed at improving hand-eye coordination 
and scope navigation, enhancing 3D cognitive perception and acquiring detailed anatomical knowledge of the 
bronchial tree.
Objectives
♦   To improve hand-eye coordination
♦   To acquire fundamental bronchoscope maneuvering capabilities
♦   To enhance 3D anatomical perception
♦  To perform a comprehensive, methodical,  bronchoscopic inspection
♦   To gain familiarity with bronchial anatomy and identify each bronchial segment by name
♦   To objectively assess one’s bronchoscopic skills level
♦   To objectively assess one’s knowledge of bronchial anatomy


[TABLE]
| The CHEST Standardized Curriculum for Essential Bronchoscopic Skills and                                            |
|:--------------------------------------------------------------------------------------------------------------------|
| Diagnostic Bronchoscopy - Essential Skills Segment                                                                  |
| Description                                                                                                         |
| The CHEST Curriculum for the BRONCH Mentor is aimed at providing learners with the educational opportunity to       |
| learn and demonstrate fundamental bronchoscopic skills, as well as clinical knowledge and informed decision         |
| making.                                                                                                             |
| The Essential Skills segment of the curriculum provides designated skill tasks to accelerate the trainee's learning |
| curve while acquiring and integrating fundamental bronchoscopic capabilities.                                       |
| This segment provides constructive and didactic training environments, aimed at improving hand-eye coordination     |
| and scope navigation, enhancing 3D cognitive perception and acquiring detailed anatomical knowledge of the          |
| bronchial tree.                                                                                                     |

[OCR]
The CHEST Standardized Curriculum for Essential Bronchoscopic Skills and
Diagnostic Bronchoscopy - Essential Skills Segment

Description

The CHEST Curriculum for the BRONCH Mentor is aimed at providing learners with the educational opportunity to
learn and demonstrate fundamental bronchoscopic skills, as well as clinical knowledge and informed decision
making.

The Essential Skills segment of the curriculum provides designated skill tasks to accelerate the trainee's learning
curve while acquiring and integrating fundamental bronchoscopic capabilities.

This segment provides constructive and didactic training environments, aimed at improving hand-eye coordination
and scope navigation, enhancing 3D cognitive perception and acquiring detailed anatomical knowledge of the
bronchial tree.

Objectives

¢ To improve hand-eye coordination

¢ To acquire fundamental bronchoscope maneuvering capabilities

¢ To enhance 3D anatomical perception

¢ To perform a comprehensive, methodical, bronchoscopic inspection

¢ To gain familiarity with bronchial anatomy and identify each bronchial segment by name
¢ To objectively assess one’s bronchoscopic skills level

¢ To objectively assess one’s knowledge of bronchial anatomy