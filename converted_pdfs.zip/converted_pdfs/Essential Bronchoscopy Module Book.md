

# Page 1

Essential Bronchoscopy Module
1
BRONCH Mentor
Introduction
The Essential Bronchoscopy module provides designated skill tasks, 
supporting focused acquisition of the necessary basic bronchoscopic 
capabilities.
The module provides a highly constructive and didactic training environment, 
aimed at improving hand-eye coordination and scope navigation, enhancing 
3D cognitive perception, acquiring and demonstrating detailed anatomical 
knowledge of the bronchial tree and adjoining anatomical structures, and 
practicing step-by-step tissue sampling maneuvers. 
The module consists of five essential skill tasks:
	
 Task 1 – Basic Scope Manipulation.
	
 Task 2 – Guided Anatomical Navigation.
	
 Task 3 – Lung Anatomy, Bronchial Segments.
	
 Task 4 – Lung Anatomy, Lymph Nodes.
	
 Task 5 – Step-by-Step Diagnostic Maneuvers.
 
Training in an individual focused manner helps accelerating the trainees’ 
learning curve while acquiring and integrating the desired skills. 
The captured performance metrics, uniquely defined for each task, turns this 
module into an objective assessment tool for bronchoscopy basic skills, with 
competency benchmark to be optionally set by the training facility.
This module was developed in conjunction with and endorsed  
by the American Association for Bronchology and Interventional 
Pulmonology – AABIP.
 


[TABLE]
| Introduction                                                                 |
|:-----------------------------------------------------------------------------|
| The Essential Bronchoscopy module provides designated skill tasks,           |
| supporting focused acquisition of the necessary basic bronchoscopic          |
| capabilities.                                                                |
| The module provides a highly constructive and didactic training environment, |
| aimed at improving hand-eye coordination and scope navigation, enhancing     |
| 3D cognitive perception, acquiring and demonstrating detailed anatomical     |
| knowledge of the bronchial tree and adjoining anatomical structures, and     |
| practicing step-by-step tissue sampling maneuvers.                           |
| The module consists of five essential skill tasks:                           |
|  Task 1 – Basic Scope Manipulation.                                                                              |
|  Task 2 – Guided Anatomical Navigation.                                                                              |
|  Task 3 – Lung Anatomy, Bronchial Segments.                                                                              |
|  Task 4 – Lung Anatomy, Lymph Nodes.                                                                              |
|  Task 5 – Step-by-Step Diagnostic Maneuvers.                                                                              |
| T                                                                            |
| raining in an individual focused manner helps accelerating the trainees’     |
| learning curve while acquiring and integrating the desired skills.           |
| The captured performance metrics, uniquely defined for each task, turns this |
| module into an objective assessment tool for bronchoscopy basic skills, with |
| competency benchmark to be optionally set by the training facility.          |
| This module was developed in conjunction with and endorsed                   |
| by the American Association for Bronchology and Interventional               |
| Pulmonology – AABIP.                                                         |

[OCR_TABLE]
_

[OCR]
Essential Bronchoscopy Module |

Introduction

The Essential Bronchoscopy module provides designated skill tasks,
supporting focused acquisition of the necessary basic bronchoscopic
capabilities.

The module provides a highly constructive and didactic training environment,
aimed at improving hand-eye coordination and scope navigation, enhancing
3D cognitive perception, acquiring and demonstrating detailed anatomical
knowledge of the bronchial tree and adjoining anatomical structures, and
racticing step-by-step tissue sampling maneuvers.

pI

The module consists of five essential skill tasks:
= Task 1- Basic Scope Manipulation.

= Task 2 - Guided Anatomical Navigation.

= Task 3 - Lung Anatomy, Bronchial Segments.

= Task 4-Lung Anatomy, Lymph Nodes.

= Task 5 - Step-by-Step Diagnostic Maneuvers.

Training in an individual focused manner helps accelerating the trainees’
learning curve while acquiring and integrating the desired skills.

The captured performance metrics, uniquely defined for each task, turns this
module into an objective assessment tool for bronchoscopy basic skills, with
competency benchmark to be optionally set by the training facility.

This module was developed in conjunction with and endorsed
by the American Association for Bronchology and Interventional
Pulmonology — AABIP.

surgical BRONCH Mentor


# Page 2

Essential Bronchoscopy Module
2
BRONCH Mentor
Educational Goals
	
 Practicing designated skill tasks in a focused manner, to accelerate the 
learning curve towards acquiring the essential cognitive and coordinative 
skills. 
	
 Practicing in a stressless educational environment, allowing for maximum 
focus, gradual and layered acquisition of skills and capabilities, and a 
positive learning experience.
	
 Developing skills and habits in a constructive and didactic environment, 
inherently offering the ability to objectively assess and improve oneself, and 
ultimately demonstrate advancement towards competency level.
Learning Objectives
	
 To improve hand-eye coordination.
	
 To acquire basic bronchoscope maneuvering capabilities.
	
 To enhance 3D anatomical perception.
	
 To perform a comprehensive, methodical, bronchoscopic inspection.
	
 To gain familiarity with bronchial anatomy and identify each bronchial 
segment by name.
	
 To gain familiarity with adjoining mediastinal, hilar, interlobar and lobar lymph 
node stations, under the IASLC map (2009).
	
 To practice the step-by-step performance of forceps biopsy, cytology 
brushing, and transbronchial needle aspiration.
	
 To objectively assess bronchoscopic skills level.
	
 To objectively assess knowledge of bronchial anatomy. 
	
 To objectively assess knowledge of lymph nodes location and classification 
(according to IASLC 2009).
	
 To objectively assess readiness to perform forceps biopsy, cytology 
brushing, and transbronchial needle aspiration.


[TABLE]
| Educational Goals                                                              |
|:-------------------------------------------------------------------------------|
|  Practicing designated skill tasks in a focused manner, to accelerate the                                                                                |
| learning curve towards acquiring the essential cognitive and coordinative      |
| skills.                                                                        |
|  Practicing in a stressless educational environment, allowing for maximum                                                                                |
| focus, gradual and layered acquisition of skills and capabilities, and a       |
| positive learning experience.                                                  |
|  Developing skills and habits in a constructive and didactic environment,                                                                                |
| inherently offering the ability to objectively assess and improve oneself, and |
| ultimately demonstrate advancement towards competency level.                   |

[OCR]
Essential Bronchoscopy Module |

Educational Goals

= Practicing designated skill tasks in a focused manner, to accelerate the
learning curve towards acquiring the essential cognitive and coordinative
skills.

= Practicing in a stressless educational environment, allowing for maximum
focus, gradual and layered acquisition of skills and capabilities, and a
positive learning experience.

= Developing skills and habits in a constructive and didactic environment,
inherently offering the ability to objectively assess and improve oneself, and
ultimately demonstrate advancement towards competency level.

Learning Objectives

= To improve hand-eye coordination.

= To acquire basic bronchoscope maneuvering capabilities.

= To enhance 3D anatomical perception.

= To perform a comprehensive, methodical, bronchoscopic inspection.

= To gain familiarity with bronchial anatomy and identify each bronchial
segment by name.

= To gain familiarity with adjoining mediastinal, hilar, interlobar and lobar lymph
node stations, under the IASLC map (2009).

= To practice the step-by-step performance of forceps biopsy, cytology
brushing, and transbronchial needle aspiration.

= To objectively assess bronchoscopic skills level.
= To objectively assess knowledge of bronchial anatomy.

= To objectively assess knowledge of lymph nodes location and classification
(according to IASLC 2009).

= To objectively assess readiness to perform forceps biopsy, cytology
brushing, and transbronchial needle aspiration.

surgical BRONCH Mentor


# Page 3

Essential Bronchoscopy Module
3
BRONCH Mentor
General Screen Layout and Features
  
Note: The above screen layout applies to Tasks 2, 3, 4 and 5. Task 1 which is 
performed in a non-anatomical environment, displays a different layout (see 
Task 1– Basic Scope Manipulation).
1 - Main View
	
 Displaying the scope’s video.
	
 Helpers, indicators and controls, varying per task, are displayed over the 
main view. 
	
 Elapsed time is indicated in the upper right corner.
	
 This module does not support Full Screen view.
2 - Main view controls
The main view controls turn on or off helpers and simulation features and may 
vary per task with the most common ones being:
	
 Compass - dynamically displays over the main view an anatomical compass 
indicating body coordinates (Anterior, Posterior, Left and Right).
	
 Labels - display the bronchial segments labels over the main view. Two 
labeling conventions are available: descriptive-numeric and advanced-
numeric which label the sub-segments one level deeper within the lungs.
	
 Stop Breathing - stops the virtual patient’s breathing, allowing for easier 
performance of the required maneuvers.
1
3
7
4
4
5
6
2


[TABLE]
| Essential Bronchoscopy Module                                                 |
|:------------------------------------------------------------------------------|
| General Screen Layout and Features                                            |
| 2                                                                             |
| 1                                                                             |
| 4                                                                             |
| 6                                                                             |
| 4                                                                             |
| 5                                                                             |
| 3                                                                             |
| 7                                                                             |
| Note: The above screen layout applies to Tasks 2, 3, 4 and 5. Task 1 which is |
| performed in a non-anatomical environment, displays a different layout (see   |
| Task 1– Basic Scope Manipulation).                                            |
| 1 - Main View                                                                 |
|  Displaying the scope’s video.                                                                               |
|  Helpers, indicators and controls, varying per task, are displayed over the                                                                               |
| main view.                                                                    |
|  Elapsed time is indicated in the upper right corner.                                                                               |
|  This module does not support Full Screen view.                                                                               |
| 2 - Main view controls                                                        |
| The main view controls turn on or off helpers and simulation features and may |
| vary per task with the most common ones being:                                |
|  Compass - dynamically displays over the main view an anatomical compass                                                                               |
| indicating body coordinates (Anterior, Posterior, Left and Right).            |
|  Labels - display the bronchial segments labels over the main view. Two                                                                               |
| labeling conventions are available: descriptive-numeric and advanced-         |
| numeric which label the sub-segments one level deeper within the lungs.       |
|  Stop Breathing - stops the virtual patient’s breathing, allowing for easier                                                                               |
| performance of the required maneuvers.                                        |
| 3                                                                             |
| BRONCH Mentor                                                                 |

[OCR]
Essential Bronchoscopy Module

General Screen Layout and Features

Note: The above screen layout applies to Tasks 2, 3, 4 and 5. Task 1 which is
performed in a non-anatomical environment, displays a different layout (see
Task 1- Basic Scope Manipulation).

1- Main View
= Displaying the scope’s video.

= Helpers, indicators and controls, varying per task, are displayed over the
main view.

= Elapsed time is indicated in the upper right corner.
= This module does not support Full Screen view.
2 - Main view controls

The main view controls turn on or off helpers and simulation features and may
vary per task with the most common ones being:

= Compass - dynamically displays over the main view an anatomical compass
indicating body coordinates (Anterior, Posterior, Left and Right).

= Labels - display the bronchial segments labels over the main view. Two
labeling conventions are available: descriptive-numeric and advanced-
numeric which label the sub-segments one level deeper within the lungs.

= Stop Breathing - stops the virtual patient’s breathing, allowing for easier
performance of the required maneuvers.

surgicalscience BRONCH Mentor


# Page 4

Essential Bronchoscopy Module
4
BRONCH Mentor
3 - Patient Management Region
Since this module focuses on acquiring basic skills and capabilities, patient 
management is not part of this module.
4 - Complementary displays 
These two panes present displays complementing the main view. Available 
controls are located to the right of the display:
	
 Upper pane, 3D-Map – an external dynamic 3D visualization of the scope 
within the bronchial tree. Controls such as zoom, pan, rotate and more are 
available to its right.
	
 Lower pane, Instructions – instructions relevant for the task performance. 
Note: Additional complementary displays may be displayed over the default 
ones during task performance.
5 - Virtual instructor 
The Virtual Instructor provides real-time warnings, comments, and tips 
regarding procedure performance.  In this module, it applies only to Task 5 - 
Step-by-Step Diagnostic Maneuvers.
6 - Tool panel
Note: Tools are active only for Task 5 - Step-by-Step Diagnostic Maneuvers.
The master tool is used to simulate all diagnostic tools.
Following the master tool insertion into the scope’s working channel and menu 
selection of the desired endoscopic tool, the simulated tool appears inside the 
anatomy and its tool panel is displayed.
Note: The syringe is not used in this module.
 


[TABLE]
| Essential Bronchoscopy Module                                                   |
|:--------------------------------------------------------------------------------|
| 3 - Patient Management Region                                                   |
| Since this module focuses on acquiring basic skills and capabilities, patient   |
| management is not part of this module.                                          |
| 4 - Complementary displays                                                      |
| These two panes present displays complementing the main view. Available         |
| controls are located to the right of the display:                               |
|  Upper pane, 3D-Map – an external dynamic 3D visualization of the scope                                                                                 |
| within the bronchial tree. Controls such as zoom, pan, rotate and more are      |
| available to its right.                                                         |
|  Lower pane, Instructions – instructions relevant for the task performance.                                                                                 |
| Note: Additional complementary displays may be displayed over the default       |
| ones during task performance.                                                   |
| 5 - Virtual instructor                                                          |
| The Virtual Instructor provides real-time warnings, comments, and tips          |
| regarding procedure performance.  In this module, it applies only to Task 5 -   |
| Step-by-Step Diagnostic Maneuvers.                                              |
| 6 - Tool panel                                                                  |
| Note: Tools are active only for Task 5 - Step-by-Step Diagnostic Maneuvers.     |
| The master tool is used to simulate all diagnostic tools.                       |
| Following the master tool insertion into the scope’s working channel and menu   |
| selection of the desired endoscopic tool, the simulated tool appears inside the |
| anatomy and its tool panel is displayed.                                        |
| Note: The syringe is not used in this module.                                   |

[OCR]
Essential Bronchoscopy Module |

3 - Patient Management Region

Since this module focuses on acquiring basic skills and capabilities, patient
management is not part of this module.

4 - Complementary displays

These two panes present displays complementing the main view. Available
controls are located to the right of the display:

= Upper pane, 3D-Map — an external dynamic 3D visualization of the scope
within the bronchial tree. Controls such as zoom, pan, rotate and more are
available to its right.

= Lower pane, Instructions — instructions relevant for the task performance.

Note: Additional complementary displays may be displayed over the default
ones during task performance.

5 - Virtual instructor

The Virtual Instructor provides real-time warnings, comments, and tips
regarding procedure performance. In this module, it applies only to Task 5 -
Step-by-Step Diagnostic Maneuvers.

6 - Tool panel
Note: Tools are active only for Task 5 - Step-by-Step Diagnostic Maneuvers.
The master tool is used to simulate all diagnostic tools.

Following the master tool insertion into the scope’s working channel and menu
selection of the desired endoscopic tool, the simulated tool appears inside the
anatomy and its tool panel is displayed.

Note: The syringe is not used in this module.

surgical BRONCH Mentor


# Page 5

Essential Bronchoscopy Module
5
BRONCH Mentor
The Forceps, Brush and Needle tool 
panels (1, 2 and 3) display the tools’ states 
and options. All three allow for virtual 
activation, overpowering the master tool 
handle to facilitate easier solo training. 
Note: Virtual tool activation can be 
controlled via touch screen, foot switch, or 
scope buttons.
The tool panels indicate whether Virtual 
Activation is on, what is the current tool 
state, and provide additional control 
options when applicable.
The Needle tool panel (3) displays the 
following additional controls:
Lock locks the needle out of its sheath. 
It is performed via the touch screen and 
is a mandatory step in simulated TBNA 
performance.
1
2
3
Note: The Lock button is enabled only when the needle is pushed completely 
out of its sheath.
Secure Proximally simulates manually holding together the proximal portion of 
the needle’s sheath in the working channel, allowing for advancing the scope 
and needle as one unit.
Suction is performed by pulling the actual syringe piston open to Aspirate and 
pushing it close to Release. Applying suction is a mandatory step in simulated 
TBNA performance.
7 - General Buttons
	
 Mute button toggles the sound on and off.
	
 Case File button opens the current Task case file.
	
 Help button opens the online help (availability is per software version).
	
 Finish button ends the current simulation, allowing for saving its 
performance metrics. 


[TABLE]
| 1   | 3   |                                               |
|:----|:----|:----------------------------------------------|
|     |     | The Forceps, Brush and Needle tool            |
|     |     | panels (1, 2 and 3) display the tools’ states |
|     |     | and options. All three allow for virtual      |
|     |     | activation, overpowering the master tool      |
|     |     | handle to facilitate easier solo training.    |
|     |     | Note: Virtual tool activation can be          |
|     |     | controlled via touch screen, foot switch, or  |
|     |     | scope buttons.                                |
| 2   |     |                                               |
|     |     | The tool panels indicate whether Virtual      |
|     |     | Activation is on, what is the current tool    |
|     |     | state, and provide additional control         |
|     |     | options when applicable.                      |
|     |     | The Needle tool panel (3) displays the        |
|     |     | following additional controls:                |
|     |     | Lock locks the needle out of its sheath.      |
|     |     | It is performed via the touch screen and      |
|     |     | is a mandatory step in simulated TBNA         |
|     |     | performance.                                  |

[TABLE]
| It is performed via the touch screen and                                       |
|:-------------------------------------------------------------------------------|
| is a mandatory step in simulated TBNA                                          |
| performance.                                                                   |
| Note: The Lock button is enabled only when the needle is pushed completely     |
| out of its sheath.                                                             |
| Secure Proximally simulates manually holding together the proximal portion of  |
| the needle’s sheath in the working channel, allowing for advancing the scope   |
| and needle as one unit.                                                        |
| Suction is performed by pulling the actual syringe piston open to Aspirate and |
| pushing it close to Release. Applying suction is a mandatory step in simulated |
| TBNA performance.                                                              |
| 7 - General Buttons                                                            |
|  Mute button toggles the sound on and off.                                                                                |
|  Case File button opens the current Task case file.                                                                                |
|  Help button opens the online help (availability is per software version).                                                                                |
|  Finish button ends the current simulation, allowing for saving its                                                                                |
| performance metrics.                                                           |

[OCR_TABLE]
Cees

[OCR]
Essential Bronchoscopy Module *

The Forceps, Brush and Needle tool
panels (1, 2 and 3) display the tools’ states
and options. All three allow for virtual
activation, overpowering the master tool
handle to facilitate easier solo training.

Note: Virtual tool activation can be
controlled via touch screen, foot switch, or
scope buttons.

[ The tool panels indicate whether Virtual

Activation is on, what is the current tool
Suction state, and provide additional control
options when applicable.

ne The Needle tool panel (3) displays the
L » following additional controls:

Lock locks the needle out of its sheath.
It is performed via the touch screen and
is a mandatory step in simulated TBNA

performance.

Note: The Lock button is enabled only when the needle is pushed completely
out of its sheath.

Secure Proximally simulates manually holding together the proximal portion of
the needle’s sheath in the working channel, allowing for advancing the scope
and needle as one unit.

Suction is performed by pulling the actual syringe piston open to Aspirate and
pushing it close to Release. Applying suction is a mandatory step in simulated
TBNA performance.

7 - General Buttons

= Mute button toggles the sound on and off.

= Case File button opens the current Task case file.

= Help button opens the online help (availability is per software version).

= Finish button ends the current simulation, allowing for saving its
performance metrics.

surgical BRONCH Mentor


# Page 6

Essential Bronchoscopy Module
6
BRONCH Mentor
Skill Task 1 - Basic Scope Manipulation
Goal:
Acquire basic bronchoscope control capabilities.
Method:
Learn to navigate the bronchoscope in a cyber environment to acquire the 
basic scope manipulation skills and to further develop hand-eye coordination. 
Manipulate the scope to stay in the center and avoid wall contact while 
following an object along a randomly selected narrowing lumen. The cyber 
environment allows for ongoing practice and improvement, providing 
immediate feedback following the completion of each navigated route.
Performance Assessment:
Scope maneuvering attributes such as time to complete navigation, keeping 
the scope tip in mid-lumen or hitting the wall are captured, displayed, and 
incorporated into a final score, ranging from 0 to 100.
1


[TABLE]
|                                                                               |
|:------------------------------------------------------------------------------|
| Skill Task 1 - Basic Scope Manipulation                                       |
| 1                                                                             |
| Goal:                                                                         |
| Acquire basic bronchoscope control capabilities.                              |
| Method:                                                                       |
| Learn to navigate the bronchoscope in a cyber environment to acquire the      |
| basic scope manipulation skills and to further develop hand-eye coordination. |
| Manipulate the scope to stay in the center and avoid wall contact while       |
| following an object along a randomly selected narrowing lumen. The cyber      |
| environment allows for ongoing practice and improvement, providing            |
| immediate feedback following the completion of each navigated route.          |
| Performance Assessment:                                                       |
| Scope maneuvering attributes such as time to complete navigation, keeping     |
| the scope tip in mid-lumen or hitting the wall are captured, displayed, and   |
| incorporated into a final score, ranging from 0 to 100.                       |

[OCR]
Essential Bronchoscopy Module

Skill Task 1 - Basic Scope Manipulation

Goal:

Acquire basic bronchoscope control capabilities.

Method:

Learn to navigate the bronchoscope in a cyber environment to acquire the
basic scope manipulation skills and to further develop hand-eye coordination.
Manipulate the scope to stay in the center and avoid wall contact while
following an object along a randomly selected narrowing lumen. The cyber
environment allows for ongoing practice and improvement, providing
immediate feedback following the completion of each navigated route.

Performance Assessment:

Scope maneuvering attributes such as time to complete navigation, keeping
the scope tip in mid-lumen or hitting the wall are captured, displayed, and
incorporated into a final score, ranging from 0 to 100.

PERFORMANCE

surgical BRONCH Mentor


# Page 7

Essential Bronchoscopy Module
7
BRONCH Mentor
Skill Task 2 - Guided Anatomical Navigation
Goal: 
Learn and practice correct scope navigation within the anatomical 
environment.
Method:
Perform bronchial navigation maneuvers using ‘Directional Guidance’: 
Figures within the lumen correspond to the scope’s ‘viewfinder’, hinting the 
correct scope roll and flex/extent for each anatomical carina. While entering 
each bronchial segment, the figure in the carina indicates whether maneuver 
was performed satisfactorily.
Performance Assessment:
General assessment of endobronchial scope navigation and detailed 
information as to the maneuver performed at each anatomical carina.
2


[TABLE]
|                                                                               |
|:------------------------------------------------------------------------------|
| Skill Task 2 - Guided Anatomical Navigation                                   |
| 2                                                                             |
| Goal:                                                                         |
| Learn and practice correct scope navigation within the anatomical             |
| environment.                                                                  |
| Method:                                                                       |
| Perform bronchial navigation maneuvers using ‘Directional Guidance’:          |
| Figures within the lumen correspond to the scope’s ‘viewfinder’, hinting the  |
| correct scope roll and flex/extent for each anatomical carina. While entering |
| each bronchial segment, the figure in the carina indicates whether maneuver   |
| was performed satisfactorily.                                                 |
| Performance Assessment:                                                       |
| General assessment of endobronchial scope navigation and detailed             |
| information as to the maneuver performed at each anatomical carina.           |

[OCR]
Essential Bronchoscopy Module

Skill Task 2 - Guided Anatomical Navigation

Goal:

Learn and practice correct scope navigation within the anatomical
environment.

Method:

Perform bronchial navigation maneuvers using ‘Directional Guidance’:
Figures within the lumen correspond to the scope’s ‘viewfinder’, hinting the
correct scope roll and flex/extent for each anatomical carina. While entering
each bronchial segment, the figure in the carina indicates whether maneuver
was performed satisfactorily.

Performance Assessment:

General assessment of endobronchial scope navigation and detailed
information as to the maneuver performed at each anatomical carina.

surgicalscience BRONCH Mentor


# Page 8

Essential Bronchoscopy Module
8
BRONCH Mentor
Skill Task 3 - Lung Anatomy, Bronchial Segments
Goal: 
Gain familiarity with bronchial anatomy and identify each bronchial segment by 
name.
Method:
User identifies the bronchial segments by name, by focusing the scope on 
question marks within the segments and selecting the correct name for each 
segment. Two naming conventions are available: Descriptive-numeric and 
Advanced-numeric; their selection is done prior to starting the task.  
Three identification tries are allowed for each segment; after the third mistake, 
the segment’s name is revealed.
Performance Assessment:
Detailed information is given as to the correct identification of each bronchial 
segment, using the selected naming convention.
3


[TABLE]
|                                                                                   |
|:----------------------------------------------------------------------------------|
| Skill Task 3 - Lung Anatomy, Bronchial Segments                                   |
| 3                                                                                 |
| Goal:                                                                             |
| Gain familiarity with bronchial anatomy and identify each bronchial segment by    |
| name.                                                                             |
| Method:                                                                           |
| User identifies the bronchial segments by name, by focusing the scope on          |
| question marks within the segments and selecting the correct name for each        |
| segment. Two naming conventions are available: Descriptive-numeric and            |
| Advanced-numeric; their selection is done prior to starting the task.             |
| Three identification tries are allowed for each segment; after the third mistake, |
| the segment’s name is revealed.                                                   |
| Performance Assessment:                                                           |
| Detailed information is given as to the correct identification of each bronchial  |
| segment, using the selected naming convention.                                    |

[OCR]
Essential Bronchoscopy Module

Skill Task 3 - Lung Anatomy, Bronchial Segments

Goal:

Gain familiarity with bronchial anatomy and identify each bronchial segment by
name.

Method:

User identifies the bronchial segments by name, by focusing the scope on
question marks within the segments and selecting the correct name for each
segment. Two naming conventions are available: Descriptive-numeric and
Advanced-numeric; their selection is done prior to starting the task.

Three identification tries are allowed for each segment; after the third mistake,
the segment’s name is revealed.

Performance Assessment:

Detailed information is given as to the correct identification of each bronchial
segment, using the selected naming convention.

surgicalscience BRONCH Mentor


# Page 9

Essential Bronchoscopy Module
9
BRONCH Mentor
Skill Task 4 - Lung Anatomy, Lymph Nodes
Goal: 
Gain familiarity with adjoining mediastinal vascular structures and lymph node 
stations, under the IASLC map (2009).
Method:
Focusing the scope on arrows pointing to airway walls will reveal lymph 
nodes and vascular structures behind it. The same lymph node station will be 
highlighted on the corresponding external view and shown on CT scan images. 
A menu is opened to select the correct lymph node name under the IASLC map 
(2009). Three identification tries are allowed for each lymph node; after the 
third mistake, the correct name is revealed.
Note: Lymph node stations may be represented by multiple nodes.
Performance Assessment:
Detailed information is provided as to the correct identification of each lymph 
node.
4


[TABLE]
| Essential Bronchoscopy Module                                                   |
|:--------------------------------------------------------------------------------|
| Skill Task 4 - Lung Anatomy, Lymph Nodes                                        |
| 4                                                                               |
| Goal:                                                                           |
| Gain familiarity with adjoining mediastinal vascular structures and lymph node  |
| stations, under the IASLC map (2009).                                           |
| Method:                                                                         |
| Focusing the scope on arrows pointing to airway walls will reveal lymph         |
| nodes and vascular structures behind it. The same lymph node station will be    |
| highlighted on the corresponding external view and shown on CT scan images.     |
| A menu is opened to select the correct lymph node name under the IASLC map      |
| (2009). Three identification tries are allowed for each lymph node; after the   |
| third mistake, the correct name is revealed.                                    |
| Note: Lymph node stations may be represented by multiple nodes.                 |
| Performance Assessment:                                                         |
| Detailed information is provided as to the correct identification of each lymph |
| node.                                                                           |
| 9                                                                               |
| BRONCH Mentor                                                                   |

[OCR]
Essential Bronchoscopy Module

Skill Task 4 - Lung Anatomy, Lymph Nodes

Goal:

Gain familiarity with adjoining mediastinal vascular structures and lymph node
stations, under the IASLC map (2009).

Method:

Focusing the scope on arrows pointing to airway walls will reveal lymph

nodes and vascular structures behind it. The same lymph node station will be
highlighted on the corresponding external view and shown on CT scan images.
A menu is opened to select the correct lymph node name under the IASLC map
(2009). Three identification tries are allowed for each lymph node; after the
third mistake, the correct name is revealed.

Note: Lymph node stations may be represented by multiple nodes.

Performance Assessment:

Detailed information is provided as to the correct identification of each lymph
node.

surgicalscience BRONCH Mentor


# Page 10

Essential Bronchoscopy Module
10
BRONCH Mentor
Skill Task 5 - Step-by-Step Diagnostic Maneuvers 
Goal: 
At the end of this task, the user should acquire the skills needed to perform a 
forceps, brush, and transbronchial needle biopsy.
Method:
Step-by-step instructions are available for each diagnostic maneuver upon 
menu tool selection of biopsy forceps, cytology brush, or aspirating needle. 
Immediate feedback is provided at the completion of each diagnostic 
maneuver to let the bronchoscopist know whether tissue was obtained 
successfully and whether or not the tool was used incorrectly during sampling. 
Real time warnings appear when the diagnostic tools are being used 
incorrectly. A video clip of each maneuver is available to demonstrate the 
correct performance of each procedure.
Note:	
Samples are taken from two blue pads located at the RLL and at the 
LUL-LLL carina. The pad is marked with a blue number to indicate a successful 
sampling attempt or with a gray number to indicate an unsuccessful sampling 
attempt.
 
5


[TABLE]
|                                                                                 |                                                                    |
|:--------------------------------------------------------------------------------|:-------------------------------------------------------------------|
| 5                                                                               | Skill Task 5 - Step-by-Step Diagnostic Maneuvers                   |
| Goal:                                                                           |                                                                    |
| At the end of this task, the user should acquire the skills needed to perform a |                                                                    |
| forceps, brush, and transbronchial needle biopsy.                               |                                                                    |
| Method:                                                                         |                                                                    |
| Step-by-step instructions are available for each diagnostic maneuver upon       |                                                                    |
| menu tool selection of biopsy forceps, cytology brush, or aspirating needle.    |                                                                    |
| Immediate feedback is provided at the completion of each diagnostic             |                                                                    |
| maneuver to let the bronchoscopist know whether tissue was obtained             |                                                                    |
| successfully and whether or not the tool was used incorrectly during sampling.  |                                                                    |
| Real time warnings appear when the diagnostic tools are being used              |                                                                    |
| incorrectly. A video clip of each maneuver is available to demonstrate the      |                                                                    |
| correct performance of each procedure.                                          |                                                                    |
| Note:                                                                           | Samples are taken from two blue pads located at the RLL and at the |
| LUL-LLL carina. The pad is marked with a blue number to indicate a successful   |                                                                    |
| sampling attempt or with a gray number to indicate an unsuccessful sampling     |                                                                    |
| attempt.                                                                        |                                                                    |

[OCR]
Essential Bronchoscopy Module |

Skill Task 5 - Step-by-Step Diagnostic Maneuvers

Goal:

At the end of this task, the user should acquire the skills needed to perform a
forceps, brush, and transbronchial needle biopsy.

Method:

Step-by-step instructions are available for each diagnostic maneuver upon
menu tool selection of biopsy forceps, cytology brush, or aspirating needle.
Immediate feedback is provided at the completion of each diagnostic
maneuver to let the bronchoscopist know whether tissue was obtained
successfully and whether or not the tool was used incorrectly during sampling.
Real time warnings appear when the diagnostic tools are being used
incorrectly. A video clip of each maneuver is available to demonstrate the
correct performance of each procedure.

Note: Samples are taken from two blue pads located at the RLL and at the
LUL-LLL carina. The pad is marked with a blue number to indicate a successful
sampling attempt or with a gray number to indicate an unsuccessful sampling
attempt.

surgical BRONCH Mentor


# Page 11

Essential Bronchoscopy Module
11
BRONCH Mentor
Performance Assessment:
Sampling quality and efficacy per each diagnostic tool used are reported, along 
with assessment of whether the maneuver was performed correctly, or, what 
steps were incorrectly performed.
Skill Task 5 - Step-by-Step Diagnostic Maneuvers 
5


[TABLE]
| Essential Bronchoscopy Module                                                   |
|:--------------------------------------------------------------------------------|
| Skill Task 5 - Step-by-Step Diagnostic Maneuvers                                |
| 5                                                                               |
| Performance Assessment:                                                         |
| Sampling quality and efficacy per each diagnostic tool used are reported, along |
| with assessment of whether the maneuver was performed correctly, or, what       |
| steps were incorrectly performed.                                               |
| 11                                                                              |
| BRONCH Mentor                                                                   |

[OCR]
Essential Bronchoscopy Module

Skill Task 5 - Step-by-Step Diagnostic Maneuvers

Performance Assessment:

Sampling quality and efficacy per each diagnostic tool used are reported, along
with assessment of whether the maneuver was performed correctly, or, what
steps were incorrectly performed.

surgicalscience BRONCH Mentor