

# Page 1

Endoscopic Ultrasound (EUS)
Tasks Module -
1
GI Mentor
The EUS Tasks Module provides a fixed training program, in which 
the user’s expertise is tested, evaluated and reported.
This module offers:
	
 33 landmark tasks in which the user is required to perform scope 
positioning and anatomy identification following visual and textual 
instructions.
	
 Utilization of real-time Endoscopic view, External 3D map and Ultrasound 
view.
	
 Ultrasound image freeze and structures labeling that are later matched by 
the user to the corresponding landmark.
	
 Feedback as to the complete and accurate identification of each landmark. 
This Module was developed in collaboration with Dr. Marc Giovannini, Institut 
Paoli-Calmettes, Marseille, France. Dr. Darius Sorbi & Dr. David Fleischer, Mayo 
Clinic, Scottsdale, AZ, USA. Dr. Erwin Santo, Sourasky Medical Center, Tel-
Aviv, Israel. Dr. Yaakov Maor, Sheba Medical Center, Ramat-Gan, Israel. and 
Dr. Robert Hawes, MUSC, Charleston, SC, USA. Simbionix Ltd. (2003).


[TABLE]
| Endoscopic Ultrasound (EUS)                                         |
|:--------------------------------------------------------------------|
| The EUS Tasks Module provides a fixed training program, in which    |
| the user’s expertise is tested, evaluated and reported.             |
| This module offers:                                                 |
|  33 landmark tasks in which the user is required to perform scope                                                                     |
| positioning and anatomy identification following visual and textual |
| instructions.                                                       |
|  Utilization of real-time Endoscopic view, External 3D map and Ultrasound                                                                     |
| view.                                                               |
|  Ultrasound image freeze and structures labeling that are later matched by                                                                     |
| the user to the corresponding landmark.                             |
|  Feedback as to the complete and accurate identification of each landmark.                                                                     |

[OCR_TABLE]
This m

[OCR]
Tasks Module -

Endoscopic Ultrasound (EUS

The EUS Tasks Module provides a fixed training program, in which
the user’s expertise is tested, evaluated and reported.

This module offers:

= 33 landmark tasks in which the user is required to perform scope
positioning and anatomy identification following visual and textual
instructions.

= Utilization of real-time Endoscopic view, External 3D map and Ultrasound
view.

= Ultrasound image freeze and structures labeling that are later matched by
the user to the corresponding landmark.

= Feedback as to the complete and accurate identification of each landmark.

General Info Build Medical Program | Performance xa soon | Instructor Comments
EUS Taske (Case 1) list )
Date: 6/10/2003 3:51:30 PM +) EE
Total Time’ 10-0035 <J| 3150 | Le

Brawse landmarks Task Summar

4 out of 8 landmarks were fully identified:
50%

Total time 3D map was used: 05:00:01

6 out of 17 organs were recognized from
total list of landmarks: 35%

> Superior Genu

7 out of 14 vessels were recognized from

@ Dusdénel bully total list of landmarks: 50%

> Duvdenal Bulb 2

> Bulb Confluence

« Task Summary qq Q Enlarse maze p>

This Module was developed in collaboration with Dr. Marc Giovannini, Institut
Paoli-Calmettes, Marseille, France. Dr. Darius Sorbi & Dr. David Fleischer, Mayo
Clinic, Scottsdale, AZ, USA. Dr. Erwin Santo, Sourasky Medical Center, Tel-
Aviv, Israel. Dr. Yaakov Maor, Sheba Medical Center, Ramat-Gan, Israel. and
Dr. Robert Hawes, MUSC, Charleston, SC, USA. Simbionix Ltd. (2003).

surgical GI Mentor


# Page 2

Endoscopic Ultrasound (EUS)
Tasks Module -
2
GI Mentor
Case 1 - Linear - Duodenum Area
1
Landmark 1: Lengthen Aorta & Vena Cava
Landmark 2: Uncinate Process
1. Abdominal aorta 
2. Inferior vena cava
1. Uncinate process 
2. Superior mesenteric vein 
3. Superior mesenteric artery
Pass the pylorus 
with the same 
technique used 
for ERCP. The 
examination starts 
in the 3rd part of 
the duodenum just 
below the papilla of 
Vater. Positioning 
the scope posteriorly, a longitudinal view 
of the abdominal aorta and the inferior 
vena cava is obtained.
Minimal scope 
withdrawal, about 
0.5 cm, with a 
counterclockwise 
rotation.


[TABLE]
|                                            |
|:-------------------------------------------|
| Case 1 - Linear - Duodenum Area            |
| 1                                          |
| Landmark 1: Lengthen Aorta & Vena Cava     |
| Pass the pylorus                           |
| with the same                              |
| technique used                             |
| for ERCP. The                              |
| examination starts                         |
| in the 3rd part of                         |
| the duodenum just                          |
| below the papilla of                       |
| Vater. Positioning                         |
| the scope posteriorly, a longitudinal view |
| of the abdominal aorta and the inferior    |
| 1. Abdominal aorta                         |
| vena cava is obtained.                     |
| 2. Inferior vena cava                      |

[OCR_TABLE]
Ena

[OCR]
Tasks Module -

Endoscopic Ultrasound (EUS)

Case 1 - Linear - Duodenum Area

Landmark 1: Lengthen Aorta & Vena Cava

1. Abdominal aorta
2. Inferior vena cava

Pass the pylorus
with the same
technique used

for ERCP. The
examination starts
in the 3rd part of
the duodenum just
below the papilla of
Vater. Positioning
the scope posteriorly, a longitudinal view
of the abdominal aorta and the inferior
vena cava is obtained.

Landmark 2: Uncinate Process

1. Uncinate process
2. Superior mesenteric vein
3. Superior mesenteric artery

surgicalscience

Minimal scope
withdrawal, about
0.5 cm, with a
counterclockwise
rotation.

GI Mentor


# Page 3

Endoscopic Ultrasound (EUS)
Tasks Module -
3
GI Mentor
1
Landmark 3: Papilla
Landmark 4: Longitudinal CBD & PV
1. Pancreatic head 
2. Pancreatic duct 
3. Common bile duct 
4. Superior mesenteric vein 
5. Superior mesenteric artery 
6. Inferior vena cava 
7. Abdominal aorta
1. Common bile duct 
2. Portal Vein
Minimal scope 
withdrawal and 
adjustment of the 
image by minor 
rotation of the 
small dial to the left 
and to the right.
Scope withdrawal 
1 to 2 cm with a 
counterclockwise 
rotation. 
Positioning of the 
scope proximal 
to the superior 
genu enables a 
longitudinal 
view of the CBD 
and the PV.
Case 1 - Linear - Duodenum Area


[TABLE]
| Case 1 - Linear - Duodenum Area   |
|:----------------------------------|
| Minimal scope                     |
| withdrawal and                    |
| adjustment of the                 |
| image by minor                    |
| rotation of the                   |
| small dial to the left            |
| and to the right.                 |

[OCR]
Tasks Module -

Endoscopic Ultrasound (EUS)

Case 1 - Linear - Duodenum Area

Landmark 3: Papilla

Minimal scope
withdrawal and
adjustment of the
image by minor
rotation of the
small dial to the left
and to the right.

1. Pancreatic head

2. Pancreatic duct

3. Common bile duct

4. Superior mesenteric vein
5. Superior mesenteric artery
6. Inferior vena cava

7. Abdominal aorta

Landmark 4: Longitudinal CBD & PV

Scope withdrawal
1to2cmwitha
counterclockwise
rotation.
Positioning of the
scope proximal
to the superior
genu enables a
longitudinal

view of the CBD
and the PV.

1. Common bile duct
2. Portal Vein

surgicalscience GI Mentor


# Page 4

Endoscopic Ultrasound (EUS)
Tasks Module -
4
GI Mentor
1
Landmark 5: Superior Genu
Landmark 6: Duodenal Bulb 1
1. Superior mesenteric vein 
2. Common bile duct 
3. Pancreatic duct 
4. Pancreatic head
1. Common bile duct 
2. Pancreatic duct 
3. Pancreatic head 
4. Inferior vena cava
 Scope withdrawal.
Scope withdrawal 
from the genu 
into the duodenal 
bulb. The section 
of the CBD seen 
in this area is 
intra-pancreatic. 
The PD and the 
CBD are seen in 
parallel, converging into the papilla.
Case 1 - Linear - Duodenum Area


[TABLE]
| Tasks Module -                         |
|:---------------------------------------|
| Endoscopic Ultrasound (EUS)            |
| Case 1 - Linear - Duodenum Area        |
| 1                                      |
| Landmark 5: Superior Genu              |
| Scope withdrawal.                      |
| 1. Superior mesenteric vein            |
| 2. Common bile duct                    |
| 3. Pancreatic duct                     |
| 4. Pancreatic head                     |
| Landmark 6: Duodenal Bulb 1            |
| Scope withdrawal                       |
| from the genu                          |
| into the duodenal                      |
| bulb. The section                      |
| of the CBD seen                        |
| in this area is                        |
| intra-pancreatic.                      |
| The PD and the                         |
| CBD are seen in                        |
| parallel, converging into the papilla. |
| 1. Common bile duct                    |
| 2. Pancreatic duct                     |
| 3. Pancreatic head                     |
| 4. Inferior vena cava                  |
| 4                                      |
| GI Mentor                              |

[OCR]
Tasks Module -

Endoscopic Ultrasound (EUS)

Case 1 - Linear - Duodenum Area

Landmark 5: Superior Genu

1. Superior mesenteric vein
2. Common bile duct

3. Pancreatic duct

4. Pancreatic head

Scope withdrawal.

Landmark 6: Duodenal Bulb 1

-°

“ART EE head

1. Common bile duct
2. Pancreatic duct
3. Pancreatic head
4. Inferior vena cava

surgicalscience

Scope withdrawal
from the genu
into the duodenal
bulb. The section
of the CBD seen
in this area is
intra-pancreatic.
The PD and the
CBD are seen in
parallel, converging into the papilla.

GI Mentor


# Page 5

Endoscopic Ultrasound (EUS)
Tasks Module -
5
GI Mentor
1
Landmark 7: Duodenal Bulb 2
Landmark 8: Bulb Confluence
1. Common bile duct 
2. Portal vein 
3. Hepatic artery
1. Confluence 
2. Pancreatic head 
3. Pancreatic neck 
4. Gastroduodenal artery 
5. Pancreatic duct 
6. Common bile duct
180° rotation of the 
scope in the same 
position. Minor 
rotation of the 
small dial to the left 
and to the right. 
It is recommended 
to follow the 
portal vein until 
its bifurcation; lymph nodes area of 
examination. Gallbladder isolated when 
viewing in this position.
Scope rotated 
180° back to its 
original position. 
The scope is now 
retracted back 
to the pylorus; in 
clinical situations: 
with slight tension 
on the balloon.
Case 1 - Linear - Duodenum Area


[TABLE]
|                                        |
|:---------------------------------------|
| Case 1 - Linear - Duodenum Area        |
| 1                                      |
| Landmark 7: Duodenal Bulb 2            |
| 180° rotation of the                   |
| scope in the same                      |
| position. Minor                        |
| rotation of the                        |
| small dial to the left                 |
| and to the right.                      |
| It is recommended                      |
| to follow the                          |
| portal vein until                      |
| its bifurcation; lymph nodes area of   |
| examination. Gallbladder isolated when |
| 1. Common bile duct                    |
| viewing in this position.              |
| 2. Portal vein                         |

[OCR_TABLE]
ale!

[OCR]
Tasks Module -

Endoscopic Ultrasound (EUS)

Case 1 - Linear - Duodenum Area

Landmark 7: Duodenal Bulb 2

1. Common bile duct
2. Portal vein
3. Hepatic artery

180° rotation of the
scope in the same
position. Minor
rotation of the
small dial to the left
and to the right.

It is recommended
to follow the

portal vein until

its bifurcation; lymph nodes area of
examination. Gallbladder isolated when
viewing in this position.

Landmark 8: Bulb Confluence

{SDA

Pancreatic heads +2 pp,

+
CONF, PD

Pancreatic”
neck

1. Confluence

2. Pancreatic head

3. Pancreatic neck

4. Gastroduodenal artery
5. Pancreatic duct

6. Common bile duct

surgicalscience

Scope rotated
180° back to its
original position.
The scope is now
retracted back

to the pylorus; in
clinical situations:
with slight tension
on the balloon.

GI Mentor


# Page 6

Endoscopic Ultrasound (EUS)
Tasks Module -
6
GI Mentor
Case 2 - Linear - Antrum Area
2
Landmark 1: Antrum
Landmark 2: Butterfly Confluence
1. Pancreatic neck
2. Pancreatic duct
3. Confluence
4. Superior mesenteric artery
1. Pancreatic body
2. Superior mesenteric vein
3. Portal vein
4. Splenic vein
In clinical 
situations it is now 
recommended to 
slightly deflate 
the balloon while 
withdrawing through 
the pylorus. Small 
counterclockwise 
rotation is 
performed. Additional counterclockwise 
torque to view the gallbladder.
Scope withdrawal 
about 5 to 10 
cm back. The 
transducer is placed 
on the posterior 
wall of the stomach. 
In this position the 
confluence is in a 
butterfly shape. 
Important area for nodal staging.


[TABLE]
| In clinical                            |
|:---------------------------------------|
| situations it is now                   |
| recommended to                         |
| slightly deflate                       |
| the balloon while                      |
| withdrawing through                    |
| the pylorus. Small                     |
| counterclockwise                       |
| rotation is                            |
| performed. Additional counterclockwise |
| torque to view the gallbladder.        |

[OCR_TABLE]
End

[OCR]
Tasks Module -
Endoscopic Ultrasound (EUS) :

Case 2 - Linear - Antrum Area

Landmark 1: Antrum

In clinical

situations it is now
recommended to
slightly deflate

the balloon while
withdrawing through
the pylorus. Small
counterclockwise
rotation is
performed. Additional counterclockwise
torque to view the gallbladder.

1. Pancreatic neck

2. Pancreatic duct

3. Confluence

4. Superior mesenteric artery

Landmark 2: Butterfly Confluence

Scope withdrawal
about 5 to 10

cm back. The
transducer is placed
on the posterior
wall of the stomach.
In this position the
confluence is ina
butterfly shape.
Important area for nodal staging.

1. Pancreatic body

2. Superior mesenteric vein
3. Portal vein

4. Splenic vein

surgicalscience GI Mentor


# Page 7

Endoscopic Ultrasound (EUS)
Tasks Module -
7
GI Mentor
Case 3 - Linear - Stomach Area
3
Landmark 1: Distal Pancreatic Body
Landmark 2: Left Kidney
1. Pancreatic body
2. Pancreatic tail
3. Pancreatic duct
4. Splenic vein
5. Splenic artery
1. Left kidney
2. Pancreatic body
3. Pancreatic tail
4. Splenic vein
5. Splenic artery
Scope withdrawal 
5cm back. Slight 
torquing will reveal 
the SMA running 
below the tail.
Counterclockwise 
torque.


[TABLE]
| Scope withdrawal     |
|:---------------------|
| 5cm back. Slight     |
| torquing will reveal |
| the SMA running      |
| below the tail.      |

[OCR]
Tasks Module -

Endoscopic Ultrasound (EUS)

Case 3 - Linear - Stomach Area

Landmark 1: Distal Pancreatic Body

Scope withdrawal

j Pancreatic .
- oem 5cm back. Slight
Pancreatic tir? SA” . .

+ Body ty torquing will reveal
the SMA running
below the tail.

1. Pancreatic body

2. Pancreatic tail

3. Pancreatic duct

4. Splenic vein

5. Splenic artery

Landmark 2: Left Kidney

Poncaitic ai. Counterclockwise
. body tail, torque.

1. Left kidney

2. Pancreatic body
3. Pancreatic tail
4. Splenic vein

5. Splenic artery

surgicalscience GI Mentor


# Page 8

Endoscopic Ultrasound (EUS)
Tasks Module -
8
GI Mentor
Case 3 - Linear - Stomach Area
3
Landmark 3: Spleen-Pancreatic Tail 
Landmark 4: Celiac
1. Spleen
2. Pancreatic tail
3. Splenic hilum
4. Splenic vein
1. Abdominal aorta
2. Celiac artery
3. Superior mesenteric artery
Clockwise torque 
(If needed minimal 
scope withdrawal).
Alternatively, to 
view the spleen 
and left kidney, the 
scope is placed 
at the cardia 
area and torqued 
counterclockwise. Dial in UP position, the 
scope is pushed into the fundus area to 
see the spleen. Slightly torque scope to 
the left and right to locate the left kidney.
At EUS left kidney 
view, scope is 
withdrawn 5 cm to 
the area below the 
cardia with slight 
left/right torquing.


[TABLE]
|                                               |
|:----------------------------------------------|
| Case 3 - Linear - Stomach Area                |
| 3                                             |
| Landmark 3: Spleen-Pancreatic Tail            |
| Clockwise torque                              |
| (If needed minimal                            |
| scope withdrawal).                            |
| Alternatively, to                             |
| view the spleen                               |
| and left kidney, the                          |
| scope is placed                               |
| at the cardia                                 |
| area and torqued                              |
| counterclockwise. Dial in UP position, the    |
| scope is pushed into the fundus area to       |
| 1. Spleen                                     |
| see the spleen. Slightly torque scope to      |
| 2. Pancreatic tail                            |
| the left and right to locate the left kidney. |
| 3. Splenic hilum                              |

[OCR_TABLE]
End

[OCR]
Tasks Module -

Endoscopic Ultrasound (EUS)

Case 3 - Linear - Stomach Area

Landmark 3: Spleen-Pancreatic Tail

Clockwise torque

: . (If needed minimal
* Pancretemme .—" scope withdrawal).
Alternatively, to
view the spleen
and left kidney, the
scope is placed

at the cardia

area and torqued
counterclockwise. Dial in UP position, the
scope is pushed into the fundus area to
see the spleen. Slightly torque scope to
the left and right to locate the left kidney.

1. Spleen

2. Pancreatic tail
3. Splenic hilum
4. Splenic vein

Landmark 4: Celiac

At EUS left kidney
view, scope is
withdrawn 5 cm to
the area below the
cardia with slight
left/right torquing.

1. Abdominal aorta
2. Celiac artery
3. Superior mesenteric artery

surgicalscience GI Mentor


# Page 9

Endoscopic Ultrasound (EUS)
Tasks Module -
9
GI Mentor
Case 3 - Linear - Stomach Area
3
Landmark 5: Liver 1
Landmark 6: Liver 2
1. Liver
1. Hepatic vein
2. Inferior vena cava
3. Liver
Nearly 180° 
counterclockwise 
rotation from 
previous position 
Or at the level of 
distal body/left 
kidney.
Scope withdrawal 
from previous 
position.


[TABLE]
| Nearly 180°        |
|:-------------------|
| counterclockwise   |
| rotation from      |
| previous position  |
| Or at the level of |
| distal body/left   |
| kidney.            |

[OCR]
Tasks Module -

Endoscopic Ultrasound (EUS)

Case 3 - Linear - Stomach Area

Landmark 5: Liver 1

Nearly 180°
counterclockwise
rotation from
previous position
Or at the level of
distal body/left
kidney.

1. Liver

Landmark 6: Liver 2

Scope withdrawal
from previous
position.

1. Hepatic vein
2. Inferior vena cava
3. Liver

surgicalscience GI Mentor


# Page 10

Endoscopic Ultrasound (EUS)
Tasks Module -
10
GI Mentor
Case 4 - Radial - Stomach Area
4
Landmark 1: Abdominal Aorta
Landmark 2: Celiac Artery
1. Abdominal aorta
2. Liver
3. Inferior vena cava
4. Hepatic vein
5. Diaphragm
1. Abdominal aorta
2. Celiac artery
In the EUS view, 
identify the 
descending aorta 
in the cardia area. 
It is recommended 
to locate the 
abdominal aorta at 
6 o’clock. The liver 
and the IVC are at 
the 9 o’clock position. In order to maintain 
the transducer close to the aorta the dials 
should be rotated UP and RIGHT.
The scope is 
pushed into the 
stomach following 
the abdominal 
aorta distally until 
the celiac artery is 
seen branching off 
from the anterior 
surface of the 
aorta.


[TABLE]
|                                              |
|:---------------------------------------------|
| Case 4 - Radial - Stomach Area               |
| 4                                            |
| Landmark 1: Abdominal Aorta                  |
| In the EUS view,                             |
| identify the                                 |
| descending aorta                             |
| in the cardia area.                          |
| It is recommended                            |
| to locate the                                |
| abdominal aorta at                           |
| 6 o’clock. The liver                         |
| and the IVC are at                           |
| the 9 o’clock position. In order to maintain |
| the transducer close to the aorta the dials  |
| 1. Abdominal aorta                           |
| should be rotated UP and RIGHT.              |
| 2. Liver                                     |

[OCR_TABLE]
ena

[OCR]
Tasks Module -

Endoscopic Ultrasound (EUS)

Case 4 - Radial - Stomach Area

Landmark 1: Abdominal Aorta

In the EUS view,
identify the
descending aorta
in the cardia area.
It is recommended
to locate the
abdominal aorta at
6 o'clock. The liver
and the IVC are at
the 9 o'clock position. In order to maintain
the transducer close to the aorta the dials
should be rotated UP and RIGHT.

1. Abdominal aorta
2. Liver

3. Inferior vena cava
4. Hepatic vein

5. Diaphragm

Landmark 2: Celiac Artery

The scope is
pushed into the
stomach following
the abdominal
aorta distally until

the celiac artery is
seen branching off \
from the anterior

surface of the
aorta.

1. Abdominal aorta
2. Celiac artery

surgicalscience GI Mentor


# Page 11

Endoscopic Ultrasound (EUS)
Tasks Module -
11
GI Mentor
Case 4 - Radial - Stomach Area
4
Landmark 3: Celiac Bifurcation
Landmark 4: Confluence
1. Celiac artery
2. Hepatic artery
3. Splenic artery
4. Abdominal aorta
1. Confluence
2. Splenic vein
3. Pancreatic body
4. Pancreatic duct
5. Superior mesenteric artery
6. Liver
The scope is 
pushed slightly 
farther into the 
stomach until 
the celiac is seen 
dividing into 
the hepatic and 
splenic arteries. 
The hepatic artery 
heads in the direction of the liver and the 
splenic artery passes towards the spleen. 
The pancreatic body and tail can be 
identified from this position.
The scope is 
advanced slightly 
farther below the 
Celiac bifurcation. 
Minor rotation of 
the small dial to 
the left and to the 
right will reveal 
the confluence of 
the PV and SV. Torquing left and right 
from tail toward the pancreatic neck 
will enable a full examination of the 
pancreatic duct and parenchyma.


[TABLE]
|                                             |
|:--------------------------------------------|
| Case 4 - Radial - Stomach Area              |
| 4                                           |
| Landmark 3: Celiac Bifurcation              |
| The scope is                                |
| pushed slightly                             |
| farther into the                            |
| stomach until                               |
| the celiac is seen                          |
| dividing into                               |
| the hepatic and                             |
| splenic arteries.                           |
| The hepatic artery                          |
| heads in the direction of the liver and the |
| splenic artery passes towards the spleen.   |
| 1. Celiac artery                            |
| The pancreatic body and tail can be         |
| 2. Hepatic artery                           |
| identified from this position.              |
| 3. Splenic artery                           |

[OCR_TABLE]
Ena

[OCR]
Tasks Module -

Endoscopic Ultrasound (EUS)

Case 4 - Radial - Stomach Area

Landmark 3: Celiac Bifurcation

1. Celiac artery

2. Hepatic artery
3. Splenic artery
4. Abdominal aorta

The scope is
pushed slightly
farther into the
stomach until

the celiac is seen
dividing into

the hepatic and
splenic arteries.
The hepatic artery
heads in the direction of the liver and the
splenic artery passes towards the spleen.
The pancreatic body and tail can be
identified from this position.

Landmark 4: Confluence

+
ye Pancreatic
body

1. Confluence

2. Splenic vein

3. Pancreatic body

4. Pancreatic duct

5. Superior mesenteric artery
6. Liver

surgicalscience

The scope is
advanced slightly
farther below the
Celiac bifurcation.
Minor rotation of
the small dial to
the left and to the
right will reveal
the confluence of
the PV and SV. Torquing left and right
from tail toward the pancreatic neck
will enable a full examination of the
pancreatic duct and parenchyma.

GI Mentor


# Page 12

Endoscopic Ultrasound (EUS)
Tasks Module -
12
GI Mentor
Case 4 - Radial - Stomach Area
4
Landmark 5: Pancreatic Body
Landmark 6: Pancreatic Tail
1. Pancreatic body
2. Pancreatic duct
3. Splenic vein
1. Pancreatic tail
2. Pancreatic duct
3. Splenic vein
4. Left renal vein
5. Left renal artery
6. Left kidney
The scope is 
torqued clockwise 
to follow the 
pancreatic body 
and duct towards 
the pancreatic tail 
and spleen. The 
best landmark 
to identify the 
pancreatic body is the splenic vein 
bordering the posterior side of the 
pancreatic body appearing as a long, 
straight, tubular, anechoic structure.
Due to the scope 
deflection when 
torquing the 
scope clockwise 
the transducer 
will swing into 
the fundus area 
towards the 
pancreatic tail.


[TABLE]
|                                        |
|:---------------------------------------|
| Case 4 - Radial - Stomach Area         |
| 4                                      |
| Landmark 5: Pancreatic Body            |
| The scope is                           |
| torqued clockwise                      |
| to follow the                          |
| pancreatic body                        |
| and duct towards                       |
| the pancreatic tail                    |
| and spleen. The                        |
| best landmark                          |
| to identify the                        |
| pancreatic body is the splenic vein    |
| bordering the posterior side of the    |
| 1. Pancreatic body                     |
| pancreatic body appearing as a long,   |
| 2. Pancreatic duct                     |
| straight, tubular, anechoic structure. |
| 3. Splenic vein                        |

[OCR_TABLE]
Eno

[OCR]
Tasks Module -

Endoscopic Ultrasound (EUS)

Case 4 - Radial - Stomach Area

Landmark 5: Pancreatic Body

ete PD,
Pancreatic Body m=!

*syv

1. Pancreatic body
2. Pancreatic duct
3. Splenic vein

The scope is
torqued clockwise
to follow the
pancreatic body
and duct towards
the pancreatic tail
and spleen. The
best landmark

to identify the
pancreatic body is the splenic vein
bordering the posterior side of the
pancreatic body appearing as a long,
straight, tubular, anechoic structure.

Landmark 6: Pancreatic Tail

i BD
o. ‘Pancreatic tail

LRVY 4lk

tira

1. Pancreatic tail
2. Pancreatic duct
3. Splenic vein

4. Left renal vein
5. Left renal artery
6. Left kidney

surgicalscience

Due to the scope
deflection when
torquing the
scope clockwise
the transducer
will swing into
the fundus area
towards the
pancreatic tail.

GI Mentor


# Page 13

Endoscopic Ultrasound (EUS)
Tasks Module -
13
GI Mentor
Case 4 - Radial - Stomach Area
4
Landmark 7: Spleen
Landmark 8: Pancreatic Neck
1. Spleen
2. Splenic vein
3. Splenic hilum
1. Confluence
2. Splenic Vein
3. Superior mesenteric artery
4. Pancreatic neck
5. Pancreatic duct
The scope is 
torqued slightly 
further in the 
clockwise direction.
The scope 
is torqued 
counterclockwise 
back to the 
confluence. Once 
the confluence 
is observed, 
continuing to 
torque the scope 
counterclockwise enables viewing the 
pancreatic duct at 8 o’clock running 
around the portal vein towards the 
pancreatic head.


[TABLE]
| Tasks Module -                       |
|:-------------------------------------|
| Endoscopic Ultrasound (EUS)          |
| Case 4 - Radial - Stomach Area       |
| 4                                    |
| Landmark 7: Spleen                   |
| The scope is                         |
| torqued slightly                     |
| further in the                       |
| clockwise direction.                 |
| 1. Spleen                            |
| 2. Splenic vein                      |
| 3. Splenic hilum                     |
| Landmark 8: Pancreatic Neck          |
| The scope                            |
| is torqued                           |
| counterclockwise                     |
| back to the                          |
| confluence. Once                     |
| the confluence                       |
| is observed,                         |
| continuing to                        |
| torque the scope                     |
| counterclockwise enables viewing the |
| pancreatic duct at 8 o’clock running |
| 1. Confluence                        |
| around the portal vein towards the   |
| 2. Splenic Vein                      |
| pancreatic head.                     |
| 3. Superior mesenteric artery        |
| 4. Pancreatic neck                   |
| 5. Pancreatic duct                   |
| 13                                   |
| GI Mentor                            |

[OCR]
Tasks Module -

Endoscopic Ultrasound (EUS)

Case 4 - Radial - Stomach Area

Landmark 7: Spleen

The scope is
torqued slightly
further in the
clockwise direction.

Splenic hilum
+

sv
Spleen*

1. Spleen
2. Splenic vein
3. Splenic hilum

Landmark 8: Pancreatic Neck

The scope

is torqued
counterclockwise
back to the
confluence. Once
the confluence

is observed,
continuing to
torque the scope
counterclockwise enables viewing the
pancreatic duct at 8 o’clock running
around the portal vein towards the
pancreatic head.

1. Confluence

2. Splenic Vein

3. Superior mesenteric artery
4. Pancreatic neck

5. Pancreatic duct

surgicalscience GI Mentor


# Page 14

Endoscopic Ultrasound (EUS)
Tasks Module -
14
GI Mentor
Case 5 - Radial - 1st Duodenum Area
5
Landmark 1: Duodenal Bulb
Landmark 2: Stack Sign
1. Liver
2. Pancreatic head
3. Superior mesenteric vein
4. Pancreatic duct
1. Confluence
2. Portal vein
3. Pancreatic duct
4. Common bile duct
5. Pancreatic head
6. Liver
The scope is 
advanced under 
endoscopic view 
through the pylorus. 
The scope is then 
impacted into the 
narrow distal apex 
of the bulb and 
advanced forward 
without the scope’s tip advancing. This 
achieves long position of the scope, 
allowing for observation of the ampulla in 
the distal duodenal bulb.
When the stack 
sign is observed, 
torquing the scope 
counterclockwise 
enables following 
the CBD and PV 
to the liver. The 
pancreas body can 
be identified as 
the PV crosses it between the head and 
body of the pancreas. The pancreatic 
head is seen with the CBD and PD 
crossing towards the center of the 
screen. 


[TABLE]
|                                            |
|:-------------------------------------------|
| Case 5 - Radial - 1st Duodenum Area        |
| 5                                          |
| Landmark 1: Duodenal Bulb                  |
| The scope is                               |
| advanced under                             |
| endoscopic view                            |
| through the pylorus.                       |
| The scope is then                          |
| impacted into the                          |
| narrow distal apex                         |
| of the bulb and                            |
| advanced forward                           |
| without the scope’s tip advancing. This    |
| achieves long position of the scope,       |
| 1. Liver                                   |
| allowing for observation of the ampulla in |
| 2. Pancreatic head                         |
| the distal duodenal bulb.                  |
| 3. Superior mesenteric vein                |

[OCR_TABLE]
End

[OCR]
Tasks Module -

Endoscopic Ultrasound (EUS)

Case 5 - Radial - 1st Duodenum Area

Landmark 1: Duodenal Bulb

smu, SygPD

1. Liver

2. Pancreatic head

3. Superior mesenteric vein
4. Pancreatic duct

The scope is
advanced under
endoscopic view
through the pylorus.
The scope is then
impacted into the
narrow distal apex
of the bulb and
advanced forward
without the scope’s tip advancing. This
achieves long position of the scope,
allowing for observation of the ampulla in
the distal duodenal bulb.

Landmark 2: Stack Sign

Pancreatic
head

1. Confluence

2. Portal vein

3. Pancreatic duct
4. Common bile duct
5. Pancreatic head
6. Liver

surgicalscience

When the stack
sign is observed,
torquing the scope
counterclockwise
enables following
the CBD and PV

to the liver. The
pancreas body can
be identified as
the PV crosses it between the head and
body of the pancreas. The pancreatic
head is seen with the CBD and PD
crossing towards the center of the
screen.

GI Mentor


# Page 15

Endoscopic Ultrasound (EUS)
Tasks Module -
15
GI Mentor
Case 5 - Radial - 1st Duodenum Area
5
Landmark 3: Pancreatic Head & Neck
Landmark 4: Ampulla
1. Portal Vein
2. Splenic vein
3. Pancreatic neck
4. Pancreatic head
5. Pancreatic duct
6. Common bile duct
1. Common bile duct
2. Pancreatic duct
3. Ampulla
Torquing the scope 
clockwise will 
follow the CBD and 
PD distally towards 
the ampulla. The 
SV is seen entering 
the PV confluence 
and the genu of the 
pancreas can be 
observed.
In order to follow 
the PD and CBD 
into the papilla, the 
scope is deflected 
to the right, 
passing the genu. 
In real procedures, 
the balloon is filled 
with water in the 
genu area.


[TABLE]
| Case 5 - Radial - 1st Duodenum Area   |
|:--------------------------------------|
| Torquing the scope                    |
| clockwise will                        |
| follow the CBD and                    |
| PD distally towards                   |
| the ampulla. The                      |
| SV is seen entering                   |
| the PV confluence                     |
| and the genu of the                   |
| pancreas can be                       |
| observed.                             |

[OCR]
Tasks Module -

Endoscopic Ultrasound (EUS)

Case 5 - Radial - 1st Duodenum Area

Landmark 3: Pancreatic Head & Neck

Torquing the scope
clockwise will
follow the CBD and
PD distally towards
the ampulla. The
SV is seen entering
the PV confluence
and the genu of the
pancreas can be
observed.

1. Portal Vein

2. Splenic vein

3. Pancreatic neck
4. Pancreatic head
5. Pancreatic duct

6. Common bile duct

Landmark 4: Ampulla

In order to follow
the PD and CBD
into the papilla, the
scope is deflected
to the right,
passing the genu.
In real procedures,
the balloon is filled
with water in the
genu area.

1. Common bile duct
2. Pancreatic duct
3. Ampulla

surgicalscience GI Mentor


# Page 16

Endoscopic Ultrasound (EUS)
Tasks Module -
16
GI Mentor
Case 6 - Radial - 2nd & 3rd Duodenum Area
6
Landmark 1: Longitudinal Aorta
Landmark 2: Uncinate Process 1
1. Abdominal Aorta
2. Superior mesenteric artery
3. Superior mesenteric vein
1. Uncinate process
2. Abdominal aorta
3. Superior mesenteric vein
The scope is 
inserted to the 
3rd part of the 
duodenum similar 
to the technique 
used for ERCP. 
Minimal scope 
torquing to the left 
and to the right 
enables identification of the aorta in a 
vertically lengthened view on the left part 
of the screen.
Slight scope 
withdrawal will 
reveal the UNC at 
6 o’clock. The SMV 
is seen at 3 o’clock 
under the right side 
of the uncinate 
process.


[TABLE]
|                                             |
|:--------------------------------------------|
| Case 6 - Radial - 2nd & 3rd Duodenum Area   |
| 6                                           |
| Landmark 1: Longitudinal Aorta              |
| The scope is                                |
| inserted to the                             |
| 3rd part of the                             |
| duodenum similar                            |
| to the technique                            |
| used for ERCP.                              |
| Minimal scope                               |
| torquing to the left                        |
| and to the right                            |
| enables identification of the aorta in a    |
| vertically lengthened view on the left part |
| 1. Abdominal Aorta                          |
| of the screen.                              |
| 2. Superior mesenteric artery               |

[OCR_TABLE]
Ena

[OCR]
Tasks Module -

Endoscopic Ultrasound (EUS)

Case 6 - Radial - 2nd & 3rd Duodenum Area

Landmark 1: Longitudinal Aorta

1. Abdominal Aorta
2. Superior mesenteric artery
3. Superior mesenteric vein

The scope is
inserted to the

3rd part of the
duodenum similar
to the technique
used for ERCP.
Minimal scope
torquing to the left
and to the right
enables identification of the aorta ina
vertically lengthened view on the left part
of the screen.

Landmark 2: Uncinate Process 1

4h?

4uncinate process

ag OY

eH
*sMvie

1. Uncinate process
2. Abdominal aorta
3. Superior mesenteric vein

surgicalscience

Slight scope
withdrawal will
reveal the UNC at
6 o'clock. The SMV
is seen at 3 o'clock
under the right side
of the uncinate
process.

GI Mentor


# Page 17

Endoscopic Ultrasound (EUS)
Tasks Module -
17
GI Mentor
Case 6 - Radial - 2nd & 3rd Duodenum Area
6
Landmark 3: Uncinate Process 2
Landmark 4: Papilla
1. Uncinate process
2. Abdominal aorta
3. Superior mesenteric artery
4. Superior mesenteric vein
1. Common bile duct
2. Pancreatic duct
3. Ampulla
Further withdrawal 
of the scope around 
the 2nd-3rd genu 
will reveal the 
abdominal aorta in 
cross section. The 
SMA enters the 
view parallel to the 
SMV at 3 o’clock.
Scope is withdrawn 
to the papilla area 
until the CBD and 
the PD are seen in 
cross section at the 
pancreatic head 
Parenchyma.


[TABLE]
| Case 6 - Radial - 2nd & 3rd Duodenum Area   |
|:--------------------------------------------|
| Further withdrawal                          |
| of the scope around                         |
| the 2nd-3rd genu                            |
| will reveal the                             |
| abdominal aorta in                          |
| cross section. The                          |
| SMA enters the                              |
| view parallel to the                        |
| SMV at 3 o’clock.                           |

[OCR]
Tasks Module -

Endoscopic Ultrasound (EUS)

Case 6 - Radial - 2nd & 3rd Duodenum Area

Landmark 3: Uncinate Process 2

Further withdrawal
of the scope around
the 2nd-3rd genu
will reveal the
abdominal aorta in
cross section. The
SMA enters the
view parallel to the
0) SMV at 3 o'clock.

+42 ~~ {Uncinate process

SM A,

1. Uncinate process

2. Abdominal aorta

3. Superior mesenteric artery
4. Superior mesenteric vein

Landmark 4: Papilla

Scope is withdrawn
to the papilla area
until the CBD and
the PD are seen in
cross section at the
pancreatic head
Parenchyma.

1. Common bile duct
2. Pancreatic duct
3. Ampulla

surgicalscience GI Mentor


# Page 18

Endoscopic Ultrasound (EUS)
Tasks Module -
18
GI Mentor
Case 6 - Radial - 2nd & 3rd Duodenum Area
6
Landmark 5: Pancreatic Head
1. Pancreatic duct
2. Common bile duct
3. Pancreatic head
4. Superior mesenteric vein
5. Superior mesenteric artery
Scope is withdrawn 
around the superior 
genu enabling 
observation of the 
CBD and the PD in 
cross section at the 
pancreatic head; 
As the scope is 
withdrawn around 
the pancreatic head the SMV (closer to 
the pancreas), and the SMA are seen in 
cross section under the pancreas.


[TABLE]
|                                           |
|:------------------------------------------|
| Case 6 - Radial - 2nd & 3rd Duodenum Area |
| 6                                         |
| Landmark 5: Pancreatic Head               |
| Scope is withdrawn                        |
| around the superior                       |
| genu enabling                             |
| observation of the                        |
| CBD and the PD in                         |
| cross section at the                      |
| pancreatic head;                          |
| As the scope is                           |
| withdrawn around                          |
| the pancreatic head the SMV (closer to    |
| the pancreas), and the SMA are seen in    |
| 1. Pancreatic duct                        |
| cross section under the pancreas.         |
| 2. Common bile duct                       |

[OCR_TABLE]
End

[OCR]
Tasks Module -

Endoscopic Ultrasound (EUS)

Case 6 - Radial - 2nd & 3rd Duodenum Area

Landmark 5: Pancreatic Head

Scope is withdrawn
around the superior
genu enabling
observation of the
CBD and the PD in
cross section at the

SMA,
{SBD

pancreatic .
head pancreatic head;

As the scope is
withdrawn around
the pancreatic head the SMV (closer to
the pancreas), and the SMA are seen in
cross section under the pancreas.

1. Pancreatic duct

2. Common bile duct

3. Pancreatic head

4. Superior mesenteric vein
5. Superior mesenteric artery

surgical GI Mentor