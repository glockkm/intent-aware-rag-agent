

# Page 1

ENDO Suite - GI Mentor
 
Simulator
User Guide


[TABLE]
| ENDO Suite - GI Mentor   |
|:-------------------------|
| Simulator                |
| User Guide               |

[OCR]
User Guide

surgical


# Page 2

 
 
 
 
ENDO SUITE - GI MENTOR® 
User Guide 
 
 
 
March 2025 
 
 
11-GIUG-W0325 
 
 


[TABLE]
| E                        |
|                          |
|                          |
| NDO SUITE - GI MENTOR®   |
|:-------------------------|
| User Guide               |
| M                        |
| arch 2025                |
| 1                        |
|                          |
| 1-GIUG-W0325             |

[OCR]
ENDO SultE - GI MENTOR®

User Guide

March 2025

11-GIUG-W0325

surgicalscience


# Page 3

Contents
 
Page ii
 
Contents 
 
Chapter 1 
Safety Precautions .................................................................. 1 
Chapter 2 
ENDO Mentor Suite System ................................................... 4 
Hardware platform ...................................................................................... 4 
GI-BRONCH interchangeable cartridge ........................................................................ 6 
URO interchangeable cartridge ..................................................................................... 7 
Scope hanger................................................................................................................... 8 
Connecting the scope ..................................................................................................... 8 
Extensions ........................................................................................................................ 9 
Working positions ........................................................................................................... 11 
Height elevation mechanism ......................................................................................... 13 
Turning on the simulator ................................................................................................ 13 
Tool tray .......................................................................................................................... 14 
Foot switch ..................................................................................................................... 16 
Available endoscopes ............................................................................... 16 
Colonoscope ................................................................................................................... 17 
Duodenoscope ............................................................................................................... 18 
Auxiliary tools and connectors ................................................................ 19 
GI Mentor tools ............................................................................................................... 19 


[TABLE]
| Contents   |                                                                                                                                         |
|:-----------|:----------------------------------------------------------------------------------------------------------------------------------------|
| C          | Safety Precautions .................................................................. 1                                                 |
| hapter 1   |                                                                                                                                         |
| Chapter 2  | ENDO Mentor Suite System ................................................... 4                                                          |
|            | Hardware platform ...................................................................................... 4                              |
|            | GI-BRONCH interchangeable cartridge ........................................................................ 6                          |
|            | URO interchangeable cartridge ..................................................................................... 7                   |
|            | Scope hanger................................................................................................................... 8       |
|            | Connecting the scope ..................................................................................................... 8            |
|            | Extensions ........................................................................................................................ 9   |
|            | Working positions ........................................................................................................... 11        |
|            | Height elevation mechanism ......................................................................................... 13                 |
|            | Turning on the simulator ................................................................................................ 13            |
|            | Tool tray .......................................................................................................................... 14 |
|            | Foot switch ..................................................................................................................... 16    |
|            | Available endoscopes ............................................................................... 16                                 |
|            | Colonoscope ................................................................................................................... 17      |
|            | Duodenoscope ............................................................................................................... 18         |
|            | Auxiliary tools and connectors ................................................................ 19                                      |
|            | GI Mentor tools ............................................................................................................... 19      |

[OCR]
Contents

| Contents
Chapter 1 Safety Precautions .0..... ee eeccesccesseeseeceeceeeecseeceeeeeaeceeecsaeeeaeenaes 1
Chapter 2 ENDO Mentor Suite System... eceesceseceseeeseeeeeeeeeeeeee 4
Hardware platform uu... eececsccsscesceeseeeseceseeesecesecesceeseeeseeeeeeeeeeeeneeeseeeaeees 4

GI-BRONCH interchangeable cartridge

URO interchangeable Cartridge ........ es eesesssseseeseesceecseesseeeseeseseeseeseeeeseeaeeeeseeseeesseeaeaeees 7
SCOPE NANGEM...... ee eeeeeeessessescescescceseeeeeecseesecescescescsecseeeseeesesaesaeseeseeacaecaeeseeessesaeeaeeeaceaeeees 8
CONNECTING the SCOPE... eeeeceeseeseeeeseeseesescescescsecseeaeeeesesaceaeseeseeacseeaeeeeessesaeeaeeetaeeaeeees 8
EXteNSiONS ...... cece ccceceescseseceeecsesscessesesscssscsesssesscsesscecscsesssessesesssesecsesaeessssssseesessssaeases 9
WOKING POSITIONS... eee eseeeeseesetecseeeeeeeseeseseeseeaceaesecseeeesesseeaeseeseeaesecseeeseessetaeeatseeaeees 11
Height elevation MECHANISM...........eesesesecseeeeeeeeeeseeeesceaceccseeseeecsesaeeeseeseeaesesseeaeeesaeeaeee 13
TUPNING ON the SIMULACOM...... eee eeeeeeeceeeeeescescseeseeecseeseeeeseesceacsecseeeeeesseeaeeaeseeseeaeseeaeeese 13
TOOL tray oo... ceceseseesesseeseesecsecssccsecsecssesseeseessecsecesecsesseessecseseescsseseseseeseseaeseesaeeseseaseneseaeegs 14
FOOt SWITCH oo. cece ceec cece ceescseseceescseseseescsesssesscsesssssscsesssesessesseessesesseesecsesseeseeeeeaeeee 16

Available endoscopes
COIONOSCOPE...... eee eeseesseesceecseesseeeseeseeeseescacsceseacseeseeeeseesesaescesceacsacsecseassesaeaeseeseeacseeaeees® 17

DUOCENOSCOPE oe eeeeesceccseeseeeeseeseecescescesesecseeecseesesaeseeseaceacseeaeeecsesaeasseeseaesesaeeeseeeaeeaeee 18

Auxiliary tools and connectors

GI Mentor tOOIS oe eeeeeescesceecseceeeeeseeseeescesceacsecseeecsecsesaeseesceacsacseesseessesaeeeeseeaceaceeeaeeass 19

surgicalscience Page ii


# Page 4

Contents
 
Page iii
 
Chapter 3 
GI Mentor Express Platform ................................................. 21 
Hardware platform .................................................................................... 21 
Laptop setup .................................................................................................................. 22 
Simulator body and connectors ................................................................................... 25 
Connecting the sleeve .................................................................................................. 26 
Connecting the scope ................................................................................................... 28 
Scope.............................................................................................................................. 29 
Auxiliary tools and devices ........................................................................................... 30 
Chapter 4 
Getting Started ...................................................................... 32 
User interface ............................................................................................ 32 
Essential workflow .................................................................................... 32 
Chapter 5 
MentorLearn .......................................................................... 33 
MentorLearn overview .............................................................................. 33 
MentorLearn workflow ............................................................................. 33 
Logging in to MentorLearn on the simulator .......................................... 34 
Working locally and on a cloud site ............................................................................. 36 
Accessing a module or course within My Curricula or Library ............. 37 
Grid view of the Library ................................................................................................ 38 
Easy Access to courses and modules in the Library ................................................. 40 
Reviewing didactic materials ........................................................................................ 41 


[TABLE]
|           | Contents                                                                                                                               |
|:----------|:---------------------------------------------------------------------------------------------------------------------------------------|
| Chapter 3 | GI Mentor Express Platform ................................................. 21                                                        |
|           | Hardware platform .................................................................................... 21                              |
|           | Laptop setup .................................................................................................................. 22     |
|           | Simulator body and connectors ................................................................................... 25                   |
|           | Connecting the sleeve .................................................................................................. 26            |
|           | Connecting the scope ................................................................................................... 28            |
|           | Scope.............................................................................................................................. 29 |
|           | Auxiliary tools and devices ........................................................................................... 30             |
| Chapter 4 | Getting Started ...................................................................... 32                                              |
|           | User interface ............................................................................................ 32                         |
|           | Essential workflow .................................................................................... 32                             |
| Chapter 5 | MentorLearn .......................................................................... 33                                              |
|           | MentorLearn overview .............................................................................. 33                                 |
|           | MentorLearn workflow ............................................................................. 33                                  |
|           | Logging in to MentorLearn on the simulator .......................................... 34                                               |
|           | Working locally and on a cloud site ............................................................................. 36                   |
|           | Accessing a module or course within My Curricula or Library ............. 37                                                           |
|           | Grid view of the Library ................................................................................................ 38           |
|           | Easy Access to courses and modules in the Library ................................................. 40                                 |
|           | Reviewing didactic materials ........................................................................................ 41               |

[OCR]
Contents

Chapter 3 GI Mentor Express Platform ...........eccescessceseeseeeeeeeseeeseeeeees 21

Hardware platform... ceecccscesscceseeeseeeseceseeeseeeeeeseeeeeceeeeseeseeeeeeeeeaeeeeeenee 21

Chapter 4 = Getting Started... ec eeeeseesseceseeeceseceaeeeeeeeeeeeeeseeeaees 32
USP INCA CE oo. eee eeeeeeeeereeceeeseeseeesesseesecseesesseeeeeaecsesaeeaesaeeneeeeeateas 32
Essential WOrkfloW ou... sseseeseesceseesseseessesseesecseesessceeeeeecsesaeesesseeneeeeeeateas 32

Chapter 5 «= M@ttorLe@ arn... eee eeceseeseceseeeseeeseceseeesceeeceaeeeseeeeeeeeeseeeaees 33

MentorLearn overview

MentorLearn Workflow .........csesesesseseeesesseesecseeseseeeeseeeeesesaeeaeeseeseeeeeateas 33
Logging in to MentorLearn on the SiMUIatOF ........ eee eeeeeeeeeeeeeeeeeeeeeee 34
Working locally and On a CIOU Sit@ oo... eee seseeeeeceeeeeeeseeseeeesceaeacsecseeeseeeeeeteetaees 36
Accessing a module or course within My Curricula or Library.............. 37
Grid View Of the LIDrary oe eee eeseeseesceecseesceeeseeseseeseescacsecaeeacseeseeesseesesaeseeseeaeeeseees 38
Easy Access to courses and modules in the Library... eeseseeeeeeeteeeeeeeeeeeeeeees 40
Reviewing didactic Materials ......... cc eeseseeeeeeseeseeeeeesceecseeseeecsesseeeeseeseeacesseseeeeeeeeeees 41

surgicalscience Page iii


# Page 5

Contents
 
Page iv
 
Starting a simulation case or task ............................................................................... 42 
Viewing course/module completion status ................................................................. 44 
Chapter 6 
GI Mentor Display Modes ..................................................... 47 
Cyberscopy display mode ........................................................................ 47 
Screen layout ................................................................................................................. 47 
General features ............................................................................................................ 49 
General Endoscopy display mode ........................................................... 49 
Screen layout ................................................................................................................. 50 
General features and educational aids ....................................................................... 50 
Endoscopy and Fluoroscopy display mode ............................................ 57 
Screen layout ................................................................................................................. 57 
General features and educational aids ....................................................................... 58 
Working with fluoroscopy ............................................................................................. 58 
Endoscopy and Ultrasound display mode .............................................. 61 
Screen layout ................................................................................................................. 62 
General features and educational aids ....................................................................... 63 
Enhanced Clinical display mode .............................................................. 87 
Screen layout ................................................................................................................. 88 
General features and educational aids ....................................................................... 89 
Patient Management ..................................................................................................... 92 


[TABLE]
|           | Contents                                                                                                                           |
|:----------|:-----------------------------------------------------------------------------------------------------------------------------------|
|           | Starting a simulation case or task ............................................................................... 42              |
|           | Viewing course/module completion status ................................................................. 44                       |
| Chapter 6 | GI Mentor Display Modes ..................................................... 47                                                   |
|           | Cyberscopy display mode ........................................................................ 47                                |
|           | Screen layout ................................................................................................................. 47 |
|           | General features ............................................................................................................ 49   |
|           | General Endoscopy display mode ........................................................... 49                                      |
|           | Screen layout ................................................................................................................. 50 |
|           | General features and educational aids ....................................................................... 50                   |
|           | Endoscopy and Fluoroscopy display mode ............................................ 57                                             |
|           | Screen layout ................................................................................................................. 57 |
|           | General features and educational aids ....................................................................... 58                   |
|           | Working with fluoroscopy ............................................................................................. 58          |
|           | Endoscopy and Ultrasound display mode .............................................. 61                                            |
|           | Screen layout ................................................................................................................. 62 |
|           | General features and educational aids ....................................................................... 63                   |
|           | Enhanced Clinical display mode .............................................................. 87                                   |
|           | Screen layout ................................................................................................................. 88 |
|           | General features and educational aids ....................................................................... 89                   |
|           | Patient Management ..................................................................................................... 92        |

[OCR]
Contents

Starting a Simulation Case OF taSK oo... eeseeeeteeeeeeeeetseeeesceaceecseeseeeeeesesaeeeeseeaeeeeseees 42
Viewing course/Module COMpletion StatUS....... ce eeeeeeeeeseeeeeeeteeseeectecseeeseeeseteeeeteees 44
Chapter 6 Gl Mentor Display MOd@S............ccesccesceeseeeseeeseeeeeeeeeeeseeesees 47
Cyberscopy display MOC... ee ceceeseeesecsteceseceseceeeeeseceseseaeceseceaeseaeeeaeees 47
SCrEON LAYOUL... ee eeeeesceecseesceeceesseecsesseeaeseescacsecseeeeseesessesaeseeaceacsecaeeesseesesaseasseeaeeaeaeees 47
General features... ce cecnsceceesescececsessecscsesscecsesesssesessessessessesseesessesseeneeeees 49
General Endoscopy display MOde@ uu... ceceesessecesecsteceeeceeeeeseeeeeeaeeeaeees 49
SCrEON LAYOUL... ee eeeeesceecseesceeceesseecsesseeaeseescacsecseeeeseesessesaeseeaceacsecaeeesseesesaseasseeaeeaeaeees 50
General features and educational aids 0... eee eens ceceeseneeeteeseseseteeseeeeneeeees 50
Endoscopy and Fluoroscopy display MOde............eeeseeeseeeceeeeeeeeeeeeeeee 57
SCrEON LAYOUL... ee eeeeesceecseesceeceesseecsesseeaeseescacsecseeeeseesessesaeseeaceacsecaeeesseesesaseasseeaeeaeaeees 57
General features and educational aids 0... eee eens ceceeseneeeteeseseseteeseeeeneeeees 58
Working with flUOrOSCOPY.........eseessesesecsseseecesceeecescescsecseeeeseesesaecesceaceacseeseeeseeaeeasaeaees 58

Endoscopy and Ultrasound display mode
SCrEON LAYOUL... ee eeeeesceecseesceeceesseecsesseeaeseescacsecseeeeseesessesaeseeaceacsecaeeesseesesaseasseeaeeaeaeees 62

General features and Educational aids ..0..... cece eeseeseeeeeeesceeceecseeeeeecseseeeeeseeaeeecseens 63

Enhanced Clinical display mode

SCrEON LAYOUL... ee eeeeesceecseesceeceesseecsesseeaeseescacsecseeeeseesessesaeseeaceacsecaeeesseesesaseasseeaeeaeaeees 88
General features and Educational aids ..0..... cece eeseeseeeeeeesceeceecseeeeeecseseeeeeseeaeeecseens 89
Patient ManageMent......... ce eeessesseecesceseeeceeeeeecsesseseeseesceecsecseeeeseesesaesaeseeaceacseeeseeeseeaes 92

surgicalscience Page iv


# Page 6

Contents
 
Page v
 
Chapter 7 
Working with Endoscopic Tools .......................................... 97 
Working with tools .................................................................................... 97 
Working with tools requiring electrosurgical current ............................ 98 
Working with multiple tools and wires .................................................... 99 
Chapter 8 
Viewing Performance Reports ........................................... 103 
Overview .................................................................................................. 103 
Viewing reports ....................................................................................... 103 
Viewing additional information................................................................................... 106 
Viewing recorded videos .............................................................................................107 
Browsing between sessions ........................................................................................ 110 
Additional report types ............................................................................ 110 
Viewing user saved snapshots ................................................................................... 110 
Viewing performance playback .................................................................................. 111 
Understanding the scoreboard ................................................................................... 112 
Understanding benchmarks and rating scales .......................................................... 114 
Understanding learning curve graphs ........................................................................ 115 
Exporting performance results ............................................................... 116 
Chapter 9 
Technical Support ................................................................ 118 
SURGICAL SCIENCE SUPPORT POLICY .................................................................... 118 
Surgical Science Call Center ....................................................................................... 118 


[TABLE]
|           | Contents                                                                                                                 |
|:----------|:-------------------------------------------------------------------------------------------------------------------------|
| Chapter 7 | Working with Endoscopic Tools .......................................... 97                                              |
|           | Working with tools .................................................................................... 97               |
|           | Working with tools requiring electrosurgical current ............................ 98                                     |
|           | Working with multiple tools and wires .................................................... 99                            |
| Chapter 8 | Viewing Performance Reports ........................................... 103                                              |
|           | Overview .................................................................................................. 103          |
|           | Viewing reports ....................................................................................... 103              |
|           | Viewing additional information................................................................................... 106    |
|           | Viewing recorded videos .............................................................................................107 |
|           | Browsing between sessions ........................................................................................ 110   |
|           | Additional report types ............................................................................ 110                 |
|           | Viewing user saved snapshots ................................................................................... 110     |
|           | Viewing performance playback .................................................................................. 111      |
|           | Understanding the scoreboard ................................................................................... 112     |
|           | Understanding benchmarks and rating scales .......................................................... 114                |
|           | Understanding learning curve graphs ........................................................................ 115         |
|           | Exporting performance results ............................................................... 116                        |
| Chapter 9 | Technical Support ................................................................ 118                                   |
|           | SURGICAL SCIENCE SUPPORT POLICY .................................................................... 118                 |
|           | Surgical Science Call Center ....................................................................................... 118 |

[OCR]
Contents

Chapter 7 = Working with Endoscopic Tools ..........cccecesceeseeeeeeeereeeeeeeees 97
WOKING With tOOIS ........eeeeesceeseceseceseeeseceseceseeeseceseceseeeseeeaeeeaeeeseeeeeeeeeaees 97
Working with tools requiring electrosurgical CUITeNT ...........eeeeeeeeeeeee 98

Working with multiple tools and wires...

Chapter 8 Viewing Performance Reports... eeesesseeseeteeeeeeeeeeee 103
OVEIVICW 0... eee eeesceseesceeesceseessesseeseeseesecscesescesseaeeaecseesesscessesaeeaeeaeensesnene® 103
VIQWING FEPOTtS oe. eeeeeeesccesceeseeesceesceeseeeseceseeeeeeseceseeeaeeeaeeeseeeaeeeaeeeaes 103

Viewing additional information. ..........ccceeeesessesseeceeescteceeeeeeceeseseeseeseeeceecseeeeeeeseeeeee 106
VIEWING FECOPdEd VIGEOS...... ee eeeeeseescsecsseseeeescesceescesceecseeseeeeseeseeacseeseeaceacseenseeeaeeaeatees 107
BrowSing DeEtWEEN SESSIONS..........eececeseeeeteeeeseeeeseesecesceacsecseeaeeessesaeeaeseeseeacesseeeeeeee 110

Additional report types

Viewing USEF SAVE SNAPSNOTS «00... ee eeeeeeeeseeeeeeecesceecseeseeesecseseeseeseeaeeecseeeseeeseeaeeatees 110
Viewing performance playback ....... see eesesesceceeeeseeeceecseeeeseeseeecsecseeaeeeeseenseecaeeaeeateee 111
Understanding the SCOreDOAard...... ee eeseeeseesseseeeeseeseeeescescseeseeaeeessecaeeaeseeseeaceeaeeeeeeees 112
Understanding benchmarks and rating SCAlCS.......... ee eeseeeeseeseeeeeeeseeeeeeesceaceeaeeneeees 114

Understanding learning curve graphs...

Exporting performance results 00... eecceeseeeeeseceeeeeeeeceeeeseeeeeeeteeeseeeeeeees 116
Chapter 9 = Technical SUPPOMF th... eee eee eeceeseeeneeeeeeseeeeeeseeeeeeeeeeeaes 118
SURGICAL SCIENCE SUPPORT POLICY ......sscsssesssssseesseesseesneesncesueecasesneesnsenneenseensrees 118
Surgical Science Call Center... ee cessesesscescescsecseeeceecseseeeeesceaceecsecaeeeeseseeeaeeeeseeaeeees 118

surgicalscience Page v


# Page 7

Contents
 
Page vi
 
Chapter 10 
End-User Software License Agreement ............................ 119 
GI Mentor® ..................................................................................................................... 119 
1  EXTENT OF LICENSE ................................................................................................ 119 
2  CONFIDENCE OF THE SOFTWARE AND COPYRIGHT ......................................... 120 
3  OWNERSHIP OF SOFTWARE .................................................................................. 121 
4  SUPPORT SERVICES ................................................................................................ 121 
5  INTEGRITY OF THE SOFTWARE ............................................................................ 122 
6  RIGHT OF ACCESS .................................................................................................. 122 
7  WARRANTY AND LIMITATION OF LIABILITY ........................................................ 123 
8  TERMINATION ......................................................................................................... 124 
9.  MISCELLANEOUS ................................................................................................... 125 
Index ............................................................................................................ 126 
 
 


[TABLE]
|                                                                                                                        | Contents                                                                                                                             |
|:-----------------------------------------------------------------------------------------------------------------------|:-------------------------------------------------------------------------------------------------------------------------------------|
| Chapter 10                                                                                                             | End-User Software License Agreement ............................ 119                                                                 |
|                                                                                                                        | GI Mentor® ..................................................................................................................... 119 |
|                                                                                                                        | 1  EXTENT OF LICENSE ................................................................................................ 119            |
|                                                                                                                        | 2  CONFIDENCE OF THE SOFTWARE AND COPYRIGHT ......................................... 120                                            |
|                                                                                                                        | 3  OWNERSHIP OF SOFTWARE .................................................................................. 121                      |
|                                                                                                                        | 4  SUPPORT SERVICES ................................................................................................ 121             |
|                                                                                                                        | 5  INTEGRITY OF THE SOFTWARE ............................................................................ 122                        |
|                                                                                                                        | 6  RIGHT OF ACCESS .................................................................................................. 122            |
|                                                                                                                        | 7  WARRANTY AND LIMITATION OF LIABILITY ........................................................ 123                                 |
|                                                                                                                        | 8  TERMINATION ......................................................................................................... 124         |
|                                                                                                                        | 9.  MISCELLANEOUS ................................................................................................... 125            |
| Index ............................................................................................................ 126 |                                                                                                                                      |

[OCR]
Contents

Chapter 10 End-User Software License Agreemenrt.............:ceeeeeeeeee 119
GI MONtOr? eee eeeeeceetesesesescseeessseeesesnscssesessscscscssscscasacecseseessnsesesusseusssscscsceescacasaceeanaes 119
1 EXTENT OF LICENSE........sssessssssseessessnserseesseecnseessessscssscesnessncesecesueesnsesneecesenneenseeeseees 119
2 CONFIDENCE OF THE SOFTWARE AND COPYRIGHT.......:sssssssesseeseeecseeeseeeseeeeee 120
3 OWNERSHIP OF SOFTWARE .......csssesssesssessseeseeesecesecesueesusesnsesurecnsensessesneeeseeesneesess 121
4. SUPPORT SERVICES........ssssssssssssesesesnsesseesseecseesessecnseessessecesecesueesuserseeceeeeneenseesseees 121

5 INTEGRITY OF THE SOFTWARE...

6 RIGHT OF ACCESS... eeesesceccsseeeseeseescssesceseeecsceseeseeeseeacacsceaceecsecseeeseesesaeeasseeaeees 122
7 WARRANTY AND LIMITATION OF LIABILITY ....c..ssccssecssesssecsssssseecsnccssecsseceseceneenses 123
& TERMINATION .......scscsessssecssecssecssscessecssccssecssecsseconecsuecesscesscsusecssecsnecsneessecsneceseeessesses 124
9. MISCELLANEOUS. .....cccssssssecssesssssssscsssecssecsnecssecsuecsuscesscesscesscessecsuecauecsuessneceseeenenses 125
MINOX oo. eeeeseeececseccescesseeesecesecesecsaecaeceseceaeceaeseaeceaeceseeeaeceaeceaeseaeceaeeeaeeeaeeeaeesaes 126

surgicalscience Page vi


# Page 8

Figures
 
Page vii
 
Figures 
 
Figure 2-1: ENDO Mentor Suite - GI Mentor platform ......................................................... 5 
Figure 2-2: GI-BRONCH interchangeable cartridge – lower orifice selected ................... 6 
Figure 2-3: URO interchangeable cartridge ......................................................................... 7 
Figure 2-4: Scope hanger – GI scopes ................................................................................. 8 
Figure 2-5: System and scope connectors .......................................................................... 9 
Figure 2-6: GI modality extension ......................................................................................... 9 
Figure 2-7: URO modality extension .................................................................................... 10 
Figure 2-8: GI extension fully opened (left), URO extension fully opened (right) ........... 11 
Figure 2-9: GI Mentor working position .............................................................................. 12 
Figure 2-10: Height elevation panel – (from left to right) USB port, Height Elevation 
mechanism, Computer On/Off button ................................................................................. 13 
Figure 2-11: Tool tray hanger with GI tools ......................................................................... 14 
Figure 2-12: Tool connection outlets ................................................................................... 15 
Figure 2-13: Foot switch ....................................................................................................... 16 
Figure 2-14: Colonoscope .................................................................................................... 17 
Figure 2-15: Duodenoscope ................................................................................................. 18 
Figure 2-16: Master Tool....................................................................................................... 19 
Figure 3-1: GI Mentor Express platform .............................................................................. 21 
Figure 3-2: Laptop on stand ................................................................................................ 22 
Figure 3-3: Connecting the laptop ..................................................................................... 23 
Figure 3-4: Adjusting the stand .......................................................................................... 24 
Figure 3-5: Simulator body connections ............................................................................ 25 
Figure 3-6: Connecting the sleeve ..................................................................................... 27 
Figure 3-7: System side and scope side connectors........................................................ 28 
Figure 3-8: GI Mentor Express scope ................................................................................. 29 


[TABLE]
| Figures                                                                                                                             |
|:------------------------------------------------------------------------------------------------------------------------------------|
| Figures                                                                                                                             |
| F                                                                                                                                   |
| igure 2-1: ENDO Mentor Suite - GI Mentor platform ......................................................... 5                       |
| Figure 2-2: GI-BRONCH interchangeable cartridge – lower orifice selected ................... 6                                      |
| Figure 2-3: URO interchangeable cartridge ......................................................................... 7               |
| Figure 2-4: Scope hanger – GI scopes ................................................................................. 8            |
| Figure 2-5: System and scope connectors .......................................................................... 9                |
| Figure 2-6: GI modality extension ......................................................................................... 9       |
| Figure 2-7: URO modality extension .................................................................................... 10          |
| Figure 2-8: GI extension fully opened (left), URO extension fully opened (right) ........... 11                                     |
| Figure 2-9: GI Mentor working position .............................................................................. 12            |
| Figure 2-10: Height elevation panel – (from left to right) USB port, Height Elevation                                               |
| mechanism, Computer On/Off button ................................................................................. 13              |
| Figure 2-11: Tool tray hanger with GI tools ......................................................................... 14            |
| Figure 2-12: Tool connection outlets ................................................................................... 15         |
| Figure 2-13: Foot switch ....................................................................................................... 16 |
| Figure 2-14: Colonoscope .................................................................................................... 17    |
| Figure 2-15: Duodenoscope ................................................................................................. 18      |
| Figure 2-16: Master Tool....................................................................................................... 19  |
| Figure 3-1: GI Mentor Express platform .............................................................................. 21            |
| Figure 3-2: Laptop on stand ................................................................................................ 22     |
| Figure 3-3: Connecting the laptop ..................................................................................... 23          |
| Figure 3-4: Adjusting the stand .......................................................................................... 24       |
| Figure 3-5: Simulator body connections ............................................................................ 25              |
| Figure 3-6: Connecting the sleeve ..................................................................................... 27          |
| Figure 3-7: System side and scope side connectors........................................................ 28                        |
| Figure 3-8: GI Mentor Express scope ................................................................................. 29            |

[OCR]
Figures

| Figur

es

Figure 2-1: ENDO Mentor Suite - Gl Mentor platform... eeseceseeseeeeeeseeeeeeeseeseeeeseeeeeeees 5
Figure 2-2: GI-BRONCH interchangeable cartridge — lower orifice selected ..............00 6
Figure 2-3: URO interchangeable Cartridge... eeeeseesceceeeeeeecteeseeeeeeeseeeeeeeseeaceecseeeeeeees 7
Figure 2-4: Scope Nanger — Gl SCOPES... eesesseceseeeeeeseesceecscesceecseeseeeeseeaceaceecseeaseeseeeeeneee 8
Figure 2-5: System and SCOPE CONNECHOMS........ceeeseseeeeseeseeeeeceseeececseeeeeesceaceeseeaseecaeeesenees 9
Figure 2-6: Gl modality Extension... ecseseesceecseeseseeseesceeceeseeececseseeeeseeaeeeseeaceesseeeeeeees 9

Figure 2-7:
Figure 2-8: GI extension fully opened (left), URO extension fully opened (right)..
Figure 2-9: GI Mentor working position

Figure 2-

mechanism, Computer On/Off DUttON 0... eee eeeeeeeeseeeeeeeeeeseseeseeacsecseeeeseesesaeeeeseeseeaeseeneenes 13

Figure 2-

Figure 2-

Figure 2-

Figure 2-

Figure 2-

Figure 2-1

URO modality Extension... eeeeesceseesceecseceeseeeesceecseeseeeceeeseseeseeseseeeerseeaeees 10

0: Height elevation panel - (from left to right) USB port, Height Elevation

1: Tool tray hanger With Gl tOOIS 0... ee eeeeseseeeeeeteceeseeseeseeeceeseeaseeeseeeeeeeseeaeee 14

2: Tool connection outlets...

3: Foot switch...

4: Colonoscope

5: Duodenoscope....
6: Master TOI... eeececscesceseeecsessesecsesseseesceaceecsecseeeesesaeaeseesceaceesseeeseeesesaeeerseeaeeee 19

Figure 3-1: GI Mentor Express platform ........ cei eesesesseseeseesceecseeeseecseeeeeeeseesceecseeaeeaseeeeeeees 21
Figure 3-2: Laptop ON Stand... eee eeeeeseeseeseeeeseeeceecseeseseeseesceecseeseeecsecsseesseesesaeeetseeaceeseeees 22
Figure 3-3: Connecting the laptop ....... ee eeseeseecctecsseseeeesessceecseeaceecseeseeeeeesesaeeerseeaeeeseees 23
Figure 3-4: Adjusting the Stand ou... eeseeesceseeeceecseeseeeeseesceecseeaeeecsecseeeeseesesaeeesseeaseesseees 24
Figure 3-5: Simulator Dody CONNECtIONS ....... elects ess eseeeeseeeceeeseesceecseeeeeeeeeseeaeeeeseeaseesseees 25
Figure 3-6: Connecting the SlC@VEC oe eeeeeseeseecctecsseseeeescescecseeaceecseeseeasseeseeaesesseeaseeseeees 27

Figure 3-7:

System side and Scope SIdE CONNECHOSS........ cc eeeeeeeeseeeeeeeseeececeaeeeeeeeseeeeeeeees 28

Figure 3-8: Gl Mentor Express SCOPC....... ce eeseeseesceecsseseeeescesceecsceaceecseeseeesseesesaeseeseeaseeaeees 29

surgicalscience Page vii


# Page 9

Figures
 
Page viii
 
Figure 3-9: Master Tool inserted into the work channel .................................................. 30 
Figure 3-10: Foot switch ....................................................................................................... 31 
Figure 6-1: MentorLearn Login screen ............................................................................... 34 
Figure 5-1: My Curricula screen .......................................................................................... 37 
Figure 5-2: GI Mentor Library screen ................................................................................. 38 
Figure 6-3: Library in grid view ........................................................................................... 39 
Figure 5-3: Opening a module ............................................................................................. 41 
Figure 5-4: Task description ............................................................................................... 44 
Figure 5-5: Completion status for modules/courses with benchmarks .......................... 45 
Figure 5-6: Completion status for cases/tasks with benchmarks ................................... 45 
Figure 5-7: Required Skill Level information ...................................................................... 46 
Figure 6-1: Cyberscopy screen- EndoBubble .................................................................... 48 
Figure 6-2: Cyberscopy screen – EndoBasket .................................................................. 48 
Figure 6-3: General Endoscopy screen .............................................................................. 50 
Figure 6-4: Primary view – General Endoscopy display mode ......................................... 51 
Figure 6-5: Full Screen view ................................................................................................ 52 
Figure 6-6: External 3D Map – General Endoscopy display mode .................................. 53 
Figure 6-7: Interactive Map ................................................................................................. 54 
Figure 6-8: Virtual Instructor alert ...................................................................................... 55 
Figure 6-9: Virtual Instructor comment .............................................................................. 55 
Figure 6-10: Endoscopy and Fluoroscopy screen ............................................................. 57 
Figure 6-11: Fluoroscopic image ......................................................................................... 59 
Figure 6-12: Fluoroscopic View Controls in the fluoroscopic display ............................. 60 
Figure 6-13: Endoscopy and Ultrasound screen ............................................................... 62 
Figure 6-14: Landmark instructions and anticipated capture .......................................... 63 
Figure 6-15: Zoom panel ...................................................................................................... 65 
Figure 6-16: Region sub-panel ............................................................................................ 66 


[TABLE]
| Figures                                                                                                                             |
|:------------------------------------------------------------------------------------------------------------------------------------|
| Figure 3-9: Master Tool inserted into the work channel .................................................. 30                        |
| Figure 3-10: Foot switch ....................................................................................................... 31 |
| Figure 6-1: MentorLearn Login screen ............................................................................... 34             |
| Figure 5-1: My Curricula screen .......................................................................................... 37       |
| Figure 5-2: GI Mentor Library screen ................................................................................. 38           |
| Figure 6-3: Library in grid view ........................................................................................... 39     |
| Figure 5-3: Opening a module ............................................................................................. 41       |
| Figure 5-4: Task description ............................................................................................... 44     |
| Figure 5-5: Completion status for modules/courses with benchmarks .......................... 45                                     |
| Figure 5-6: Completion status for cases/tasks with benchmarks ................................... 45                                |
| Figure 5-7: Required Skill Level information ...................................................................... 46              |
| Figure 6-1: Cyberscopy screen- EndoBubble .................................................................... 48                   |
| Figure 6-2: Cyberscopy screen – EndoBasket .................................................................. 48                    |
| Figure 6-3: General Endoscopy screen .............................................................................. 50              |
| Figure 6-4: Primary view – General Endoscopy display mode ......................................... 51                              |
| Figure 6-5: Full Screen view ................................................................................................ 52    |
| Figure 6-6: External 3D Map – General Endoscopy display mode .................................. 53                                  |
| Figure 6-7: Interactive Map ................................................................................................. 54    |
| Figure 6-8: Virtual Instructor alert ...................................................................................... 55      |
| Figure 6-9: Virtual Instructor comment .............................................................................. 55            |
| Figure 6-10: Endoscopy and Fluoroscopy screen ............................................................. 57                      |
| Figure 6-11: Fluoroscopic image ......................................................................................... 59        |
| Figure 6-12: Fluoroscopic View Controls in the fluoroscopic display ............................. 60                                |
| Figure 6-13: Endoscopy and Ultrasound screen ............................................................... 62                     |
| Figure 6-14: Landmark instructions and anticipated capture .......................................... 63                            |
| Figure 6-15: Zoom panel ...................................................................................................... 65   |
| Figure 6-16: Region sub-panel ............................................................................................ 66       |

[OCR]
Figures

Figure 3-9: Master Tool inserted into the work Channel ..........ccsesceeseeeeeeeeeeeeeeeeeeeeeeeeeee 30

Figure 3-10: Foot SWitCH...... eee eeeeseseseeseesceecseesseecseeaeseeseesceacsecseeassecsesaeseeseeaeeasseeaseaseeeneeess 31

Figure 6-1: MentorLearn Login screen
Figure 5-1: My Curricula screen.....
Figure 5-2: GI Mentor Library screen..
Figure 6-3: Library in grid view..
Figure 5-3: Opening a module
Figure 5-4: Task description ...

Figure 5-5: Completion status for modules/courses with benchmarks .45
Figure 5-6: Completion status for cases/tasks with benchmarks.. .45
Figure 5-7: Required Skill Level information... 46
Figure 6-1: Cyberscopy screen- ENdOBUDDIE.......... ee eeseeeceeeeeeseeeceeceeeeeeeeseeeceecseeaseeeeeees 48
Figure 6-2: Cyberscopy screen — EndoBasket .........seeeeeesessceseseesceeceecseeeeeeeseeeceecseeaseeeeeees 48
Figure 6-3: General ENdOSCOPY SCrEEN LQ... eeseeeeeesseseeeeseesceeesceaceecseeaseeeseeseeaeetseeaceeeseees 50
Figure 6-4: Primary view — General Endoscopy display MOde ......... ce eseesseeeeeeteeeeteeeeeees 51
Figure 6-5: Full SCree@n ViQW....... eee seeecescsseeseeecscesceeseeseseeseescaesceaceecsecsseessesaesaesesseeaceasaeees 52
Figure 6-6: External 3D Map — General Endoscopy display Mode ...........ceseeeeseeteeeeeeeee 53
Figure 6-7: Interactive Map uu... eee seeseseseeseseesceececsseseeescescacseeaeeecsesseeesseesesacasseeaseeseeees 54
Figure 6-8: Virtual Instructor alert oc eeeeeeeeseesceecseeseeeeseeececsceaseecsecseeeeeesesaeesseeaseeeeeees 55
Figure 6-9: Virtual INstrUCtor COMMENT ........ eee eseeeeecsseseeeeseeececeseeaceecseeseeeeeesesecseeseeaseeseeees 55
Figure 6-10: Endoscopy and FIUOrOSCOpPy SCFEEN........eeeeeeeceseseeseeeeeecseeeeeeeseeececseeaseeeeeees 57
Figure 6-11: FIUOFOSCOPIC IMAGE ........ ee eeeesseeeeseeseeeceeeseeseeeeseescscesceseecseeseeeceeseeaeesseeaseaseeees 59
Figure 6-12: Fluoroscopic View Controls in the fluoroscopic display ............ cece 60
Figure 6-13: Endoscopy and Ultrasound SCreeN.........eecesesseeceeeeseeeceeeseeeeeeeseeeeeeeeeeaseeeeeees 62
Figure 6-14: Landmark instructions and anticipated Capture ........ ee eeeeeeeeeeeeeteeeeeeeeeee 63
Figure 6-15: ZOOM Panel... eseseeesssseeceseescecescesceececseseeeeseesceacsceaceecsesseeeeeeseseceesseeaseesaeees 65
Figure 6-16: Region SUD-Panel uu... eeeeeesesseeseseeceeceecseeseseescesceeseeaseecsecseeessessesaesetseeacesaeees 66

surgicalscience Page viii


# Page 10

Figures
 
Page ix
 
Figure 6-17: Freeze panel .................................................................................................... 68 
Figure 6-18: Characters sub-panel ..................................................................................... 69 
Figure 6-19: Anatomical labels and measurement on Ultrasound display ...................... 70 
Figure 6-20: Caliper sub-panel ............................................................................................ 71 
Figure 6-21: Save Image sub-panel .................................................................................... 73 
Figure 6-22: Browse Images sub-panel ............................................................................. 74 
Figure 6-23: Helpers panel .................................................................................................. 75 
Figure 6-24: Automatic labeling .......................................................................................... 76 
Figure 6-25: Color contour of organs on Ultrasound display........................................... 77 
Figure 6-26: Organs colored on the Ultrasound display .................................................. 78 
Figure 6-27: Filter sub-panel ............................................................................................... 79 
Figure 6-28: Selective organs display on 3D Map and Coloring option ......................... 80 
Figure 6-29: Linear Ultrasound ............................................................................................ 81 
Figure 6-30: Radial Ultrasound ........................................................................................... 82 
Figure 6-31: Settings panel ................................................................................................. 82 
Figure 6-32: 3D Map display in focus ................................................................................ 83 
Figure 6-33: Ultrasonography beam on 3D Map .............................................................. 84 
Figure 6-34: 3D Map controls panel ................................................................................... 85 
Figure 6-35: Pan controls .................................................................................................... 85 
Figure 6-36: Filter sub-panel .............................................................................................. 87 
Figure 6-37: Enhanced Clinical Display Mode screen layout ........................................... 88 
Figure 6-38: Primary View - Enhanced Clinical display mode ......................................... 89 
Figure 6-39: 3D Map – Enhanced Clinical display mode .................................................. 90 
Figure 6-40: Image Enhancement Mode ............................................................................. 91 
Figure 6-41: Paris Classification list .................................................................................... 92 
Figure 6-42: Patient Management panel ........................................................................... 93 
Figure 6-43: Vital signs deviation alert .............................................................................. 94 


[TABLE]
| Figures                                                                                                                           |
|:----------------------------------------------------------------------------------------------------------------------------------|
| Figure 6-17: Freeze panel .................................................................................................... 68 |
| Figure 6-18: Characters sub-panel ..................................................................................... 69        |
| Figure 6-19: Anatomical labels and measurement on Ultrasound display ...................... 70                                    |
| Figure 6-20: Caliper sub-panel ............................................................................................ 71    |
| Figure 6-21: Save Image sub-panel .................................................................................... 73         |
| Figure 6-22: Browse Images sub-panel ............................................................................. 74             |
| Figure 6-23: Helpers panel .................................................................................................. 75  |
| Figure 6-24: Automatic labeling .......................................................................................... 76     |
| Figure 6-25: Color contour of organs on Ultrasound display........................................... 77                          |
| Figure 6-26: Organs colored on the Ultrasound display .................................................. 78                       |
| Figure 6-27: Filter sub-panel ............................................................................................... 79  |
| Figure 6-28: Selective organs display on 3D Map and Coloring option ......................... 80                                  |
| Figure 6-29: Linear Ultrasound ............................................................................................ 81    |
| Figure 6-30: Radial Ultrasound ........................................................................................... 82     |
| Figure 6-31: Settings panel ................................................................................................. 82  |
| Figure 6-32: 3D Map display in focus ................................................................................ 83          |
| Figure 6-33: Ultrasonography beam on 3D Map .............................................................. 84                     |
| Figure 6-34: 3D Map controls panel ................................................................................... 85         |
| Figure 6-35: Pan controls .................................................................................................... 85 |
| Figure 6-36: Filter sub-panel .............................................................................................. 87   |
| Figure 6-37: Enhanced Clinical Display Mode screen layout ........................................... 88                          |
| Figure 6-38: Primary View - Enhanced Clinical display mode ......................................... 89                           |
| Figure 6-39: 3D Map – Enhanced Clinical display mode .................................................. 90                        |
| Figure 6-40: Image Enhancement Mode ............................................................................. 91              |
| Figure 6-41: Paris Classification list .................................................................................... 92    |
| Figure 6-42: Patient Management panel ........................................................................... 93              |
| Figure 6-43: Vital signs deviation alert .............................................................................. 94        |

[OCR]
Figures

Figure 6-17:
Figure 6-18:
Figure 6-19:
Figure 6-20:
Figure 6-21:
Figure 6-22:
Figure 6-23:
Figure 6-24:
Figure 6-25:
Figure 6-26:
Figure 6-27:
Figure 6-28:
Figure 6-29:
Figure 6-30:
Figure 6-31:
Figure 6-32:
Figure 6-33:
Figure 6-34:
Figure 6-35:
Figure 6-36:
Figure 6-37:
Figure 6-38:
Figure 6-39:
Figure 6-40:
Figure 6-41:
Figure 6-42:
Figure 6-43:

FrO@Ze Panel ......sceescecscececcsecseseeeesceececscescecseeeeeeseeseeecseeaeeesseeseeeeeeeaeeeeeeeees 68
Characters SUD-Panel...... eee eeeeeseescesceecseesceecseeeeeeeseesceececeaseeceeeeeeesesseeeeeeeees 69
Anatomical labels and measurement on Ultrasound display.............ee 70
Caliper SUD-Panel 0... eeeseescseeeecceecseseeseesceacsecseeaseecseeseseeseeaceecsecseeeseeseees 71

Save Image sub-panel

Browse Images sub-panel..

Helpers panel

Automatic labeling... eeseeeeceseesceecseeseseeseesceecsceseeesseeseeeeseesesaeasseeaeeeeaeees 76
Color contour of organs on Ultrasound display......... cee eeeeeseeseeeeteeeeeeeeeee 77
Organs colored on the Ultrasound display .......... cs eeeeeeeeseecceeeeeeeeeeneeeeeeeees 78
Filter SUD-PANE|l oo... eee eee seesceseeceseeecsecseeeeseeseeacsecseeaceacsecseseeseeseeacaeseeaseeseeees 79
Selective organs display on 3D Map and Coloring option .......... eee 80
Linear UltraSOUN oo... eee cece cece ceescseseceescseneseescsesesenscsesssenseseeeseneeseeees 81

Radial UltraSOUN ou... cece ce cesses cseseceescseseseescseesenscsesssensessssenseseeeeenees 82
Se@ttINgS PANe| .0.. eee eeseesceeceeeseeeeeecseeseeeeseeseeacseesceecseeseseeeeseeseeeeseeaeeeseeees 82
3D Map display in FOCUS ...... eee eseeeeseeeesceecsceececseeeeseeseeacacseeaseesseeeeensseeaes 83
Ultrasonography beam On 3D Ma Pp ........eeeeseeeeeeseeseesceeeseeeceecseeeeeneseteeeeeeees 84
3D Map Controls Panel... eeecesesseeccecessesceecsseeeeeeseesceeceeeseeeceeeseeseeeaeeaeeeteees 85

Pan CONtIOIS ..... eee eseceeeseesseseesseesecesscsecssesseeseeseecseceesesecsesesesseeeesaseaesesseneeaees

Filter sub-panel

Enhanced Clinical Display Mode screen layout..

Primary View - Enhanced Clinical display mode

3D Map — Enhanced Clinical display Mode... eeeeesceseeeeteceeeeeeeeeeeeceeeeees 90
Image Enhancement Mode... cee esceessesseesecseceeccsecsessseseeseesseesesesseseseeeeaees 91
Paris Classification list... ccc scceceseessceescsesecesscsesecesscsesesenseseseseneeseeeees 92
Patient Management Panel .0....... ee eeeeseeeeeeseeeeeeeeeseeeesceacecsecseeeseeeseteteeteees 93

Vital SIGNs deviation Alert ...... eee eeeeeseeeesecsceeceeceeeeseeseesceecseeaseeseeeseeesseeaes 94

surgicalscience Page ix


# Page 11

Figures
 
Page x
 
Figure 6-44: Checking consciousness ............................................................................... 94 
Figure 6-45: Moderate sedation – sedative selection ...................................................... 96 
Figure 6-46: Administered Sedatives list ........................................................................... 96 
Figure 7-1: Tools menu ........................................................................................................ 97 
Figure 7-2: Electrosurgical settings (and polyp extraction) in Enhanced Clinical display 
mode ...................................................................................................................................... 98 
Figure 7-3: Electrosurgical settings for the Endoscopy and Fluoroscopy display mode
 ................................................................................................................................................ 99 
Figure 7-4: Guide wire ....................................................................................................... 100 
Figure 7-5: Stent selection menu ....................................................................................... 101 
Figure 7-6: Stent displayed in Endoscopic and Fluoroscopic views ............................. 102 
Figure 8-1: Single-case report without benchmarks....................................................... 104 
Figure 8-2: Single-case report with benchmarks ............................................................ 105 
Figure 8-3: Snapshot viewed from single report .............................................................107 
Figure 8-4: Recorded video viewed from single report .................................................. 109 
Figure 8-5: Playback screen............................................................................................... 112 
Figure 8-6: Case benchmark scoreboard ......................................................................... 113 
Figure 8-7: Session benchmark scoreboard ..................................................................... 114 
Figure 8-8: Benchmark rating scale .................................................................................. 114 
Figure 8-9: Report's learning curve ................................................................................... 116 
Figure 8-10: Export Performance window ........................................................................ 117 


[TABLE]
| Figures                                                                                                                                             |
|:----------------------------------------------------------------------------------------------------------------------------------------------------|
| Figure 6-44: Checking consciousness ............................................................................... 94                              |
| Figure 6-45: Moderate sedation – sedative selection ...................................................... 96                                       |
| Figure 6-46: Administered Sedatives list ........................................................................... 96                             |
| Figure 7-1: Tools menu ........................................................................................................ 97                  |
| Figure 7-2: Electrosurgical settings (and polyp extraction) in Enhanced Clinical display                                                            |
| mode ...................................................................................................................................... 98      |
| Figure 7-3: Electrosurgical settings for the Endoscopy and Fluoroscopy display mode                                                                 |
| ................................................................................................................................................ 99 |
| Figure 7-4: Guide wire ....................................................................................................... 100                  |
| Figure 7-5: Stent selection menu ....................................................................................... 101                        |
| Figure 7-6: Stent displayed in Endoscopic and Fluoroscopic views ............................. 102                                                  |
| Figure 8-1: Single-case report without benchmarks....................................................... 104                                        |
| Figure 8-2: Single-case report with benchmarks ............................................................ 105                                     |
| Figure 8-3: Snapshot viewed from single report .............................................................107                                     |
| Figure 8-4: Recorded video viewed from single report .................................................. 109                                         |
| Figure 8-5: Playback screen............................................................................................... 112                      |
| Figure 8-6: Case benchmark scoreboard ......................................................................... 113                                 |
| Figure 8-7: Session benchmark scoreboard ..................................................................... 114                                  |
| Figure 8-8: Benchmark rating scale .................................................................................. 114                           |
| Figure 8-9: Report's learning curve ................................................................................... 116                         |
| Figure 8-10: Export Performance window ........................................................................ 117                                 |

[OCR]
Figures

Figure 6-44: Checking CONSCIOUSNESS... eeeseeeeeesseseeeeseescecesceaceecseceeeeeseeseeaeeecseeaseeeeeees 94

Figure 6-45: Moderate sedation — sedative selection... + 96

Figure 6-46: Administered Sedatives list..

Figure 7-1: Tools menu ..

Figure 7-2:

Electrosurgical settings (and polyp extraction) in Enhanced Clinical display

MOC Loe cccececeescseeeceescsessceescsesssenscsesssenscsesscssscsesseesscsessessscsesssesscsesssesecsesssesecsesseesessesaeesees 98
Figure 7-3: Electrosurgical settings for the Endoscopy and Fluoroscopy display mode

socseseseseseeesessucussesesesesescscacscacsesesnsesssususucusucscscacscacaescseseseeesesesesusssuassacscscaescasasseeeaeseesseseseeeaeeenaees 99
Figure 7-4: Guide WIC oo... eee eeseeseseeseesceccscesceecsceseeeeseesceacsacseeaceasaeeeseessesaeeatseeaceaeneeaeeass 100
Figure 7-5: Stent Selection MENU... eeeeeseeseeseseeseeeeeeesceeeseeseescseeseseeeeseeacecseeaseeeseeeeeetee 101
Figure 7-6: Stent displayed in Endoscopic and Fluoroscopic Vi@WS..........:cceseseeeeeeeees 102
Figure 8-1: Single-case report without DENCHMAMKS......... ee eeseeeeteeeeeeeeeeeeeeeeeseeeeneeaeeees 104
Figure 8-2: Single-case report With DENCHMALKS......... cece eeseeseeeeseeeeeeeeesceeceeeseeeeeeseeeees 105
Figure 8-3: Snapshot viewed from Single report uu... eeeeeseeeeeeseeeeeeceeeeeeetseeaceeeaeeeeeeee 107
Figure 8-4: Recorded video viewed from Single report... eee eeeeeeeeseeeeseeeeeeeeeeees 109
Figure 8-5: Playback SCION... ce seeeesceseescseesceececseeeeseesceceseeseesesecseeesseesesaesaeseeaeeeeaeeesenees 112
Figure 8-6: Case benchmark SCOreDOarC uu... sees eeeeeseeseeeescesceeseeeeeeeseescacseeaeeesseeeeeeees 113
Figure 8-7: Session benchmark SCOreDOAMrC......... ee eeeeeseeseeeceesceecseeeeeeeseeseecseeaeeeeseeeeeneee 114
Figure 8-8: Benchmark rating SCale 0... ee eesceeeeeseeseeeeseeeeseeseesceeeseeeeseeseescacseeaceeseeeeeee 114
Figure 8-9: Report's learning CUVE uu... eeseesseccseeseeseeeesceecseeseesesecseseeeeseeaeecaeeaseeseeeateeee 116
Figure 8-10: Export Performance WiINdOW .........sesssesceseeseeeeseesceecseseeeeeseeseecseeaeeeeseeeteeee 117

surgicalscience Page x


# Page 12

Chapter 1 
 Safety Precautions
 
Page 1
 
Chapter 1 Safety Precautions 
Before using the ENDO Mentor Suite simulator, please read these safety precautions 
to ensure proper use of the equipment. These items contain important notes to 
prevent injury to the operator and damage to the equipment. The following precautions 
apply to both the GI Mentor and the BRONCH Mentor which share the ENDO Mentor 
Suite platform. 
Two symbols are used to indicate specific types of warnings in addition to the general 
note table, which is clearly marked: 
 
 
A warning that indicates a prohibition. 
 
A general warning that emphasizes essential information about something 
that must be done.  
 
The following safety precautions must be adhered to upon setup and using the ENDO 
Mentor Suite simulator. Failure to follow these precautions may result in the removal of 
the warranty and may cause irreversible damage to the simulator or injury to 
operators. 
 
 
Read all the instructions and precautions fully before attempting to 
setup or use the ENDO Mentor Suite simulator. 
 
Follow all warnings and instructions marked on the ENDO Mentor 
Suite simulator.  
 
Do not attempt to open, check, alter, or fix any part of the ENDO 
Mentor Suite system, unless directly asked to do so during a support 
session with a Surgical Science representative. 
 
Unplug the ENDO Mentor Suite simulator when you know an 
electrical storm is approaching.  


[TABLE]
| Chapter 1                                                                          | Safety Precautions                                                                     |
|:-----------------------------------------------------------------------------------|:---------------------------------------------------------------------------------------|
| Chapter 1  Safety Precautions                                                      |                                                                                        |
| Before using the ENDO Mentor Suite simulator, please read these safety precautions |                                                                                        |
| to ensure proper use of the equipment. These items contain important notes to      |                                                                                        |
|                                                                                    | prevent injury to the operator and damage to the equipment. The following precautions  |
| apply to both the GI Mentor and the BRONCH Mentor which share the ENDO Mentor      |                                                                                        |
| Suite platform.                                                                    |                                                                                        |
|                                                                                    | Two symbols are used to indicate specific types of warnings in addition to the general |
| note table, which is clearly marked:                                               |                                                                                        |

[TABLE]
| the warranty and may cause irreversible damage to the simulator or injury to   |
|:-------------------------------------------------------------------------------|
| Read all the instructions and precautions fully before attempting to           |
| setup or use the ENDO Mentor Suite simulator.                                  |
| Follow all warnings and instructions marked on the ENDO Mentor                 |
| Suite simulator.                                                               |
| Do not attempt to open, check, alter, or fix any part of the ENDO              |
| Mentor Suite system, unless directly asked to do so during a support           |
| session with a Surgical Science representative.                                |
| Unplug the ENDO Mentor Suite simulator when you know an                        |
| electrical storm is approaching.                                               |

[OCR]
Chapter 1 Safety Precautions

| Chapter 1 Safety Precautions

Before using the ENDO Mentor Suite simulator, please read these safety precautions
to ensure proper use of the equipment. These items contain important notes to
prevent injury to the operator and damage to the equipment. The following precautions
apply to both the GI Mentor and the BRONCH Mentor which share the ENDO Mentor
Suite platform.

Two symbols are used to indicate specific types of warnings in addition to the general
note table, which is clearly marked:

@ A warning that indicates a prohibition.

A general warning that emphasizes essential information about something
that must be done.

The following safety precautions must be adhered to upon setup and using the ENDO
Mentor Suite simulator. Failure to follow these precautions may result in the removal of
the warranty and may cause irreversible damage to the simulator or injury to
operators.

Read all the instructions and precautions fully before attempting to
setup or use the ENDO Mentor Suite simulator.

Follow all warnings and instructions marked on the ENDO Mentor
Suite simulator.

Do not attempt to open, check, alter, or fix any part of the ENDO
Mentor Suite system, unless directly asked to do so during a support
session with a Surgical Science representative.

Unplug the ENDO Mentor Suite simulator when you know an
electrical storm is approaching.

surgicalscience Page 1


# Page 13

Chapter 1 
 Safety Precautions
 
Page 2
 
 
Before cleaning, unplug the ENDO Mentor Suite simulator from the 
wall outlet. Use a dry cloth without liquid. Do not use aerosol 
cleaners. 
 
Do not use the ENDO Mentor Suite near water.  
 
When not in use or upon moving, disconnect all scopes from the 
system side connector. Failing to do so may result in irreparable 
damage. 
 
When not in use or upon moving, make sure that the tool tray is at its 
original folded position. Failing to do so may result in damage to the 
system. 
 
Make sure scopes and wires are not protruding before closing the 
drawer. Failing to do so may result in irreparable damage to the 
scopes or wires. 
 
When placing the ENDO Mentor Suite in a room with additional 
simulators, other electrical systems, or large amounts of metal, 
ensure that these items are at least 1 meter away from the ENDO 
Mentor Suite simulator. Failing to do so may result in an improper 
functioning of the simulator. 
 
Do not move the interchangeable cartridge in any way while the 
scope is inserted into the cavity. Doing so may result in irreparable 
scope damage. 
 
The interchangeable cartridge must be inserted and locked in place 
properly before attempting scope introduction for all the modalities 
to work. 
 
The bronchoscope’s insertion tube should not be bent unnecessarily 
- neither by attaching it to the hanger clip, nor by leaving it within the 
manikin when not being used. 
 
Do not leave the syringe, master tool, or any other instrument 
inserted in the scope’s working channel unnecessarily. 
 
Place the ENDO Mentor Suite on stable ground only. 


[TABLE]
| Safety Precautions                                                         |
|:---------------------------------------------------------------------------|
| Before cleaning, unplug the ENDO Mentor Suite simulator from the           |
| wall outlet. Use a dry cloth without liquid. Do not use aerosol            |
| cleaners.                                                                  |
| Do not use the ENDO Mentor Suite near water.                               |
| When not in use or upon moving, disconnect all scopes from the             |
| system side connector. Failing to do so may result in irreparable          |
| damage.                                                                    |
| When not in use or upon moving, make sure that the tool tray is at its     |
| original folded position. Failing to do so may result in damage to the     |
| system.                                                                    |
| Make sure scopes and wires are not protruding before closing the           |
| drawer. Failing to do so may result in irreparable damage to the           |
| scopes or wires.                                                           |
| When placing the ENDO Mentor Suite in a room with additional               |
| simulators, other electrical systems, or large amounts of metal,           |
| ensure that these items are at least 1 meter away from the ENDO            |
| Mentor Suite simulator. Failing to do so may result in an improper         |
| functioning of the simulator.                                              |
| Do not move the interchangeable cartridge in any way while the             |
| scope is inserted into the cavity. Doing so may result in irreparable      |
| scope damage.                                                              |
| The interchangeable cartridge must be inserted and locked in place         |
| properly before attempting scope introduction for all the modalities       |
| to work.                                                                   |
| The bronchoscope’s insertion tube should not be bent unnecessarily         |
| - neither by attaching it to the hanger clip, nor by leaving it within the |
| manikin when not being used.                                               |
| Do not leave the syringe, master tool, or any other instrument             |
| inserted in the scope’s working channel unnecessarily.                     |
| Place the ENDO Mentor Suite on stable ground only.                         |

[OCR]
Chapter 1

Safety Precautions

a5

Before cleaning, unplug the ENDO Mentor Suite simulator from the
wall outlet. Use a dry cloth without liquid. Do not use aerosol
cleaners.

Do not use the ENDO Mentor Suite near water.

When not in use or upon moving, disconnect all scopes from the
system side connector. Failing to do so may result in irreparable
damage.

When not in use or upon moving, make sure that the tool tray is at its
original folded position. Failing to do so may result in damage to the
system.

Make sure scopes and wires are not protruding before closing the
drawer. Failing to do so may result in irreparable damage to the
scopes or wires.

When placing the ENDO Mentor Suite in a room with additional
simulators, other electrical systems, or large amounts of metal,
ensure that these items are at least 1 meter away from the ENDO
Mentor Suite simulator. Failing to do so may result in an improper
functioning of the simulator.

Do not move the interchangeable cartridge in any way while the
scope is inserted into the cavity. Doing so may result in irreparable
scope damage.

The interchangeable cartridge must be inserted and locked in place
properly before attempting scope introduction for all the modalities
to work.

The bronchoscope’s insertion tube should not be bent unnecessarily
- neither by attaching it to the hanger clip, nor by leaving it within the
manikin when not being used.

Do not leave the syringe, master tool, or any other instrument
inserted in the scope’s working channel unnecessarily.

Place the ENDO Mentor Suite on stable ground only.

surgicalscience

Page 2


# Page 14

Chapter 1 
 Safety Precautions
 
Page 3
 
 
To protect the ENDO Mentor Suite from overheating, the opening on 
the back of the platform should not be covered or blocked.  
 
The ENDO Mentor Suite should not be placed near a radiator or heat 
register. 
 
The ENDO Mentor Suite should be placed in a room with a 
temperature range between 5 and 30 degrees centigrade. Proper 
ventilation is crucial.  
 
Do not allow anything to rest on the power cord or position the ENDO 
Mentor Suite where a cord could be stepped on or pulled out 
accidentally. 
 
Do not overload wall outlets and extension cords. 
 
Never spill liquid of any kind on the simulator. 
 
Avoid placing or dropping anything on the ENDO Mentor Suite. It may 
cause a malfunction or irreparable damage. 
 
Power must be off when handling the system or disconnecting any 
internal part during a support session.  
 
Unplug the ENDO Mentor Suite from the wall outlet and contact 
Surgical Science support under the following conditions:  
• 
When any cord, especially the power supply cord, is damaged 
or frayed. 
• 
If liquid has been spilled into the ENDO Mentor Suite. 
• 
If something has been dropped on the ENDO Mentor Suite. 
 
When opening the system’s back panel and pulling out the computer 
drawer during support – please note that the monitor must be in the 
opposite (front) side of the system and the computer drawer must be 
pulled out cautiously to avoid equilibrium problems. 
 
 


[TABLE]
|                                         | Safety Precautions                                                   |
|:----------------------------------------|:---------------------------------------------------------------------|
|                                         | To protect the ENDO Mentor Suite from overheating, the opening on    |
|                                         | the back of the platform should not be covered or blocked.           |
|                                         | The ENDO Mentor Suite should not be placed near a radiator or heat   |
| register.                               |                                                                      |
|                                         | The ENDO Mentor Suite should be placed in a room with a              |
|                                         | temperature range between 5 and 30 degrees centigrade. Proper        |
| ventilation is crucial.                 |                                                                      |
|                                         | Do not allow anything to rest on the power cord or position the ENDO |
|                                         | Mentor Suite where a cord could be stepped on or pulled out          |
| accidentally.                           |                                                                      |
|                                         | Do not overload wall outlets and extension cords.                    |
|                                         | Never spill liquid of any kind on the simulator.                     |
|                                         | Avoid placing or dropping anything on the ENDO Mentor Suite. It may  |
|                                         | cause a malfunction or irreparable damage.                           |
|                                         | Power must be off when handling the system or disconnecting any      |
| internal part during a support session. |                                                                      |
|                                         | Unplug the ENDO Mentor Suite from the wall outlet and contact        |
|                                         | Surgical Science support under the following conditions:             |
| •                                       | When any cord, especially the power supply cord, is damaged          |

[OCR]
Chapter 1

Safety Precautions

eeee e?ese

To protect the ENDO Mentor Suite from overheating, the opening on
the back of the platform should not be covered or blocked.

The ENDO Mentor Suite should not be placed near a radiator or heat
register.

The ENDO Mentor Suite should be placed in a room with a
temperature range between 5 and 30 degrees centigrade. Proper
ventilation is crucial.

Do not allow anything to rest on the power cord or position the ENDO
Mentor Suite where a cord could be stepped on or pulled out
accidentally.

Do not overload wall outlets and extension cords.

Never spill liquid of any kind on the simulator.

Avoid placing or dropping anything on the ENDO Mentor Suite. It may
cause a malfunction or irreparable damage.

Power must be off when handling the system or disconnecting any
internal part during a support session.

Unplug the ENDO Mentor Suite from the wall outlet and contact
Surgical Science support under the following conditions:

° When any cord, especially the power supply cord, is damaged
or frayed.

° If liquid has been spilled into the ENDO Mentor Suite.
° If something has been dropped on the ENDO Mentor Suite.

When opening the system’s back panel and pulling out the computer
drawer during support — please note that the monitor must be in the
opposite (front) side of the system and the computer drawer must be
pulled out cautiously to avoid equilibrium problems.

surgicalscience

Page 3


# Page 15

Chapter 2 
 ENDO Mentor Suite System
 
Page 4
 
Chapter 2 ENDO Mentor Suite System  
The ENDO Mentor Suite® is a multidisciplinary platform that provides hands-on 
practice of multiple GI procedures as well as complete bronchoscopy procedures and 
basic endoscopic and bronchoscopic skills for single trainees or an entire team.  
Hardware platform 
The platform consists of:  
• 
Wheeled hardware unit.  
• 
One or more scopes according to system configuration 
(Colonoscope/Duodenoscope/Bronchoscope/Rigid Scopes and Flexible Scope 
for Endourology).  
• 
Interchangeable cartridge for inserting scopes. 
• 
Set of tools according to system configuration.  
• 
Triple foot switch. 
• 
Wireless keyboard and mouse. 


[TABLE]
| Chapter 2                                                                        | ENDO Mentor Suite System                                                           |
|:---------------------------------------------------------------------------------|:-----------------------------------------------------------------------------------|
| Chapter 2 ENDO Mentor Suite System                                               |                                                                                    |
| The ENDO Mentor Suite® is a multidisciplinary platform that provides hands-on    |                                                                                    |
|                                                                                  | practice of multiple GI procedures as well as complete bronchoscopy procedures and |
| basic endoscopic and bronchoscopic skills for single trainees or an entire team. |                                                                                    |
| Hardware platform                                                                |                                                                                    |
| The platform consists of:                                                        |                                                                                    |

[TABLE]
| Hardware platform         |                                                                        |
|:--------------------------|:-----------------------------------------------------------------------|
| The platform consists of: |                                                                        |
| •                         | Wheeled hardware unit.                                                 |
| •                         | One or more scopes according to system configuration                   |
|                           | (Colonoscope/Duodenoscope/Bronchoscope/Rigid Scopes and Flexible Scope |
|                           | for Endourology).                                                      |
| •                         | Interchangeable cartridge for inserting scopes.                        |
| •                         | Set of tools according to system configuration.                        |
| •                         | Triple foot switch.                                                    |
| •                         | Wireless keyboard and mouse.                                           |

[OCR]
Chapter 2 ENDO Mentor Suite System

| Chapter 2 ENDO Mentor Suite System

The ENDO Mentor Suite® is a multidisciplinary platform that provides hands-on
practice of multiple Gl procedures as well as complete bronchoscopy procedures and
basic endoscopic and bronchoscopic skills for single trainees or an entire team.

Hardware platform

The platform consists of:

° Wheeled hardware unit.

e One or more scopes according to system configuration
(Colonoscope/Duodenoscope/Bronchoscope/Rigid Scopes and Flexible Scope
for Endourology).

Interchangeable cartridge for inserting scopes.

Set of tools according to system configuration.

Triple foot switch.

Wireless keyboard and mouse.

surgicalscience Page 4


# Page 16

Chapter 2 
 ENDO Mentor Suite System
 
Page 5
 
 
Figure 2-1: ENDO Mentor Suite - GI Mentor platform 
1 
27” touch screen 
2 
GI interchangeable cartridge (see Figure 2-2 on page 6) 
3 
Wireless keyboard and mouse 
4 
Scope hanger (see Figure 2-4 on page 8) 
5 
Scope connectors (see Figure 2-5 on page 9) 
6 
Elevation mechanism (see Figure 2-10 on page 13) 
7 
Computer activation button 
8 
Rotating tool tray (see Figure 2-11 on page 14) 


[TABLE]
|   F | gure 2-1: ENDO Mentor Suite - GI Mentor platform        |
|   i |                                                         |
|----:|:--------------------------------------------------------|
|   1 | 27” touch screen                                        |
|   2 | GI interchangeable cartridge (see Figure 2-2 on page 6) |
|   3 | Wireless keyboard and mouse                             |
|   4 | Scope hanger (see Figure 2-4 on page 8)                 |
|   5 | Scope connectors (see Figure 2-5 on page 9)             |
|   6 | Elevation mechanism (see Figure 2-10 on page 13)        |
|   7 | Computer activation button                              |
|   8 | Rotating tool tray (see Figure 2-11 on page 14)         |

[OCR]
Chapter 2 ENDO Mentor Suite System

IEP"

Figure 2-1: ENDO Mentor Suite - G/ Mentor platform

1

2
3
4
5
6
7
8

27” touch screen

Gl interchangeable cartridge (see Figure 2-2 on page 6)
Wireless keyboard and mouse

Scope hanger (see Figure 2-4 on page 8)

Scope connectors (see Figure 2-5 on page 9)

Elevation mechanism (see Figure 2-10 on page 13)
Computer activation button

Rotating tool tray (see Figure 2-11 on page 14)

surgicalscience Page 5


# Page 17

Chapter 2 
 ENDO Mentor Suite System
 
Page 6
 
9 
Upper drawer for Bronchoscope, 2 URO rigid scopes and wires 
(tools are stored in this drawer when shipped) 
10 
Lower drawer for Colonoscope, Duodenoscope, URO and GI-
BRONCH interchangeable cartridges 
11 
Foot switch (see Figure 2-13 on page 16) 
12 
Power switch, foot switch connector and USB outlet (on back 
panel) 
GI-BRONCH interchangeable cartridge  
 
Figure 2-2: GI-BRONCH interchangeable cartridge – lower orifice selected 
Two symbols of the upper GI and lower GI tracts are displayed on the GI-BRONCH 
interchangeable cartridge indicating the relevant GI tract segment. Depending on the 
module selected, the LED will light up on the cartridge to designate the GI tract that 
will be used for procedure. 


[TABLE]
| Chapter 2   |                                                             |
|:------------|:------------------------------------------------------------|
| 9           | Upper drawer for Bronchoscope, 2 URO rigid scopes and wires |
|             | (tools are stored in this drawer when shipped)              |
| 10          | Lower drawer for Colonoscope, Duodenoscope, URO and GI-     |
|             | BRONCH interchangeable cartridges                           |
| 11          | Foot switch (see Figure 2-13 on page 16)                    |
| 12          | Power switch, foot switch connector and USB outlet (on back |
|             | panel)                                                      |

[OCR_TABLE]
—— *

RR (

[OCR]
Chapter 2 ENDO Mentor Suite System

9 Upper drawer for Bronchoscope, 2 URO rigid scopes and wires
(tools are stored in this drawer when shipped)

10 Lower drawer for Colonoscope, Duodenoscope, URO and GI-
BRONCH interchangeable cartridges

11 Foot switch (see Figure 2-13 on page 16)

12 Power switch, foot switch connector and USB outlet (on back
panel)

GI-BRONCH interchangeable cartridge

Figure 2-2: GI-BRONCH interchangeable cartridge — lower orifice selected

Two symbols of the upper GI and lower Gl tracts are displayed on the GI-BRONCH
interchangeable cartridge indicating the relevant GI tract segment. Depending on the
module selected, the LED will light up on the cartridge to designate the Gl tract that
will be used for procedure.

surgicalscience Page 6


# Page 18

Chapter 2 
 ENDO Mentor Suite System
 
Page 7
 
URO interchangeable cartridge   
 
Figure 2-3: URO interchangeable cartridge 
To switch between the ENDO Mentor Suite interchangeable cartridges: 
1.  Insert your right hand in the groove on the bottom of the interchangeable cartridge 
and your left hand into the edge on the top of the cartridge and gently free the 
cartridge. You should hear a click. 
2.  Pull the cartridge horizontally out. Store it in its designated cavity in the lower 
drawer. 
3.  Insert the desired cartridge with one hand in the groove and the other on the top 
of the cartridge, push it horizontally into place. You should hear a click. 
 
Note: The cartridge must be properly positioned prior to introducing the scopes. 


[TABLE]
| F                                                                                        |                                                                                     |
| i                                                                                        |                                                                                     |
| gure 2-3: URO interchangeable cartridge                                                  |                                                                                     |
|:-----------------------------------------------------------------------------------------|:------------------------------------------------------------------------------------|
| To switch between the ENDO Mentor Suite interchangeable cartridges:                      |                                                                                     |
| 1.                                                                                       | Insert your right hand in the groove on the bottom of the interchangeable cartridge |
|                                                                                          | and your left hand into the edge on the top of the cartridge and gently free the    |
|                                                                                          | cartridge. You should hear a click.                                                 |
| 2.   Pull the cartridge horizontally out. Store it in its designated cavity in the lower |                                                                                     |
|                                                                                          | drawer.                                                                             |
| 3.                                                                                       | Insert the desired cartridge with one hand in the groove and the other on the top   |
|                                                                                          | of the cartridge, push it horizontally into place. You should hear a click.         |

[OCR]
Chapter 2 ENDO Mentor Suite System

URO interchangeable cartridge

4

Figure 2-3: URO interchangeable cartridge

To switch between the ENDO Mentor Suite interchangeable cartridges:

1. Insert your right hand in the groove on the bottom of the interchangeable cartridge
and your left hand into the edge on the top of the cartridge and gently free the
cartridge. You should hear a click.

2. Pull the cartridge horizontally out. Store it in its designated cavity in the lower
drawer.

3. Insert the desired cartridge with one hand in the groove and the other on the top
of the cartridge, push it horizontally into place. You should hear a click.

Note: The cartridge must be properly positioned prior to introducing the scopes.

surgicalscience Page 7


# Page 19

Chapter 2 
 ENDO Mentor Suite System
 
Page 8
 
Scope hanger 
 
Figure 2-4: Scope hanger – GI scopes  
• 
The GI scope hangers come with a clip for hanging the scope insertion tube as 
shown above. This is to prevent the tip from hitting the floor. 
• 
The scope hanger units are generic, the bronchoscope can fit in any hanger. 
Connecting the scope 
The GI scopes and BRONCH scope are connected to socket C at the front of the 
system.  
The rigid URO scopes are connected to sockets A and B; the BRONCH scope is used 
as a flexible URO scope and is connected to socket C. 
To connect the scope:  
1.  Fit the scope connector exactly in the prongs and recesses of the system 
connector.  
2.  Turn the external dial on the scope connector to the right until you hear a click. 


[TABLE]
| Chapter 2                                                                               |
|  ENDO Mentor Suite System                                                               |
|:----------------------------------------------------------------------------------------|
| Scope hanger                                                                            |
| F                                                                                       |
| i                                                                                       |
| gure 2-4: Scope hanger – GI scopes                                                      |
| The GI scope hangers come with a clip for hanging the scope insertion tube as           |
| •                                                                                       |
| shown above. This is to prevent the tip from hitting the floor.                         |
| The scope hanger units are generic, the bronchoscope can fit in any hanger.             |
| •                                                                                       |
| Connecting the scope                                                                    |
| The GI scopes and BRONCH scope are connected to socket C at the front of the            |
| system.                                                                                 |
| The rigid URO scopes are connected to sockets A and B; the BRONCH scope is used         |
| as a flexible URO scope and is connected to socket C.                                   |
| To connect the scope:                                                                   |
| 1.   Fit the scope connector exactly in the prongs and recesses of the system           |
| connector.                                                                              |
| 2.   Turn the external dial on the scope connector to the right until you hear a click. |
| Page 8                                                                                  |

[OCR]
Chapter 2 ENDO Mentor Suite System

Scope hanger

Figure 2-4: Scope hanger — G/ scopes

. The GI scope hangers come with a clip for hanging the scope insertion tube as
shown above. This is to prevent the tip from hitting the floor.
. The scope hanger units are generic, the bronchoscope can fit in any hanger.

Connecting the scope

The GI scopes and BRONCH scope are connected to socket C at the front of the
system.

The rigid URO scopes are connected to sockets A and B; the BRONCH scope is used
as a flexible URO scope and is connected to socket C.

To connect the scope:

1. Fit the scope connector exactly in the prongs and recesses of the system
connector.
2. Turn the external dial on the scope connector to the right until you hear a click.

surgicalscience Page 8


# Page 20

Chapter 2 
 ENDO Mentor Suite System
 
Page 9
 
To disconnect the scope: 
1.  Turn the dial to the left and remove the scope connector. 
Note: Bumping against the scope connector while connected may result in damage to both the 
scope and the system. 
 
Figure 2-5: System and scope connectors 
Extensions 
The GI Mentor and URO Mentor modules require an extension for performing certain 
procedures. The GI modality extension is on the left side of the ENDO Mentor Suite 
and the URO modality extension is on the back of the simulator. 
 
Figure 2-6: GI modality extension 


[TABLE]
| Chapter 2                                                                                   | ENDO Mentor Suite System   |
|:--------------------------------------------------------------------------------------------|:---------------------------|
| To disconnect the scope:                                                                    |                            |
| 1.   Turn the dial to the left and remove the scope connector.                              |                            |
| Note:  Bumping against the scope connector while connected may result in damage to both the |                            |
| scope and the system.                                                                       |                            |
| F                                                                                           |                            |
| i                                                                                           |                            |
| gure 2-5: System and scope connectors                                                       |                            |
| Extensions                                                                                  |                            |
| The GI Mentor and URO Mentor modules require an extension for performing certain            |                            |
| procedures. The GI modality extension is on the left side of the ENDO Mentor Suite          |                            |
| and the URO modality extension is on the back of the simulator.                             |                            |
| F                                                                                           |                            |
| i                                                                                           |                            |
| gure 2-6: GI modality extension                                                             |                            |
|                                                                                             | Page 9                     |

[OCR]
Chapter 2 ENDO Mentor Suite System

To disconnect the scope:
1. Turn the dial to the left and remove the scope connector.

Note: Bumping against the scope connector while connected may result in damage to both the
scope and the system.

Figure 2-5: System and scope connectors

Extensions

The GI Mentor and URO Mentor modules require an extension for performing certain
procedures. The GI modality extension is on the left side of the ENDO Mentor Suite
and the URO modality extension is on the back of the simulator.

Figure 2-6: Gl modality extension

surgicalscience Page 9


# Page 21

Chapter 2 
 ENDO Mentor Suite System
 
Page 10
 
 
Figure 2-7: URO modality extension 
To open the extension:  
1.  Press gently the modality extension. It will pop out.  
 
 
2.  Pull it to its full length. 


[TABLE]
| Chapter 2                                                  | ENDO Mentor Suite System   |
|:-----------------------------------------------------------|:---------------------------|
| F                                                          |                            |
| i                                                          |                            |
| gure 2-7: URO modality extension                           |                            |
| To open the extension:                                     |                            |
| 1.   Press gently the modality extension. It will pop out. |                            |
| 2.   Pull it to its full length.                           |                            |
|                                                            | Page 10                    |

[OCR]
Chapter 2 ENDO Mentor Suite System

Figure 2-7: URO modality extension

To open the extension:
1. Press gently the modality extension. It will pop out.

2. Pull it to its full length.

surgicalscience Page 10


# Page 22

Chapter 2 
 ENDO Mentor Suite System
 
Page 11
 
 
 
Figure 2-8: GI extension fully opened (left), URO extension fully opened (right) 
To close the extension: 
1.  Push the extension until it fits back in place. 
Working positions 
The ENDO Mentor Suite supports different working positions. 
GI Mentor: 
The user is operating in front of the simulator, facing the GI-BRONCH interchangeable 
cartridge. 


[TABLE]
| F                                                                                     |
| i                                                                                     |
| gure 2-8: GI extension fully opened (left), URO extension fully opened (right)        |
|:--------------------------------------------------------------------------------------|
| To close the extension:                                                               |
| 1.   Push the extension until it fits back in place.                                  |
| Working positions                                                                     |
| The ENDO Mentor Suite supports different working positions.                           |
| GI Mentor:                                                                            |
| The user is operating in front of the simulator, facing the GI-BRONCH interchangeable |
| cartridge.                                                                            |

[OCR]
Chapter 2 ENDO Mentor Suite System

4A Een 2

~

Figure 2-8: G/ extension fully opened (left), URO extension fully opened (right)

To close the extension:
1. Push the extension until it fits back in place.

Working positions

The ENDO Mentor Suite supports different working positions.
GI Mentor:

The user is operating in front of the simulator, facing the GI-BRONCH interchangeable
cartridge.

surgicalscience Page 11


# Page 23

Chapter 2 
 ENDO Mentor Suite System
 
Page 12
 
 
Figure 2-9: GI Mentor working position 
BRONCH Mentor: 
• 
Superior – the user is operating from behind the patient’s head. 
• 
Lateral – the user is operating laterally to the patient. 
URO Mentor: 
The user is operating in front of the simulator, facing the URO interchangeable 
cartridge. 
 
The screen and the tool tray are adjustable to conveniently support each working 
position. 


[TABLE]
| F                                      |                                                                                 |
| i                                      |                                                                                 |
| gure 2-9: GI Mentor working position   |                                                                                 |
|:---------------------------------------|:--------------------------------------------------------------------------------|
| BRONCH Mentor:                         |                                                                                 |
| •                                      | Superior – the user is operating from behind the patient’s head.                |
| •                                      | Lateral – the user is operating laterally to the patient.                       |
| URO Mentor:                            |                                                                                 |
|                                        | The user is operating in front of the simulator, facing the URO interchangeable |
| cartridge.                             |                                                                                 |
| T                                      | he screen and the tool tray are adjustable to conveniently support each working |
| position.                              |                                                                                 |

[OCR]
Chapter 2 ENDO Mentor Suite System

a]
Figure 2-9: GI Mentor working position

BRONCH Mentor:

. Superior — the user is operating from behind the patient’s head.
. Lateral - the user is operating laterally to the patient.

URO Mentor:

The user is operating in front of the simulator, facing the URO interchangeable
cartridge.

The screen and the tool tray are adjustable to conveniently support each working
position.

surgicalscience Page 12


# Page 24

Chapter 2 
 ENDO Mentor Suite System
 
Page 13
 
Height elevation mechanism 
The height of the ENDO Mentor Suite platform can be adjusted.  
 
Figure 2-10: Height elevation panel – (from left to right) USB port, Height Elevation mechanism, 
Computer On/Off button 
Use the Up and Down arrows on the Height Elevation panel to find the desired height.  
Note: The USB port can be used for example for connecting an external hard drive. 
Turning on the simulator 
1.  Make sure the On/Off Power switch on the back of the simulator is turned on. 
2.  Use the button to the right of the Height Elevation mechanism to turn on the ENDO 
Mentor Suite computer. 
 


[TABLE]
| Chapter 2                                                                         | ENDO Mentor Suite System                                                                       |
|:----------------------------------------------------------------------------------|:-----------------------------------------------------------------------------------------------|
| Height elevation mechanism                                                        |                                                                                                |
| The height of the ENDO Mentor Suite platform can be adjusted.                     |                                                                                                |
| F                                                                                 | gure 2-10: Height elevation panel – (from left to right) USB port, Height Elevation mechanism, |
| i                                                                                 |                                                                                                |
| Computer On/Off button                                                            |                                                                                                |
|                                                                                   | Use the Up and Down arrows on the Height Elevation panel to find the desired height.           |
| Note: The USB port can be used for example for connecting an external hard drive. |                                                                                                |
| Turning on the simulator                                                          |                                                                                                |
| 1.   Make sure the On/Off Power switch on the back of the simulator is turned on. |                                                                                                |
|                                                                                   | 2.   Use the button to the right of the Height Elevation mechanism to turn on the ENDO         |
| Mentor Suite computer.                                                            |                                                                                                |
|                                                                                   | Page 13                                                                                        |

[OCR]
Chapter 2 ENDO Mentor Suite System

Height elevation mechanism

The height of the ENDO Mentor Suite platform can be adjusted.

Figure 2-10: Height elevation panel - (from left to right) USB port, Height Elevation mechanism,
Computer On/Off button

Use the Up and Down arrows on the Height Elevation panel to find the desired height.

Note: The USB port can be used for example for connecting an external hard drive.

Turning on the simulator

1. Make sure the On/Off Power switch on the back of the simulator is turned on.
2. Use the button to the right of the Height Elevation mechanism to turn on the ENDO
Mentor Suite computer.

surgicalscience Page 13


# Page 25

Chapter 2 
 ENDO Mentor Suite System
 
Page 14
 
Tool tray 
The rotating tool tray holds all the tools for the ENDO Mentor Suite system: 
• 
Master Tool – all platforms 
• 
URO forceps – URO Mentor 
• 
Syringe – BRONCH Mentor 
• 
EBUS needle – BRONCH Mentor 
• 
Red and blue wires – GI Mentor 
Note: When not being used or upon moving the system, the tool tray must be stored in its 
original position to avoid damage. 
 
 
Figure 2-11: Tool tray hanger with GI tools  


[TABLE]
| Tool tray                                                                                 |                                    |
|:------------------------------------------------------------------------------------------|:-----------------------------------|
| The rotating tool tray holds all the tools for the ENDO Mentor Suite system:              |                                    |
| •                                                                                         | Master Tool – all platforms        |
| •                                                                                         | URO forceps – URO Mentor           |
| •                                                                                         | Syringe – BRONCH Mentor            |
| •                                                                                         | EBUS needle – BRONCH Mentor        |
| •                                                                                         | Red and blue wires – GI Mentor     |
| Note:  When not being used or upon moving the system, the tool tray must be stored in its |                                    |
|                                                                                           | original position to avoid damage. |

[OCR]
Chapter 2 ENDO Mentor Suite System

Tool tray

The rotating tool tray holds all the tools for the ENDO Mentor Suite system:

Master Tool - all platforms

URO forceps — URO Mentor
Syringe - BRONCH Mentor
EBUS needle - BRONCH Mentor
Red and blue wires — GI Mentor

Note: When not being used or upon moving the system, the tool tray must be stored in its
original position to avoid damage.

Figure 2-11: Tool tray hanger with G/ tools

surgicalscience Page 14


# Page 26

Chapter 2 
 ENDO Mentor Suite System
 
Page 15
 
The tool connectors are on the side of the platform under the tool tray. Use the labeled 
outlets to connect the tool cables as shown below. 
 
Figure 2-12: Tool connection outlets 
1 
MT (Master tool) 
2 
UR (URO forceps) 
3 
SR (Syringe) 
4 
EB (EBUS needle) 
The red and blue wires do not need to be connected to a tool outlet as they are 
wireless; the white wire needs no connection as it is already connected to the Master 
Tool. 
When not in use, the wires can be stored either in the upper drawer or on the tool tray. 


[TABLE]
| Chapter 2   |                                                                                          | ENDO Mentor Suite System   |
|:------------|:-----------------------------------------------------------------------------------------|:---------------------------|
|             | The tool connectors are on the side of the platform under the tool tray. Use the labeled |                            |
|             | outlets to connect the tool cables as shown below.                                       |                            |
| F           | gure 2-12: Tool connection outlets                                                       |                            |
| i           |                                                                                          |                            |
| 1           | MT (Master tool)                                                                         |                            |
| 2           | UR (URO forceps)                                                                         |                            |
| 3           | SR (Syringe)                                                                             |                            |
| 4           | EB (EBUS needle)                                                                         |                            |
|             | The red and blue wires do not need to be connected to a tool outlet as they are          |                            |
|             | wireless; the white wire needs no connection as it is already connected to the Master    |                            |
| Tool.       |                                                                                          |                            |
|             | When not in use, the wires can be stored either in the upper drawer or on the tool tray. |                            |
|             |                                                                                          | Page 15                    |

[OCR]
Chapter 2 ENDO Mentor Suite System

The tool connectors are on the side of the platform under the tool tray. Use the labeled
outlets to connect the tool cables as shown below.

Figure 2-12: Tool connection outlets

1 MT (Master tool)

2 UR (URO forceps)
3 SR (Syringe)

4 EB (EBUS needle)

The red and blue wires do not need to be connected to a tool outlet as they are
wireless; the white wire needs no connection as it is already connected to the Master
Tool.

When not in use, the wires can be stored either in the upper drawer or on the tool tray.

surgicalscience Page 15


# Page 27

Chapter 2 
 ENDO Mentor Suite System
 
Page 16
 
Foot switch 
A triple foot switch is provided with the platform and utilized in some of the modules 
for actions such as application of electrosurgical current (left foot switch) or 
application of X-ray (right foot switch).  
 
Figure 2-13: Foot switch 
Available endoscopes 
Two scopes are available with the GI Mentor. Both are real scopes that were modified 
for simulation purposes. 
The following scopes are available and provided according to which modules were 
purchased:  
• 
Colonoscope – used also for gastroscopy 
• 
Duodenoscope – used for the ERCP and EUS modules 
 
 
Make sure the scopes are not protruding before closing the drawer. 
Failing to do so may result in irreparable damage to the scopes. 


[TABLE]
| Chapter 2                                                                              | ENDO Mentor Suite System   |
|:---------------------------------------------------------------------------------------|:---------------------------|
| Foot switch                                                                            |                            |
| A triple foot switch is provided with the platform and utilized in some of the modules |                            |
| for actions such as application of electrosurgical current (left foot switch) or       |                            |
| application of X-ray (right foot switch).                                              |                            |
| F                                                                                      |                            |
| i                                                                                      |                            |
| gure 2-13: Foot switch                                                                 |                            |
| Available endoscopes                                                                   |                            |
| Two scopes are available with the GI Mentor. Both are real scopes that were modified   |                            |
| for simulation purposes.                                                               |                            |
| The following scopes are available and provided according to which modules were        |                            |
| purchased:                                                                             |                            |
| Colonoscope – used also for gastroscopy                                                |                            |
| •                                                                                      |                            |
| Duodenoscope – used for the ERCP and EUS modules                                       |                            |
| •                                                                                      |                            |
| Make sure the scopes are not protruding before closing the drawer.                     |                            |
| Failing to do so may result in irreparable damage to the scopes.                       |                            |
|                                                                                        | Page 16                    |

[OCR]
Chapter 2 ENDO Mentor Suite System

Foot switch

A triple foot switch is provided with the platform and utilized in some of the modules
for actions such as application of electrosurgical current (left foot switch) or
application of X-ray (right foot switch).

Figure 2-13: Foot switch

Available endoscopes

Two scopes are available with the GI Mentor. Both are real scopes that were modified
for simulation purposes.

The following scopes are available and provided according to which modules were
purchased:

. Colonoscope — used also for gastroscopy
e Duodenoscope - used for the ERCP and EUS modules

Make sure the scopes are not protruding before closing the drawer.
Failing to do so may result in irreparable damage to the scopes.

surgicalscience Page 16


# Page 28

Chapter 2 
 ENDO Mentor Suite System
 
Page 17
 
Colonoscope 
The colonoscope, a forward viewing endoscope, is an actual scope modified for 
simulation purposes.  
 
 
 
 
1 – Working Channel  
2 – Up-Down 
Directional Knob  
3 – Right-Left 
Directional Knob 
4 – Lock/Free Switch 
for Up-Down 
Movement  
5 – Lock/Free Switch 
for Right-Left 
Movement 
6 – Suction Button  
7 – Insufflation and 
Irrigation Button 
Figure 2-14: Colonoscope 


[TABLE]
| 1                    |
|  – Working Channel   |
|:---------------------|
| 2 – Up-Down          |
| Directional Knob     |
| 3 – Right-Left       |
| Directional Knob     |
| 4 – Lock/Free Switch |
| for Up-Down          |
| Movement             |
| 5 – Lock/Free Switch |
| for Right-Left       |
| Movement             |
| 6 – Suction Button   |
| 7 – Insufflation and |
| Irrigation Button    |

[OCR]
Chapter 2

ENDO Mentor Suite System

Colonoscope

The colonoscope, a forward viewing endoscope, is an
simulation purposes.

2-
3-

4-

5-

Figure 2-14: Colonoscope

actual scope modified for

1 - Working Channel

Up-Down

Directional Knob

Right-Left

Directional Knob

Lock/Free Switch

for Up-Down
Movement

Lock/Free Switch

for Right-Left
Movement

6 - Suction Button

7 - Insufflation and
Irrigation Button

surgicalscience

Page 17


# Page 29

Chapter 2 
 ENDO Mentor Suite System
 
Page 18
 
Duodenoscope 
The duodenoscope,  a side viewing scope, is an actual scope modified for simulation 
purposes.  
 
 
 
1 – Working 
Channel for Master 
Tool  
2 – Working 
Channel for Red 
Wire  
3 – Working 
Channel for Blue 
Wire  
4 – Up-Down 
Directional Knob  
5 – Right-Left 
Directional Knob  
6 – Tool Elevation 
Lever 
7 – Lock/Free 
Switch for Up-
Down Movement  
8 – Lock/Free 
Switch for Right-
Left Movement  
9 – Suction Button 
10 – Insufflation 
and Irrigation 
Button 
Figure 2-15: Duodenoscope 


[TABLE]
| 1                  |
|  – Working         |
|:-------------------|
| Channel for Master |
| Tool               |
| 2 – Working        |
| Channel for Red    |
| Wire               |
| 3 – Working        |
| Channel for Blue   |
| Wire               |
| 4 – Up-Down        |
| Directional Knob   |
| 5 – Right-Left     |
| Directional Knob   |
| 6 – Tool Elevation |
| Lever              |
| 7 – Lock/Free      |
| Switch for Up-     |
| Down Movement      |
| 8 – Lock/Free      |
| Switch for Right-  |
| Left Movement      |
| 9 – Suction Button |
| 10 – Insufflation  |
| and Irrigation     |
| Button             |

[OCR]
Chapter 2

ENDO Mentor Suite System

Duodenoscope

The duodenoscope, a side viewing scope, is an actual scope modified for simulation

purposes.

Figure 2-15: Duodenoscope

1 - Working
Channel for Master
Tool

2 - Working
Channel for Red
Wire

3 - Working
Channel for Blue
Wire

4 -Up-Down
Directional Knob
5 - Right-Left
Directional Knob

6 - Tool Elevation
Lever

7 - Lock/Free
Switch for Up-
Down Movement

8 - Lock/Free
Switch for Right-
Left Movement

9 - Suction Button

10 — Insufflation
and Irrigation
Button

surgicalscience

Page 18


# Page 30

Chapter 2 
 ENDO Mentor Suite System
 
Page 19
 
Auxiliary tools and connectors 
 
Make sure the wires are not protruding before closing the drawer. Failing 
to do so may result in irreparable damage to the wires. 
GI Mentor tools 
The GI Mentor has three available tools: a Master Tool, used to simulate most of the 
tools in all the modules and red and blue wires, used in the ERCP modules, in addition 
to the Master Tool. 
Master Tool 
 
Figure 2-16: Master Tool 
To select a virtual tool using the Master Tool: 
1.  Insert the Master Tool slowly into the working channel until the Tools menu 
appears.  
The Tools menu opens with pictures of all available tools.  
To work with Master Tool handle: 
• 
Pull the Master Tool handle back to open, inflate, or fill the tool. 
• 
Push the Master Tool handle forward to close, deflate, or inject using the tool.  


[TABLE]
| Chapter 2                                                                              |
|  ENDO Mentor Suite System                                                              |
|:---------------------------------------------------------------------------------------|
| Auxiliary tools and connectors                                                         |
| Make sure the wires are not protruding before closing the drawer. Failing              |
| to do so may result in irreparable damage to the wires.                                |
| GI Mentor tools                                                                        |
| The GI Mentor has three available tools: a Master Tool, used to simulate most of the   |
| tools in all the modules and red and blue wires, used in the ERCP modules, in addition |
| to the Master Tool.                                                                    |
| Master Tool                                                                            |
| F                                                                                      |
| i                                                                                      |
| gure 2-16: Master Tool                                                                 |
| To select a virtual tool using the Master Tool:                                        |
| 1.                                                                                     |
| Insert the Master Tool slowly into the working channel until the Tools menu            |
| appears.                                                                               |
| The Tools menu opens with pictures of all available tools.                             |
| To work with Master Tool handle:                                                       |
| Pull the Master Tool handle back to open, inflate, or fill the tool.                   |
| •                                                                                      |
| Push the Master Tool handle forward to close, deflate, or inject using the tool.       |
| •                                                                                      |
| Page 19                                                                                |

[OCR]
Chapter 2 ENDO Mentor Suite System

Auxiliary tools and connectors

Make sure the wires are not protruding before closing the drawer. Failing
to do so may result in irreparable damage to the wires.

Gl Mentor tools

The GI Mentor has three available tools: a Master Tool, used to simulate most of the
tools in all the modules and red and blue wires, used in the ERCP modules, in addition
to the Master Tool.

Master Tool

Figure 2-16: Master Tool

To select a virtual tool using the Master Tool:

1. Insert the Master Tool slowly into the working channel until the Tools menu
appears.
The Tools menu opens with pictures of all available tools.

To work with Master Tool handle:

e Pull the Master Tool handle back to open, inflate, or fill the tool.
. Push the Master Tool handle forward to close, deflate, or inject using the tool.

surgicalscience Page 19


# Page 31

Chapter 2 
 ENDO Mentor Suite System
 
Page 20
 
Additional wires 
A blue wire and a red wire are used in the ERCP modules. The duodenoscope allows 
for working simultaneously with three tools and wires, inserted through three separate 
openings. Each colored wire is inserted into its color marked opening and simulates a 
different tool or wire during the ERCP procedure. For more information, see Working 
with multiple tools and wires on page 99. 
Note: The red and blue wires are wireless and do not need to be connected to a tool outlet; the 
white wire needs no connection as it is already connected to the Master Tool. 
 


[TABLE]
| Chapter 2                                                                           | ENDO Mentor Suite System                                                                        |
|:------------------------------------------------------------------------------------|:------------------------------------------------------------------------------------------------|
| Additional wires                                                                    |                                                                                                 |
| A blue wire and a red wire are used in the ERCP modules. The duodenoscope allows    |                                                                                                 |
|                                                                                     | for working simultaneously with three tools and wires, inserted through three separate          |
|                                                                                     | openings. Each colored wire is inserted into its color marked opening and simulates a           |
| different tool or wire during the ERCP procedure. For more information, see Working |                                                                                                 |
| with multiple tools and wires on page 99.                                           |                                                                                                 |
|                                                                                     | Note: The red and blue wires are wireless and do not need to be connected to a tool outlet; the |
| white wire needs no connection as it is already connected to the Master Tool.       |                                                                                                 |

[OCR]
Chapter 2 ENDO Mentor Suite System

Additional wires

A blue wire and a red wire are used in the ERCP modules. The duodenoscope allows
for working simultaneously with three tools and wires, inserted through three separate
openings. Each colored wire is inserted into its color marked opening and simulates a
different tool or wire during the ERCP procedure. For more information, see Working
with multiple tools and wires on page 99.

Note: The red and blue wires are wireless and do not need to be connected to a tool outlet; the
white wire needs no connection as it is already connected to the Master Tool.

surgicalscience Page 20


# Page 32

Chapter 3 
 GI Mentor Express Platform
 
Page 21
 
Chapter 3 GI Mentor Express Platform  
The GI Mentor® Express is a portable platform that provides hands-on practice for 
basic endoscopic skills and GI procedures.  
Hardware platform  
 
Figure 3-1: GI Mentor Express platform 
① Laptop 
② Adjustable stand 
③ Wireless mouse 
④ Simulator body 
⑤ Scope trail extension (sleeve) 
⑥ Scope  
⑦ Scope connector  
⑧ Generic upper/lower orifice  
⑨ Master tool connector 
 
⑩ Control panel 
* A foot switch is provided 
* Control panel functionality availability is per software version 


[TABLE]
| Chapter 3                                                                         | GI Mentor Express Platform   |
|:----------------------------------------------------------------------------------|:-----------------------------|
| Chapter 3 GI Mentor Express Platform                                              |                              |
| The GI Mentor® Express is a portable platform that provides hands-on practice for |                              |
| basic endoscopic skills and GI procedures.                                        |                              |
| Hardware platform                                                                 |                              |
| F                                                                                 |                              |
| i                                                                                 |                              |
| gure 3-1: GI Mentor Express platform                                              |                              |
| ①  Laptop                                                                         |                              |
| ②  Adjustable stand                                                               |                              |
| ③  Wireless mouse                                                                 |                              |
| ④  Simulator body                                                                 |                              |
| ⑤  Scope trail extension (sleeve)                                                 |                              |
| ⑥  Scope                                                                          |                              |
| ⑦  Scope connector                                                                |                              |
| ⑧  Generic upper/lower orifice                                                    |                              |
| ⑨  Master tool connector                                                          |                              |
| Control panel                                                                     |                              |
| * A foot switch is provided                                                       |                              |
| * Control panel functionality availability is per software version                |                              |
|                                                                                   | Page 21                      |

[OCR]
Chapter 3 Gl Mentor Express Platform

| Chapter 3 GI Mentor Express Platform

The GI Mentor® Express is a portable platform that provides hands-on practice for
basic endoscopic skills and Gl procedures.

Hardware platform

Figure 3-1: GI Mentor Express platform

Laptop

Adjustable stand

Wireless mouse

imulator body

cope trail extension (sleeve)
cope

cope connector

Generic upper/lower orifice
Master tool connector
Control panel

* A foot switch is provided

* Control panel functionality availability is per software version

Ss)
Ss)
Ss)
Ss)

COQQECLHECHO

surgicalscience Page 21


# Page 33

Chapter 3 
 GI Mentor Express Platform
 
Page 22
 
Note: The GI Mentor Express should be placed in environments that are clear of large metal 
object or other objects that may cause electromagnetic interference. 
Laptop setup 
The laptop is placed on an adjustable stand and can be raised, lowered, or slanted, as 
needed. 
 
Figure 3-2: Laptop on stand 
1.  Place the laptop on the stand. 


[TABLE]
| Chapter 3                                                                                   | GI Mentor Express Platform                                                             |
|:--------------------------------------------------------------------------------------------|:---------------------------------------------------------------------------------------|
| Note:  The GI Mentor Express should be placed in environments that are clear of large metal |                                                                                        |
| object or other objects that may cause electromagnetic interference.                        |                                                                                        |
| Laptop setup                                                                                |                                                                                        |
|                                                                                             | The laptop is placed on an adjustable stand and can be raised, lowered, or slanted, as |
| needed.                                                                                     |                                                                                        |
| F                                                                                           |                                                                                        |
| i                                                                                           |                                                                                        |
| gure 3-2: Laptop on stand                                                                   |                                                                                        |
| 1.   Place the laptop on the stand.                                                         |                                                                                        |
|                                                                                             | Page 22                                                                                |

[OCR]
Chapter 3 Gl Mentor Express Platform

Note: The GI Mentor Express should be placed in environments that are clear of large metal
object or other objects that may cause electromagnetic interference.

Laptop setup

The laptop is placed on an adjustable stand and can be raised, lowered, or slanted, as
needed.

Figure 3-2: Laptop on stand

1. Place the laptop on the stand.

surgicalscience Page 22


# Page 34

Chapter 3 
 GI Mentor Express Platform
 
Page 23
 
 
Figure 3-3: Connecting the laptop 
2.  Connect the laptop power supply cable. 
3.  Connect the 2 USB simulator cables. 
4.  Connect the USB nano receiver for the wireless mouse. 


[TABLE]
| Chapter 3                                                  | GI Mentor Express Platform   |
|:-----------------------------------------------------------|:-----------------------------|
| F                                                          |                              |
| i                                                          |                              |
| gure 3-3: Connecting the laptop                            |                              |
| 2.   Connect the laptop power supply cable.                |                              |
| 3.   Connect the 2 USB simulator cables.                   |                              |
| 4.   Connect the USB nano receiver for the wireless mouse. |                              |
|                                                            | Page 23                      |

[OCR]
Chapter 3 Gl Mentor Express Platform

7}

Figure 3-3: Connecting the laptop

Connect the laptop power supply cable.
Connect the 2 USB simulator cables.
Connect the USB nano receiver for the wireless mouse.

RON

surgicalscience Page 23


# Page 35

Chapter 3 
 GI Mentor Express Platform
 
Page 24
 
 
Figure 3-4: Adjusting the stand 
5.  Adjust the height of the standby pushing the switch (3) to the open position and 
then tilting the stand (2) up or down. Push the switch (3) to the close position. 
6.  Adjust the angle of the standby releasing the handle (1) and tilting to the desired 
angle. Lock the handle (1) back in place. 
Note: In order to secure a neutral electromagnetic environment, a minimal distance of 20 cm 
should be maintained between the laptop stand and the simulator body in general, and 
the scope tunnel in particular. 
 


[TABLE]
| Chapter 3                                                                                |
|  GI Mentor Express Platform                                                              |
|:-----------------------------------------------------------------------------------------|
| F                                                                                        |
| i                                                                                        |
| gure 3-4: Adjusting the stand                                                            |
| 5.   Adjust the height of the standby pushing the switch (3) to the open position and    |
| then tilting the stand (2) up or down. Push the switch (3) to the close position.        |
| 6.   Adjust the angle of the standby releasing the handle (1) and tilting to the desired |
| angle. Lock the handle (1) back in place.                                                |
| Note:                                                                                    |
| In order to secure a neutral electromagnetic environment, a minimal distance of 20 cm    |
| should be maintained between the laptop stand and the simulator body in general, and     |
| the scope tunnel in particular.                                                          |
| Page 24                                                                                  |

[OCR]
Chapter 3 Gl Mentor Express Platform

Figure 3-4: Adjusting the stand

5. Adjust the height of the standby pushing the switch (3) to the open position and
then tilting the stand (2) up or down. Push the switch (3) to the close position.

6. Adjust the angle of the standby releasing the handle (1) and tilting to the desired
angle. Lock the handle (1) back in place.

Note: In order to secure a neutral electromagnetic environment, a minimal distance of 20 cm
should be maintained between the laptop stand and the simulator body in general, and
the scope tunnel in particular.

surgicalscience Page 24


# Page 36

Chapter 3 
 GI Mentor Express Platform
 
Page 25
 
Simulator body and connectors  
The simulator body is connected to the laptop and to the scope, the master tool and 
the foot switch. 
 
Figure 3-5: Simulator body connections 
1.  Connect the simulator power supply to its socket (2) on the back of the simulator 
body and to the power outlet. 
2.  Connect the 2 cables (3) and (4) from the back of the simulator body to the laptop 
USB sockets (see Figure 3-5). 
3.  Connect the foot switch cable to its socket (5) on the back of the simulator body. 
4.  Turn on the power switch (1). 
The extension sleeve should always be assembled when working with the simulator 
and can be disassembled for storage purposes.  


[TABLE]
| Chapter 3                                                                           | GI Mentor Express Platform                                                              |
|:------------------------------------------------------------------------------------|:----------------------------------------------------------------------------------------|
| Simulator body and connectors                                                       |                                                                                         |
| The simulator body is connected to the laptop and to the scope, the master tool and |                                                                                         |
| the foot switch.                                                                    |                                                                                         |
| F                                                                                   |                                                                                         |
| i                                                                                   |                                                                                         |
| gure 3-5: Simulator body connections                                                |                                                                                         |
|                                                                                     | 1.   Connect the simulator power supply to its socket (2) on the back of the simulator  |
| body and to the power outlet.                                                       |                                                                                         |
|                                                                                     | 2.   Connect the 2 cables (3) and (4) from the back of the simulator body to the laptop |
| USB sockets (see Figure 3-5).                                                       |                                                                                         |
|                                                                                     | 3.   Connect the foot switch cable to its socket (5) on the back of the simulator body. |
| 4.   Turn on the power switch (1).                                                  |                                                                                         |
| The extension sleeve should always be assembled when working with the simulator     |                                                                                         |
| and can be disassembled for storage purposes.                                       |                                                                                         |
|                                                                                     | Page 25                                                                                 |

[OCR]
Chapter 3 Gl Mentor Express Platform

Simulator body and connectors

The simulator body is connected to the laptop and to the scope, the master tool and
the foot switch.

3.
4.

Figure 3-5: Simulator body connections

Connect the simulator power supply to its socket (2) on the back of the simulator
body and to the power outlet.

Connect the 2 cables (3) and (4) from the back of the simulator body to the laptop
USB sockets (see Figure 3-5).

Connect the foot switch cable to its socket (5) on the back of the simulator body.
Turn on the power switch (1).

The extension sleeve should always be assembled when working with the simulator
and can be disassembled for storage purposes.

surgicalscience Page 25


# Page 37

Chapter 3 
 GI Mentor Express Platform
 
Page 26
 
Connecting the sleeve 
1.  Insert the sleeve into the sleeve opening on the simulator body, aligning the holes 
on each component. 
 
2.  Insert the two black thumb screws in the holes and tighten in place. 
Note: The complete sleeve length should be resting on the table at the same height as the 
simulator body and must not be hanging in the air. 
 
  
 


[TABLE]
| Chapter 3                                                                                  |
|  GI Mentor Express Platform                                                                |
|:-------------------------------------------------------------------------------------------|
| Connecting the sleeve                                                                      |
| 1.                                                                                         |
| Insert the sleeve into the sleeve opening on the simulator body, aligning the holes        |
| on each component.                                                                         |
| 2.                                                                                         |
| Insert the two black thumb screws in the holes and tighten in place.                       |
| Note:  The complete sleeve length should be resting on the table at the same height as the |
| simulator body and must not be hanging in the air.                                         |
| Page 26                                                                                    |

[OCR]
Chapter 3 Gl Mentor Express Platform

Connecting the sleeve

1. Insert the sleeve into the sleeve opening on the simulator body, aligning the holes
on each component.

2. Insert the two black thumb screws in the holes and tighten in place.

Note: The complete sleeve length should be resting on the table at the same height as the
simulator body and must not be hanging in the air.

surgical Page 26


# Page 38

Chapter 3 
 GI Mentor Express Platform
 
Page 27
 
 
Figure 3-6: Connecting the sleeve 


[TABLE]
| Chapter 3                       | GI Mentor Express Platform   |
|:--------------------------------|:-----------------------------|
| F                               |                              |
| i                               |                              |
| gure 3-6: Connecting the sleeve |                              |
|                                 | Page 27                      |

[OCR]
Chapter 3 Gl Mentor Express Platform

Figure 3-6: Connecting the sleeve

surgicalscience Page 27


# Page 39

Chapter 3 
 GI Mentor Express Platform
 
Page 28
 
Connecting the scope 
To connect the scope:  
1.  Fit the scope side connector exactly in the prongs and recesses of the simulator’s 
side connector (the single prong towards 6:00 o’clock).  
 
 
Figure 3-7: System side and scope side connectors 
2.  Turn the external dial on the scope connector to the right until you hear a click. 
To disconnect the scope: 
1.  Turn the dial to the left and remove the scope side connector. 


[TABLE]
| Chapter 3                                                                               | GI Mentor Express Platform                                                              |
|:----------------------------------------------------------------------------------------|:----------------------------------------------------------------------------------------|
| Connecting the scope                                                                    |                                                                                         |
| To connect the scope:                                                                   |                                                                                         |
|                                                                                         | 1.   Fit the scope side connector exactly in the prongs and recesses of the simulator’s |
| side connector (the single prong towards 6:00 o’clock).                                 |                                                                                         |
| F                                                                                       |                                                                                         |
| i                                                                                       |                                                                                         |
| gure 3-7: System side and scope side connectors                                         |                                                                                         |
| 2.   Turn the external dial on the scope connector to the right until you hear a click. |                                                                                         |
| To disconnect the scope:                                                                |                                                                                         |
| 1.   Turn the dial to the left and remove the scope side connector.                     |                                                                                         |
|                                                                                         | Page 28                                                                                 |

[OCR]
Chapter 3 Gl Mentor Express Platform

Connecting the scope

To connect the scope:

1. Fit the scope side connector exactly in the prongs and recesses of the simulator’s
side connector (the single prong towards 6:00 o'clock).

Figure 3-7: System side and scope side connectors

2. Turn the external dial on the scope connector to the right until you hear a click.

To disconnect the scope:
1. Turn the dial to the left and remove the scope side connector.

surgicalscience Page 28


# Page 40

Chapter 3 
 GI Mentor Express Platform
 
Page 29
 
Note: Bumping against the scope side connector while connected may result in damage to both 
the scope and the system. 
Scope 
 
 
 
1 – Working Channel  
2 – Up-Down 
Directional Knob  
3 – Right-Left 
Directional Knob 
4 – Lock/Free Switch 
for Up-Down 
Movement  
5 – Lock/Free Switch 
for Right-Left 
Movement 
6 – Suction Button  
7 – Insufflation and 
Irrigation Button 
Figure 3-8: GI Mentor Express scope 


[TABLE]
| 1                    |
|  – Working Channel   |
|:---------------------|
| 2 – Up-Down          |
| Directional Knob     |
| 3 – Right-Left       |
| Directional Knob     |
| 4 – Lock/Free Switch |
| for Up-Down          |
| Movement             |
| 5 – Lock/Free Switch |
| for Right-Left       |
| Movement             |
| 6 – Suction Button   |
| 7 – Insufflation and |
| Irrigation Button    |

[OCR]
Chapter 3

Gl Mentor Express Platform

Note: Bumping against the scope side connector while connected may result in damage to both

the scope and the system.

Scope

2-
3-

4-

5-

Figure 3-8: Gi Mentor Express scope

1 - Working Channel

Up-Down

Directional Knob

Right-Left

Directional Knob

Lock/Free Switch

for Up-Down
Movement

Lock/Free Switch

for Right-Left
Movement

6 - Suction Button

7 - Insufflation and
Irrigation Button

surgicalscience

Page 29


# Page 41

Chapter 3 
 GI Mentor Express Platform
 
Page 30
 
Auxiliary tools and devices 
The GI Mentor Express has the following tools and devices provided with the platform: 
a Master Tool, a foot switch, and a wireless mouse. 
Master Tool 
The Master Tool is used to simulate all the tools in the basic GI modules. 
 
Figure 3-9: Master Tool inserted into the work channel 
To select a virtual tool using the Master Tool: 
1.  Insert the Master Tool all the way through the working channel until the Tools 
menu appears on the screen.  
The Tools menu opens with pictures of all available tools.  
Note: The master tool wire insertion required is much less than in a real procedure. Once 
introduced into the working channel, the simulated tool is considered as being almost out 
of the working channel’s distal end.  
To work with Master Tool handle: 
• 
Pull the Master Tool handle back to open, inflate, or fill the tool. 
• 
Push the Master Tool handle forward to close, deflate, or inject using the tool.  


[TABLE]
| Chapter 3                                                                  | GI Mentor Express Platform                                                            |
|:---------------------------------------------------------------------------|:--------------------------------------------------------------------------------------|
| Auxiliary tools and devices                                                |                                                                                       |
|                                                                            | The GI Mentor Express has the following tools and devices provided with the platform: |
| a Master Tool, a foot switch, and a wireless mouse.                        |                                                                                       |
| Master Tool                                                                |                                                                                       |
| The Master Tool is used to simulate all the tools in the basic GI modules. |                                                                                       |

[OCR]
Chapter 3 Gl Mentor Express Platform

Auxiliary tools and devices

The GI Mentor Express has the following tools and devices provided with the platform:
a Master Tool, a foot switch, and a wireless mouse.

Master Tool

The Master Tool is used to simulate all the tools in the basic Gl modules.

Figure 3-9: Master Tool inserted into the work channel

To select a virtual tool using the Master Tool:

1. Insert the Master Tool all the way through the working channel until the Tools
menu appears on the screen.

The Tools menu opens with pictures of all available tools.

Note: The master tool wire insertion required is much less than in a real procedure. Once
introduced into the working channel, the simulated tool is considered as being almost out
of the working channel's distal end.

To work with Master Tool handle:

e Pull the Master Tool handle back to open, inflate, or fill the tool.
. Push the Master Tool handle forward to close, deflate, or inject using the tool.

surgicalscience Page 30


# Page 42

Chapter 3 
 GI Mentor Express Platform
 
Page 31
 
Foot switch 
The foot switch is connected to the simulator body as seen in Figure 3-5 and is used 
to simulate the application of electrosurgical current. 
 
 
Figure 3-10: Foot switch 
 


[TABLE]
| Chapter 3                                                                            | GI Mentor Express Platform   |
|:-------------------------------------------------------------------------------------|:-----------------------------|
| Foot switch                                                                          |                              |
| The foot switch is connected to the simulator body as seen in Figure 3-5 and is used |                              |
| to simulate the application of electrosurgical current.                              |                              |
| F                                                                                    |                              |
| i                                                                                    |                              |
| gure 3-10: Foot switch                                                               |                              |
|                                                                                      | Page 31                      |

[OCR]
Chapter 3 Gl Mentor Express Platform

Foot switch

The foot switch is connected to the simulator body as seen in Figure 3-5 and is used
to simulate the application of electrosurgical current.

-

Figure 3-10: Foot switch

surgicalscience Page 31


# Page 43

Chapter 4 
 Getting Started
 
Page 32
 
Chapter 4 Getting Started  
This chapter explains in general terms how to begin using the system. 
User interface 
The GI Mentor simulator’s interface may be operated using either the touch screen or 
the trackball (or the wireless mouse for the GI Mentor Express).  
• 
Touch screen: Use the tip of your finger to touch the buttons and icons as 
directed in this manual or 
• 
Use the trackball/mouse in the usual fashion, as a computer mouse. 
Note: In this document, Press will be used to either click a button or icon with the mouse or tap 
a button or icon on the Touch screen. 
Essential workflow 
The following chapters will describe how to use the simulator. To get started, on any 
simulation case or task follow this workflow. 
1.  Log in to the simulator, entering your login name and password (see page 34). 
2.  Select a module or course from the Library and review its didactic materials if 
available (see page 37). 
3.  Start a simulation case or task (see page 42). 
4.  Perform the virtual patient simulation: inspecting, diagnosing and treating as you 
see fit. Multiple educational aids and helpers are at your disposal (see page 50).  
5.  Once you have completed treating the virtual patient, click Finish to exit the 
simulation. 
6.  Review your performance report and learning curve graphs (see page 103). 


[TABLE]
| Chapter 4                                                                            | Getting Started   |
|:-------------------------------------------------------------------------------------|:------------------|
| Chapter 4 Getting Started                                                            |                   |
| This chapter explains in general terms how to begin using the system.                |                   |
| User interface                                                                       |                   |
| The GI Mentor simulator’s interface may be operated using either the touch screen or |                   |
| the trackball (or the wireless mouse for the GI Mentor Express).                     |                   |

[TABLE]
| User interface                                                                       |                                                                                             |
|:-------------------------------------------------------------------------------------|:--------------------------------------------------------------------------------------------|
| The GI Mentor simulator’s interface may be operated using either the touch screen or |                                                                                             |
| the trackball (or the wireless mouse for the GI Mentor Express).                     |                                                                                             |
| •                                                                                    | Touch screen: Use the tip of your finger to touch the buttons and icons as                  |
|                                                                                      | directed in this manual or                                                                  |
| •                                                                                    | Use the trackball/mouse in the usual fashion, as a computer mouse.                          |
| Note:                                                                                | In this document, Press will be used to either click a button or icon with the mouse or tap |
|                                                                                      | a button or icon on the Touch screen.                                                       |

[OCR]
Chapter 4 Getting Started

| Chapter 4 Getting Started

This chapter explains in general terms how to begin using the system.

User interface

The GI Mentor simulator’s interface may be operated using either the touch screen or
the trackball (or the wireless mouse for the GI Mentor Express).

. Touch screen: Use the tip of your finger to touch the buttons and icons as
directed in this manual or
. Use the trackball/mouse in the usual fashion, as a computer mouse.

Note: In this document, Press will be used to either click a button or icon with the mouse or tap
a button or icon on the Touch screen.

Essential workflow

The following chapters will describe how to use the simulator. To get started, on any
simulation case or task follow this workflow.

1. Login to the simulator, entering your login name and password (see page 34).

2. Select a module or course from the Library and review its didactic materials if
available (see page 37).

3. Start.a simulation case or task (see page 42).

4. Perform the virtual patient simulation: inspecting, diagnosing and treating as you
see fit. Multiple educational aids and helpers are at your disposal (see page 50).

5. Once you have completed treating the virtual patient, click Finish to exit the
simulation.

6. Review your performance report and learning curve graphs (see page 103).

surgicalscience Page 32


# Page 44

Chapter 5 
 MentorLearn
 
Page 33
 
Chapter 5 MentorLearn 
MentorLearn overview 
MentorLearn® is a web-based simulator curricula management system, providing the 
optimal solution for managing training and education needs for the Surgical Science 
line of simulators.  
This easy-to-use system facilitates performing the administrative tasks of a simulator-
based curriculum, running a training course or workshop. The system includes a library 
of ready-to-use simulator-based courses and a platform to design new training 
courses. Courses may include online didactic content, proficiency based hands-on 
training, and performance review and assessment. For more information regarding 
using MentorLearn, refer to the MentorLearn Guide for Learners. 
MentorLearn workflow 
All GI Mentor modules, including didactic materials, simulation tasks, simulation cases, 
are accessed from MentorLearn, Surgical Science's web-based simulation curricula 
management system. 
When you want to use didactic materials from a GI Mentor module, you log in to 
MentorLearn and open the materials from MentorLearn. The MentorLearn login page 
appears on the screen when you turn on the system. 
When you want to perform a hands-on training task or case, you open it from 
MentorLearn. MentorLearn opens the GI Mentor task or case for you, closes it when 
you finish the case or task, and shows you a report of your performance afterwards. 
This is the workflow for performing hands-on training: 
• 
Log in to MentorLearn on the simulator (see page 34). 
• 
Review didactic material (see page 41). 
• 
Start a GI Mentor hands-on case or task from MentorLearn (see Starting a 
simulation case or task on page 42). MentorLearn opens it for you to begin the 
hands-on simulation. 
• 
Perform the case or task using the GI Mentor simulator (see Performing surgery 
on page 97). When you finish the case or task, MentorLearn closes it and 
displays a performance report. 
• 
Review your performance (see Viewing Performance Reports on page 103). 
 


[TABLE]
| Chapter 5                                                                           | MentorLearn                                                                              |
|:------------------------------------------------------------------------------------|:-----------------------------------------------------------------------------------------|
| Chapter 5 MentorLearn                                                               |                                                                                          |
| MentorLearn overview                                                                |                                                                                          |
| MentorLearn® is a web-based simulator curricula management system, providing the    |                                                                                          |
| optimal solution for managing training and education needs for the Surgical Science |                                                                                          |
| line of simulators.                                                                 |                                                                                          |
|                                                                                     | This easy-to-use system facilitates performing the administrative tasks of a simulator-  |
|                                                                                     | based curriculum, running a training course or workshop. The system includes a library   |
| of ready-to-use simulator-based courses and a platform to design new training       |                                                                                          |
| courses. Courses may include online didactic content, proficiency based hands-on    |                                                                                          |
| training, and performance review and assessment. For more information regarding     |                                                                                          |
| using MentorLearn, refer to the MentorLearn Guide for Learners.                     |                                                                                          |
| MentorLearn workflow                                                                |                                                                                          |
|                                                                                     | All GI Mentor modules, including didactic materials, simulation tasks, simulation cases, |
| are accessed from MentorLearn, Surgical Science's web-based simulation curricula    |                                                                                          |
| management system.                                                                  |                                                                                          |
| When you want to use didactic materials from a GI Mentor module, you log in to      |                                                                                          |
| MentorLearn and open the materials from MentorLearn. The MentorLearn login page     |                                                                                          |
| appears on the screen when you turn on the system.                                  |                                                                                          |
| When you want to perform a hands-on training task or case, you open it from         |                                                                                          |
| MentorLearn. MentorLearn opens the GI Mentor task or case for you, closes it when   |                                                                                          |
| you finish the case or task, and shows you a report of your performance afterwards. |                                                                                          |
| This is the workflow for performing hands-on training:                              |                                                                                          |

[TABLE]
| When you want to perform a hands-on training task or case, you open it from         |                                                                                |
|:------------------------------------------------------------------------------------|:-------------------------------------------------------------------------------|
| MentorLearn. MentorLearn opens the GI Mentor task or case for you, closes it when   |                                                                                |
| you finish the case or task, and shows you a report of your performance afterwards. |                                                                                |
| This is the workflow for performing hands-on training:                              |                                                                                |
| •                                                                                   | Log in to MentorLearn on the simulator (see page 34).                          |
| •                                                                                   | Review didactic material (see page 41).                                        |
| •                                                                                   | Start a GI Mentor hands-on case or task from MentorLearn (see Starting a       |
|                                                                                     | simulation case or task on page 42). MentorLearn opens it for you to begin the |
|                                                                                     | hands-on simulation.                                                           |
| •                                                                                   | Perform the case or task using the GI Mentor simulator (see Performing surgery |
|                                                                                     | on page 97). When you finish the case or task, MentorLearn closes it and       |
|                                                                                     | displays a performance report.                                                 |
| •                                                                                   | Review your performance (see Viewing Performance Reports on page 103).         |

[OCR_TABLE]
Si Ee

[OCR_TABLE]
Mento

[OCR]
Chapter 5 MentorLearn

| Chapter 5 MentorLearn

MentorLearn overview

MentorLearn® is a web-based simulator curricula management system, providing the
optimal solution for managing training and education needs for the Surgical Science
line of simulators.

This easy-to-use system facilitates performing the administrative tasks of a simulator-
based curriculum, running a training course or workshop. The system includes a library
of ready-to-use simulator-based courses and a platform to design new training
courses. Courses may include online didactic content, proficiency based hands-on
training, and performance review and assessment. For more information regarding
using MentorLearn, refer to the MentorLearn Guide for Learners.

MentorLearn workflow

All GI Mentor modules, including didactic materials, simulation tasks, simulation cases,
are accessed from MentorLearn, Surgical Science's web-based simulation curricula
management system.

When you want to use didactic materials from a GI Mentor module, you log in to
MentorLearn and open the materials from MentorLearn. The MentorLearn login page
appears on the screen when you turn on the system.

When you want to perform a hands-on training task or case, you open it from
MentorLearn. MentorLearn opens the GI Mentor task or case for you, closes it when
you finish the case or task, and shows you a report of your performance afterwards.
This is the workflow for performing hands-on training:

e Log in to MentorLearn on the simulator (see page 34).
e Review didactic material (see page 41).
e Start a GI Mentor hands-on case or task from MentorLearn (see Starting a

simulation case or task on page 42). MentorLearn opens it for you to begin the
hands-on simulation.

e Perform the case or task using the GI Mentor simulator (see Performing surgery
on page 97). When you finish the case or task, MentorLearn closes it and
displays a performance report.

. Review your performance (see Viewing Performance Reports on page 103).

surgicalscience Page 33


# Page 45

Chapter 5 
 MentorLearn
 
Page 34
 
Logging in to MentorLearn on the simulator 
In order to access functionality on a simulator, you need to first enter the MentorLearn 
system. You require a login name and password to login. When you log in, your Library 
screen is displayed. For more information regarding using MentorLearn, refer to the 
MentorLearn Guide for Learners or MentorLearn Guide for Administrators. 
Note: If you are entering the application for the first time, contact your system administrator 
and ask him to create your user profile.  
To log in: 
 
Figure 6-1: MentorLearn Login screen 
1.  Press Login. 
The Login screen is displayed. 


[TABLE]
| Chapter 5                                                                                 |
|  MentorLearn                                                                              |
|:------------------------------------------------------------------------------------------|
| Logging in to MentorLearn on the simulator                                                |
| In order to access functionality on a simulator, you need to first enter the MentorLearn  |
| system. You require a login name and password to login. When you log in, your Library     |
| screen is displayed. For more information regarding using MentorLearn, refer to the       |
| MentorLearn Guide for Learners or MentorLearn Guide for Administrators.                   |
| Note:                                                                                     |
| If you are entering the application for the first time, contact your system administrator |
| and ask him to create your user profile.                                                  |

[OCR]
Chapter 5 MentorLearn

Logging in to MentorLearn on the simulator

In order to access functionality on a simulator, you need to first enter the MentorLearn
system. You require a login name and password to login. When you log in, your Library
screen is displayed. For more information regarding using MentorLearn, refer to the
MentorLearn Guide for Learners or MentorLearn Guide for Administrators.

Note: If you are entering the application for the first time, contact your system administrator
and ask him to create your user profile.

To log in:

Register to use the system

Select Language

English

Select Theme

Light

Figure 6-1: MentorLearn Login screen

1. Press Login.
The Login screen is displayed.

surgicalscience Page 34


# Page 46

Chapter 5 
 MentorLearn
 
Page 35
 
 
2.  In Login Name, enter your login name. The login name is case sensitive. 
3.  In Password, enter your password. Your password is case sensitive. 
4.  Press Login. 
MentorLearn opens and displays your Library screen. Your first name and last 
name appear in the top right corner of the screen. 


[TABLE]
| Chapter 5                                                                    |
|  MentorLearn                                                                 |
|:-----------------------------------------------------------------------------|
| 2.                                                                           |
| In Login Name, enter your login name. The login name is case sensitive.      |
| 3.                                                                           |
| In Password, enter your password. Your password is case sensitive.           |
| 4.   Press Login.                                                            |
| MentorLearn opens and displays your Library screen. Your first name and last |
| name appear in the top right corner of the screen.                           |
| Page 35                                                                      |

[OCR]
Chapter 5

MentorLearn

surgicalscience

Login Name

Password

LOGIN

|

Forgot Password?

LOG IN AS A GUEST

RETURN TO MAIN PAGE

RON

In Login Name, enter your login name. The login name is case sensitive.
In Password, enter your password. Your password is case sensitive.
Press Login.

MentorLearn opens and displays your Library screen. Your first name and last

name appear in the top right corner of the screen.

surgicalscience

Page 35


# Page 47

Chapter 5 
 MentorLearn
 
Page 36
 
When you log in to MentorLearn, the MentorLearn menu appears on the left side of 
the screen. 
 
The menu gives you structured access to the MentorLearn functionality. Press any 
menu option to open the associated screen in MentorLearn. Press 
 above the 
MentorLearn menu to hide it. 
Note: The buttons that appear on the MentorLearn menu are dependent on your 
user-type. 
Working locally and on a cloud site 
The cloud configuration is possible only if there is access to the internet. If there is 
temporarily no internet access but you need to use the simulators, you can switch to 
working locally on the simulator.  
When you switch to work locally, MentorLearn switches from the cloud database to a 
local database, meaning:  
• 
Group, user, and assigned course information is not saved to the local simulator. 
If necessary, groups and users must be redefined on each local simulator, and 
training must be reassigned. 
• 
Any data that is created during the time you are working locally is not saved to 
the cloud database after the simulator is switched back to the cloud site. Any 
reports or information on how a user performed a simulator case will not be 
available, new users and groups, and so on, are maintained in the local database 
and are not available when you are in cloud site. 
 


[TABLE]
| Note: The buttons that appear on the MentorLearn menu are dependent on your              |
|:-----------------------------------------------------------------------------------------|
| user-type.                                                                               |
| Working locally and on a cloud site                                                      |
| The cloud configuration is possible only if there is access to the internet. If there is |
| temporarily no internet access but you need to use the simulators, you can switch to     |
| working locally on the simulator.                                                        |
| When you switch to work locally, MentorLearn switches from the cloud database to a       |
| local database, meaning:                                                                 |

[TABLE]
| working locally on the simulator.                                                  |                                                                                   |
|:-----------------------------------------------------------------------------------|:----------------------------------------------------------------------------------|
| When you switch to work locally, MentorLearn switches from the cloud database to a |                                                                                   |
| local database, meaning:                                                           |                                                                                   |
| •                                                                                  | Group, user, and assigned course information is not saved to the local simulator. |
|                                                                                    | If necessary, groups and users must be redefined on each local simulator, and     |
|                                                                                    | training must be reassigned.                                                      |
| •                                                                                  | Any data that is created during the time you are working locally is not saved to  |
|                                                                                    | the cloud database after the simulator is switched back to the cloud site. Any    |
|                                                                                    | reports or information on how a user performed a simulator case will not be       |
|                                                                                    | available, new users and groups, and so on, are maintained in the local database  |
|                                                                                    | and are not available when you are in cloud site.                                 |

[OCR_TABLE]
Libr:

[OCR]
Chapter 5 MentorLearn

When you log in to MentorLearn, the MentorLearn menu appears on the left side of
the screen.

Library
My Curricula
Reports

My Profile

The menu gives you structured access to the MentorLearn functionality. Press any

menu option to open the associated screen in MentorLearn. Press = above the
MentorLearn menu to hide it.

Note: The buttons that appear on the MentorLearn menu are dependent on your
user-type.

Working locally and on a cloud site

The cloud configuration is possible only if there is access to the internet. If there is
temporarily no internet access but you need to use the simulators, you can switch to
working locally on the simulator.

When you switch to work locally, MentorLearn switches from the cloud database to a
local database, meaning:

Group, user, and assigned course information is not saved to the local simulator.
If necessary, groups and users must be redefined on each local simulator, and
training must be reassigned.

Any data that is created during the time you are working locally is not saved to
the cloud database after the simulator is switched back to the cloud site. Any
reports or information on how a user performed a simulator case will not be
available, new users and groups, and so on, are maintained in the local database
and are not available when you are in cloud site.

surgicalscience Page 36


# Page 48

Chapter 5 
 MentorLearn
 
Page 37
 
To switch from working on the MentorLearn cloud site to working locally: 
1.  Open MentorLearn on the simulator. MentorLearn is redirected to work locally with 
the selected simulator. The 
 icon on the top of any screen changes to the 
 
icon.  
Note: It is recommended that you switch back to cloud mode as soon the internet connection is 
restored. 
 
To switch from working locally to working on the MentorLearn cloud site: 
1.  Open the web browser and go to http://Your-site-name.mentorlearn.com    
MentorLearn is redirected to work with the MentorLearn cloud database. The 
 
icon on the top of any screen changes to the 
 icon. 
Accessing a module or course within My Curricula or 
Library 
This section describes how users train using MentorLearn. 
• 
To access training courses and modules that you have been assigned, press My 
Curricula on the MentorLearn menu (left pane). 
 
Figure 5-2: My Curricula screen 
• 
To access all the training courses and modules available in the library, press 
Library on the MentorLearn menu (left pane). 


[TABLE]
| Chapter 5                                                                                     |
|  MentorLearn                                                                                  |
|:----------------------------------------------------------------------------------------------|
| To switch from working on the MentorLearn cloud site to working locally:                      |
| 1.   Open MentorLearn on the simulator. MentorLearn is redirected to work locally with        |
| the selected simulator. The                                                                   |
|  icon on the top of any screen changes to the                                                 |
| icon.                                                                                         |
| Note: It is recommended that you switch back to cloud mode as soon the internet connection is |
| restored.                                                                                     |
| T                                                                                             |
| o switch from working locally to working on the MentorLearn cloud site:                       |
| 1.   Open the web browser and go to http://Your-site-name.mentorlearn.com                     |
| MentorLearn is redirected to work with the MentorLearn cloud database. The                    |
| icon on the top of any screen changes to the                                                  |
|  icon.                                                                                        |
| Accessing a module or course within My Curricula or                                           |
| Library                                                                                       |
| This section describes how users train using MentorLearn.                                     |
| To access training courses and modules that you have been assigned, press My                  |
| •                                                                                             |
| Curricula on the MentorLearn menu (left pane).                                                |
| F                                                                                             |
| i                                                                                             |
| gure 5-2: My Curricula screen                                                                 |
| To access all the training courses and modules available in the library, press                |
| •                                                                                             |
| Library on the MentorLearn menu (left pane).                                                  |
| Page 37                                                                                       |

[OCR]
Chapter 5 MentorLearn

To switch from working on the MentorLearn cloud site to working locally:
1. Open MentorLearn on the simulator. MentorLearn is redirected to work locally with

the selected simulator. The &é icon on the top of any screen changes to the Q
icon.

Note: It is recommended that you switch back to cloud mode as soon the internet connection is
restored.

To switch from working locally to working on the MentorLearn cloud site:
1. Open the web browser and go to http://Your-site-name.mentorlearn.com

MentorLearn is redirected to work with the MentorLearn cloud database. The Q

icon on the top of any screen changes to the &é icon.

Accessing a module or course within My Curricula or
Library

This section describes how users train using MentorLearn.

e To access training courses and modules that you have been assigned, press My
Curricula on the MentorLearn menu (left pane).

‘Second Year Residents - Gastro

Figure 5-2: My Curricula screen

. To access all the training courses and modules available in the library, press
Library on the MentorLearn menu (left pane).

surgicalscience Page 37


# Page 49

Chapter 5 
 MentorLearn
 
Page 38
 
 
Figure 5-3: GI Mentor Library screen  
On the Library screen, MentorLearn displays the list of modules and courses. They are 
categorized as Surgical Science Simulation Modules, Standard Courses (ready-to-use 
courses provided by experienced educators in collaboration with Surgical Science), 
and Customized Courses (courses you and other educators at your center have 
created). 
Grid view of the Library 
The grid view of the Library has been designed for tablets and small screens to 
enhance user accessibility. 
Click 
 to view the Library in the grid view. 


[TABLE]
|                                                                                       | F                                    |                                       |
|                                                                                       | i                                    |                                       |
|                                                                                       | gure 5-3: GI Mentor Library screen   |                                       |
|:--------------------------------------------------------------------------------------|:-------------------------------------|:--------------------------------------|
| On the Library screen, MentorLearn displays the list of modules and courses. They are |                                      |                                       |
| categorized as Surgical Science Simulation Modules, Standard Courses (ready-to-use    |                                      |                                       |
| courses provided by experienced educators in collaboration with Surgical Science),    |                                      |                                       |
| and Customized Courses (courses you and other educators at your center have           |                                      |                                       |
| created).                                                                             |                                      |                                       |
| Grid view of the Library                                                              |                                      |                                       |
| The grid view of the Library has been designed for tablets and small screens to       |                                      |                                       |
| enhance user accessibility.                                                           |                                      |                                       |
| Click                                                                                 |                                      | to view the Library in the grid view. |

[OCR]
Chapter 5 MentorLearn

Simulation Modules
Skills and Tasks

ts) Cyberscopy - EndoBasket
Proficient: No, Completion: 0%:

\°) eee

Clinical Procedures

we First Module for Colonoscopy
Proficient: No, Completion: 0%

Second Module for Colonoscopy
By) Sete cee
profient No, compton: 0
f) Flexible Sigmoidescopy
GR] caret. ean
TBR] sevanced costo emergency Bleeding
[REDD ret toate forener

Figure 5-3: G! Mentor Library screen

On the Library screen, MentorLearn displays the list of modules and courses. They are
categorized as Surgical Science Simulation Modules, Standard Courses (ready-to-use
courses provided by experienced educators in collaboration with Surgical Science),
and Customized Courses (courses you and other educators at your center have
created).

Grid view of the Library

The grid view of the Library has been designed for tablets and small screens to
enhance user accessibility.

Click =| to view the Library in the grid view.

surgicalscience Page 38


# Page 50

Chapter 5 
 MentorLearn
 
Page 39
 
 
Figure 6-4: Library in grid view 
Click  
 to return to the list view. 


[TABLE]
| Chapter 5                      |                             | MentorLearn   |
|:-------------------------------|:----------------------------|:--------------|
| F                              |                             |               |
| i                              |                             |               |
| gure 6-4: Library in grid view |                             |               |
| Click                          | to return to the list view. |               |
|                                |                             | Page 39       |

[OCR]
Chapter 5

MentorLearn

Q  oisteya >

‘Simulation Modules
‘Sle and Tasks

r) ] Coyberscopy -EndoBacket
Clinical Procedures

CAI) iste for caonescons
Profit: No, Completion 0%

BI) Sesto sosoecny

[Ba raerns caste mein Beads
[Ag] 0s testo

Endoscopy Skil Competition

QA} crercoseepy stats competnon

Quizzes

ey ‘quizzes Lmrary GI Mentor
Profit: Na, complation 2%

Prosar No, Compl

Gy eee

[ai matte cater oO

[I eros rrsonemt sas

‘Second Module for Colonoecopy
Proficient No, Completion. 0%

Led ves =

Figure 6-4: Library in grid view

Click [=| to return to the list view.

surgicalscience

Page 39


# Page 51

Chapter 5 
 MentorLearn
 
Page 40
 
Easy Access to courses and modules in the Library 
 
To easily access courses and modules in 
the Library, press the Easy Access arrow 
on the top right side of the screen and 
select an option from the list. 
To search for a specific module or group 
of modules, press the Search button, 
enter a term and press the Search button 
again. To clear the search results, press 
one of the easy access options. 
 
Open a module or course, review didactic material or perform in a hands-on simulation 
case. For more information, see Reviewing didactic materials on page 41 and on 
Starting a simulation case or task on page 42. 
 
1.  To open a module or course, press its row. The module opens, displaying a 
description of the module, its learning objectives, and the educational content of 
the module. 


[TABLE]
| Easy Access to courses and modules in the Library   |
|:----------------------------------------------------|
| To easily access courses and modules in             |
| the Library, press the Easy Access arrow            |
| on the top right side of the screen and             |
| select an option from the list.                     |
| To search for a specific module or group            |
| of modules, press the Search button,                |
| enter a term and press the Search button            |
| again. To clear the search results, press           |
| one of the easy access options.                     |

[OCR_TABLE]
Cnapter o

[OCR]
Chapter 5 MentorLearn

Easy Access to courses and modules in the Library

To easily access courses and modules in

Q_DisplayAll ~ the Library, press the Easy Access arrow
on the top right side of the screen and
select an option from the list.

To search for a specific module or group
of modules, press the Search button,
Customized Courses enter a term and press the Search button
again. To clear the search results, press
one of the easy access options.

Display All

Standard Courses

Modules

Open a module or course, review didactic material or perform in a hands-on simulation
case. For more information, see Reviewing didactic materials on page 41 and on
Starting a simulation case or task on page 42.

1. To open a module or course, press its row. The module opens, displaying a
description of the module, its learning objectives, and the educational content of
the module.

surgicalscience Page 40


# Page 52

Chapter 5 
 MentorLearn
 
Page 41
 
 
Figure 5-5: Opening a module 
Reviewing didactic materials 
The GI Mentor modules and courses include didactic materials preceding the hands-on 
training. Materials may include simulation course/curricula and real-life procedure 
videos. 
1.  On the MentorLearn menu, press Library. 
MentorLearn displays the list of simulation modules and standard courses in the 
simulator library. 
2.  Open a module or course by pressing its row. The module opens, displaying a 
description of the module and all the items in the module. 
3.  Under Didactics, select the didactic material you want to look at and press its row. 


[TABLE]
| F                                                                                         |
| i                                                                                         |
| gure 5-5: Opening a module                                                                |
|:------------------------------------------------------------------------------------------|
| Reviewing didactic materials                                                              |
| The GI Mentor modules and courses include didactic materials preceding the hands-on       |
| training. Materials may include simulation course/curricula and real-life procedure       |
| videos.                                                                                   |
| 1.   On the MentorLearn menu, press Library.                                              |
| MentorLearn displays the list of simulation modules and standard courses in the           |
| simulator library.                                                                        |
| 2.   Open a module or course by pressing its row. The module opens, displaying a          |
| description of the module and all the items in the module.                                |
| 3.   Under Didactics, select the didactic material you want to look at and press its row. |

[OCR]
Chapter 5 MentorLearn

EMR Cases

Didactics

Proctor Book EMRESD pat

sion Examination Basics. pd!

[og 121 sete ert ntoners
Le 2c toners

2

az case3-EMRinUprer GI

k

Figure 5-5: Opening a module

Reviewing didactic materials

The GI Mentor modules and courses include didactic materials preceding the hands-on
training. Materials may include simulation course/curricula and real-life procedure
videos.

1. On the MentorLearn menu, press Library.
MentorLearn displays the list of simulation modules and standard courses in the
simulator library.

2. Open a module or course by pressing its row. The module opens, displaying a
description of the module and all the items in the module.
3. Under Didactics, select the didactic material you want to look at and press its row.

surgicalscience Page 41


# Page 53

Chapter 5 
 MentorLearn
 
Page 42
 
 
Note: If the didactic material is in a format that is not supported by the simulator, 
you are prompted to save the file to an external location. PDF, mp4 files, and 
graphic files can be opened on the simulator. Microsoft® PowerPoint® and 
Word® files cannot be opened on a simulator. If you are using MentorLearn 
Cloud, the didactic material may be viewed on another computer by 
accessing your MentorLearn Cloud site. 
 
4.  When you have finished, close the material. 
 
Starting a simulation case or task 
To open a case or task: 
1.  From the MentorLearn menu, press one of the following menu options: 
o 
Library - lists all the courses and modules in the GI Mentor library. If other 
simulator libraries are listed, select Library > GI Mentor. 
o 
My Curricula - lists all your assigned courses and modules. 
2.  Press the Expand arrow 
 on the right side of the screen to display more details 
about the module or course. 


[TABLE]
| Note: If the didactic material is in a format that is not supported by the simulator,   |
|:----------------------------------------------------------------------------------------|
| you are prompted to save the file to an external location. PDF, mp4 files, and          |
| graphic files can be opened on the simulator. Microsoft® PowerPoint® and                |
| Word® files cannot be opened on a simulator. If you are using MentorLearn               |
| Cloud, the didactic material may be viewed on another computer by                       |
| accessing your MentorLearn Cloud site.                                                  |

[OCR]
Chapter 5 MentorLearn

Or. Eric Pauli

Note: If the didactic material is in a format that is not supported by the simulator,
you are prompted to save the file to an external location. PDF, mp4 files, and
graphic files can be opened on the simulator. Microsoft® PowerPoint® and
Word® files cannot be opened on a simulator. If you are using MentorLearn
Cloud, the didactic material may be viewed on another computer by
accessing your MentorLearn Cloud site.

4. When you have finished, close the material.

Starting a simulation case or task

To open a case or task:
1. From the MentorLearn menu, press one of the following menu options:

° Library - lists all the courses and modules in the GI Mentor library. If other
simulator libraries are listed, select Library > GI Mentor.
° My Curricula - lists all your assigned courses and modules.

v

2. Press the Expand arrow on the right side of the screen to display more details

about the module or course.

surgicalscience Page 42


# Page 54

Chapter 5 
 MentorLearn
 
Page 43
 
 
3.  Open the module or course you want by pressing its row. 
The details include a description and the objectives of the module or course. 
 
4.  Under Hands-on, select the case or task you want to perform, and press its row. 
The task description or patient file opens. 


[TABLE]
| Chapter 5                                                                            | MentorLearn   |
|:-------------------------------------------------------------------------------------|:--------------|
| 3.   Open the module or course you want by pressing its row.                         |               |
| The details include a description and the objectives of the module or course.        |               |
| 4.   Under Hands-on, select the case or task you want to perform, and press its row. |               |
| The task description or patient file opens.                                          |               |
|                                                                                      | Page 43       |

[OCR]
Chapter 5

MentorLearn

Description

‘The GI Endoscopy ~ Fundamental Skills module offers didactic tutorials and designated skill tasks to guide the learner through learning and acquiring competence in GI Flexible Endoscopy
essentials, Practicing this module's tasks the learner acquires and improves his Gl endoscopy understanding, capabilites and sensibilities. This module provides the learners with the
opportunity to assess themselves as they progress along the learning curve to competency, The different tasks shall address the five fundamental Gi flexible endoscopy skills, as were
deconstructed and defined by SAGES (Society of American Gastrointestinal and Endoscopic Surgeons)*: Endoscopic Navigation; Loop Reduction; Retroflexion; Mucosal Evaluation; Targeting
Surg Endosc. 2014 Mar; 2(3)704-11, dot: 10.1007/s00464-013-3298-4. Epub 2013 Nov 20. Fundamentals of endoscopic surgery: creation and validation of the hands-on test. Vassiliou MC1,
Dunkin BJ, Fried GM, Mellinger JO, Tus T, Kaneva P, Lyons C, Komdorffer JR Jr, Ujki M, Velanovich V, Kochman ML, Tsuda , Martinez J, Scott DJ, Korus G, Park A, Marks JM

3. Open the module or course you want by pressing its row.

The details include a description and the objectives of the module or course.

+ To elf assess ones hands-on proficiency levlin Gl Endoscopy Retoferion
+ To self-assess one's henson proficiency leven Gt Endoscopy Targeting wth 9 to)
+ To progress towards mastering the hands-on performance of al five fundamental sie
+ To prepare oneself to demonstrate hands-on proficiency in endoscopic fundamental skis

Endoscopic Navigation
Didaetc

Bs Endoscope insertion and Maneuvering

Hands-On

Mucosal Evaluation

Didactes

Bg. ver cr mucosa! Evasion — complete Workton

4. Under Hands-on, select the case or task you want to perform, and press its row.
The task description or patient file opens.

surgicalscience

Page 43


# Page 55

Chapter 5 
 MentorLearn
 
Page 44
 
 
Figure 5-6: Task description 
5.  Press 
. The simulation case begins. 
When you have completed the simulation case, you are returned to MentorLearn, 
and a report of your performance is displayed. 
6.  If at any time you wish to choose another case, module, or course or another 
MentorLearn Library, press that item in the browse sequence hierarchy above the 
middle pane. 
 
Viewing course/module completion status 
In some modules and courses, benchmarks have been defined for evaluating 
performance. A skill level for difference performance metrics, based on expert-derived 
goals, is used as a point of reference against which the learner’s performance is 
measured.  
A summary of your current performance is displayed for modules and courses that 
have benchmarks. Opening those modules/courses displays a detailed explanation 
about your performance in specific cases/tasks. You can view at a glance how far you 
are from reaching the required skill level and what is required to achieve the 
benchmark standard.  


[TABLE]
| F                                                                               |
| i                                                                               |
| gure 5-6: Task description                                                      |
|:--------------------------------------------------------------------------------|
| 5.   Press                                                                      |
| . The simulation case begins.                                                   |
| When you have completed the simulation case, you are returned to MentorLearn,   |
| and a report of your performance is displayed.                                  |
| 6.                                                                              |
| If at any time you wish to choose another case, module, or course or another    |
| MentorLearn Library, press that item in the browse sequence hierarchy above the |
| middle pane.                                                                    |

[OCR_TABLE]
‘The
dyn

[OCR]
Chapter 5 MentorLearn

Task 2 - Endoscopic Navigation >)

The goal of this task is to enhance the trainee’s maneuvering capability, providing
dynamic assessment during the task performance

In this Endoscopic Navigation task, the learner enhances his maneuvering
capabilities, navigating the endoscope and acquiring targets as they appear. Target
acquisition is achieved by fitting the scope's ‘viewfinder to the target, taking into
consideration distance, position and orientation.

The required maneuvers range from simple to complex and the ‘How Am | Doing’ bar
dynamically reflects the performance level

By performing this task, the learner can perfect his endoscope navigation skills ina
focused manner within a stress-less, abstract, environment.

Figure 5-6: Task description

5. Press o The simulation case begins.

When you have completed the simulation case, you are returned to MentorLearn,
and a report of your performance is displayed.

6. If at any time you wish to choose another case, module, or course or another
MentorLearn Library, press that item in the browse sequence hierarchy above the
middle pane.

= GI Mentor GI Endoscopy — Fundamental Skills > Task2- scopic Navigation

Viewing course/module completion status

In some modules and courses, benchmarks have been defined for evaluating
performance. A skill level for difference performance metrics, based on expert-derived
goals, is used as a point of reference against which the learner’s performance is
measured.

A summary of your current performance is displayed for modules and courses that
have benchmarks. Opening those modules/courses displays a detailed explanation
about your performance in specific cases/tasks. You can view at a glance how far you
are from reaching the required skill level and what is required to achieve the
benchmark standard.

surgicalscience Page 44


# Page 56

Chapter 5 
 MentorLearn
 
Page 45
 
 
Completion status for modules/courses with benchmarks 
If benchmarks have been defined for module or course, its "Completion Status" or 
current proficiency status appears after its name: 
 
Figure 5-7: Completion status for modules/courses with benchmarks 
Proficient  
• 
Yes indicates you achieved proficiency in the module/course by completing all 
cases at the required skill level. 
• 
No indicates you have not yet achieved proficiency since not all the cases have 
been completed at the required skill level.  
The Completion indicator (percentage) increases as you pass (achieve proficiency in) 
more and more of the cases. 
 
Proficiency scoreboard for cases/tasks with benchmarks 
A variety of indicators provide information about your proficiency status in the 
cases/tasks you have performed, allowing you to better understand what your goals 
are in order to achieve the benchmark standards.  
 
Figure 5-8: Completion status for cases/tasks with benchmarks 
Proficient: Yes indicates that you have achieved the required skill level for each of the 
case’s metrics with a defined skill level the required number of times; No indicates that 
you haven’t achieved the required skill level. 
Best Score: the best score you achieved for the case. 


[TABLE]
| Chapter 5                                                                                 |
|  MentorLearn                                                                              |
|:------------------------------------------------------------------------------------------|
| C                                                                                         |
| ompletion status for modules/courses with benchmarks                                      |
| If benchmarks have been defined for module or course, its "Completion Status" or          |
| current proficiency status appears after its name:                                        |
| F                                                                                         |
| i                                                                                         |
| gure 5-7: Completion status for modules/courses with benchmarks                           |
| Proficient                                                                                |
| Yes indicates you achieved proficiency in the module/course by completing all             |
| •                                                                                         |
| cases at the required skill level.                                                        |
| No indicates you have not yet achieved proficiency since not all the cases have           |
| •                                                                                         |
| been completed at the required skill level.                                               |
| The Completion indicator (percentage) increases as you pass (achieve proficiency in)      |
| more and more of the cases.                                                               |
| P                                                                                         |
| roficiency scoreboard for cases/tasks with benchmarks                                     |
| A variety of indicators provide information about your proficiency status in the          |
| cases/tasks you have performed, allowing you to better understand what your goals         |
| are in order to achieve the benchmark standards.                                          |
| F                                                                                         |
| i                                                                                         |
| gure 5-8: Completion status for cases/tasks with benchmarks                               |
| Proficient: Yes indicates that you have achieved the required skill level for each of the |
| case’s metrics with a defined skill level the required number of times; No indicates that |
| you haven’t achieved the required skill level.                                            |
| Best Score: the best score you achieved for the case.                                     |
| Page 45                                                                                   |

[OCR]
Chapter 5 MentorLearn

Completion status for modules/courses with benchmarks

If benchmarks have been defined for module or course, its "Completion Status" or
current proficiency status appears after its name:

8 Cyberscopy - EndoBasket
Cyberscopy - EndoBubble
Proficient: No, Completion: 50

Figure 5-7: Completion status for modules/courses with benchmarks

Proficient

. Yes indicates you achieved proficiency in the module/course by completing all
cases at the required skill level.

. No indicates you have not yet achieved proficiency since not all the cases have

been completed at the required skill level.

The Completion indicator (percentage) increases as you pass (achieve proficiency in)
more and more of the cases.

Proficiency scoreboard for cases/tasks with benchmarks

A variety of indicators provide information about your proficiency status in the
cases/tasks you have performed, allowing you to better understand what your goals
are in order to achieve the benchmark standards.

Hands-On

Figure 5-8: Completion status for cases/tasks with benchmarks

Proficient: Yes indicates that you have achieved the required skill level for each of the
case’s metrics with a defined skill level the required number of times; No indicates that
you haven't achieved the required skill level.

Best Score: the best score you achieved for the case.

surgicalscience Page 45


# Page 57

Chapter 5 
 MentorLearn
 
Page 46
 
Non-consecutive/consecutive: the number of times you achieved the required skill 
level in consecutive/non-consecutive attempts (depending on the defined 
requirement). 
Attempts: the number of tries you attempted to pass the case. 
Required Skill Level: Press on the underlined text to display a list of the required skill 
levels. You are required to achieve this skill level on each of the metrics to achieve 
proficiency for the case. 
 
Figure 5-9: Required Skill Level information 
 


[TABLE]
| Chapter 5                                                                                  | MentorLearn   |
|:-------------------------------------------------------------------------------------------|:--------------|
| Non-consecutive/consecutive: the number of times you achieved the required skill           |               |
| level in consecutive/non-consecutive attempts (depending on the defined                    |               |
| requirement).                                                                              |               |
| Attempts: the number of tries you attempted to pass the case.                              |               |
| Required Skill Level: Press on the underlined text to display a list of the required skill |               |
| levels. You are required to achieve this skill level on each of the metrics to achieve     |               |
| proficiency for the case.                                                                  |               |

[OCR]
Chapter 5 MentorLearn

Non-consecutive/consecutive: the number of times you achieved the required skill
level in consecutive/non-consecutive attempts (depending on the defined
requirement).

Attempts: the number of tries you attempted to pass the case.

Required Skill Level: Press on the underlined text to display a list of the required skill
levels. You are required to achieve this skill level on each of the metrics to achieve
proficiency for the case.

s, Best Score: 90%, Non consecutive: 1 of 1, Consecutive: 1 of 1, Attempts

Required Skill Level

Total time <= 78

Number of wall hits <= 2

Number of balloons popped out of 20 >= 19

Figure 5-9: Required Skill Level information

surgicalscience Page 46


# Page 58

Chapter 6 
 GI Mentor Display Modes
 
Page 47
 
Chapter 6 GI Mentor Display Modes 
The GI Mentor offers five basic display modes for different procedures: 
• 
Cyberscopy 
• 
General Endoscopy 
• 
Endoscopy and Fluoroscopy  
• 
Endoscopy and Ultrasound 
• 
Enhanced Clinical 
Cyberscopy display mode 
The Cyberscopy display mode is aimed at optimizing the acquisition of basic GI 
endoscopy skills, such as hand-eye coordination and scope maneuvering.  
Screen layout 
There are two different types of Cyberscopy cases, each offering two levels of 
difficulty: 
• 
EndoBubble  
• 
EndoBasket  


[TABLE]
| Chapter 6 GI Mentor Display Modes                                       |                           |
|:------------------------------------------------------------------------|:--------------------------|
| The GI Mentor offers five basic display modes for different procedures: |                           |
| •                                                                       | Cyberscopy                |
| •                                                                       | General Endoscopy         |
| •                                                                       | Endoscopy and Fluoroscopy |
| •                                                                       | Endoscopy and Ultrasound  |
| •                                                                       | Enhanced Clinical         |

[OCR]
Chapter 6 Gl Mentor Display Modes

| Chapter 6 GI Mentor Display Modes

The GI Mentor offers five basic display modes for different procedures:

Cyberscopy

General Endoscopy
Endoscopy and Fluoroscopy
Endoscopy and Ultrasound
Enhanced Clinical

Cyberscopy display mode

The Cyberscopy display mode is aimed at optimizing the acquisition of basic Gl
endoscopy skills, such as hand-eye coordination and scope maneuvering.

Screen layout

There are two different types of Cyberscopy cases, each offering two levels of
difficulty:

e EndoBubble
e EndoBasket

surgicalscience Page 47


# Page 59

Chapter 6 
 GI Mentor Display Modes
 
Page 48
 
 
Figure 6-1: Cyberscopy screen- EndoBubble 
 
Figure 6-2: Cyberscopy screen – EndoBasket 


[TABLE]
| Chapter 6                                | GI Mentor Display Modes   |
|:-----------------------------------------|:--------------------------|
| F                                        |                           |
| i                                        |                           |
| gure 6-1: Cyberscopy screen- EndoBubble  |                           |
| F                                        |                           |
| i                                        |                           |
| gure 6-2: Cyberscopy screen – EndoBasket |                           |
|                                          | Page 48                   |

[OCR]
Chapter 6 Gl Mentor Display Modes

surgical

Figure 6-2: Cyberscopy screen — EndoBasket

surgicalscience Page 48


# Page 60

Chapter 6 
 GI Mentor Display Modes
 
Page 49
 
General features 
The Primary View shows the scope view as you navigate inside the cyber environment. 
Note: The forceps and needle are simulated with the scope. The Master Tool is not used the in 
the Cyberscopy cases. 
 
Elapsed time – displays the time that has elapsed since starting the case. 
Finish button 
 – ends the current simulation and returns to the previous 
screen or the performance reports section if the performance was saved. 
General Endoscopy display mode 
The General Endoscopy display mode is used for all modules where the endoscopy 
modality is the only imagery modality used, such as colonoscopy, gastroscopy, gastric 
bleeding, and sigmoidoscopy.  
Note: The endoscope used is a forward viewing scope, as in reality. 


[TABLE]
| Chapter 6                                                                 | GI Mentor Display Modes                                                                        |
|:--------------------------------------------------------------------------|:-----------------------------------------------------------------------------------------------|
| General features                                                          |                                                                                                |
|                                                                           | The Primary View shows the scope view as you navigate inside the cyber environment.            |
|                                                                           | Note:  The forceps and needle are simulated with the scope. The Master Tool is not used the in |
| the Cyberscopy cases.                                                     |                                                                                                |
| E                                                                         |                                                                                                |
| lapsed time – displays the time that has elapsed since starting the case. |                                                                                                |
| Finish button                                                             | – ends the current simulation and returns to the previous                                      |
| screen or the performance reports section if the performance was saved.   |                                                                                                |
| General Endoscopy display mode                                            |                                                                                                |
|                                                                           | The General Endoscopy display mode is used for all modules where the endoscopy                 |
|                                                                           | modality is the only imagery modality used, such as colonoscopy, gastroscopy, gastric          |
| bleeding, and sigmoidoscopy.                                              |                                                                                                |
| Note:  The endoscope used is a forward viewing scope, as in reality.      |                                                                                                |
|                                                                           | Page 49                                                                                        |

[OCR]
Chapter 6 Gl Mentor Display Modes

General features

The Primary View shows the scope view as you navigate inside the cyber environment.

Note: The forceps and needle are simulated with the scope. The Master Tool is not used the in
the Cyberscopy cases.

Elapsed time — displays the time that has elapsed since starting the case.

Finish button C Fit ends the current simulation and returns to the previous

screen or the performance reports section if the performance was saved.

General Endoscopy display mode

The General Endoscopy display mode is used for all modules where the endoscopy
modality is the only imagery modality used, such as colonoscopy, gastroscopy, gastric
bleeding, and sigmoidoscopy.

Note: The endoscope used is a forward viewing scope, as in reality.

surgicalscience Page 49


# Page 61

Chapter 6 
 GI Mentor Display Modes
 
Page 50
 
Screen layout  
 
Figure 6-3: General Endoscopy screen  
The screen is divided into the following parts: 
① Primary View 
② 3D Map button 
③ Interactive Map 
④ Snapshots 
⑤ Virtual Instructor  
⑥ Pain and Air Indicators 
⑦ General Buttons 
The name of the module and the case file number you are running are displayed on the 
upper left side of the screen.  
General features and educational aids 
Several features and educational aids are available while you train on the GI Mentor.  


[TABLE]
| Chapter 6                                                                             | GI Mentor Display Modes                                                              |
|:--------------------------------------------------------------------------------------|:-------------------------------------------------------------------------------------|
| Screen layout                                                                         |                                                                                      |
| F                                                                                     |                                                                                      |
| i                                                                                     |                                                                                      |
| gure 6-3: General Endoscopy screen                                                    |                                                                                      |
| The screen is divided into the following parts:                                       |                                                                                      |
| ①  Primary View                                                                       |                                                                                      |
| ②  3D Map button                                                                      |                                                                                      |
| ③  Interactive Map                                                                    |                                                                                      |
| ④  Snapshots                                                                          |                                                                                      |
| ⑤  Virtual Instructor                                                                 |                                                                                      |
| ⑥  Pain and Air Indicators                                                            |                                                                                      |
| ⑦  General Buttons                                                                    |                                                                                      |
|                                                                                       | The name of the module and the case file number you are running are displayed on the |
| upper left side of the screen.                                                        |                                                                                      |
| General features and educational aids                                                 |                                                                                      |
| Several features and educational aids are available while you train on the GI Mentor. |                                                                                      |
|                                                                                       | Page 50                                                                              |

[OCR]
Chapter 6 Gl Mentor Display Modes

Screen layout

surgical

Figure 6-3: General Endoscopy screen

The screen is divided into the following parts:
@ Primary View
3D Map button
(3) Interactive Map
(4) Snapshots
(5) Virtual Instructor
Pain and Air Indicators
@

General Buttons

The name of the module and the case file number you are running are displayed on the
upper left side of the screen.

General features and educational aids

Several features and educational aids are available while you train on the GI Mentor.

surgicalscience Page 50


# Page 62

Chapter 6 
 GI Mentor Display Modes
 
Page 51
 
Primary view 
The primary view ① shows the real-time simulated endoscope’s view during the 
procedure you are performing. The elapsed time is displayed in the upper right side of 
the Primary View. 
 
Figure 6-4: Primary view – General Endoscopy display mode 
Full Screen view 
You can switch between Normal view and Full Screen view, while working with the 
simulator. The Full Screen view is restricted to the actual view displayed during real 
endoscopic operations. No educational aids are available on this view. 


[TABLE]
| Chapter 6                                                                              | GI Mentor Display Modes                                                                |
|:---------------------------------------------------------------------------------------|:---------------------------------------------------------------------------------------|
| Primary view                                                                           |                                                                                        |
| The primary view ① shows the real-time simulated endoscope’s view during the           |                                                                                        |
|                                                                                        | procedure you are performing. The elapsed time is displayed in the upper right side of |
| the Primary View.                                                                      |                                                                                        |
| F                                                                                      |                                                                                        |
| i                                                                                      |                                                                                        |
| gure 6-4: Primary view – General Endoscopy display mode                                |                                                                                        |
| Full Screen view                                                                       |                                                                                        |
| You can switch between Normal view and Full Screen view, while working with the        |                                                                                        |
| simulator. The Full Screen view is restricted to the actual view displayed during real |                                                                                        |
| endoscopic operations. No educational aids are available on this view.                 |                                                                                        |
|                                                                                        | Page 51                                                                                |

[OCR]
Chapter 6 Gl Mentor Display Modes

Primary view

The primary view (1) shows the real-time simulated endoscope’s view during the
procedure you are performing. The elapsed time is displayed in the upper right side of
the Primary View.

Figure 6-4: Primary view - General Endoscopy display mode

Full Screen view

You can switch between Normal view and Full Screen view, while working with the
simulator. The Full Screen view is restricted to the actual view displayed during real
endoscopic operations. No educational aids are available on this view.

surgicalscience Page 51


# Page 63

Chapter 6 
 GI Mentor Display Modes
 
Page 52
 
 
Figure 6-5: Full Screen view 
To switch to Full Screen View: 
• 
Double-click with the mouse anywhere on the primary view while in the normal 
mode. 
Or 
• 
Tap twice anywhere on the primary view of the Touch screen while in normal 
mode. 
Note: Tool selection in Full Screen view is the same as in Normal View (see Working with 
Endoscopic Tools on page 97). 
To return to Normal View: 
 
• 
Double-click anywhere on the Full Screen display. 
Or 
• 
Tap twice anywhere on the Full Screen display. 
 


[TABLE]
| F                                                                                         |                                                                              |
| i                                                                                         |                                                                              |
| gure 6-5: Full Screen view                                                                |                                                                              |
|:------------------------------------------------------------------------------------------|:-----------------------------------------------------------------------------|
| To switch to Full Screen View:                                                            |                                                                              |
| •                                                                                         | Double-click with the mouse anywhere on the primary view while in the normal |
|                                                                                           | mode.                                                                        |
|                                                                                           | Or                                                                           |
| •                                                                                         | Tap twice anywhere on the primary view of the Touch screen while in normal   |
|                                                                                           | mode.                                                                        |
| Note:  Tool selection in Full Screen view is the same as in Normal View (see Working with |                                                                              |
|                                                                                           | Endoscopic Tools on page 97).                                                |
| To return to Normal View:                                                                 |                                                                              |
| •                                                                                         | Double-click anywhere on the Full Screen display.                            |
|                                                                                           | Or                                                                           |
| •                                                                                         | Tap twice anywhere on the Full Screen display.                               |

[OCR]
Chapter 6 Gl Mentor Display Modes

00:01:08

Figure 6-5: Full Screen view

To switch to Full Screen View:

. Double-click with the mouse anywhere on the primary view while in the normal
mode.
Or
. Tap twice anywhere on the primary view of the Touch screen while in normal
mode.

Note: Tool selection in Full Screen view is the same as in Normal View (see Working with
Endoscopic Tools on page 97).

To return to Normal View:

. Double-click anywhere on the Full Screen display.
Or
. Tap twice anywhere on the Full Screen display.

surgicalscience Page 52


# Page 64

Chapter 6 
 GI Mentor Display Modes
 
Page 53
 
External 3D Map view ④ 
 
Figure 6-6: External 3D Map – General Endoscopy display mode 
The 3D map shows a dynamic external view of the GI tract and the current position of 
the endoscope. It facilitates a greater understanding of the anatomy and the way it is 
affected by the endoscope.  
1.  Press the 3D Map 
 button to display the 3D map. 
2.  Use the arrows to rotate the map up and down or left and right.  
3.  Press the Reset button to revert to the original display. 
4.  Press the Close button to return to the primary view. 
Note: The 3D Map feature is available in all the modules where training is performed in an 
anatomical environment. 


[TABLE]
| Chapter 6                                                                                   | GI Mentor Display Modes                                                                |
|:--------------------------------------------------------------------------------------------|:---------------------------------------------------------------------------------------|
| External 3D Map view ④                                                                      |                                                                                        |
| F                                                                                           |                                                                                        |
| i                                                                                           |                                                                                        |
| gure 6-6: External 3D Map – General Endoscopy display mode                                  |                                                                                        |
|                                                                                             | The 3D map shows a dynamic external view of the GI tract and the current position of   |
|                                                                                             | the endoscope. It facilitates a greater understanding of the anatomy and the way it is |
| affected by the endoscope.                                                                  |                                                                                        |
| 1.   Press the 3D Map                                                                       | button to display the 3D map.                                                          |
| 2.   Use the arrows to rotate the map up and down or left and right.                        |                                                                                        |
| 3.   Press the Reset button to revert to the original display.                              |                                                                                        |
| 4.   Press the Close button to return to the primary view.                                  |                                                                                        |
| Note:  The 3D Map feature is available in all the modules where training is performed in an |                                                                                        |
| anatomical environment.                                                                     |                                                                                        |
|                                                                                             | Page 53                                                                                |

[OCR]
Chapter 6 Gl Mentor Display Modes

External 3D Map view (@)

Discomfort

Figure 6-6: External 3D Map - General Endoscopy display mode

The 3D map shows a dynamic external view of the GI tract and the current position of
the endoscope. It facilitates a greater understanding of the anatomy and the way it is
affected by the endoscope.

3D Map ;
Press the 3D Map button to display the 3D map.

1

2. Use the arrows to rotate the map up and down or left and right.
3. Press the Reset button to revert to the original display.

4. Press the Close button to return to the primary view.

Note: The 3D Map feature is available in all the modules where training is performed in an
anatomical environment.

surgicalscience Page 53


# Page 65

Chapter 6 
 GI Mentor Display Modes
 
Page 54
 
Interactive Map ③ 
 
Figure 6-7: Interactive Map 
The dynamic Interactive Map enables you to view the current position of the 
endoscope in the patient’s anatomy while you are working. It is overlaid over the scope 
view, demonstrating scope advancement, looping, shortening, and long/short position. 
To display, press the Interactive Map 
 button. Press the 
button again to hide. 


[TABLE]
| Chapter 6                                                                   | GI Mentor Display Modes                                                                 |
|:----------------------------------------------------------------------------|:----------------------------------------------------------------------------------------|
| Interactive Map ③                                                           |                                                                                         |
| F                                                                           |                                                                                         |
| i                                                                           |                                                                                         |
| gure 6-7: Interactive Map                                                   |                                                                                         |
| The dynamic Interactive Map enables you to view the current position of the |                                                                                         |
|                                                                             | endoscope in the patient’s anatomy while you are working. It is overlaid over the scope |
|                                                                             | view, demonstrating scope advancement, looping, shortening, and long/short position.    |
| To display, press the Interactive Map                                       | button. Press the                                                                       |
| button again to hide.                                                       |                                                                                         |
|                                                                             | Page 54                                                                                 |

[OCR]
Chapter 6 Gl Mentor Display Modes

Interactive Map @)

3 3D Map

Figure 6-7: Interactive Map

The dynamic Interactive Map enables you to view the current position of the
endoscope in the patient's anatomy while you are working. It is overlaid over the scope
view, demonstrating scope advancement, looping, shortening, and long/short position.

To display, press the Interactive Map [ Interactive Ma p button. Press the

button again to hide.

surgicalscience Page 54


# Page 66

Chapter 6 
 GI Mentor Display Modes
 
Page 55
 
Pain and Air indicators ⑥ 
 
 
 
Two Pain Indicators operate on the 
simulator. Vocal indications of pain as 
well as a visual pain indicator show the 
virtual patient’s discomfort level caused 
by your performance.  
 
The Air indicator shows the level of air in 
the lumen close to the endoscope. The 
arrow on the dial as well as the lumen 
itself respond to insufflation/suction.  
Note: The arrow’s pointing to orange does not mean that the lumen cannot be further 
inflated. Additional air will disperse to more distant segments of the colon. 
Virtual Instructor ⑤ 
 
Figure 6-8: Virtual Instructor alert 
The Virtual Instructor displays a warning symbol 
 at the bottom of the 
screen each time performance is compromised, might lead to an unsafe situation, or 
might result in a clinical complication. The Virtual Instructor provides an alert explaining 
the problem and offering a solution. When the performance is corrected, the warning 
symbol dims and the instructions disappear from the screen. 
The Virtual Instructor also displays comments that are not alerts, aiding the training 
process. 
 
Figure 6-9: Virtual Instructor comment 


[TABLE]
| Pain and Air indicators ⑥                 |
|:------------------------------------------|
| Two Pain Indicators operate on the        |
| simulator. Vocal indications of pain as   |
| well as a visual pain indicator show the  |
| virtual patient’s discomfort level caused |
| by your performance.                      |

[OCR]
Chapter 6 Gl Mentor Display Modes

Pain and Air indicators 6)

Two Pain Indicators operate on the
simulator. Vocal indications of pain as
well as a visual pain indicator show the

petduielad Plead virtual patient’s discomfort level caused
by your performance.

The Air indicator shows the level of air in
the lumen close to the endoscope. The
—, arrow on the dial as well as the lumen
Air itself respond to insufflation/suction.

Note: The arrow’s pointing to orange does not mean that the lumen cannot be further
inflated. Additional air will disperse to more distant segments of the colon.

Virtual Instructor G)

No view of lumen : Lumen at 5 o'clock

Figure 6-8: Virtual Instructor alert

The Virtual Instructor displays a warning symbol — at the bottom of the
screen each time performance is compromised, might lead to an unsafe situation, or
might result in a clinical complication. The Virtual Instructor provides an alert explaining
the problem and offering a solution. When the performance is corrected, the warning
symbol dims and the instructions disappear from the screen.

The Virtual Instructor also displays comments that are not alerts, aiding the training
process.

Syringe is empty : Open handle to refill

Figure 6-9: Virtual Instructor comment

surgicalscience Page 55


# Page 67

Chapter 6 
 GI Mentor Display Modes
 
Page 56
 
Snapshot button ④ 
• 
 – captures and saves snapshots of the scope’s display 
while working. 
To capture a snapshot: 
• 
Press the Snapshot button on the left side of the screen. 
The captured images are automatically saved. While filling in your trainee report, you 
may delete an image or add information such as location, pathology, and comments 
regarding each of the snapshots. All the images and comments will be available at the 
Performance Report. 
Note:  For some events such as a polypectomy or biopsy, a snapshot is automatically captured 
by the system and can be viewed, together with additional information about the event, 
from the Performance page. 
General buttons 
• 
⑦ Patient File button 
 – Press this button to view the case’s patient file. 
The patient file includes the patient histories, biological test results, and imaging 
results. You can open the file without ending the current session. Press Close to 
resume the procedure. 
• 
⑦ Sound button 
 – Press this button repeatedly until the desired sound 
level is attained. Once the maximum sound level is reached, the next click turns 
the sound off (mute).   
• 
⑦ Help 
 – opens the online help of the system (check its availability based 
on the software version). 
• 
⑦ Finish button 
 – Press this button to end the current simulation. A 
message is displayed asking you if you want to save your performance for the 
session.  
• 
Press Yes – to save your performance. It will open the Trainee Report page, 
enabling you to fill in a report for the case. The report is saved in the 
Trainee Report and may be viewed in the Performance tab. 


[TABLE]
| Chapter 6                                                                                    |
|  GI Mentor Display Modes                                                                     |
|:---------------------------------------------------------------------------------------------|
| Snapshot button ④                                                                            |
| – captures and saves snapshots of the scope’s display                                        |
| •                                                                                            |
| while working.                                                                               |
| To capture a snapshot:                                                                       |
| Press the Snapshot button on the left side of the screen.                                    |
| •                                                                                            |
| The captured images are automatically saved. While filling in your trainee report, you       |
| may delete an image or add information such as location, pathology, and comments             |
| regarding each of the snapshots. All the images and comments will be available at the        |
| Performance Report.                                                                          |
| Note:  For some events such as a polypectomy or biopsy, a snapshot is automatically captured |
| by the system and can be viewed, together with additional information about the event,       |
| from the Performance page.                                                                   |
| General buttons                                                                              |
| ⑦ Patient File button                                                                        |
|  – Press this button to view the case’s patient file.                                        |
| •                                                                                            |
| The patient file includes the patient histories, biological test results, and imaging        |
| results. You can open the file without ending the current session. Press Close to            |
| resume the procedure.                                                                        |
| ⑦ Sound button                                                                               |
|  – Press this button repeatedly until the desired sound                                      |
| •                                                                                            |
| level is attained. Once the maximum sound level is reached, the next click turns             |
| the sound off (mute).                                                                        |
| ⑦ Help                                                                                       |
|  – opens the online help of the system (check its availability based                         |
| •                                                                                            |
| on the software version).                                                                    |
| ⑦ Finish button                                                                              |
|  – Press this button to end the current simulation. A                                        |
| •                                                                                            |
| message is displayed asking you if you want to save your performance for the                 |
| session.                                                                                     |
| Press Yes – to save your performance. It will open the Trainee Report page,                  |
| •                                                                                            |
| enabling you to fill in a report for the case. The report is saved in the                    |
| Trainee Report and may be viewed in the Performance tab.                                     |
| Page 56                                                                                      |

[OCR_TABLE]
“Mbyte

[OCR_TABLE]
VITGVollV!

[OCR]
Chapter 6 Gl Mentor Display Modes

Snapshot button @)

e i S na Ps h ot — captures and saves snapshots of the scope’s display

while working.

To capture a snapshot:
. Press the Snapshot button on the left side of the screen.

The captured images are automatically saved. While filling in your trainee report, you
may delete an image or add information such as location, pathology, and comments
regarding each of the snapshots. All the images and comments will be available at the
Performance Report.

Note: For some events such as a polypectomy or biopsy, a snapshot is automatically captured
by the system and can be viewed, together with additional information about the event,
from the Performance page.

General buttons

. @ Patient File button i Press this button to view the case’s patient file.
The patient file includes the patient histories, biological test results, and imaging
results. You can open the file without ending the current session. Press Close to
resume the procedure.

wy)

e @ Sound button - Press this button repeatedly until the desired sound
level is attained. Once the maximum sound level is reached, the next click turns
the sound off (mute).

. @ Help — opens the online help of the system (check its availability based
on the software version).

. @ Finish button er Press this button to end the current simulation. A
message is displayed asking you if you want to save your performance for the
session.

e Press Yes - to save your performance. It will open the Trainee Report page,
enabling you to fill in a report for the case. The report is saved in the
Trainee Report and may be viewed in the Performance tab.

surgicalscience Page 56


# Page 68

Chapter 6 
 GI Mentor Display Modes
 
Page 57
 
• 
Press No – to return to the previous selection screen. Your performance will 
not be saved. 
Endoscopy and Fluoroscopy display mode  
In the ERCP module, video endoscopy is used simultaneously with real time 
fluoroscopy. 
Note: The duodenoscope used is a side viewing scope, as in reality. 
Screen layout 
 
Figure 6-10: Endoscopy and Fluoroscopy screen 
The screen is divided into the following parts: 
① Endoscopic Display  
② Fluoroscopic Display 
③ Snapshots  
④ 3D Map and Interactive Map Buttons 
⑤ Apply X-Ray Button 
⑥ Contrast Injection 


[TABLE]
| •                                                                         | Press No – to return to the previous selection screen. Your performance will   |
|:--------------------------------------------------------------------------|:-------------------------------------------------------------------------------|
|                                                                           | not be saved.                                                                  |
| Endoscopy and Fluoroscopy display mode                                    |                                                                                |
| In the ERCP module, video endoscopy is used simultaneously with real time |                                                                                |
| fluoroscopy.                                                              |                                                                                |
| Note:  The duodenoscope used is a side viewing scope, as in reality.      |                                                                                |
| Screen layout                                                             |                                                                                |

[OCR]
Chapter 6 Gl Mentor Display Modes

e Press No - to return to the previous selection screen. Your performance will
not be saved.

Endoscopy and Fluoroscopy display mode

In the ERCP module, video endoscopy is used simultaneously with real time
fluoroscopy.

Note: The duodenoscope used is a side viewing scope, as in reality.

Screen layout

surgical

Figure 6-10: Endoscopy and Fluoroscopy screen

The screen is divided into the following parts:
(@) Endoscopic Display
@ Fluoroscopic Display
Snapshots
(4) 3D Map and Interactive Map Buttons
(5) Apply X-Ray Button
(6) Contrast Injection

surgicalscience Page 57


# Page 69

Chapter 6 
 GI Mentor Display Modes
 
Page 58
 
⑦ Fluoroscopic View Controls 
⑧ Electrical Mode Selection Buttons  
⑨ Electricity Power Setting Controls  
⑩ General Buttons 
⑪ Virtual Instructor  
 
Above the main displays is an icon indication of the module and the case file number 
you are running as well as the elapsed time indicator.  
General features and educational aids 
Primary views 
The Endoscopy and Fluoroscopy mode features a split screen display: the simulated 
endoscopic view ① on the left and a simulated fluoroscopic view ➁ on the right.  
Note: The simulation starts when the duodenoscope is already inside the esophagus. 
Full Screen View – is restricted to the actual view displayed during real endoscopic 
operations. 
General features 
Many of the features and educational aids available in the Endoscopy and Fluoroscopy 
mode are similar to the General Endoscopy mode. For a detailed explanation, see 
pages 53-56. 
Working with fluoroscopy 
Simulating X-Ray application ⑤  
You can simulate X-ray application. The accumulated X-ray exposure time is displayed 
in the lower left side of the fluoroscopic view.  
To apply X-Ray: 
• 
Press the X-ray 
 button on the left side of the screen. 
Or 


[TABLE]
| Chapter 6                                                                            | GI Mentor Display Modes                                                              |
|:-------------------------------------------------------------------------------------|:-------------------------------------------------------------------------------------|
| ⑦  Fluoroscopic View Controls                                                        |                                                                                      |
| ⑧  Electrical Mode Selection Buttons                                                 |                                                                                      |
| ⑨  Electricity Power Setting Controls                                                |                                                                                      |
| General Buttons                                                                      |                                                                                      |
| Virtual Instructor                                                                   |                                                                                      |
| ⑩                                                                                    |                                                                                      |
| A                                                                                    |                                                                                      |
| ⑪                                                                                    |                                                                                      |
|                                                                                      | bove the main displays is an icon indication of the module and the case file number  |
| you are running as well as the elapsed time indicator.                               |                                                                                      |
| General features and educational aids                                                |                                                                                      |
| Primary views                                                                        |                                                                                      |
| The Endoscopy and Fluoroscopy mode features a split screen display: the simulated    |                                                                                      |
| endoscopic view ① on the left and a simulated fluoroscopic view ② on the right.      |                                                                                      |
| Note: The simulation starts when the duodenoscope is already inside the esophagus.   |                                                                                      |
| Full Screen View – is restricted to the actual view displayed during real endoscopic |                                                                                      |
| operations.                                                                          |                                                                                      |
| General features                                                                     |                                                                                      |
|                                                                                      | Many of the features and educational aids available in the Endoscopy and Fluoroscopy |
| mode are similar to the General Endoscopy mode. For a detailed explanation, see      |                                                                                      |
| pages 53-56.                                                                         |                                                                                      |
| Working with fluoroscopy                                                             |                                                                                      |
| Simulating X-Ray application ⑤                                                       |                                                                                      |
|                                                                                      | You can simulate X-ray application. The accumulated X-ray exposure time is displayed |
| in the lower left side of the fluoroscopic view.                                     |                                                                                      |
| To apply X-Ray:                                                                      |                                                                                      |
| Press the X-ray                                                                      | button on the left side of the screen.                                               |
| •                                                                                    |                                                                                      |
| Or                                                                                   |                                                                                      |
|                                                                                      | Page 58                                                                              |

[OCR]
Chapter 6 Gl Mentor Display Modes

() Fluoroscopic View Controls
(8) Electrical Mode Selection Buttons

@) Electricity Power Setting Controls
General Buttons
a) Virtual Instructor

Above the main displays is an icon indication of the module and the case file number
you are running as well as the elapsed time indicator.

General features and educational aids

Primary views

The Endoscopy and Fluoroscopy mode features a split screen display: the simulated
endoscopic view @ on the left and a simulated fluoroscopic view @ on the right.

Note: The simulation starts when the duodenoscope is already inside the esophagus.

Full Screen View - is restricted to the actual view displayed during real endoscopic
operations.

General features
Many of the features and educational aids available in the Endoscopy and Fluoroscopy

mode are similar to the General Endoscopy mode. For a detailed explanation, see
pages 53-56.

Working with fluoroscopy

Simulating X-Ray application 6)

You can simulate X-ray application. The accumulated X-ray exposure time is displayed
in the lower left side of the fluoroscopic view.

To apply X-Ray:

X-ray .
. Press the X-ray button on the left side of the screen.

Or

surgicalscience Page 58


# Page 70

Chapter 6 
 GI Mentor Display Modes
 
Page 59
 
• 
Press the X-ray (right) foot switch. 
Injecting contrast ⑥ 
To inject contrast agent: 
1.  Press the Inject 
 button on the left side of the screen. 
The tool that is currently in use injects the contrast agent into the duct.  
2.  Press the button again to inject more contrast agent. 
 
Figure 6-11: Fluoroscopic image 
Fluoroscopic view controls ⑦ 
To activate the fluoroscopic view controls: 
1.  Press the Controls 
 button on the left side of the screen.  
The Fluoroscopic View Controls are displayed over the fluoroscopic display. 


[TABLE]
| Chapter 6                                                                   |
|  GI Mentor Display Modes                                                    |
|:----------------------------------------------------------------------------|
| Press the X-ray (right) foot switch.                                        |
| •                                                                           |
| Injecting contrast ⑥                                                        |
| To inject contrast agent:                                                   |
| 1.   Press the Inject                                                       |
|  button on the left side of the screen.                                     |
| The tool that is currently in use injects the contrast agent into the duct. |
| 2.   Press the button again to inject more contrast agent.                  |
| F                                                                           |
| i                                                                           |
| gure 6-11: Fluoroscopic image                                               |
| Fluoroscopic view controls ⑦                                                |
| To activate the fluoroscopic view controls:                                 |
| 1.   Press the Controls                                                     |
|  button on the left side of the screen.                                     |
| The Fluoroscopic View Controls are displayed over the fluoroscopic display. |
| Page 59                                                                     |

[OCR]
Chapter 6 Gl Mentor Display Modes

e Press the X-ray (right) foot switch.
Injecting contrast 6)

To inject contrast agent:

| |
1. Press the Inject button on the left side of the screen.

The tool that is currently in use injects the contrast agent into the duct.
2. Press the button again to inject more contrast agent.

surgical

Figure 6-17: Fluoroscopic image

Fluoroscopic view controls (7)

To activate the fluoroscopic view controls:

a
|
1. Press the Controls Mii button on the left side of the screen.

The Fluoroscopic View Controls are displayed over the fluoroscopic display.

surgicalscience Page 59


# Page 71

Chapter 6 
 GI Mentor Display Modes
 
Page 60
 
 
 Figure 6-12: Fluoroscopic View Controls in the fluoroscopic display 
To pan: 
1.  Press the desired directional arrow 
 on the four sides of the fluoroscopic 
display to move the image horizontally or vertically.  
To zoom in or out: 
1.  Press the Zoom In 
 button to enlarge the display. 
2.  Press the Zoom Out 
 button to reduce the display. 
To flip the image horizontally: 
1.  Press the Flip 
 button to flip the display horizontally. 
To deactivate the Fluoroscopic View Controls: 
1.  Press again on the Controls 
 button to deactivate the controls. 
or 


[TABLE]
| F                                                                   |
| i                                                                   |
| gure 6-12: Fluoroscopic View Controls in the fluoroscopic display   |
|:--------------------------------------------------------------------|
| To pan:                                                             |
| 1.   Press the desired directional arrow                            |
|  on the four sides of the fluoroscopic                              |
| display to move the image horizontally or vertically.               |
| To zoom in or out:                                                  |
| 1.   Press the Zoom In                                              |
|  button to enlarge the display.                                     |
| 2.   Press the Zoom Out                                             |
|  button to reduce the display.                                      |
| To flip the image horizontally:                                     |
| 1.   Press the Flip                                                 |
|  button to flip the display horizontally.                           |
| To deactivate the Fluoroscopic View Controls:                       |
| 1.   Press again on the Controls                                    |
|  button to deactivate the controls.                                 |

[OCR]
Chapter 6 Gl Mentor Display Modes

surgicalscie0e

> Map

© interactive Map

00:00:02

Figure 6-12: Fluoroscopic View Controls in the fluoroscopic display

To pan:

1. Press the desired directional arrow E] on the four sides of the fluoroscopic
display to move the image horizontally or vertically.

To zoom in or out:

1. Press the Zoom In E] button to enlarge the display.

2. Press the Zoom Out | button to reduce the display.
To flip the image horizontally:

1. Press the Flip -] button to flip the display horizontally.

To deactivate the Fluoroscopic View Controls:

A
| |
1. Press again on the Controls Hii button to deactivate the controls.

or

surgical Page 60


# Page 72

Chapter 6 
 GI Mentor Display Modes
 
Page 61
 
Wait a few seconds and the arrows will become deactivated. 
Electrosurgical controls 
The electrical mode selection buttons ⑧ and electricity power setting controls ⑨ are 
used with tools requiring electrosurgical current. For a detailed explanation, see 
Working with tools requiring electrosurgical current on page 98. 
Endoscopy and Ultrasound display mode 
The Endoscopy and Ultrasound display mode applies to the EUS Educational and 
Tasks Modules.  
You can switch between the different displays using either a single display or a split 
screen for two simultaneous views. 
Note: The scope used is a side-viewing scope, as in reality. 
The didactic way to perform EUS simulation training is to follow the case info 
instructions, correctly acquiring and identifying each anatomical landmark. 


[TABLE]
| Chapter 6                                                                              | GI Mentor Display Modes                                                              |
|:---------------------------------------------------------------------------------------|:-------------------------------------------------------------------------------------|
| Wait a few seconds and the arrows will become deactivated.                             |                                                                                      |
| Electrosurgical controls                                                               |                                                                                      |
|                                                                                        | The electrical mode selection buttons ⑧ and electricity power setting controls ⑨ are |
| used with tools requiring electrosurgical current. For a detailed explanation, see     |                                                                                      |
| Working with tools requiring electrosurgical current on page 98.                       |                                                                                      |
| Endoscopy and Ultrasound display mode                                                  |                                                                                      |
| The Endoscopy and Ultrasound display mode applies to the EUS Educational and           |                                                                                      |
| Tasks Modules.                                                                         |                                                                                      |
| You can switch between the different displays using either a single display or a split |                                                                                      |
| screen for two simultaneous views.                                                     |                                                                                      |
| Note:  The scope used is a side-viewing scope, as in reality.                          |                                                                                      |
| The didactic way to perform EUS simulation training is to follow the case info         |                                                                                      |
| instructions, correctly acquiring and identifying each anatomical landmark.            |                                                                                      |

[OCR]
Chapter 6 Gl Mentor Display Modes

Wait a few seconds and the arrows will become deactivated.
Electrosurgical controls
The electrical mode selection buttons @) and electricity power setting controls @) are

used with tools requiring electrosurgical current. For a detailed explanation, see
Working with tools requiring electrosurgical current on page 98.

Endoscopy and Ultrasound display mode
The Endoscopy and Ultrasound display mode applies to the EUS Educational and
Tasks Modules.

You can switch between the different displays using either a single display or a split
screen for two simultaneous views.

Note: The scope used is a side-viewing scope, as in reality.

The didactic way to perform EUS simulation training is to follow the case info
instructions, correctly acquiring and identifying each anatomical landmark.

surgicalscience Page 61


# Page 73

Chapter 6 
 GI Mentor Display Modes
 
Page 62
 
Screen layout 
 
Figure 6-13: Endoscopy and Ultrasound screen 
The screen is divided into the following parts: 
① Left display  
② Right display 
③ Case Info 
④ Elapsed time 
⑤ Perforation meter 
⑥ Split and Focus buttons  
⑦ Content Selection buttons  
⑧ Ultrasound Display Function buttons   
⑨ Actions Panel for the selected function 
⑩ General Buttons  
Note: The EUS Tasks environment differ from the EUS Educational environment in the 
availability of certain features and educational aids.  


[TABLE]
| Chapter 6                                                                           | GI Mentor Display Modes   |
|:------------------------------------------------------------------------------------|:--------------------------|
| Screen layout                                                                       |                           |
| F                                                                                   |                           |
| i                                                                                   |                           |
| gure 6-13: Endoscopy and Ultrasound screen                                          |                           |
| The screen is divided into the following parts:                                     |                           |
| ①  Left display                                                                     |                           |
| ②  Right display                                                                    |                           |
| ③  Case Info                                                                        |                           |
| ④  Elapsed time                                                                     |                           |
| ⑤  Perforation meter                                                                |                           |
| ⑥  Split and Focus buttons                                                          |                           |
| ⑦  Content Selection buttons                                                        |                           |
| ⑧  Ultrasound Display Function buttons                                              |                           |
| ⑨  Actions Panel for the selected function                                          |                           |
| General Buttons                                                                     |                           |
| Note:  The EUS Tasks environment differ from the EUS Educational environment in the |                           |
| ⑩                                                                                   |                           |
| availability of certain features and educational aids.                              |                           |
|                                                                                     | Page 62                   |

[OCR]
Chapter 6 Gl Mentor Display Modes

Screen layout

surgicalscience

bid

Freeze

Inferior Vena Cava,
i

Figure 6-13: Endoscopy and Ultrasound screen

The screen is divided into the following parts:

Left display
Right display
(3) Case Info
(4) Elapsed time
(5) Perforation meter
(6) Split and Focus buttons
(7) Content Selection buttons
(8) Ultrasound Display Function buttons
(9) Actions Panel for the selected function

General Buttons

Note: The EUS Tasks environment differ from the EUS Educational environment in the
availability of certain features and educational aids.

surgical Page 62


# Page 74

Chapter 6 
 GI Mentor Display Modes
 
Page 63
 
General features and educational aids 
Case Info ③  
The case info is the basis for the EUS hands-on ultrasound landmark recognition. The 
Case Info includes: 
• 
Six different cases with a list of landmarks for each case.  
• 
A verbal explanation accompanied by 3D Map capture showing the position and 
orientation of the scope and ultrasound beam  
for each landmark acquisition. 
• 
A preview of the desired ultrasound image for this landmark, with all its relevant 
anatomical structures labeled.  
To display the case information: 
1.  Press Case Info 
 button in the top left corner of the screen. 
2.  Select a case and a landmark from its list to view the scope maneuvering 
instructions and desired ultrasound capture. 
 
 
Figure 6-14: Landmark instructions and anticipated capture 
Note: The Scope Orientation Instructions for Landmarks are available and can be followed in 
both the educational environment and the task environment. 


[TABLE]
| Case Info ③                                                                          |                                                                                    |
|:-------------------------------------------------------------------------------------|:-----------------------------------------------------------------------------------|
| The case info is the basis for the EUS hands-on ultrasound landmark recognition. The |                                                                                    |
| Case Info includes:                                                                  |                                                                                    |
| •                                                                                    | Six different cases with a list of landmarks for each case.                        |
| •                                                                                    | A verbal explanation accompanied by 3D Map capture showing the position and        |
|                                                                                      | orientation of the scope and ultrasound beam                                       |
|                                                                                      | for each landmark acquisition.                                                     |
| •                                                                                    | A preview of the desired ultrasound image for this landmark, with all its relevant |
|                                                                                      | anatomical structures labeled.                                                     |

[OCR]
Chapter 6

Gl Mentor Display Modes

General features and educational aids

Case Info @)

The case info is the basis for the EUS hands-on ultrasound landmark recognition. The

Case Info includes:

e
. A verbal explanation accompanied by 3D Map capture
orientation of the scope and ultrasound beam

for each landmark acquisition.

anatomical structures labeled.

To display the case information:

Six different cases with a list of landmarks for each case.

showing the position and

A preview of the desired ultrasound image for this landmark, with all its relevant

1. Press Case Info A button in the top left corner of the screen.
2. Select a case and a landmark from its list to view the scope maneuvering

instructions and desired ultrasound capture.

Case | - Linear - Duodenum Area

Select Landmark Uncinate Process

Find Landmark - Label Anatomy

> Aorta & Vena Cava
> Enaneee yaaa
> Papilla

Longitudinal CBD & PY

| Bulb 1

Duodenal Bulb 2

Bulb Confluence 7
1. Uncinate process

2. Superior mesenteric vein
3. Superior mesenteric artery

How To Reach This Landmark

Help (2

Figure 6-14: Landmark instructions and anticipated capture

Note: The Scope Orientation Instructions for Landmarks are available and can be followed in

both the educational environment and the task environment.

surgicalscience

Page 63


# Page 75

Chapter 6 
 GI Mentor Display Modes
 
Page 64
 
Split, set focus, and select content of the displays  
You can split the display pane into two panes and view simultaneously two displays of 
your choice or work with a single display pane. The Ultrasound, Endoscopic and 3D 
Map displays can each be viewed in any of the display panes.  
To split the display pane ⑥:  
1.  Press the Split 
 button. 
2.  Press the display selection button of your choice under each pane. 
The selected display appears in the designated pane. 
To set the display focus ⑥:  
1.  Press anywhere inside the display pane not currently selected.  
Or 
Press the right or left 
 set focus button. 
Note: The display focus is indicated by a thin yellow line around the display pane. The Function 
Buttons and Actions Panel are updated accordingly.  
To select the display’s content ⑦: 
Press a content button under the display pane to view it in the above display. 
• 
 – Endoscopic (Video) 
• 
 – EUS (Ultrasound) 
• 
 – 3D Map 
General buttons ⑩ 
The buttons are the same as for the General Endoscopy mode. For an explanation, see 
page 56. 
Elapsed Time and Perforation meter 
④ Elapsed Time – display the amount of time that has elapsed since starting the 
procedure. 
⑤ Perforation meter – displays how much the scope is pushing against the tissue. 


[TABLE]
| Chapter 6                    |                                                                                       | GI Mentor Display Modes   |
|:-----------------------------|:--------------------------------------------------------------------------------------|:--------------------------|
|                              | Split, set focus, and select content of the displays                                  |                           |
|                              | You can split the display pane into two panes and view simultaneously two displays of |                           |
|                              | your choice or work with a single display pane. The Ultrasound, Endoscopic and 3D     |                           |
|                              | Map displays can each be viewed in any of the display panes.                          |                           |
| To split the display pane ⑥: |                                                                                       |                           |
| 1.   Press the Split         | button.                                                                               |                           |
|                              | 2.   Press the display selection button of your choice under each pane.               |                           |
|                              | The selected display appears in the designated pane.                                  |                           |
| To set the display focus ⑥:  |                                                                                       |                           |
|                              | 1.   Press anywhere inside the display pane not currently selected.                   |                           |

[OCR]
Chapter 6 Gl Mentor Display Modes

Split, set focus, and select content of the displays

You can split the display pane into two panes and view simultaneously two displays of
your choice or work with a single display pane. The Ultrasound, Endoscopic and 3D
Map displays can each be viewed in any of the display panes.

To split the display pane ©):
1. Press the Split a button.
2. Press the display selection button of your choice under each pane.

The selected display appears in the designated pane.

To set the display focus ©):
1. Press anywhere inside the display pane not currently selected.
Or

Press the right or left a set focus button.

Note: The display focus is indicated by a thin yellow line around the display pane. The Function
Buttons and Actions Panel are updated accordingly.

To select the display’s content @:
Press a content button under the display pane to view it in the above display.

e — Endoscopic (Video)

e — EUS (Ultrasound)

e [e). 3D Map
General buttons

The buttons are the same as for the General Endoscopy mode. For an explanation, see
page 56.

Elapsed Time and Perforation meter

@ Elapsed Time - display the amount of time that has elapsed since starting the
procedure.

® Perforation meter — displays how much the scope is pushing against the tissue.

surgicalscience Page 64


# Page 76

Chapter 6 
 GI Mentor Display Modes
 
Page 65
 
Ultrasound display functions  
The Ultrasound Function buttons ⑧ are located above the right display pane. Pressing 
a button displays its action panel on the right side of the screen ⑨.  
Action panels 
 Zoom panel 
Note: This panel is available for both the educational and task environments. 
 
Press the Zoom 
 function button above the right pane. 
The Zoom panel is displayed. 
 
Figure 6-15: Zoom panel 
Zooming  
To enlarge the ultrasound display: 
1.  Press the Zoom In 
 button. 


[TABLE]
| Chapter 6                                                                      | GI Mentor Display Modes                                                              |
|:-------------------------------------------------------------------------------|:-------------------------------------------------------------------------------------|
| Ultrasound display functions                                                   |                                                                                      |
|                                                                                | The Ultrasound Function buttons ⑧ are located above the right display pane. Pressing |
| a button displays its action panel on the right side of the screen ⑨.          |                                                                                      |
| Action panels                                                                  |                                                                                      |
| Zoom panel                                                                     |                                                                                      |
| Note:  This panel is available for both the educational and task environments. |                                                                                      |
| Press the Zoom                                                                 |                                                                                      |
|  function button above the right pane.                                         |                                                                                      |
| The Zoom panel is displayed.                                                   |                                                                                      |
| F                                                                              |                                                                                      |
| i                                                                              |                                                                                      |
| gure 6-15: Zoom panel                                                          |                                                                                      |
| Zooming                                                                        |                                                                                      |
| To enlarge the ultrasound display:                                             |                                                                                      |
| 1.   Press the Zoom In                                                         |                                                                                      |
|  button.                                                                       |                                                                                      |
|                                                                                | Page 65                                                                              |

[OCR]
Chapter 6 Gl Mentor Display Modes

Ultrasound display functions

The Ultrasound Function buttons (8) are located above the right display pane. Pressing
a button displays its action panel on the right side of the screen ©.

Action panels

Q) Zoom panel

Note: This panel is available for both the educational and task environments.

Press the Zoom Qa function button above the right pane.
The Zoom panel is displayed.

Figure 6-15: Zoom panel

Zooming

To enlarge the ultrasound display:

1. Press the Zoom In @ button.

surgicalscience Page 65


# Page 77

Chapter 6 
 GI Mentor Display Modes
 
Page 66
 
To reduce the ultrasound display:  
1.  Press the Zoom Out 
 button. 
To set the center of the view after zooming in: 
1. Press the Set Center 
 button and then press anywhere on the ultrasound 
image. 
The selected point becomes the center of the ultrasound image. 
To zoom on a selected region: 
1.  Press the Region 
 button.  
A yellow square is displayed on the screen and the Region sub-panel is displayed. 
 
Figure 6-16: Region sub-panel 
2.  Press OK. 
The selected area is enlarged. 
To enlarge a selected region: 
1.  Press Enlarge. 
The size of the yellow square is enlarged. 


[TABLE]
| Chapter 6                                       |                                                                | GI Mentor Display Modes   |
|:------------------------------------------------|:---------------------------------------------------------------|:--------------------------|
| To reduce the ultrasound display:               |                                                                |                           |
| 1.   Press the Zoom Out                         | button.                                                        |                           |
| To set the center of the view after zooming in: |                                                                |                           |
| 1.                                              | button and then press anywhere on the ultrasound               |                           |
| Press the Set Center                            |                                                                |                           |
| image.                                          |                                                                |                           |
|                                                 | The selected point becomes the center of the ultrasound image. |                           |
| To zoom on a selected region:                   |                                                                |                           |
| 1.   Press the Region                           | button.                                                        |                           |

[OCR]
Chapter 6 Gl Mentor Display Modes

To reduce the ultrasound display:

1. Press the Zoom Out || button.

To set the center of the view after zooming in:

1. Press the Set center a button and then press anywhere on the ultrasound
image.
The selected point becomes the center of the ultrasound image.

To zoom on a selected region:

1. Press the Region C button.

A yellow square is displayed on the screen and the Region sub-panel is displayed.

Enlarge

Figure 6-16: Region sub-panel
2. Press OK.
The selected area is enlarged.

To enlarge a selected region:
1. Press Enlarge.

The size of the yellow square is enlarged.

surgicalscience Page 66


# Page 78

Chapter 6 
 GI Mentor Display Modes
 
Page 67
 
2.  Press anywhere on the screen.  
The yellow square moves to the selected area. 
3.  Press OK. 
The selected area is enlarged. 
To reduce a selected region:  
1.  Press the Region 
 button.  
A yellow square is displayed on the screen and the Region sub-panel is displayed. 
2.  Press Reduce. 
The size of the yellow square is reduced. 
3.  Press anywhere on the screen.  
The yellow square moves to the selected area. 
4.  Press OK. 
The selected area is enlarged. 
To reset the zoom level of the ultrasound display: 
1.  Press the Reset 
 button. The display returns to its original zoom settings. 
 Freeze panel   
Use the Freeze panel to freeze the ultrasound image, which is the first step in 
capturing and saving a desired landmark. 
Press the Freeze 
 function button above the display pane. 
The Freeze panel is displayed. 


[TABLE]
| Chapter 6                                          | GI Mentor Display Modes                                                           |
|:---------------------------------------------------|:----------------------------------------------------------------------------------|
| 2.   Press anywhere on the screen.                 |                                                                                   |
| The yellow square moves to the selected area.      |                                                                                   |
| 3.   Press OK.                                     |                                                                                   |
| The selected area is enlarged.                     |                                                                                   |
| To reduce a selected region:                       |                                                                                   |
| 1.   Press the Region                              | button.                                                                           |
|                                                    | A yellow square is displayed on the screen and the Region sub-panel is displayed. |
| 2.   Press Reduce.                                 |                                                                                   |
| The size of the yellow square is reduced.          |                                                                                   |
| 3.   Press anywhere on the screen.                 |                                                                                   |
| The yellow square moves to the selected area.      |                                                                                   |
| 4.   Press OK.                                     |                                                                                   |
| The selected area is enlarged.                     |                                                                                   |
| To reset the zoom level of the ultrasound display: |                                                                                   |
| 1.   Press the Reset                               | button. The display returns to its original zoom settings.                        |

[OCR]
Chapter 6 Gl Mentor Display Modes

2. Press anywhere on the screen.

The yellow square moves to the selected area.
3. Press OK.

The selected area is enlarged.

To reduce a selected region:

1. Press the Region Cj button.

A yellow square is displayed on the screen and the Region sub-panel is displayed.
2. Press Reduce.

The size of the yellow square is reduced.
3. Press anywhere on the screen.

The yellow square moves to the selected area.
4. Press OK.

The selected area is enlarged.

To reset the zoom level of the ultrasound display:

co

1. Press the Reset LA button. The display returns to its original zoom settings.

bia Freeze panel

Use the Freeze panel to freeze the ultrasound image, which is the first step in
capturing and saving a desired landmark.

Press the Freeze bia function button above the display pane.
The Freeze panel is displayed.

surgicalscience Page 67


# Page 79

Chapter 6 
 GI Mentor Display Modes
 
Page 68
 
 
Figure 6-17: Freeze panel 
Freezing and unfreezing 
To freeze the ultrasound image: 
1.  Press the On/Off 
 button to freeze the ultrasound image. 
The ultrasound image is frozen and a green dot appears above the Freeze function 
button and in the On/Off button, indicating the image is frozen. 
To unfreeze the ultrasound image: 
1.  Press the On/Off 
 button again. 
The ultrasound image returns to the live duodenoscope image. 
Note: When you try to unfreeze the ultrasound image, you are asked if you want to save or 
discard the frozen image, i.e. the captured landmark, if the image was modified or not 
saved. 


[TABLE]
| F                                                                                          |                                                                                        |
| i                                                                                          |                                                                                        |
| gure 6-17: Freeze panel                                                                    |                                                                                        |
|:-------------------------------------------------------------------------------------------|:---------------------------------------------------------------------------------------|
| Freezing and unfreezing                                                                    |                                                                                        |
| To freeze the ultrasound image:                                                            |                                                                                        |
| 1.   Press the On/Off                                                                      | button to freeze the ultrasound image.                                                 |
|                                                                                            | The ultrasound image is frozen and a green dot appears above the Freeze function       |
| button and in the On/Off button, indicating the image is frozen.                           |                                                                                        |
| To unfreeze the ultrasound image:                                                          |                                                                                        |
| 1.   Press the On/Off                                                                      | button again.                                                                          |
| The ultrasound image returns to the live duodenoscope image.                               |                                                                                        |
| Note:  When you try to unfreeze the ultrasound image, you are asked if you want to save or |                                                                                        |
|                                                                                            | discard the frozen image, i.e. the captured landmark, if the image was modified or not |

[OCR]
Chapter 6 Gl Mentor Display Modes

Figure 6-17: Freeze panel

Freezing and unfreezing
To freeze the ultrasound image:

1. Press the On/Off e| button to freeze the ultrasound image.

The ultrasound image is frozen and a green dot appears above the Freeze function
button and in the On/Off button, indicating the image is frozen.

To unfreeze the ultrasound image:

1. Press the On/Off le button again.

The ultrasound image returns to the live duodenoscope image.

Note: When you try to unfreeze the ultrasound image, you are asked if you want to save or
discard the frozen image, i.e. the captured landmark, if the image was modified or not
saved.

surgicalscience Page 68


# Page 80

Chapter 6 
 GI Mentor Display Modes
 
Page 69
 
Manual structure labeling 
The ultrasound image freeze features allows for anatomical structure labeling. 
To manually identify anatomical structures and organs: 
1.  Press the Character 
 button. 
2.  Press on the Ultrasound display where you want to label an organ or structure. 
The white + turns yellow and the Characters sub-panel is displayed. 
 
Figure 6-18: Characters sub-panel 
3.  Press to select a name from the list or type the name in the text box with the 
keyboard.  
Note: You can also type a letter to display the list of names for that letter and then use the 
keyboard or screen to select the name from the list. 
The name appears in yellow in the specified place on the ultrasound image. 
4.  Press Enter. 
The label turns white on the image and is set for that structure. 


[TABLE]
| Chapter 6                       |                                                                                                 | GI Mentor Display Modes   |
|:--------------------------------|:------------------------------------------------------------------------------------------------|:--------------------------|
| Manual structure labeling       |                                                                                                 |                           |
|                                 | The ultrasound image freeze features allows for anatomical structure labeling.                  |                           |
|                                 | To manually identify anatomical structures and organs:                                          |                           |
| 1.   Press the Character        | button.                                                                                         |                           |
|                                 | 2.   Press on the Ultrasound display where you want to label an organ or structure.             |                           |
|                                 | The white + turns yellow and the Characters sub-panel is displayed.                             |                           |
| F                               |                                                                                                 |                           |
| i                               |                                                                                                 |                           |
| gure 6-18: Characters sub-panel |                                                                                                 |                           |
|                                 | 3.   Press to select a name from the list or type the name in the text box with the             |                           |
| keyboard.                       |                                                                                                 |                           |
|                                 | Note:  You can also type a letter to display the list of names for that letter and then use the |                           |
|                                 | keyboard or screen to select the name from the list.                                            |                           |
|                                 | The name appears in yellow in the specified place on the ultrasound image.                      |                           |
| 4.   Press Enter.               |                                                                                                 |                           |
|                                 | The label turns white on the image and is set for that structure.                               |                           |
|                                 |                                                                                                 | Page 69                   |

[OCR]
Chapter 6 Gl Mentor Display Modes

Manual structure labeling
The ultrasound image freeze features allows for anatomical structure labeling.

To manually identify anatomical structures and organs:

1. Press the Character EN button.
2. Press on the Ultrasound display where you want to label an organ or structure.

The white + turns yellow and the Characters sub-panel is displayed.

Characters

Enter Cancel

Figure 6-18: Characters sub-panel

3. Press to select a name from the list or type the name in the text box with the
keyboard.

Note: You can also type a letter to display the list of names for that letter and then use the
keyboard or screen to select the name from the list.

The name appears in yellow in the specified place on the ultrasound image.
4. Press Enter.

The label turns white on the image and is set for that structure.

surgicalscience Page 69


# Page 81

Chapter 6 
 GI Mentor Display Modes
 
Page 70
 
Note: The Enter button on the screen and the Enter key on the keyboard can both be used for 
setting the label. 
 
Figure 6-19: Anatomical labels and measurement on Ultrasound display 
Upon completion, the original Freeze panel is displayed. You can save the image 
with the anatomical labels or continue to label other anatomical structures. 
Caliper measurements  
To take a measurement: 
1.  Press the Caliper 
 button. 
The Caliper sub-panel is displayed. 


[TABLE]
| Chapter 6                           |                                                                                              | GI Mentor Display Modes   |
|:------------------------------------|:---------------------------------------------------------------------------------------------|:--------------------------|
|                                     | Note:  The Enter button on the screen and the Enter key on the keyboard can both be used for |                           |
| setting the label.                  |                                                                                              |                           |
| F                                   | gure 6-19: Anatomical labels and measurement on Ultrasound display                           |                           |
| i                                   |                                                                                              |                           |
|                                     | Upon completion, the original Freeze panel is displayed. You can save the image              |                           |
|                                     | with the anatomical labels or continue to label other anatomical structures.                 |                           |
| Caliper measurements                |                                                                                              |                           |
| To take a measurement:              |                                                                                              |                           |
| 1.   Press the Caliper              | button.                                                                                      |                           |
| The Caliper sub-panel is displayed. |                                                                                              |                           |
|                                     |                                                                                              | Page 70                   |

[OCR]
Chapter 6 Gl Mentor Display Modes

Note: The Enter button on the screen and the Enter key on the keyboard can both be used for
setting the label.

FreeHand-Simulation surgical

i

HELP FINISH

Figure 6-19: Anatomical labels and measurement on Ultrasound display

Upon completion, the original Freeze panel is displayed. You can save the image
with the anatomical labels or continue to label other anatomical structures.

Caliper measurements

To take a measurement:

1. Press the Caliper | button.

The Caliper sub-panel is displayed.

surgicalscience Page 70


# Page 82

Chapter 6 
 GI Mentor Display Modes
 
Page 71
 
 
Figure 6-20: Caliper sub-panel  
2.  Press on the Ultrasound display where you want to define the first caliper point. 
3.  Press the Lock 1st Point 
 button.  
A yellow square appears where the first point was placed. 
4.  Press on the Ultrasound display where you want to define the second caliper point. 
A second yellow square appears on the screen and a yellow line is drawn between 
the two points. 
5.  Press the Lock 2nd Point 
 button. 
The yellow line turns white and the distance is displayed in mm on the right side of 
the ultrasound display.  
You can press the Cancel button at any time to cancel the current measurement 
and return to the Freeze panel. 
Upon completion, the Freeze panel is displayed. You can save the image with the 
measurement or continue to measure other values.  


[TABLE]
| 2.   Press on the Ultrasound display where you want to define the first caliper point.   |                                                                                      |
|:-----------------------------------------------------------------------------------------|:-------------------------------------------------------------------------------------|
| 3.   Press the Lock 1st Point                                                            | button.                                                                              |
| A yellow square appears where the first point was placed.                                |                                                                                      |
| 4.   Press on the Ultrasound display where you want to define the second caliper point.  |                                                                                      |
|                                                                                          | A second yellow square appears on the screen and a yellow line is drawn between      |
| the two points.                                                                          |                                                                                      |
| 5.   Press the Lock 2nd Point                                                            | button.                                                                              |
|                                                                                          | The yellow line turns white and the distance is displayed in mm on the right side of |
| the ultrasound display.                                                                  |                                                                                      |
|                                                                                          | You can press the Cancel button at any time to cancel the current measurement        |
| and return to the Freeze panel.                                                          |                                                                                      |
| Upon completion, the Freeze panel is displayed. You can save the image with the          |                                                                                      |

[OCR]
Chapter 6 Gl Mentor Display Modes

Caliper

Figure 6-20: Caliper sub-panel

2. Press on the Ultrasound display where you want to define the first caliper point.

3. Press the Lock 1* Point button.

A yellow square appears where the first point was placed.

4. Press on the Ultrasound display where you want to define the second caliper point.
A second yellow square appears on the screen and a yellow line is drawn between
the two points.

5. Press the Lock 2™ Point 2) button.
The yellow line turns white and the distance is displayed in mm on the right side of
the ultrasound display.
You can press the Cancel button at any time to cancel the current measurement
and return to the Freeze panel.
Upon completion, the Freeze panel is displayed. You can save the image with the
measurement or continue to measure other values.

surgicalscience Page 71


# Page 83

Chapter 6 
 GI Mentor Display Modes
 
Page 72
 
Deleting measurements and labels 
To delete a measurement or label from an image: 
1.  On the Freeze panel, press Delete Item. 
A red + appears on the screen. 
2.  Place the + sign over the measurement or label you want to delete. 
3.  Press to select the item. 
The item turns yellow and a prompt appears asking if you want to delete the item 
from the image. 
4.  Press Confirm Delete Image.  
The measurement or label is deleted from the image. 
To delete all the measurements and labels from an image: 
1.  On the Freeze panel, press Delete All. 
A prompt appears asking if you want to delete all the items on the image. 
2.  Press Confirm Delete Image. 
All the measurements and labels are deleted from the image. 
Saving ultrasound images 
You can save snapshots of frozen ultrasound images (i.e. landmarks), while working. 
Those images can also include structure labeling and measurements.  
You can easily browse through these images and delete images you don’t need.  
To save an image: 
1.  Press the Save Image 
 button.  
The Save Image sub-panel is displayed. 


[TABLE]
| Chapter 6                                                                 | GI Mentor Display Modes                                                          |
|:--------------------------------------------------------------------------|:---------------------------------------------------------------------------------|
| Deleting measurements and labels                                          |                                                                                  |
| To delete a measurement or label from an image:                           |                                                                                  |
| 1.   On the Freeze panel, press Delete Item.                              |                                                                                  |
| A red + appears on the screen.                                            |                                                                                  |
| 2.   Place the + sign over the measurement or label you want to delete.   |                                                                                  |
| 3.   Press to select the item.                                            |                                                                                  |
|                                                                           | The item turns yellow and a prompt appears asking if you want to delete the item |
| from the image.                                                           |                                                                                  |
| 4.   Press Confirm Delete Image.                                          |                                                                                  |
| The measurement or label is deleted from the image.                       |                                                                                  |
| To delete all the measurements and labels from an image:                  |                                                                                  |
| 1.   On the Freeze panel, press Delete All.                               |                                                                                  |
| A prompt appears asking if you want to delete all the items on the image. |                                                                                  |
| 2.   Press Confirm Delete Image.                                          |                                                                                  |

[OCR]
Chapter 6 Gl Mentor Display Modes

Deleting measurements and labels

To delete a measurement or label from an image:
1. On the Freeze panel, press Delete Item.

A red + appears on the screen.

2. Place the + sign over the measurement or label you want to delete.
3. Press to select the item.

The item turns yellow and a prompt appears asking if you want to delete the item
from the image.

4. Press Confirm Delete Image.
The measurement or label is deleted from the image.

To delete all the measurements and labels from an image:
1. On the Freeze panel, press Delete All.

A prompt appears asking if you want to delete all the items on the image.
2. Press Confirm Delete Image.

All the measurements and labels are deleted from the image.

Saving ultrasound images

You can save snapshots of frozen ultrasound images (i.e. landmarks), while working.
Those images can also include structure labeling and measurements.

You can easily browse through these images and delete images you don’t need.

To save an image:

1. Press the Save Image Ee) button.
The Save Image sub-panel is displayed.

surgicalscience Page 72


# Page 84

Chapter 6 
 GI Mentor Display Modes
 
Page 73
 
 
Figure 6-21: Save Image sub-panel 
2.  Press Add New Image if you want to save the displayed image as a new image.  
Or  
Press Overwrite Image if you want this image to replace the previous image. 
The image is saved to the case performance. 
You can press the Cancel button at any time to return to the Freeze panel without 
saving.  
Browsing images 
To browse through the saved images: 
1.  Press the Browse Images 
 button. The Browse Images sub-panel is 
displayed. 


[TABLE]
| Chapter 6                                                                        | GI Mentor Display Modes                                                           |
|:---------------------------------------------------------------------------------|:----------------------------------------------------------------------------------|
| F                                                                                |                                                                                   |
| i                                                                                |                                                                                   |
| gure 6-21: Save Image sub-panel                                                  |                                                                                   |
| 2.   Press Add New Image if you want to save the displayed image as a new image. |                                                                                   |
| Or                                                                               |                                                                                   |
|                                                                                  | Press Overwrite Image if you want this image to replace the previous image.       |
| The image is saved to the case performance.                                      |                                                                                   |
|                                                                                  | You can press the Cancel button at any time to return to the Freeze panel without |
| saving.                                                                          |                                                                                   |
| Browsing images                                                                  |                                                                                   |
| To browse through the saved images:                                              |                                                                                   |
| 1.   Press the Browse Images                                                     | button. The Browse Images sub-panel is                                            |
| displayed.                                                                       |                                                                                   |
|                                                                                  | Page 73                                                                           |

[OCR]
Chapter 6 Gl Mentor Display Modes

Save Image

Figure 6-27: Save Image sub-panel

2. Press Add New Image if you want to save the displayed image as a new image.
Or
Press Overwrite Image if you want this image to replace the previous image.
The image is saved to the case performance.
You can press the Cancel button at any time to return to the Freeze panel without
saving.
Browsing images

To browse through the saved images:

1. Press the Browse Images - >| button. The Browse Images sub-panel is
displayed.

surgicalscience Page 73


# Page 85

Chapter 6 
 GI Mentor Display Modes
 
Page 74
 
 
Figure 6-22: Browse Images sub-panel 
2.  Press the Previous Image button to view the previous image or Next Image button 
to view the next image. The image number indication below the two arrows will 
change accordingly. 
To select an image: 
1.  Press the Select Image button. 
The image is now active and can be used for labeling, measuring, and other 
actions. 
To delete an image: 
1.  Press the Delete Image 
 button. 
2.  Press Confirm Delete Image. 
You can press the Cancel button at any time to return to the Freeze panel. 


[TABLE]
| F                                                                                    |                                                                               |
| i                                                                                    |                                                                               |
| gure 6-22: Browse Images sub-panel                                                   |                                                                               |
|:-------------------------------------------------------------------------------------|:------------------------------------------------------------------------------|
| 2.   Press the Previous Image button to view the previous image or Next Image button |                                                                               |
|                                                                                      | to view the next image. The image number indication below the two arrows will |
| change accordingly.                                                                  |                                                                               |
| To select an image:                                                                  |                                                                               |
| 1.   Press the Select Image button.                                                  |                                                                               |
|                                                                                      | The image is now active and can be used for labeling, measuring, and other    |
| actions.                                                                             |                                                                               |
| To delete an image:                                                                  |                                                                               |
| 1.   Press the Delete Image                                                          | button.                                                                       |
| 2.   Press Confirm Delete Image.                                                     |                                                                               |

[OCR]
Chapter 6 Gl Mentor Display Modes

Browse Images

Figure 6-22: Browse Images sub-panel

2. Press the Previous Image button to view the previous image or Next Image button
to view the next image. The image number indication below the two arrows will
change accordingly.

To select an image:
1. Press the Select Image button.

The image is now active and can be used for labeling, measuring, and other
actions.

To delete an image:
1. Press the Delete Image >| button.
2. Press Confirm Delete Image.
You can press the Cancel button at any time to return to the Freeze panel.

surgicalscience Page 74


# Page 86

Chapter 6 
 GI Mentor Display Modes
 
Page 75
 
 Helpers panel  
Note: This panel is only available for the educational environment. 
Press the Helpers 
 function button.  
The Helpers panel is displayed. 
 
Figure 6-23: Helpers panel 
Automatic labeling for anatomical structure identification 
You can automatically label organs and anatomical structures in the ultrasound view in 
order to identify them. 


[TABLE]
| Chapter 6                       |                                                                                        | GI Mentor Display Modes   |
|:--------------------------------|:---------------------------------------------------------------------------------------|:--------------------------|
| Helpers panel                   |                                                                                        |                           |
|                                 | Note:  This panel is only available for the educational environment.                   |                           |
| Press the Helpers               | function button.                                                                       |                           |
| The Helpers panel is displayed. |                                                                                        |                           |
| F                               |                                                                                        |                           |
| i                               |                                                                                        |                           |
| gure 6-23: Helpers panel        |                                                                                        |                           |
|                                 | Automatic labeling for anatomical structure identification                             |                           |
|                                 | You can automatically label organs and anatomical structures in the ultrasound view in |                           |
| order to identify them.         |                                                                                        |                           |
|                                 |                                                                                        | Page 75                   |

[OCR]
Chapter 6 Gl Mentor Display Modes

ind Helpers panel

Note: This panel is only available for the educational environment.

Press the Helpers i function button.
The Helpers panel is displayed.

Helpers

Contour

Figure 6-23: Helpers panel

Automatic labeling for anatomical structure identification

You can automatically label organs and anatomical structures in the ultrasound view in
order to identify them.

surgicalscience Page 75


# Page 87

Chapter 6 
 GI Mentor Display Modes
 
Page 76
 
 
Figure 6-24: Automatic labeling 
To automatically label: 
1.  Press the Labels 
 button. 
2.  Press on the structure of interest in the Ultrasound display. 
The name of the organ or structure is displayed on the screen. 
Coloring options  
To color the contour of organs: 
1.  In the Helpers panel, press the Contour 
 button. The color contour of the 
organs, with the same color displayed in the 3D map, is displayed on the 
Ultrasound display. 
 


[TABLE]
| Chapter 6                       |                                                                          | GI Mentor Display Modes          |
|:--------------------------------|:-------------------------------------------------------------------------|:---------------------------------|
| F                               |                                                                          |                                  |
| i                               |                                                                          |                                  |
| gure 6-24: Automatic labeling   |                                                                          |                                  |
| To automatically label:         |                                                                          |                                  |
| 1.   Press the Labels           | button.                                                                  |                                  |
|                                 | 2.   Press on the structure of interest in the Ultrasound display.       |                                  |
|                                 | The name of the organ or structure is displayed on the screen.           |                                  |
| Coloring options                |                                                                          |                                  |
| To color the contour of organs: |                                                                          |                                  |
| 1.                              | In the Helpers panel, press the Contour                                  | button. The color contour of the |
|                                 | organs, with the same color displayed in the 3D map, is displayed on the |                                  |
| Ultrasound display.             |                                                                          |                                  |
|                                 |                                                                          | Page 76                          |

[OCR]
Chapter 6 Gl Mentor Display Modes

creatic Duct

Figure 6-24; Automatic labeling
To automatically label:
1. Press the Labels button.

2. Press on the structure of interest in the Ultrasound display.

The name of the organ or structure is displayed on the screen.

Coloring options
To color the contour of organs:
1. In the Helpers panel, press the Contour | button. The color contour of the

organs, with the same color displayed in the 3D map, is displayed on the
Ultrasound display.

surgicalscience Page 76


# Page 88

Chapter 6 
 GI Mentor Display Modes
 
Page 77
 
 
Figure 6-25: Color contour of organs on Ultrasound display 
To color the entire organ: 
1.  In the Helpers panel, press the Colored 
 button. The organs are colored on the 
Ultrasound display as they are colored on the 3D map. 
 


[TABLE]
| Chapter 6                                                |
|  GI Mentor Display Modes                                 |
|:---------------------------------------------------------|
| F                                                        |
| i                                                        |
| gure 6-25: Color contour of organs on Ultrasound display |
| To color the entire organ:                               |
| 1.                                                       |
| In the Helpers panel, press the Colored                  |
|  button. The organs are colored on the                   |
| Ultrasound display as they are colored on the 3D map.    |
| Page 77                                                  |

[OCR]
Chapter 6 Gl Mentor Display Modes

Figure 6-25: Color contour of organs on Ultrasound display

To color the entire organ:

1. In the Helpers panel, press the Colored 9 button. The organs are colored on the
Ultrasound display as they are colored on the 3D map.

surgicalscience Page 77


# Page 89

Chapter 6 
 GI Mentor Display Modes
 
Page 78
 
 
Figure 6-26: Organs colored on the Ultrasound display 
To remove the contours and colors: 
1.  In the Helpers panel, press the Normal 
 button. The colors and contours are 
removed from the organs in the Ultrasound display. 
Filtering anatomical structures and organs 
To access the Filter sub-panel: 
1.  In the Helpers panel, press Filter 
 button. 
A sub-panel with an alphabetical list of organs and structures is displayed. 
 
Note: The same Filter sub-panel is available in the 3D-Map Controls panel. The filtered organs 
are displayed on both the 3D Map and the Ultrasound colored organs displays. 


[TABLE]
| Chapter 6                                                                                       |
|  GI Mentor Display Modes                                                                        |
|:------------------------------------------------------------------------------------------------|
| F                                                                                               |
| i                                                                                               |
| gure 6-26: Organs colored on the Ultrasound display                                             |
| To remove the contours and colors:                                                              |
| 1.                                                                                              |
| In the Helpers panel, press the Normal                                                          |
|  button. The colors and contours are                                                            |
| removed from the organs in the Ultrasound display.                                              |
| F                                                                                               |
| i                                                                                               |
| l                                                                                               |
| tering anatomical structures and organs                                                         |
| To access the Filter sub-panel:                                                                 |
| 1.                                                                                              |
| In the Helpers panel, press Filter                                                              |
|  button.                                                                                        |
| A sub-panel with an alphabetical list of organs and structures is displayed.                    |
| Note:  The same Filter sub-panel is available in the 3D-Map Controls panel. The filtered organs |
| are displayed on both the 3D Map and the Ultrasound colored organs displays.                    |
| Page 78                                                                                         |

[OCR]
Chapter 6 Gl Mentor Display Modes

Figure 6-26: Organs colored on the Ultrasound display

To remove the contours and colors:

1. In the Helpers panel, press the Normal 9) button. The colors and contours are
removed from the organs in the Ultrasound display.

Filtering anatomical structures and organs

To access the Filter sub-panel:

1. In the Helpers panel, press Filter Ed button.

A sub-panel with an alphabetical list of organs and structures is displayed.

Note: The same Filter sub-panel is available in the 3D-Map Controls panel. The filtered organs
are displayed on both the 3D Map and the Ultrasound colored organs displays.

surgicalscience Page 78


# Page 90

Chapter 6 
 GI Mentor Display Modes
 
Page 79
 
 
 
Figure 6-27: Filter sub-panel  
To hide anatomical structures or organs: 
1.  Press to unselect the check box next to those organs you wish to hide. 
The selected organs are removed from the 3D Map display and are not colored on 
the Ultrasound display. 
To show anatomical structures or organs: 
1.  Press to select the check box next to those organs you wish to show. 
The selected organs are added to the 3D Map display and are colored on the 
Ultrasound display. 


[TABLE]
| Chapter 6                                                                   | GI Mentor Display Modes                                                        |
|:----------------------------------------------------------------------------|:-------------------------------------------------------------------------------|
| F                                                                           |                                                                                |
| i                                                                           |                                                                                |
| gure 6-27: Filter sub-panel                                                 |                                                                                |
| To hide anatomical structures or organs:                                    |                                                                                |
| 1.   Press to unselect the check box next to those organs you wish to hide. |                                                                                |
|                                                                             | The selected organs are removed from the 3D Map display and are not colored on |
| the Ultrasound display.                                                     |                                                                                |
| To show anatomical structures or organs:                                    |                                                                                |
| 1.   Press to select the check box next to those organs you wish to show.   |                                                                                |
|                                                                             | The selected organs are added to the 3D Map display and are colored on the     |
| Ultrasound display.                                                         |                                                                                |
|                                                                             | Page 79                                                                        |

[OCR]
Chapter 6 Gl Mentor Display Modes

Filter

Figure 6-27. Filter sub-panel
To hide anatomical structures or organs:
1. Press to unselect the check box next to those organs you wish to hide.

The selected organs are removed from the 3D Map display and are not colored on
the Ultrasound display.

To show anatomical structures or organs:

1. Press to select the check box next to those organs you wish to show.

The selected organs are added to the 3D Map display and are colored on the
Ultrasound display.

surgicalscience Page 79


# Page 91

Chapter 6 
 GI Mentor Display Modes
 
Page 80
 
 
Figure 6-28: Selective organs display on 3D Map and Coloring option 
To select all the organs/structures: 
1.  Press All in the Filter panel. 
 
To deselect all the organs/structures: 
1.  Press None in the Filter panel. 
 
When the organs/structures selection fits your currently desired configuration, press 
Close. 
Switching between ultrasound modes  
You can select a different ultrasound mode during the simulation using the options in 
the Helpers panel.  
Note: In the EUS tasks module, the ultrasound mode is not selectable but set according to the 
practiced case.  


[TABLE]
| F                                                                   |                                                                                         |
| i                                                                   |                                                                                         |
| gure 6-28: Selective organs display on 3D Map and Coloring option   |                                                                                         |
|:--------------------------------------------------------------------|:----------------------------------------------------------------------------------------|
| To select all the organs/structures:                                |                                                                                         |
| 1.   Press All in the Filter panel.                                 |                                                                                         |
| T                                                                   |                                                                                         |
| o deselect all the organs/structures:                               |                                                                                         |
| 1.   Press None in the Filter panel.                                |                                                                                         |
| W                                                                   | hen the organs/structures selection fits your currently desired configuration, press    |
| Close.                                                              |                                                                                         |
| Switching between ultrasound modes                                  |                                                                                         |
|                                                                     | You can select a different ultrasound mode during the simulation using the options in   |
| the Helpers panel.                                                  |                                                                                         |
| Note:                                                               | In the EUS tasks module, the ultrasound mode is not selectable but set according to the |
|                                                                     | practiced case.                                                                         |

[OCR]
Chapter 6 Gl Mentor Display Modes

Figure 6-28: Selective organs display on 3D Map and Coloring option

To select all the organs/structures:
1. Press Allin the Filter panel.

To deselect all the organs/structures:
1. Press None in the Filter panel.

When the organs/structures selection fits your currently desired configuration, press
Close.
Switching between ultrasound modes

You can select a different ultrasound mode during the simulation using the options in
the Helpers panel.

Note: In the EUS tasks module, the ultrasound mode is not selectable but set according to the
practiced case.

surgicalscience Page 80


# Page 92

Chapter 6 
 GI Mentor Display Modes
 
Page 81
 
To select Linear EUS: 
1.  Press the Linear 
 button. The Linear ultrasound becomes active. 
 
Figure 6-29: Linear Ultrasound 
To select Radial EUS:  
1.  Press the Radial 
 button. The Radial ultrasound becomes active. 


[TABLE]
| Chapter 6                    | GI Mentor Display Modes                       |
|:-----------------------------|:----------------------------------------------|
| To select Linear EUS:        |                                               |
| 1.   Press the Linear        | button. The Linear ultrasound becomes active. |
| F                            |                                               |
| i                            |                                               |
| gure 6-29: Linear Ultrasound |                                               |
| To select Radial EUS:        |                                               |
| 1.   Press the Radial        | button. The Radial ultrasound becomes active. |
|                              | Page 81                                       |

[OCR]
Chapter 6 Gl Mentor Display Modes

To select Linear EUS:

1. Press the Linear Cy button. The Linear ultrasound becomes active.

Figure 6-29: Linear Ultrasound

To select Radial EUS:

1. Press the Radial button. The Radial ultrasound becomes active.

surgicalscience Page 81


# Page 93

Chapter 6 
 GI Mentor Display Modes
 
Page 82
 
 
Figure 6-30: Radial Ultrasound  
 Settings panel 
You can use the Settings panel to flip the ultrasound display. 
Press the Settings 
 function button above the right display pane.  
The Settings Panel is displayed. 
 
 
Figure 6-31: Settings panel 


[TABLE]
| Chapter 6                                                      | GI Mentor Display Modes                       |
|:---------------------------------------------------------------|:----------------------------------------------|
| F                                                              |                                               |
| i                                                              |                                               |
| gure 6-30: Radial Ultrasound                                   |                                               |
| Settings panel                                                 |                                               |
| You can use the Settings panel to flip the ultrasound display. |                                               |
| Press the Settings                                             | function button above the right display pane. |
| The Settings Panel is displayed.                               |                                               |
| F                                                              |                                               |
| i                                                              |                                               |
| gure 6-31: Settings panel                                      |                                               |
|                                                                | Page 82                                       |

[OCR]
Chapter 6 Gl Mentor Display Modes

Figure 6-30: Radial Ultrasound

Settings panel

You can use the Settings panel to flip the ultrasound display.

Press the Settings ~| function button above the right display pane.
The Settings Panel is displayed.

Settings

Flip &

Figure 6-31: Settings panel

surgicalscience Page 82


# Page 94

Chapter 6 
 GI Mentor Display Modes
 
Page 83
 
Flipping the ultrasound display  
To flip the ultrasound display: 
1.  Press the left Flip 
 button to flip the display horizontally to the left. 
2.  Press the right Flip 
 button to flip the display horizontally to the right. 
Working with 3D Map display 
 
Figure 6-32: 3D Map display in focus 
Display of ultrasound plane on 3D Map 
The ultrasound plane is dynamically displayed on the 3D map, offering correlation 
between the anatomical location of the scope and the structures demonstrated in the 
ultrasound view.  


[TABLE]
| Chapter 6                                                                         | GI Mentor Display Modes                                                             |
|:----------------------------------------------------------------------------------|:------------------------------------------------------------------------------------|
| F                                                                                 |                                                                                     |
| l                                                                                 |                                                                                     |
| i                                                                                 |                                                                                     |
| pping the ultrasound display                                                      |                                                                                     |
| To flip the ultrasound display:                                                   |                                                                                     |
| 1.   Press the left Flip                                                          | button to flip the display horizontally to the left.                                |
| 2.   Press the right Flip                                                         | button to flip the display horizontally to the right.                               |
| Working with 3D Map display                                                       |                                                                                     |
| F                                                                                 |                                                                                     |
| i                                                                                 |                                                                                     |
| gure 6-32: 3D Map display in focus                                                |                                                                                     |
| Display of ultrasound plane on 3D Map                                             |                                                                                     |
| The ultrasound plane is dynamically displayed on the 3D map, offering correlation |                                                                                     |
|                                                                                   | between the anatomical location of the scope and the structures demonstrated in the |
| ultrasound view.                                                                  |                                                                                     |
|                                                                                   | Page 83                                                                             |

[OCR]
Chapter 6 Gl Mentor Display Modes

Flipping the ultrasound display
To flip the ultrasound display:

1. Press the left Flip aa | button to flip the display horizontally to the left.

2. Press the right Flip button to flip the display horizontally to the right.

Working with 3D Map display

surgicals: o>

Figure 6-32: 3D Map display in focus

Display of ultrasound plane on 3D Map

The ultrasound plane is dynamically displayed on the 3D map, offering correlation
between the anatomical location of the scope and the structures demonstrated in the
ultrasound view.

surgical Page 83


# Page 95

Chapter 6 
 GI Mentor Display Modes
 
Page 84
 
  
Figure 6-33: Ultrasonography beam on 3D Map  
3D Map controls panel 
The 3D Map display has no function buttons as it only has one panel.  
Whenever the 3D map display is in focus, its controls panel is displayed: 


[TABLE]
| Chapter 6                                                                 | GI Mentor Display Modes   |
|:--------------------------------------------------------------------------|:--------------------------|
| F                                                                         |                           |
| i                                                                         |                           |
| gure 6-33: Ultrasonography beam on 3D Map                                 |                           |
| 3D Map controls panel                                                     |                           |
| The 3D Map display has no function buttons as it only has one panel.      |                           |
| Whenever the 3D map display is in focus, its controls panel is displayed: |                           |
|                                                                           | Page 84                   |

[OCR]
Chapter 6 Gl Mentor Display Modes

Figure 6-33: Ultrasonography beam on 3D Map

3D Map controls panel
The 3D Map display has no function buttons as it only has one panel.

Whenever the 3D map display is in focus, its controls panel is displayed:

surgicalscience Page 84


# Page 96

Chapter 6 
 GI Mentor Display Modes
 
Page 85
 
 
Figure 6-34: 3D Map controls panel 
Panning the 3D Map  
To pan the 3D Map: 
1.  Press an arrow button. The display is shifted in the direction of the arrow. 
 
Figure 6-35: Pan controls 


[TABLE]
| Chapter 6                                                                         | GI Mentor Display Modes   |
|:----------------------------------------------------------------------------------|:--------------------------|
| F                                                                                 |                           |
| i                                                                                 |                           |
| gure 6-34: 3D Map controls panel                                                  |                           |
| Panning the 3D Map                                                                |                           |
| To pan the 3D Map:                                                                |                           |
| 1.   Press an arrow button. The display is shifted in the direction of the arrow. |                           |
| F                                                                                 |                           |
| i                                                                                 |                           |
| gure 6-35: Pan controls                                                           |                           |
|                                                                                   | Page 85                   |

[OCR]
Chapter 6 Gl Mentor Display Modes

Controls

Zoom Out Zoom In

Figure 6-34: 3D Map controls panel

Panning the 3D Map

To pan the 3D Map:
1. Press an arrow button. The display is shifted in the direction of the arrow.

Figure 6-35: Pan controls

surgicalscience Page 85


# Page 97

Chapter 6 
 GI Mentor Display Modes
 
Page 86
 
Rotating the 3D Map  
To rotate the 3D Map: 
1.  Press one of the Rotate 
 arrows. The 3D Map rotates on its axis 
in the direction of the arrow. 
Zooming the 3D Map display 
To enlarge the 3D Map display: 
1.  Press the Zoom In 
 button in the Controls panel.  
To reduce the 3D Map display:  
1.  Press the Zoom Out 
 button. 
Reseting the 3D Map display 
To reset the 3D Map display: 
1.  Press the Reset 
 button. The display returns to its original settings. 
Filtering anatomical structures or organs 
You can use the filtering option to show or hide anatomical structures and organs.  
Note: The same filter sub-panel is available in the Helpers panel. The filtered organs are 
displayed on both the 3D Map and the Ultrasound colored organs displays. 
 
To access the Filter sub-panel: 
1.  In the Controls panel, press the Filter 
 button. An alphabetical list of organs 
and structures is displayed. 


[TABLE]
| Chapter 6                                                                                   |
|  GI Mentor Display Modes                                                                    |
|:--------------------------------------------------------------------------------------------|
| Rotating the 3D Map                                                                         |
| To rotate the 3D Map:                                                                       |
| 1.   Press one of the Rotate                                                                |
|  arrows. The 3D Map rotates on its axis                                                     |
| in the direction of the arrow.                                                              |
| Zooming the 3D Map display                                                                  |
| To enlarge the 3D Map display:                                                              |
| 1.   Press the Zoom In                                                                      |
|  button in the Controls panel.                                                              |
| To reduce the 3D Map display:                                                               |
| 1.   Press the Zoom Out                                                                     |
|  button.                                                                                    |
| Reseting the 3D Map display                                                                 |
| To reset the 3D Map display:                                                                |
| 1.   Press the Reset                                                                        |
|  button. The display returns to its original settings.                                      |
| F                                                                                           |
| i                                                                                           |
| l                                                                                           |
| tering anatomical structures or organs                                                      |
| You can use the filtering option to show or hide anatomical structures and organs.          |
| Note:  The same filter sub-panel is available in the Helpers panel. The filtered organs are |
| displayed on both the 3D Map and the Ultrasound colored organs displays.                    |
| T                                                                                           |
| o access the Filter sub-panel:                                                              |
| 1.                                                                                          |
| In the Controls panel, press the Filter                                                     |
|  button. An alphabetical list of organs                                                     |
| and structures is displayed.                                                                |
| Page 86                                                                                     |

[OCR]
Chapter 6 Gl Mentor Display Modes

Rotating the 3D Map
To rotate the 3D Map:

1. Press one of the Rotate arrows. The 3D Map rotates on its axis
in the direction of the arrow.

Zooming the 3D Map display
To enlarge the 3D Map display:

1. Press the Zoom In iQ button in the Controls panel.
To reduce the 3D Map display:

1. Press the Zoom Out |] button.

Reseting the 3D Map display
To reset the 3D Map display:

1. Press the Reset fe) button. The display returns to its original settings.

Filtering anatomical structures or organs

You can use the filtering option to show or hide anatomical structures and organs.

Note: The same filter sub-panel is available in the Helpers panel. The filtered organs are
displayed on both the 3D Map and the Ultrasound colored organs displays.

To access the Filter sub-panel:

1. In the Controls panel, press the Filter Eg button. An alphabetical list of organs
and structures is displayed.

surgicalscience Page 86


# Page 98

Chapter 6 
 GI Mentor Display Modes
 
Page 87
 
 
Figure 6-36: Filter sub-panel  
For a detailed explanation how to use the filter option, see Filtering anatomical 
structures and organs on page 78. 
Enhanced Clinical display mode 
The Enhanced Clinical display mode applies to the EMR/ESD modules.  


[TABLE]
| Chapter 6                                                                         | GI Mentor Display Modes   |
|:----------------------------------------------------------------------------------|:--------------------------|
| F                                                                                 |                           |
| i                                                                                 |                           |
| gure 6-36: Filter sub-panel                                                       |                           |
| For a detailed explanation how to use the filter option, see Filtering anatomical |                           |
| structures and organs on page 78.                                                 |                           |
| Enhanced Clinical display mode                                                    |                           |
| The Enhanced Clinical display mode applies to the EMR/ESD modules.                |                           |
|                                                                                   | Page 87                   |

[OCR]
Chapter 6 Gl Mentor Display Modes

Figure 6-36: Filter sub-panel

For a detailed explanation how to use the filter option, see Filtering anatomical
structures and organs on page 78.

Enhanced Clinical display mode

The Enhanced Clinical display mode applies to the EMR/ESD modules.

surgicalscience Page 87


# Page 99

Chapter 6 
 GI Mentor Display Modes
 
Page 88
 
Screen layout 
 
Figure 6-37: Enhanced Clinical Display Mode screen layout 
The screen is divided into the following parts: 
① Main View  
② 3D Map 
③ Patient Management Panel 
④ Controls Panel 
⑤ Tool Menu 
⑥ Virtual Instructor  
⑦ General Buttons 
Note: The Case environment differs from the Step-by-Step Task environment in that step-step 
on-screen guidance replaces the Patient Management panel. 


[TABLE]
| Chapter 6                                                 | GI Mentor Display Modes                                                                      |
|:----------------------------------------------------------|:---------------------------------------------------------------------------------------------|
| Screen layout                                             |                                                                                              |
| F                                                         |                                                                                              |
| i                                                         |                                                                                              |
| gure 6-37: Enhanced Clinical Display Mode screen layout   |                                                                                              |
| The screen is divided into the following parts:           |                                                                                              |
| ①  Main View                                              |                                                                                              |
| ②  3D Map                                                 |                                                                                              |
| ③  Patient Management Panel                               |                                                                                              |
| ④  Controls Panel                                         |                                                                                              |
| ⑤  Tool Menu                                              |                                                                                              |
| ⑥  Virtual Instructor                                     |                                                                                              |
| ⑦  General Buttons                                        |                                                                                              |
|                                                           | Note:  The Case environment differs from the Step-by-Step Task environment in that step-step |
| on-screen guidance replaces the Patient Management panel. |                                                                                              |
|                                                           | Page 88                                                                                      |

[OCR]
Chapter 6 Gl Mentor Display Modes

Screen layout

surgical

@ excessive local pressure : Pll back (6)

Figure 6-37: Enhanced Clinical Display Mode screen layout

The screen is divided into the following parts:
@) Main View

(2) 3D Map

(3) Patient Management Panel

(4) Controls Panel

() Tool Menu
(6) Virtual Instructor

@) General Buttons

Note: The Case environment differs from the Step-by-Step Task environment in that step-step
on-screen guidance replaces the Patient Management panel.

surgicalscience Page 88


# Page 100

Chapter 6 
 GI Mentor Display Modes
 
Page 89
 
Primary view 
 
Figure 6-38: Primary View - Enhanced Clinical display mode 
The primary view  shows the real-time simulated endoscope’s view during the 
procedure you are performing. 
General features and educational aids 
The following is a list of features and educational aids available in the Enhanced 
Clinical display mode: 
② 3D Map 
 – opens or 
collapses the external 3D Map view on the top of the left panel. The map can be 
rotated by sliding on the touch screen and restored to its default position by 
pressing the Reset button 
. 


[TABLE]
| Chapter 6                     |                                                                                    | GI Mentor Display Modes   |
|:------------------------------|:-----------------------------------------------------------------------------------|:--------------------------|
| Primary view                  |                                                                                    |                           |
| F                             | gure 6-38: Primary View - Enhanced Clinical display mode                           |                           |
| i                             |                                                                                    |                           |
|                               | The primary view  shows the real-time simulated endoscope’s view during the       |                           |
| procedure you are performing. |                                                                                    |                           |
|                               | General features and educational aids                                              |                           |
|                               | The following is a list of features and educational aids available in the Enhanced |                           |
| Clinical display mode:        |                                                                                    |                           |
| ②  3D Map                     |                                                                                    | – opens or                |
|                               | collapses the external 3D Map view on the top of the left panel. The map can be    |                           |
|                               | rotated by sliding on the touch screen and restored to its default position by     |                           |
| pressing the Reset button     | .                                                                                  |                           |
|                               |                                                                                    | Page 89                   |

[OCR]
Chapter 6 Gl Mentor Display Modes

Primary view

Figure 6-38: Primary View - Enhanced Clinical display mode

The primary view © shows the real-time simulated endoscope’s view during the
procedure you are performing.

General features and educational aids

The following is a list of features and educational aids available in the Enhanced
Clinical display mode:

@ 3D Map — opens or
collapses the external 3D Map view on the top of the left panel. The map can be
rotated by sliding on the touch screen and restored to its default position by
24

pressing the Reset button

surgicalscience Page 89


# Page 101

Chapter 6 
 GI Mentor Display Modes
 
Page 90
 
 
Figure 6-39: 3D Map – Enhanced Clinical display mode 
⑥  Virtual Instructor – see page 55.  
 
 
⑦ General Buttons – The buttons are the same as for the General Endoscopy 
mode. For an explanation, see page 56. 
Image Enhancement Mode 
Image Enhancement Mode ④ displays the Primary View using simulated electronic 
chromoendoscopy. Electronic chromoendoscopy provides detailed enhancement of 
blood vessels on the mucosal surface. 
To view the Primary View in Image Enhancement Mode, press the Image Enhancement 
 button in the Controls panel on the right side of the screen. 
OR 
Press the F or 1 button on the scope. 


[TABLE]
| ⑦                                                                               |
|                                                                                 |
|   General Buttons – The buttons are the same as for the General Endoscopy       |
|:--------------------------------------------------------------------------------|
| mode. For an explanation, see page 56.                                          |
| Image Enhancement Mode                                                          |
| Image Enhancement Mode ④ displays the Primary View using simulated electronic   |
| chromoendoscopy. Electronic chromoendoscopy provides detailed enhancement of    |
| blood vessels on the mucosal surface.                                           |
| To view the Primary View in Image Enhancement Mode, press the Image Enhancement |
| button in the Controls panel on the right side of the screen.                   |
| OR                                                                              |
| Press the F or 1 button on the scope.                                           |

[OCR]
Chapter 6 Gl Mentor Display Modes

Figure 6-39: 3D Map — Enhanced Clinical display mode

©) Virtual Instructor - see page 55.

® The risk of perforation is increasing: Do not apply electricity so close to Gl wall

@) General Buttons - The buttons are the same as for the General Endoscopy
mode. For an explanation, see page 56.

Image Enhancement Mode

Image Enhancement Mode () displays the Primary View using simulated electronic
chromoendoscopy. Electronic chromoendoscopy provides detailed enhancement of
blood vessels on the mucosal surface.

To view the Primary View in Image Enhancement Mode, press the Image Enhancement

awe

button in the Controls panel on the right side of the screen.
OR

Press the F or 1 button on the scope.

surgicalscience Page 90


# Page 102

Chapter 6 
 GI Mentor Display Modes
 
Page 91
 
 
Figure 6-40: Image Enhancement Mode 
Paris Classification 
Press the Classification 
 button ④ in the Controls panel on the right side of the 
screen to display the different grades of Paris Classification. Review the list prior to 
choosing the proper type. 


[TABLE]
| Chapter 6                                                                                | GI Mentor Display Modes                                 |
|:-----------------------------------------------------------------------------------------|:--------------------------------------------------------|
| F                                                                                        |                                                         |
| i                                                                                        |                                                         |
| gure 6-40: Image Enhancement Mode                                                        |                                                         |
| Paris Classification                                                                     |                                                         |
| Press the Classification                                                                 | button ④ in the Controls panel on the right side of the |
| screen to display the different grades of Paris Classification. Review the list prior to |                                                         |
| choosing the proper type.                                                                |                                                         |
|                                                                                          | Page 91                                                 |

[OCR]
Chapter 6 Gl Mentor Display Modes

Enhanced Imaging

Figure 6-40: Image Enhancement Mode

Paris Classification

—

Press the Classification Go button @) in the Controls panel on the right side of the
screen to display the different grades of Paris Classification. Review the list prior to
choosing the proper type.

surgicalscience Page 91


# Page 103

Chapter 6 
 GI Mentor Display Modes
 
Page 92
 
 
Figure 6-41: Paris Classification list 
Electrosurgical controls ⑤ 
The electrical mode selection buttons  and electricity power setting controls are used 
with tools requiring electrosurgical current. For a detailed explanation, see Working 
with tools requiring electrosurgical current on page 98. 
Patient Management 
The Enhanced Clinical Display Mode, includes a responsive virtual patient, featuring 
moderate sedation medications and oxygen supplement, both affecting an altering 
consciousness level and vital signs.  
The Patient Management panel ③ consists of all the patient care elements that are 
part of the moderate sedation for EMR/ESD procedure.  


[TABLE]
| F                                                                                      |
| i                                                                                      |
| gure 6-41: Paris Classification list                                                   |
|:---------------------------------------------------------------------------------------|
| Electrosurgical controls ⑤                                                             |
| The electrical mode selection buttons  and electricity power setting controls are used |
| with tools requiring electrosurgical current. For a detailed explanation, see Working  |
| with tools requiring electrosurgical current on page 98.                               |
| Patient Management                                                                     |
| The Enhanced Clinical Display Mode, includes a responsive virtual patient, featuring   |
| moderate sedation medications and oxygen supplement, both affecting an altering        |
| consciousness level and vital signs.                                                   |
| The Patient Management panel ③ consists of all the patient care elements that are      |
| part of the moderate sedation for EMR/ESD procedure.                                   |

[OCR]
Chapter 6 Gl Mentor Display Modes

Figure 6-41: Paris Classification list

Electrosurgical controls G)

The electrical mode selection buttons and electricity power setting controls are used
with tools requiring electrosurgical current. For a detailed explanation, see Working
with tools requiring electrosurgical current on page 98.

Patient Management

The Enhanced Clinical Display Mode, includes a responsive virtual patient, featuring
moderate sedation medications and oxygen supplement, both affecting an altering
consciousness level and vital signs.

The Patient Management panel @) consists of all the patient care elements that are
part of the moderate sedation for EMR/ESD procedure.

surgicalscience Page 92


# Page 104

Chapter 6 
 GI Mentor Display Modes
 
Page 93
 
 
Figure 6-42: Patient Management panel 
The Patient Management Panel contains the following components: 
① Vital Signs 
➁ Consciousness Level  
③ Oxygen Supplement 
④ Moderate Sedation Administration 
⑤ Administered Sedatives List  
Vital signs monitoring  
① - The vital signs section includes current patient Heart Rate, Blood Pressure, 
Respiratory Rate, and SpO2 as well as an ECG line. 
When a vital sign deviates from its normal range, an exclamation mark will appear 
adjacent to the relevant vital sign requiring the user's attention.  


[TABLE]
| F                                                                                 |
| i                                                                                 |
| gure 6-42: Patient Management panel                                               |
|:----------------------------------------------------------------------------------|
| The Patient Management Panel contains the following components:                   |
| ①  Vital Signs                                                                    |
| ②  Consciousness Level                                                            |
| ③  Oxygen Supplement                                                              |
| ④  Moderate Sedation Administration                                               |
| ⑤  Administered Sedatives List                                                    |
| Vital signs monitoring                                                            |
| ① - The vital signs section includes current patient Heart Rate, Blood Pressure,  |
| Respiratory Rate, and SpO2 as well as an ECG line.                                |
| When a vital sign deviates from its normal range, an exclamation mark will appear |
| adjacent to the relevant vital sign requiring the user's attention.               |

[OCR]
Chapter 6 Gl Mentor Display Modes

P

21/82

1

Oxygen: < | 2L\min | > @ Consciousness

Flumazenil Vv <) 200mcg

Sedative Time Total
Midazolam 00:00:04 | 2mg
Fentanyl 00:00:21 | 25mcg
Propofol 00:00:59 | 40mg
Naloxone 00:01:32 | 30mcg
Flumazenil 00:01:51 | 200mcg

Figure 6-42: Patient Management panel

The Patient Management Panel contains the following components:
@) Vital Signs

(2) Consciousness Level

(3) Oxygen Supplement

(4) Moderate Sedation Administration

(5) Administered Sedatives List

Vital signs monitoring
@ - The vital signs section includes current patient Heart Rate, Blood Pressure,
Respiratory Rate, and SpO2 as well as an ECG line.

When a vital sign deviates from its normal range, an exclamation mark will appear
adjacent to the relevant vital sign requiring the user's attention.

surgicalscience Page 93


# Page 105

Chapter 6 
 GI Mentor Display Modes
 
Page 94
 
 
Figure 6-43: Vital signs deviation alert 
If not attended, the deviation might deteriorate into aggravating hemodynamic 
complications or respiratory depression events. 
Consciousness level monitoring  
② - Monitoring the consciousness level, according to the Ramsey scale, can be done 
by pressing the Consciousness button. The consciousness level is affected by the 
sedation administered as explained in Moderate sedation administration on page 95.  
 
Figure 6-44: Checking consciousness  
The consciousness levels are: 
1 - Anxious and agitated, or restless, or both 
2 - Cooperative, orientated, and tranquil 
3 - Responds to commands only 
4 - Brisk response to tactile or loud auditory stimulus 
5 - Sluggish response to tactile or loud auditory stimulus 
6 - No response to stimulus 
Oxygen supplement  
③ - Administering oxygen supplement of up to 10 L/min is available, helping to keep 
the virtual patient's SpO2 within the desired range. 


[TABLE]
| F                                                                                  |
| i                                                                                  |
| gure 6-43: Vital signs deviation alert                                             |
|:-----------------------------------------------------------------------------------|
| If not attended, the deviation might deteriorate into aggravating hemodynamic      |
| complications or respiratory depression events.                                    |
| Consciousness level monitoring                                                     |
| ② - Monitoring the consciousness level, according to the Ramsey scale, can be done |
| by pressing the Consciousness button. The consciousness level is affected by the   |
| sedation administered as explained in Moderate sedation administration on page 95. |

[OCR]
Chapter 6 Gl Mentor Display Modes

97% 68/46

Figure 6-43: Vital signs deviation alert

If not attended, the deviation might deteriorate into aggravating hemodynamic
complications or respiratory depression events.

Consciousness level monitoring

@ - Monitoring the consciousness level, according to the Ramsey scale, can be done
by pressing the Consciousness button. The consciousness level is affected by the
sedation administered as explained in Moderate sedation administration on page 95.

1- Anxious and agitated or restless or both

Figure 6-44: Checking consciousness

The consciousness levels are:

1 - Anxious and agitated, or restless, or both

2 - Cooperative, orientated, and tranquil

3 - Responds to commands only

4 - Brisk response to tactile or loud auditory stimulus

5 - Sluggish response to tactile or loud auditory stimulus
6 - No response to stimulus

Oxygen supplement

© - Administering oxygen supplement of up to 10 L/min is available, helping to keep
the virtual patient's SpO2 within the desired range.

surgicalscience Page 94


# Page 106

Chapter 6 
 GI Mentor Display Modes
 
Page 95
 
To administrate oxygen: 
Use the right and left arrows to set the oxygen flow rate in units of liter per minute. 
Moderate sedation administration 
④ - As moderate sedation is mostly an integral part of the GI procedure, the GI Mentor 
offers commonly used sedatives and their reversal agents to simulate this aspect of 
the procedure. However, under no circumstances should this be perceived as a course 
in moderate sedation.  
The sedatives and reversal agents available are: 
Group 
Sedative 
Reversal agent 
Benzodiazepines 
Midazolam 
Flumazenil 
 
Narcotics 
Fentanyl 
Meperidine 
Naloxone 
 
Other 
Propofol  
 
 
At the beginning of the procedure, the sedative list is available and the reversal agents 
are disabled. Once a sedative from a certain group is administered, the other sedatives 
of this group become disabled for the duration of the case run and the reversal agent 
for that group of sedatives is enabled.  
Once a reversal agent has been used, all sedatives become disabled. 
Propofol can be used as a third agent only if the other two sedatives haven't exceeded 
a certain amount.  


[TABLE]
| Chapter 6                                                                               | GI Mentor Display Modes                                                                |
|:----------------------------------------------------------------------------------------|:---------------------------------------------------------------------------------------|
| To administrate oxygen:                                                                 |                                                                                        |
| Use the right and left arrows to set the oxygen flow rate in units of liter per minute. |                                                                                        |
| Moderate sedation administration                                                        |                                                                                        |
|                                                                                         | ④ - As moderate sedation is mostly an integral part of the GI procedure, the GI Mentor |
| offers commonly used sedatives and their reversal agents to simulate this aspect of     |                                                                                        |
|                                                                                         | the procedure. However, under no circumstances should this be perceived as a course    |
| in moderate sedation.                                                                   |                                                                                        |
| The sedatives and reversal agents available are:                                        |                                                                                        |

[OCR_TABLE]
Chanter &

[OCR_TABLE]
VU GMI

LIan FAR rin

[OCR]
Chapter 6 Gl Mentor Display Modes

To administrate oxygen:
Use the right and left arrows to set the oxygen flow rate in units of liter per minute.

Moderate sedation administration
() - As moderate sedation is mostly an integral part of the Gl procedure, the GI Mentor
offers commonly used sedatives and their reversal agents to simulate this aspect of

the procedure. However, under no circumstances should this be perceived as a course
in moderate sedation.

The sedatives and reversal agents available are:

Group Sedative Reversal agent
Benzodiazepines Midazolam Flumazenil
Narcotics Fentanyl Naloxone
Meperidine
Other Propofol

At the beginning of the procedure, the sedative list is available and the reversal agents
are disabled. Once a sedative from a certain group is administered, the other sedatives
of this group become disabled for the duration of the case run and the reversal agent
for that group of sedatives is enabled.

Once a reversal agent has been used, all sedatives become disabled.

Propofol can be used as a third agent only if the other two sedatives haven't exceeded
a certain amount.

surgicalscience Page 95


# Page 107

Chapter 6 
 GI Mentor Display Modes
 
Page 96
 
 
Figure 6-45: Moderate sedation – sedative selection 
To administer sedation:  
1. Select the desired sedative from the list of available drugs. 
2. Use the Left and Right arrows if you wish to administer a different dosage. 
3. Press the syringe icon to administer the drug. 
4. Administered sedatives will appear in the Administered Sedatives list. 
Administered Sedatives List  
⑤ - The Administered Sedatives List displays the sedative name, dosage, time since 
the drug was administered, and the total dosage of each drug administered. 
 
Figure 6-46: Administered Sedatives list 


[TABLE]
| F                                                                               | gure 6-45: Moderate sedation – sedative selection                                  |
| i                                                                               |                                                                                    |
|:--------------------------------------------------------------------------------|:-----------------------------------------------------------------------------------|
| To administer sedation:                                                         |                                                                                    |
| 1.                                                                              | Select the desired sedative from the list of available drugs.                      |
| 2.  Use the Left and Right arrows if you wish to administer a different dosage. |                                                                                    |
| 3.  Press the syringe icon to administer the drug.                              |                                                                                    |
| 4.  Administered sedatives will appear in the Administered Sedatives list.      |                                                                                    |
| Administered Sedatives List                                                     |                                                                                    |
|                                                                                 | ⑤ - The Administered Sedatives List displays the sedative name, dosage, time since |
| the drug was administered, and the total dosage of each drug administered.      |                                                                                    |

[OCR]
Chapter 6 Gl Mentor Display Modes

Midazolam

Midazolam

Fentanyl

Meperidine

Propofol

Figure 6-45: Moderate sedation — sedative selection

To administer sedation:

1. Select the desired sedative from the list of available drugs.

2. Use the Left and Right arrows if you wish to administer a different dosage.
3. Press the syringe icon to administer the drug.

4. Administered sedatives will appear in the Administered Sedatives list.

Administered Sedatives List

© - The Administered Sedatives List displays the sedative name, dosage, time since
the drug was administered, and the total dosage of each drug administered.

Flumazenil < 200 mcg

Midazolam 00:00:04

Fentanyl 00:00:21

Propofol 00:00:59
Naloxone 00:01:32
Flumazenil 00:01:51

Figure 6-46: Administered Sedatives list

surgicalscience Page 96


# Page 108

Chapter 7 
 Working with Endoscopic Tools
 
Page 97
 
Chapter 7 Working with Endoscopic Tools 
The Master Tool is used to simulate multiple tools. For a detailed explanation on the 
Master Tool, see Master Tool on page 19. 
Working with tools  
Upon inserting the Master Tool into the working channel of the scope, a tools menu 
opens from which you can select the desired tool. 
To select a tool: 
1.  Insert the Master Tool slowly into the working channel until the Tools menu 
appears.  
The Tools menu opens with pictures of all available tools for the current case.  
2.  Press to select the desired tool.  
The Tools menu closes and the tool is displayed in the primary view. 
Note: Unlike in an actual procedure, the selected tool is simulated already at the far end of the 
working channel upon initial tool insertion. Thus, after introducing and selecting a tool, 
you only need to slightly insert it to have it already inside the anatomy. 
 
 
Figure 7-1: Tools menu 


[TABLE]
| Chapter 7                                                                                          |
|  Working with Endoscopic Tools                                                                     |
|:---------------------------------------------------------------------------------------------------|
| Chapter 7 Working with Endoscopic Tools                                                            |
| The Master Tool is used to simulate multiple tools. For a detailed explanation on the              |
| Master Tool, see Master Tool on page 19.                                                           |
| Working with tools                                                                                 |
| Upon inserting the Master Tool into the working channel of the scope, a tools menu                 |
| opens from which you can select the desired tool.                                                  |
| To select a tool:                                                                                  |
| 1.                                                                                                 |
| Insert the Master Tool slowly into the working channel until the Tools menu                        |
| appears.                                                                                           |
| The Tools menu opens with pictures of all available tools for the current case.                    |
| 2.   Press to select the desired tool.                                                             |
| The Tools menu closes and the tool is displayed in the primary view.                               |
| Note:  Unlike in an actual procedure, the selected tool is simulated already at the far end of the |
| working channel upon initial tool insertion. Thus, after introducing and selecting a tool,         |

[OCR]
Chapter 7 Working with Endoscopic Tools

| Chapter 7 Working with Endoscopic Tools

The Master Tool is used to simulate multiple tools. For a detailed explanation on the
Master Tool, see Master Tool on page 19.

Working with tools

Upon inserting the Master Tool into the working channel of the scope, a tools menu
opens from which you can select the desired tool.

To select a tool:

1. Insert the Master Tool slowly into the working channel until the Tools menu
appears.

The Tools menu opens with pictures of all available tools for the current case.
2. Press to select the desired tool.

The Tools menu closes and the tool is displayed in the primary view.

Note: Unlike in an actual procedure, the selected tool is simulated already at the far end of the
working channel upon initial tool insertion. Thus, after introducing and selecting a tool,
you only need to slightly insert it to have it already inside the anatomy.

Forceps Injection Needle

Balloon

Figure 7-1: Tools menu

surgicalscience Page 97


# Page 109

Chapter 7 
 Working with Endoscopic Tools
 
Page 98
 
To work with Master Tool handle: 
• 
Pull the Master Tool handle back to open, inflate, or fill the tool. 
• 
Push the Master Tool handle forward to close, deflate, or inject with the tool.  
To finish working with a selected tool, or change your tool selection: 
1.  Remove the Master Tool from the working channel of the colonoscope. 
2.  Upon reintroducing the Master Tool, you will again be prompted to select the 
endoscopic tool you wish to use. 
Working with tools requiring electrosurgical current 
When a tool requiring an electrosurgical current is selected from the Tools menu, 
electrical power settings are displayed beside the primary display. These settings 
allow you to select the electrical mode and values for activating the tool. 
To work with a tool requiring electricity: 
1.  Select the tool. The tool mode and power settings are displayed. 
 
Figure 7-2: Electrosurgical settings (and polyp extraction) in Enhanced Clinical display mode 


[TABLE]
| Chapter 7                                                                          |
|  Working with Endoscopic Tools                                                     |
|:-----------------------------------------------------------------------------------|
| To work with Master Tool handle:                                                   |
| Pull the Master Tool handle back to open, inflate, or fill the tool.               |
| •                                                                                  |
| Push the Master Tool handle forward to close, deflate, or inject with the tool.    |
| •                                                                                  |
| To finish working with a selected tool, or change your tool selection:             |
| 1.   Remove the Master Tool from the working channel of the colonoscope.           |
| 2.   Upon reintroducing the Master Tool, you will again be prompted to select the  |
| endoscopic tool you wish to use.                                                   |
| Working with tools requiring electrosurgical current                               |
| When a tool requiring an electrosurgical current is selected from the Tools menu,  |
| electrical power settings are displayed beside the primary display. These settings |
| allow you to select the electrical mode and values for activating the tool.        |
| To work with a tool requiring electricity:                                         |
| 1.   Select the tool. The tool mode and power settings are displayed.              |

[OCR]
Chapter 7 Working with Endoscopic Tools

To work with Master Tool handle:

e Pull the Master Tool handle back to open, inflate, or fill the tool.

e Push the Master Tool handle forward to close, deflate, or inject with the tool.
To finish working with a selected tool, or change your tool selection:

1. Remove the Master Tool from the working channel of the colonoscope.
2. Upon reintroducing the Master Tool, you will again be prompted to select the
endoscopic tool you wish to use.

Working with tools requiring electrosurgical current

When a tool requiring an electrosurgical current is selected from the Tools menu,
electrical power settings are displayed beside the primary display. These settings
allow you to select the electrical mode and values for activating the tool.

To work with a tool requiring electricity:

1. Select the tool. The tool mode and power settings are displayed.

Figure 7-2: Electrosurgical settings (and polyp extraction) in Enhanced Clinical display mode

surgicalscience Page 98


# Page 110

Chapter 7 
 Working with Endoscopic Tools
 
Page 99
 
 
Figure 7-3: Electrosurgical settings for the Endoscopy and Fluoroscopy display mode 
2.  Select the desired mode (Cut, Coag or Blend). 
3.  Adjust the desired electrical power settings by pressing the directional arrows. 
4.  Press the left foot switch to apply electricity. 
Working with multiple tools and wires 
Note: The duodenoscope allows for working simultaneously with three tools and wires, inserted 
through three separate working channel openings.  
1.  Insert the Master Tool into the white-marked working channel and select from the 
Tools menu (see Working with tools on page 97). 
2.  When there is a tool in the white working channel, the red wire, simulating the 
guide wire, can be inserted into the red-marked working channel. 
Note:  The red wire always simulates the guide wire and need not be selected from a menu. 
The guide wire appears in both the endoscopic and the fluoroscopic views. 


[TABLE]
|                                                                                                | F                                                                                   |
|                                                                                                | i                                                                                   |
|                                                                                                | gure 7-3: Electrosurgical settings for the Endoscopy and Fluoroscopy display mode   |
|:-----------------------------------------------------------------------------------------------|:------------------------------------------------------------------------------------|
| 2.   Select the desired mode (Cut, Coag or Blend).                                             |                                                                                     |
| 3.   Adjust the desired electrical power settings by pressing the directional arrows.          |                                                                                     |
| 4.   Press the left foot switch to apply electricity.                                          |                                                                                     |
| Working with multiple tools and wires                                                          |                                                                                     |
| Note:  The duodenoscope allows for working simultaneously with three tools and wires, inserted |                                                                                     |
|                                                                                                | through three separate working channel openings.                                    |
| 1.                                                                                             | Insert the Master Tool into the white-marked working channel and select from the    |
|                                                                                                | Tools menu (see Working with tools on page 97).                                     |
| 2.   When there is a tool in the white working channel, the red wire, simulating the           |                                                                                     |
|                                                                                                | guide wire, can be inserted into the red-marked working channel.                    |
| Note:  The red wire always simulates the guide wire and need not be selected from a menu.      |                                                                                     |

[OCR]
Chapter 7 Working with Endoscopic Tools

surgical

00:01:07

Figure 7-3: Electrosurgical settings for the Endoscopy and Fluoroscopy display mode

2. Select the desired mode (Cut, Coag or Blend).
3. Adjust the desired electrical power settings by pressing the directional arrows.
4. Press the left foot switch to apply electricity.

Working with multiple tools and wires

Note: The duodenoscope allows for working simultaneously with three tools and wires, inserted
through three separate working channel openings.

1. Insert the Master Tool into the white-marked working channel and select from the
Tools menu (see Working with tools on page 97).

2. When there is a tool in the white working channel, the red wire, simulating the
guide wire, can be inserted into the red-marked working channel.

Note: The red wire always simulates the guide wire and need not be selected from a menu.

The guide wire appears in both the endoscopic and the fluoroscopic views.

surgicalscience Page 99


# Page 111

Chapter 7 
 Working with Endoscopic Tools
 
Page 100
 
 
Figure 7-4: Guide wire  
Note: When inserted into its channel, the guide wire is simulated already at the far end of the 
working channel. Thus, after introducing it, you only need to slightly insert it to have it 
already inside the anatomy. You can press on the About Guide Wire option, at the bottom 
of the Tools menu, to review additional information. 
3.  When the Master Tool is simulating a guiding catheter and the guide wire is 
inserted, insert the blue wire into the blue-marked working channel to simulate 
stent placing. 
A menu providing a list of stents is displayed. 
The blue wire always simulates the pushing catheter and need not be selected 
from the menu. However, the stent type and size needs to be selected upon 
inserting the blue wire. 


[TABLE]
| working channel. Thus, after introducing it, you only need to slightly insert it to have it   |
|:----------------------------------------------------------------------------------------------|
| already inside the anatomy. You can press on the About Guide Wire option, at the bottom       |
| of the Tools menu, to review additional information.                                          |
| 3.   When the Master Tool is simulating a guiding catheter and the guide wire is              |
| inserted, insert the blue wire into the blue-marked working channel to simulate               |
| stent placing.                                                                                |
| A menu providing a list of stents is displayed.                                               |
| The blue wire always simulates the pushing catheter and need not be selected                  |
| from the menu. However, the stent type and size needs to be selected upon                     |
| inserting the blue wire.                                                                      |

[OCR]
Chapter 7 Working with Endoscopic Tools

surgical

00:01:07

Figure 7-4: Guide wire

Note: When inserted into its channel, the guide wire is simulated already at the far end of the
working channel. Thus, after introducing it, you only need to slightly insert it to have it
already inside the anatomy. You can press on the About Guide Wire option, at the bottom
of the Tools menu, to review additional information.

3. When the Master Tool is simulating a guiding catheter and the guide wire is
inserted, insert the blue wire into the blue-marked working channel to simulate
stent placing.

A menu providing a list of stents is displayed.

The blue wire always simulates the pushing catheter and need not be selected
from the menu. However, the stent type and size needs to be selected upon
inserting the blue wire.

surgicalscience Page 100


# Page 112

Chapter 7 
 Working with Endoscopic Tools
 
Page 101
 
 
Figure 7-5: Stent selection menu 
4.  Select the desired type and size of stent. 
The stent is displayed at the tip of the pushing catheter and can be seen in the 
endoscopic view and on the fluoroscopic view. 


[TABLE]
| Chapter 7                                       | Working with Endoscopic Tools                                                    |
|:------------------------------------------------|:---------------------------------------------------------------------------------|
| F                                               |                                                                                  |
| i                                               |                                                                                  |
| gure 7-5: Stent selection menu                  |                                                                                  |
| 4.   Select the desired type and size of stent. |                                                                                  |
|                                                 | The stent is displayed at the tip of the pushing catheter and can be seen in the |
| endoscopic view and on the fluoroscopic view.   |                                                                                  |
|                                                 | Page 101                                                                         |

[OCR]
Chapter 7 Working with Endoscopic Tools

Biliary Stent Pancreatic Stent

French size: 10 Length: 5em

French size: 10 Length: 7em

French size: 10 Length: 9cm

French size: 10 Length: 12cm

Figure 7-5: Stent selection menu

4. Select the desired type and size of stent.

The stent is displayed at the tip of the pushing catheter and can be seen in the
endoscopic view and on the fluoroscopic view.

surgicalscience Page 101


# Page 113

Chapter 7 
 Working with Endoscopic Tools
 
Page 102
 
 
Figure 7-6: Stent displayed in Endoscopic and Fluoroscopic views 
Note: Unlike an actual procedure when inserted into the working channel, the catheter is 
simulated already at the far end of the working channel. Thus, after introducing it, you 
only need to slightly insert it to have it already inside the anatomy.  
 


[TABLE]
| Chapter 7                                                                                 | Working with Endoscopic Tools                                                            |
|:------------------------------------------------------------------------------------------|:-----------------------------------------------------------------------------------------|
| F                                                                                         |                                                                                          |
| i                                                                                         |                                                                                          |
| gure 7-6: Stent displayed in Endoscopic and Fluoroscopic views                            |                                                                                          |
| Note:  Unlike an actual procedure when inserted into the working channel, the catheter is |                                                                                          |
|                                                                                           | simulated already at the far end of the working channel. Thus, after introducing it, you |
| only need to slightly insert it to have it already inside the anatomy.                    |                                                                                          |
|                                                                                           | Page 102                                                                                 |

[OCR]
Chapter 7 Working with Endoscopic Tools

surgical

00:00:39

Figure 7-6: Stent displayed in Endoscopic and Fluoroscopic views

Note: Unlike an actual procedure when inserted into the working channel, the catheter is
simulated already at the far end of the working channel. Thus, after introducing it, you
only need to slightly insert it to have it already inside the anatomy.

surgicalscience Page 102


# Page 114

Chapter 8 
 Viewing Performance Reports
 
Page 103
 
Chapter 8 Viewing Performance Reports 
Overview 
Performance reports are displayed after each simulation case or task, allowing you to 
monitor and track your training progress. 
Note: MentorLearn produces reports for simulation cases only; reports are not produced 
relating to the completion of any didactic material included in a course. 
When you press Finish to end a task or case, your performance report is displayed 
automatically. All of your reports are listed in the MentorLearn Reports screen. 
Viewing reports 
To view performance reports: 
1.  Press Reports on the MentorLearn menu to access the Reports screen. 
 
2.  The entries in the reports table appear in chronological order – the most recently 
performed sessions appear at the top of the list. Each row in the reports table 
represents a single session, meaning that if a user completed a particular 
simulation case three times, three entries (rows) for that case are displayed. 


[TABLE]
| Chapter 8                                                                              | Viewing Performance Reports                                                           |
|:---------------------------------------------------------------------------------------|:--------------------------------------------------------------------------------------|
| Chapter 8 Viewing Performance Reports                                                  |                                                                                       |
| Overview                                                                               |                                                                                       |
|                                                                                        | Performance reports are displayed after each simulation case or task, allowing you to |
| monitor and track your training progress.                                              |                                                                                       |
| Note: MentorLearn produces reports for simulation cases only; reports are not produced |                                                                                       |
| relating to the completion of any didactic material included in a course.              |                                                                                       |
| When you press Finish to end a task or case, your performance report is displayed      |                                                                                       |
| automatically. All of your reports are listed in the MentorLearn Reports screen.       |                                                                                       |
| Viewing reports                                                                        |                                                                                       |
| To view performance reports:                                                           |                                                                                       |
| 1.   Press Reports on the MentorLearn menu to access the Reports screen.               |                                                                                       |

[OCR]
Chapter 8 Viewing Performance Reports

| Chapter 8 Viewing Performance Reports

Overview

Performance reports are displayed after each simulation case or task, allowing you to
monitor and track your training progress.

Note: MentorLearn produces reports for simulation cases only; reports are not produced
relating to the completion of any didactic material included in a course.

When you press Finish to end a task or case, your performance report is displayed
automatically. All of your reports are listed in the MentorLearn Reports screen.

Viewing reports
To view performance reports:
1. Press Reports on the MentorLearn menu to access the Reports screen.

1 Mentr wot
a
a
2 - =
a Fier By Date “
chert master ENR E50

2 © tssiwonth ©. vestvesr
o coer
a 2126/2026 a
a

3/26/2025 5
a
a

Fiterby Module and case 4
a
a ‘client Administrator aa

>

a ot
ao even
ie] Cent acminstater 2
a
a
a
oa ssigents zi is Evauaien = advnced |

2. The entries in the reports table appear in chronological order — the most recently
performed sessions appear at the top of the list. Each row in the reports table
represents a single session, meaning that if a user completed a particular
simulation case three times, three entries (rows) for that case are displayed.

surgicalscience Page 103


# Page 115

Chapter 8 
 Viewing Performance Reports
 
Page 104
 
3.  To display a shorter, more focused list of sessions in the Reports table, use the 
search at the top of the table or define a filter in the right pane. To restore the full, 
unfiltered list of reports, clear the selected checkbox(es). 
4.  To scroll through the list of reports, use the Next and Previous arrows at the 
bottom of the Reports screen.  
5.  To open a single-case report, press its row on the Reports table. 
Note: The single-case report differ for cases/tasks with benchmarks and those without 
benchmarks. 
 
Figure 8-1: Single-case report without benchmarks 


[TABLE]
| Chapter 8                                                                              | Viewing Performance Reports                                                               |
|:---------------------------------------------------------------------------------------|:------------------------------------------------------------------------------------------|
| 3.   To display a shorter, more focused list of sessions in the Reports table, use the |                                                                                           |
|                                                                                        | search at the top of the table or define a filter in the right pane. To restore the full, |
| unfiltered list of reports, clear the selected checkbox(es).                           |                                                                                           |
| 4.   To scroll through the list of reports, use the Next and Previous arrows at the    |                                                                                           |
| bottom of the Reports screen.                                                          |                                                                                           |
| 5.   To open a single-case report, press its row on the Reports table.                 |                                                                                           |
| Note: The single-case report differ for cases/tasks with benchmarks and those without  |                                                                                           |
| benchmarks.                                                                            |                                                                                           |
| F                                                                                      |                                                                                           |
| i                                                                                      |                                                                                           |
| gure 8-1: Single-case report without benchmarks                                        |                                                                                           |
|                                                                                        | Page 104                                                                                  |

[OCR]
Chapter 8 Viewing Performance Reports

3. To display a shorter, more focused list of sessions in the Reports table, use the
search at the top of the table or define a filter in the right pane. To restore the full,
unfiltered list of reports, clear the selected checkbox(es).

4. To scroll through the list of reports, use the Next and Previous arrows at the
bottom of the Reports screen.

5. To open a single-case report, press its row on the Reports table.

Note: The single-case report differ for cases/tasks with benchmarks and those withou

benchmarks.
8
—— , if

General

Navigation and Scope

Procedure and Complications

Figure 8-1: Single-case report without benchmarks

surgicalscience Page 104


# Page 116

Chapter 8 
 Viewing Performance Reports
 
Page 105
 
 
Figure 8-2: Single-case report with benchmarks 
1 
Report Header displays information about the report, 
including the user who performed the case, the name of 
the case performed, and the module that contains the 
performed case. 
The session number is displayed in the report header. 
2 
Scoreboard displays information about your total score 
for the task/case. For more information, see 
Understanding the scoreboard on page 112. 
3 
Video options display options for viewing, downloading 
and deleting the recorded video of your simulation 
performance. For more information, see Viewing 
recorded videos on page 107.  


[TABLE]
| gure 8-2: Single-case report with benchmarks   |                                                        |
|:-----------------------------------------------|:-------------------------------------------------------|
| 1                                              | Report Header displays information about the report,   |
|                                                | including the user who performed the case, the name of |
|                                                | the case performed, and the module that contains the   |
|                                                | performed case.                                        |
|                                                | The session number is displayed in the report header.  |
| 2                                              | Scoreboard displays information about your total score |
|                                                | for the task/case. For more information, see           |
|                                                | Understanding the scoreboard on page 112.              |
| 3                                              | Video options display options for viewing, downloading |
|                                                | and deleting the recorded video of your simulation     |
|                                                | performance. For more information, see Viewing         |
|                                                | recorded videos on page 107.                           |

[OCR]
Chapter 8

Viewing Performance Reports

Cent Administer [ meron |

Case proficiency ton

2 Session 2.Msrs6.2ms2rs2o0 +

Session proficiency

Total time

Failed

uber otbatoon poppe 29

Figure 8-2: Single-case report with benchmarks

1

Report Header displays information about the report,
including the user who performed the case, the name of
the case performed, and the module that contains the
performed case.

The session number is displayed in the report header.
Scoreboard displays information about your total score

for the task/case. For more information, see
Understanding the scoreboard on page 112.

Video options display options for viewing, downloading
and deleting the recorded video of your simulation
performance. For more information, see Viewing
recorded videos on page 107.

surgicalscience Page 105


# Page 117

Chapter 8 
 Viewing Performance Reports
 
Page 106
 
4 
Metric column: the metrics included in the report. The 
available categories and metrics vary between simulators 
and simulation modules and cases. 
If a report has benchmarks, metrics with a defined skill 
level appear in the Benchmark section at the top of the 
list.  
Press the Up arrow at the end of the metric’s row to hide 
the associated metrics; press the Down arrow at the end 
of the metric category’s row to display the metrics. 
5 
Result column: the result of the metrics as recorded 
during the user's performance of a simulation case. Press 
a result to display additional information. For a detailed 
explanation, see Viewing additional information on page 
106. 
6 
Score column: The score as calculated on a normalized 
scale of 1-5. For a detailed explanation, see 
Understanding benchmarks and rating scales on page 
114. 
7 
Learning Curve Graph for a selected metric: a colorful 
graph is displayed on the right side of the Report screen 
if the user has completed two or more sessions of the 
specific simulation case. For a detailed explanation of the 
graph, see Understanding learning curve graphs on page 
115. 
Additional information if available such as a snapshot is 
displayed under the graph. 
8 
Print: press 
 to print the report to print the report. 
 
Viewing additional information 
1.  Press a metric’s result or click Additional Info to display details about the metric 
such as how it is measured or a captured snapshot.  


[TABLE]
| 4   | Metric column: the metrics included in the report. The      |
|:----|:------------------------------------------------------------|
|     | available categories and metrics vary between simulators    |
|     | and simulation modules and cases.                           |
|     | If a report has benchmarks, metrics with a defined skill    |
|     | level appear in the Benchmark section at the top of the     |
|     | list.                                                       |
|     | Press the Up arrow at the end of the metric’s row to hide   |
|     | the associated metrics; press the Down arrow at the end     |
|     | of the metric category’s row to display the metrics.        |
| 5   | Result column: the result of the metrics as recorded        |
|     | during the user's performance of a simulation case. Press   |
|     | a result to display additional information. For a detailed  |
|     | explanation, see Viewing additional information on page     |
|     | 106.                                                        |
| 6   | Score column: The score as calculated on a normalized       |
|     | scale of 1-5. For a detailed explanation, see               |
|     | Understanding benchmarks and rating scales on page          |
|     | 114.                                                        |
| 7   | Learning Curve Graph for a selected metric: a colorful      |
|     | graph is displayed on the right side of the Report screen   |
|     | if the user has completed two or more sessions of the       |
|     | specific simulation case. For a detailed explanation of the |
|     | graph, see Understanding learning curve graphs on page      |
|     | 115.                                                        |
|     | Additional information if available such as a snapshot is   |
|     | displayed under the graph.                                  |
| 8   |                                                             |
|     | Print: press                                                |
|     |  to print the report to print the report.                   |

[OCR]
Chapter 8

Viewing Performance Reports

Metric column: the metrics included in the report. The
available categories and metrics vary between simulators
and simulation modules and cases.

If a report has benchmarks, metrics with a defined skill
level appear in the Benchmark section at the top of the
list.

Press the Up arrow at the end of the metric’s row to hide
the associated metrics; press the Down arrow at the end
of the metric category’s row to display the metrics.

Result column: the result of the metrics as recorded
during the user's performance of a simulation case. Press
a result to display additional information. For a detailed
explanation, see Viewing additional information on page
106.

Score column: The score as calculated on a normalized
scale of 1-5. For a detailed explanation, see
Understanding benchmarks and rating scales on page
114.

Learning Curve Graph for a selected metric: a colorful
graph is displayed on the right side of the Report screen
if the user has completed two or more sessions of the
specific simulation case. For a detailed explanation of the
graph, see Understanding learning curve graphs on page
115.

Additional information if available such as a snapshot is
displayed under the graph.

Print: press & to print the report to print the report.

Viewing additional information

1. Press a metric’s result or click Additional Info to display details about the metric
such as how it is measured or a captured snapshot.

surgicalscience

Page 106


# Page 118

Chapter 8 
 Viewing Performance Reports
 
Page 107
 
 
2.  Double-click the captured snapshot to display it in a separate window. 
 
Figure 8-3: Snapshot viewed from single report 
Viewing recorded videos 
You can view a video of your simulation performance. You can download the video to 
review your performance at a later time or delete the recorded video. 


[TABLE]
| Chapter 8                                                                   | Viewing Performance Reports                                                        |
|:----------------------------------------------------------------------------|:-----------------------------------------------------------------------------------|
| 2.   Double-click the captured snapshot to display it in a separate window. |                                                                                    |
| F                                                                           |                                                                                    |
| i                                                                           |                                                                                    |
| gure 8-3: Snapshot viewed from single report                                |                                                                                    |
| Viewing recorded videos                                                     |                                                                                    |
|                                                                             | You can view a video of your simulation performance. You can download the video to |
| review your performance at a later time or delete the recorded video.       |                                                                                    |
|                                                                             | Page 107                                                                           |

[OCR]
Chapter 8

Viewing Performance Reports

Client Administrator

Video

General

Navigation and Scope

Procedure and Complications

Total numberof iectons pois

2. Double-click the captured snapshot to display it in a separate window.

Figure 8-3: Snapshot viewed from single report

Viewing recorded videos

You can view a video of your simulation performance. You can download the video to

review your performance at a later time or delete the recorded video.

surgicalscience

Page 107


# Page 119

Chapter 8 
 Viewing Performance Reports
 
Page 108
 
To view the performance video: 
1.  In the Video section of the report, press Video.  
The recorded video of your simulation case performance is displayed. 
 
2.  Double-click it to display in a separate window. 


[TABLE]
| Chapter 8                                                            | Viewing Performance Reports   |
|:---------------------------------------------------------------------|:------------------------------|
| To view the performance video:                                       |                               |
| 1.                                                                   |                               |
| In the Video section of the report, press Video.                     |                               |
| The recorded video of your simulation case performance is displayed. |                               |
| 2.   Double-click it to display in a separate window.                |                               |
|                                                                      | Page 108                      |

[OCR]
Chapter 8 Viewing Performance Reports

To view the performance video:
1. In the Video section of the report, press Video.

The recorded video of your simulation case performance is displayed.

Video “

surgical

Benchmarks od

Percentage of mucosal surface examined 22% MM Score: 1.00

2. Double-click it to display in a separate window.

surgicalscience Page 108


# Page 120

Chapter 8 
 Viewing Performance Reports
 
Page 109
 
 
Figure 8-4: Recorded video viewed from single report 
3.  Use the buttons under the video to play, pause, or view in full screen. 
4.  Press outside the video to close it and return to the single report. 
To download the performance video: 
1.  Press 
 in the top left corner of the screen and select Video>Download. 
OR 
Press 
 under the video and select Download Video. 
2.  Browse to select the file location where you want the video to be downloaded. 
3.  Press Save. 
The video is downloaded to the selected location. 
To delete the performance video: 
1.  Press 
 and select Video>Delete.  
The recorded video is deleted. 


[TABLE]
| Chapter 8                                                                    | Viewing Performance Reports                                                        |
|:-----------------------------------------------------------------------------|:-----------------------------------------------------------------------------------|
| F                                                                            | gure 8-4: Recorded video viewed from single report                                 |
| i                                                                            |                                                                                    |
| 3.   Use the buttons under the video to play, pause, or view in full screen. |                                                                                    |
| 4.   Press outside the video to close it and return to the single report.    |                                                                                    |
| To download the performance video:                                           |                                                                                    |
| 1.   Press                                                                   | in the top left corner of the screen and select Video>Download.                    |
| OR                                                                           |                                                                                    |
| Press                                                                        | under the video and select Download Video.                                         |
|                                                                              | 2.   Browse to select the file location where you want the video to be downloaded. |
| 3.   Press Save.                                                             |                                                                                    |
| The video is downloaded to the selected location.                            |                                                                                    |
| To delete the performance video:                                             |                                                                                    |
| 1.   Press                                                                   | and select Video>Delete.                                                           |
| The recorded video is deleted.                                               |                                                                                    |
|                                                                              | Page 109                                                                           |

[OCR]
Chapter 8 Viewing Performance Reports

surgical

> has / 148

Figure 8-4: Recorded video viewed from single report

3. Use the buttons under the video to play, pause, or view in full screen.
4. Press outside the video to close it and return to the single report.

To download the performance video:

1. Press ie in the top left corner of the screen and select Video>Download.
OR

Press | | under the video and select Download Video.

2. Browse to select the file location where you want the video to be downloaded.
3. Press Save.

The video is downloaded to the selected location.

To delete the performance video:

1. Press el and select Video>Delete.

The recorded video is deleted.

surgicalscience Page 109


# Page 121

Chapter 8 
 Viewing Performance Reports
 
Page 110
 
Note: A message will appear when there is no more storage space for the recorded videos on 
your local drive. It is recommended to download those videos you wish to save to another 
drive on the computer or to an external drive (e.g. flash drive, or external hard disk) and 
then delete them.  
Browsing between sessions 
MentorLearn allows you to browse between the sessions performed of the same case 
within a certain course/module. Therefore, if a learner performed a case independently 
3 times for a module listed in the Library and then performed the same case an 
additional two times within the framework of a course, these sessions will not be linked 
together. The learner would need to browse separately between the sessions 
performed in the module and sessions performed within the framework of the course. 
In a single report, click the arrow by the session’s date to display a drop-down list of 
report sessions. Select the report session you want to view. 
 
 
 
Additional report types 
Viewing user saved snapshots 
You can view saved snapshots and your comments relating to snapshots. 
1.  Press the underlined blue value in the result column of the Trainee Report and 
Snapshots. 


[TABLE]
| Chapter 8                                                                                   | Viewing Performance Reports                                                                 |
|:--------------------------------------------------------------------------------------------|:--------------------------------------------------------------------------------------------|
| Note:  A message will appear when there is no more storage space for the recorded videos on |                                                                                             |
|                                                                                             | your local drive. It is recommended to download those videos you wish to save to another    |
|                                                                                             | drive on the computer or to an external drive (e.g. flash drive, or external hard disk) and |
| then delete them.                                                                           |                                                                                             |
| Browsing between sessions                                                                   |                                                                                             |
|                                                                                             | MentorLearn allows you to browse between the sessions performed of the same case            |
|                                                                                             | within a certain course/module. Therefore, if a learner performed a case independently      |
| 3 times for a module listed in the Library and then performed the same case an              |                                                                                             |
|                                                                                             | additional two times within the framework of a course, these sessions will not be linked    |
| together. The learner would need to browse separately between the sessions                  |                                                                                             |
|                                                                                             | performed in the module and sessions performed within the framework of the course.          |
| In a single report, click the arrow by the session’s date to display a drop-down list of    |                                                                                             |
| report sessions. Select the report session you want to view.                                |                                                                                             |
| A                                                                                           |                                                                                             |
| dditional report types                                                                      |                                                                                             |
| Viewing user saved snapshots                                                                |                                                                                             |
| You can view saved snapshots and your comments relating to snapshots.                       |                                                                                             |
| 1.   Press the underlined blue value in the result column of the Trainee Report and         |                                                                                             |
| Snapshots.                                                                                  |                                                                                             |
|                                                                                             | Page 110                                                                                    |

[OCR_TABLE]
Vitaytrel &

[OCR]
Chapter 8 Viewing Performance Reports

Note: A message will appear when there is no more storage space for the recorded videos on
your local drive. It is recommended to download those videos you wish to save to another
drive on the computer or to an external drive (e.g. flash drive, or external hard disk) and
then delete them.

Browsing between sessions

MentorLearn allows you to browse between the sessions performed of the same case
within a certain course/module. Therefore, if a learner performed a case independently
3 times for a module listed in the Library and then performed the same case an
additional two times within the framework of a course, these sessions will not be linked
together. The learner would need to browse separately between the sessions
performed in the module and sessions performed within the framework of the course.

In a single report, click the arrow by the session’s date to display a drop-down list of
report sessions. Select the report session you want to view.

Session 2-Mar 26, 2025, 3:09:30 PM [-]
Session proficiency Client Administrator
EMR / ESD
@ fe) Case 2 - EMR in Lower GI
Yes 100% ;
Proficient ren Session 1 -Mar 24, 2025, 12:02:26 PM

Additional report types

Viewing user saved snapshots

You can view saved snapshots and your comments relating to snapshots.

1. Press the underlined blue value in the result column of the Trainee Report and
Snapshots.

surgicalscience Page 110


# Page 122

Chapter 8 
 Viewing Performance Reports
 
Page 111
 
2.  If upon completing a case and saving its performance, you entered and saved 
comments relating to snapshots you took, you can later view them and decide 
whether to delete any of these snapshots. No editing of the text is possible at this 
stage. 
 
3.  Use the arrows to browse through the snapshots. 
4.  Press Delete Snapshot to delete those snapshots you do not want. 
5.  Press Close. 
Viewing performance playback 
You can view a recording of your complete performance of the procedure. 
Note: Playback can be reviewed only on the simulator station on which it was performed.  


[TABLE]
| Chapter 8                                                                                |
|  Viewing Performance Reports                                                             |
|:-----------------------------------------------------------------------------------------|
| 2.                                                                                       |
| If upon completing a case and saving its performance, you entered and saved              |
| comments relating to snapshots you took, you can later view them and decide              |
| whether to delete any of these snapshots. No editing of the text is possible at this     |
| stage.                                                                                   |
| 3.   Use the arrows to browse through the snapshots.                                     |
| 4.   Press Delete Snapshot to delete those snapshots you do not want.                    |
| 5.   Press Close.                                                                        |
| Viewing performance playback                                                             |
| You can view a recording of your complete performance of the procedure.                  |
| Note:  Playback can be reviewed only on the simulator station on which it was performed. |
| Page 111                                                                                 |

[OCR]
Chapter 8 Viewing Performance Reports

2. If upon completing a case and saving its performance, you entered and saved
comments relating to snapshots you took, you can later view them and decide
whether to delete any of these snapshots. No editing of the text is possible at this
stage.

Lower GI Endoscopy | Trainee Report

3. Use the arrows to browse through the snapshots.
4. Press Delete Snapshot to delete those snapshots you do not want.
5. Press Close.

Viewing performance playback

You can view a recording of your complete performance of the procedure.

Note: Playback can be reviewed only on the simulator station on which it was performed.

surgicalscience Page 111


# Page 123

Chapter 8 
 Viewing Performance Reports
 
Page 112
 
1.  Press the underlined blue PLAY in the result column of the Playback of performed 
procedure.  
The performance procedure playback begins playing. 
 
Figure 8-5: Playback screen 
2.  The following actions are available in the Playback screen: 
• 
To pause the recording, press the Pause 
 button. 
• 
To play the recording, press the Play 
 button.  
• 
To play the recording from the beginning, press the Back 
 button. 
3.  Press Close to return to the single-case report. 
Understanding the scoreboard 
The benchmark scoreboard displays a summary of your performance in a clear and 
colorful way.  


[TABLE]
| Chapter 8     |                                                                                       | Viewing Performance Reports   |          |
|:--------------|:--------------------------------------------------------------------------------------|:------------------------------|:---------|
|               | 1.   Press the underlined blue PLAY in the result column of the Playback of performed |                               |          |
|               | procedure.                                                                            |                               |          |
|               | The performance procedure playback begins playing.                                    |                               |          |
|               | F                                                                                     |                               |          |
|               | i                                                                                     |                               |          |
|               | gure 8-5: Playback screen                                                             |                               |          |
|               | 2.   The following actions are available in the Playback screen:                      |                               |          |
| •             | To pause the recording, press the Pause                                               |                               |          |
|               |  button.                                                                              |                               |          |
| •             | To play the recording, press the Play                                                 |                               |          |
|               |  button.                                                                              |                               |          |
| •             | To play the recording from the beginning, press the Back                              | button.                       |          |
|               | 3.   Press Close to return to the single-case report.                                 |                               |          |
|               | Understanding the scoreboard                                                          |                               |          |
|               | The benchmark scoreboard displays a summary of your performance in a clear and        |                               |          |
| colorful way. |                                                                                       |                               |          |
|               |                                                                                       |                               | Page 112 |

[OCR]
Chapter 8 Viewing Performance Reports

1. Press the underlined blue PLAY in the result column of the Playback of performed
procedure.

The performance procedure playback begins playing.

Figure 8-5: Playback screen

2. The following actions are available in the Playback screen:

To pause the recording, press the Pause Go button.

To play the recording, press the Play (<3) button.
To play the recording from the beginning, press the Back button.

3. Press Close to return to the single-case report.

Understanding the scoreboard

The benchmark scoreboard displays a summary of your performance in a clear and
colorful way.

surgicalscience Page 112


# Page 124

Chapter 8 
 Viewing Performance Reports
 
Page 113
 
a
 
Figure 8-6: Case benchmark scoreboard 
It includes the following components: 
• 
Proficient: shows if you reached the required skill level or not for the simulation 
case.  
• 
Best Score: is calculated as a weighted average of the scores for each of the 
benchmark metrics. In the above report, 86% = the average score of the metrics 
for the case/task (e.g. total time, total path, accuracy rate, horizontal view). The 
best score is displayed in a percentage.  
o 
The default is that the benchmarks have the same weights. However, the 
best score can be customized so that certain metrics have more weight 
than others. 
o 
Some metrics may be set as critical (must pass) and if you don’t pass the 
metric, you receive a total score of “Failed”. For example, if a case/task 
must be performed with no complications and 2 complications occurred, 
your total score would be “Failed”:  
• 
Non-consecutive: indicates how many times you need to attain the required skill 
level to achieve proficiency. For example, if you are required to achieve the skill 
level once and you accomplished it, your score would be Non-consecutive: 1 of 
1. 
• 
Consecutive: indicates how many consecutive times you are required to attain a 
skill level. For example, if you are required to achieve the skill level in two 
consecutive times and you succeeded the first time, the result would show 
Consecutive: 1 of 2. If you succeed in the next attempt, the score will show 
Consecutive: 2 of 2. If you failed at the second attempt, you would have to start 
again since the requirement is for 2 consecutive successful attempts. 
• 
Attempts: how many attempts/sessions/repetitions of this case you performed. 
 


[TABLE]
| a                                     |                                                                                      |
|:--------------------------------------|:-------------------------------------------------------------------------------------|
| F                                     |                                                                                      |
| i                                     |                                                                                      |
| gure 8-6: Case benchmark scoreboard   |                                                                                      |
| It includes the following components: |                                                                                      |
| •                                     | Proficient: shows if you reached the required skill level or not for the simulation  |
|                                       | case.                                                                                |
| •                                     | Best Score: is calculated as a weighted average of the scores for each of the        |
|                                       | benchmark metrics. In the above report, 86% = the average score of the metrics       |
|                                       | for the case/task (e.g. total time, total path, accuracy rate, horizontal view). The |
|                                       | best score is displayed in a percentage.                                             |

[TABLE]
| Best Score: is calculated as a weighted average of the scores for each of the        |
|:-------------------------------------------------------------------------------------|
| benchmark metrics. In the above report, 86% = the average score of the metrics       |
| for the case/task (e.g. total time, total path, accuracy rate, horizontal view). The |
| best score is displayed in a percentage.                                             |
| The default is that the benchmarks have the same weights. However, the               |
| o                                                                                    |
| best score can be customized so that certain metrics have more weight                |
| than others.                                                                         |
| Some metrics may be set as critical (must pass) and if you don’t pass the            |
| o                                                                                    |
| metric, you receive a total score of “Failed”. For example, if a case/task           |
| must be performed with no complications and 2 complications occurred,                |
| your total score would be “Failed”:                                                  |
| Non-consecutive: indicates how many times you need to attain the required skill      |

[OCR_TABLE]
Case pr

[OCR]
Chapter 8 Viewing Performance Reports

a

Case proficiency Proficiency established by: TASSL

@ oO @ @ ise

Yes 100% 1 of 1 1 of 1 3

Proficient Best Score: Non consecutive: Consecutive: Attempts:

Figure 8-6: Case benchmark scoreboard

It includes the following components:

Proficient: shows if you reached the required skill level or not for the simulation
case.

Best Score: is calculated as a weighted average of the scores for each of the
benchmark metrics. In the above report, 86% = the average score of the metrics
for the case/task (e.g. total time, total path, accuracy rate, horizontal view). The
best score is displayed in a percentage.

° The default is that the benchmarks have the same weights. However, the
best score can be customized so that certain metrics have more weight
than others.

° Some metrics may be set as critical (must pass) and if you don’t pass the
metric, you receive a total score of “Failed”. For example, if a case/task
must be performed with no complications and 2 complications occurred,
your total score would be “Failed”:

Non-consecutive: indicates how many times you need to attain the required skill
level to achieve proficiency. For example, if you are required to achieve the skill
level once and you accomplished it, your score would be Non-consecutive: 1 of
1.

Consecutive: indicates how many consecutive times you are required to attain a
skill level. For example, if you are required to achieve the skill level in two
consecutive times and you succeeded the first time, the result would show
Consecutive: 1 of 2. If you succeed in the next attempt, the score will show
Consecutive: 2 of 2. If you failed at the second attempt, you would have to start
again since the requirement is for 2 consecutive successful attempts.

Attempts: how many attempts/sessions/repetitions of this case you performed.

surgicalscience Page 113


# Page 125

Chapter 8 
 Viewing Performance Reports
 
Page 114
 
The session components are displayed below the case/task components: 
 
Figure 8-7: Session benchmark scoreboard 
Proficient: shows if you reached the required skill level or not for this session of the 
case/task.  
Score: is calculated as a weighted average of the scores for each of the benchmark 
metrics for this session. In the above report, 86% = the average score of the metrics 
for the session (e.g. total time, total path, accuracy rate, horizontal view). The score is 
displayed in a percentage.  
Understanding benchmarks and rating scales 
Metrics with a defined skill level appear in the Benchmark section. Each metric is 
displayed on a rating scale showing at a quick glance if you have passed or failed the 
required level for this metric.  
 
Figure 8-8: Benchmark rating scale 
The rating scale includes the following components: 


[TABLE]
| Chapter 8                                                                                   | Viewing Performance Reports   |
|:--------------------------------------------------------------------------------------------|:------------------------------|
| The session components are displayed below the case/task components:                        |                               |
| F                                                                                           |                               |
| i                                                                                           |                               |
| gure 8-7: Session benchmark scoreboard                                                      |                               |
| Proficient: shows if you reached the required skill level or not for this session of the    |                               |
| case/task.                                                                                  |                               |
| Score: is calculated as a weighted average of the scores for each of the benchmark          |                               |
| metrics for this session. In the above report, 86% = the average score of the metrics       |                               |
| for the session (e.g. total time, total path, accuracy rate, horizontal view). The score is |                               |
| displayed in a percentage.                                                                  |                               |
| Understanding benchmarks and rating scales                                                  |                               |
| Metrics with a defined skill level appear in the Benchmark section. Each metric is          |                               |
| displayed on a rating scale showing at a quick glance if you have passed or failed the      |                               |
| required level for this metric.                                                             |                               |
| F                                                                                           |                               |
| i                                                                                           |                               |
| gure 8-8: Benchmark rating scale                                                            |                               |
| The rating scale includes the following components:                                         |                               |
|                                                                                             | Page 114                      |

[OCR_TABLE]
Tha caccin

[OCR]
Chapter 8 Viewing Performance Reports

The session components are displayed below the case/task components:

Session proficiency

@ O

Yes 100%

Proficient: Score:

Figure 8-7: Session benchmark scoreboard

Proficient: shows if you reached the required skill level or not for this session of the
case/task.

Score: is calculated as a weighted average of the scores for each of the benchmark
metrics for this session. In the above report, 86% = the average score of the metrics
for the session (e.g. total time, total path, accuracy rate, horizontal view). The score is
displayed in a percentage.

Understanding benchmarks and rating scales

Metrics with a defined skill level appear in the Benchmark section. Each metric is
displayed on a rating scale showing at a quick glance if you have passed or failed the
required level for this metric.

Benchmarks *

Total time 00:02:40 WM Score: 2.42

Number of wall hits 2 MM Score: 4.00 [/)
ry

Number of balloons popped out of 20 12 MH score: 2.38

Figure 8-8: Benchmark rating scale

The rating scale includes the following components:

surgicalscience Page 114


# Page 126

Chapter 8 
 Viewing Performance Reports
 
Page 115
 
• 
Proficiency (where the score = exactly 4) is exactly the value for which the area 
turns from gray to green. If your result is exactly or better than the proficiency 
value, your score falls in the green area. 
 
• 
If you are not proficient, your score is in the gray area: 
 
• 
Scores are calculated on a normalized scale of 1-5: 
o 
<2 = poor 
o 
2.0 - <4.0 = average 
o 
4.0 - <4.5 = expert (score = 4 exactly when you reach proficiency) 
o 
> 4.5 = superior 
• 
Press the rating scale; additional information is displayed in the right pane. 
Understanding learning curve graphs 
If you have completed two or more sessions of the specific simulation case, the graph 
shows the learning curve for the selected metric.  
Note: If benchmarks are defined, the graph is colored using the same color scheme as the 
rating scale. 
The y axis charts the results for the selected metric and the x axis charts the 
repetitions or attempts of this case. 
When benchmarks are defined, you can see your progress in attaining proficiency for 
the specific metric.  
Press a metric in order to display its graph. 
 
If the curve is the gray area, you haven’t achieved proficiency for this metric.  


[TABLE]
| Chapter 8                                                                          |
|  Viewing Performance Reports                                                       |
|:-----------------------------------------------------------------------------------|
| Proficiency (where the score = exactly 4) is exactly the value for which the area  |
| •                                                                                  |
| turns from gray to green. If your result is exactly or better than the proficiency |
| value, your score falls in the green area.                                         |
| If you are not proficient, your score is in the gray area:                         |
| •                                                                                  |
| Scores are calculated on a normalized scale of 1-5:                                |
| •                                                                                  |

[TABLE]
|                                                                                          | 4.0 - <4.5 = expert (score = 4 exactly when you reach proficiency)             |
|:-----------------------------------------------------------------------------------------|:-------------------------------------------------------------------------------|
|                                                                                          | o                                                                              |
|                                                                                          | > 4.5 = superior                                                               |
|                                                                                          | o                                                                              |
| •                                                                                        | Press the rating scale; additional information is displayed in the right pane. |
| Understanding learning curve graphs                                                      |                                                                                |
| If you have completed two or more sessions of the specific simulation case, the graph    |                                                                                |
| shows the learning curve for the selected metric.                                        |                                                                                |
| Note: If benchmarks are defined, the graph is colored using the same color scheme as the |                                                                                |
|                                                                                          | rating scale.                                                                  |
| The y axis charts the results for the selected metric and the x axis charts the          |                                                                                |
| repetitions or attempts of this case.                                                    |                                                                                |
| When benchmarks are defined, you can see your progress in attaining proficiency for      |                                                                                |
| the specific metric.                                                                     |                                                                                |
| Press a metric in order to display its graph.                                            |                                                                                |
| If the curve is the gray area, you haven’t achieved proficiency for this metric.         |                                                                                |

[OCR]
Chapter 8 Viewing Performance Reports

° Proficiency (where the score = exactly 4) is exactly the value for which the area
turns from gray to green. If your result is exactly or better than the proficiency
94% |
value, your score falls in the green area. a
. If you are not proficient, your score is in the gray area:
00:02:40 a
ry
. Scores are calculated on a normalized scale of 1-5:
° <2 = poor
° 2.0 - <4.0 = average
° 4.0 - <4.5 = expert (score = 4 exactly when you reach proficiency)
° > 4.5 = superior

. Press the rating scale; additional information is displayed in the right pane.

Understanding learning curve graphs

If you have completed two or more sessions of the specific simulation case, the graph
shows the learning curve for the selected metric.

Note: If benchmarks are defined, the graph is colored using the same color scheme as the
rating scale.

The y axis charts the results for the selected metric and the x axis charts the
repetitions or attempts of this case.

When benchmarks are defined, you can see your progress in attaining proficiency for
the specific metric.

Press a metric in order to display its graph.

Total time 00:00:51 MH Score: 5.00 @
a

If the curve is the gray area, you haven't achieved proficiency for this metric.

surgicalscience Page 115


# Page 127

Chapter 8 
 Viewing Performance Reports
 
Page 116
 
If the curve is in the green area, you are proficient in this metric. 
 
Figure 8-9: Report's learning curve 
Exporting performance results 
Performance results can be exported to a file. The data is saved as CSV (comma 
separated values) file, which can be viewed using Microsoft® Excel®. 
Note: Only client administrators, course directors and proctors can export performance results.  
To export data: 
1.  Press Reports on the MentorLearn menu to access the Reports screen. 
2.  Select the reports you want to export. 
3.  Press 
  and select Reports>Export Performance.  


[TABLE]
| Chapter 8                                   |                                                                                                 | Viewing Performance Reports   |
|:--------------------------------------------|:------------------------------------------------------------------------------------------------|:------------------------------|
|                                             | If the curve is in the green area, you are proficient in this metric.                           |                               |
| F                                           | gure 8-9: Report's learning curve                                                               |                               |
| i                                           |                                                                                                 |                               |
| Exporting performance results               |                                                                                                 |                               |
|                                             | Performance results can be exported to a file. The data is saved as CSV (comma                  |                               |
|                                             | separated values) file, which can be viewed using Microsoft® Excel®.                            |                               |
|                                             | Note: Only client administrators, course directors and proctors can export performance results. |                               |
| To export data:                             |                                                                                                 |                               |
|                                             | 1.   Press Reports on the MentorLearn menu to access the Reports screen.                        |                               |
| 2.   Select the reports you want to export. |                                                                                                 |                               |
| 3.   Press                                  | and select Reports>Export Performance.                                                          |                               |
|                                             |                                                                                                 | Page 116                      |

[OCR]
Chapter 8 Viewing Performance Reports

If the curve is in the green area, you are proficient in this metric.

Total time

From Mar 24, 2025, 9:50:26 AM To Mar 26, 2025, 3:15:06
PM (3 Sessions)

234
200

150

100

0
*Only the sessions in which the event occurred are

displayed

Figure 8-9: Report's learning curve

Exporting performance results

Performance results can be exported to a file. The data is saved as CSV (comma
separated values) file, which can be viewed using Microsoft® Excel®.

Note: Only client administrators, course directors and proctors can export performance results.

To export data:
1. Press Reports on the MentorLearn menu to access the Reports screen.
2. Select the reports you want to export.

3. Press ie and select Reports>Export Performance.

surgicalscience Page 116


# Page 128

Chapter 8 
 Viewing Performance Reports
 
Page 117
 
 
Figure 8-10: Export Performance window 
4.  In the Export Performance window, define the format of the report as well as the 
time period that should be included in the exported file and press Export. 
5.  Select a location where MentorLearn will save the exported file, and then press 
Save. 
MentorLearn generates the performance data and saves the exported file in the 
specified location. 


[TABLE]
|                                                                                      | F                                                                                |
|                                                                                      | i                                                                                |
|                                                                                      | gure 8-10: Export Performance window                                             |
|:-------------------------------------------------------------------------------------|:---------------------------------------------------------------------------------|
| 4.                                                                                   | In the Export Performance window, define the format of the report as well as the |
|                                                                                      | time period that should be included in the exported file and press Export.       |
| 5.   Select a location where MentorLearn will save the exported file, and then press |                                                                                  |
|                                                                                      | Save.                                                                            |
|                                                                                      | MentorLearn generates the performance data and saves the exported file in the    |
|                                                                                      | specified location.                                                              |

[OCR]
Chapter 8 Viewing Performance Reports

Export Performance x

C Export time in seconds

12/24/2020 a

1/24/2021 a

CANCEL EXPORT

Figure 8-10: Export Performance window

4. In the Export Performance window, define the format of the report as well as the
time period that should be included in the exported file and press Export.

5. Select a location where MentorLearn will save the exported file, and then press
Save.

MentorLearn generates the performance data and saves the exported file in the
specified location.

surgicalscience Page 117


# Page 129

Chapter 9 
 Technical Support
 
Page 118
 
Chapter 9 Technical Support 
SURGICAL SCIENCE SUPPORT POLICY 
Surgical Science assigns the highest priority to customer support. We are committed 
to doing our utmost to provide our clients with reliable support and assistance 24 
hours a day, 7 days a week. This support is available in real time via telephone or 
email. 
Surgical Science Call Center 
Customer service 24/7: +1-216-270-2020 
email: support@surgicalscience.com 
 
 
 
 
 
 


[TABLE]
| Chapter 9                                                                           | Technical Support   |
|:------------------------------------------------------------------------------------|:--------------------|
| Chapter 9 Technical Support                                                         |                     |
| SURGICAL SCIENCE SUPPORT POLICY                                                     |                     |
| Surgical Science assigns the highest priority to customer support. We are committed |                     |
| to doing our utmost to provide our clients with reliable support and assistance 24  |                     |
| hours a day, 7 days a week. This support is available in real time via telephone or |                     |
| email.                                                                              |                     |
| Surgical Science Call Center                                                        |                     |
| Customer service 24/7: +1-216-270-2020                                              |                     |
| email: support@surgicalscience.com                                                  |                     |

[OCR_TABLE]
Chapter 9

[OCR]
Chapter 9 Technical Support

| Chapter 9 Technical Support
SURGICAL SCIENCE SUPPORT POLICY

Surgical Science assigns the highest priority to customer support. We are committed
to doing our utmost to provide our clients with reliable support and assistance 24
hours a day, 7 days a week. This support is available in real time via telephone or
email.

Surgical Science Call Center

Customer service 24/7: +1-216-270-2020

email: support@surgicalscience.com

surgicalscience Page 118


# Page 130

Chapter 10 
 End-User Software License Agreement
 
Page 119
 
Chapter 10 End-User Software License 
Agreement 
GI Mentor® 
1.  DEFINITIONS 
This End-User License Agreement ("Agreement") is a legal agreement between you 
(either an individual or a single entity) and Surgical Science Sweden AB ("Surgical 
Science") for GI Mentor® or such upgrade or future versions thereof identified in the 
Particulars or the License Key Issue Note, which includes computer software and may 
include associated media, printed materials, and electronic documentation 
("Software"). 
 
11.  GRANT 
Surgical Science hereby grants to you a non-exclusive, non-transferable license to 
install and use one copy of the Software, or any prior version for the same operating 
system in accordance with the applicable license type (the type of license in your case 
can be found in the order form / invoice as well as in the License Key Issue Note from 
Surgical Science). The License hereby granted is subject to the following conditions. 
 
111.  CONDITIONS 
1  EXTENT OF LICENSE 
1.1  If you have acquired a hardware identity-based license you may install and use one 
copy of the Software, or any prior version for the same operating system on the single 
computer for which the License Key is issued. 


[TABLE]
| Chapter 10           |                                                                                         | End-User Software License Agreement   |
|:---------------------|:----------------------------------------------------------------------------------------|:--------------------------------------|
|                      | Chapter 10 End-User Software License                                                    |                                       |
|                      | Agreement                                                                               |                                       |
| GI Mentor®           |                                                                                         |                                       |
| 1.  DEFINITIONS      |                                                                                         |                                       |
|                      | This End-User License Agreement ("Agreement") is a legal agreement between you          |                                       |
|                      | (either an individual or a single entity) and Surgical Science Sweden AB ("Surgical     |                                       |
|                      | Science") for GI Mentor® or such upgrade or future versions thereof identified in the   |                                       |
|                      | Particulars or the License Key Issue Note, which includes computer software and may     |                                       |
|                      | include associated media, printed materials, and electronic documentation               |                                       |
| ("Software").        |                                                                                         |                                       |
| 1                    |                                                                                         |                                       |
| 1.  GRANT            |                                                                                         |                                       |
|                      | Surgical Science hereby grants to you a non-exclusive, non-transferable license to      |                                       |
|                      | install and use one copy of the Software, or any prior version for the same operating   |                                       |
|                      | system in accordance with the applicable license type (the type of license in your case |                                       |
|                      | can be found in the order form / invoice as well as in the License Key Issue Note from  |                                       |
|                      | Surgical Science). The License hereby granted is subject to the following conditions.   |                                       |
| 1                    |                                                                                         |                                       |
| 11.  CONDITIONS      |                                                                                         |                                       |
| 1  EXTENT OF LICENSE |                                                                                         |                                       |
|                      | 1.1  If you have acquired a hardware identity-based license you may install and use one |                                       |
|                      | copy of the Software, or any prior version for the same operating system on the single  |                                       |
|                      | computer for which the License Key is issued.                                           |                                       |
|                      |                                                                                         | Page 119                              |

[OCR]
Chapter 10 End-User Software License Agreement

Chapter 10 End-User Software License
Agreement

GI Mentor®

1. DEFINITIONS

This End-User License Agreement ("Agreement") is a legal agreement between you
(either an individual or a single entity) and Surgical Science Sweden AB ("Surgical
Science") for GI Mentor® or such upgrade or future versions thereof identified in the
Particulars or the License Key Issue Note, which includes computer software and may
include associated media, printed materials, and electronic documentation
("Software").

11. GRANT

Surgical Science hereby grants to you a non-exclusive, non-transferable license to
install and use one copy of the Software, or any prior version for the same operating
system in accordance with the applicable license type (the type of license in your case
can be found in the order form / invoice as well as in the License Key Issue Note from
Surgical Science). The License hereby granted is subject to the following conditions.

111. CONDITIONS
1 EXTENT OF LICENSE

1.1 If you have acquired a hardware identity-based license you may install and use one
copy of the Software, or any prior version for the same operating system on the single
computer for which the License Key is issued.

surgicalscience Page 119


# Page 131

Chapter 10 
 End-User Software License Agreement
 
Page 120
 
1.2  If you have acquired a hardware key ("dongle") based node locked license you 
may install and use one copy of the Software, or any prior version for the same 
operating system on the single computer to which the Hardware Key, for which the 
License Key is issued, is attached. Note that you are not obligated to remove the 
installed Software from the computer even if the Hardware Key is removed. However, 
you are not entitled to use the Software on that computer unless the Hardware key is 
reattached. 
1.3  If you have acquired a floating license, you may install one copy of the Software or 
any prior version for the same operating system on any number of computers and 
simultaneously use no more than the number of Software permitted in the License Key 
Issue Note. The rights of installation and use of Software is restricted to the site 
defined in the License Key Issue Note. 
1.4  If the Software is labeled as an upgrade, you must be properly licensed to use a 
product identified by Surgical Science as being eligible for the upgrade in order to use 
the Software. Software labeled as an upgrade replaces and/or supplements the 
product that formed the basis for your eligibility for the upgrade. You may use the 
resulting upgraded product only in accordance with the terms of this Agreement. 
1.5  If the Software is labeled as an upgrade, you must be properly licensed to use a 
product identified by Surgical Science as being eligible for the upgrade in order to use 
the Software. Software labeled as an upgrade replaces and/or supplements the 
product that formed the basis for your eligibility for the upgrade. You may use the 
resulting upgraded product only in accordance with the terms of this Agreement. 
1.6  This license is personal to you and you shall not assign or transfer any interest in it 
or grant any right under it to any third party or seek to exercise this license for the 
benefit or on the data of any third party. 
2  CONFIDENCE OF THE SOFTWARE AND COPYRIGHT 
2.1  The Software, all associated documentation, and all copies are secret and 
confidential to Surgical Science and shall be retained under the effective control of you 
during the period of this Agreement. Disclosures shall be limited to those members of 
your staff (including temporary staff) who need access to the Software to enable you 
to exercise this license. You shall take all measures necessary to maintain confidence 
and secrecy in the Software during the period of this license and after its termination, 
however such termination may arise. 


[TABLE]
| Chapter 10                                                                              | End-User Software License Agreement                                                          |
|:----------------------------------------------------------------------------------------|:---------------------------------------------------------------------------------------------|
| 1.2  If you have acquired a hardware key ("dongle") based node locked license you       |                                                                                              |
| may install and use one copy of the Software, or any prior version for the same         |                                                                                              |
| operating system on the single computer to which the Hardware Key, for which the        |                                                                                              |
| License Key is issued, is attached. Note that you are not obligated to remove the       |                                                                                              |
|                                                                                         | installed Software from the computer even if the Hardware Key is removed. However,           |
|                                                                                         | you are not entitled to use the Software on that computer unless the Hardware key is         |
| reattached.                                                                             |                                                                                              |
|                                                                                         | 1.3  If you have acquired a floating license, you may install one copy of the Software or    |
| any prior version for the same operating system on any number of computers and          |                                                                                              |
|                                                                                         | simultaneously use no more than the number of Software permitted in the License Key          |
| Issue Note. The rights of installation and use of Software is restricted to the site    |                                                                                              |
| defined in the License Key Issue Note.                                                  |                                                                                              |
| 1.4  If the Software is labeled as an upgrade, you must be properly licensed to use a   |                                                                                              |
|                                                                                         | product identified by Surgical Science as being eligible for the upgrade in order to use     |
| the Software. Software labeled as an upgrade replaces and/or supplements the            |                                                                                              |
| product that formed the basis for your eligibility for the upgrade. You may use the     |                                                                                              |
| resulting upgraded product only in accordance with the terms of this Agreement.         |                                                                                              |
| 1.5  If the Software is labeled as an upgrade, you must be properly licensed to use a   |                                                                                              |
|                                                                                         | product identified by Surgical Science as being eligible for the upgrade in order to use     |
| the Software. Software labeled as an upgrade replaces and/or supplements the            |                                                                                              |
| product that formed the basis for your eligibility for the upgrade. You may use the     |                                                                                              |
| resulting upgraded product only in accordance with the terms of this Agreement.         |                                                                                              |
|                                                                                         | 1.6  This license is personal to you and you shall not assign or transfer any interest in it |
| or grant any right under it to any third party or seek to exercise this license for the |                                                                                              |
| benefit or on the data of any third party.                                              |                                                                                              |
| 2  CONFIDENCE OF THE SOFTWARE AND COPYRIGHT                                             |                                                                                              |
| 2.1  The Software, all associated documentation, and all copies are secret and          |                                                                                              |
|                                                                                         | confidential to Surgical Science and shall be retained under the effective control of you    |
|                                                                                         | during the period of this Agreement. Disclosures shall be limited to those members of        |
|                                                                                         | your staff (including temporary staff) who need access to the Software to enable you         |
|                                                                                         | to exercise this license. You shall take all measures necessary to maintain confidence       |
|                                                                                         | and secrecy in the Software during the period of this license and after its termination,     |
| however such termination may arise.                                                     |                                                                                              |

[OCR_TABLE]
Chapter 10

[OCR_TABLE]
1.2 If you |

[OCR_TABLE]
License Ke
inetallad Cc

[OCR]
Chapter 10 End-User Software License Agreement

1.2 If you have acquired a hardware key ("dongle") based node locked license you
may install and use one copy of the Software, or any prior version for the same
operating system on the single computer to which the Hardware Key, for which the
License Key is issued, is attached. Note that you are not obligated to remove the
installed Software from the computer even if the Hardware Key is removed. However,
you are not entitled to use the Software on that computer unless the Hardware key is
reattached.

1.3 If you have acquired a floating license, you may install one copy of the Software or
any prior version for the same operating system on any number of computers and
simultaneously use no more than the number of Software permitted in the License Key
Issue Note. The rights of installation and use of Software is restricted to the site
defined in the License Key Issue Note.

1.4 If the Software is labeled as an upgrade, you must be properly licensed to use a
product identified by Surgical Science as being eligible for the upgrade in order to use
the Software. Software labeled as an upgrade replaces and/or supplements the
product that formed the basis for your eligibility for the upgrade. You may use the
resulting upgraded product only in accordance with the terms of this Agreement.

1.5 If the Software is labeled as an upgrade, you must be properly licensed to use a
product identified by Surgical Science as being eligible for the upgrade in order to use
the Software. Software labeled as an upgrade replaces and/or supplements the
product that formed the basis for your eligibility for the upgrade. You may use the
resulting upgraded product only in accordance with the terms of this Agreement.

1.6 This license is personal to you and you shall not assign or transfer any interest in it
or grant any right under it to any third party or seek to exercise this license for the
benefit or on the data of any third party.

2 CONFIDENCE OF THE SOFTWARE AND COPYRIGHT

2.1 The Software, all associated documentation, and all copies are secret and
confidential to Surgical Science and shall be retained under the effective control of you
during the period of this Agreement. Disclosures shall be limited to those members of
your staff (including temporary staff) who need access to the Software to enable you
to exercise this license. You shall take all measures necessary to maintain confidence
and secrecy in the Software during the period of this license and after its termination,
however such termination may arise.

surgicalscience Page 120


# Page 132

Chapter 10 
 End-User Software License Agreement
 
Page 121
 
2.2  All title and copyrights and patents in and to the Software (including but not 
limited to any images, photographs, animations, video, audio, music, text, techniques 
and "applets" incorporated into the Software), the accompanying printed materials, 
and any copies of the Software are owned by Surgical Science or its suppliers. The 
Software is protected by copyright laws and patents laws as well as by international 
treaty provisions. Therefore, you must treat the Software like any other copyrighted or 
patented material. You may not copy the printed materials accompanying the 
Software. 
3  OWNERSHIP OF SOFTWARE 
3.1  Subject to the rights granted to you by this Agreement, you acknowledge that all 
and any proprietary rights in the software (including but not limited to copyrights, 
patents, trademarks and trade secrets) and in all associated documentation and other 
material related to the Software in each case now existing or to be developed by 
Surgical Science shall remain the sole property of Surgical Science. 
3.2  Usage Data. You acknowledge and agree that Surgical Science may derive or 
create data and information about the use of the Software by you and your users 
("Usage Data") and Surgical Science may use and disclose Usage Data to its third-
party service providers in order to improve the Software. Personal data related to any 
identifiable individual is not collected by Surgical Science. 
4  SUPPORT SERVICES 
4.1  Surgical Science may provide you with support services related to the Software 
("Support Services"). Use of Support Services is governed by the Surgical Science 
policies and programs described in the user manual, in "online" documentation, and/or 
in other Surgical Science-provided materials. Any supplemental software provided to 
you as part of the Support Services shall be considered part of the Software and 
subject to the terms and conditions of this Agreement. With respect to technical 
information you provide to Surgical Science as part of the Support Services, Surgical 
Science may use such information for its business purposes, including for product 
support and development. Surgical Science will not utilize such technical information in 
a form that personally identifies you. 


[TABLE]
| Chapter 10                                                                           | End-User Software License Agreement                                                      |
|:-------------------------------------------------------------------------------------|:-----------------------------------------------------------------------------------------|
| 2.2  All title and copyrights and patents in and to the Software (including but not  |                                                                                          |
|                                                                                      | limited to any images, photographs, animations, video, audio, music, text, techniques    |
| and "applets" incorporated into the Software), the accompanying printed materials,   |                                                                                          |
| and any copies of the Software are owned by Surgical Science or its suppliers. The   |                                                                                          |
| Software is protected by copyright laws and patents laws as well as by international |                                                                                          |
|                                                                                      | treaty provisions. Therefore, you must treat the Software like any other copyrighted or  |
| patented material. You may not copy the printed materials accompanying the           |                                                                                          |
| Software.                                                                            |                                                                                          |
| 3  OWNERSHIP OF SOFTWARE                                                             |                                                                                          |
|                                                                                      | 3.1  Subject to the rights granted to you by this Agreement, you acknowledge that all    |
| and any proprietary rights in the software (including but not limited to copyrights, |                                                                                          |
|                                                                                      | patents, trademarks and trade secrets) and in all associated documentation and other     |
| material related to the Software in each case now existing or to be developed by     |                                                                                          |
| Surgical Science shall remain the sole property of Surgical Science.                 |                                                                                          |
| 3.2  Usage Data. You acknowledge and agree that Surgical Science may derive or       |                                                                                          |
| create data and information about the use of the Software by you and your users      |                                                                                          |
| ("Usage Data") and Surgical Science may use and disclose Usage Data to its third-    |                                                                                          |
|                                                                                      | party service providers in order to improve the Software. Personal data related to any   |
| identifiable individual is not collected by Surgical Science.                        |                                                                                          |
| 4  SUPPORT SERVICES                                                                  |                                                                                          |
| 4.1  Surgical Science may provide you with support services related to the Software  |                                                                                          |
| ("Support Services"). Use of Support Services is governed by the Surgical Science    |                                                                                          |
|                                                                                      | policies and programs described in the user manual, in "online" documentation, and/or    |
|                                                                                      | in other Surgical Science-provided materials. Any supplemental software provided to      |
| you as part of the Support Services shall be considered part of the Software and     |                                                                                          |
| subject to the terms and conditions of this Agreement. With respect to technical     |                                                                                          |
|                                                                                      | information you provide to Surgical Science as part of the Support Services, Surgical    |
| Science may use such information for its business purposes, including for product    |                                                                                          |
|                                                                                      | support and development. Surgical Science will not utilize such technical information in |
| a form that personally identifies you.                                               |                                                                                          |

[OCR_TABLE]
T° Le ee tee AX

[OCR_TABLE]
2.2 All title

[OCR_TABLE]
and "apple
and any co

[OCR]
Chapter 10 End-User Software License Agreement

2.2 All title and copyrights and patents in and to the Software (including but not
limited to any images, photographs, animations, video, audio, music, text, techniques
and "applets" incorporated into the Software), the accompanying printed materials,
and any copies of the Software are owned by Surgical Science or its suppliers. The
Software is protected by copyright laws and patents laws as well as by international
treaty provisions. Therefore, you must treat the Software like any other copyrighted or
patented material. You may not copy the printed materials accompanying the
Software.

3 OWNERSHIP OF SOFTWARE

3.1 Subject to the rights granted to you by this Agreement, you acknowledge that all
and any proprietary rights in the software (including but not limited to copyrights,
patents, trademarks and trade secrets) and in all associated documentation and other
material related to the Software in each case now existing or to be developed by
Surgical Science shall remain the sole property of Surgical Science.

3.2 Usage Data. You acknowledge and agree that Surgical Science may derive or
create data and information about the use of the Software by you and your users
("Usage Data") and Surgical Science may use and disclose Usage Data to its third-
party service providers in order to improve the Software. Personal data related to any
identifiable individual is not collected by Surgical Science.

4 SUPPORT SERVICES

4.1 Surgical Science may provide you with support services related to the Software
("Support Services"). Use of Support Services is governed by the Surgical Science
policies and programs described in the user manual, in "online" documentation, and/or
in other Surgical Science-provided materials. Any supplemental software provided to
you as part of the Support Services shall be considered part of the Software and
subject to the terms and conditions of this Agreement. With respect to technical
information you provide to Surgical Science as part of the Support Services, Surgical
Science may use such information for its business purposes, including for product
support and development. Surgical Science will not utilize such technical information in
a form that personally identifies you.

surgicalscience Page 121


# Page 133

Chapter 10 
 End-User Software License Agreement
 
Page 122
 
5  INTEGRITY OF THE SOFTWARE 
5.1  You shall not, directly or indirectly in any form or manner, copy, distribute, 
reproduce, incorporate or allow unauthorized use or access to the Software or modify, 
decompile, reverse engineer, disassemble or otherwise attempt to derive a source 
code or similar information from Software, except as explicitly permitted under this 
Agreement. 
5.2  The Software is licensed as a single product. Its component parts may not be 
separated for use on more than one computer. 
5.3  You shall ensure that all copies of and extracts from the Software and its 
associated documentation made or disclosed by you carry Surgical Science’ copyright 
notice in the form shown on the original, or such other copyright notices as Surgical 
Science may specify from time to time and shall ensure that no such notice is deleted. 
6  RIGHT OF ACCESS 
6.1  For the purpose only of verifying your compliance with these conditions, you 
hereby irrevocable grants permission for Surgical Science and its authorized 
representatives during normal business hours to enter the premises from time to time 
wholly or partly occupied by you and in each case there to access, operate, and 
inspect computer equipment and to access, inspect and take copies of documents and 
records (including magnetic and other media). Surgical Science shall exercise this right 
only for the above purpose and shall observe strict confidence in all information which 
it obtains as a result of such inspections except to the extent that disclosure to third 
parties is necessary for the purposes of protecting Surgical Science’ rights in the 
Software. 


[TABLE]
| Chapter 10                                                                            | End-User Software License Agreement                                                      |
|:--------------------------------------------------------------------------------------|:-----------------------------------------------------------------------------------------|
| 5  INTEGRITY OF THE SOFTWARE                                                          |                                                                                          |
| 5.1  You shall not, directly or indirectly in any form or manner, copy, distribute,   |                                                                                          |
|                                                                                       | reproduce, incorporate or allow unauthorized use or access to the Software or modify,    |
| decompile, reverse engineer, disassemble or otherwise attempt to derive a source      |                                                                                          |
| code or similar information from Software, except as explicitly permitted under this  |                                                                                          |
| Agreement.                                                                            |                                                                                          |
| 5.2  The Software is licensed as a single product. Its component parts may not be     |                                                                                          |
| separated for use on more than one computer.                                          |                                                                                          |
| 5.3  You shall ensure that all copies of and extracts from the Software and its       |                                                                                          |
|                                                                                       | associated documentation made or disclosed by you carry Surgical Science’ copyright      |
| notice in the form shown on the original, or such other copyright notices as Surgical |                                                                                          |
|                                                                                       | Science may specify from time to time and shall ensure that no such notice is deleted.   |
| 6  RIGHT OF ACCESS                                                                    |                                                                                          |
| 6.1  For the purpose only of verifying your compliance with these conditions, you     |                                                                                          |
| hereby irrevocable grants permission for Surgical Science and its authorized          |                                                                                          |
|                                                                                       | representatives during normal business hours to enter the premises from time to time     |
| wholly or partly occupied by you and in each case there to access, operate, and       |                                                                                          |
|                                                                                       | inspect computer equipment and to access, inspect and take copies of documents and       |
|                                                                                       | records (including magnetic and other media). Surgical Science shall exercise this right |
|                                                                                       | only for the above purpose and shall observe strict confidence in all information which  |
|                                                                                       | it obtains as a result of such inspections except to the extent that disclosure to third |
| parties is necessary for the purposes of protecting Surgical Science’ rights in the   |                                                                                          |
| Software.                                                                             |                                                                                          |

[OCR_TABLE]
5 INTEGRI

[OCR]
Chapter 10 End-User Software License Agreement

5 INTEGRITY OF THE SOFTWARE

5.1 You shall not, directly or indirectly in any form or manner, copy, distribute,
reproduce, incorporate or allow unauthorized use or access to the Software or modify,
decompile, reverse engineer, disassemble or otherwise attempt to derive a source
code or similar information from Software, except as explicitly permitted under this
Agreement.

5.2 The Software is licensed as a single product. Its component parts may not be
separated for use on more than one computer.

5.3 You shall ensure that all copies of and extracts from the Software and its
associated documentation made or disclosed by you carry Surgical Science’ copyright
notice in the form shown on the original, or such other copyright notices as Surgical
Science may specify from time to time and shall ensure that no such notice is deleted.

6 RIGHT OF ACCESS

6.1 For the purpose only of verifying your compliance with these conditions, you
hereby irrevocable grants permission for Surgical Science and its authorized
representatives during normal business hours to enter the premises from time to time
wholly or partly occupied by you and in each case there to access, operate, and
inspect computer equipment and to access, inspect and take copies of documents and
records (including magnetic and other media). Surgical Science shall exercise this right
only for the above purpose and shall observe strict confidence in all information which
it obtains as a result of such inspections except to the extent that disclosure to third
parties is necessary for the purposes of protecting Surgical Science’ rights in the
Software.

surgicalscience Page 122


# Page 134

Chapter 10 
 End-User Software License Agreement
 
Page 123
 
7  WARRANTY AND LIMITATION OF LIABILITY 
7.1  Surgical Science warrants that (i) the Software will perform substantially in 
accordance with the accompanying written materials for a period of ninety (90) days 
from the date of receipt, and (ii) any Support Services provided by Surgical Science 
shall be substantially as described in applicable written materials provided to you by 
Surgical Science, and Surgical Science support engineers will make commercially 
reasonable efforts to solve any problem issues. Some jurisdictions do not allow 
limitations on duration of an implied warranty, so the above limitation may not apply to 
you. To the extent allowed by applicable law, implied warranties on the Software, if 
any, are limited to ninety (90) days. 
The above said warranty is void if failure of the Software has resulted from accident, 
abuse, or misapplication. Any replacement Software will be warranted for the 
remainder of the original warranty period or thirty (30) days, whichever is longer. 
Neither these remedies nor any Support Services offered by Surgical Science are 
available without proof of purchase from an authorized source. 
7.2  To the maximum extent permitted by applicable law, Surgical Science and its 
suppliers disclaim all other warranties and conditions, either express or implied, 
including, but not limited to, implied warranties of fitness for a particular purpose, title, 
and non-infringement, with regard to the Software, and the provision of or failure to 
provide Support Services. 
7.3  To the maximum extent permitted by applicable law, in no event shall Surgical 
Science or its suppliers be liable for any special, incidental, indirect, or consequential 
damages whatsoever (including, without limitation, damages for loss of business 
profits, business interruption or loss of business information) arising out of the use of 
or inability to use the Software or the provision of or failure to provide Support 
Services. However, if you have entered into a Surgical Science Support Services 
agreement, Surgical Science’ entire liability regarding Support Services shall be 
governed by the terms of that agreement. 
7.4  Surgical Science’ entire liability under any provision of this Agreement and your 
exclusive remedy shall be, at Surgical Science’ sole discretion to, either (i) return of the 
amount actually paid by you for the Software, if any, or (ii) repair or replacement of the 
Software that does not meet Surgical Science’ warranty and which is returned to 
Surgical Science with a copy of your receipt. 


[TABLE]
| Chapter 10                                                                             | End-User Software License Agreement                                                           |
|:---------------------------------------------------------------------------------------|:----------------------------------------------------------------------------------------------|
| 7  WARRANTY AND LIMITATION OF LIABILITY                                                |                                                                                               |
| 7.1  Surgical Science warrants that (i) the Software will perform substantially in     |                                                                                               |
|                                                                                        | accordance with the accompanying written materials for a period of ninety (90) days           |
| from the date of receipt, and (ii) any Support Services provided by Surgical Science   |                                                                                               |
|                                                                                        | shall be substantially as described in applicable written materials provided to you by        |
| Surgical Science, and Surgical Science support engineers will make commercially        |                                                                                               |
| reasonable efforts to solve any problem issues. Some jurisdictions do not allow        |                                                                                               |
|                                                                                        | limitations on duration of an implied warranty, so the above limitation may not apply to      |
| you. To the extent allowed by applicable law, implied warranties on the Software, if   |                                                                                               |
| any, are limited to ninety (90) days.                                                  |                                                                                               |
|                                                                                        | The above said warranty is void if failure of the Software has resulted from accident,        |
| abuse, or misapplication. Any replacement Software will be warranted for the           |                                                                                               |
| remainder of the original warranty period or thirty (30) days, whichever is longer.    |                                                                                               |
| Neither these remedies nor any Support Services offered by Surgical Science are        |                                                                                               |
| available without proof of purchase from an authorized source.                         |                                                                                               |
| 7.2  To the maximum extent permitted by applicable law, Surgical Science and its       |                                                                                               |
| suppliers disclaim all other warranties and conditions, either express or implied,     |                                                                                               |
|                                                                                        | including, but not limited to, implied warranties of fitness for a particular purpose, title, |
| and non-infringement, with regard to the Software, and the provision of or failure to  |                                                                                               |
| provide Support Services.                                                              |                                                                                               |
| 7.3  To the maximum extent permitted by applicable law, in no event shall Surgical     |                                                                                               |
|                                                                                        | Science or its suppliers be liable for any special, incidental, indirect, or consequential    |
| damages whatsoever (including, without limitation, damages for loss of business        |                                                                                               |
|                                                                                        | profits, business interruption or loss of business information) arising out of the use of     |
| or inability to use the Software or the provision of or failure to provide Support     |                                                                                               |
| Services. However, if you have entered into a Surgical Science Support Services        |                                                                                               |
| agreement, Surgical Science’ entire liability regarding Support Services shall be      |                                                                                               |
| governed by the terms of that agreement.                                               |                                                                                               |
| 7.4  Surgical Science’ entire liability under any provision of this Agreement and your |                                                                                               |
|                                                                                        | exclusive remedy shall be, at Surgical Science’ sole discretion to, either (i) return of the  |
|                                                                                        | amount actually paid by you for the Software, if any, or (ii) repair or replacement of the    |
| Software that does not meet Surgical Science’ warranty and which is returned to        |                                                                                               |
| Surgical Science with a copy of your receipt.                                          |                                                                                               |

[OCR_TABLE]
Chapter 10

[OCR_TABLE]
7 WARRAT

[OCR_TABLE]
IA Qiyirnin

[OCR_TABLE]
fe —h—e ws

accordanc

[OCR]
Chapter 10 End-User Software License Agreement

7 WARRANTY AND LIMITATION OF LIABILITY

7.1 Surgical Science warrants that (i) the Software will perform substantially in
accordance with the accompanying written materials for a period of ninety (90) days
from the date of receipt, and (ii) any Support Services provided by Surgical Science
shall be substantially as described in applicable written materials provided to you by
Surgical Science, and Surgical Science support engineers will make commercially
reasonable efforts to solve any problem issues. Some jurisdictions do not allow
limitations on duration of an implied warranty, so the above limitation may not apply to
you. To the extent allowed by applicable law, implied warranties on the Software, if
any, are limited to ninety (90) days.

The above said warranty is void if failure of the Software has resulted from accident,
abuse, or misapplication. Any replacement Software will be warranted for the
remainder of the original warranty period or thirty (30) days, whichever is longer.
Neither these remedies nor any Support Services offered by Surgical Science are
available without proof of purchase from an authorized source.

7.2 To the maximum extent permitted by applicable law, Surgical Science and its
suppliers disclaim all other warranties and conditions, either express or implied,
including, but not limited to, implied warranties of fitness for a particular purpose, title,
and non-infringement, with regard to the Software, and the provision of or failure to
provide Support Services.

7.3 To the maximum extent permitted by applicable law, in no event shall Surgical
Science or its suppliers be liable for any special, incidental, indirect, or consequential
damages whatsoever (including, without limitation, damages for loss of business
profits, business interruption or loss of business information) arising out of the use of
or inability to use the Software or the provision of or failure to provide Support
Services. However, if you have entered into a Surgical Science Support Services
agreement, Surgical Science’ entire liability regarding Support Services shall be
governed by the terms of that agreement.

7.4 Surgical Science’ entire liability under any provision of this Agreement and your
exclusive remedy shall be, at Surgical Science’ sole discretion to, either (i) return of the
amount actually paid by you for the Software, if any, or (ii) repair or replacement of the
Software that does not meet Surgical Science’ warranty and which is returned to
Surgical Science with a copy of your receipt.

surgicalscience Page 123


# Page 135

Chapter 10 
 End-User Software License Agreement
 
Page 124
 
8  TERMINATION 
8.1  If this license is a Trial license, you shall be entitled to return the Software to 
Surgical Science on or before Trial Expiry Date specified in the License Key Issue Note 
and, in that event, this Agreement shall then terminate. Unless otherwise agreed under 
special conditions, no license fee or other charges shall be payable by you in respect 
of the trial. 
8.2  Unless terminated pursuant to 8.3 below this Agreement shall continue until the 
expiry date, if any, specified in the Particulars or the License Key Issue Note. 
8.3  This Agreement may be terminated by Surgical Science at any time by written 
notice of termination: 
8.3.1.  if you shall expressly or impliedly repudiate this license by refusing or 
threatening to refuse to observe any of the conditions to which this license is subject; 
or 
8.3.2  if you shall fail to make payment of any amount due to and invoiced by Surgical 
Science or to observe any of the conditions to which this license is subject and, after 
your attention has been drawn by notice to such failure, shall fail to remedy the matter 
to Surgical Science's reasonable satisfaction within thirty days of the giving or such 
notice; or 
8.3.3  if you shall have a receiver or administrative receiver or administrator appointed 
or shall enter into liquidation whether compulsory or voluntary or if you or any member 
of your partnership shall be unable to pay its debts as and when they fall due or any 
judgment or execution or other process issued in respect of any judgment against you 
is unsatisfied for fourteen days. 
8.4  On expiry, surrender or other termination of this Agreement, however such 
termination may arise, you shall cease to load, store, copy or use the Software, shall 
delete the Software from the any computers on which the Software is installed or 
copied and at Surgical Science's option shall either surrender the Software and all 
documentation and other related materials to Surgical Science or shall destroy the 
Software with all documentation and other related materials and deliver to Surgical 
Science a certificate of comprehensive destruction. You shall continue after 
termination to observe and enforce confidence and secrecy in respect of the Software 
and its documentation and related materials for the benefit of Surgical Science, and 
however termination may occur it shall not prejudice any right of action or remedy 
which may have accrued prior to termination. 


[TABLE]
| Chapter 10                                                                               | End-User Software License Agreement                                                       |
|:-----------------------------------------------------------------------------------------|:------------------------------------------------------------------------------------------|
| 8  TERMINATION                                                                           |                                                                                           |
| 8.1  If this license is a Trial license, you shall be entitled to return the Software to |                                                                                           |
|                                                                                          | Surgical Science on or before Trial Expiry Date specified in the License Key Issue Note   |
|                                                                                          | and, in that event, this Agreement shall then terminate. Unless otherwise agreed under    |
|                                                                                          | special conditions, no license fee or other charges shall be payable by you in respect    |
| of the trial.                                                                            |                                                                                           |
| 8.2  Unless terminated pursuant to 8.3 below this Agreement shall continue until the     |                                                                                           |
| expiry date, if any, specified in the Particulars or the License Key Issue Note.         |                                                                                           |
| 8.3  This Agreement may be terminated by Surgical Science at any time by written         |                                                                                           |
| notice of termination:                                                                   |                                                                                           |
| 8.3.1.  if you shall expressly or impliedly repudiate this license by refusing or        |                                                                                           |
|                                                                                          | threatening to refuse to observe any of the conditions to which this license is subject;  |
| or                                                                                       |                                                                                           |
|                                                                                          | 8.3.2  if you shall fail to make payment of any amount due to and invoiced by Surgical    |
|                                                                                          | Science or to observe any of the conditions to which this license is subject and, after   |
|                                                                                          | your attention has been drawn by notice to such failure, shall fail to remedy the matter  |
| to Surgical Science's reasonable satisfaction within thirty days of the giving or such   |                                                                                           |
| notice; or                                                                               |                                                                                           |
|                                                                                          | 8.3.3  if you shall have a receiver or administrative receiver or administrator appointed |
|                                                                                          | or shall enter into liquidation whether compulsory or voluntary or if you or any member   |
| of your partnership shall be unable to pay its debts as and when they fall due or any    |                                                                                           |
|                                                                                          | judgment or execution or other process issued in respect of any judgment against you      |
| is unsatisfied for fourteen days.                                                        |                                                                                           |
| 8.4  On expiry, surrender or other termination of this Agreement, however such           |                                                                                           |
| termination may arise, you shall cease to load, store, copy or use the Software, shall   |                                                                                           |
| delete the Software from the any computers on which the Software is installed or         |                                                                                           |
| copied and at Surgical Science's option shall either surrender the Software and all      |                                                                                           |
| documentation and other related materials to Surgical Science or shall destroy the       |                                                                                           |
| Software with all documentation and other related materials and deliver to Surgical      |                                                                                           |
| Science a certificate of comprehensive destruction. You shall continue after             |                                                                                           |
|                                                                                          | termination to observe and enforce confidence and secrecy in respect of the Software      |
| and its documentation and related materials for the benefit of Surgical Science, and     |                                                                                           |
| however termination may occur it shall not prejudice any right of action or remedy       |                                                                                           |
| which may have accrued prior to termination.                                             |                                                                                           |

[OCR_TABLE]
Q TERMIN

[OCR_TABLE]
8.1 If this |
Surgical Sc

[OCR]
Chapter 10 End-User Software License Agreement

8 TERMINATION

8.1 If this license is a Trial license, you shall be entitled to return the Software to
Surgical Science on or before Trial Expiry Date specified in the License Key Issue Note
and, in that event, this Agreement shall then terminate. Unless otherwise agreed under
special conditions, no license fee or other charges shall be payable by you in respect
of the trial.

8.2 Unless terminated pursuant to 8.3 below this Agreement shall continue until the
expiry date, if any, specified in the Particulars or the License Key Issue Note.

8.3 This Agreement may be terminated by Surgical Science at any time by written
notice of termination:

8.3.1. if you shall expressly or impliedly repudiate this license by refusing or
threatening to refuse to observe any of the conditions to which this license is subject;
or

8.3.2 if you shall fail to make payment of any amount due to and invoiced by Surgical
Science or to observe any of the conditions to which this license is subject and, after
your attention has been drawn by notice to such failure, shall fail to remedy the matter
to Surgical Science's reasonable satisfaction within thirty days of the giving or such
notice; or

8.3.3 if you shall have a receiver or administrative receiver or administrator appointed
or shall enter into liquidation whether compulsory or voluntary or if you or any member
of your partnership shall be unable to pay its debts as and when they fall due or any
judgment or execution or other process issued in respect of any judgment against you
is unsatisfied for fourteen days.

8.4 On expiry, surrender or other termination of this Agreement, however such
termination may arise, you shall cease to load, store, copy or use the Software, shall
delete the Software from the any computers on which the Software is installed or
copied and at Surgical Science's option shall either surrender the Software and all
documentation and other related materials to Surgical Science or shall destroy the
Software with all documentation and other related materials and deliver to Surgical
Science a certificate of comprehensive destruction. You shall continue after
termination to observe and enforce confidence and secrecy in respect of the Software
and its documentation and related materials for the benefit of Surgical Science, and
however termination may occur it shall not prejudice any right of action or remedy
which may have accrued prior to termination.

surgicalscience Page 124


# Page 136

Chapter 10 
 End-User Software License Agreement
 
Page 125
 
9.  MISCELLANEOUS 
9.1  This Agreement is governed by Swedish law and any disputes arising out of or in 
connection to this Agreement shall be submitted to the exclusive jurisdiction of the 
Swedish courts. 
9.2  The headings to these Conditions are included for convenience only and do not 
affect their interpretation. 
9.3  Should you have any questions concerning this Agreement, or if you desire to 
contact Surgical Science for any reason, please contact Surgical Science (write or e-
mail): Surgical Science Sweden AB, Drakegatan 7, SE-412 50 Göteborg, Sweden, 
[info@surgical-science.com]. 
 


[TABLE]
| Chapter 10                                                                            | End-User Software License Agreement                                                  |
|:--------------------------------------------------------------------------------------|:-------------------------------------------------------------------------------------|
| 9.  MISCELLANEOUS                                                                     |                                                                                      |
|                                                                                       | 9.1  This Agreement is governed by Swedish law and any disputes arising out of or in |
| connection to this Agreement shall be submitted to the exclusive jurisdiction of the  |                                                                                      |
| Swedish courts.                                                                       |                                                                                      |
| 9.2  The headings to these Conditions are included for convenience only and do not    |                                                                                      |
| affect their interpretation.                                                          |                                                                                      |
| 9.3  Should you have any questions concerning this Agreement, or if you desire to     |                                                                                      |
| contact Surgical Science for any reason, please contact Surgical Science (write or e- |                                                                                      |
| mail): Surgical Science Sweden AB, Drakegatan 7, SE-412 50 Göteborg, Sweden,          |                                                                                      |
| [info@surgical-science.com].                                                          |                                                                                      |

[OCR_TABLE]
METAMAS! TV

[OCR]
Chapter 10 End-User Software License Agreement

9. MISCELLANEOUS

9.1 This Agreement is governed by Swedish law and any disputes arising out of or in
connection to this Agreement shall be submitted to the exclusive jurisdiction of the
Swedish courts.

9.2 The headings to these Conditions are included for convenience only and do not
affect their interpretation.

9.3 Should you have any questions concerning this Agreement, or if you desire to
contact Surgical Science for any reason, please contact Surgical Science (write or e-
mail): Surgical Science Sweden AB, Drakegatan 7, SE-412 50 Géteborg, Sweden,
[info@surgical-science.com].

surgicalscience Page 125


# Page 137

Index
 
Page 126
 
Index 
3 
3D Map · 50 
enhanced clinical display mode · 90 
general endoscope display mode · 53 
ultrasound plane on · 83 
3D Map display · 62 
3D Map display functions 
Controls panel · 84 
3D Mapy · 88 
A 
Accessing a module or course · 37 
easy access buttons · 40 
Actions panel · 62 
Additional wires · 20 
Adjusting height · 13 
Adjusting platform height · 13 
Adjusting the stand · 24 
Administered Sedatives list · 96 
Air indicator · 50, 55 
Automatic labeling · 75 
B 
Benchmarks 
on the Library screen · 44 
report graph · 115 
report rating scale · 114 
report scoreboard · 112 
Blue guide wire · 100 
Browsing through the saved images · 73 
C 
Caliper options · 71 
Capturing snapshots · 56 
ultrasound images · 72 
Case Info · 62 
Centering images in ultrasound display · 66 
Character options · 69 
Cloud configuration · 36 
Colonoscope · 17 
master tool · 98 
Colored organs on EUS · 77 
Coloring options · 76 
Completion status 
viewing in Library · 44 
Connecting the scope · 8 
Connecting the sleeve · 26 
Consciousness level monitoring · 94 
Consecutive times · 113 
Content selection buttons · 62 
Contours of organs · 76 
Contrast agent · 59 
Contrast agent, injecting · 59 
Contrast injection · 58 
Controls panel · 84, 88 
Filter panel · 86 
Cyberscopy 
display mode · 47 
programs · 47 
D 
Deleting 
measurement or label from ultrasound 
image · 72 
ultrasound image · 74 
Didactic materials · 41 
Display content buttons · 62 


[TABLE]
| 3                                   |                                             |
|:------------------------------------|:--------------------------------------------|
|                                     | C                                           |
| 3D Map · 50                         |                                             |
|                                     | Caliper options · 71                        |
| enhanced clinical display mode · 90 |                                             |
|                                     | Capturing snapshots · 56                    |
| general endoscope display mode · 53 |                                             |
|                                     | ultrasound images · 72                      |
| ultrasound plane on · 83            |                                             |
|                                     | Case Info · 62                              |
| 3D Map display · 62                 |                                             |
|                                     | Centering images in ultrasound display · 66 |
| 3D Map display functions            |                                             |
|                                     | Character options · 69                      |
| Controls panel · 84                 |                                             |
|                                     | Cloud configuration · 36                    |
| 3D Mapy · 88                        |                                             |
|                                     | Colonoscope · 17                            |
|                                     | master tool · 98                            |
|                                     | Colored organs on EUS · 77                  |
| A                                   |                                             |
|                                     | Coloring options · 76                       |
|                                     | Completion status                           |
| Accessing a module or course · 37   |                                             |
|                                     | viewing in Library · 44                     |
| easy access buttons · 40            |                                             |
|                                     | Connecting the scope · 8                    |
| Actions panel · 62                  |                                             |
|                                     | Connecting the sleeve · 26                  |
| Additional wires · 20               |                                             |
|                                     | Consciousness level monitoring · 94         |
| Adjusting height · 13               |                                             |
|                                     | Consecutive times · 113                     |
| Adjusting platform height · 13      |                                             |
|                                     | Content selection buttons · 62              |
| Adjusting the stand · 24            |                                             |
|                                     | Contours of organs · 76                     |
| Administered Sedatives list · 96    |                                             |
|                                     | Contrast agent · 59                         |
| Air indicator · 50, 55              |                                             |
|                                     | Contrast agent, injecting · 59              |
| Automatic labeling · 75             |                                             |
|                                     | Contrast injection · 58                     |
|                                     | Controls panel · 84, 88                     |
|                                     | Filter panel · 86                           |
| B                                   | Cyberscopy                                  |
|                                     | display mode · 47                           |

[OCR_TABLE]
nde

[OCR]
Index

| Index

3 C
3D Map - 50
enhanced clinical display mode - 90
general endoscope display mode - 53
ultrasound plane on - 83
3D Map display - 62
3D Map display functions
Controls panel - 84
3D Mapy - 88

Caliper options - 71
Capturing snapshots - 56
ultrasound images - 72
Case Info - 62
Centering images in ultrasound display - 66
Character options - 69
Cloud configuration - 36
Colonoscope - 17
master tool - 98
AO Colored organs on EUS - 77
Coloring options - 76

Completion status
Accessing a module or course - 37 viewing in Library - 44
easy access buttons - 40 Connecting the scope - 8
Actions panel - 62 Connecting the sleeve - 26
Additional wires - 20 Consciousness level monitoring - 94
Adjusting height - 13 Consecutive times - 113
Adjusting platform height - 13 Content selection buttons - 62
Adjusting the stand - 24 Contours of organs - 76
Administered Sedatives list - 96 Contrast agent - 59
Air indicator - 50, 55 Contrast agent, injecting - 59
Automatic labeling - 75 Contrast injection - 58
Controls panel - 84, 88
—_— oe Filter panel - 86
B Cyberscopy
display mode - 47
Benchmarks programs : 47

on the Library screen - 44
report graph - 115

report rating scale - 114 D
report scoreboard - 112
Blue guide wire - 100 Deleting
Browsing through the saved images - 73 measurement or label from ultrasound

image - 72
ultrasound image - 74
Didactic materials - 41
Display content buttons - 62

surgicalscience Page 126


# Page 138

Index
 
Page 127
 
Display focus · 64 
Display modes · 47 
cyberscopy · 47 
endoscopy and ultrasound · 61 
enhanced clinical · 87 
general endoscopy · 49 
Displaying 
colored organs on EUS · 77 
contour of organs · 76 
linear EUS · 81 
radial EUS · 81 
Duodenoscope · 18 
master tool · 99 
E 
Educational aids 
air indicators · 55 
coloring and filtering options · 76 
endoscopy and fluoroscopy display 
mode · 58 
enhanced clinical display mode · 89 
EUS orientation landmarks · 75 
interactive map · 54 
pain indicators · 55 
virtual instructor · 55 
Electrosurgical current · 98 
ENDO Mentor Suite 
GI Mentor platform · 5 
EndoBasket · 47 
Endoscopic display · 57 
Endoscopy and Fluoroscopy display mode 
split screen · 58 
Endoscopy and Ultrasound display mode · 
61 
primary displays · 64 
splitting display pane · 64 
switching displays · 64 
Enhanced Clinical display mode · 87 
Enlarging 
3D Map display · 86 
section of ultrasound display · 66 
ultrasound display · 65 
EUS orientation landmarks · 75 
Exporting performance results · 116 
External 3D Map view · 53 
F 
Filter options 
3D Map display · 87 
Ultrasound display · 79 
Filtering structures or organs 
Ultrasound display · 79 
Finish button · 56 
Flipping image · 60 
Flipping ultrasound display · 82 
Fluoroscopic display · 57, 58 
Fluoroscopic view controls · 58 
activating · 59 
deactivating · 60 
Focus buttons · 62 
Foot · 16, 31 
Foot switch · 16 
Freeze panel · 67 
Freezing the ultrasound image · 68 
Full screen mode · 51 
Function buttons · 62, 65 
actions panel · 62 
G 
General buttons · 50, 57, 62, 88 
General buttons · 88 
General Endoscopy display mode · 49 
screen · 50 
GI Mentor Express 
foot switch · 31 
master tool · 30 
GI-BRONCH interchangeable panel · 6 
Grid View · 38 
Guide wire · 100 


[TABLE]
| Display focus · 64            | Exporting performance results · 116   |
|:------------------------------|:--------------------------------------|
| Display modes · 47            | External 3D Map view · 53             |
| cyberscopy · 47               |                                       |
| endoscopy and ultrasound · 61 |                                       |
|                               |                                       |
| enhanced clinical · 87        | F                                     |
| general endoscopy · 49        |                                       |
| Displaying                    |                                       |
|                               | Filter options                        |
| colored organs on EUS · 77    |                                       |
|                               | 3D Map display · 87                   |
| contour of organs · 76        |                                       |
|                               | Ultrasound display · 79               |
| linear EUS · 81               |                                       |
|                               | Filtering structures or organs        |
| radial EUS · 81               |                                       |
|                               | Ultrasound display · 79               |
| Duodenoscope · 18             |                                       |
|                               | Finish button · 56                    |
| master tool · 99              |                                       |
|                               | Flipping image · 60                   |
|                               | Flipping ultrasound display · 82      |

[OCR_TABLE]
isplay fo

[OCR_TABLE]
we TE ww

enhance

[OCR]
Index

Display focus - 64
Display modes - 47
cyberscopy - 47
endoscopy and ultrasound - 61
enhanced clinical - 87
general endoscopy - 49
Displaying
colored organs on EUS - 77
contour of organs - 76
linear EUS - 81
radial EUS - 81
Duodenoscope - 18
master tool - 99

E

Educational aids
air indicators - 55
coloring and filtering options - 76

endoscopy and fluoroscopy display

mode - 58

enhanced clinical display mode - 89

EUS orientation landmarks - 75

interactive map - 54

pain indicators - 55

virtual instructor - 55
Electrosurgical current - 98
ENDO Mentor Suite

Gl Mentor platform - 5
EndoBasket - 47
Endoscopic display - 57

Endoscopy and Fluoroscopy display mode

split screen - 58

Endoscopy and Ultrasound display mode -

61
primary displays - 64
splitting display pane - 64
switching displays - 64
Enhanced Clinical display mode - 87
Enlarging
3D Map display - 86
section of ultrasound display - 66
ultrasound display - 65
EUS orientation landmarks - 75

Exporting performance results - 116
External 3D Map view - 53

F

Filter options

3D Map display - 87

Ultrasound display - 79

Filtering structures or organs

Ultrasound display - 79

Finish button - 56

Flipping image - 60

Flipping ultrasound display - 82

Fluoroscopic display - 57, 58

Fluoroscopic view controls - 58

activating - 59

deactivating - 60

Focus buttons - 62

Foot : 16, 31

Foot switch - 16

Freeze panel - 67

Freezing the ultrasound image - 68

Full screen mode - 51

Function buttons - 62, 65
actions panel - 62

G

General buttons - 50, 57, 62, 88
General buttons - 88

General Endoscopy display mode - 49

screen - 50

GI Mentor Express
foot switch - 31
master tool - 30

GI-BRONCH interchangeable panel - 6

Grid View - 38
Guide wire - 100

surgicalscience

Page 127


# Page 139

Index
 
Page 128
 
H 
Hardware · 4 
Height elevation mechanism · 13 
Helpers options · 75, 76 
Helpers panel · 75 
Filter panel · 78 
Hiding structures or organs 
Ultrasound display · 79 
I 
Image Enhancement mode · 90 
Injecting 
contrast agent · 59 
Instructional aids · 50 
Interactive map · 50, 54, 57 
L 
Labeling 
EUS landmarks · 75 
options · 76 
structures and organs · 69 
Landmarks, EUS orientation · 75 
Laptop setup · 22 
Lateral working position · 11 
Linear EUS · 81 
Logging in to MentorLearn · 32 
M 
Main display 
general endoscopy · 50 
Main view · 88 
Master tool · 19, 97 
MentorLearn 
Library screen · 38 
overview · 33 
patient file · 43 
starting case or task · 42 
workflow · 33 
Modality extensions · 9 
Modes · 47 
cyberscopy · 47 
endoscopy and ultrasound · 61 
enhanced clinical · 87 
general endoscopy · 49 
O 
Opening a Case or Task · 32 
Opening a module · 41 
Oxygen administration · 94 
Oxygen supplement · 94 
P 
Pain indicator · 50, 55 
Panning 3D Map display · 85 
Panning image · 60 
Paris Classification · 91 
Patient file · 43, 56 
Patient Management panel · 88, 92 
Perforation meter · 62 
Playback, procedure · 111 
Position of the endoscope · 54 
Primary view 
general endoscopy · 50, 51 
Proficiency scoreboard 
cases and tasks · 45 
module and courses · 45 
Pushing catheter · 100 
R 
Radial EUS · 81 
Reducing 
3D Map display · 86 
section of ultrasound image · 67 
ultrasound display · 66 


[TABLE]
|                                 | starting case or task · 42    |
|:--------------------------------|:------------------------------|
| H                               |                               |
|                                 | workflow · 33                 |
|                                 | Modality extensions · 9       |
| Hardware · 4                    |                               |
|                                 | Modes · 47                    |
| Height elevation mechanism · 13 |                               |
|                                 | cyberscopy · 47               |
| Helpers options · 75, 76        |                               |
|                                 | endoscopy and ultrasound · 61 |
| Helpers panel · 75              |                               |
|                                 | enhanced clinical · 87        |
| Filter panel · 78               |                               |
|                                 | general endoscopy · 49        |
| Hiding structures or organs     |                               |
| Ultrasound display · 79         |                               |

[OCR]
Index

H

Hardware - 4

Height elevation mechanism : 13

Helpers options - 75, 76
Helpers panel - 75
Filter panel - 78
Hiding structures or organs
Ultrasound display - 79

/

Image Enhancement mode - 90
Injecting

contrast agent - 59
Instructional aids - 50
Interactive map - 50, 54, 57

L

Labeling

EUS landmarks - 75

options - 76

structures and organs - 69
Landmarks, EUS orientation - 75
Laptop setup - 22
Lateral working position - 11
Linear EUS - 81
Logging in to MentorLearn - 32

M

Main display
general endoscopy - 50
Main view - 88
Master tool - 19, 97
MentorLearn
Library screen - 38
overview : 33
patient file - 43

starting case or task - 42
workflow - 33

Modality extensions - 9

Modes - 47
cyberscopy - 47
endoscopy and ultrasound - 61
enhanced clinical - 87
general endoscopy - 49

oO

Opening a Case or Task - 32
Opening a module - 41
Oxygen administration - 94
Oxygen supplement - 94

)

Pain indicator - 50, 55
Panning 3D Map display - 85
Panning image - 60

Paris Classification - 91
Patient file - 43, 56

Patient Management panel - 88, 92

Perforation meter - 62
Playback, procedure - 111
Position of the endoscope - 54
Primary view

general endoscopy - 50, 51
Proficiency scoreboard

cases and tasks - 45

module and courses - 45
Pushing catheter - 100

R

Radial EUS - 81
Reducing
3D Map display - 86

section of ultrasound image - 67

ultrasound display - 66

surgicalscience

Page 128


# Page 140

Index
 
Page 129
 
Removing colors and contours · 78 
Reports with benchmarks 
learning curve graph · 115 
rating scale · 114 
scoreboard · 112 
Reset 
ultrasound display · 67 
Reviewing 
didactic materials · 41 
Rotating 3D Map display · 86 
S 
Saving 
ultrasound images · 72 
Scope 
connectors · 9 
hangers · 8 
Scopes · 16 
colonoscope · 17 
duodenoscope · 18 
GI Mentor Express · 29 
Sedation administration · 95, 96 
Selecting 
ultrasound image · 74 
Settings options · 83 
Settings panel · 82 
Showing structures or organs 
Ultrasound display · 79 
Simulator 
hardware · 4 
Simulator body connections · 25 
Single-case report · 104 
Sleeve · 26 
Snapshots · 50, 56, 57, 106 
ultrasound images · 72 
Sound · 56 
Split screen 
endoscopy and fluoroscopy display 
mode · 58 
Split screen button · 62 
Starting a simulation case or task · 42 
Stents · 101 
Superior working position · 11 
Switching interchangeable panels · 7 
T 
Tool menu · 88 
Tool tray · 14 
connection outlets · 15 
Total score · 113, 114 
Touch screen · 32 
Trackball · 32 
Trainee report · 56 
Training with MentorLearn within a module 
or course · 37 
Turning on the simulator · 13 
U 
Ultrasound display function buttons · 62 
Ultrasound display functions · 65 
Freeze panel · 67 
Helpers panel · 75 
Settings panel · 82 
Zoom panel · 65 
Ultrasound display panels · 65 
Ultrasound plane · 83 
Unfreezing the ultrasound image · 68 
URO interchangeable panel · 7 
V 
Videos · 107 
Viewing 
additional information in report · 106 
procedure playback · 111 
saved snapshots · 110 
snapshots · 106 
videos · 107 
Viewing performance reports · 32, 103 
Virtual instructor · 55, 57 
Virtual Instructor · 50, 88 
Vital signs monitoring · 93 


[TABLE]
| Removing colors and contours · 78   | Switching interchangeable panels · 7   |
|:------------------------------------|:---------------------------------------|
| Reports with benchmarks             |                                        |
| learning curve graph · 115          |                                        |
|                                     |                                        |
| rating scale · 114                  | T                                      |
| scoreboard · 112                    |                                        |
| Reset                               |                                        |
|                                     | Tool menu · 88                         |
| ultrasound display · 67             |                                        |
|                                     | Tool tray · 14                         |
| Reviewing                           |                                        |
|                                     | connection outlets · 15                |
| didactic materials · 41             |                                        |
|                                     | Total score · 113, 114                 |
| Rotating 3D Map display · 86        |                                        |
|                                     | Touch screen · 32                      |
|                                     | Trackball · 32                         |

[OCR_TABLE]
emoving
eports wi

[OCR_TABLE]
scorebo
eset

[OCR]
Index

Removing colors and contours - 78
Reports with benchmarks
learning curve graph - 115
rating scale - 114
scoreboard - 112
Reset
ultrasound display - 67
Reviewing
didactic materials - 41
Rotating 3D Map display - 86

Ss

Saving
ultrasound images - 72
Scope
connectors - 9
hangers - 8
Scopes : 16
colonoscope - 17
duodenoscope - 18
GI Mentor Express - 29
Sedation administration - 95, 96
Selecting
ultrasound image - 74
Settings options - 83
Settings panel - 82
Showing structures or organs
Ultrasound display - 79
Simulator
hardware - 4
Simulator body connections - 25
Single-case report - 104
Sleeve - 26
Snapshots - 50, 56, 57, 106
ultrasound images - 72
Sound - 56
Split screen
endoscopy and fluoroscopy display
mode - 58
Split screen button - 62
Starting a simulation case or task - 42
Stents - 101
Superior working position - 11

Switching interchangeable panels - 7

a

Tool menu - 88

Tool tray - 14
connection outlets - 15

Total score - 113, 114

Touch screen - 32

Trackball - 32

Trainee report - 56

Training with MentorLearn within a module
or course - 37

Turning on the simulator - 13

U

Ultrasound display function buttons - 62
Ultrasound display functions - 65
Freeze panel - 67
Helpers panel - 75
Settings panel - 82
Zoom panel - 65
Ultrasound display panels - 65
Ultrasound plane - 83
Unfreezing the ultrasound image - 68
URO interchangeable panel - 7

V

Videos - 107
Viewing
additional information in report - 106
procedure playback - 111
saved snapshots - 110
snapshots - 106
videos - 107
Viewing performance reports - 32, 103
Virtual instructor - 55, 57
Virtual Instructor - 50, 88
Vital signs monitoring - 93

surgicalscience

Page 129


# Page 141

Index
 
Page 130
 
W 
Workflow · 32 
Working 
locally · 36 
on the cloud site · 36 
Working locally configuration · 36 
Working positions · 11 
Working with 
3D Map · 83 
basic tools · 97 
multiple tools and wires · 99 
tools requiring electricity · 98 
X 
X-ray · 58 
Z 
Zoom options · 65 
Zoom panel · 65 
Zooming in · 60 
3D Map display · 86 
ultrasound image · 65 
Zooming out · 60 
3D Map display · 86 
section of ultrasound image · 66 
ultrasound image · 66 
 


[TABLE]
| W                                  | X                                |
|:-----------------------------------|:---------------------------------|
| Workflow · 32                      | X-ray · 58                       |
| Working                            |                                  |
| locally · 36                       |                                  |
|                                    |                                  |
| on the cloud site · 36             | Z                                |
| Working locally configuration · 36 |                                  |
| Working positions · 11             |                                  |
|                                    | Zoom options · 65                |
| Working with                       |                                  |
|                                    | Zoom panel · 65                  |
| 3D Map · 83                        |                                  |
|                                    | Zooming in · 60                  |
| basic tools · 97                   |                                  |
|                                    | 3D Map display · 86              |
| multiple tools and wires · 99      |                                  |
|                                    | ultrasound image · 65            |
| tools requiring electricity · 98   |                                  |
|                                    | Zooming out · 60                 |
|                                    | 3D Map display · 86              |
|                                    | section of ultrasound image · 66 |
|                                    | ultrasound image · 66            |

[OCR]
Index

W

Workflow - 32
Working
locally - 36
on the cloud site - 36
Working locally configuration - 36
Working positions - 11
Working with
3D Map - 83
basic tools - 97
multiple tools and wires - 99
tools requiring electricity - 98

X-ray - 58

Zz

Zoom options - 65
Zoom panel - 65
Zooming in - 60
3D Map display - 86
ultrasound image - 65
Zooming out - 60
3D Map display - 86
section of ultrasound image - 66
ultrasound image - 66

surgicalscience

Page 130