

# Page 1

1
GI Mentor
GI Endoscopy - Fundamental  
Skills Module
Introduction
The GI Endoscopy - Fundamental Skills module offers didactic tutorials and 
designated skill tasks to guide the trainee through learning and acquiring 
competence in GI Flexible Endoscopy essentials. 
Practicing this module’s tasks the learner acquires and improves his GI 
endoscopy understanding, capabilities and sensibilities.  
This module provides the learners with the opportunity to assess 
themselves as they progress along the learning curve to competency. 
The different tasks shall address the five fundamental GI flexible 
endoscopy skills, as were deconstructed and defined by SAGES* (Society 
of American Gastrointestinal and Endoscopic Surgeons): 
	
 Endoscopic Navigation
	
 Loop Reduction
	
 Retroflexion
	
 Mucosal Evaluation
	
 Targeting
 
*Surg Endosc. 2014 Mar; 28(3):704-11. doi: 10.1007/s00464-013-3298-4.  
Epub 2013 Nov 20. / Fundamentals of endoscopic surgery: creation 
and validation of the hands-on test. / Vassiliou MC1, Dunkin BJ, Fried 
GM, Mellinger JD, Trus T, Kaneva P, Lyons C, Korndorffer JR Jr, Ujiki M, 
Velanovich V, Kochman ML, Tsuda S, Martinez J, Scott DJ, Korus G, Park 
A, Marks JM.
Consulted on the development of this module:  
Eric Pauli, MD, Penn State Hershey, PA, USA


[TABLE]
| GI Endoscopy - Fundamental                                                 |
|:---------------------------------------------------------------------------|
| Skills Module                                                              |
| Introduction                                                               |
| The GI Endoscopy - Fundamental Skills module offers didactic tutorials and |
| designated skill tasks to guide the trainee through learning and acquiring |
| competence in GI Flexible Endoscopy essentials.                            |
| Practicing this module’s tasks the learner acquires and improves his GI    |
| endoscopy understanding, capabilities and sensibilities.                   |
| This module provides the learners with the opportunity to assess           |
| themselves as they progress along the learning curve to competency.        |
| The different tasks shall address the five fundamental GI flexible         |
| endoscopy skills, as were deconstructed and defined by SAGES* (Society     |
| of American Gastrointestinal and Endoscopic Surgeons):                     |
|  Endoscopic Navigation                                                                            |
|  Loop Reduction                                                                            |
|  Retroflexion                                                                            |
|  Mucosal Evaluation                                                                            |
|  Targeting                                                                            |
| *                                                                          |
| Surg Endosc. 2014 Mar; 28(3):704-11. doi: 10.1007/s00464-013-3298-4.       |
| Epub 2013 Nov 20. / Fundamentals of endoscopic surgery: creation           |
| and validation of the hands-on test. / Vassiliou MC1, Dunkin BJ, Fried     |
| GM, Mellinger JD, Trus T, Kaneva P, Lyons C, Korndorffer JR Jr, Ujiki M,   |
| Velanovich V, Kochman ML, Tsuda S, Martinez J, Scott DJ, Korus G, Park     |
| A, Marks JM.                                                               |
| Consulted on the development of this module:                               |
| Eric Pauli, MD, Penn State Hershey, PA, USA                                |
| 1                                                                          |
| GI Mentor                                                                  |

[OCR_TABLE]
Ski

[OCR_TABLE]
Intro

[OCR]
GI Endoscopy - Fundamental

Skills Module

Introduction

The GI Endoscopy - Fundamental Skills module offers didactic tutorials and
designated skill tasks to guide the trainee through learning and acquiring
competence in GI Flexible Endoscopy essentials.

Practicing this module’s tasks the learner acquires and improves his Gl
endoscopy understanding, capabilities and sensibilities.

This module provides the learners with the opportunity to assess
themselves as they progress along the learning curve to competency.

The different tasks shall address the five fundamental Gl flexible
endoscopy skills, as were deconstructed and defined by SAGES* (Society
of American Gastrointestinal and Endoscopic Surgeons):

= Endoscopic Navigation

Loop Reduction

Retroflexion

Mucosal Evaluation

= Targeting

*Surg Endosc. 2014 Mar; 28(3):704-11. doi: 10.1007/s00464-013-3298-4.
Epub 2013 Nov 20. / Fundamentals of endoscopic surgery: creation

and validation of the hands-on test. / Vassiliou MC1, Dunkin BJ, Fried
GM, Mellinger JD, Trus T, Kaneva P, Lyons C, Korndorffer JR Jr, Ujiki M,
Velanovich V, Kochman ML, Tsuda S, Martinez J, Scott DJ, Korus G, Park
A, Marks JM.

Consulted on the development of this module:
Eric Pauli, MD, Penn State Hershey, PA, USA

surgical GI Mentor


# Page 2

2
GI Mentor
GI Endoscopy - Fundamental  
Skills Module
Learning Objectives
	
 To acquire understanding and hands-on competence in GI Endoscopic 
Navigation
	
 To acquire understanding and hands-on competence in GI Endoscopy 
Mucosal Evaluation
	
 To acquire understanding and hands-on competence in GI Endoscopy 
Loop Reduction
	
 To acquire understanding and hands-on competence in GI Endoscopy 
Retroflexion
	
 To acquire understanding and hands-on competence in GI Endoscopy 
Targeting (with a tool)
	
 To self-assess one’s hands-on proficiency level in GI Endoscopic 
Navigation 
	
 To self-assess one’s hands-on proficiency level in GI Endoscopy 
Mucosal Evaluation
	
 To self-assess one’s hands-on proficiency level in GI Endoscopy Loop 
Reduction
	
 To self-assess one’s hands-on proficiency level in GI Endoscopy 
Retroflexion
	
 To self-assess one’s hands-on proficiency level in GI Endoscopy 
Targeting (with a tool)
	
 To progress towards mastering the hands-on performance of all five 
fundamental skills
	
 To prepare oneself to demonstrate hands-on proficiency in endoscopic 
fundamental skills


[TABLE]
| Learning Objectives     |
|:------------------------|
|  To acquire understanding and hands-on competence in GI Endoscopic                         |
| Navigation              |
|  To acquire understanding and hands-on competence in GI Endoscopy                         |
| Mucosal Evaluation      |
|  To acquire understanding and hands-on competence in GI Endoscopy                         |
| Loop Reduction          |
|  To acquire understanding and hands-on competence in GI Endoscopy                         |
| Retroflexion            |
|  To acquire understanding and hands-on competence in GI Endoscopy                         |
| Targeting (with a tool) |
|  To self-assess one’s hands-on proficiency level in GI Endoscopic                         |
| Navigation              |
|  To self-assess one’s hands-on proficiency level in GI Endoscopy                         |
| Mucosal Evaluation      |
|  To self-assess one’s hands-on proficiency level in GI Endoscopy Loop                         |
| Reduction               |
|  To self-assess one’s hands-on proficiency level in GI Endoscopy                         |
| Retroflexion            |
|  To self-assess one’s hands-on proficiency level in GI Endoscopy                         |
| Targeting (with a tool) |
|  To progress towards mastering the hands-on performance of all five                         |
| fundamental skills      |
|  To prepare oneself to demonstrate hands-on proficiency in endoscopic                         |
| fundamental skills      |

[OCR]
GI Endoscopy - Fundamental

Skills Module

Learning Objectives

= To acquire understanding and hands-on competence in GI Endoscopic
Navigation

= To acquire understanding and hands-on competence in GI Endoscopy
Mucosal Evaluation

= To acquire understanding and hands-on competence in GI Endoscopy
Loop Reduction

= To acquire understanding and hands-on competence in GI Endoscopy
Retroflexion

= To acquire understanding and hands-on competence in GI Endoscopy
Targeting (with a tool)

= To self-assess one’s hands-on proficiency level in GI Endoscopic
Navigation
= To self-assess one’s hands-on proficiency level in GI Endoscopy
Mucosal Evaluation

= To self-assess one’s hands-on proficiency level in GI Endoscopy Loop
Reduction

= To self-assess one’s hands-on proficiency level in GI Endoscopy
Retroflexion

= To self-assess one’s hands-on proficiency level in GI Endoscopy
Targeting (with a tool)

= To progress towards mastering the hands-on performance of all five
fundamental skills

= To prepare oneself to demonstrate hands-on proficiency in endoscopic
fundamental skills

surgical GI Mentor


# Page 3

3
GI Mentor
GI Endoscopy - Fundamental  
Skills Module
General Screen Layout and Features
 
1 - Main View
	
 A dynamic display of the endoscope’s video
	
 Simulated environment and indications may vary per task
	
 a - Elapsed time is indicated in the upper right corner 
	
 b - Virtual instructor, when available, is displayed in the lower left corner
1
3
4
5
2
a
b


[TABLE]
| GI Endoscopy - Fundamental         |
|:-----------------------------------|
| Skills Module                      |
| General Screen Layout and Features |
| a                                  |
| 1                                  |
| 2                                  |
| 3                                  |
| b                                  |
| 4                                  |
| 5                                  |
| 1 - Main View                      |
|  A dynamic display of the endoscope’s video                                    |
|  Simulated environment and indications may vary per task                                    |
|  a - Elapsed time is indicated in the upper right corner                                    |
|  b - Virtual instructor, when available, is displayed in the lower left corner                                    |
| 3                                  |
| GI Mentor                          |

[OCR]
GI Endoscopy - Fundamental

Skills Module

General Screen Layout and Features

1- Main View

= A dynamic display of the endoscope’s video

= Simulated environment and indications may vary per task
= a - Elapsed time is indicated in the upper right corner

= b - Virtual instructor, when available, is displayed in the lower left corner

surgicalscience GI Mentor


# Page 4

4
GI Mentor
GI Endoscopy - Fundamental  
Skills Module
2 - Step-By-Step Instructions
	
 Contextual instructions for the currently performed task
	
 Automatically advanced upon completing the current instruction
3 - Tutorial Video Clips
	
 Relevant tutorial for the skill task
	
 Available for Basic level tasks
	
 Controls: Play, pause, restart and full screen
4 - How-Am-I-Doing-Bar 
	
 A real time indication of the performance level
	
 Available for Advanced level tasks
	
 Dynamically changes to reflect progress during the task performance 
Note: Some tasks will be complemented with How-Am-I-Doing bars in future 
versions.
5 - General Buttons 
	
 The Mute button turns the sounds Off / On
	
 The Exit button exits the current task


[TABLE]
| GI Endoscopy - Fundamental                                               |
|:-------------------------------------------------------------------------|
| Skills Module                                                            |
| 2 - Step-By-Step Instructions                                            |
|  Contextual instructions for the currently performed task                                                                          |
|  Automatically advanced upon completing the current instruction                                                                          |
| 3 - Tutorial Video Clips                                                 |
|  Relevant tutorial for the skill task                                                                          |
|  Available for Basic level tasks                                                                          |
|  Controls: Play, pause, restart and full screen                                                                          |
| 4 - How-Am-I-Doing-Bar                                                   |
|  A real time indication of the performance level                                                                          |
|  Available for Advanced level tasks                                                                          |
|  Dynamically changes to reflect progress during the task performance                                                                          |
| Note: Some tasks will be complemented with How-Am-I-Doing bars in future |
| versions.                                                                |
| 5 - General Buttons                                                      |
|  The Mute button turns the sounds Off / On                                                                          |
|  The Exit button exits the current task                                                                          |
| 4                                                                        |
| GI Mentor                                                                |

[OCR]
GI Endoscopy - Fundamental

Skills Module

2 - Step-By-Step Instructions

= Contextual instructions for the currently performed task

= Automatically advanced upon completing the current instruction
3 - Tutorial Video Clips

= Relevant tutorial for the skill task

= Available for Basic level tasks

= Controls: Play, pause, restart and full screen

4 - How-Am-!-Doing-Bar

= A real time indication of the performance level

= Available for Advanced level tasks

= Dynamically changes to reflect progress during the task performance

Note: Some tasks will be complemented with How-Am-I-Doing bars in future
versions.

5 - General Buttons

= The Mute button turns the sounds Off / On

= The Exit button exits the current task

surgical GI Mentor


# Page 5

GI Endoscopy - Fundamental  
Skills Module
5
GI Mentor
Skill: Endoscopic Navigation 
Task 1 – Basic Scope Manipulation
1
Goal:
The goal of this task is to understand basic endoscope maneuvers and to 
gain manual dexterity in applying them properly.
Method:
In the Basic Scope Manipulation task, the novice user can watch tutorials 
for endoscope handling and maneuvering and follow step-by-step 
instructions to perform discrete endoscope maneuvers. Maneuvers such 
as tip deflections, torque or forward/backward movements are required 
to fit targets into the endoscope field of view. After a target has been 
acquired, the scope must be reset to its neutral position.
Task Summary:
By performing this task, the learner becomes familiar with the discrete 
maneuvers prior to integrating them into a more challenging navigation,  
as required in the next, more advanced, Endoscopic Navigation task.


[TABLE]
| Skill: Endoscopic Navigation                                              |
|:--------------------------------------------------------------------------|
| Task 1 – Basic Scope Manipulation                                         |
| 1                                                                         |
| Goal:                                                                     |
| The goal of this task is to understand basic endoscope maneuvers and to   |
| gain manual dexterity in applying them properly.                          |
| Method:                                                                   |
| In the Basic Scope Manipulation task, the novice user can watch tutorials |
| for endoscope handling and maneuvering and follow step-by-step            |
| instructions to perform discrete endoscope maneuvers. Maneuvers such      |
| as tip deflections, torque or forward/backward movements are required     |
| to fit targets into the endoscope field of view. After a target has been  |
| acquired, the scope must be reset to its neutral position.                |
| Task Summary:                                                             |
| By performing this task, the learner becomes familiar with the discrete   |
| maneuvers prior to integrating them into a more challenging navigation,   |
| as required in the next, more advanced, Endoscopic Navigation task.       |

[OCR]
GI Endoscopy - Fundamental

Skills Module

Task 1- Basic Scope Manipulation

Goal:

The goal of this task is to understand basic endoscope maneuvers and to
gain manual dexterity in applying them properly.

Method:

In the Basic Scope Manipulation task, the novice user can watch tutorials
for endoscope handling and maneuvering and follow step-by-step
instructions to perform discrete endoscope maneuvers. Maneuvers such
as tip deflections, torque or forward/backward movements are required
to fit targets into the endoscope field of view. After a target has been
acquired, the scope must be reset to its neutral position.

Task Summary:

By performing this task, the learner becomes familiar with the discrete
maneuvers prior to integrating them into a more challenging navigation,
as required in the next, more advanced, Endoscopic Navigation task.

surgical GI Mentor


# Page 6

GI Endoscopy - Fundamental  
Skills Module
6
GI Mentor
Skill: Endoscopic Navigation 
Task 2 - Endoscopic Navigation
2
Goal: 
The goal of this task is to enhance the trainee’s maneuvering capability, 
providing dynamic assessment during the task performance.
Method:
In this Endoscopic Navigation task, the learner enhances his maneuvering 
capabilities, navigating the endoscope and acquiring targets as they 
appear.  Target acquisition is achieved by fitting the scope’s ‘viewfinder’ 
to the target, taking into consideration distance, position and orientation. 
The required maneuvers range from simple to complex and the ‘How Am I 
Doing’ bar dynamically reflects the performance level.
Task Summary:
By performing this task, the learner can perfect his endoscope navigation 
skills in a focused manner within a stress-less, abstract, environment.


[TABLE]
| Skill: Endoscopic Navigation                                                 |
|:-----------------------------------------------------------------------------|
| Task 2 - Endoscopic Navigation                                               |
| 2                                                                            |
| Goal:                                                                        |
| The goal of this task is to enhance the trainee’s maneuvering capability,    |
| providing dynamic assessment during the task performance.                    |
| Method:                                                                      |
| In this Endoscopic Navigation task, the learner enhances his maneuvering     |
| capabilities, navigating the endoscope and acquiring targets as they         |
| appear.  Target acquisition is achieved by fitting the scope’s ‘viewfinder’  |
| to the target, taking into consideration distance, position and orientation. |
| The required maneuvers range from simple to complex and the ‘How Am I        |
| Doing’ bar dynamically reflects the performance level.                       |
| Task Summary:                                                                |
| By performing this task, the learner can perfect his endoscope navigation    |
| skills in a focused manner within a stress-less, abstract, environment.      |

[OCR]
GI Endoscopy - Fundamental

Skills Module

Skill: Endoscopic Navigation
Task 2 - Endoscopic Navigation

Goal:

The goal of this task is to enhance the trainee’s maneuvering capability,
providing dynamic assessment during the task performance.

Method:

In this Endoscopic Navigation task, the learner enhances his maneuvering
capabilities, navigating the endoscope and acquiring targets as they
appear. Target acquisition is achieved by fitting the scope’s ‘viewfinder’
to the target, taking into consideration distance, position and orientation.
The required maneuvers range from simple to complex and the ‘How Am |
Doing’ bar dynamically reflects the performance level.

Task Summary:

By performing this task, the learner can perfect his endoscope navigation
skills in a focused manner within a stress-less, abstract, environment.

surgicalscience GI Mentor


# Page 7

GI Endoscopy - Fundamental  
Skills Module
7
GI Mentor
Skill: Mucosal Evaluation  
Task 3 - Mucosal Evaluation, Basic
3
Goal: 
The goal of this task is to learn and practice complete mucosal 
evaluation, such as of the Lower GI Tract.
Method:
In the Mucosal Evaluation Basic task, the learner advances the scope 
as instructed and then visualizes the entire luminal surface on scope 
withdrawal. Scope control is required to keep the lumen centered while 
circumferentially assessing the lumen surface. Properly evaluated 
surface is indicated by lights over the surface turning green (Note that 
once the scope is fully withdrawn, the task is considered complete 
whether or not it was optimally performed).
Task Summary:
By performing this task, the learner acquires habits of a thorough 
mucosal evaluation.


[TABLE]
| Skill: Mucosal Evaluation                                                |
|:-------------------------------------------------------------------------|
| Task 3 - Mucosal Evaluation, Basic                                       |
| 3                                                                        |
| Goal:                                                                    |
| The goal of this task is to learn and practice complete mucosal          |
| evaluation, such as of the Lower GI Tract.                               |
| Method:                                                                  |
| In the Mucosal Evaluation Basic task, the learner advances the scope     |
| as instructed and then visualizes the entire luminal surface on scope    |
| withdrawal. Scope control is required to keep the lumen centered while   |
| circumferentially assessing the lumen surface. Properly evaluated        |
| surface is indicated by lights over the surface turning green (Note that |
| once the scope is fully withdrawn, the task is considered complete       |
| whether or not it was optimally performed).                              |
| Task Summary:                                                            |
| By performing this task, the learner acquires habits of a thorough       |
| mucosal evaluation.                                                      |

[OCR]
GI Endoscopy - Fundamental

Skills Module

Skill: Mucosal Evaluation
Task 3 - Mucosal Evaluation, Basic

Goal:

The goal of this task is to learn and practice complete mucosal
evaluation, such as of the Lower GI Tract.

Method:

In the Mucosal Evaluation Basic task, the learner advances the scope
as instructed and then visualizes the entire luminal surface on scope
withdrawal. Scope control is required to keep the lumen centered while
circumferentially assessing the lumen surface. Properly evaluated
surface is indicated by lights over the surface turning green (Note that
once the scope is fully withdrawn, the task is considered complete
whether or not it was optimally performed).

Task Summary:

By performing this task, the learner acquires habits of a thorough
mucosal evaluation.

—
L: |S

surgicalscience GI Mentor


# Page 8

GI Endoscopy - Fundamental  
Skills Module
8
GI Mentor
Skill: Mucosal Evaluation   
Task 4 - Mucosal Evaluation, Advanced I
4
Goal: 
The goal of this task is to perform a complete mucosal evaluation of 
the Lower GI Tract, inspecting the entire mucosal surface, and paying 
special attention to hidden or otherwise suspicious findings.
Method:
In this task, the learner advances the scope and then inspects the 
mucosal surface on scope withdrawal. Properly evaluated mucosal 
surface is indicated by the clearing of a rectangular pattern overlaying 
the entire surface. In certain locations, lesions are to be identified and 
particularly examined. A lesion is considered fairly examined when it 
turns into a check-marked image. This requires maintaining the lesion 
in the field of view for several seconds. (Note that once the scope is 
fully withdrawn, the task is considered complete whether or not it was 
optimally performed).
Task Summary:
By performing this task, the learner acquires habits of a thorough 
mucosal evaluation, paying special attention to suspicious findings 
during the evaluation.


[TABLE]
| Skill: Mucosal Evaluation                                                  |
|:---------------------------------------------------------------------------|
| Task 4 - Mucosal Evaluation, Advanced I                                    |
| 4                                                                          |
| Goal:                                                                      |
| The goal of this task is to perform a complete mucosal evaluation of       |
| the Lower GI Tract, inspecting the entire mucosal surface, and paying      |
| special attention to hidden or otherwise suspicious findings.              |
| Method:                                                                    |
| In this task, the learner advances the scope and then inspects the         |
| mucosal surface on scope withdrawal. Properly evaluated mucosal            |
| surface is indicated by the clearing of a rectangular pattern overlaying   |
| the entire surface. In certain locations, lesions are to be identified and |
| particularly examined. A lesion is considered fairly examined when it      |
| turns into a check-marked image. This requires maintaining the lesion      |
| in the field of view for several seconds. (Note that once the scope is     |
| fully withdrawn, the task is considered complete whether or not it was     |
| optimally performed).                                                      |
| Task Summary:                                                              |
| By performing this task, the learner acquires habits of a thorough         |
| mucosal evaluation, paying special attention to suspicious findings        |
| during the evaluation.                                                     |

[OCR]
GI Endoscopy - Fundamental

Skills Module

Skill: Mucosal Evaluation
Task 4 - Mucosal Evaluation, Advanced |

Goal:

The goal of this task is to perform a complete mucosal evaluation of
the Lower GI Tract, inspecting the entire mucosal surface, and paying
special attention to hidden or otherwise suspicious findings.

Method:

In this task, the learner advances the scope and then inspects the
mucosal surface on scope withdrawal. Properly evaluated mucosal
surface is indicated by the clearing of a rectangular pattern overlaying
the entire surface. In certain locations, lesions are to be identified and
particularly examined. A lesion is considered fairly examined when it
turns into a check-marked image. This requires maintaining the lesion
in the field of view for several seconds. (Note that once the scope is
fully withdrawn, the task is considered complete whether or not it was
optimally performed).

Task Summary:

By performing this task, the learner acquires habits of a thorough
mucosal evaluation, paying special attention to suspicious findings
during the evaluation.

surgicalscience GI Mentor


# Page 9

GI Endoscopy - Fundamental  
Skills Module
9
GI Mentor
Skill: Mucosal Evaluation   
Task 5 - Mucosal Evaluation, Advanced II 
5
Goal: 
The goal of this task is to perform a complete mucosal evaluation of 
the Lower GI Tract, detecting all the hidden or otherwise suspicious 
findings.
Method:
In this task, the learner advances the scope and then evaluates the 
mucosa on scope withdrawal. In certain locations, especially behind 
haustral folds, lesions are to be identified and particularly examined. A 
lesion is considered fairly examined when it turns into a check-marked 
image. This requires maintaining the lesion in the field of view for 
several seconds. (Note that once the scope is fully withdrawn, the task 
is considered complete whether or not it was optimally performed). 
The ‘How Am I Doing’ bar dynamically reflects the efficiency of lesion 
assessment and acquisition.
Task Summary:
By performing this task, the learner is expected to complete the 
mucosal evaluation in a timely manner, evaluate behind mucosal folds, 
and recognize all suspicious findings.


[TABLE]
| Skill: Mucosal Evaluation                                                 |
|:--------------------------------------------------------------------------|
| Task 5 - Mucosal Evaluation, Advanced II                                  |
| 5                                                                         |
| Goal:                                                                     |
| The goal of this task is to perform a complete mucosal evaluation of      |
| the Lower GI Tract, detecting all the hidden or otherwise suspicious      |
| findings.                                                                 |
| Method:                                                                   |
| In this task, the learner advances the scope and then evaluates the       |
| mucosa on scope withdrawal. In certain locations, especially behind       |
| haustral folds, lesions are to be identified and particularly examined. A |
| lesion is considered fairly examined when it turns into a check-marked    |
| image. This requires maintaining the lesion in the field of view for      |
| several seconds. (Note that once the scope is fully withdrawn, the task   |
| is considered complete whether or not it was optimally performed).        |
| The ‘How Am I Doing’ bar dynamically reflects the efficiency of lesion    |
| assessment and acquisition.                                               |
| Task Summary:                                                             |
| By performing this task, the learner is expected to complete the          |
| mucosal evaluation in a timely manner, evaluate behind mucosal folds,     |
| and recognize all suspicious findings.                                    |

[OCR]
GI Endoscopy - Fundamental

Skills Module

Skill: Mucosal Evaluation
Task 5 - Mucosal Evaluation, Advanced II

Goal:

The goal of this task is to perform a complete mucosal evaluation of
the Lower GI Tract, detecting all the hidden or otherwise suspicious
findings.

Method:

In this task, the learner advances the scope and then evaluates the
mucosa on scope withdrawal. In certain locations, especially behind
haustral folds, lesions are to be identified and particularly examined. A
lesion is considered fairly examined when it turns into a check-marked
image. This requires maintaining the lesion in the field of view for
several seconds. (Note that once the scope is fully withdrawn, the task
is considered complete whether or not it was optimally performed).
The ‘How Am | Doing’ bar dynamically reflects the efficiency of lesion
assessment and acquisition.

Task Summary:

By performing this task, the learner is expected to complete the
mucosal evaluation in a timely manner, evaluate behind mucosal folds,
and recognize all suspicious findings.

surgicalscience GI Mentor


# Page 10

GI Endoscopy - Fundamental  
Skills Module
10
GI Mentor
Skill: Retroflexion   
Task 6 - Endoscopic Retroflexion, Basic
6
Goal: 
The goal of this task is to learn the optimal motions for retroflexion and 
practice working in a retroflex position.
Method:
In the Endoscope Retroflexion Basic Task, the learner deflects the 
scope tip to perform retroflexion when instructed, then, navigates 
the scope while retroflexed in order to remove spheres. A sphere is 
removed by entering it and holding the scope steady for 3 seconds. 
At some points of the task, the learner is required to straighten the 
scope and restore its neutral position before retroflexing again.
Task Summary:
By performing the task, the learner practices optimal retroflexion and 
acquires the skill of working in a retroflexed position, where forward/
backwards motions are reversed.


[TABLE]
| Skill: Retroflexion                                                        |
|:---------------------------------------------------------------------------|
| Task 6 - Endoscopic Retroflexion, Basic                                    |
| 6                                                                          |
| Goal:                                                                      |
| The goal of this task is to learn the optimal motions for retroflexion and |
| practice working in a retroflex position.                                  |
| Method:                                                                    |
| In the Endoscope Retroflexion Basic Task, the learner deflects the         |
| scope tip to perform retroflexion when instructed, then, navigates         |
| the scope while retroflexed in order to remove spheres. A sphere is        |
| removed by entering it and holding the scope steady for 3 seconds.         |
| At some points of the task, the learner is required to straighten the      |
| scope and restore its neutral position before retroflexing again.          |
| Task Summary:                                                              |
| By performing the task, the learner practices optimal retroflexion and     |
| acquires the skill of working in a retroflexed position, where forward/    |
| backwards motions are reversed.                                            |

[OCR]
GI Endoscopy - Fundamental

Skills Module

Task 6 - Endoscopic Retroflexion, Basic

Goal:

The goal of this task is to learn the optimal motions for retroflexion and
practice working in a retroflex position.

Method:

In the Endoscope Retroflexion Basic Task, the learner deflects the
scope tip to perform retroflexion when instructed, then, navigates
the scope while retroflexed in order to remove spheres. A sphere is
removed by entering it and holding the scope steady for 3 seconds.

At some points of the task, the learner is required to straighten the
scope and restore its neutral position before retroflexing again.
Task Summary:

By performing the task, the learner practices optimal retroflexion and
acquires the skill of working in a retroflexed position, where forward/
backwards motions are reversed.

surgical GI Mentor


# Page 11

GI Endoscopy - Fundamental  
Skills Module
11
GI Mentor
Skill: Retroflexion 
Task 7 - Endoscopic Retroflexion, Advanced
7
Goal: 
The goal of this task is to obtain an accurate scope control in a 
retroflexed scope position.
Method:
In the Endoscope Retroflexion Advanced Task, the learner navigates 
the scope between targets while retroflexed and maneuvers the scope 
to acquire targets. When the scope is approaching a target, a biopsy 
forceps automatically appears. The learner has to direct the scope so 
that the forceps will establish contact with the green area of the target, 
and by that, making the target disappear. 
The learner has to avoid contact with the red area of the target and the 
walls of the environment.
Task Summary:
By performing the task, the learner acquires the required skills for 
accurately control the scope in a retroflexed position. 


[TABLE]
| Skill: Retroflexion                                                        |
|:---------------------------------------------------------------------------|
| Task 7 - Endoscopic Retroflexion, Advanced                                 |
| 7                                                                          |
| Goal:                                                                      |
| The goal of this task is to obtain an accurate scope control in a          |
| retroflexed scope position.                                                |
| Method:                                                                    |
| In the Endoscope Retroflexion Advanced Task, the learner navigates         |
| the scope between targets while retroflexed and maneuvers the scope        |
| to acquire targets. When the scope is approaching a target, a biopsy       |
| forceps automatically appears. The learner has to direct the scope so      |
| that the forceps will establish contact with the green area of the target, |
| and by that, making the target disappear.                                  |
| The learner has to avoid contact with the red area of the target and the   |
| walls of the environment.                                                  |
| Task Summary:                                                              |
| By performing the task, the learner acquires the required skills for       |
| accurately control the scope in a retroflexed position.                    |

[OCR]
GI Endoscopy - Fundamental

Skills Module

Skill: Retroflexion
Task 7 - Endoscopic Retroflexion, Advanced

Goal:

The goal of this task is to obtain an accurate scope control in a
retroflexed scope position.

Method:

In the Endoscope Retroflexion Advanced Task, the learner navigates
the scope between targets while retroflexed and maneuvers the scope
to acquire targets. When the scope is approaching a target, a biopsy
forceps automatically appears. The learner has to direct the scope so
that the forceps will establish contact with the green area of the target,
and by that, making the target disappear.

The learner has to avoid contact with the red area of the target and the
walls of the environment.

Task Summary:

By performing the task, the learner acquires the required skills for
accurately control the scope in a retroflexed position.

surgicalscience GI Mentor


# Page 12

GI Endoscopy - Fundamental  
Skills Module
12
GI Mentor
Skill: Targeting 
Task 8 - Targeting (with a Tool), Basic
8
Goal: 
The goal of this task is to learn and refine scope navigation and 
targeting with a tool.
Method:
In the Basic Targeting task, the learner navigates the lower GI tract 
encountering targets on ‘tumors’ along the colon. Once close to a 
target, the learner advances the endoscopic tool to touch the target.
A ‘Line of Sight’ from the tool’s tip assists the learner in predicting its 
path and refining the approach towards the target. Upon touching 
a target with the tool the scope and tool must be held in place for 2 
seconds to acquire the target.
Navigating the colon the learner is expected to retract the tool and 
keep it inside the working channel, in order to avoid tool contact with 
the mucosal surface. 
Task Summary:
By performing the task, the learner practices efficient targeting and 
acquires the skill of accurately working with a tool without causing 
damage to tissue.


[TABLE]
| Skill: Targeting                                                            |
|:----------------------------------------------------------------------------|
| Task 8 - Targeting (with a Tool), Basic                                     |
| 8                                                                           |
| Goal:                                                                       |
| The goal of this task is to learn and refine scope navigation and           |
| targeting with a tool.                                                      |
| Method:                                                                     |
| In the Basic Targeting task, the learner navigates the lower GI tract       |
| encountering targets on ‘tumors’ along the colon. Once close to a           |
| target, the learner advances the endoscopic tool to touch the target.       |
| A ‘Line of Sight’ from the tool’s tip assists the learner in predicting its |
| path and refining the approach towards the target. Upon touching            |
| a target with the tool the scope and tool must be held in place for 2       |
| seconds to acquire the target.                                              |
| Navigating the colon the learner is expected to retract the tool and        |
| keep it inside the working channel, in order to avoid tool contact with     |
| the mucosal surface.                                                        |
| Task Summary:                                                               |
| By performing the task, the learner practices efficient targeting and       |
| acquires the skill of accurately working with a tool without causing        |
| damage to tissue.                                                           |

[OCR]
GI Endoscopy - Fundamental

Skills Module

Skill: Targeting
Task 8 - Targeting (with a Tool), Basic

Goal:

The goal of this task is to learn and refine scope navigation and
targeting with a tool.

Method:

In the Basic Targeting task, the learner navigates the lower Gl tract
encountering targets on ‘tumors’ along the colon. Once close to a
target, the learner advances the endoscopic tool to touch the target.

A ‘Line of Sight’ from the tool’s tip assists the learner in predicting its
path and refining the approach towards the target. Upon touching

a target with the tool the scope and tool must be held in place for 2
seconds to acquire the target.

Navigating the colon the learner is expected to retract the tool and
keep it inside the working channel, in order to avoid tool contact with
the mucosal surface.

Task Summary:

By performing the task, the learner practices efficient targeting and
acquires the skill of accurately working with a tool without causing
damage to tissue.

surgicalscience GI Mentor


# Page 13

GI Endoscopy - Fundamental  
Skills Module
13
GI Mentor
Skill: Targeting 
Task 9 - Targeting (with a Tool), Advanced
9
Goal: 
The goal of this task is to gain proficiency in accurately targeting with a 
tool in the lower GI.
Method:
In the Advanced Targeting task, the learner navigates the lower GI 
tract, encountering targets on ‘tumors’ along the colon. 
Manipulating the scope and tool to touch only the green center of the 
target for several seconds, the target will be acquired. 
The learner is expected to avoid navigating with a protruding tool, 
avoid tool contact with the mucosal surface, and avoid contact with the 
target’s red circumference.
Task Summary:
By performing this task, the learner gains experience in accurately, 
safely and efficiently targeting an endoscopic tool in the lower GI tract. 


[TABLE]
| Skill: Targeting                                                            |
|:----------------------------------------------------------------------------|
| Task 9 - Targeting (with a Tool), Advanced                                  |
| 9                                                                           |
| Goal:                                                                       |
| The goal of this task is to gain proficiency in accurately targeting with a |
| tool in the lower GI.                                                       |
| Method:                                                                     |
| In the Advanced Targeting task, the learner navigates the lower GI          |
| tract, encountering targets on ‘tumors’ along the colon.                    |
| Manipulating the scope and tool to touch only the green center of the       |
| target for several seconds, the target will be acquired.                    |
| The learner is expected to avoid navigating with a protruding tool,         |
| avoid tool contact with the mucosal surface, and avoid contact with the     |
| target’s red circumference.                                                 |
| Task Summary:                                                               |
| By performing this task, the learner gains experience in accurately,        |
| safely and efficiently targeting an endoscopic tool in the lower GI tract.  |

[OCR]
GI Endoscopy - Fundamental

Skills Module

Skill: Targeting
Task 9 - Targeting (with a Tool), Advanced

Goal:

The goal of this task is to gain proficiency in accurately targeting with a
tool in the lower Gl.

Method:

In the Advanced Targeting task, the learner navigates the lower Gl
tract, encountering targets on ‘tumors’ along the colon.

Manipulating the scope and tool to touch only the green center of the
target for several seconds, the target will be acquired.

The learner is expected to avoid navigating with a protruding tool,
avoid tool contact with the mucosal surface, and avoid contact with the
target's red circumference.

Task Summary:

By performing this task, the learner gains experience in accurately,
safely and efficiently targeting an endoscopic tool in the lower Gl tract.

sanpcal

surgicalscience GI Mentor


# Page 14

GI Endoscopy - Fundamental  
Skills Module
14
GI Mentor
Skill: Loop Reduction 
Task 10 - Loop Reduction
10
Goal: 
The goal of this task is to identify when a colon loop is formed and to 
effectively perform endoscopic maneuvers to reduce the loop.
Method:
In this task, the learner is expected to complete an endoscopic 
navigation to the cecum, and into the terminal ileum. He should identify 
when a loop is formed as the scope tip stops moving although the scope 
is being pushed/pulled. 
The learner should then perform a loop reduction maneuver, applying 
clockwise or counterclockwise torque while withdrawing the scope, 
and relying on paradoxical movement as an indication the loop is being 
effectively reduced.   When the loop is fully reduced the learner is 
expected to resume forward navigation towards the cecum.
Three loops are formed along the navigation.  A loop indicator is 
available to assist with identification of the loop status and whether it is 
being effectively reduced.
Task Summary:
By performing this task, the learner gains experience in recognizing 
when colon loops are formed and performing effective loop reduction 
maneuvers until forward navigation can be resumed.      


[TABLE]
| Skills Module                                                                |
|:-----------------------------------------------------------------------------|
| Skill: Loop Reduction                                                        |
| Task 10 - Loop Reduction                                                     |
| 10                                                                           |
| Goal:                                                                        |
| The goal of this task is to identify when a colon loop is formed and to      |
| effectively perform endoscopic maneuvers to reduce the loop.                 |
| Method:                                                                      |
| In this task, the learner is expected to complete an endoscopic              |
| navigation to the cecum, and into the terminal ileum. He should identify     |
| when a loop is formed as the scope tip stops moving although the scope       |
| is being pushed/pulled.                                                      |
| The learner should then perform a loop reduction maneuver, applying          |
| clockwise or counterclockwise torque while withdrawing the scope,            |
| and relying on paradoxical movement as an indication the loop is being       |
| effectively reduced.   When the loop is fully reduced the learner is         |
| expected to resume forward navigation towards the cecum.                     |
| Three loops are formed along the navigation.  A loop indicator is            |
| available to assist with identification of the loop status and whether it is |
| being effectively reduced.                                                   |
| Task Summary:                                                                |
| By performing this task, the learner gains experience in recognizing         |
| when colon loops are formed and performing effective loop reduction          |
| maneuvers until forward navigation can be resumed.                           |

[OCR]
GI Endoscopy - Fundamental

Skills Module

Skill: Loop Reduction
Task 10 - Loop Reduction

Goal:

The goal of this task is to identify when a colon loop is formed and to
effectively perform endoscopic maneuvers to reduce the loop.

Method:

In this task, the learner is expected to complete an endoscopic
navigation to the cecum, and into the terminal ileum. He should identify
when a loop is formed as the scope tip stops moving although the scope
is being pushed/pulled.

The learner should then perform a loop reduction maneuver, applying
clockwise or counterclockwise torque while withdrawing the scope,

and relying on paradoxical movement as an indication the loop is being
effectively reduced. When the loop is fully reduced the learner is
expected to resume forward navigation towards the cecum.

Three loops are formed along the navigation. A loop indicator is
available to assist with identification of the loop status and whether it is
being effectively reduced.

Task Summary:

By performing this task, the learner gains experience in recognizing
when colon loops are formed and performing effective loop reduction
maneuvers until forward navigation can be resumed.

surgicalscience GI Mentor