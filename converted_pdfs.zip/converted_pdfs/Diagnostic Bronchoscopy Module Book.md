

# Page 1

Diagnostic Bronchoscopy Module
1
BRONCH Mentor
Introduction
The BRONCH Mentor Diagnostic Bronchoscopy Module provides  
a comprehensive solution for hands-on training in all aspects of diagnostic 
bronchoscopies, for team and solo training alike.
This module provides an all-inclusive training environment, where the most 
extensive clinical environment is featured within a supporting educational 
setting. Six virtual patient cases are featured; within each, the trainee is free to 
inspect, analyze and perform, according to his clinical judgment.
The BRONCH simulation offers:
	 Realistic bronchoscopic experience – featuring an actual scope, realistic 
video display and true physical behavior of scope, endoscopic tools and 
fluids. A responsive virtual patient is featured; one that will cough, bleed, 
stress or deteriorate to hemodynamic complications and respiratory 
depression in accordance with the trainee’s performance.
	 Comprehensive patient environment – featuring detailed anatomy and 
physiology, complete patient management and active patient monitoring. A 
random factor alters the virtual patient’s characteristics with each case run. 
	 Didactic options enhancing trainee understanding – including bronchial 
segments labeling (descriptive and numeric), real-time guidance with 
patient safety and equipment safety alerts, an external 3D Map dynamically 
visualizing the scope within the bronchial tree, an anatomy atlas, and 
performance objectives capturing and reporting.
Consulted on the development of this module:
Eric S Edell MD, Mayo Clinic, Rochester, MN, USA 
Gerard A. Silvestri MD, MS, Medical University of South Carolina, Charleston, SC, USA
Thomas Gildea MD, MS, Cleveland Clinic, Cleveland, OH, USA
Michael S. Machuzak MD, Cleveland Clinic, Cleveland, OH, USA
David Feller-Kopman MD, Johns Hopkins Hospital, Baltimore, MD, USA
James Goldring MD, Royal Free Hospital, London, UK
J. Scott Ferguson MD, University of Wisconsin-Madison, Madison, WI, USA
Yehuda A. Schwarz MD, Sourasky Medical Center, Tel-Aviv, Israel
Tiberiu Shulimzon MD, Sheba Medical Center, Tel Hashomer, Israel


[TABLE]
| Introduction                                                                         |
|:-------------------------------------------------------------------------------------|
| The BRONCH Mentor Diagnostic Bronchoscopy Module provides                            |
| a comprehensive solution for hands-on training in all aspects of diagnostic          |
| bronchoscopies, for team and solo training alike.                                    |
| This module provides an all-inclusive training environment, where the most           |
| extensive clinical environment is featured within a supporting educational           |
| setting. Six virtual patient cases are featured; within each, the trainee is free to |
| inspect, analyze and perform, according to his clinical judgment.                    |
| The BRONCH simulation offers:                                                        |
|  Realistic bronchoscopic experience – featuring an actual scope, realistic                                                                                      |
| video display and true physical behavior of scope, endoscopic tools and              |

[TABLE]
| inspect, analyze and perform, according to his clinical judgment.              |
|:-------------------------------------------------------------------------------|
| The BRONCH simulation offers:                                                  |
|  Realistic bronchoscopic experience – featuring an actual scope, realistic                                                                                |
| video display and true physical behavior of scope, endoscopic tools and        |
| fluids. A responsive virtual patient is featured; one that will cough, bleed,  |
| stress or deteriorate to hemodynamic complications and respiratory             |
| depression in accordance with the trainee’s performance.                       |
|  Comprehensive patient environment – featuring detailed anatomy and                                                                                |
| physiology, complete patient management and active patient monitoring. A       |
| random factor alters the virtual patient’s characteristics with each case run. |
|  Didactic options enhancing trainee understanding – including bronchial                                                                                |
| segments labeling (descriptive and numeric), real-time guidance with           |
| patient safety and equipment safety alerts, an external 3D Map dynamically     |
| visualizing the scope within the bronchial tree, an anatomy atlas, and         |
| performance objectives capturing and reporting.                                |

[OCR_TABLE]
Intro

[OCR]
Diagnostic Bronchoscopy Module

Introduction

The BRONCH Mentor Diagnostic Bronchoscopy Module provides
a comprehensive solution for hands-on training in all aspects of diagnostic
bronchoscopies, for team and solo training alike.

This module provides an all-inclusive training environment, where the most
extensive clinical environment is featured within a supporting educational
setting. Six virtual patient cases are featured; within each, the trainee is free to
inspect, analyze and perform, according to his clinical judgment.

The BRONCH simulation offers:

= Realistic bronchoscopic experience — featuring an actual scope, realistic
video display and true physical behavior of scope, endoscopic tools and
fluids. A responsive virtual patient is featured; one that will cough, bleed,
stress or deteriorate to hemodynamic complications and respiratory
depression in accordance with the trainee’s performance.

= Comprehensive patient environment - featuring detailed anatomy and
physiology, complete patient management and active patient monitoring. A
random factor alters the virtual patient’s characteristics with each case run.

= Didactic options enhancing trainee understanding — including bronchial
segments labeling (descriptive and numeric), real-time guidance with
patient safety and equipment safety alerts, an external 3D Map dynamically
visualizing the scope within the bronchial tree, an anatomy atlas, and
performance objectives capturing and reporting.

Consulted on the development of this module:

Eric S Edell MD, Mayo Clinic, Rochester, MN, USA

Gerard A. Silvestri MD, MS, Medical University of South Carolina, Charleston, SC, USA
Thomas Gildea MD, MS, Cleveland Clinic, Cleveland, OH, USA

Michael S. Machuzak MD, Cleveland Clinic, Cleveland, OH, USA

David Feller-Kopman MD, Johns Hopkins Hospital, Baltimore, MD, USA

James Goldring MD, Royal Free Hospital, London, UK

J. Scott Ferguson MD, University of Wisconsin-Madison, Madison, WI, USA

Yehuda A. Schwarz MD, Sourasky Medical Center, Tel-Aviv, Israel

Tiberiu Shulimzon MD, Sheba Medical Center, Tel Hashomer, Israel

surgical BRONCH Mentor


# Page 2

Diagnostic Bronchoscopy Module
2
BRONCH Mentor
Educational Goals
	
 Learning and practicing the complete workflow of diagnostic bronchoscopy, 
from scope introduction through patient management and complete airway 
inspection, to selecting desired sampling methods and successfully obtaining 
tissue samples from the relevant sites.
	
 Developing methodical habits to safely and efficiently inspect and obtain 
tissue samples, while maintaining patient safety and avoiding risks of 
damaging the equipment.
	
 Practicing in a true to life, unrestricted environment where operational or 
clinical mistakes can be made and learnt from. 
	
 Gaining experience in all aspects of diagnostic bronchoscopy to acquire 
confidence and reach competence level prior to performing on real patients. 
 
Learning Objectives:
	
 To practice the complete workflow of diagnostic bronchoscopy procedure
	
 To gain experience in endobronchial scope navigation in varied anatomies
	
 To perform a complete airway inspection
	
 To assess the clinical scenario and use the available sampling methods 
accordingly
	
 To practice endobronchial and transbronchial tissue sampling using biopsy 
forceps, cytology brush, aspirating needle and BAL 
	
 To safely and efficiently obtain tissue samples, avoiding risks to patient and 
equipment 
	
 To sedate and maintain virtual patient’s condition, avoiding hemodynamic and 
respiratory complications 
	
 To practice on a variety of virtual patients, each exhibiting a unique anatomy 
and pathologies and altering a response to moderate sedation


[TABLE]
| Educational Goals                                                            |
|:-----------------------------------------------------------------------------|
|  Learning and practicing the complete workflow of diagnostic bronchoscopy,                                                                              |
| from scope introduction through patient management and complete airway       |
| inspection, to selecting desired sampling methods and successfully obtaining |
| tissue samples from the relevant sites.                                      |
|  Developing methodical habits to safely and efficiently inspect and obtain                                                                              |
| tissue samples, while maintaining patient safety and avoiding risks of       |
| damaging the equipment.                                                      |
|  Practicing in a true to life, unrestricted environment where operational or                                                                              |
| clinical mistakes can be made and learnt from.                               |
|  Gaining experience in all aspects of diagnostic bronchoscopy to acquire                                                                              |
| confidence and reach competence level prior to performing on real patients.  |

[OCR]
Diagnostic Bronchoscopy Module

Educational Goals

= Learning and practicing the complete workflow of diagnostic bronchoscopy,
from scope introduction through patient management and complete airway
inspection, to selecting desired sampling methods and successfully obtaining
tissue samples from the relevant sites.

= Developing methodical habits to safely and efficiently inspect and obtain
tissue samples, while maintaining patient safety and avoiding risks of
damaging the equipment.

= Practicing in a true to life, unrestricted environment where operational or
clinical mistakes can be made and learnt from.

= Gaining experience in all aspects of diagnostic bronchoscopy to acquire
confidence and reach competence level prior to performing on real patients.

Learning Objectives:

= To practice the complete workflow of diagnostic bronchoscopy procedure
= To gain experience in endobronchial scope navigation in varied anatomies
= To perform a complete airway inspection

= To assess the clinical scenario and use the available sampling methods
accordingly

= To practice endobronchial and transbronchial tissue sampling using biopsy
forceps, cytology brush, aspirating needle and BAL

= To safely and efficiently obtain tissue samples, avoiding risks to patient and
equipment

= To sedate and maintain virtual patient’s condition, avoiding hemodynamic and
respiratory complications

= To practice on a variety of virtual patients, each exhibiting a unique anatomy
and pathologies and altering a response to moderate sedation

surgical BRONCH Mentor


# Page 3

Diagnostic Bronchoscopy Module
3
BRONCH Mentor
Screen Layout and Features
1 - Main View
	
 Displaying the scope’s video
	
 Upon ‘Freeze’ a small video display appears in the upper left corner and over 
the frozen main view.
	
 Elapsed time is indicated in the upper right corner.
2 - Main View Controls
a.	 Full Screen enlarges the main view display as a ‘procedure restricted’ 
view, removing all aids that are unavailable during an actual bronchoscopic 
procedure.
b.	Compass dynamically displays, over the main view, an anatomical compass 
indicating body coordinates (Anterior, Posterior, Left and Right).
Note: Patient safety related alerts are displayed over the main view.
1
3
5
7
6
2
a
e
c
b
d
4
4


[TABLE]
| 7                                                                           |
|:----------------------------------------------------------------------------|
| 1 - Main View                                                               |
|  Displaying the scope’s video                                                                             |
|  Upon ‘Freeze’ a small video display appears in the upper left corner and over                                                                             |
| the frozen main view.                                                       |
|  Elapsed time is indicated in the upper right corner.                                                                             |
| Note: Patient safety related alerts are displayed over the main view.       |
| 2 - Main View Controls                                                      |
| a.  Full Screen enlarges the main view display as a ‘procedure restricted’  |
| view, removing all aids that are unavailable during an actual bronchoscopic |
| procedure.                                                                  |
| b.  Compass dynamically displays, over the main view, an anatomical compass |
| indicating body coordinates (Anterior, Posterior, Left and Right).          |

[OCR]
Diagnostic Bronchoscopy Module

Screen Layout and Features

olfel[a] fe) [2|

1- Main View
= Displaying the scope’s video

= Upon ‘Freeze’ a small video display appears in the upper left corner and over
the frozen main view.

= Elapsed time is indicated in the upper right corner.

Note: Patient safety related alerts are displayed over the main view.

2 - Main View Controls

a. Full Screen enlarges the main view display as a ‘procedure restricted’
view, removing all aids that are unavailable during an actual bronchoscopic
procedure.

b. Compass dynamically displays, over the main view, an anatomical compass
indicating body coordinates (Anterior, Posterior, Left and Right).

surgicalscience BRONCH Mentor


# Page 4

Diagnostic Bronchoscopy Module
4
BRONCH Mentor
c.	 Labels display the bronchial segments labels over the main view. Two 
labeling conventions are available: descriptive-numeric and advanced-
numeric which labels the sub-segments one level deeper within the 
lungs.
d.	Stop Breathing stops the virtual patient’s breathing, allowing for easier 
performance of the diagnostic maneuvers.
e.	 Transparency turns the airway wall transparent revealing lymph nodes 
and vascular structures behind it (applies only to cases where lymph 
nodes can be sampled). TBNA can be performed regardless of the 
Transparency feature.
Note: The transparency region is visible only when the scope is close to the 
immediate environment of a lymph node.
3 - Patient Management Region
The Patient Management Region incorporates patient monitoring 
and management that is complementary to the bronchoscopy and 
is not performed via the bronchoscope. The virtual patient reacts to 
the implementation of sedatives and other actions as reflected in the 
consciousness level and vital signs values. 
The Patient Management options include:
a.	 Moderate Sedation administration allows for the selection of 
benzodiazepines, narcotics, or reversal agents from the list and for 
the setting and administering of the desired dosage. The affect on the 
virtual patient occurs according to each drug time to affect, and varies 
each time the case is run. All administered sedatives are registered and 
the current total is constantly displayed. 
a
c
d
b


[TABLE]
| c.  Labels display the bronchial segments labels over the main view. Two      |
|:------------------------------------------------------------------------------|
| labeling conventions are available: descriptive-numeric and advanced-         |
| numeric which labels the sub-segments one level deeper within the             |
| lungs.                                                                        |
| d.  Stop Breathing stops the virtual patient’s breathing, allowing for easier |
| performance of the diagnostic maneuvers.                                      |
| e.  Transparency turns the airway wall transparent revealing lymph nodes      |
| and vascular structures behind it (applies only to cases where lymph          |
| nodes can be sampled). TBNA can be performed regardless of the                |
| Transparency feature.                                                         |

[OCR_TABLE]
lal

[OCR_TABLE]
NUIT
luno

[OCR]
Diagnostic Bronchoscopy Module

c. Labels display the bronchial segments labels over the main view. Two
labeling conventions are available: descriptive-numeric and advanced-
numeric which labels the sub-segments one level deeper within the
lungs.

d. Stop Breathing stops the virtual patient’s breathing, allowing for easier
performance of the diagnostic maneuvers.

e. Transparency turns the airway wall transparent revealing lymph nodes
and vascular structures behind it (applies only to cases where lymph
nodes can be sampled). TBNA can be performed regardless of the
Transparency feature.

Note: The transparency region is visible only when the scope is close to the
immediate environment of a lymph node.

3 - Patient Management Region

Midazolam > He

Time Since Total

The Patient Management Region incorporates patient monitoring
and management that is complementary to the bronchoscopy and

is not performed via the bronchoscope. The virtual patient reacts to
the implementation of sedatives and other actions as reflected in the
consciousness level and vital signs values.

The Patient Management options include:

a. Moderate Sedation administration allows for the selection of
benzodiazepines, narcotics, or reversal agents from the list and for
the setting and administering of the desired dosage. The affect on the
virtual patient occurs according to each drug time to affect, and varies
each time the case is run. All administered sedatives are registered and
the current total is constantly displayed.

surgical BRONCH Mentor


# Page 5

Diagnostic Bronchoscopy Module
5
BRONCH Mentor
b.	Vital Signs monitoring via the constantly updating values of heart rate, 
blood pressure, respiratory rate, SpO2 and ECG. The vital signs values 
vary according to patient and treatment, and may go as low or high 
as severe hemodynamic complications, requiring the stopping of the 
procedure.
c.	 Consciousness Level monitoring using the 1 to 6 Ramsey scale, allows 
for ongoing inspection of patient condition and adaptation of moderate 
sedation regime accordingly.
d.	Oxygen Supplement administration allows for administering 0 to 10 L/
min oxygen supplement, affecting the SpO2 level. 
 
Note: As the Patient Management is part of the actual procedure, all the 
above segments are also available in Full Screen mode.
Note:  The Patient Management was designed to provide a real opportunity 
for team training, providing each team member with his designated role to 
actively perform during the simulation.
4 - Complementary Displays 
Selection from the menu opened using the arrow button on the left. Upon 
selection, the controls for each display are available to the right. 
Optional displays: 
	 3D-Map – an external dynamic 3D visualization of the scope within the 
bronchial tree. Controls such as zoom, pan, rotate and more are available 
to its right.
	 Anatomy Atlas – a static display of the chest anatomy divided into layers 
of organs and anatomical structures. Controls such as layers filtering, 
zoom, pan, rotate and more are available to its right.
	 Imaging Results / CT Browser – shows relevant images for the virtual 
patient such as X-rays, CT scan slices, or an actual CT scan. Controls 
such as plane orientation selection (Axial, Coronal and Sagittal) are 
available for the actual CT scans.
Note:  Once a control type is selected from display’s right, the touch screen 
itself is used for the actual manipulation of the display.


[TABLE]
| b.  Vital Signs monitoring via the constantly updating values of heart rate,   |
|:-------------------------------------------------------------------------------|
| blood pressure, respiratory rate, SpO2 and ECG. The vital signs values         |
| vary according to patient and treatment, and may go as low or high             |
| as severe hemodynamic complications, requiring the stopping of the             |
| procedure.                                                                     |
| c.  Consciousness Level monitoring using the 1 to 6 Ramsey scale, allows       |
| for ongoing inspection of patient condition and adaptation of moderate         |
| sedation regime accordingly.                                                   |
| d.  Oxygen Supplement administration allows for administering 0 to 10 L/       |
| min oxygen supplement, affecting the SpO2 level.                               |

[TABLE]
| selection, the controls for each display are available to the right.      |
|:--------------------------------------------------------------------------|
| Optional displays:                                                        |
|  3D-Map – an external dynamic 3D visualization of the scope within the                                                                           |
| bronchial tree. Controls such as zoom, pan, rotate and more are available |
| to its right.                                                             |
|  Anatomy Atlas – a static display of the chest anatomy divided into layers                                                                           |
| of organs and anatomical structures. Controls such as layers filtering,   |
| zoom, pan, rotate and more are available to its right.                    |
|  Imaging Results / CT Browser – shows relevant images for the virtual                                                                           |
| patient such as X-rays, CT scan slices, or an actual CT scan. Controls    |
| such as plane orientation selection (Axial, Coronal and Sagittal) are     |
| available for the actual CT scans.                                        |

[OCR_TABLE]
eres

[OCR]
Diagnostic Bronchoscopy Module

b. Vital Signs monitoring via the constantly updating values of heart rate,
blood pressure, respiratory rate, SpO2 and ECG. The vital signs values
vary according to patient and treatment, and may go as low or high
as severe hemodynamic complications, requiring the stopping of the
procedure.

c. Consciousness Level monitoring using the 1 to 6 Ramsey scale, allows
for ongoing inspection of patient condition and adaptation of moderate
sedation regime accordingly.

d. Oxygen Supplement administration allows for administering 0 to 10 L/
min oxygen supplement, affecting the SpO2 level.

Note: As the Patient Management is part of the actual procedure, all the
above segments are also available in Full Screen mode.

Note: The Patient Management was designed to provide a real opportunity
for team training, providing each team member with his designated role to
actively perform during the simulation.

4 - Complementary Displays

Selection from the menu opened using the arrow button on the left. Upon
selection, the controls for each display are available to the right.

Optional displays:

= 3D-Map - an external dynamic 3D visualization of the scope within the
bronchial tree. Controls such as zoom, pan, rotate and more are available
to its right.

= Anatomy Atlas — a static display of the chest anatomy divided into layers
of organs and anatomical structures. Controls such as layers filtering,
zoom, pan, rotate and more are available to its right.

= Imaging Results / CT Browser — shows relevant images for the virtual
patient such as X-rays, CT scan slices, or an actual CT scan. Controls
such as plane orientation selection (Axial, Coronal and Sagittal) are
available for the actual CT scans.

Note: Once a control type is selected from display’s right, the touch screen
itself is used for the actual manipulation of the display.

surgical BRONCH Mentor


# Page 6

Diagnostic Bronchoscopy Module
6
BRONCH Mentor
5 - Virtual Instructor 
The Virtual Instructor provides real-time warnings, comments, and tips 
regarding procedure performance efficiency as well as mild patient 
condition notices.
6 - Tool Panel
The master tool and the syringe are used in this module to simulate all 
tools. Following the master tool insertion into the scope’s working channel 
and menu selection of the desired endoscopic tool, the simulated tool 
appears inside the anatomy and its tool panel is displayed.
Note:  The syringe, along with its tool panel, becomes active in the 
simulation upon inserting the syringe into the working channel.
The Forceps, Brush and Needle tool 
panels (1, 2 and 3) display each tool’s 
states and options. All three allow for 
virtual activation, overriding  the master 
tool handle to facilitate easier solo 
training.
Note: The tool panels indicate whether 
Virtual Activation is on, the current tool 
state and additional control options when 
applicable.
The Needle tool panel (3) displays the 
following additional controls:
Lock locks the needle out of its sheath. 
It is performed via the touch screen and 
is a mandatory step in simulated TBNA 
performance.
1
2
3
Note: The Lock button becomes enabled only when the needle is pushed 
completely out of its sheath.
Secure Proximally simulates manually holding together the proximal portion 
of the needle’s sheath in the working channel, allowing for advancing the 
scope and needle as one.
Suction is performed by pulling the actual syringe piston open to Aspirate 
and pushing it close to Release. Applying suction is a mandatory step in 
simulated TBNA performance.


[TABLE]
| Diagnostic Bronchoscopy Module                                              |
|:----------------------------------------------------------------------------|
| 5 - Virtual Instructor                                                      |
| The Virtual Instructor provides real-time warnings, comments, and tips      |
| regarding procedure performance efficiency as well as mild patient          |
| condition notices.                                                          |
| 6 - Tool Panel                                                              |
| The master tool and the syringe are used in this module to simulate all     |
| tools. Following the master tool insertion into the scope’s working channel |
| and menu selection of the desired endoscopic tool, the simulated tool       |
| appears inside the anatomy and its tool panel is displayed.                 |
| Note:  The syringe, along with its tool panel, becomes active in the        |
| simulation upon inserting the syringe into the working channel.             |

[TABLE]
|    | Note:  The syringe, along with its tool panel, becomes active in the   |                                            |
|:---|:-----------------------------------------------------------------------|:-------------------------------------------|
|    | simulation upon inserting the syringe into the working channel.        |                                            |
| 1  | 3                                                                      | The Forceps, Brush and Needle tool         |
|    |                                                                        | panels (1, 2 and 3) display each tool’s    |
|    |                                                                        | states and options. All three allow for    |
|    |                                                                        | virtual activation, overriding  the master |
|    |                                                                        | tool handle to facilitate easier solo      |
|    |                                                                        | training.                                  |
|    |                                                                        | Note: The tool panels indicate whether     |
|    |                                                                        | Virtual Activation is on, the current tool |
| 2  |                                                                        |                                            |
|    |                                                                        | state and additional control options when  |
|    |                                                                        | applicable.                                |
|    |                                                                        | The Needle tool panel (3) displays the     |
|    |                                                                        | following additional controls:             |
|    |                                                                        | Lock locks the needle out of its sheath.   |
|    |                                                                        | It is performed via the touch screen and   |
|    |                                                                        | is a mandatory step in simulated TBNA      |
|    |                                                                        | performance.                               |

[TABLE]
| It is performed via the touch screen and                                   |
|:---------------------------------------------------------------------------|
| is a mandatory step in simulated TBNA                                      |
| performance.                                                               |
| Note: The Lock button becomes enabled only when the needle is pushed       |
| completely out of its sheath.                                              |
| Secure Proximally simulates manually holding together the proximal portion |
| of the needle’s sheath in the working channel, allowing for advancing the  |
| scope and needle as one.                                                   |
| Suction is performed by pulling the actual syringe piston open to Aspirate |
| and pushing it close to Release. Applying suction is a mandatory step in   |
| simulated TBNA performance.                                                |

[OCR]
Diagnostic Bronchoscopy Module

5 - Virtual Instructor

The Virtual Instructor provides real-time warnings, comments, and tips
regarding procedure performance efficiency as well as mild patient
condition notices.

6 - Tool Panel

The master tool and the syringe are used in this module to simulate all
tools. Following the master tool insertion into the scope’s working channel
and menu selection of the desired endoscopic tool, the simulated tool
appears inside the anatomy and its tool panel is displayed.

Note: The syringe, along with its tool panel, becomes active in the
simulation upon inserting the syringe into the working channel.

AM forceps The Forceps, Brush and Needle tool
panels (1, 2 and 3) display each tool's
states and options. All three allow for
virtual activation, overriding the master
tool handle to facilitate easier solo
training.

Note: The tool panels indicate whether
Virtual Activation is on, the current tool

L state and additional control options when

applicable.

Suction The Needle tool panel (3) displays the

following additional controls:

[ ~ Lock locks the needle out of its sheath.
rr It is performed via the touch screen and
is a mandatory step in simulated TBNA

performance.

Note: The Lock button becomes enabled only when the needle is pushed
completely out of its sheath.

Secure Proximally simulates manually holding together the proximal portion
of the needle’s sheath in the working channel, allowing for advancing the
scope and needle as one.

Suction is performed by pulling the actual syringe piston open to Aspirate
and pushing it close to Release. Applying suction is a mandatory step in
simulated TBNA performance.

surgical BRONCH Mentor


# Page 7

Diagnostic Bronchoscopy Module
7
BRONCH Mentor
a
c
e
b
d
f
4
The Syringe tool panel (4) displays the following 
choices:
a.	 Selection of fluids to be used 
b.	Properties of the currently selected fluid 
c.	 Selection of syringe size
Note: The same physical syringe simulates different 
size syringes, according to the size selection.
d.	Optional additional controls per the selected 
substance 
e.	The syringe’s dynamic animation, indicating its 
current state
f.	 The accumulating amount of fluids injected and 
retrieved is displayed whenever the syringe is 
active
Note: The syringe needs to be open when inserted.
7 - General Buttons
	
 Mute button toggles the system sound on and off.
	
 Case File button opens the current virtual patient’s case file.
	
 Help button opens the online help (availability is per software version).
	
 Finish button ends the current simulation, allowing for saving its performance 
metrics. 


[TABLE]
| 4   |    |    |    |                                                     |
|:----|:---|:---|:---|:----------------------------------------------------|
|     |    |    |    | The Syringe tool panel (4) displays the following   |
|     |    |    |    | choices:                                            |
|     |    |    |    | a.  Selection of fluids to be used                  |
|     | a  |    |    |                                                     |
|     |    |    |    | b.  Properties of the currently selected fluid      |
|     | b  |    |    |                                                     |
|     |    |    |    | c.  Selection of syringe size                       |
|     |    |    | c  | Note: The same physical syringe simulates different |
|     |    |    |    | size syringes, according to the size selection.     |
|     |    |    |    | d.  Optional additional controls per the selected   |
|     |    |    |    | substance                                           |
|     |    |    | d  |                                                     |
|     |    |    |    | e.  The syringe’s dynamic animation, indicating its |
| e   |    |    |    | current state                                       |
|     |    |    |    | f.  The accumulating amount of fluids injected and  |
|     |    | f  |    | retrieved is displayed whenever the syringe is      |
|     |    |    |    | active                                              |
|     |    |    |    | Note: The syringe needs to be open when inserted.   |

[TABLE]
| active                                            |
|:--------------------------------------------------|
| Note: The syringe needs to be open when inserted. |
| 7 - General Buttons                               |
|  Mute button toggles the system sound on and off.                                                   |
|  Case File button opens the current virtual patient’s case file.                                                   |
|  Help button opens the online help (availability is per software version).                                                   |
|  Finish button ends the current simulation, allowing for saving its performance                                                   |
| metrics.                                          |

[OCR]
Diagnostic Bronchoscopy Module

The Syringe tool panel (4) displays the following
choices:

a. Selection of fluids to be used
b. Properties of the currently selected fluid

c. Selection of syringe size

Note: The same physical syringe simulates different
size syringes, according to the size selection.

d. Optional additional controls per the selected
substance

e. The syringe’s dynamic animation, indicating its
current state

f. The accumulating amount of fluids injected and
retrieved is displayed whenever the syringe is
active

Note: The syringe needs to be open when inserted.

7 - General Buttons

= Mute button toggles the system sound on and off.

Case File button opens the current virtual patient’s case file.

Help button opens the online help (availability is per software version).

Finish button ends the current simulation, allowing for saving its performance
metrics.

surgical BRONCH Mentor


# Page 8

Diagnostic Bronchoscopy Module
8
BRONCH Mentor
Patient History and Condition
An outpatient 58 year old male, weighing 98 kg, was referred with a complaint 
of persistent cough. Past smoker for 15 years, ~30 cigarettes a day, quit 
smoking 7 years ago. A chest X-ray showed no findings.
Vital Signs Measured
	
 BP: 130/98
	
 HR: 98
	
 RR:14
Available Test Results 
	
 PT- 11.9 sec. (11 - 13.5)
	
 Platelet count – 300,000 per mcL (150,000 - 400,000)
	
 CBC: 
•	RBC – 5.3 million/mcL (4.7 - 6.1)
•	WBC – 7,000 cells/mcL (4,500 - 10,000)
•	Hematocrit – 41.4 % (40.7 - 50.3)
•	Hemoglobin  - 14.2 gm/dL (13.8 - 17.2)
•	MCV -  91 femtoliter (80 - 95)
•	MCH – 27 pg/cell (27 - 31)
•	MCHC - 33 gm/dL (32 - 36)
Case Summary
A virtual patient with endobronchial lesion not showing on chest X-ray.
Perform a complete evaluation, find the lesion and obtain tissue samples using 
diagnostic tools of choice.
Case 1
1


[TABLE]
|  PT- 11.9 sec. (11 - 13.5)                                           |
|:------------------------------------------|
|  Platelet count – 300,000 per mcL (150,000 - 400,000)                                           |
|  CBC:                                           |
| •  RBC – 5.3 million/mcL (4.7 - 6.1)      |
| •  WBC – 7,000 cells/mcL (4,500 - 10,000) |
| •  Hematocrit – 41.4 % (40.7 - 50.3)      |
| •  Hemoglobin  - 14.2 gm/dL (13.8 - 17.2) |
| •  MCV -  91 femtoliter (80 - 95)         |
| •  MCH – 27 pg/cell (27 - 31)             |
| •  MCHC - 33 gm/dL (32 - 36)              |

[OCR]
Diagnostic Bronchoscopy Module

Case 1

Patient History and Condition

An outpatient 58 year old male, weighing 98 kg, was referred with a complaint
of persistent cough. Past smoker for 15 years, ~30 cigarettes a day, quit
smoking 7 years ago. A chest X-ray showed no findings.

Vital Signs Measured
= BP: 130/98

= HR: 98
= RR14

Available Test Results
= PT- 11.9 sec. (11 - 13.5)

= Platelet count - 300,000 per mcL (150,000 - 400,000)
= CBC:

« RBC - 5.3 million/mcL (4.7 - 6.1)
« WBC - 7,000 cells/mcL (4,500 - 10,000)
« Hematocrit - 41.4 % (40.7 - 50.3)
« Hemoglobin - 14.2 gm/dL (13.8 - 17.2)
« MCV - 91 femtoliter (80 - 95)
* MCH - 27 pg/cell (27 - 31)
* MCHC - 33 gm/dL (32 - 36)
Case Summary

A virtual patient with endobronchial lesion not showing on chest X-ray.
Perform a complete evaluation, find the lesion and obtain tissue samples using
diagnostic tools of choice.

surgical BRONCH Mentor


# Page 9

Diagnostic Bronchoscopy Module
9
BRONCH Mentor
Patient History and Condition
A 56 year old male Russian immigrant, weighing 85 kg, complaining of 
persistent cough, night sweating and weight loss. Patient is a smoker, 15 to 
20 non-filter cigarettes a day. Thoracic CT scan shows a thin walled cavitary 
lesion with air-fluid level in the right middle lobe.
Vital Signs Measured
	
 BP: 120/82
	
 HR: 80
	
 RR: 12
Available Test Results
	
 PT- 12.1 sec. (11 - 13.5)
	
 Platelet count - 310,000 per mcL (150,000 - 400,000)
Case Summary
A case of Aspergillus showing on CT thin walled cavitary lesion with air-
fluid level. Perform a complete evaluation and obtain tissue samples, using 
diagnostic tools of choice.
Case 2
2


[TABLE]
| Diagnostic Bronchoscopy Module                                                |
|:------------------------------------------------------------------------------|
| Case 2                                                                        |
| 2                                                                             |
| Patient History and Condition                                                 |
| A 56 year old male Russian immigrant, weighing 85 kg, complaining of          |
| persistent cough, night sweating and weight loss. Patient is a smoker, 15 to  |
| 20 non-filter cigarettes a day. Thoracic CT scan shows a thin walled cavitary |
| lesion with air-fluid level in the right middle lobe.                         |
| Vital Signs Measured                                                          |
|  BP: 120/82                                                                               |
|  HR: 80                                                                               |
|  RR: 12                                                                               |
| Available Test Results                                                        |
|  PT- 12.1 sec. (11 - 13.5)                                                                               |
|  Platelet count - 310,000 per mcL (150,000 - 400,000)                                                                               |
| Case Summary                                                                  |
| A case of Aspergillus showing on CT thin walled cavitary lesion with air-     |
| fluid level. Perform a complete evaluation and obtain tissue samples, using   |
| diagnostic tools of choice.                                                   |
| 9                                                                             |
| BRONCH Mentor                                                                 |

[OCR]
Diagnostic Bronchoscopy Module

Case 2

Patient History and Condition

A 56 year old male Russian immigrant, weighing 85 kg, complaining of
persistent cough, night sweating and weight loss. Patient is a smoker, 15 to
20 non-filter cigarettes a day. Thoracic CT scan shows a thin walled cavitary
lesion with air-fluid level in the right middle lobe.

Vital Signs Measured

= BP: 120/82

= HR: 80

= RR: 12

Available Test Results
= PT- 12.1 sec. (11 - 13.5)
= Platelet count - 310,000 per mcL (150,000 - 400,000)

Case Summary

A case of Aspergillus showing on CT thin walled cavitary lesion with air-
fluid level. Perform a complete evaluation and obtain tissue samples, using
diagnostic tools of choice.

surgical BRONCH Mentor


# Page 10

Diagnostic Bronchoscopy Module
10
BRONCH Mentor
Patient History and Condition
A 56 year old female, weighing 52 kg, complaining 
of shortness of breath and fatigue. A cardiac inquiry 
showed no findings. Patient is a smoker, ~20 cigarettes 
a day. A thoracic CT scan demonstrated two solid 
masses in the left upper lobe and the left lower 
lobe. Enlarged subcarinal and 11L lymph nodes were 
demonstrated as well.
Vital Signs Measured
	
 BP: 140/90
	
 HR: 86
	
 RR: 16
Available Test Results
	
 PT- sec. 12.9 (11 - 13.5)
	
 Platelet count – 220,000 per mcL (150,000 - 400,000)
	
 CBC: 
•	RBC – 5.3 million/mcL (4.7 - 6.1)
•	WBC – 9000 cells/mcL (4,500 - 10,000)
•	Hematocrit – 39.3% (36.1 - 44.3)
•	Hemoglobin  - 15.8 gm/dL (12.1 - 15.1)
Case Summary
A virtual patient with endobronchial malignancies and 
enlarged LN 7 and LN 11L. 
Perform a complete evaluation, and obtain endobronchial 
and transbronchial tissue samples using diagnostic tools 
of choice.
Case 3
3


[TABLE]
|                                                         |
|:--------------------------------------------------------|
| Case 3                                                  |
| 3                                                       |
| Patient History and Condition                           |
| A 56 year old female, weighing 52 kg, complaining       |
| of shortness of breath and fatigue. A cardiac inquiry   |
| showed no findings. Patient is a smoker, ~20 cigarettes |
| a day. A thoracic CT scan demonstrated two solid        |
| masses in the left upper lobe and the left lower        |
| lobe. Enlarged subcarinal and 11L lymph nodes were      |
| demonstrated as well.                                   |
| Vital Signs Measured                                    |
|  BP: 140/90                                                         |
|  HR: 86                                                         |
|  RR: 16                                                         |
| Available Test Results                                  |
|  PT- sec. 12.9 (11 - 13.5)                                                         |
|  Platelet count – 220,000 per mcL (150,000 - 400,000)                                                         |
|  CBC:                                                         |

[OCR]
Diagnostic Bronchoscopy Module

Case 3

Patient History and Condition

A 56 year old female, weighing 52 kg, complaining

of shortness of breath and fatigue. A cardiac inquiry
showed no findings. Patient is a smoker, ~20 cigarettes
a day. A thoracic CT scan demonstrated two solid
masses in the left upper lobe and the left lower

lobe. Enlarged subcarinal and 11L lymph nodes were
demonstrated as well.

Vital Signs Measured

= BP: 140/90
= HR: 86
= RR: 16

Available Test Results
= PT- sec. 12.9 (11 - 13.5)

= Platelet count - 220,000 per mcL (150,000 - 400,000)
= CBC:

« RBC — 5.3 million/mcL (4.7 - 6.1)

« WBC - 9000 cells/mcL (4,500 - 10,000)
« Hematocrit - 39.3% (36.1 - 44.3)

¢ Hemoglobin - 15.8 gm/dL (12.1 - 15.1)

Case Summary

A virtual patient with endobronchial malignancies and
enlarged LN 7 and LN 11L.

Perform a complete evaluation, and obtain endobronchial
and transbronchial tissue samples using diagnostic tools
of choice.

surgical BRONCH Mentor


# Page 11

Diagnostic Bronchoscopy Module
11
BRONCH Mentor
Patient History and Condition
An eight YO boy with a history of recurring infections was referred 
with coughing and shortness of breath. A chest X-Ray showed no 
findings. Patient is weighing 28 kg. (61.7 lbs).
Vital Signs Measured
	
 BP: 110/70
	
 HR: 110
	
 RR: 20
Case Summary
A pediatric virtual patient with recurring infections.  
Perform a complete evaluation, and diagnose using diagnostic 
methods of choice. 
Case 4
4


[TABLE]
| Diagnostic Bronchoscopy Module                                      |               |
|:--------------------------------------------------------------------|:--------------|
| Case 4                                                              |               |
| 4                                                                   |               |
| Patient History and Condition                                       |               |
| An eight YO boy with a history of recurring infections was referred |               |
| with coughing and shortness of breath. A chest X-Ray showed no      |               |
| findings. Patient is weighing 28 kg. (61.7 lbs).                    |               |
| Vital Signs Measured                                                |               |
|  BP: 110/70                                                                     |               |
|  HR: 110                                                                     |               |
|  RR: 20                                                                     |               |
| Case Summary                                                        |               |
| A pediatric virtual patient with recurring infections.              |               |
| Perform a complete evaluation, and diagnose using diagnostic        |               |
| methods of choice.                                                  |               |
| 11                                                                  |               |
|                                                                     | BRONCH Mentor |

[OCR]
Diagnostic Bronchoscopy Module

Case 4

Patient History and Condition

An eight YO boy with a history of recurring infections was referred
with coughing and shortness of breath. A chest X-Ray showed no
findings. Patient is weighing 28 kg. (61.7 Ibs).

Vital Signs Measured

= BP: 110/70

= HR: 110
= RR: 20

Case Summary

A pediatric virtual patient with recurring infections.
Perform a complete evaluation, and diagnose using diagnostic
methods of choice.

surgicalscience BRONCH Mentor


# Page 12

Diagnostic Bronchoscopy Module
12
BRONCH Mentor
Patient History and Condition
An outpatient 41 year old male, weighing 73 kg, complaining of  
a persistent cough, with minimal blood clots on sputum.
Patient is a non smoker, HIV positive. A CT scan showed an enlarged 11Rs 
lymph node of 2.9 cm. 
Vital Signs Measured
	
 BP: 128/88
	
 HR: 90
	
 RR: 14
Available Test Results 
	
 PT- 12.5 sec. (11 - 13.5)
	
 Platelet count - 230,000 per mcL (150,000 - 400,000)
	
 CBC: 
•	RBC - 5.9 million/mcL (4.7 - 6.1)
•	WBC - 9,300 cells/mcL (4,500 - 10,000)
•	Hematocrit - 48.7 % (40.7 - 50.3)
•	Hemoglobin  - 15.7 gm/dL (13.8 - 17.2)
•	MCV - 88 femtoliter (80 - 95)
•	MCH - 29 pg/cell (27 - 31)
•	MCHC - 33 gm/dL (32 - 36)
Case Summary
A virtual patient with Kaposi’s sarcoma and an enlarged LN 11Rs.  
Perform a complete evaluation, using diagnostic tools of choice.
Case 5
5


[TABLE]
|  PT- 12.5 sec. (11 - 13.5)                                           |
|:------------------------------------------|
|  Platelet count - 230,000 per mcL (150,000 - 400,000)                                           |
|  CBC:                                           |
| •  RBC - 5.9 million/mcL (4.7 - 6.1)      |
| •  WBC - 9,300 cells/mcL (4,500 - 10,000) |
| •  Hematocrit - 48.7 % (40.7 - 50.3)      |
| •  Hemoglobin  - 15.7 gm/dL (13.8 - 17.2) |
| •  MCV - 88 femtoliter (80 - 95)          |
| •  MCH - 29 pg/cell (27 - 31)             |
| •  MCHC - 33 gm/dL (32 - 36)              |

[OCR]
Diagnostic Bronchoscopy Module

Case 5

Patient History and Condition

An outpatient 41 year old male, weighing 73 kg, complaining of
a persistent cough, with minimal blood clots on sputum.

Patient is a non smoker, HIV positive. A CT scan showed an enlarged 11Rs
lymph node of 2.9 cm.

Vital Signs Measured

= BP: 128/88

= HR: 90

= RR: 14

Available Test Results

= PT- 12.5 sec. (11 - 13.5)

= Platelet count - 230,000 per mcL (150,000 - 400,000)
= CBC:

« RBC - 5.9 million/mcL (4.7 - 6.1)
¢ WBC - 9,300 cells/mcL (4,500 - 10,000)
« Hematocrit - 48.7 % (40.7 - 50.3)
e Hemoglobin - 15.7 gm/dL (13.8 - 17.2)
* MCV - 88 femtoliter (80 - 95)
* MCH - 29 pg/cell (27 - 31)
* MCHC - 33 gm/dL (32 - 36)
Case Summary

A virtual patient with Kaposi’s sarcoma and an enlarged LN 11Rs.
Perform a complete evaluation, using diagnostic tools of choice.

surgical BRONCH Mentor


# Page 13

Diagnostic Bronchoscopy Module
13
BRONCH Mentor
Patient History and Condition
A 54 YO male exhibiting symptoms of cough, severe dyspnea and tiredness 
without fever or night sweats. 
A chest CT demonstrated diffused reticulonodular infiltrates, and bilateral 
mediastinal, hilar and interlobar lymphadenopathy. Lymph node stations 2R, 
4R, 4L, 7, 10R, 10L, 11Rs, 11Ri and 11L are visible.
Vital Signs Measured
	
 BP: 132/92
	
 HR: 86
	
 RR: 20
Case Summary
A virtual patient with sarcoidosis, presenting both diffused reticulonodular 
infiltrates and multiple enlarged lymph nodes.  
Perform a complete evaluation, and obtain endobronchial and transbronchial 
tissue samples from sites of choice.
Case 6
6


[TABLE]
| Diagnostic Bronchoscopy Module                                               |
|:-----------------------------------------------------------------------------|
| Case 6                                                                       |
| 6                                                                            |
| Patient History and Condition                                                |
| A 54 YO male exhibiting symptoms of cough, severe dyspnea and tiredness      |
| without fever or night sweats.                                               |
| A chest CT demonstrated diffused reticulonodular infiltrates, and bilateral  |
| mediastinal, hilar and interlobar lymphadenopathy. Lymph node stations 2R,   |
| 4R, 4L, 7, 10R, 10L, 11Rs, 11Ri and 11L are visible.                         |
| Vital Signs Measured                                                         |
|  BP: 132/92                                                                              |
|  HR: 86                                                                              |
|  RR: 20                                                                              |
| Case Summary                                                                 |
| A virtual patient with sarcoidosis, presenting both diffused reticulonodular |
| infiltrates and multiple enlarged lymph nodes.                               |
| Perform a complete evaluation, and obtain endobronchial and transbronchial   |
| tissue samples from sites of choice.                                         |
| 13                                                                           |
| BRONCH Mentor                                                                |

[OCR]
Diagnostic Bronchoscopy Module

Case 6

Patient History and Condition
A 54 YO male exhibiting symptoms of cough, severe dyspnea and tiredness
without fever or night sweats.

A chest CT demonstrated diffused reticulonodular infiltrates, and bilateral
mediastinal, hilar and interlobar lymphadenopathy. Lymph node stations 2R,
AR, 4L, 7, 10R, 10L, 11Rs, 11Ri and 11L are visible.

Vital Signs Measured

= BP: 132/92

= HR: 86
= RR: 20

Case Summary

A virtual patient with sarcoidosis, presenting both diffused reticulonodular
infiltrates and multiple enlarged lymph nodes.

Perform a complete evaluation, and obtain endobronchial and transbronchial
tissue samples from sites of choice.

Bes

surgicalscience BRONCH Mentor