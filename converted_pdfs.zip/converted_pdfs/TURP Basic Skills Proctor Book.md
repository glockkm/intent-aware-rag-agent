

# Page 1

TURP Basic Skills Proctor Book 
Overview 
The TURP Basic Skills module enables the trainee to acquire core skills 
essential for the TURP procedure.  
Providing the opportunity to practice in a non-anatomic environment, this 
module offers training for camera navigation and manipulation using 
angled optics, resection, and bleeding control skills.  
Unique Features: 
Camera Manipulation Skills 
• 
Targets position of varying difficulty levels 
• 
Usage of angled optics to reach targets  
• 
Usage of horizontal plane for target acquisition for advanced 
training 
• 
Cases with randomized target order for increased difficulty  
 
Resection Skills 
• 
Colored tissue segments for marking resection region and depth   
• 
Training at different clock angels for enhanced 
resectoscope manipulation skills 
 
Bleeding Control 
• 
Bleeders at different severities 
• 
Training at different clock angels for enhanced 
resectoscope manipulation skills 
 
 


[TABLE]
|                                                                           | TURP Basic Skills Proctor Book                |
|:--------------------------------------------------------------------------|:----------------------------------------------|
| Overview                                                                  |                                               |
| The TURP Basic Skills module enables the trainee to acquire core skills   |                                               |
| essential for the TURP procedure.                                         |                                               |
| Providing the opportunity to practice in a non-anatomic environment, this |                                               |
| module offers training for camera navigation and manipulation using       |                                               |
| angled optics, resection, and bleeding control skills.                    |                                               |
| Unique Features:                                                          |                                               |
| Camera Manipulation Skills                                                |                                               |
| •                                                                         | Targets position of varying difficulty levels |

[TABLE]
| Unique Features:           |                 |                                                                |
|:---------------------------|:----------------|:---------------------------------------------------------------|
| Camera Manipulation Skills |                 |                                                                |
|                            | •               | Targets position of varying difficulty levels                  |
|                            | •               | Usage of angled optics to reach targets                        |
|                            | •               | Usage of horizontal plane for target acquisition for advanced  |
|                            |                 | training                                                       |
|                            | •               | Cases with randomized target order for increased difficulty    |
| Resection Skills           |                 |                                                                |
|                            | •               | Colored tissue segments for marking resection region and depth |
|                            | •               | Training at different clock angels for enhanced                |
|                            |                 | resectoscope manipulation skills                               |
| B                          | leeding Control |                                                                |
|                            | •               | Bleeders at different severities                               |
|                            | •               | Training at different clock angels for enhanced                |
|                            |                 | resectoscope manipulation skills                               |

[OCR_TABLE]
TIiIiDp

[OCR_TABLE]
aw

[OCR]
TURP Basic Skills Proctor Book

Overview

The TURP Basic Skills module enables the trainee to acquire core skills
essential for the TURP procedure.

Providing the opportunity to practice in a non-anatomic environment, this
module offers training for camera navigation and manipulation using
angled optics, resection, and bleeding control skills.

Unique Features:

Camera Manipulation Skills
e Targets position of varying difficulty levels
e Usage of angled optics to reach targets
e Usage of horizontal plane for target acquisition for advanced
training
e Cases with randomized target order for increased difficulty

Resection Skills
e Colored tissue segments for marking resection region and depth
e Training at different clock angels for enhanced
resectoscope manipulation skills

Bleeding Control
e Bleeders at different severities
e Training at different clock angels for enhanced
resectoscope manipulation skills


# Page 2

URO Mentor 
 
Page 2 
 
Tasks Description 
Task 
Description 
Notes 
Camera Manipulation  
1 
Camera Manipulation 0° 
• 
 Use viewfinder to locate the 
targets by order 
• 
Viewfinder arrow indicates 
the direction of the next 
target 
• 
Camera uses a 00 scope  
2 
Camera Manipulation 0° 
Advanced 
• 
Use viewfinder to locate the 
targets by order 
• 
Viewfinder arrow indicates 
the direction of the next 
target 
• 
Align horizontal plane for 
target acquisition 
• 
Camera uses a 00 scope  
3 
Camera Manipulation 0° 
Advanced Randomized 
• 
Use viewfinder to locate the 
targets by order.  
• 
Viewfinder arrow indicates 
the direction of the next 
target 
• 
Align horizontal plane for 
target acquisition. 
• 
Camera uses a 00 scope 
• 
Random targets order each 
time 


[TABLE]
| Task                | Description            |    | Notes                        |
|:--------------------|:-----------------------|:---|:-----------------------------|
| Camera Manipulation |                        |    |                              |
|                     |                        | •  | Use viewfinder to locate the |
|                     |                        |    | targets by order             |
|                     |                        | •  | Viewfinder arrow indicates   |
| 1                   | Camera Manipulation 0° |    |                              |
|                     |                        |    | the direction of the next    |
|                     |                        |    | target                       |
|                     |                        | •  | Camera uses a 00 scope       |
|                     |                        | •  | Use viewfinder to locate the |
|                     |                        |    | targets by order             |
|                     |                        | •  | Viewfinder arrow indicates   |
|                     | Camera Manipulation 0° |    | the direction of the next    |
| 2                   |                        |    |                              |
|                     | Advanced               |    | target                       |
|                     |                        | •  | Align horizontal plane for   |
|                     |                        |    | target acquisition           |
|                     |                        | •  | Camera uses a 00 scope       |
|                     |                        | •  | Use viewfinder to locate the |
|                     |                        |    | targets by order.            |
|                     |                        | •  | Viewfinder arrow indicates   |
|                     |                        |    | the direction of the next    |
|                     |                        |    | target                       |
|                     | Camera Manipulation 0° |    |                              |
| 3                   |                        |    |                              |
|                     | Advanced Randomized    | •  | Align horizontal plane for   |
|                     |                        |    | target acquisition.          |
|                     |                        | •  | Camera uses a 00 scope       |
|                     |                        | •  | Random targets order each    |
|                     |                        |    | time                         |

[OCR]
URO Mentor

Tasks Description

Task Description

Notes

Camera Manipulation

1 Camera Manipulation 0°

Use viewfinder to locate the
targets by order

Viewfinder arrow indicates
the direction of the next
target

Camera uses a 0° scope

Camera Manipulation 0°
Advanced

Use viewfinder to locate the
targets by order

Viewfinder arrow indicates
the direction of the next
target

Align horizontal plane for
target acquisition

Camera uses a 0° scope

Camera Manipulation 0°

Use viewfinder to locate the
targets by order.
Viewfinder arrow indicates
the direction of the next
target

Advanced Randomized Align horizontal plane for
target acquisition.
Camera uses a 0° scope
Random targets order each
time
Page 2 surgicalscience


# Page 3

TURP Basic Skills Proctor Book
 
Page 3 
 
4 
Camera Manipulation 30° 
• 
Use viewfinder to locate the 
targets by order.  
• 
Viewfinder arrow indicates 
the direction of the next 
target.  
• 
Camera uses a 300 scope  
5 
Camera Manipulation 30° 
Advanced 
• 
Use viewfinder to locate the 
targets by order 
• 
Viewfinder arrow indicates 
the direction of the next 
target 
• 
Align horizontal plane for 
target acquisition 
• 
Camera uses a 300 scope  
6 
Camera Manipulation 30° 
Advanced Randomized 
• 
Use viewfinder to locate the 
targets by order 
• 
Viewfinder arrow indicates 
the direction of the next 
target 
• 
Align horizontal plane for 
target acquisition.  
• 
Camera uses a 300 scope.  
• 
Random targets order each 
time 
 
 


[TABLE]
|    |                         |    | TURP Basic Skills Proctor Book   |
|:---|:------------------------|:---|:---------------------------------|
|    |                         | •  | Use viewfinder to locate the     |
|    |                         |    | targets by order.                |
|    |                         | •  | Viewfinder arrow indicates       |
| 4  | Camera Manipulation 30° |    |                                  |
|    |                         |    | the direction of the next        |
|    |                         |    | target.                          |
|    |                         | •  | Camera uses a 300 scope          |
|    |                         | •  | Use viewfinder to locate the     |
|    |                         |    | targets by order                 |
|    |                         | •  | Viewfinder arrow indicates       |
|    |                         |    | the direction of the next        |
|    | Camera Manipulation 30° |    |                                  |
| 5  |                         |    |                                  |
|    |                         |    | target                           |
|    | Advanced                |    |                                  |
|    |                         | •  | Align horizontal plane for       |
|    |                         |    | target acquisition               |
|    |                         | •  | Camera uses a 300 scope          |
|    |                         | •  | Use viewfinder to locate the     |
|    |                         |    | targets by order                 |
|    |                         | •  | Viewfinder arrow indicates       |
|    |                         |    | the direction of the next        |
|    |                         |    | target                           |
|    | Camera Manipulation 30° |    |                                  |
| 6  |                         |    |                                  |
|    | Advanced Randomized     | •  | Align horizontal plane for       |
|    |                         |    | target acquisition.              |
|    |                         | •  | Camera uses a 300 scope.         |
|    |                         | •  | Random targets order each        |
|    |                         |    | time                             |

[OCR]
TURP Basic Skills Proctor Book

Camera Manipulation 30°

Use viewfinder to locate the
targets by order.

Viewfinder arrow indicates
the direction of the next
target.

Camera uses a 30° scope

Camera Manipulation 30°
Advanced

Use viewfinder to locate the
targets by order

Viewfinder arrow indicates
the direction of the next
target

Align horizontal plane for
target acquisition

Camera uses a 30° scope

Camera Manipulation 30°
Advanced Randomized

Use viewfinder to locate the
targets by order

Viewfinder arrow indicates
the direction of the next
target

Align horizontal plane for
target acquisition.

Camera uses a 30° scope.

Random targets order each
time

surgicalscience

Page 3


# Page 4

URO Mentor 
 
Page 4 
 
Resection Skills 
1 
Resection – 6 o'clock 
• 
Resect four marked tissue 
segments at 6 o’clock  
2 
Resection – 3 o'clock 
• 
Resect four marked tissue 
segments at 3 o’clock  
3 
Resection – 9 o'clock 
• 
Resect four marked tissue 
segments at 9 o’clock  
4 
Resection – 12 o'clock 
• 
Resect four marked tissue 
segments at 12 o’clock  
Bleeding Control Skills 
1 
Bleeding Control Easy 
• 
Coagulate as many bleeding 
sources as possible in 3min  
• 
Bleeding sources located 
between 5 and 7 o’clock 
• 
Low murky level of fluid  
2 
Bleeding Control Medium 
• 
Coagulate as many bleeding 
sources as possible in 3min 
• 
Bleeding sources located 
between 3 and 9 o’clock 
• 
Moderate murky level of fluid 
3 
Bleeding Control Difficult 
• 
Coagulate as many bleeding 
sources as possible in 3min  
• 
Bleeding sources located 
across the entire clockface, 
spanning 360 degrees 
• 
High murky level of fluid 


[TABLE]
| URO Mentor              |                            |    |                               |
|:------------------------|:---------------------------|:---|:------------------------------|
| Resection Skills        |                            |    |                               |
|                         |                            | •  | Resect four marked tissue     |
| 1                       | Resection – 6 o'clock      |    |                               |
|                         |                            |    | segments at 6 o’clock         |
|                         |                            | •  | Resect four marked tissue     |
| 2                       | Resection – 3 o'clock      |    |                               |
|                         |                            |    | segments at 3 o’clock         |
|                         |                            | •  | Resect four marked tissue     |
| 3                       | Resection – 9 o'clock      |    |                               |
|                         |                            |    | segments at 9 o’clock         |
|                         |                            | •  | Resect four marked tissue     |
| 4                       | Resection – 12 o'clock     |    |                               |
|                         |                            |    | segments at 12 o’clock        |
| Bleeding Control Skills |                            |    |                               |
|                         |                            | •  | Coagulate as many bleeding    |
|                         |                            |    | sources as possible in 3min   |
| 1                       | Bleeding Control Easy      | •  | Bleeding sources located      |
|                         |                            |    | between 5 and 7 o’clock       |
|                         |                            | •  | Low murky level of fluid      |
|                         |                            | •  | Coagulate as many bleeding    |
|                         |                            |    | sources as possible in 3min   |
| 2                       | Bleeding Control Medium    | •  | Bleeding sources located      |
|                         |                            |    | between 3 and 9 o’clock       |
|                         |                            | •  | Moderate murky level of fluid |
|                         |                            | •  | Coagulate as many bleeding    |
|                         |                            |    | sources as possible in 3min   |
|                         |                            | •  | Bleeding sources located      |
| 3                       | Bleeding Control Difficult |    |                               |
|                         |                            |    | across the entire clockface,  |
|                         |                            |    | spanning 360 degrees          |
|                         |                            | •  | High murky level of fluid     |

[OCR]
URO Mentor

Resection Skills

e Resect four marked tissue

1 Resection — 6 o'clock ,
segments at 6 o’clock
. ' e Resect four marked tissue
2 Resection — 3 o'clock ,
segments at 3 o’clock
. ' e Resect four marked tissue
3 Resection — 9 o'clock ,
segments at 9 o’clock
. e Resect four marked tissue
4 Resection — 12 o'clock

segments at 12 o’clock

Bleeding Control Skills

e Coagulate as many bleeding
sources as possible in 3min

1 Bleeding Control Easy e Bleeding sources located
between 5 and 7 o’clock

e Low murky level of fluid

e Coagulate as many bleeding
sources as possible in 3min

2 Bleeding Control Medium e Bleeding sources located
between 3 and 9 o’clock

e Moderate murky level of fluid

e Coagulate as many bleeding
sources as possible in 3min

e Bleeding sources located
across the entire clockface,
spanning 360 degrees

3 Bleeding Control Difficult

e High murky level of fluid

Page 4 surgicalscience


# Page 5

TURP Basic Skills Proctor Book
 
Page 5 
 
Module-Specific Hardware 
Device 
Physical Hardware 
Resectoscope 
 
 
 
 
Performance Report 
Metric 
Definition 
Camera Manipulation  
Total task time  
Total time elapsed between when the user 
begins the task and enters with the scope 
and when the user finishes or exits the 
exercise (hh:mm:ss) 
Number of targets 
acquired successfully 
The number of targets that were 
successfully acquired (max is 8) 
Average time per target  
The average time it took the user to capture 
the targets (sec) 
Total path of camera 
Total distance the camera traveled (cm) 


[TABLE]
| Metric                  | Definition                                   |
|:------------------------|:---------------------------------------------|
| Camera Manipulation     |                                              |
| Total task time         | Total time elapsed between when the user     |
|                         | begins the task and enters with the scope    |
|                         | and when the user finishes or exits the      |
|                         | exercise (hh:mm:ss)                          |
| Number of targets       | The number of targets that were              |
| acquired successfully   | successfully acquired (max is 8)             |
| Average time per target | The average time it took the user to capture |
|                         | the targets (sec)                            |
| Total path of camera    | Total distance the camera traveled (cm)      |

[OCR]
TURP Basic Skills Proctor Book

Module-Specific Hardware

Device Physical Hardware

Resectoscope

Performance Report

Metric Definition

Camera Manipulation

Total task time Total time elapsed between when the user
begins the task and enters with the scope
and when the user finishes or exits the
exercise (hh:mm:ss)

Number of targets The number of targets that were
acquired successfully successfully acquired (max is 8)
Average time per target The average time it took the user to capture

the targets (sec)

Total path of camera Total distance the camera traveled (cm)

surgicalscience Page 5


# Page 6

URO Mentor 
 
Page 6 
 
Resection Skills 
Total task time 
Total time elapsed between when the user 
begins the task and enters with the scope 
and when the user finishes or exits the 
exercise (hh:mm:ss) 
Resection during 
movement 
Measures the number of occurrences that 
resection was applied during scope 
movement 
Resection percentage 
Indicates the percentage resected for each 
segment  
Number of resection cuts 
Indicates the number of cuts it took the user 
to complete resection of each segment 
Peripheral damage 
Indicates the percentage of tissue resected 
surrounding of the marked segment 
Bleeding Control Skills 
Percent time worked in 
Clear View mode 
Measures percentage of time the Clear View 
mode was turned on 
Coagulation surface 
accuracy 
Measures the percentage of accurate 
coagulation done out of total coagulation 
attempts  
Bleeders coagulated 
Indicates the total number of bleeders that 
were coagulated  
Scope retracted 
Indicates the number of instances the scope 
was retracted for flushing 
Average time to coagulate 
bleeding 
The average time it took the user to 
coagulate the bleeding sources  
 
 


[TABLE]
| URO Mentor                |                                               |
|:--------------------------|:----------------------------------------------|
| Resection Skills          |                                               |
| Total task time           | Total time elapsed between when the user      |
|                           | begins the task and enters with the scope     |
|                           | and when the user finishes or exits the       |
|                           | exercise (hh:mm:ss)                           |
| Resection during          | Measures the number of occurrences that       |
| movement                  | resection was applied during scope            |
|                           | movement                                      |
| Resection percentage      | Indicates the percentage resected for each    |
|                           | segment                                       |
| Number of resection cuts  | Indicates the number of cuts it took the user |
|                           | to complete resection of each segment         |
| Peripheral damage         | Indicates the percentage of tissue resected   |
|                           | surrounding of the marked segment             |
| Bleeding Control Skills   |                                               |
| Percent time worked in    | Measures percentage of time the Clear View    |
| Clear View mode           | mode was turned on                            |
| Coagulation surface       | Measures the percentage of accurate           |
| accuracy                  | coagulation done out of total coagulation     |
|                           | attempts                                      |
| Bleeders coagulated       | Indicates the total number of bleeders that   |
|                           | were coagulated                               |
| Scope retracted           | Indicates the number of instances the scope   |
|                           | was retracted for flushing                    |
|                           | The average time it took the user to          |
| Average time to coagulate |                                               |
| bleeding                  | coagulate the bleeding sources                |

[OCR]
URO Mentor

Resection Skills

Total task time

Total time elapsed between when the user
begins the task and enters with the scope
and when the user finishes or exits the
exercise (hh:mm:ss)

Resection during
movement

Measures the number of occurrences that
resection was applied during scope
movement

Resection percentage

Indicates the percentage resected for each
segment

Number of resection cuts

Indicates the number of cuts it took the user
to complete resection of each segment

Peripheral damage

Indicates the percentage of tissue resected
surrounding of the marked segment

Bleeding Control Skills

Percent time worked in
Clear View mode

Measures percentage of time the Clear View
mode was turned on

Coagulation surface
accuracy

Measures the percentage of accurate
coagulation done out of total coagulation
attempts

Bleeders coagulated

Indicates the total number of bleeders that
were coagulated

Scope retracted

Indicates the number of instances the scope
was retracted for flushing

Average time to coagulate
bleeding

The average time it took the user to
coagulate the bleeding sources

Page 6

surgicalscience


# Page 7

TURP Basic Skills Proctor Book
 
Page 7 
 
Main Features and Controls 
Feature 
Button 
Description 
Patient File 
 
Review the case objectives 
Sound  
 
Mute the sound 
Camera Manipulation 
Viewfinder 
directional 
arrow  
 
The viewfinder arrow points you in the 
direction of the next target. The arrow 
disappears as you get closer to the 
target 
Viewfinder 
return sign 
 
The viewfinder U-turn sign appears 
when the target is passed. Go back 
with the scope to find the target 
Viewfinder 
horizontal 
plane indicator  
 
 
Advanced cases require alignment of 
the horizontal plane, indicated in 
viewfinder, with the target’s horizontal 
plane 
Resection Skills 
Segment step 
indicator 
 
Indicates during resection if a segment 
was partially or fully resected  
Bleeding Control Skills 
Clear View 
mode 
 
Clear the view for helping diagnose 
bleeding sources 
Coagulation 
counter 
 
Counts the number of bleeders 
coagulated during the session 
 


[TABLE]
| Main Features and Controls   |        |                                          |
|:-----------------------------|:-------|:-----------------------------------------|
| Feature                      | Button | Description                              |
| Patient File                 |        | Review the case objectives               |
| Sound                        |        | Mute the sound                           |
| Camera Manipulation          |        |                                          |
| Viewfinder                   |        | The viewfinder arrow points you in the   |
| directional                  |        | direction of the next target. The arrow  |
| arrow                        |        | disappears as you get closer to the      |
|                              |        | target                                   |
|                              |        | The viewfinder U-turn sign appears       |
| Viewfinder                   |        |                                          |
|                              |        | when the target is passed. Go back       |
| return sign                  |        |                                          |
|                              |        | with the scope to find the target        |
|                              |        | Advanced cases require alignment of      |
| Viewfinder                   |        |                                          |
|                              |        | the horizontal plane, indicated in       |
| horizontal                   |        |                                          |
|                              |        | viewfinder, with the target’s horizontal |
| plane indicator              |        |                                          |
|                              |        | plane                                    |
| Resection Skills             |        |                                          |

[OCR]
TURP Basic Skills Proctor Book

Main Features and Controls

Feature Button Description
Patient File a Review the case objectives
Sound Mute the sound

Camera Manipulation

plane indicator

Viewfinder The viewfinder arrow points you in the
directional A direction of the next target. The arrow
arrow disappears as you get closer to the
target
Viewfinder The viewfinder U-turn sign appears
. J when the target is passed. Go back
return sign . .
with the scope to find the target
Advanced cases require alignment of
Viewfinder . 4 a 8 .
. the horizontal plane, indicated in
horizontal

viewfinder, with the target’s horizontal
plane

Resection Skills

Segment step

Indicates during resection if a segment

indicator was partially or fully resected
Bleeding Control Skills

Clear View Clear the view for helping diagnose
mode + bleeding sources

Coagulation Counts the number of bleeders
counter coagulated during the session

surgicalscience

Page 7