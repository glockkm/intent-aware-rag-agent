

# Page 1

1
GI Mentor
Upper Gastrointestinal  
Endoscopy (Gastroscopy) 
Second Module -
This module is designed for trainees who have just begun the “hands-on” 
phase of learning and training in Gastroscopy.
The module objectives are:
	
 Performing a complete survey of the Upper GI tract with a forward viewing 
video-endoscope.
	
 Recognizing typical lesions.
	
 Performing diagnostic and therapeutic procedures in “patients” with major 
pathologies.
The module consists of 10 cases. The cases were created by Prof. Florent, 
Hôpital Saint-Antoine, Paris, France.


[TABLE]
| Upper Gastrointestinal                                                    |
|:--------------------------------------------------------------------------|
| Endoscopy (Gastroscopy)                                                   |
| This module is designed for trainees who have just begun the “hands-on”   |
| phase of learning and training in Gastroscopy.                            |
| The module objectives are:                                                |
|  Performing a complete survey of the Upper GI tract with a forward viewing                                                                           |
| video-endoscope.                                                          |
|  Recognizing typical lesions.                                                                           |
|  Performing diagnostic and therapeutic procedures in “patients” with major                                                                           |
| pathologies.                                                              |
| The module consists of 10 cases. The cases were created by Prof. Florent, |
| Hôpital Saint-Antoine, Paris, France.                                     |

[OCR]
This module is designed for trainees who have just begun the “hands-on”
phase of learning and training in Gastroscopy.

The module objectives are:

= Performing a complete survey of the Upper Gl tract with a forward viewing
video-endoscope.

= Recognizing typical lesions.

= Performing diagnostic and therapeutic procedures in “patients” with major
pathologies.

The module consists of 10 cases. The cases were created by Prof. Florent,

H6pital Saint-Antoine, Paris, France.

surgical GI Mentor


# Page 2

Upper Gastrointestinal  
Endoscopy (Gastroscopy) 
Second Module -
2
GI Mentor
1
Medical History: 
Mr. DUPOND, 40 years of age, was transferred to the Intensive Care Unit due 
to hematemesis and melena. He is a bank clerk. He underwent a surgery at the 
age of 8 for an umbilical hernia. 
He has smoked 30 cigarettes per day and has consumed 30 g of alcohol (beer) 
daily for the past 20 years. He has periumbilical collateral venous circulation, 
splenomegaly and abdominal meteorism.
Biological Tests: 
RBC: 
 
3.2 x 10¹²/L 
(4-5 x 10¹²) 
MCV: 
 
109 µ³  
(85-95) 
Leucocytes: 
11.7 x 10⁹/L 
(5-10 x 10⁹) 
Platelets: 
95 x 10⁹/L 
(100-300 x 10⁹) 
Hemoglobin: 
8.5 g/dL 
(N>14) 
ALT: 
 
95 IU 
 
(N<30) 
Alk. Phos: 
80 IU 
 
(N<100) 
PT: 
 
65% 
 
(N<75)
Comments: 
Diagnosis: Bleeding from esophageal varices. 
The portal hypertension is secondary to a post-operative portal thrombosis.
Treatment: Endoscopic band ligations or variceal sclerotherapy and 
Avlocardyl® (propranolol).
Esophageal varices
Case 1 


[TABLE]
|                                                                                  |        |         |
|:---------------------------------------------------------------------------------|:-------|:--------|
| 1                                                                                | Case 1 |         |
| Medical History:                                                                 |        |         |
| Mr. DUPOND, 40 years of age, was transferred to the Intensive Care Unit due      |        |         |
| to hematemesis and melena. He is a bank clerk. He underwent a surgery at the     |        |         |
| age of 8 for an umbilical hernia.                                                |        |         |
| He has smoked 30 cigarettes per day and has consumed 30 g of alcohol (beer)      |        |         |
| daily for the past 20 years. He has periumbilical collateral venous circulation, |        |         |
| splenomegaly and abdominal meteorism.                                            |        |         |
| Biological Tests:                                                                |        |         |
| RBC:                                                                             | 3.2	x	10¹²/L        | (4-5	x	10¹²)         |
| MCV:                                                                             | 109	µ³        | (85-95) |
| Leucocytes:                                                                      | 11.7	x	10⁹/L        | (5-10	x	10⁹)         |
| Platelets:                                                                       | 95	x	10⁹/L        | (100-300	x	10⁹)         |
| Hemoglobin:                                                                      | 8.5	g/dL        | (N>14)  |
| ALT:                                                                             | 95	IU        | (N<30)  |
| Alk.	Phos:                                                                                  | 80	IU        | (N<100) |
| PT:                                                                              | 65%    | (N<75)  |
| Comments:                                                                        |        |         |
| Diagnosis: Bleeding from esophageal varices.                                     |        |         |
| The portal hypertension is secondary to a post-operative portal thrombosis.      |        |         |
| Treatment: Endoscopic band ligations or variceal sclerotherapy and               |        |         |
| Avlocardyl® (propranolol).                                                       |        |         |

[OCR_TABLE]
VvPrPr*
Ende

[OCR]
Case 1

Medical History:

Mr. DUPOND, 40 years of age, was transferred to the Intensive Care Unit due
to hematemesis and melena. He is a bank clerk. He underwent a surgery at the
age of 8 for an umbilical hernia.

He has smoked 30 cigarettes per day and has consumed 30 g of alcohol (beer)
daily for the past 20 years. He has periumbilical collateral venous circulation,
splenomegaly and abdominal meteorism.

Biological Tests:

RBC: 3.2 x 10/L (4-5 x 1072)
MCV: 109 ye (85-95)
Leucocytes: 11.7 « 109/L (5-10 x 10°)
Platelets: 95 x 109/L (100-300 x 109)
Hemoglobin: 8.5 g/dL (N>14)

ALT: 95 1U (N<30)

Alk. Phos: 80 IU (N<100)

PT: 65% (N<75)
Comments:

Diagnosis: Bleeding from esophageal varices.

The portal hypertension is secondary to a post-operative portal thrombosis.
Treatment: Endoscopic band ligations or variceal sclerotherapy and
Avlocardyl® (propranolol).

Esophageal varices

surgical GI Mentor


# Page 3

Upper Gastrointestinal  
Endoscopy (Gastroscopy) 
Second Module -
3
GI Mentor
2
Medical History: 
Mr. DECAS was hospitalized in the Intensive Care Unit for hematemesis with 
hypovolemic shock (BP 80/60 mmHg, pulse 136/min, dyspnea).  
He has been suffering from crampy epigastric pain for 10 days, at first when 
fasting, but later the pain became constant. Medical history includes a 
duodenal ulcer 10 years ago.  
He was treated with ranitidine 300 mg/day for 6 weeks, then maintenance 
treatment with ranitidine 150 mg before bedtime for 2 years.
Biological Tests: 
RBC: 
 
2.3 x 10¹²/L 
(4-5 x 10¹²) 
Hemoglobin: 
6.5 g/dL  
(N>14) 
Platelets: 
130 x 10⁹/L 
(100-300 x 10⁹) 
PT: 
 
87% 
 
(N>75)
Comments: 
Diagnosis is hemorrhagic duodenal ulcer. 
It is necessary to perform antral biopsies in order to search for Helicobacter 
pylori before administering anti-secretory drugs. These biopsies must be 
performed 1 to 2 cm above the pylorus.
Case 2 
Bleeding ulcer


[TABLE]
|                                                                              |                                                                                |        |
|:-----------------------------------------------------------------------------|:-------------------------------------------------------------------------------|:-------|
| 2                                                                            | Case 2                                                                         |        |
| Medical History:                                                             |                                                                                |        |
| Mr. DECAS was hospitalized in the Intensive Care Unit for hematemesis with   |                                                                                |        |
| hypovolemic	shock	(BP	80/60	mmHg,	pulse	136/min,	dyspnea).                                                                              |                                                                                |        |
| He has been suffering from crampy epigastric pain for 10 days, at first when |                                                                                |        |
| fasting, but later the pain became constant. Medical history includes a      |                                                                                |        |
| duodenal ulcer 10 years ago.                                                 |                                                                                |        |
| He	was	treated	with	ranitidine	300	mg/day	for	6	weeks,	then	maintenance                                                                              |                                                                                |        |
|                                                                              | treatment	with	ranitidine	150	mg	before	bedtime	for	2	years.                                                                                |        |
| Biological Tests:                                                            |                                                                                |        |
| RBC:                                                                         | 2.3	x	10¹²/L                                                                                | (4-5	x	10¹²)        |
| Hemoglobin:                                                                  | 6.5	g/dL                                                                                | (N>14) |
| Platelets:                                                                   | 130	x	10⁹/L                                                                                | (100-300	x	10⁹)        |
| PT:                                                                          | 87%                                                                            | (N>75) |
| Comments:                                                                    |                                                                                |        |
|                                                                              | Diagnosis is hemorrhagic duodenal ulcer.                                       |        |
|                                                                              | It is necessary to perform antral biopsies in order to search for Helicobacter |        |
|                                                                              | pylori before administering anti-secretory drugs. These biopsies must be       |        |
|                                                                              | performed 1 to 2 cm above the pylorus.                                         |        |

[OCR_TABLE]
~rPP
Ende

[OCR]
Case 2

Medical History:

Mr. DECAS was hospitalized in the Intensive Care Unit for hematemesis with
hypovolemic shock (BP 80/60 mmHg, pulse 136/min, dyspnea).

He has been suffering from crampy epigastric pain for 10 days, at first when
fasting, but later the pain became constant. Medical history includes a
duodenal ulcer 10 years ago.

He was treated with ranitidine 300 mg/day for 6 weeks, then maintenance
treatment with ranitidine 150 mg before bedtime for 2 years.

Biological Tests:

RBC: 2.3 x 107/L (4-5 x 10")
Hemoglobin: 6.5 g/dL (N>14)
Platelets: 130 x 109/L (100-300 x 109)
PT: 87% (N>75)
Comments:

Diagnosis is hemorrhagic duodenal ulcer.

It is necessary to perform antral biopsies in order to search for Helicobacter
pylori before administering anti-secretory drugs. These biopsies must be
performed 1 to 2 cm above the pylorus.

Bleeding ulcer

surgical GI Mentor


# Page 4

Upper Gastrointestinal  
Endoscopy (Gastroscopy) 
Second Module -
4
GI Mentor
3
Medical History: 
Miss POYER, 32 years of age, suffered for 2 years from chronic diarrhea 
associated with weight loss and anemia. She has no particular medical or surgical 
history. She is 172 cm in height, 42 kg in weight (she weighed 52 kg at age 25).
Examination shows meteorism of the abdomen with no palpable mass and 
bilateral edema of lower limbs. BP: 120/80 mmHg.
Biological Tests: 
RBC: 
 
4.5 x 10¹²/L 
(4-5 x 10¹²) 
MCV: 
 
125 µ³  
(85-95) 
Leucocytes: 
11.7 x 10⁹/L 
(5-10 x 10⁹) 
Platelets: 
650 x 10⁹/L 
(100-300 x 10⁹) 
Hemoglobin: 
9.2 g/dL  
(N>12) 
PT: 
 
50% 
 
(N>75) 
Albumin: 
20 g/L  
(N=40) 
S Calcium: 
1.8 mM  
(N=2.5)
Comments: 
Celiac disease: It is necessary to perform biopsies of the second duodenum, or 
further. The treatment is based on a gluten-free diet i.e. a modification of the 
food plan, particularly the elimination of wheat flour (Note: many industrial foods 
contain wheat flour for example candies and sausage). Consulting a dietician is 
therefore essential.
Case 3
Celiac disease


[TABLE]
|                                                                                 |                                                                                   |         |
|:--------------------------------------------------------------------------------|:----------------------------------------------------------------------------------|:--------|
| 3                                                                               | Case 3                                                                            |         |
| Medical History:                                                                |                                                                                   |         |
|                                                                                 | Miss POYER, 32 years of age, suffered for 2 years from chronic diarrhea           |         |
|                                                                                 | associated with weight loss and anemia. She has no particular medical or surgical |         |
|                                                                                 | history.	She	is	172	cm	in	height,	42	kg	in	weight	(she	weighed	52	kg	at	age	25).                                                                                   |         |
|                                                                                 | Examination shows meteorism of the abdomen with no palpable mass and              |         |
|                                                                                 | bilateral	edema	of	lower	limbs.	BP:	120/80	mmHg.                                                                                   |         |
| Biological Tests:                                                               |                                                                                   |         |
| RBC:                                                                            | 4.5	x	10¹²/L                                                                                   | (4-5	x	10¹²)         |
| MCV:                                                                            | 125	µ³                                                                                   | (85-95) |
| Leucocytes:                                                                     | 11.7	x	10⁹/L                                                                                   | (5-10	x	10⁹)         |
| Platelets:                                                                      | 650	x	10⁹/L                                                                                   | (100-300	x	10⁹)         |
| Hemoglobin:                                                                     | 9.2	g/dL                                                                                   | (N>12)  |
| PT:                                                                             | 50%                                                                               | (N>75)  |
| Albumin:                                                                        | 20	g/L                                                                                   | (N=40)  |
| S	Calcium:                                                                                 | 1.8	mM                                                                                   | (N=2.5) |
| Comments:                                                                       |                                                                                   |         |
|                                                                                 | Celiac disease: It is necessary to perform biopsies of the second duodenum, or    |         |
|                                                                                 | further. The treatment is based on a gluten-free diet i.e. a modification of the  |         |
|                                                                                 | food	plan,	particularly	the	elimination	of	wheat	flour	(Note:	many	industrial	foods                                                                                   |         |
| contain wheat flour for example candies and sausage). Consulting a dietician is |                                                                                   |         |
| therefore essential.                                                            |                                                                                   |         |

[OCR_TABLE]
Uppe

[OCR]
Case 3

Medical History:

Miss POYER, 32 years of age, suffered for 2 years from chronic diarrhea
associated with weight loss and anemia. She has no particular medical or surgical

history. She is 172 cm in height, 42
Examination shows meteorism of th

g in weight (she weighed 52 kg at age 25).
e abdomen with no palpable mass and

bilateral edema of lower limbs. BP: 120/80 mmHg.

Biological Tests:

4-5 x 1072)
85-95)

5-10 x 10°)
100-300 x 10°)
N>12)

N>75)

N=40)

RBC: 4.5 x 10"/L
MCV: 125 ys
Leucocytes: 11.7 x 109/L
Platelets: 650 x 10°/L
Hemoglobin: 9.2 g/dL
PT: 50%
Albumin: 20 g/L

S Calcium: 1.8 mM
Comments:

Celiac disease: It is necessary to pe

N=2.5)

tform biopsies of the second duodenum, or

further. The treatment is based on a gluten-free diet i.e. a modification of the

food plan, particularly the eliminatio

n of wheat flour (Note: many industrial foods

contain wheat flour for example candies and sausage). Consulting a dietician is

therefore essential.

Celiac disease

surgical

GI Mentor


# Page 5

Upper Gastrointestinal  
Endoscopy (Gastroscopy) 
Second Module -
5
GI Mentor
4
Medical History: 
Ms. PERRIN, 25 years of age, underwent total colo-proctectomy with ileo-anal 
anastomosis 10 years ago, as treatment for familial adenomatous polyposis 
coli. She suffers from moderate “colicky” abdominal pain and from diarrhea 
consisting of 4 to 6 soft stools per day. Endoscopy of ileal reservoir was 
normal.
Biological Tests: 
Blood count and platelets, calcium, albumin, PT and C reactive protein were 
normal.  
Parasitological examination of stools was normal.
Comments: 
This is a cystic dilatation of the fundic glands. It is necessary to perform fundic 
biopsies to confirm the diagnosis. 
Problem: Due to the number of lesions, it is possible that an adenoma, 
requiring endoscopic treatment, is hidden among the lesions. Cystic dysplasia 
of the fundic glands does not require treatment or monitoring of any kind.
Endoscopic monitoring of adenomatous polyposis after surgery is intended 
as follow-up on the appearance and/or development of gastric, duodenal and 
papillary adenoma.
Case 4
Cystic dilation of 
fundic glands


[TABLE]
|                                                                                     |
|:------------------------------------------------------------------------------------|
| Case 4                                                                              |
| 4                                                                                   |
| Medical History:                                                                    |
| Ms.	PERRIN,	25	years	of	age,	underwent	total	colo-proctectomy	with	ileo-anal                                                                                     |
| anastomosis 10 years ago, as treatment for familial adenomatous polyposis           |
| coli. She suffers from moderate “colicky” abdominal pain and from diarrhea          |
| consisting	of	4	to	6	soft	stools	per	day.	Endoscopy	of	ileal	reservoir	was                                                                                     |
| normal.                                                                             |
| Biological Tests:                                                                   |
| Blood count and platelets, calcium, albumin, PT and C reactive protein were         |
| normal.                                                                             |
| Parasitological examination of stools was normal.                                   |
| Comments:                                                                           |
| This is a cystic dilatation of the fundic glands. It is necessary to perform fundic |
| biopsies to confirm the diagnosis.                                                  |
| Problem: Due to the number of lesions, it is possible that an adenoma,              |
| requiring endoscopic treatment, is hidden among the lesions. Cystic dysplasia       |
| of the fundic glands does not require treatment or monitoring of any kind.          |
| Endoscopic monitoring of adenomatous polyposis after surgery is intended            |
| as follow-up on the appearance and/or development of gastric, duodenal and          |
| papillary adenoma.                                                                  |

[OCR_TABLE]
ad el
Cereal -

[OCR]
Case 4

Medical History:

Ms. PERRIN, 25 years of age, underwent total colo-proctectomy with ileo-anal
anastomosis 10 years ago, as treatment for familial adenomatous polyposis
coli. She suffers from moderate “colicky” abdominal pain and from diarrhea
consisting of 4 to 6 soft stools per day. Endoscopy of ileal reservoir was
normal.

Biological Tests:

Blood count and platelets, calcium, albumin, PT and C reactive protein were
normal.

Parasitological examination of stools was normal.

Comments:

This is a cystic dilatation of the fundic glands. It is necessary to perform fundic
biopsies to confirm the diagnosis.

Problem: Due to the number of lesions, it is possible that an adenoma,
requiring endoscopic treatment, is hidden among the lesions. Cystic dysplasia
of the fundic glands does not require treatment or monitoring of any kind.
Endoscopic monitoring of adenomatous polyposis after surgery is intended

as follow-up on the appearance and/or development of gastric, duodenal and
papillary adenoma.

Cystic dilation of
fundic glands

surgical GI Mentor


# Page 6

Upper Gastrointestinal  
Endoscopy (Gastroscopy) 
Second Module -
6
GI Mentor
5
Medical History: 
Ms. RICHARD, 45 years of age, suffered from asthenia and weight loss of 
5 kg in 3 months. She underwent surgery 20 years ago for colonic familial 
adenomatous polyposis (total colo-proctectomy, with ileo-anal anastomosis).
Two years ago, she underwent surgery for a desmoid tumor on the abdominal 
wall. Her sister, age 32, also suffers from familial adenomatous polyposis 
coli. The physical examination is normal except for scars from previous 
laparotomies. There are no abdominal masses.
Biological Tests: 
RBC: 
 
3.5 x 10¹²/L 
(4 - 5 x 10¹²) 
Hemoglobin: 
9.2 g/dL 
(N > 12) 
MCV: 
 
120 µ³  
(85 - 95) 
Leukocytes: 
12 x 10⁹/L 
(5 - 10 x 10⁹) 
Albumin: 
39 g/L  
(35 - 45)
Comments: 
This is a degenerated gastric polyp, which developed on atrophic gastritis 
(Biermer’s disease). To confirm the diagnosis it is necessary to perform 
biopsies of the polyp and the fundic mucosa and to take a sample of gastric 
fluid to determine the level of the intrinsic factor. It is also necessary to 
determine blood levels of vitamin B12 and folic acid.
Case 5
Degenerated 
gastric polyp


[TABLE]
|                                                                               |                                                                             |    |
|:------------------------------------------------------------------------------|:----------------------------------------------------------------------------|:---|
| 5                                                                             | Case 5                                                                      |    |
| Medical History:                                                              |                                                                             |    |
|                                                                               | Ms.	RICHARD,	45	years	of	age,	suffered	from	asthenia	and	weight	loss	of                                                                             |    |
|                                                                               | 5	kg	in	3	months.	She	underwent	surgery	20	years	ago	for	colonic	familial                                                                             |    |
|                                                                               | adenomatous polyposis (total colo-proctectomy, with ileo-anal anastomosis). |    |
|                                                                               | Two years ago, she underwent surgery for a desmoid tumor on the abdominal   |    |
|                                                                               | wall. Her sister, age 32, also suffers from familial adenomatous polyposis  |    |
|                                                                               | coli. The physical examination is normal except for scars from previous     |    |
|                                                                               | laparotomies. There are no abdominal masses.                                |    |
| Biological Tests:                                                             |                                                                             |    |
| RBC:                                                                          | 3.5	x	10¹²/L                                                                             | (4	-	5	x	10¹²)    |
| Hemoglobin:                                                                   | 9.2	g/dL                                                                             | (N	>	12)    |
| MCV:                                                                          | 120	µ³                                                                             | (85	-	95)    |
| Leukocytes:                                                                   | 12	x	10⁹/L                                                                             | (5	-	10	x	10⁹)    |
| Albumin:                                                                      | 39	g/L                                                                             | (35	-	45)    |
| Comments:                                                                     |                                                                             |    |
|                                                                               | This is a degenerated gastric polyp, which developed on atrophic gastritis  |    |
|                                                                               | (Biermer’s	disease).	To	confirm	the	diagnosis	it	is	necessary	to	perform                                                                             |    |
| biopsies of the polyp and the fundic mucosa and to take a sample of gastric   |                                                                             |    |
| fluid to determine the level of the intrinsic factor. It is also necessary to |                                                                             |    |
| determine blood levels of vitamin B12 and folic acid.                         |                                                                             |    |

[OCR_TABLE]
ad el
Endc

[OCR]
Case 5

Medical History:

Ms. RICHARD, 45 years of age, suffered from asthenia and weight loss of

5 kg in 3 months. She underwent surgery 20 years ago for colonic familial
adenomatous polyposis (total colo-proctectomy, with ileo-anal anastomosis).
Two years ago, she underwent surgery for a desmoid tumor on the abdominal
wall. Her sister, age 32, also suffers from familial adenomatous polyposis

coli. The physical examination is normal except for scars from previous
laparotomies. There are no abdominal masses.

Biological Tests:

RBC: 3.5 x 1077/L (4 - 5 x 10")
Hemoglobin: 9.2 g/dL (N > 12)
MCV: 120 ye (85 - 95)
Leukocytes: 12 x 109/L (5 - 10 x 10°)
Albumin: 39 g/L (35 - 45)
Comments:

This is a degenerated gastric polyp, which developed on atrophic gastritis
(Biermer's disease). To confirm the diagnosis it is necessary to perform
biopsies of the polyp and the fundic mucosa and to take a sample of gastric
fluid to determine the level of the intrinsic factor. It is also necessary to
determine blood levels of vitamin B12 and folic acid.

Degenerated
gastric polyp

surgical GI Mentor


# Page 7

Upper Gastrointestinal  
Endoscopy (Gastroscopy) 
Second Module -
7
GI Mentor
6
Case 6
Medical History: 
Mr. THOMAS, 26 years of age, is suffering from dysphagia of solids, which 
appeared suddenly 8 days ago. For 1 month he has suffered from asthenia, bouts 
of fever, and a liquid diarrhea consisting of 4 to 6 post-prandial stools, with 
steatorrhea. The physical examination shows a patient in good health, 187 cm in 
height and 73 kg in weight. No amyotrophy was found. 
There is a sub-angulo-maxillary adenopathy, 1.4 cm, without signs of 
inflammation. 
Previous history: At age 17, he underwent a splenectomy following a road 
accident.  
He received three units of packed red blood cells.
Biological Tests: 
Hemoglobin: 
12.6 g/L  
(N > 14) 
MCV: 
 
95 µ³ 
 
(85 - 95) 
WBC: 
 
13 x 10⁹/L 
(5 - 10 x 10⁹) 
 
 
of which 89% polynuclear neutrophiles 
ESR: 
 
12 - 32 mm 
(N < 30) 
	
	
at 1 and 2 hours. 
Calcium:  
2.35 mM 
(N = 2.5) 
Albumin: 
35 g/L  
(N = 45) 
Serology of hepatitis B and C were negative.
Ulcer of esophagus


[TABLE]
|                                                                                 |                                                                          |    |
|:--------------------------------------------------------------------------------|:-------------------------------------------------------------------------|:---|
| 6                                                                               | Case 6                                                                   |    |
| Medical History:                                                                |                                                                          |    |
|                                                                                 | Mr.	THOMAS,	26	years	of	age,	is	suffering	from	dysphagia	of	solids,	which                                                                          |    |
| appeared suddenly 8 days ago. For 1 month he has suffered from asthenia, bouts  |                                                                          |    |
| of	fever,	and	a	liquid	diarrhea	consisting	of	4	to	6	post-prandial	stools,	with                                                                                 |                                                                          |    |
| steatorrhea. The physical examination shows a patient in good health, 187 cm in |                                                                          |    |
| height and 73 kg in weight. No amyotrophy was found.                            |                                                                          |    |
|                                                                                 | There is a sub-angulo-maxillary adenopathy, 1.4 cm, without signs of     |    |
| inflammation.                                                                   |                                                                          |    |
|                                                                                 | Previous history: At age 17, he underwent a splenectomy following a road |    |
| accident.                                                                       |                                                                          |    |
|                                                                                 | He received three units of packed red blood cells.                       |    |
| Biological Tests:                                                               |                                                                          |    |
| Hemoglobin:                                                                     | 12.6	g/L                                                                          | (N	>	14)    |
| MCV:                                                                            | 95	µ³                                                                          | (85	-	95)    |
| WBC:                                                                            | 13	x	10⁹/L                                                                          | (5	-	10	x	10⁹)    |
|                                                                                 | of	which	89%	polynuclear	neutrophiles                                                                          |    |
| ESR:                                                                            | 12	-	32	mm                                                                          | (N	<	30)    |
|                                                                                 | at 1 and 2 hours.                                                        |    |
| Calcium:                                                                        | 2.35	mM                                                                          | (N	=	2.5)    |
| Albumin:                                                                        | 35	g/L                                                                          | (N	=	45)    |
|                                                                                 | Serology of hepatitis B and C were negative.                             |    |

[OCR_TABLE]
VvrPr*
Endc

[OCR]
Case 6

Medical History:

Mr. THOMAS, 26 years of age, is suffering from dysphagia of solids, which
appeared suddenly 8 days ago. For 1 month he has suffered from asthenia, bouts
of fever, and a liquid diarrhea consisting of 4 to 6 post-prandial stools, with
steatorrhea. The physical examination shows a patient in good health, 187 cm in
height and 73 kg in weight. No amyotrophy was found.

There is a sub-angulo-maxillary adenopathy, 1.4 cm, without signs of
inflammation.

Previous history: At age 17, he underwent a splenectomy following a road
accident.

He received three units of packed red blood cells.

Biological Tests:

Hemoglobin: 12.6 g/L (N > 14)
MCV: 95 us (85 - 95)
WBC: 13 x 109/L (5 - 10 x 10°)
of which 89% polynuclear neutrophiles
ESR: 12 - 32mm (N < 30)
at 1 and 2 hours.
Calcium: 2.35 mM (N = 2.5)
Albumin: 35 g/L (N = 45)

Serology of hepatitis B and C were negative.

Ulcer of esophagus

surgical GI Mentor


# Page 8

Upper Gastrointestinal  
Endoscopy (Gastroscopy) 
Second Module -
8
GI Mentor
6
Case 6
Comments: 
Voluminous ulcer of lower esophagus, penetrating with well-defined edges, linked 
with a CMV infection. It is necessary to perform biopsies in order to locate CMV 
inclusions in histology. This young patient is HIV+ and is suffering from an initial 
infectious complication of his disease. He has 90 lymphocytes CD4. Treatment 
with specific antiviral drugs was started, which was supposed to bring about 
clinical improvement and cicatrization (within 4 weeks) of the ulcerated lesion.
Tritheapy was scheduled to be started at the same time.
Six years later, the patient has 1000 lymphocytes CD4 and feels well.
He has suffered no other infectious complication of his disease.


[TABLE]
|                                                                                  |
|:---------------------------------------------------------------------------------|
| Case 6                                                                           |
| 6                                                                                |
| Comments:                                                                        |
| Voluminous ulcer of lower esophagus, penetrating with well-defined edges, linked |
| with a CMV infection. It is necessary to perform biopsies in order to locate CMV |
| inclusions	in	histology.	This	young	patient	is	HIV+	and	is	suffering	from	an	initial                                                                                  |
| infectious	complication	of	his	disease.	He	has	90	lymphocytes	CD4.	Treatment                                                                                  |
| with specific antiviral drugs was started, which was supposed to bring about     |
| clinical improvement and cicatrization (within 4 weeks) of the ulcerated lesion. |
| Tritheapy was scheduled to be started at the same time.                          |
| Six years later, the patient has 1000 lymphocytes CD4 and feels well.            |
| He has suffered no other infectious complication of his disease.                 |

[OCR_TABLE]
Endc

[OCR]
Case 6

Comments:

Voluminous ulcer of lower esophagus, penetrating with well-defined edges, linked
with a CMV infection. It is necessary to perform biopsies in order to locate CMV
inclusions in histology. This young patient is HIV+ and is suffering from an initial
infectious complication of his disease. He has 90 lymphocytes CD4. Treatment
with specific antiviral drugs was started, which was supposed to bring about
clinical improvement and cicatrization (within 4 weeks) of the ulcerated lesion.

Tritheapy was scheduled to be started at the same time.
Six years later, the patient has 1000 lymphocytes CD4 and feels well.

He has suffered no other infectious complication of his disease.

surgical GI Mentor


# Page 9

Upper Gastrointestinal  
Endoscopy (Gastroscopy) 
Second Module -
9
GI Mentor
7
Medical History: 
Mr. DIEZ, 26 years of age, suffered from diarrhea, which appeared 3 months 
earlier, along with a weight loss of 15 kg. This patient has no prior personal 
medical history. He is married and is a father to a 6-month-old baby. 
The diarrhea presents all the characteristics of steatorrhea. The physical 
examination was normal (no adenomegaly, splenomegaly, hepatomegaly, 
abdominal mass).
Biological Tests: 
Hemoglobin: 
10.6 g/L  
(N > 14) 
MCV: 
 
67 µ³ 
 
(85 - 95) 
Serum iron: 
11 µmol/L 
(8 - 24) 
Albumin: 
25 g/L  
(N < 35) 
Hypocalcemia: 1.97 mEq/L 
(N < 2.0) 
Platelets: 
250 x 10⁹/L 
(100 - 300 x 10⁹) 
Leukocytes: 
8.7 x 10⁹/L 
(5 - 10 x 10⁹) 
 
 
with 87% polynuclear neutrophiles.
Case 7
Pseudo-whipple


[TABLE]
|                                                                            |        |    |
|:---------------------------------------------------------------------------|:-------|:---|
| 7                                                                          | Case 7 |    |
| Medical History:                                                           |        |    |
| Mr.	DIEZ,	26	years	of	age,	suffered	from	diarrhea,	which	appeared	3	months                                                                            |        |    |
| earlier,	along	with	a	weight	loss	of	15	kg.	This	patient	has	no	prior	personal                                                                            |        |    |
| medical	history.	He	is	married	and	is	a	father	to	a	6-month-old	baby.                                                                            |        |    |
| The diarrhea presents all the characteristics of steatorrhea. The physical |        |    |
| examination was normal (no adenomegaly, splenomegaly, hepatomegaly,        |        |    |
| abdominal mass).                                                           |        |    |
| Biological Tests:                                                          |        |    |
| Hemoglobin:                                                                | 10.6	g/L        | (N	>	14)    |
| MCV:                                                                       | 67	µ³        | (85	-	95)    |
| Serum	iron:                                                                            | 11	µmol/L        | (8	-	24)    |
| Albumin:                                                                   | 25	g/L        | (N	<	35)    |
| Hypocalcemia:                                                              | 1.97	mEq/L        | (N	<	2.0)    |
| Platelets:                                                                 | 250	x	10⁹/L        | (100	-	300	x	10⁹)    |
| Leukocytes:                                                                | 8.7	x	10⁹/L        | (5	-	10	x	10⁹)    |
|                                                                            | with	87%	polynuclear	neutrophiles.        |    |

[OCR_TABLE]
~rrP
Ende

[OCR]
Case 7

Medical History:

Mr. DIEZ, 26 years of age, suffered from diarrhea, which appeared 3 months
earlier, along with a weight loss of 15 kg. This patient has no prior personal
medical history. He is married and is a father to a 6-month-old baby.

The diarrhea presents all the characteristics of steatorrhea. The physical
examination was normal (no adenomegaly, splenomegaly, hepatomegaly,
abdominal mass).

Biological Tests:

Hemoglobin: 10.6 g/L (N > 14)

MCV: 67 y? (85 - 95)

Serum iron: 11 umol/L (8 - 24)

Albumin: 25 g/L (N < 35)
Hypocalcemia: 1.97 mEq/L (N < 2.0)
Platelets: 250 x 109/L (100 - 300 x 109)
Leukocytes: 8.7 x 109/L (5 - 10 x 10°)

with 87% polynuclear neutrophiles.

Pseudo-whipple

surgical GI Mentor


# Page 10

Upper Gastrointestinal  
Endoscopy (Gastroscopy) 
Second Module -
10
GI Mentor
7
Case 7
Comments: 
This case is characterized by edema and whitish signs, recalling Whipple’s 
disease. The villi are thickened. In fact, this is a case of pseudo-Whipple, i.e. 
a Mycobacterium avium intracellular (ICMA) infection related to AIDS. This 
patient had sexual intercourse once with a prostitute prior to his marriage. It is 
necessary to perform biopsies of the D2, for a histological examination. These 
biopsies will show the existence of an infiltration of the villi by macrophages, 
containing Mycobacterium (Ziehl Nielsen stain) and, under transmission 
electronic microscopy, multiple inclusions in the form of bacilli.  
The culture of the biopsies and bronchial samples confirmed the diagnosis.
An HIV test was performed and found to be positive.  
The mother and the child are both HIV negative.
An anti-Mycobacterial polychemotherapy and treatment with AZT were 
ineffective.
The patient died 6 months later, with multiple sites of ICMA infection.


[TABLE]
|                                                                                    |
|:-----------------------------------------------------------------------------------|
| Case 7                                                                             |
| 7                                                                                  |
| Comments:                                                                          |
| This	case	is	characterized	by	edema	and	whitish	signs,	recalling	Whipple’s                                                                                    |
| disease. The villi are thickened. In fact, this is a case of pseudo-Whipple, i.e.  |
| a	Mycobacterium	avium	intracellular	(ICMA)	infection	related	to	AIDS.	This                                                                                    |
| patient had sexual intercourse once with a prostitute prior to his marriage. It is |
| necessary to perform biopsies of the D2, for a histological examination. These     |
| biopsies will show the existence of an infiltration of the villi by macrophages,   |
| containing	Mycobacterium	(Ziehl	Nielsen	stain)	and,	under	transmission                                                                                    |
| electronic microscopy, multiple inclusions in the form of bacilli.                 |
| The culture of the biopsies and bronchial samples confirmed the diagnosis.         |
| An HIV test was performed and found to be positive.                                |
| The mother and the child are both HIV negative.                                    |
| An anti-Mycobacterial polychemotherapy and treatment with AZT were                 |
| ineffective.                                                                       |
| The	patient	died	6	months	later,	with	multiple	sites	of	ICMA	infection.                                                                                    |

[OCR_TABLE]
Ende

[OCR]
Case 7

Comments:

This case is characterized by edema and whitish signs, recalling Whipple’s
disease. The villi are thickened. In fact, this is a case of pseudo-Whipple, i.e.

a Mycobacterium avium intracellular (ICMA) infection related to AIDS. This
patient had sexual intercourse once with a prostitute prior to his marriage. It is
necessary to perform biopsies of the D2, for a histological examination. These
biopsies will show the existence of an infiltration of the villi by macrophages,
containing Mycobacterium (Zieh Nielsen stain) and, under transmission
electronic microscopy, multiple inclusions in the form of bacilli.

The culture of the biopsies and bronchial samples confirmed the diagnosis.

An HIV test was performed and found to be positive.
The mother and the child are both HIV negative.

An anti-Mycobacterial polychemotherapy and treatment with AZT were
ineffective.

The patient died 6 months later, with multiple sites of ICMA infection.

surgical GI Mentor


# Page 11

Upper Gastrointestinal  
Endoscopy (Gastroscopy) 
Second Module -
11
GI Mentor
8
Medical History: 
Ms. CHAUSSE, 56 years of age, was hospitalized for chronic anemia with a 
hemoglobin of 6.0 g/dL. This patient - who suffers from alcoholic cirrhosis - 6 
months earlier was hospitalized for bleeding esophageal varices. 
Treatment with elastic ligatures solved the problem after 3 sessions, without 
complication. Preventive treatment with Avlocardyl® 160 LP (propranolol) 
was then initiated.Despite eliminating the varices, the anemia progressively 
returned. A series of tests for the presence of blood in the stools is found to be 
positive.Colonoscopy and ileoscopy were normal.
Biological Tests: 
Hemoglobin: 
 
6.0 g/dL 
(N > 12) 
Hematocrit: 
 
30% 
 
(40 - 48) 
MCV: 
 
 
68 µ³ 
 
(85 - 95) 
Leukocytes: 
 
7.5 x 10⁹/L 
(5 - 10 x 10⁹) 
Polymorphonuclears: 
78% 
 
(30 - 80) 
PT: 
 
 
65% 
 
(N = 75) 
Factor V: 
 
75% 
Alphafetoprotein is negative 
AST, ALT, Alk. Phos, Alb: Normal
Comments: 
The EVA (antral vascular ectasia) are not specific of cirrhosis. They are not 
sensitive to beta-blockers or estrogens. Their treatment is based on physical 
destruction by laser or coagulation by Argon Plasma Coagulation and generally 
causes the anemia to disappear.
Case 8
Watermelon stomach


[TABLE]
|                                  |                                                                                    |    |
|:---------------------------------|:-----------------------------------------------------------------------------------|:---|
| Case 8                           |                                                                                    |    |
| 8                                |                                                                                    |    |
| Medical History:                 |                                                                                    |    |
| Ms.	CHAUSSE,	56	years	of	age,	was	hospitalized	for	chronic	anemia	with	a                                  |                                                                                    |    |
| hemoglobin	of	6.0	g/dL.	This	patient	-	who	suffers	from	alcoholic	cirrhosis	-	6                                  |                                                                                    |    |
|                                  | months earlier was hospitalized for bleeding esophageal varices.                   |    |
|                                  | Treatment with elastic ligatures solved the problem after 3 sessions, without      |    |
|                                  | complication.	Preventive	treatment	with	Avlocardyl®	160	LP	(propranolol)                                                                                    |    |
|                                  | was then initiated.Despite eliminating the varices, the anemia progressively       |    |
|                                  | returned. A series of tests for the presence of blood in the stools is found to be |    |
|                                  | positive.Colonoscopy and ileoscopy were normal.                                    |    |
| Biological Tests:                |                                                                                    |    |
| Hemoglobin:                      | 6.0	g/dL                                                                                    | (N	>	12)    |
| Hematocrit:                      | 30%                                                                                | (40	-	48)    |
| MCV:                             | 68	µ³                                                                                    | (85	-	95)    |
| Leukocytes:                      | 7.5	x	10⁹/L                                                                                    | (5	-	10	x	10⁹)    |
| Polymorphonuclears:              | 78%                                                                                | (30	-	80)    |
| PT:                              | 65%                                                                                | (N	=	75)    |
| Factor	V:                                  | 75%                                                                                |    |
| Alphafetoprotein is negative     |                                                                                    |    |
| AST, ALT, Alk. Phos, Alb: Normal |                                                                                    |    |
| Comments:                        |                                                                                    |    |
|                                  | The EVA (antral vascular ectasia) are not specific of cirrhosis. They are not      |    |
|                                  | sensitive to beta-blockers or estrogens. Their treatment is based on physical      |    |
|                                  | destruction by laser or coagulation by Argon Plasma Coagulation and generally      |    |
| causes the anemia to disappear.  |                                                                                    |    |
| Watermelon stomach               |                                                                                    |    |

[OCR_TABLE]
Vvrr*
Endc

[OCR]
Case 8

Medical History:

Ms. CHAUSSE, 56 years of age, was hospitalized for chronic anemia with a
hemoglobin of 6.0 g/dL. This patient - who suffers from alcoholic cirrhosis - 6
months earlier was hospitalized for bleeding esophageal varices.

Treatment with elastic ligatures solved the problem after 3 sessions, without
complication. Preventive treatment with Avlocardyl® 160 LP (propranolol)

was then initiated.Despite eliminating the varices, the anemia progressively
returned. A series of tests for the presence of blood in the stools is found to be
positive.Colonoscopy and ileoscopy were normal.

Biological Tests:

Hemoglobin: 6.0 g/dL (N > 12)
Hematocrit: 30% (40 - 48)
MCV: 68 us (85 - 95)
Leukocytes: 7.5 x 109/L (5 - 10 x 109)
Polymorphonuclears: 78% (30 - 80)

PT: 65% (N = 75)
Factor V: 75%

Alphafetoprotein is negative
AST, ALT, Alk. Phos, Alb: Normal

Comments:

The EVA (antral vascular ectasia) are not specific of cirrhosis. They are not
sensitive to beta-blockers or estrogens. Their treatment is based on physical
destruction by laser or coagulation by Argon Plasma Coagulation and generally
causes the anemia to disappear.

Watermelon stomach

surgical GI Mentor


# Page 12

Upper Gastrointestinal  
Endoscopy (Gastroscopy) 
Second Module -
12
GI Mentor
9
Medical History: 
Ms. DUVAL, 56 years of age, was suffering from epigastric pain and vomiting 
striated with blood. This patient has no previous history of digestive disease. 
She is under treatment with paracetamol for gonarthritis. Her weight is 75 kg 
and height 160 cm. She does not smoke, but has consumed about 50 g of pure 
alcohol daily for the past 25 years. She occasionally takes 1 to 2 g of aspirin per 
day, according to her pain. The mucosa of the gastric antrum and the duodenal 
bulb is normal.
Biological Tests: 
Hemoglobin: 
10.5 g/dL 
(N > 12) 
MCV: 
 
100 µ³  
(85 - 95) 
Leukocytes: 
8.5 x 10⁹/L 
(5 - 10 x 10⁹) 
 
 
of which 65% are polynuclear neutrophiles 
Platelets: 
145 x 10⁹/L 
(100 - 300 x 10⁹) 
PT: 
 
75% 
 
(N > 75) 
Gamma GT: 
75 IU 
 
(N < 35) 
Transaminases:	 ALT and AST normal
Comments: 
This is a typical type of aspirin-induced hemorrhagic gastritis. 
Following ingestion of aspirin, petechia-type lesions appear within less than 60 
minutes at the level of the fundic mucosa in more than 80% of cases. 
These lesions are ephemeral and disappear in a few days if the patient stops 
aspirin ingestion. They can also disappear in cases where the patient takes 
aspirin regularly, due to a phenomenon of mucosal adaption.
Case 9
Hemorrhagic gastritis


[TABLE]
|                                                                              |                                                                                 |    |
|:-----------------------------------------------------------------------------|:--------------------------------------------------------------------------------|:---|
| 9                                                                            | Case 9                                                                          |    |
| Medical History:                                                             |                                                                                 |    |
|                                                                              | Ms.	DUVAL,	56	years	of	age,	was	suffering	from	epigastric	pain	and	vomiting                                                                                 |    |
|                                                                              | striated with blood. This patient has no previous history of digestive disease. |    |
|                                                                              | She	is	under	treatment	with	paracetamol	for	gonarthritis.	Her	weight	is	75	kg                                                                                 |    |
|                                                                              | and	height	160	cm.	She	does	not	smoke,	but	has	consumed	about	50	g	of	pure                                                                                 |    |
|                                                                              | alcohol	daily	for	the	past	25	years.	She	occasionally	takes	1	to	2	g	of	aspirin	per                                                                                 |    |
|                                                                              | day, according to her pain. The mucosa of the gastric antrum and the duodenal   |    |
| bulb is normal.                                                              |                                                                                 |    |
| Biological Tests:                                                            |                                                                                 |    |
| Hemoglobin:                                                                  | 10.5	g/dL                                                                                 | (N	>	12)    |
| MCV:                                                                         | 100	µ³                                                                                 | (85	-	95)    |
| Leukocytes:                                                                  | 8.5	x	10⁹/L                                                                                 | (5	-	10	x	10⁹)    |
|                                                                              | of	which	65%	are	polynuclear	neutrophiles                                                                                 |    |
| Platelets:                                                                   | 145	x	10⁹/L                                                                                 | (100	-	300	x	10⁹)    |
| PT:                                                                          | 75%                                                                             | (N	>	75)    |
| Gamma	GT:                                                                              | 75	IU                                                                                 | (N	<	35)    |
|                                                                              | Transaminases:  ALT and AST normal                                              |    |
| Comments:                                                                    |                                                                                 |    |
|                                                                              | This is a typical type of aspirin-induced hemorrhagic gastritis.                |    |
|                                                                              | Following	ingestion	of	aspirin,	petechia-type	lesions	appear	within	less	than	60                                                                                 |    |
|                                                                              | minutes	at	the	level	of	the	fundic	mucosa	in	more	than	80%	of	cases.                                                                                 |    |
| These lesions are ephemeral and disappear in a few days if the patient stops |                                                                                 |    |
| aspirin ingestion. They can also disappear in cases where the patient takes  |                                                                                 |    |
| aspirin regularly, due to a phenomenon of mucosal adaption.                  |                                                                                 |    |
| Hemorrhagic gastritis                                                        |                                                                                 |    |

[OCR_TABLE]
ad el
Endc

[OCR]
Case 9

Medical History:

Ms. DUVAL, 56 years of age, was suffering from epigastric pain and vomiting
striated with blood. This patient has no previous history of digestive disease.
She is under treatment with paracetamol for gonarthritis. Her weight is 75 kg
and height 160 cm. She does not smoke, but has consumed about 50 g of pure
alcohol daily for the past 25 years. She occasionally takes 1 to 2 g of aspirin per
day, according to her pain. The mucosa of the gastric antrum and the duodenal
bulb is normal.

Biological Tests:

Hemoglobin: 10.5 g/dL (N > 12)
MCV: 100 ye (85 - 95)
Leukocytes: 8.5 x 109/L (5 - 10 x 10°)
of which 65% are polynuclear neutrophiles
Platelets: 145 x 109/L (100 - 300 x 109)
PT: 75% (N > 75)
Gamma GT: 75 1U (N < 35)

Transaminases: ALT and AST normal

Comments:

This is a typical type of aspirin-induced hemorrhagic gastritis.

Following ingestion of aspirin, petechia-type lesions appear within less than 60
minutes at the level of the fundic mucosa in more than 80% of cases.

These lesions are ephemeral and disappear in a few days if the patient stops
aspirin ingestion. They can also disappear in cases where the patient takes
aspirin regularly, due to a phenomenon of mucosal adaption.

Hemorrhagic gastritis

surgical GI Mentor


# Page 13

Upper Gastrointestinal  
Endoscopy (Gastroscopy) 
Second Module -
13
GI Mentor
9
Case 9
Gastritis does not include gastro-duodenal lesions linked to the ingestion of 
aspirin, which can cause penetrating ulcers and hemorrhages, sometimes 
severe, of the digestive tract.
Taking alcohol with aspirin increases the mucosal toxicity of the latter drug.
No specific treatment is necessary.
Aspirin causes mucosal lesions even at doses intended for the prevention of 
platelet aggregation, but the severity of these lesions is proportional to the 
ingested dose. Platelet anti-aggregates (such as ticlopidine) increase the risk of 
gastro-duodenal hemorrhage, but do not create lesions of the mucosa.


[TABLE]
|                                                                                    |
|:-----------------------------------------------------------------------------------|
| Case 9                                                                             |
| 9                                                                                  |
| Gastritis does not include gastro-duodenal lesions linked to the ingestion of      |
| aspirin, which can cause penetrating ulcers and hemorrhages, sometimes             |
| severe, of the digestive tract.                                                    |
| Taking alcohol with aspirin increases the mucosal toxicity of the latter drug.     |
| No specific treatment is necessary.                                                |
| Aspirin causes mucosal lesions even at doses intended for the prevention of        |
| platelet aggregation, but the severity of these lesions is proportional to the     |
| ingested dose. Platelet anti-aggregates (such as ticlopidine) increase the risk of |
| gastro-duodenal hemorrhage, but do not create lesions of the mucosa.               |

[OCR]
Case 9

Gastritis does not include gastro-duodenal lesions linked to the ingestion of
aspirin, which can cause penetrating ulcers and hemorrhages, sometimes
severe, of the digestive tract.

Taking alcohol with aspirin increases the mucosal toxicity of the latter drug.
No specific treatment is necessary.

Aspirin causes mucosal lesions even at doses intended for the prevention of
platelet aggregation, but the severity of these lesions is proportional to the
ingested dose. Platelet anti-aggregates (such as ticlopidine) increase the risk of
gastro-duodenal hemorrhage, but do not create lesions of the mucosa.

surgical GI Mentor


# Page 14

Upper Gastrointestinal  
Endoscopy (Gastroscopy) 
Second Module -
14
GI Mentor
10
Medical History: 
Mr. CHARLES, 56 years of age, was hospitalized due to general deterioration, 
with jaundice and edema of the lower limbs. 
The liver is enlarged in volume with a sharp lower edge. There is porta-caval 
collateral venous circulation, but no ascitis.
Biological Tests: 
ALT: 
 
56 IU 
 
(N < 35) 
AST: 
 
125 IU  
(N < 35) 
Alk. Phos: 
1250 IU  
(N < 100) 
Total bilirubin: 
65 µM  
(N < 10) 
Hemoglobin: 
10.5 g/dL 
(N > 14) 
MCV: 
 
117 µ³ 
 
(85 - 95) 
Leukocytes: 
15.7 x 10⁹/L 
 
 
 
of which 87% polynuclear neutrophiles
Comments: 
This is a typical case of hypertensive gastropathy, due to a cirrhosis of the 
liver. This aspect may be observed in the absence of esophageal varices.  
This aspect is more obvious using video-endoscope. 
This aspect is different from EVA, which are “angioma” of the antral mucosa. 
They are seen in most causes in the fundic area - Portal hypertensive 
gastropathy is a real cause of upper GI bleeding. 
The treatment is Avlocardyl® (propranolol).
Case 10
Portal hypertensive 
gastropathy


[TABLE]
|                                             |                                                                               |    |
|:--------------------------------------------|:------------------------------------------------------------------------------|:---|
| 10                                          | Case 10                                                                       |    |
| Medical History:                            |                                                                               |    |
|                                             | Mr.	CHARLES,	56	years	of	age,	was	hospitalized	due	to	general	deterioration,                                                                               |    |
|                                             | with jaundice and edema of the lower limbs.                                   |    |
|                                             | The liver is enlarged in volume with a sharp lower edge. There is porta-caval |    |
|                                             | collateral venous circulation, but no ascitis.                                |    |
| Biological Tests:                           |                                                                               |    |
| ALT:                                        | 56	IU                                                                               | (N	<	35)    |
| AST:                                        | 125	IU                                                                               | (N	<	35)    |
| Alk.	Phos:                                             | 1250	IU                                                                               | (N	<	100)    |
| Total	bilirubin:                                             | 65	µM                                                                               | (N	<	10)    |
| Hemoglobin:                                 | 10.5	g/dL                                                                               | (N	>	14)    |
| MCV:                                        | 117	µ³                                                                               | (85	-	95)    |
| Leukocytes:                                 | 15.7	x	10⁹/L                                                                               |    |
|                                             | of	which	87%	polynuclear	neutrophiles                                                                               |    |
| Comments:                                   |                                                                               |    |
|                                             | This is a typical case of hypertensive gastropathy, due to a cirrhosis of the |    |
|                                             | liver. This aspect may be observed in the absence of esophageal varices.      |    |
|                                             | This aspect is more obvious using video-endoscope.                            |    |
|                                             | This aspect is different from EVA, which are “angioma” of the antral mucosa.  |    |
|                                             | They	are	seen	in	most	causes	in	the	fundic	area	-	Portal	hypertensive                                                                               |    |
|                                             | gastropathy is a real cause of upper GI bleeding.                             |    |
| The treatment is Avlocardyl® (propranolol). |                                                                               |    |

[OCR]
Case 10

Medical History:

Mr. CHARLES, 56 years of age, was hospitalized due to general deterioration,
with jaundice and edema of the lower limbs.

The liver is enlarged in volume with a sharp lower edge. There is porta-caval
collateral venous circulation, but no ascitis.

Biological Tests:

ALT: 56 1U (N < 35)
AST: 125 1U (N < 35)
Alk. Phos: 1250 IU (N < 100)
Total bilirubin: 65 uM (N < 10)
Hemoglobin: 10.5 g/dL (N > 14)
MCV: 117 pe (85 - 95)

Leukocytes: 15.7 x 109/L
of which 87% polynuclear neutrophiles

Comments:

This is a typical case of hypertensive gastropathy, due to a cirrhosis of the
liver. This aspect may be observed in the absence of esophageal varices.
This aspect is more obvious using video-endoscope.

This aspect is different from EVA, which are “angioma” of the antral mucosa.
They are seen in most causes in the fundic area - Portal hypertensive
gastropathy is a real cause of upper GI bleeding.

The treatment is Aviocardyl® (propranolol).

Portal hypertensive
gastropathy

surgical GI Mentor