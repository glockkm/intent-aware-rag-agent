

# Page 1

TURP Procedure Proctor Book 
Overview 
This module includes hands-on training on clinical cases of transurethral resection 
of the prostate (TURP) procedure. The cases present realistic scenarios of benign 
prostatic hyperplasia (BPH) with small to large side lobes and median lobes, with 
variations in bleeding severity.   
Accompanied by comprehensive educational aids, trainees can practice hands-on 
resection, visualization of anatomical landmarks, management of irrigation fluid 
and control of bleeding.   
Unique Features: 
• 
Virtual training for monopolar and bipolar resectoscopes 
• 
Different angled optics 
• 
Complete virtual patient environment with realistic anatomy 
• 
Resection Assist educational aid with colored map visualization and 
planning of cutting regions 
• 
Progress bar tracking of percentage of prostate resected 
• 
On-screen warning and complication messages  
• 
Clear view mode – simulated environment enabled clearing view to help 
diagnose bleeding sources 
• 
Performance review provides feedback of safety measures and 
complication handling for post-procedure debriefing 
Acknowledgements 
This module was created in collaboration with: 
• 
Dr. Yaniv Shilo, Director of Endourology, Kaplan Medical Center, Rehovot, 
Israel. 


[TABLE]
| TURP Procedure Proctor Book                                                         |
|:------------------------------------------------------------------------------------|
| Overview                                                                            |
| This module includes hands-on training on clinical cases of transurethral resection |
| of the prostate (TURP) procedure. The cases present realistic scenarios of benign   |
| prostatic hyperplasia (BPH) with small to large side lobes and median lobes, with   |
| variations in bleeding severity.                                                    |
| Accompanied by comprehensive educational aids, trainees can practice hands-on       |
| resection, visualization of anatomical landmarks, management of irrigation fluid    |
| and control of bleeding.                                                            |
| Unique Features:                                                                    |

[TABLE]
| resection, visualization of anatomical landmarks, management of irrigation fluid   |                                                                       |
|:-----------------------------------------------------------------------------------|:----------------------------------------------------------------------|
| and control of bleeding.                                                           |                                                                       |
| Unique Features:                                                                   |                                                                       |
| •                                                                                  | Virtual training for monopolar and bipolar resectoscopes              |
| •                                                                                  | Different angled optics                                               |
| •                                                                                  | Complete virtual patient environment with realistic anatomy           |
| •                                                                                  | Resection Assist educational aid with colored map visualization and   |
|                                                                                    | planning of cutting regions                                           |
| •                                                                                  | Progress bar tracking of percentage of prostate resected              |
| •                                                                                  | On-screen warning and complication messages                           |
| •                                                                                  | Clear view mode – simulated environment enabled clearing view to help |
|                                                                                    | diagnose bleeding sources                                             |
| •                                                                                  | Performance review provides feedback of safety measures and           |
|                                                                                    | complication handling for post-procedure debriefing                   |

[OCR]
TURP Procedure Proctor Book

Overview

This module includes hands-on training on clinical cases of transurethral resection
of the prostate (TURP) procedure. The cases present realistic scenarios of benign
prostatic hyperplasia (BPH) with small to large side lobes and median lobes, with
variations in bleeding severity.

Accompanied by comprehensive educational aids, trainees can practice hands-on
resection, visualization of anatomical landmarks, management of irrigation fluid
and control of bleeding.

Unique Features:

° Virtual training for monopolar and bipolar resectoscopes

° Different angled optics

° Complete virtual patient environment with realistic anatomy

° Resection Assist educational aid with colored map visualization and
planning of cutting regions

° Progress bar tracking of percentage of prostate resected

. On-screen warning and complication messages

° Clear view mode — simulated environment enabled clearing view to help
diagnose bleeding sources

° Performance review provides feedback of safety measures and

complication handling for post-procedure debriefing

Acknowledgements

This module was created in collaboration with:

. Dr. Yaniv Shilo, Director of Endourology, Kaplan Medical Center, Rehovot,
Israel.


# Page 2

URO Mentor 
 
Page 2 
 
Case Description 
Case Description 
Notes 
Case 1 – Easy 
Approximately 30 grams prostate 
Light bleeding 
Small median lobe and side lobes 
Case 2 – Easy 
Approximately 40 grams prostate 
Light bleeding 
Medium median lobe & small side lobes 
Case 3 – Easy 
Approximately 45 grams prostate 
Light bleeding 
Small median lobe and side lobes 
Case 4 – Moderate 
Approximately 55 grams prostate 
Moderate bleeding 
Small median lobe and side lobes 
Case 5 – Moderate 
Approximately 60 grams prostate 
Moderate bleeding 
Large median lobe & side lobes 
Case 6 – Moderate 
Approximately 70 grams prostate 
Moderate bleeding 
Medium median lobe & side lobes 
Case 7 – Advanced 
Approximately 80 grams prostate 
Severe bleeding 
Medium median lobe & side lobes 
Case 8 – Advanced 
Approximately 90 grams prostate 
Severe bleeding 
Small median lobe and large side lobes 
Case 9 – Advanced 
Approximately 100 grams prostate 
Severe bleeding 
Large median lobe & side lobes 


[TABLE]
| Case Description   |                                  |                                        |
|:-------------------|:---------------------------------|:---------------------------------------|
| Case Description   |                                  | Notes                                  |
|                    | Approximately 30 grams prostate  |                                        |
| Case 1 – Easy      | Light bleeding                   |                                        |
|                    | Small median lobe and side lobes |                                        |
|                    | Approximately 40 grams prostate  |                                        |
| Case 2 – Easy      | Light bleeding                   |                                        |
|                    |                                  | Medium median lobe & small side lobes  |
|                    | Approximately 45 grams prostate  |                                        |
| Case 3 – Easy      | Light bleeding                   |                                        |
|                    | Small median lobe and side lobes |                                        |
|                    | Approximately 55 grams prostate  |                                        |
| Case 4 – Moderate  | Moderate bleeding                |                                        |
|                    | Small median lobe and side lobes |                                        |
|                    | Approximately 60 grams prostate  |                                        |
| Case 5 – Moderate  | Moderate bleeding                |                                        |
|                    | Large median lobe & side lobes   |                                        |
|                    | Approximately 70 grams prostate  |                                        |
| Case 6 – Moderate  | Moderate bleeding                |                                        |
|                    | Medium median lobe & side lobes  |                                        |
|                    | Approximately 80 grams prostate  |                                        |
| Case 7 – Advanced  | Severe bleeding                  |                                        |
|                    | Medium median lobe & side lobes  |                                        |
|                    | Approximately 90 grams prostate  |                                        |
| Case 8 – Advanced  | Severe bleeding                  |                                        |
|                    |                                  | Small median lobe and large side lobes |
|                    | Approximately 100 grams prostate |                                        |
| Case 9 – Advanced  | Severe bleeding                  |                                        |
|                    | Large median lobe & side lobes   |                                        |

[OCR]
URO Mentor

Case Description

Case Description

Notes

Approximately 30 grams prostate

Case 1 - Easy Light bleeding
Small median lobe and side lobes
Approximately 40 grams prostate

Case 2 - Easy Light bleeding
Medium median lobe & small side lobes
Approximately 45 grams prostate

Case 3 - Easy Light bleeding

Small median lobe and side lobes

Case 4 — Moderate

Approximately 55 grams prostate
Moderate bleeding

Small median lobe and side lobes

Case 5 — Moderate

Approximately 60 grams prostate
Moderate bleeding

Large median lobe & side lobes

Case 6 — Moderate

Approximately 70 grams prostate
Moderate bleeding
Medium median lobe & side lobes

Case 7 — Advanced

Approximately 80 grams prostate
Severe bleeding

Medium median lobe & side lobes

Case 8 — Advanced

Approximately 90 grams prostate
Severe bleeding

Small median lobe and large side lobes

Case 9 — Advanced

Approximately 100 grams prostate
Severe bleeding

Large median lobe & side lobes

Page 2

surgicalscience


# Page 3

TURP Procedure Proctor Book
 
Page 3 
 
 
Module-Specific Hardware 
Device 
Physical Hardware 
Resectoscope 
 
 
Keyboard Shortcuts 
Shortcut Key 
Description 
CTRL+F 
Freeze the resectoscope location to enable a live screen 
view without the need to manually hold the resectoscope  


[TABLE]
|    |                         | TURP Procedure Proctor Book                              |
|:---|:------------------------|:---------------------------------------------------------|
| M  | odule-Specific Hardware |                                                          |
|    | Device                  | Physical Hardware                                        |
|    | Resectoscope            |                                                          |
| K  | eyboard Shortcuts       |                                                          |
|    | Shortcut Key            | Description                                              |
|    | CTRL+F                  | Freeze the resectoscope location to enable a live screen |
|    |                         | view without the need to manually hold the resectoscope  |
|    |                         | Page 3                                                   |

[OCR]
TURP Procedure Proctor Book

Module-Specific Hardware

Device Physical Hardware

Resectoscope
Keyboard Shortcuts
Shortcut Key Description
CTRL+F Freeze the resectoscope location to enable a live screen
view without the need to manually hold the resectoscope

surgicalscience Page 3


# Page 4

URO Mentor 
 
Page 4 
 
Performance Report 
Metric 
Definition 
Time & Economy 
Procedure time 
Total procedure time, measured from scope 
entrance until exit from case (hh:mm:ss) 
Ergonomics 
Working angle 00 /120 / 300 
Percentage of time trainee worked with angle 
Educational Aids 
Percent time worked in Clear 
View mode 
Measures percentage of time the Clear View 
mode was turned on 
Percent time worked in 
Resection Assist mode 
Measures percentage of time Resection Assist 
mode was turned on 
Resection 
Amount of prostate resected 
Measures the percentage of prostate resected 
Resection during movement 
Measures the number of occurrences that 
resection was applied during scope movement 
Active cutting towards the 
bladder 
Measures the number of occurrences that 
resection was done with loop movements in 
direction of the bladder  
Bleeding control 
Percent time worked in low 
visibility 
Measures the percentage of time during 
procedure trainee worked in low visibility 
Remaining bleeders 
Indicates the number of bleeders remained 
open 


[TABLE]
| Performance Report           |                                              |
|:-----------------------------|:---------------------------------------------|
| Metric                       | Definition                                   |
| Time & Economy               |                                              |
| Procedure time               | Total procedure time, measured from scope    |
|                              | entrance until exit from case (hh:mm:ss)     |
| Ergonomics                   |                                              |
| Working angle 00 /120 / 300  | Percentage of time trainee worked with angle |
| Educational Aids             |                                              |
| Percent time worked in Clear | Measures percentage of time the Clear View   |
| View mode                    | mode was turned on                           |
| Percent time worked in       | Measures percentage of time Resection Assist |
| Resection Assist mode        | mode was turned on                           |
| Resection                    |                                              |
| Amount of prostate resected  | Measures the percentage of prostate resected |
| Resection during movement    | Measures the number of occurrences that      |
|                              | resection was applied during scope movement  |
| Active cutting towards the   | Measures the number of occurrences that      |
| bladder                      | resection was done with loop movements in    |
|                              | direction of the bladder                     |
| Bleeding control             |                                              |
| Percent time worked in low   | Measures the percentage of time during       |
| visibility                   | procedure trainee worked in low visibility   |
| Remaining bleeders           | Indicates the number of bleeders remained    |
|                              | open                                         |

[OCR]
URO Mentor

Performance Report

Metric

Definition

Time & Economy

Procedure time

Total procedure time, measured from scope
entrance until exit from case (hh:mm:ss)

Ergonomics

Working angle 0°/12°/ 30°

Percentage of time trainee worked with angle

Educational Aids

Percent time worked in Clear
View mode

Measures percentage of time the Clear View
mode was turned on

Percent time worked in
Resection Assist mode

Measures percentage of time Resection Assist
mode was turned on

Resection

Amount of prostate resected

Measures the percentage of prostate resected

Resection during movement

Measures the number of occurrences that
resection was applied during scope movement

Active cutting towards the
bladder

Measures the number of occurrences that
resection was done with loop movements in
direction of the bladder

Bleeding control

Percent time worked in low
visibility

Measures the percentage of time during
procedure trainee worked in low visibility

Remaining bleeders

Indicates the number of bleeders remained
open

Page 4

surgicalscience


# Page 5

TURP Procedure Proctor Book
 
Page 5 
 
Coagulation surface accuracy 
Measures the percentage of accurate 
coagulation done out of total coagulation 
attempts 
Time coagulation is applied 
without appropriate contact 
with tissue 
Measures the total time coagulation is applied 
without contact with tissue (hh:mm:ss) 
Safety 
Cuts into the verumontanum 
Measured the number of occurrences in 
which the trainee cuts into the 
verumontanum 
Cuts into urethral orifices 
Measured the number of occurrences in 
which the trainee cuts into the ureteral 
orifices 
Cuts into capsule 
Measured the number of occurrences in 
which the trainee cuts into the capsule 
Visualization 
Total path of camera  
Measures the total distance that was traveled 
with the camera during the procedure (cm) 
Right urethral orifice 
Indicates if the right urethral orifice was 
visualized (Yes/No)  
Left urethral orifice 
Indicates if the left urethral orifice was 
visualized (Yes/No) 
 
 
 


[TABLE]
|                              | TURP Procedure Proctor Book                    |
|:-----------------------------|:-----------------------------------------------|
| Coagulation surface accuracy | Measures the percentage of accurate            |
|                              | coagulation done out of total coagulation      |
|                              | attempts                                       |
| Time coagulation is applied  | Measures the total time coagulation is applied |
| without appropriate contact  | without contact with tissue (hh:mm:ss)         |
| with tissue                  |                                                |
| Safety                       |                                                |
| Cuts into the verumontanum   | Measured the number of occurrences in          |
|                              | which the trainee cuts into the                |
|                              | verumontanum                                   |
| Cuts into urethral orifices  | Measured the number of occurrences in          |
|                              | which the trainee cuts into the ureteral       |
|                              | orifices                                       |
| Cuts into capsule            | Measured the number of occurrences in          |
|                              | which the trainee cuts into the capsule        |
| Visualization                |                                                |
| Total path of camera         | Measures the total distance that was traveled  |
|                              | with the camera during the procedure (cm)      |
| Right urethral orifice       | Indicates if the right urethral orifice was    |
|                              | visualized (Yes/No)                            |
| Left urethral orifice        | Indicates if the left urethral orifice was     |
|                              | visualized (Yes/No)                            |

[OCR]
TURP Procedure Proctor Book

Coagulation surface accuracy

Measures the percentage of accurate
coagulation done out of total coagulation
attempts

Time coagulation is applied
without appropriate contact
with tissue

Measures the total time coagulation is applied
without contact with tissue (hh:mm:ss)

Safety

Cuts into the verumontanum

Measured the number of occurrences in
which the trainee cuts into the
verumontanum

Cuts into urethral orifices

Measured the number of occurrences in
which the trainee cuts into the ureteral
orifices

Cuts into capsule

Measured the number of occurrences in
which the trainee cuts into the capsule

Visualization

Total path of camera

Measures the total distance that was traveled
with the camera during the procedure (cm)

Right urethral orifice

Indicates if the right urethral orifice was
visualized (Yes/No)

Left urethral orifice

Indicates if the left urethral orifice was
visualized (Yes/No)

surgicalscience

Page 5


# Page 6

URO Mentor 
 
Page 6 
 
Main Features and Controls 
Feature 
Button 
Description 
Patient file 
 
Review the case objectives 
Sound  
 
Mute the sound 
3D map 
 
Dynamic external view of the 
prostate and bladder and 
current position of the 
resectoscope during the 
procedure 
3D slicer 
 
Slice through the 3D anatomy 
on the external view using a 
scroll bar 
Camera angle 
 
Selection of camera angle  
00, 120 or 300 
Tool selection 
 
 
Select monopolar or bipolar 
loop 
Resection Assist mode 
 
Color height map indicating 
areas remained to resect 
Resection progress bar 
 
Percent of prostate resected 
Clear View mode 
 
Clear the view for helping 
diagnose bleeding sources 
 


[TABLE]
| Main Features and Controls   |        |                              |
|:-----------------------------|:-------|:-----------------------------|
| Feature                      | Button | Description                  |
| Patient file                 |        | Review the case objectives   |
| Sound                        |        | Mute the sound               |
| 3D map                       |        | Dynamic external view of the |
|                              |        | prostate and bladder and     |
|                              |        | current position of the      |
|                              |        | resectoscope during the      |
|                              |        | procedure                    |
| 3D slicer                    |        | Slice through the 3D anatomy |
|                              |        | on the external view using a |
|                              |        | scroll bar                   |
| Camera angle                 |        | Selection of camera angle    |
|                              |        | 00, 120 or 300               |
|                              |        | Select monopolar or bipolar  |
|                              |        | loop                         |
| Tool selection               |        |                              |
|                              |        | Color height map indicating  |
| Resection Assist mode        |        |                              |
|                              |        | areas remained to resect     |
|                              |        | Percent of prostate resected |
| Resection progress bar       |        |                              |
|                              |        | Clear the view for helping   |
| Clear View mode              |        |                              |
|                              |        | diagnose bleeding sources    |

[OCR]
URO Mentor

Main Features and Controls

Feature Button Description

Patient file Review the case objectives

Sound Mute the sound

3D map Dynamic external view of the
prostate and bladder and
current position of the
resectoscope during the
procedure

3D slicer Slice through the 3D anatomy

on the external view using a
scroll bar

Camera angle

Selection of camera angle
0°, 12° or 30°

Tool selection

Select monopolar or bipolar
loop

Resection Assist mode

Color height map indicating
areas remained to resect

Resection progress bar

Percent of prostate resected

Clear View mode

Clear the view for helping
diagnose bleeding sources

Page 6

surgicalscience