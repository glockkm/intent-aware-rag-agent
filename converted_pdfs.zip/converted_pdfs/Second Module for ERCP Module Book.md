

# Page 1

Endoscopic Retrograde 
Cholangio-pancreatography (ERCP)
Second Module -
1
GI Mentor
The Module provides the opportunity for advanced training on complicated 
ERCP procedures.
The module objectives are:
	
 Practicing new medical cases with distinctive pathologies.
	
 Performing scope maneuvers to find the papilla, cannulation, and 
radiographic demonstration of the biliary system.
	
 Using a wide variety of accessories (tools) to perform sphincterotomy and 
therapy.
	
 Training on the manipulation of plastic and metal stents.
The module consists of 10 cases that include all the above-indicated training 
objectives.
The cases were created in collaboration with PD Dr. med. Michael Keymling, 
Klinikum Meiningen, Germany.


[TABLE]
| Cholangio-pancreatography (ERCP)                                              |
|:------------------------------------------------------------------------------|
| The Module provides the opportunity for advanced training on complicated      |
| ERCP procedures.                                                              |
| The module objectives are:                                                    |
|  Practicing new medical cases with distinctive pathologies.                                                                               |
|  Performing scope maneuvers to find the papilla, cannulation, and                                                                               |
| radiographic demonstration of the biliary system.                             |
|  Using a wide variety of accessories (tools) to perform sphincterotomy and                                                                               |
| therapy.                                                                      |
|  Training on the manipulation of plastic and metal stents.                                                                               |
| The module consists of 10 cases that include all the above-indicated training |
| objectives.                                                                   |
| The cases were created in collaboration with PD Dr. med. Michael Keymling,    |
| Klinikum Meiningen, Germany.                                                  |

[OCR]
Second Module -
Endoscopic Retrograde |

Cholangio-pancreatography (ERCP)

The Module provides the opportunity for advanced training on complicated
ERCP procedures.

The module objectives are:

= Practicing new medical cases with distinctive pathologies.

= Performing scope maneuvers to find the papilla, cannulation, and
radiographic demonstration of the biliary system.

= Using a wide variety of accessories (tools) to perform sphincterotomy and
therapy.

= Training on the manipulation of plastic and metal stents.

The module consists of 10 cases that include all the above-indicated training

objectives.

The cases were created in collaboration with PD Dr. med. Michael Keymling,
Klinikum Meiningen, Germany.

surgical GI Mentor


# Page 2

Endoscopic Retrograde 
Cholangio-pancreatography (ERCP)
Second Module -
2
GI Mentor
1
Medical History 
A 24-year-old male is hospitalized because of acute upper abdominal pain. He 
has no previous medical history. The physical examination shows tenderness 
of the upper abdomen, very small bowel movements, and a temperature of 
38.6°C.
Biological Tests: 
WBC: 
 
13,000/mm³ 
(4,500 - 11,000) 
Alk. Phos: 
310 U/L  
(<180) 
Lipase:  
7,800 U/L 
(<60) 
Total bilirubin: 
2.8 mg/dL 
(N=1.0)
Ultrasound: 
Gallbladder and liver normal, pancreas could not be seen due to air distention.
Plain film of abdomen: 
No ileus and no perforation are seen.
Comments: 
The diagnosis was acute biliary pancreatitis due to a suspicion of a stone in 
the common bile duct. Emergency ERCP was performed, which demonstrated 
a small CBD stone. The biliary duct system was not dilated.Complete 
sphincterotomy was performed, and the stone was extracted with a basket. 
Lipase values fell to normal within four days, and the patient was discharged 
from the hospital seven days after admission.
Fluoroscopic view
Case 1 


[TABLE]
|                                                                                 |            |         |
|:--------------------------------------------------------------------------------|:-----------|:--------|
| 1                                                                               | Case 1     |         |
| Medical History                                                                 |            |         |
| A 24-year-old male is hospitalized because of acute upper abdominal pain. He    |            |         |
| has no previous medical history. The physical examination shows tenderness      |            |         |
| of the upper abdomen, very small bowel movements, and a temperature of          |            |         |
| 38.6°C.                                                                         |            |         |
| Biological Tests:                                                               |            |         |
| WBC:                                                                            | 13,000/mm³ | (4,500	-	11,000)         |
| Alk.	Phos:                                                                                 | 310	U/L            | (<180)  |
| Lipase:                                                                         | 7,800	U/L            | (<60)   |
| Total	bilirubin:                                                                                 | 2.8	mg/dL            | (N=1.0) |
| Ultrasound:                                                                     |            |         |
| Gallbladder and liver normal, pancreas could not be seen due to air distention. |            |         |
| Plain film of abdomen:                                                          |            |         |
| No	ileus	and	no	perforation	are	seen.                                                                                 |            |         |
| Comments:                                                                       |            |         |
| The diagnosis was acute biliary pancreatitis due to a suspicion of a stone in   |            |         |
| the common bile duct. Emergency ERCP was performed, which demonstrated          |            |         |
| a small CBD stone. The biliary duct system was not dilated.Complete             |            |         |
| sphincterotomy was performed, and the stone was extracted with a basket.        |            |         |
| Lipase	values	fell	to	normal	within	four	days,	and	the	patient	was	discharged                                                                                 |            |         |
| from the hospital seven days after admission.                                   |            |         |

[OCR_TABLE]
FrL. |

[OCR]
Second Module -
Endoscopic Retrograde |

Cholangio-pancreatography (ERCP)

Case 1

Medical History

A 24-year-old male is hospitalized because of acute upper abdominal pain. He
has no previous medical history. The physical examination shows tenderness
of the upper abdomen, very small bowel movements, and a temperature of

38.6°C.

Biological Tests:

WBC: 13,000/mm? (4,500 - 11,000)
Alk. Phos: 310 U/L (<180)

Lipase: 7,800 U/L (<60)

Total bilirubin: 2.8 mg/dL (N=1.0)
Ultrasound:

Gallbladder and liver normal, pancreas could not be seen due to air distention.

Plain film of abdomen:
No ileus and no perforation are seen.

Comments:

The diagnosis was acute biliary pancreatitis due to a suspicion of a stone in
the common bile duct. Emergency ERCP was performed, which demonstrated
asmall CBD stone. The biliary duct system was not dilated.Complete
sphincterotomy was performed, and the stone was extracted with a basket.
Lipase values fell to normal within four days, and the patient was discharged
from the hospital seven days after admission.

Fluoroscopic view

surgical GI Mentor


# Page 3

Endoscopic Retrograde 
Cholangio-pancreatography (ERCP)
Second Module -
3
GI Mentor
2
Medical History 
A 41-year-old male has suffered from chronic pancreatitis for 10 years due to 
alcoholic abuse. ERCP was performed previously, and a pancreatic stent was 
introduced because of an obstruction at the head of the pancreas. The patient is 
suffering again from indigestion, abdominal pain (cramping), and consequently 
has lost a lot of weight. He is unable to decrease his dependence on alcohol.
Biological Tests: 
WBC: 
 
4,800/mm³ 
(4,500 - 11,000) 
Alk. Phos: 
135 U/L  
(<180) 
Lipase:  
57 U/L  
(<60) 
Total bilirubin: 
0.84 mg/dL 
(N=1.0) 
Platelets: 
77,000/µL 
(150,000 - 440,000) 
Hemoglobin: 
13.0 g/dL 
(14 - 18)
Ultrasound: 
The head of the pancreas is swollen. Calcifications: A proximal dilated 
pancreatic duct is seen as a consequence of the obstructed pancreatic duct. 
No fluid is seen around the pancreas. No areas of necrosis are seen.
EUS: 
The body and tail of the duct are dilated due to stenosis of the pancreas, 
caused by the chronic inflammation of the pancreas.
Case 2 
Fluoroscopic view


[TABLE]
|                                                                                  |           |         |
|:---------------------------------------------------------------------------------|:----------|:--------|
| 2                                                                                | Case 2    |         |
| Medical History                                                                  |           |         |
| A 41-year-old male has suffered from chronic pancreatitis for 10 years due to    |           |         |
| alcoholic abuse. ERCP was performed previously, and a pancreatic stent was       |           |         |
| introduced because of an obstruction at the head of the pancreas. The patient is |           |         |
| suffering again from indigestion, abdominal pain (cramping), and consequently    |           |         |
| has lost a lot of weight. He is unable to decrease his dependence on alcohol.    |           |         |
| Biological Tests:                                                                |           |         |
| WBC:                                                                             | 4,800/mm³ | (4,500	-	11,000)         |
| Alk.	Phos:                                                                                  | 135	U/L           | (<180)  |
| Lipase:                                                                          | 57	U/L           | (<60)   |
| Total	bilirubin:                                                                                  | 0.84	mg/dL           | (N=1.0) |
| Platelets:                                                                       | 77,000/µL | (150,000	-	440,000)         |
| Hemoglobin:                                                                      | 13.0	g/dL           | (14	-	18)         |
| Ultrasound:                                                                      |           |         |
| The head of the pancreas is swollen. Calcifications: A proximal dilated          |           |         |
| pancreatic duct is seen as a consequence of the obstructed pancreatic duct.      |           |         |
| No	fluid	is	seen	around	the	pancreas.	No	areas	of	necrosis	are	seen.                                                                                  |           |         |
| EUS:                                                                             |           |         |
| The body and tail of the duct are dilated due to stenosis of the pancreas,       |           |         |
| caused by the chronic inflammation of the pancreas.                              |           |         |

[OCR_TABLE]
Chal

[OCR]
Second Module -
Endoscopic Retrograde |

Cholangio-pancreatography (ERCP)

Case 2

Medical History

A 41-year-old male has suffered from chronic pancreatitis for 10 years due to
alcoholic abuse. ERCP was performed previously, and a pancreatic stent was
introduced because of an obstruction at the head of the pancreas. The patient is
suffering again from indigestion, abdominal pain (cramping), and consequently
has lost a lot of weight. He is unable to decrease his dependence on alcohol.

Biological Tests:

WBC: 4,800/mm? (4,500 - 11,000)

Alk. Phos: 135 U/L (<180)

Lipase: 57 U/L (<60)

Total bilirubin: 0.84 mg/dL (N=1.0)

Platelets: 77,000/uL (150,000 - 440,000)
Hemoglobin: 13.0 g/dL (14 - 18)
Ultrasound:

he head of the pancreas is swollen. Calcifications: A proximal dilated
pancreatic duct is seen as a consequence of the obstructed pancreatic duct.
No fluid is seen around the pancreas. No areas of necrosis are seen.

Eus:
The body and tail of the duct are dilated due to stenosis of the pancreas,
caused by the chronic inflammation of the pancreas.

Fluoroscopic view

surgical GI Mentor


# Page 4

Endoscopic Retrograde 
Cholangio-pancreatography (ERCP)
Second Module -
4
GI Mentor
Comments:
1.	 Pain due to chronic pancreatitis at the head of the pancreas can be resolved 
by inserting plastic stents. Clinical symptoms can be improved if it is 
successful.
2.	To avoid stent occlusion, the stent should be changed every 2-3 months.
3.	In cases of chronic pancreatitis, blood levels are not always elevated. In this 
case, the low platelets indicate additional cirrhosis of the liver.
2
Case 2 


[TABLE]
| Second Module -                                                                    |
|:-----------------------------------------------------------------------------------|
| Endoscopic Retrograde                                                              |
| Cholangio-pancreatography (ERCP)                                                   |
| Case 2                                                                             |
| 2                                                                                  |
| Comments:                                                                          |
| 1.  Pain due to chronic pancreatitis at the head of the pancreas can be resolved   |
| by inserting plastic stents. Clinical symptoms can be improved if it is            |
| successful.                                                                        |
| 2. To	avoid	stent	occlusion,	the	stent	should	be	changed	every	2-3	months.                                                                                    |
| 3. In cases of chronic pancreatitis, blood levels are not always elevated. In this |
| case, the low platelets indicate additional cirrhosis of the liver.                |
| 4                                                                                  |
| GI Mentor                                                                          |

[OCR]
Second Module -
Endoscopic Retrograde |

Cholangio-pancreatography (ERCP)

Case 2

Comments:

1. Pain due to chronic pancreatitis at the head of the pancreas can be resolved
by inserting plastic stents. Clinical symptoms can be improved if it is
successful.

2. To avoid stent occlusion, the stent should be changed every 2-3 months.

3. In cases of chronic pancreatitis, blood levels are not always elevated. In this
case, the low platelets indicate additional cirrhosis of the liver.

surgical GI Mentor


# Page 5

Endoscopic Retrograde 
Cholangio-pancreatography (ERCP)
Second Module -
5
GI Mentor
3
Medical History: 
A 66 year old male with a medical history of chronic pancreatitis for the last 5 years 
is complaining of a weight loss of 5 kg in the last 6 weeks. He also suffers from 
epigastric pain for the last four days, nausea, intermittent vomiting, and white stool 
the day before hospitalization. He appears jaundiced and has a fever of 39.2°C.
Biological Tests: 
Alk. Phos: 
331 U/L  
(<180) 
Lipase:  
324 U/L  
(<60) 
Total Bilirubin: 
3.24 mg/dL 
(N=1.0) 
Leukocytes: 
17,800/µL 
(4,000 - 9,400) 
GGT: 
 
256 U/L  
(<18) 
CRP: 
 
21.1 mg/dL 
(<1.0)
Ultrasound: 
The pancreatic duct is dilated more than 10 mm in the body and tail. At the 
head of the pancreas, there is no view of the pancreatic duct, with the rest of 
the biliary system appearing normal.
Comments: 
There was no concrement found either in the CBD or the PD during ERCP. The 
mild jaundice could have resulted from the slight pressure on the CBD although 
no dilation of the CBD was observed. The fever was caused by an inflammation 
due to the obstructed PD; decompression of the obstruction was accomplished 
with the insertion of a plastic stent to the PD. The mild jaundice may have 
resulted also from the CBD. Since there was no dilatation of the CBD no stent was 
inserted. The elevated temperature returned to normal the next day; the jaundice 
disappeared and the patient recovered well. Sphincterotomy of the PD should 
be done very carefully although the technique is similar to sphincterotomy of the 
CBD. The risk of bleeding and perforation must always be seriously considered.
Case 3
Fluoroscopic view


[TABLE]
|                                                                                        |                                                                                   |         |
|:---------------------------------------------------------------------------------------|:----------------------------------------------------------------------------------|:--------|
| 3                                                                                      | Case 3                                                                            |         |
| Medical History:                                                                       |                                                                                   |         |
|                                                                                        | A	66	year	old	male	with	a	medical	history	of	chronic	pancreatitis	for	the	last	5	years                                                                                   |         |
|                                                                                        | is	complaining	of	a	weight	loss	of	5	kg	in	the	last	6	weeks.	He	also	suffers	from                                                                                   |         |
| epigastric pain for the last four days, nausea, intermittent vomiting, and white stool |                                                                                   |         |
| the day before hospitalization. He appears jaundiced and has a fever of 39.2°C.        |                                                                                   |         |
| Biological Tests:                                                                      |                                                                                   |         |
| Alk.	Phos:                                                                                        | 331	U/L                                                                                   | (<180)  |
| Lipase:                                                                                | 324	U/L                                                                                   | (<60)   |
| Total	Bilirubin:                                                                                        | 3.24	mg/dL                                                                                   | (N=1.0) |
| Leukocytes:                                                                            | 17,800/µL                                                                         | (4,000	-	9,400)         |
| GGT:                                                                                   | 256	U/L                                                                                   | (<18)   |
| CRP:                                                                                   | 21.1	mg/dL                                                                                   | (<1.0)  |
| Ultrasound:                                                                            |                                                                                   |         |
|                                                                                        | The pancreatic duct is dilated more than 10 mm in the body and tail. At the       |         |
|                                                                                        | head of the pancreas, there is no view of the pancreatic duct, with the rest of   |         |
|                                                                                        | the biliary system appearing normal.                                              |         |
| Comments:                                                                              |                                                                                   |         |
|                                                                                        | There was no concrement found either in the CBD or the PD during ERCP. The        |         |
|                                                                                        | mild jaundice could have resulted from the slight pressure on the CBD although    |         |
|                                                                                        | no dilation of the CBD was observed. The fever was caused by an inflammation      |         |
|                                                                                        | due to the obstructed PD; decompression of the obstruction was accomplished       |         |
|                                                                                        | with the insertion of a plastic stent to the PD. The mild jaundice may have       |         |
|                                                                                        | resulted also from the CBD. Since there was no dilatation of the CBD no stent was |         |
|                                                                                        | inserted. The elevated temperature returned to normal the next day; the jaundice  |         |
|                                                                                        | disappeared and the patient recovered well. Sphincterotomy of the PD should       |         |
|                                                                                        | be done very carefully although the technique is similar to sphincterotomy of the |         |
|                                                                                        | CBD. The risk of bleeding and perforation must always be seriously considered.    |         |
| Fluoroscopic view                                                                      |                                                                                   |         |

[OCR_TABLE]
salah

[OCR]
Second Module -
Endoscopic Retrograde |

Cholangio-pancreatography (ERCP)

Case 3

Medical History:

A 66 year old male with a medical history of chronic pancreatitis for the last 5 years
is complaining of a weight loss of 5 kg in the last 6 weeks. He also suffers from
epigastric pain for the last four days, nausea, intermittent vomiting, and white stool
the day before hospitalization. He appears jaundiced and has a fever of 39.2°C.

Biological Tests:

Alk. Phos: 331 U/L (<180)

Lipase: 324 U/L (<60)

Total Bilirubin: 3.24 mg/dL (N=1.0)
Leukocytes: 17,800/pL (4,000 - 9,400)
GGT: 256 U/L (<18)

CRP: 21.1 mg/dL (<1.0)
Ultrasound:

The pancreatic duct is dilated more than 10 mm in the body and tail. At the
head of the pancreas, there is no view of the pancreatic duct, with the rest of
the biliary system appearing normal.

Comments:

There was no concrement found either in the CBD or the PD during ERCP. The
mild jaundice could have resulted from the slight pressure on the CBD although
no dilation of the CBD was observed. The fever was caused by an inflammation
due to the obstructed PD; decompression of the obstruction was accomplished
with the insertion of a plastic stent to the PD. The mild jaundice may have
resulted also from the CBD. Since there was no dilatation of the CBD no stent was
inserted. The elevated temperature returned to normal the next day; the jaundice
disappeared and the patient recovered well. Sphincterotomy of the PD should

be done very carefully although the technique is similar to sphincterotomy of the
CBD. The risk of bleeding and perforation must always be seriously considered.

Fluoroscopic view

surgical GI Mentor


# Page 6

Endoscopic Retrograde 
Cholangio-pancreatography (ERCP)
Second Module -
6
GI Mentor
4
Medical History: 
A 43 year old female has refused to see a physician in spite of suffering 
from intermittent right upper quadrant pain for a period of 3 weeks. She is 
admitted to the hospital in the middle of the night with severe abdominal pain 
(cramping), a fever of 40°C and a slightly jaundiced appearance.
Biological Tests: 
WBC: 
 
15,000/mm³ 
(4,500-11,000) 
Lipase:  
2300 U/L 
(<60) 
Total Bilirubin: 
4.5 mg/dL 
(N=1.0) 
CRP: 
 
12.0 mg/dL 
(<1.0)
Ultrasound: 
Pancreas was not demonstrated due to air distention. No free fluids or stones 
in the gallbladder were seen.
Plain film of abdomen: 
No signs of perforation or bowel obstruction.
Comments: 
A sphincterotome should be the first choice because the balloon-like 
papilla indicates that sphincterotomy is probably needed. After insertion 
of the sphincterotome, an impacted stone was fluoroscopically revealed. 
Sphincterotomy was performed and the stone fell out spontaneously. The 
patient recovered well after sphincterotomy. Her fever dropped to normal 
values within a day, elevated laboratory findings normalized in two days and 
she was discharged on the third day. As there was no additional stone and the 
gallbladder was normal, no cholecystectomy was performed.
Case 4
Fluoroscopic view


[TABLE]
|                                                                                |            |                |
|:-------------------------------------------------------------------------------|:-----------|:---------------|
| 4                                                                              | Case 4     |                |
| Medical History:                                                               |            |                |
| A 43 year old female has refused to see a physician in spite of suffering      |            |                |
| from intermittent right upper quadrant pain for a period of 3 weeks. She is    |            |                |
| admitted to the hospital in the middle of the night with severe abdominal pain |            |                |
| (cramping), a fever of 40°C and a slightly jaundiced appearance.               |            |                |
| Biological Tests:                                                              |            |                |
| WBC:                                                                           | 15,000/mm³ | (4,500-11,000) |
| Lipase:                                                                        | 2300	U/L            | (<60)          |
| Total	Bilirubin:                                                                                | 4.5	mg/dL            | (N=1.0)        |
| CRP:                                                                           | 12.0	mg/dL            | (<1.0)         |
| Ultrasound:                                                                    |            |                |
| Pancreas	was	not	demonstrated	due	to	air	distention.	No	free	fluids	or	stones                                                                                |            |                |
| in the gallbladder were seen.                                                  |            |                |
| Plain film of abdomen:                                                         |            |                |
| No	signs	of	perforation	or	bowel	obstruction.                                                                                |            |                |
| Comments:                                                                      |            |                |
| A sphincterotome should be the first choice because the balloon-like           |            |                |
| papilla indicates that sphincterotomy is probably needed. After insertion      |            |                |
| of the sphincterotome, an impacted stone was fluoroscopically revealed.        |            |                |
| Sphincterotomy was performed and the stone fell out spontaneously. The         |            |                |
| patient recovered well after sphincterotomy. Her fever dropped to normal       |            |                |
| values within a day, elevated laboratory findings normalized in two days and   |            |                |
| she was discharged on the third day. As there was no additional stone and the  |            |                |
| gallbladder was normal, no cholecystectomy was performed.                      |            |                |
| Fluoroscopic view                                                              |            |                |

[OCR_TABLE]
mm EE we

FrLl. |

[OCR]
Second Module -
Endoscopic Retrograde |

Cholangio-pancreatography (ERCP)

Case 4

Medical History:

A 43 year old female has refused to see a physician in spite of suffering

from intermittent right upper quadrant pain for a period of 3 weeks. She is
admitted to the hospital in the middle of the night with severe abdominal pain
(cramping), a fever of 40°C and a slightly jaundiced appearance.

Biological Tests:

WBC: 15,000/mm? (4,500-11,000)
Lipase: 2300 U/L (<60)

Total Bilirubin: 4.5 mg/dL (N=1.0)

CRP: 12.0 mg/dL (<1.0)
Ultrasound:

Pancreas was not demonstrated due to air distention. No free fluids or stones
in the gallbladder were seen.

Plain film of abdomen:
No signs of perforation or bowel obstruction.

Comments:

A sphincterotome should be the first choice because the balloon-like

papilla indicates that sphincterotomy is probably needed. After insertion

of the sphincterotome, an impacted stone was fluoroscopically revealed.
Sphincterotomy was performed and the stone fell out spontaneously. The
patient recovered well after sphincterotomy. Her fever dropped to normal
values within a day, elevated laboratory findings normalized in two days and
she was discharged on the third day. As there was no additional stone and the
gallbladder was normal, no cholecystectomy was performed.

Fluoroscopic view

~~

fe

surgical GI Mentor


# Page 7

Endoscopic Retrograde 
Cholangio-pancreatography (ERCP)
Second Module -
7
GI Mentor
5
Medical History:
A 46 year old female underwent a complication-free laparoscopic 
cholecystectomy because of stones in the gallbladder. She was discharged 
on the 6th post-operative day. Three days after discharge she developed a 
persistent pain in the right upper abdominal quadrant and a fever of 38.5°C.
Biological Tests: 
WBC: 
 
12,200/mm³ 
(4,500-11,000) 
Alk. Phos: 
486 U/L  
(<180) 
Total Bilirubin: 
3.0 mg/dL 
(N=1.0) 
GGT: 
 
132 U/L  
(<18) 
GOT: 
 
134 U/L  
(<15) 
GPT: 
 
291 U/L  
(<22) 
CRP: 
 
18.3 mg/dL 
(<1.0)
Ultrasound: 
Normal CBD, small amounts of perihepatic fluids were seen.
Comments: 
There was a clear indication for ERCP because leakage from the cystic duct 
was suspected. ERCP was performed on the day of hospitalization and the 
leakage from the cystic duct was proven. During the same session a plastic 
stent was inserted into the CBD in order to bypass the cystic duct. The 
symptoms disappeared and laboratory test results normalized within 10 days. 
The leakage stopped and the plastic stent was removed.
Case 5
Fluoroscopic view


[TABLE]
|                                                                           |                                                                             |                |
|:--------------------------------------------------------------------------|:----------------------------------------------------------------------------|:---------------|
| 5                                                                         | Case 5                                                                      |                |
| Medical History:                                                          |                                                                             |                |
| A 46 year old female underwent a complication-free laparoscopic           |                                                                             |                |
| cholecystectomy because of stones in the gallbladder. She was discharged  |                                                                             |                |
| on the 6th post-operative day. Three days after discharge she developed a |                                                                             |                |
| persistent	pain	in	the	right	upper	abdominal	quadrant	and	a	fever	of	38.5°C.                                                                           |                                                                             |                |
| Biological Tests:                                                         |                                                                             |                |
| WBC:                                                                      | 12,200/mm³                                                                  | (4,500-11,000) |
| Alk.	Phos:                                                                           | 486	U/L                                                                             | (<180)         |
| Total	Bilirubin:                                                                           | 3.0	mg/dL                                                                             | (N=1.0)        |
| GGT:                                                                      | 132	U/L                                                                             | (<18)          |
| GOT:                                                                      | 134	U/L                                                                             | (<15)          |
| GPT:                                                                      | 291	U/L                                                                             | (<22)          |
| CRP:                                                                      | 18.3	mg/dL                                                                             | (<1.0)         |
| Ultrasound:                                                               |                                                                             |                |
|                                                                           | Normal	CBD,	small	amounts	of	perihepatic	fluids	were	seen.                                                                             |                |
| Comments:                                                                 |                                                                             |                |
|                                                                           | There was a clear indication for ERCP because leakage from the cystic duct  |                |
|                                                                           | was suspected. ERCP was performed on the day of hospitalization and the     |                |
|                                                                           | leakage from the cystic duct was proven. During the same session a plastic  |                |
|                                                                           | stent was inserted into the CBD in order to bypass the cystic duct. The     |                |
|                                                                           | symptoms disappeared and laboratory test results normalized within 10 days. |                |
|                                                                           | The leakage stopped and the plastic stent was removed.                      |                |
| Fluoroscopic view                                                         |                                                                             |                |

[OCR]
Second Module -
Endoscopic Retrograde |

Cholangio-pancreatography (ERCP)

Case 5

Medical History:

A 46 year old female underwent a complication-free laparoscopic

cholecystectomy because of stones in the gallbladder. She was discharged
on the 6th post-operative day. Three days after discharge she developed a
persistent pain in the right upper abdominal quadrant and a fever of 38.5°C.

Biological Tests:

WBC: 12,200/mm? (4,500-11,000)
Alk. Phos: 486 U/L (<180)

Total Bilirubin: 3.0 mg/dL (N=1.0)

GGT: 132 U/L (<18)

GOT: 134 U/L (<15)

GPT: 291 U/L (<22)

CRP: 18.3 mg/dL (<1.0)
Ultrasound:

Normal CBD, small amounts of perihepatic fluids were seen.

Comments:

There was a clear indication for ERCP because leakage from the cystic duct
was suspected. ERCP was performed on the day of hospitalization and the
leakage from the cystic duct was proven. During the same session a plastic
stent was inserted into the CBD in order to bypass the cystic duct. The
symptoms disappeared and laboratory test results normalized within 10 days.
The leakage stopped and the plastic stent was removed.

Fluoroscopic view

surgical GI Mentor


# Page 8

Endoscopic Retrograde 
Cholangio-pancreatography (ERCP)
Second Module -
8
GI Mentor
6
Case 6
Medical History: 
A 35 year old male is referred for ERCP because of epigastric pain, a fever of 
38.4°C, nausea and vomiting. Medical history includes a cholecystectomy 3 
years ago and no complaints since then.
Biological Tests: 
Alk. Phos: 
478 U/L  
(<180) 
Lipase:  
30 U/L  
(<60) 
Total Bilirubin: 
2.67 mg/dL 
(N=1.0) 
Platelets: 
158,000/μL 
(150,000-440,000) 
Hemoglobin: 
16.2 g/dL 
(14-18) 
Leukocytes: 
18,800/μL 
(4,000-9,400) 
GGT: 
 
180 U/L  
(<18) 
GOT: 
 
5 U/L 
 
(<15) 
GPT: 
 
12 U/L  
(<22) 
CRP: 
 
12.44 mg/dL 
(<1.0)
Ultrasound: 
No pathology or dilation of common bile duct.
Comments: 
The indication for ERCP was due to the signs of cholangitis. The history 
of cholecystectomy indicated a possible CBD stone, which was the case. 
Cannulation was difficult so a hydrophilic coated guide wire was inserted through 
the ERCP catheter to simplify the access to the CBD. Afterwards this catheter was 
removed and a sphincterotome was introduced into the CBD using the guide wire. 
After the sphincterotome was inserted in the CBD a stone was demonstrated. 
Sphincterotomy was performed and the stone was removed with a basket. If the 
sphincterotomy is unsuccessful, a needle knife sphincterotomy could be helpful.
Fluoroscopic view


[TABLE]
|                                                                                   |            |                   |
|:----------------------------------------------------------------------------------|:-----------|:------------------|
| 6                                                                                 | Case 6     |                   |
| Medical History:                                                                  |            |                   |
| A	35	year	old	male	is	referred	for	ERCP	because	of	epigastric	pain,	a	fever	of                                                                                   |            |                   |
| 38.4°C, nausea and vomiting. Medical history includes a cholecystectomy 3         |            |                   |
| years ago and no complaints since then.                                           |            |                   |
| Biological Tests:                                                                 |            |                   |
| Alk.	Phos:                                                                                   | 478	U/L            | (<180)            |
| Lipase:                                                                           | 30	U/L            | (<60)             |
| Total	Bilirubin:                                                                                   | 2.67	mg/dL            | (N=1.0)           |
| Platelets:                                                                        | 158,000/μL | (150,000-440,000) |
| Hemoglobin:                                                                       | 16.2	g/dL            | (14-18)           |
| Leukocytes:                                                                       | 18,800/μL  | (4,000-9,400)     |
| GGT:                                                                              | 180	U/L            | (<18)             |
| GOT:                                                                              | 5	U/L            | (<15)             |
| GPT:                                                                              | 12	U/L            | (<22)             |
| CRP:                                                                              | 12.44	mg/dL            | (<1.0)            |
| Ultrasound:                                                                       |            |                   |
| No	pathology	or	dilation	of	common	bile	duct.                                                                                   |            |                   |
| Comments:                                                                         |            |                   |
| The indication for ERCP was due to the signs of cholangitis. The history          |            |                   |
| of cholecystectomy indicated a possible CBD stone, which was the case.            |            |                   |
| Cannulation was difficult so a hydrophilic coated guide wire was inserted through |            |                   |
| the ERCP catheter to simplify the access to the CBD. Afterwards this catheter was |            |                   |
| removed and a sphincterotome was introduced into the CBD using the guide wire.    |            |                   |
| After the sphincterotome was inserted in the CBD a stone was demonstrated.        |            |                   |
| Sphincterotomy was performed and the stone was removed with a basket. If the      |            |                   |
| sphincterotomy is unsuccessful, a needle knife sphincterotomy could be helpful.   |            |                   |
| Fluoroscopic view                                                                 |            |                   |

[OCR]
Second Module -
Endoscopic Retrograde |

Cholangio-pancreatography (ERCP)

Case 6

Medical History:

A 35 year old male is referred for ERCP because of epigastric pain, a fever of
38.4°C, nausea and vomiting. Medical history includes a cholecystectomy 3
years ago and no complaints since then.

Biological Tests:

Alk. Phos: 478 U/L <180)

Lipase: 30 U/L <60)

Total Bilirubin: 2.67 mg/dL N=1.0)
Platelets: 158,000/uL 150,000-440,000)
Hemoglobin: 16.2 g/dL 14-18)
Leukocytes: 18,800/uL 4,000-9,400)
GGT: 180 U/L <18)

GOT: 5 U/L <15)

GPT: 12 U/L <22)

CRP: 12.44 mg/dL <1.0)
Ultrasound:

No pathology or dilation of common bile duct.

Comments:

The indication for ERCP was due to the signs of cholangitis. The history

of cholecystectomy indicated a possible CBD stone, which was the case.
Cannulation was difficult so a hydrophilic coated guide wire was inserted through
the ERCP catheter to simplify the access to the CBD. Afterwards this catheter was
removed and a sphincterotome was introduced into the CBD using the guide wire.
After the sphincterotome was inserted in the CBD a stone was demonstrated.
Sphincterotomy was performed and the stone was removed with a basket. If the
sphincterotomy is unsuccessful, a needle knife sphincterotomy could be helpful.

Fluoroscopic view

surgical GI Mentor


# Page 9

Endoscopic Retrograde 
Cholangio-pancreatography (ERCP)
Second Module -
9
GI Mentor
7
Medical History: 
An 80-year-old female has been suffering for the last three weeks from mild 
discomfort in the right upper abdominal quadrant. Her medical history includes 
a cholecystectomy 14 years ago because of gallbladder stones.
Biological Tests: 
Alk. Phos: 
476 U/L to 615 U/L within 7 days  
 
(<180) 
Total Bilirubin: 
0.99 mg/dL to 2.88 mg/dL within 7 days 
 
(N=1.0) 
GOT: 
 
117 U/L to 76 U/L within 7 days 
 
 
(<15)
Ultrasound: 
Normal liver and biliary system, no view of gallbladder.
MRCP: 
Normal biliary system with no signs of stones.
Comments: 
ERCP was performed. A peripapillary diverticulum was found, and 
the fluoroscopic visualization of the CBD did not show any stones. A 
sphincterotomy in cases of diverticulum is dangerous because the plica is 
often torqued, demanding extreme care in the direction of the sphincterotomy. 
A small sphincterotomy (2-3 mm) in the direction of the plica is recommended.
Case 7
Fluoroscopic view


[TABLE]
|                                                                               |                                                                                |         |
|:------------------------------------------------------------------------------|:-------------------------------------------------------------------------------|:--------|
| Case 7                                                                        |                                                                                |         |
| 7                                                                             |                                                                                |         |
| Medical History:                                                              |                                                                                |         |
|                                                                               | An 80-year-old female has been suffering for the last three weeks from mild    |         |
|                                                                               | discomfort in the right upper abdominal quadrant. Her medical history includes |         |
|                                                                               | a cholecystectomy 14 years ago because of gallbladder stones.                  |         |
| Biological Tests:                                                             |                                                                                |         |
| Alk.	Phos:                                                                               | 476	U/L	to	615	U/L	within	7	days                                                                                | (<180)  |
| Total	Bilirubin:                                                                               | 0.99	mg/dL	to	2.88	mg/dL	within	7	days                                                                                | (N=1.0) |
| GOT:                                                                          | 117	U/L	to	76	U/L	within	7	days                                                                                | (<15)   |
| Ultrasound:                                                                   |                                                                                |         |
| Normal	liver	and	biliary	system,	no	view	of	gallbladder.                                                                               |                                                                                |         |
| MRCP:                                                                         |                                                                                |         |
| Normal	biliary	system	with	no	signs	of	stones.                                                                               |                                                                                |         |
| Comments:                                                                     |                                                                                |         |
| ERCP was performed. A peripapillary diverticulum was found, and               |                                                                                |         |
| the fluoroscopic visualization of the CBD did not show any stones. A          |                                                                                |         |
| sphincterotomy in cases of diverticulum is dangerous because the plica is     |                                                                                |         |
| often torqued, demanding extreme care in the direction of the sphincterotomy. |                                                                                |         |
| A	small	sphincterotomy	(2-3	mm)	in	the	direction	of	the	plica	is	recommended.                                                                               |                                                                                |         |

[OCR]
Second Module -
Endoscopic Retrograde |

Cholangio-pancreatography (ERCP)

Case 7

Medical History:

An 80-year-old female has been suffering for the last three weeks from mild
discomfort in the right upper abdominal quadrant. Her medical history includes
a cholecystectomy 14 years ago because of gallbladder stones.

Biological Tests:

Alk. Phos: 476 U/L to 615 U/L within 7 days (<180)
Total Bilirubin: 0.99 mg/dL to 2.88 mg/dL within 7 days (N=1.0)
GOT: 117 U/L to 76 U/L within 7 days (<15)
Ultrasound:

Normal liver and biliary system, no view of gallbladder.

MRCP:

Normal biliary system with no signs of stones.

Comments:

ERCP was performed. A peripapillary diverticulum was found, and

the fluoroscopic visualization of the CBD did not show any stones. A
sphincterotomy in cases of diverticulum is dangerous because the plica is
often torqued, demanding extreme care in the direction of the sphincterotomy.
A small sphincterotomy (2-3 mm) in the direction of the plica is recommended.

Fluoroscopic view

surgical GI Mentor


# Page 10

Endoscopic Retrograde 
Cholangio-pancreatography (ERCP)
Second Module -
10
GI Mentor
8
Medical History: 
An 84-year-old female, with a medical history of hypertonus and Diabetes 
Mellitus, had a cholecystectomy performed 3 months earlier. She now 
complains of upper abdominal pain, nausea, dark-colored urine, and appears 
jaundiced.
Biological Tests: 
Alk. Phos: 
478 U/L  
(<180) 
Total Bilirubin: 
3.64 mg/dL 
(N=1.0) 
Platelets: 
158,000/μL 
(150,000-440,000) 
Hemoglobin: 
15.6 g/dL 
(12-16) 
Leukocytes: 
10,800/μL 
(4,000-9,400) 
GGT: 
 
180 U/L  
(<18)
Ultrasound: 
No pathologies found.
Comments: 
Cannulation of the swollen papilla was difficult, thereby necessitating the 
use of a needle knife to improve access. The needle knife sphincterotomy 
caused some bleeding that stopped spontaneously after a few seconds. After 
sphincterotomy, there are three options:
1.	 Wait for spontaneous passage of the stone.
2.	Extraction of the stone with a basket.
3.	Extraction of the stone with a balloon.
Case 8
Fluoroscopic view


[TABLE]
|                                                                             |            |                   |
|:----------------------------------------------------------------------------|:-----------|:------------------|
| 8                                                                           | Case 8     |                   |
| Medical History:                                                            |            |                   |
| An 84-year-old female, with a medical history of hypertonus and Diabetes    |            |                   |
| Mellitus, had a cholecystectomy performed 3 months earlier. She now         |            |                   |
| complains of upper abdominal pain, nausea, dark-colored urine, and appears  |            |                   |
| jaundiced.                                                                  |            |                   |
| Biological Tests:                                                           |            |                   |
| Alk.	Phos:                                                                             | 478	U/L            | (<180)            |
| Total	Bilirubin:                                                                             | 3.64	mg/dL            | (N=1.0)           |
| Platelets:                                                                  | 158,000/μL | (150,000-440,000) |
| Hemoglobin:                                                                 | 15.6	g/dL            | (12-16)           |
| Leukocytes:                                                                 | 10,800/μL  | (4,000-9,400)     |
| GGT:                                                                        | 180	U/L            | (<18)             |
| Ultrasound:                                                                 |            |                   |
| No	pathologies	found.                                                                             |            |                   |
| Comments:                                                                   |            |                   |
| Cannulation of the swollen papilla was difficult, thereby necessitating the |            |                   |
| use of a needle knife to improve access. The needle knife sphincterotomy    |            |                   |
| caused some bleeding that stopped spontaneously after a few seconds. After  |            |                   |
| sphincterotomy, there are three options:                                    |            |                   |
| 1.  Wait for spontaneous passage of the stone.                              |            |                   |
| 2. Extraction of the stone with a basket.                                   |            |                   |
| 3. Extraction of the stone with a balloon.                                  |            |                   |
| Fluoroscopic view                                                           |            |                   |

[OCR_TABLE]
mE Ewe

ya} oe

[OCR]
Second Module -
Endoscopic Retrograde |

Cholangio-pancreatography (ERCP)

Case 8

Medical History:

An 84-year-old female, with a medical history of hypertonus and Diabetes
Mellitus, had a cholecystectomy performed 3 months earlier. She now
complains of upper abdominal pain, nausea, dark-colored urine, and appears
jaundiced.

Biological Tests:

Alk. Phos: 478 U/L (<180)

Total Bilirubin: 3.64 mg/dL (N=1.0)

Platelets: 158,000/yL (150,000-440,000)
Hemoglobin: 15.6 g/dL (12-16)
Leukocytes: 10,800/uL (4,000-9,400)
GGT: 180 U/L (<18)

Ultrasound:

No pathologies found.

Comments:

Cannulation of the swollen papilla was difficult, thereby necessitating the

use of a needle knife to improve access. The needle knife sphincterotomy
caused some bleeding that stopped spontaneously after a few seconds. After
sphincterotomy, there are three options:

1. Wait for spontaneous passage of the stone.
2. Extraction of the stone with a basket.

3. Extraction of the stone with a balloon.

Fluoroscopic view

surgical GI Mentor


# Page 11

Endoscopic Retrograde 
Cholangio-pancreatography (ERCP)
Second Module -
11
GI Mentor
9
Medical History: 
An 88-year-old female with a medical history of coronary heart disease and 
Diabetes Mellitus suffered from a chronic gastric outlet obstruction due to a 
scarred duodenum after a peri cholecystic abscess. Considering her advanced 
age, a metal stent was inserted in the proximal duodenum one year ago, which 
led to complete relief of her complaints. Three months ago, she was hospitalized 
because of obstructive jaundice. A plastic stent was inserted due to high-grade 
stenosis of the CBD. She is now referred for ERCP because of recurrent right 
upper abdominal pain, jaundice, and an elevated temperature of 38.8°C.
Biological Tests: 
Alk. Phos: 
578 U/L  
(<180) 
Total Bilirubin: 
3.74 mg/dL 
(N=1.0) 
Platelets: 
145,000/μL 
(150,000-440,000) 
Hemoglobin: 
11.2 g/dL 
(12-16) 
Leukocytes: 
8,400/μL 
(4,000-9,400) 
GGT: 
 
211 U/L  
(<18)
Ultrasound: 
Intra-hepatic cholestasis is seen.
Comments: 
ERCP can be performed even through the duodenal metal stent. ERCP was 
performed on the day of admission to the hospital; the clinical symptoms led to 
the suspicion of an occluded stent. The plastic stent was extracted and replaced 
by a metal stent since the patient was in a very good clinical condition.
Case 9
Fluoroscopic view


[TABLE]
|                                                                                  |            |                   |
|:---------------------------------------------------------------------------------|:-----------|:------------------|
| 9                                                                                | Case 9     |                   |
| Medical History:                                                                 |            |                   |
| An 88-year-old female with a medical history of coronary heart disease and       |            |                   |
| Diabetes Mellitus suffered from a chronic gastric outlet obstruction due to a    |            |                   |
| scarred duodenum after a peri cholecystic abscess. Considering her advanced      |            |                   |
| age, a metal stent was inserted in the proximal duodenum one year ago, which     |            |                   |
| led to complete relief of her complaints. Three months ago, she was hospitalized |            |                   |
| because of obstructive jaundice. A plastic stent was inserted due to high-grade  |            |                   |
| stenosis of the CBD. She is now referred for ERCP because of recurrent right     |            |                   |
| upper abdominal pain, jaundice, and an elevated temperature of 38.8°C.           |            |                   |
| Biological Tests:                                                                |            |                   |
| Alk.	Phos:                                                                                  | 578	U/L            | (<180)            |
| Total	Bilirubin:                                                                                  | 3.74	mg/dL            | (N=1.0)           |
| Platelets:                                                                       | 145,000/μL | (150,000-440,000) |
| Hemoglobin:                                                                      | 11.2	g/dL            | (12-16)           |
| Leukocytes:                                                                      | 8,400/μL   | (4,000-9,400)     |
| GGT:                                                                             | 211	U/L            | (<18)             |
| Ultrasound:                                                                      |            |                   |
| Intra-hepatic cholestasis is seen.                                               |            |                   |
| Comments:                                                                        |            |                   |
| ERCP can be performed even through the duodenal metal stent. ERCP was            |            |                   |
| performed on the day of admission to the hospital; the clinical symptoms led to  |            |                   |
| the suspicion of an occluded stent. The plastic stent was extracted and replaced |            |                   |
| by a metal stent since the patient was in a very good clinical condition.        |            |                   |
| Fluoroscopic view                                                                |            |                   |

[OCR]
Second Module -
Endoscopic Retrograde |

Cholangio-pancreatography (ERCP)

Case 9

Medical History:

An 88-year-old female with a medical history of coronary heart disease and
Diabetes Mellitus suffered from a chronic gastric outlet obstruction due to a
scarred duodenum after a peri cholecystic abscess. Considering her advanced
age, a metal stent was inserted in the proximal duodenum one year ago, which
led to complete relief of her complaints. Three months ago, she was hospitalized
because of obstructive jaundice. A plastic stent was inserted due to high-grade
stenosis of the CBD. She is now referred for ERCP because of recurrent right
upper abdominal pain, jaundice, and an elevated temperature of 38.8°C.

Biological Tests:

Alk. Phos: 578 U/L (<180)

Total Bilirubin: 3.74 mg/dL (N=1.0)

Platelets: 145,000/yL (150,000-440,000)
Hemoglobin: 11.2 g/dL (12-16)
Leukocytes: 8,400/uL (4,000-9,400)
GGT: 211 U/L (<18)

Ultrasound:

Intra-hepatic cholestasis is seen.

Comments:

ERCP can be performed even through the duodenal metal stent. ERCP was
performed on the day of admission to the hospital; the clinical symptoms led to
the suspicion of an occluded stent. The plastic stent was extracted and replaced
by a metal stent since the patient was in a very good clinical condition.

Fluoroscopic view

surgical GI Mentor


# Page 12

Endoscopic Retrograde 
Cholangio-pancreatography (ERCP)
Second Module -
12
GI Mentor
10
Medical History: 
An 89 year old female with a medical history of coronary heart disease and 
Diabetes Mellitus appears jaundiced and was referred for ERCP because of 
painless obstructive jaundice for the last week.
Biological Tests: 
Alk. Phos: 
621 U/L  
(<180) 
Total Bilirubin: 
4.74 mg/dL 
(N=1.0) 
Platelets: 
145,000/μL 
(150,000–440,000) 
Hemoglobin: 
14.5 g/dL 
(12–16) 
Leukocytes: 
9,800/μL 
(4,000–9,400) 
GGT: 
 
186 U/L  
(<18)
Ultrasound: 
Dilated bile and intra hepatic ducts are seen. Pancreas is normal.
Comments: 
Filling of CBD showed a high grade subtotal irregular stenosis in the mid 
third of the CBD. A guide wire was inserted and limited sphincterotomy was 
performed. After balloon dilation of the stenosis, brush biopsy was performed 
and a metal stent was inserted due to the patient’s very good clinical condition.
Case 10
Fluoroscopic view


[TABLE]
|                                                                                   |            |                   |
|:----------------------------------------------------------------------------------|:-----------|:------------------|
| 10                                                                                | Case 10    |                   |
| Medical History:                                                                  |            |                   |
| An 89 year old female with a medical history of coronary heart disease and        |            |                   |
| Diabetes Mellitus appears jaundiced and was referred for ERCP because of          |            |                   |
| painless obstructive jaundice for the last week.                                  |            |                   |
| Biological Tests:                                                                 |            |                   |
| Alk.	Phos:                                                                                   | 621	U/L            | (<180)            |
| Total	Bilirubin:                                                                                   | 4.74	mg/dL            | (N=1.0)           |
| Platelets:                                                                        | 145,000/μL | (150,000–440,000) |
| Hemoglobin:                                                                       | 14.5	g/dL            | (12–16)           |
| Leukocytes:                                                                       | 9,800/μL   | (4,000–9,400)     |
| GGT:                                                                              | 186	U/L            | (<18)             |
| Ultrasound:                                                                       |            |                   |
| Dilated bile and intra hepatic ducts are seen. Pancreas is normal.                |            |                   |
| Comments:                                                                         |            |                   |
| Filling of CBD showed a high grade subtotal irregular stenosis in the mid         |            |                   |
| third of the CBD. A guide wire was inserted and limited sphincterotomy was        |            |                   |
| performed. After balloon dilation of the stenosis, brush biopsy was performed     |            |                   |
| and a metal stent was inserted due to the patient’s very good clinical condition. |            |                   |

[OCR]
Second Module -
Endoscopic Retrograde |

Cholangio-pancreatography (ERCP)

Case 10

Medical History:

An 89 year old female with a medical history of coronary heart disease and
Diabetes Mellitus appears jaundiced and was referred for ERCP because of
painless obstructive jaundice for the last week.

Biological Tests:

Alk. Phos: 621 U/L (<180)

Total Bilirubin: 4.74 mg/dL (N=1.0)

Platelets: 145,000/yL (150,000-440,000)
Hemoglobin: 14.5 g/dL (12-16)
Leukocytes: 9,800/uL (4,000-9,400)
GGT: 186 U/L (<18)

Ultrasound:

Dilated bile and intra hepatic ducts are seen. Pancreas is normal.

Comments:

Filling of CBD showed a high grade subtotal irregular stenosis in the mid

third of the CBD. A guide wire was inserted and limited sphincterotomy was
performed. After balloon dilation of the stenosis, brush biopsy was performed
and a metal stent was inserted due to the patient’s very good clinical condition.

Fluoroscopic view

surgical GI Mentor