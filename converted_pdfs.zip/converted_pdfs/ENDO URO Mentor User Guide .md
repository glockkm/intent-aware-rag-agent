

# Page 1

 
 
 
URO MENTOR® 
User Guide 
 
 
 
October 2024 
 
 
02-UROUG-W1024 
 
 
 


[TABLE]
| U             |
| RO MENTOR®    |
|:--------------|
| User Guide    |
| O             |
| ctober 2024   |
| 0             |
|               |
| 2-UROUG-W1024 |

[OCR]
URO MENTOR®

User Guide

October 2024

02-UROUG-W1024

surgicalscience


# Page 2

Contents
 
 
Page ii
 
Contents 
 
Chapter 1 
Safety Precautions .......................................................................................... 1 
Chapter 2 
ENDO Mentor Suite System ........................................................................... 4 
Hardware platform .............................................................................................................. 4 
URO interchangeable cartridge ..................................................................................... 6 
GI-BRONCH interchangeable cartridge ........................................................................ 7 
Scope hanger................................................................................................................... 8 
Connecting the scope ..................................................................................................... 8 
Extensions ........................................................................................................................ 9 
Working positions ........................................................................................................... 11 
Height elevation mechanism ......................................................................................... 13 
Turning on the simulator ................................................................................................ 13 
Tool tray .......................................................................................................................... 14 
Foot switch ..................................................................................................................... 17 
Available scopes ................................................................................................................ 18 
Rigid cystoscope ............................................................................................................ 19 
Rigid ureteroscope ........................................................................................................ 20 
Flexible scope ................................................................................................................. 21 
Resectoscope ................................................................................................................ 22 
Tools................................................................................................................................... 24 


[TABLE]
| Contents   |                                                                                                                                             |
|:-----------|:--------------------------------------------------------------------------------------------------------------------------------------------|
| C          | Safety Precautions .......................................................................................... 1                             |
| hapter 1   |                                                                                                                                             |
| Chapter 2  | ENDO Mentor Suite System ........................................................................... 4                                      |
|            | Hardware platform .............................................................................................................. 4          |
|            | URO interchangeable cartridge ..................................................................................... 6                       |
|            | GI-BRONCH interchangeable cartridge ........................................................................ 7                              |
|            | Scope hanger................................................................................................................... 8           |
|            | Connecting the scope ..................................................................................................... 8                |
|            | Extensions ........................................................................................................................ 9       |
|            | Working positions ........................................................................................................... 11            |
|            | Height elevation mechanism ......................................................................................... 13                     |
|            | Turning on the simulator ................................................................................................ 13                |
|            | Tool tray .......................................................................................................................... 14     |
|            | Foot switch ..................................................................................................................... 17        |
|            | Available scopes ................................................................................................................ 18        |
|            | Rigid cystoscope ............................................................................................................ 19            |
|            | Rigid ureteroscope ........................................................................................................ 20              |
|            | Flexible scope ................................................................................................................. 21         |
|            | Resectoscope ................................................................................................................ 22            |
|            | Tools................................................................................................................................... 24 |

[OCR]
Contents

| Contents

Chapter 1 Safety Precautions ...... cee eeeecescsecseesceeceeeeeeesesseseeseeseeecseesseeseesesaeesseeaeeeeseees 1
Chapter 2 ENDO Mentor Suite SYStOM...... eee eseseeeeseesceecseeeeeesesseeaeseeseeaesesseeeeeeees 4
Hardware platform... eeesssssscesceccseeseeecsecseseecesceacsecseeeesecsesaesaeseeaceacsecseeeseeseesaeseeaeeaeeees 4
URO interchangeable Cartridge ........ es eesesssseseeseesceecseesseeeseeseseeseeseeeeseeaeeeeseeseeesseeaeaeees 6
GI-BRONCH interchangeable Cartridge 0.0... eee eeeeeseeseesceeceeesceecseeseseeseeseeecseeaeeaseees 7
SCOPE NANGEM...... ee eeeeeeessessescescescceseeeeeecseesecescescescsecseeeseeesesaesaeseeseeacaecaeeseeessesaeeaeeeaceaeeees 8
CONNECTING the SCOPE... eeeeceeseeseeeeseeseesescescescsecseeaeeeesesaceaeseeseeacseeaeeeeessesaeeaeeetaeeaeeees 8
EXteNSiONS ...... cece ccceceescseseceeecsesscessesesscssscsesssesscsesscecscsesssessesesssesecsesaeessssssseesessssaeases 9
WOKING POSITIONS... eee eseeeeseesetecseeeeeeeseeseseeseeaceaesecseeeesesseeaeseeseeaesecseeeseessetaeeatseeaeees 11
Height elevation MECHANISM.......... seseeseeeeseeseeeeseeseeeeseesceccseeseeecsecaeeaeseeseeaseesseeeeeeeaeeaeee 13
TUPNING ON the SIMULACOM...... eee eeeeeeeceeeeeescescseeseeecseeseeeeseesceacsecseeeeeesseeaeeaeseeseeaeseeaeeese 13
TOOL tray oo... ceceseseesesseeseesecsecssccsecsecssesseeseessecsecesecsesseessecseseescsseseseseeseseaeseesaeeseseaseneseaeegs 14
FOOt SWITCH oo. cece ceec cece ceescseseceescseseseescsesssesscsesssssscsesssesessesseessesesseesecsesseeseeeeeaeeee 17
Available SCOPES .......ceeeecescsseeeceeescecescescsecsecseeesseeaeeacscesceacsacseeaeecsesaeeassceaceasieeaeeeeeeeaeeatee 18

Rigid cystoscope

RIGid UreterOSCOPE ...... ee eeeeseeeeseeseesceecscesceceseesseeesesseseeseescacsecseeesseesesaeaeseeaeaeseeeeeeseeeats 20
FIOXIDIS SCOPE... ee eceseeecseeseeeeeeseeceseeseesesecseeecseeseaeseeseaceecseeesessesaeaeseeseeassesaeeeseeeaeeaeee 21
Resectoscope....

surgicalscience Page ii


# Page 3

Contents
 
 
Page iii
 
Master Tool .................................................................................................................... 24 
Forceps .......................................................................................................................... 25 
Chapter 3 
URO Mentor Library of Modules and Courses ........................................... 26 
Chapter 4 
Getting Started ............................................................................................. 29 
Workflow ............................................................................................................................ 29 
Chapter 5 
MentorLearn .................................................................................................. 30 
MentorLearn overview ..................................................................................................... 30 
MentorLearn workflow ..................................................................................................... 30 
Logging in to MentorLearn on the simulator ................................................................... 31 
Working locally and on a cloud site ............................................................................. 33 
Accessing a module or course within My Curricula or Library ..................................... 34 
Easy Access to courses and modules in the Library ................................................. 36 
Reviewing didactic materials ....................................................................................... 37 
Starting a simulation case or task ............................................................................... 38 
Chapter 6 
URO Mentor Display Modes ......................................................................... 41 
Display modes .................................................................................................................... 41 
Cyberscopy display mode ................................................................................................ 41 
General features ............................................................................................................ 42 
Screen layout ................................................................................................................. 44 
Selecting a scope .......................................................................................................... 45 
Endoscopic View ........................................................................................................... 46 


[TABLE]
|           | Contents                                                                                                                                 |
|:----------|:-----------------------------------------------------------------------------------------------------------------------------------------|
|           | Master Tool .................................................................................................................... 24      |
|           | Forceps .......................................................................................................................... 25    |
| Chapter 3 | URO Mentor Library of Modules and Courses ........................................... 26                                                 |
| Chapter 4 | Getting Started ............................................................................................. 29                         |
|           | Workflow ............................................................................................................................ 29 |
| Chapter 5 | MentorLearn .................................................................................................. 30                        |
|           | MentorLearn overview ..................................................................................................... 30            |
|           | MentorLearn workflow ..................................................................................................... 30            |
|           | Logging in to MentorLearn on the simulator ................................................................... 31                        |
|           | Working locally and on a cloud site ............................................................................. 33                     |
|           | Accessing a module or course within My Curricula or Library ..................................... 34                                     |
|           | Easy Access to courses and modules in the Library ................................................. 36                                   |
|           | Reviewing didactic materials ....................................................................................... 37                  |
|           | Starting a simulation case or task ............................................................................... 38                    |
| Chapter 6 | URO Mentor Display Modes ......................................................................... 41                                    |
|           | Display modes .................................................................................................................... 41    |
|           | Cyberscopy display mode ................................................................................................ 41              |
|           | General features ............................................................................................................ 42         |
|           | Screen layout ................................................................................................................. 44       |
|           | Selecting a scope .......................................................................................................... 45          |
|           | Endoscopic View ........................................................................................................... 46           |

[OCR]
Contents

Master Tool...
FOICEDPS ou. ..eesecesesessescescescccseesseesseesesaescescacuecseeassecsesaesaeseeaceacaeeaeeessessesaesaesceaeeasaeeaseesseeats 25

Chapter 3 URO Mentor Library of Modules and Courses .........cceeseeseeeeteeeeeeeteeeeeeeees 26

Chapter 4 Getting Started ....

WOTSKPIOW.. eee ce cecececeescsesecececsesesecsesesscesscsesssesscsesseecscsessessesessessssessesessesssesscsssseetessssaegs 29
Chapter 5 MeNtorLearn....... eee eeeeesseescscescesceeeseeeeecsesaeseeseeaesecseeeseesesaeeaeseeseeeesesseeesseeaes 30
MentorLearn OVErVieW ou... ececesceeceeeeeceescsesecsescsesessescsesssenscsessssscsesseesessesseetessesseeteeeeee 30
MentorLearn Workflow ou... ccceccecescsecsceescsesecsescsesesessesesssenscsesssssssesseesessesseenessesseeseeeees 30
Logging in to MentorLearn On the SIMULAtOF «0... ee eee sete eeeeeeteeseeeceecaeeeeeeeeetaetetseeaeeee 31
Working locally and On a CIOU Sit@ oo... eee seseeeeeceeeeeeeseeseeeesceaeacsecseeeseeeeeeteetaees 33
Accessing a module or course within My Curricula or LiDrary ....... ee eeeeeeteeteeeeeeeees 34
Easy Access to courses and modules in the Library... eeseseeeeeeeteeeeeeeeeeeeeeees 36
Reviewing didactic Materials ......... ce ececsseseeecseeseseeeeescescsecseeeeeecsesaeeaeseeaeeeeseeaseeeseeaes 37
Starting a Simulation Case OF taSK oo... eeseeeeteeeeeeeeetseeeesceaceecseeseeeeeesesaeeeeseeaeeeeseees 38
Chapter 6 URO Mentor Display MOdES 2.0... eeeeseeeseeseseeeeesceeceesseeseecseseeeerseeaeeaeeeneeees 41
Display MOdES....... ee eeeseseseeseeseesescescescseeseeessessesaeseesceacacsecseeecsessesaeseeaceacsesseeasessesaesarseeaeeee 41
Cyberscopy display MOE ...... eee eesceseescnecsseeceeesesseeesceacsecseeeeeecsesseeasseeaeeacseeaeeeseeeeeeaeee 41
General features... ce cecnsceceesescececsessecscsesscecsesesssesessessessessesseesessesseeneeeees 42
SCrEON LAYOUL... ee eeeeesceecseesceeceesseecsesseeaeseescacsecseeeeseesessesaeseeaceacsecaeeesseesesaseasseeaeeaeaeees 44
SElECTING A SCOPE... eee eeeseesceccteeseeeeteeseeseseesceacsecseeeeecsesseaeseescacseeseeasseesesaeaeseeaeeeseees 45
ENCOSCOPIC VICW ..... ee eeeeeeeesseseeeescesccescescecseeseeaeseescacsceseescsecseeesseesesaceaeseeacsacseeaseesseeats 46

surgicalscience Page iii


# Page 4

Contents
 
 
Page iv
 
Fluoroscopic View ......................................................................................................... 46 
Working with fluoroscopy ............................................................................................. 47 
Injecting contrast........................................................................................................... 50 
Educational aids ............................................................................................................. 51 
Camera mode ................................................................................................................ 52 
Irrigating and draining ................................................................................................... 53 
Taking snapshots .......................................................................................................... 54 
Analyzing and documenting clinical findings ............................................................. 55 
Viewing patient file ........................................................................................................ 56 
Chapter 7 
TURP Display Modes .................................................................................... 58 
Basic Skills display mode ................................................................................................. 58 
Clinical Procedure display mode ..................................................................................... 59 
Screen display layout .................................................................................................... 60 
Internal View ................................................................................................................... 61 
External View ................................................................................................................. 65 
Virtual instructor ............................................................................................................ 66 
General buttons ............................................................................................................. 67 
Simulation Aids .................................................................................................................. 67 
Resection progress bar ................................................................................................. 68 
Clearing the simulation view ........................................................................................ 69 
Inflow and Outflow Valves ............................................................................................ 69 


[TABLE]
|           | Contents                                                                                                                              |
|:----------|:--------------------------------------------------------------------------------------------------------------------------------------|
|           | Fluoroscopic View ......................................................................................................... 46        |
|           | Working with fluoroscopy ............................................................................................. 47             |
|           | Injecting contrast........................................................................................................... 50      |
|           | Educational aids ............................................................................................................. 51     |
|           | Camera mode ................................................................................................................ 52       |
|           | Irrigating and draining ................................................................................................... 53        |
|           | Taking snapshots .......................................................................................................... 54        |
|           | Analyzing and documenting clinical findings ............................................................. 55                          |
|           | Viewing patient file ........................................................................................................ 56      |
| Chapter 7 | TURP Display Modes .................................................................................... 58                            |
|           | Basic Skills display mode ................................................................................................. 58        |
|           | Clinical Procedure display mode ..................................................................................... 59              |
|           | Screen display layout .................................................................................................... 60         |
|           | Internal View ................................................................................................................... 61  |
|           | External View ................................................................................................................. 65    |
|           | Virtual instructor ............................................................................................................ 66    |
|           | General buttons ............................................................................................................. 67      |
|           | Simulation Aids .................................................................................................................. 67 |
|           | Resection progress bar ................................................................................................. 68           |
|           | Clearing the simulation view ........................................................................................ 69              |
|           | Inflow and Outflow Valves ............................................................................................ 69             |

[OCR]
Contents

Fluoroscopic View...
Working with flUOrOSCOPY.........eseessesesecsseseecesceeecescescsecseeeeseesesaecesceaceacseeseeeseeaeeasaeaees 47

INJECTING CONTFAST.... eee eeseeeeeeseesceeesceseeecseeseseeseesceesceseescsecaeeeesecsesaesaeseeaceacieeaseeseeeaes 50

Educational aids ...

CAME MOE ou... ee cece cece escsececeeseececscsesscececsessssseesessesseesesssessesessessecsessseseessseeeneeeees 52
Irrigating AN Draining... eee eeeesesceseescecceeeeeeecsecseseescescescsecseeeeseeseseeaesceaeeaeseeeaeeeeeats 53
Taking SNAPSHOTS ..... ee eesceseeecseeseeeesecseeseseesceacsecseeeeecseesesaeseesceacseeseeaseeseseeeaeseeaeeeeseees 54
Analyzing and documenting clinical fINdINGS 0.0... eeeeeeeseeseeeeeeeseeececseeeeeeeseteeeereees 55
Viewing patient file... eee seeseeeeseeeeeeeecseseeseescescsecseeeeeesesaeseeseeaeeassesseeeseesesaseetaees 56
Chapter 7 TURP Display MOdE@S.........cceesessscessescsecseeeceecseeseseeseeacsecseeeeecsesaeeerseeaeeaeeeees 58
Basic Skills display MOE ....... ee eseescsecseeseeeceeeseeeescesceeesecseeesseesesaeseesceaeacseeaseeseeaesasetaeee 58
Clinical Procedure display MOC uu... csessecsseseseeseeseeececesceessecseeaceeeseesceesceaceeseeeeeeeseeaes 59
Screen display layout... eeessseseeseeseseescesceecseeeeeecseeseeeeseesceacsecseeeeeeesesaeeesseeaeeesseees 60
Internal VieW oo... eee eceecececscseseceescsessseescseesecscsesssesscsesscessssesssesessesseesessesseesessesseeee 61
External ViOW oo... ccc ccescseseceescsesscscscsesssesscsesssecscsesssesscsssssesecsessessessesseesessesseeseneesaees 65
VirtUal INStPUCTOP eee eee ce ces esscececseecececsesseecscsesscesscsesssesecscsssessesesssesessessseseesesseeees 66
General DULtONS occ ce cee csenececeesesecesecsesssesecsesseessesesseesessesseesessesssesesseseeeneeeees 67
SIMUIAtION AIS... eee cece ce cecececsesececscseseceescsesesecsssesssesessesssesessesseesessesseesensesaeeees 67
RESECTION PFOGFESS DAM... eeeseeeseeceseeseeecseeeseecsesseseeseeseescsecseeeeseesesaeeaeseeaeeacseeeseesseeaes 68
Clearing the Simulation ViOW ......... ce eeeeeseescseescecceeeseseeseesceccseesceecsecseeeeeeeseeaeseeeeeaseeseeees 69
Inflow and OUtflOW ValVeS..... eee cece ce csesesscececsescecscsesssesscsesssesecsesseesessesseesensesaegs 69

surgicalscience Page iv


# Page 5

Contents
 
 
Page v
 
Chapter 8 
Working with Tools ....................................................................................... 70 
Tools menu ........................................................................................................................ 70 
Selecting a tool ................................................................................................................. 70 
Working simultaneously with more than one endoscopic tool ...................................... 71 
Working with baskets, forceps and balloons .................................................................. 71 
Working with lithotripters and electrodes ...................................................................... 72 
Working with stents .......................................................................................................... 75 
Information on scopes and tools ..................................................................................... 76 
Working with resectoscope ............................................................................................. 77 
Aligning the resectoscope ............................................................................................ 77 
Inserting and positioning the camera .......................................................................... 78 
Ending the case or task .................................................................................................... 79 
Chapter 9 
Viewing Performance Reports ...................................................................... 81 
Overview ............................................................................................................................. 81 
Viewing reports .................................................................................................................. 81 
Viewing additional information..................................................................................... 85 
Viewing recorded videos .............................................................................................. 86 
Browsing between sessions ......................................................................................... 87 
Additional report types ..................................................................................................... 88 
Viewing user saved snapshots .................................................................................... 88 
Viewing performance playback ................................................................................... 89 


[TABLE]
|           | Contents                                                                                                                                  |
|:----------|:------------------------------------------------------------------------------------------------------------------------------------------|
| Chapter 8 | Working with Tools ....................................................................................... 70                             |
|           | Tools menu ........................................................................................................................ 70    |
|           | Selecting a tool ................................................................................................................. 70     |
|           | Working simultaneously with more than one endoscopic tool ...................................... 71                                       |
|           | Working with baskets, forceps and balloons .................................................................. 71                          |
|           | Working with lithotripters and electrodes ...................................................................... 72                       |
|           | Working with stents .......................................................................................................... 75         |
|           | Information on scopes and tools ..................................................................................... 76                  |
|           | Working with resectoscope ............................................................................................. 77                |
|           | Aligning the resectoscope ............................................................................................ 77                 |
|           | Inserting and positioning the camera .......................................................................... 78                        |
|           | Ending the case or task .................................................................................................... 79           |
| Chapter 9 | Viewing Performance Reports ...................................................................... 81                                     |
|           | Overview ............................................................................................................................. 81 |
|           | Viewing reports .................................................................................................................. 81     |
|           | Viewing additional information..................................................................................... 85                    |
|           | Viewing recorded videos .............................................................................................. 86                 |
|           | Browsing between sessions ......................................................................................... 87                    |
|           | Additional report types ..................................................................................................... 88          |
|           | Viewing user saved snapshots .................................................................................... 88                      |
|           | Viewing performance playback ................................................................................... 89                       |

[OCR]
Contents

Chapter 8 Working with Tools..
TOOIS MENU... cece cece cseeececscsesscecscsesssecsesesssesecsessssssssesssessssesssesscsesseessssesseesessssaeesees 70

S@lSCTING A TOO] oe ee eeeseecseeseeeeseeseesescescescsecsseeesecsesaeeesceacacsecseeeeessesasseesceacasseeaeeesseeats 70

Working simultaneously with more than one endoscopic tool....

Working with baskets, forceps ANd DallOONS ....... eee eeseeseeeeseeseeeeeeeeeeeeeesceeceeaeeeseeeseeees 71
Working with lithotripters and electrodes oo. eeeeeeseseeseeseeecseeeceecseseeeeeseeseeecseeaseeeseees 72
Working With Stents... cceeeceseceeeeseeseseesceseescsecseeecsecsesaesaesceaceacsecseeeesesaesaseerseeaceeeseees 75
Information ON SCOPES ANA tOOIS ...... eee eeeeeeeeseeeeeeeeeeeeecseceeseeseescecseeaeeeseeaseeseeeseeaeetaeee 76
Working With reSeCtOSCOPGe «00... eeeessescesseseeceseescsecseeeesecseeseaesceacacsecseeeeseeaesaseerseeaceeeneees 77
Aligning the reS@CtOSCOPG.........sessesseseeeeeseseeseeeescescsecseeeeecsesseseeseeseeaeseeseeeseeaeeatataees 77
Inserting and positioning the CAMETA Qo... ee eeeseeeeceeeeeeecseeeeeeeseesceeeseeaeeeseeseeeeeeees 78
Ending the Case OF task... eeeeseeceecseeseeecseseeseescesceecsecseeeeseesesaeeesceaceacseceseeseeseeeeeseeaeee 79
Chapter 9 Viewing Performance Reports... sesescseeseecsseeeeesesseeescesceeceecseeeseeeeeteeee 81
OVELVICW Qe eeeccccecececesesetecetsesesseecsescsesesscsesscesscsesseesscsesesesscsessesessesseseesesseesessssseesessesaeseces 81
VIOWING FEPOFtS ..... ees esceecseeseeceseeseseescescsecseesseesseeseeaesceseeacuacseeseecsesaesaeseeaeeasaeeaeeeeeeeaeeatee 81
Viewing additional information. .........ceeeeeeeseeseecesceseeecseceeeeesesseeeeseeaeeecsecseeeseeeseeaeeeraees 85
VIEWING FECOFdE” VIGCOS.......eeeesceseteeseeseeeesceccsccscescceseeseeeeseeacaeseeseasseeaeeeseeeaetassaeaees 86
BrowSing DeEtWEEN SESSIONS.........ccececeseecceeesseeeseeseeeescescescsecseeeeseesesaeeaeseeaeaeseeaseeseeeats 87
Additional report tyPe@S....... eee ecsessessescescesceecseeeeeecsessesesscesceacsecseeeesessesasseeaceaceasseeeseesseeats 88
Viewing USEF SAVE SNAPSHOTS ........ eee eeeeeeseeececesceseeeeseeeseeeseeseseeseeseeecsecseeeseeeseeateeteeee 88
Viewing performance playback ....... see eeseseesesceseesceecsseseeeeseeseeecsecseeececseeeseeeseeateraees 89

surgicalscience Page v


# Page 6

Contents
 
 
Page vi
 
Understanding the scoreboard .................................................................................... 90 
Understanding benchmarks and rating scales ............................................................ 91 
Understanding learning curve graphs ......................................................................... 92 
Exporting performance results ........................................................................................ 94 
Chapter 10 
Technical Support ........................................................................................ 95 
SURGICAL SCIENCE SUPPORT POLICY ..................................................................... 95 
Surgical Science Call Center ........................................................................................ 95 
Chapter 11 
End-User Software License Agreement ..................................................... 96 
URO Mentor® .................................................................................................................. 96 
1  EXTENT OF LICENSE ................................................................................................. 96 
2  CONFIDENCE OF THE SOFTWARE AND COPYRIGHT ........................................... 97 
3  OWNERSHIP OF SOFTWARE ................................................................................... 98 
4  SUPPORT SERVICES ................................................................................................. 98 
5  INTEGRITY OF THE SOFTWARE .............................................................................. 99 
6  RIGHT OF ACCESS .................................................................................................... 99 
7  WARRANTY AND LIMITATION OF LIABILITY ........................................................ 100 
8  TERMINATION .......................................................................................................... 101 
9.  MISCELLANEOUS ................................................................................................... 102 
Index .................................................................................................................................... 103 
 


[TABLE]
|                                                                                                                                                | Contents                                                                                                                          |
|:-----------------------------------------------------------------------------------------------------------------------------------------------|:----------------------------------------------------------------------------------------------------------------------------------|
|                                                                                                                                                | Understanding the scoreboard .................................................................................... 90              |
|                                                                                                                                                | Understanding benchmarks and rating scales ............................................................ 91                        |
|                                                                                                                                                | Understanding learning curve graphs ......................................................................... 92                  |
|                                                                                                                                                | Exporting performance results ........................................................................................ 94         |
| Chapter 10                                                                                                                                     | Technical Support ........................................................................................ 95                     |
|                                                                                                                                                | SURGICAL SCIENCE SUPPORT POLICY ..................................................................... 95                          |
|                                                                                                                                                | Surgical Science Call Center ........................................................................................ 95          |
| Chapter 11                                                                                                                                     | End-User Software License Agreement ..................................................... 96                                      |
|                                                                                                                                                | URO Mentor® .................................................................................................................. 96 |
|                                                                                                                                                | 1  EXTENT OF LICENSE ................................................................................................. 96         |
|                                                                                                                                                | 2  CONFIDENCE OF THE SOFTWARE AND COPYRIGHT ........................................... 97                                        |
|                                                                                                                                                | 3  OWNERSHIP OF SOFTWARE ................................................................................... 98                   |
|                                                                                                                                                | 4  SUPPORT SERVICES ................................................................................................. 98          |
|                                                                                                                                                | 5  INTEGRITY OF THE SOFTWARE .............................................................................. 99                    |
|                                                                                                                                                | 6  RIGHT OF ACCESS .................................................................................................... 99        |
|                                                                                                                                                | 7  WARRANTY AND LIMITATION OF LIABILITY ........................................................ 100                              |
|                                                                                                                                                | 8  TERMINATION .......................................................................................................... 101     |
|                                                                                                                                                | 9.  MISCELLANEOUS ................................................................................................... 102         |
| Index .................................................................................................................................... 103 |                                                                                                                                   |

[OCR]
Contents

Understanding the SCOreDOard ...... eee eseceseeseeeeseescesescescescsecaeeeesecsesaeaeseeaeaceeeateeeseeaes 90

Understanding benchmarks and rating scales...

Understanding learning CUrVe Graphs... eeeeseeeeeeteesceecseeeeeeeseeseeetsceaeacseeeseeeseeaes 92
Exporting performance results ....... ee eeeeeeeesesseeseecescescecseeeseecsesaeeesceaeacseeaeeeseeeseseeeetaeee 94
Chapter 10 = Technical SUPPOFt «0... eee eeeeeseeseeccteesseeeeecseeeecesceaceecsecaeeecsessesaeserseeaeeesseees 95
SURGICAL SCIENCE SUPPORT POLICY ......ccccesssesesesesssessseseesseeeseessesessseseseasacseasaes 95
Surgical Science Call Center... eee eesescescesceecneeeeeeeesseeeeseesceacsecseeeeeesesaeeeeseeaeeeeseees 95
Chapter 11 End-User Software License Agre@Ment...........ceseesecsseeeeeeeeeseeersceaeeeeneeee 96

URO Mentor®

1 EXTENT OF LICENSE ..0.. ccc cecrecececseseceseesesseessesessceseesesssesessesssenessesseeneeeees 96
2 CONFIDENCE OF THE SOFTWARE AND COPYRIGHT .........cccecsscsseeeeseeseeeseeees 97
3 OWNERSHIP OF SOFTWARE ou... ceccceecescsseececsesscecsescsssessesesseesscsesssesessesseeseeseeaees 98
A SUPPORT SERVICES... ccc cecesesscecsesesscsssesesseessesesssesscsessessessesseeseesesseeneeeees 98
S INTEGRITY OF THE SOFTWARE uu... cece cscesceescecscseseceeeesesscesscsesesensssesssesensesaegs 99
6 RIGHT OF ACCESS... cece csc ceceeecsesecececsessessesesscessssesssesessesseessssessseseeseseeeneneees 99

7 WARRANTY AND LIMITATION OF LIABILITY

B TERMINATION ......c.ceccscesesescseesesesescseecesescseseeseseseseesescseceseaeaeeeaeaceeseeseaeeeeesaeaeeeeeeaeas 101
Q. MISCELLANEOUS... ccccscsssseseseseeeeseseseseeeeseseseeeeseseseeeeseseseeecseaeeeeeeseseaeeeeaeaeeeeeeatee 102
INCOX oe eeeeeseeeeeeteeseeeeseesceacscesceasecesesseseeseescecseescacseesseecsessesaesaeseeaceasaeeesessesaeaeseeaceaeeeeaeeas® 103

surgicalscience Page vi


# Page 7

Figures
 
 
Page vii
 
Figures 
 
Figure 2-1: ENDO Mentor Suite - URO Mentor platform 
5 
Figure 2-2: URO interchangeable cartridge 
6 
Figure 2-3: GI-BRONCH interchangeable cartridge – lower orifice selected 
7 
Figure 2-4: Scope hanger – URO scopes 
8 
Figure 2-5: System and scope connectors 
9 
Figure 2-6: URO modality extension 
10 
Figure 2-7: GI modality extension 
10 
Figure 2-8: GI extension fully opened (left), URO extension fully opened (right) 
11 
Figure 2-9: URO Mentor working position 
12 
Figure 2-10: Height elevation panel – (from left to right) USB port, Height Elevation 
mechanism, Computer On/Off button 
13 
Figure 2-11: Tool tray hanger with URO tools 
15 
Figure 2-12: Resectoscope hung on the tool tray 
15 
Figure 2-13: Tool connection outlets 
16 
Figure 2-14: Foot switch 
17 
Figure 2-15: Rigid Cystoscope 
19 
Figure 2-16: Rigid Ureteroscope 
20 
Figure 2-17: Flexible scope 
21 
Figure 2-18: Adapted resectoscope 
22 
Figure 2-19: Resectoscope’s camera handle 
23 
Figure 2-20: Master Tool 
24 
Figure 2-21: Forceps 
25 
Figure 5-1: My Curricula screen 
34 
Figure 5-2: URO Mentor Library screen 
35 
Figure 5-3: Opening a module 
37 


[TABLE]
|                                                                                       | Figures   |
|:--------------------------------------------------------------------------------------|:----------|
| Figures                                                                               |           |
| F                                                                                     | 5         |
| igure 2-1: ENDO Mentor Suite - URO Mentor platform                                    |           |
| Figure 2-2: URO interchangeable cartridge                                             | 6         |
| Figure 2-3: GI-BRONCH interchangeable cartridge – lower orifice selected              | 7         |
| Figure 2-4: Scope hanger – URO scopes                                                 | 8         |
| Figure 2-5: System and scope connectors                                               | 9         |
| Figure 2-6: URO modality extension                                                    | 10        |
| Figure 2-7: GI modality extension                                                     | 10        |
| Figure 2-8: GI extension fully opened (left), URO extension fully opened (right)      | 11        |
| Figure 2-9: URO Mentor working position                                               | 12        |
| Figure 2-10: Height elevation panel – (from left to right) USB port, Height Elevation |           |
| mechanism, Computer On/Off button                                                     | 13        |
| Figure 2-11: Tool tray hanger with URO tools                                          | 15        |
| Figure 2-12: Resectoscope hung on the tool tray                                       | 15        |
| Figure 2-13: Tool connection outlets                                                  | 16        |
| Figure 2-14: Foot switch                                                              | 17        |
| Figure 2-15: Rigid Cystoscope                                                         | 19        |
| Figure 2-16: Rigid Ureteroscope                                                       | 20        |
| Figure 2-17: Flexible scope                                                           | 21        |
| Figure 2-18: Adapted resectoscope                                                     | 22        |
| Figure 2-19: Resectoscope’s camera handle                                             | 23        |
| Figure 2-20: Master Tool                                                              | 24        |
| Figure 2-21: Forceps                                                                  | 25        |
| Figure 5-1: My Curricula screen                                                       | 34        |
| Figure 5-2: URO Mentor Library screen                                                 | 35        |
| Figure 5-3: Opening a module                                                          | 37        |

[OCR]
Figures

| Figures

Figure 2-1: ENDO Mentor Suite - URO Mentor platform 5
Figure 2-2: URO interchangeable cartridge 6
Figure 2-3: GI-BRONCH interchangeable cartridge — lower orifice selected 7
Figure 2-4: Scope hanger — URO scopes 8
Figure 2-5: System and scope connectors 9
Figure 2-6: URO modality extension 10
Figure 2-7: GI modality extension 10
Figure 2-8: GI extension fully opened (left), URO extension fully opened (right) 11
Figure 2-9: URO Mentor working position 12
Figure 2-10: Height elevation panel — (from left to right) USB port, Height Elevation

mechanism, Computer On/Off button 13
Figure 2-11: Tool tray hanger with URO tools 15
Figure 2-12: Resectoscope hung on the tool tray 15
Figure 2-13: Tool connection outlets 16
Figure 2-14: Foot switch 17
Figure 2-15: Rigid Cystoscope 19
Figure 2-16: Rigid Ureteroscope 20
Figure 2-17: Flexible scope 21
Figure 2-18: Adapted resectoscope 22
Figure 2-19: Resectoscope’s camera handle 23
Figure 2-20: Master Tool 24
Figure 2-21: Forceps 25
Figure 5-1: My Curricula screen 34
Figure 5-2: URO Mentor Library screen 35
Figure 5-3: Opening a module 37

surgicalscience Page vii


# Page 8

Figures
 
 
Page viii
 
Figure 5-4: Task description 
40 
Figure 6-1: Cyberscopy display mode 
42 
Figure 6-2: Task and procedure display mode 
43 
Figure 6-3: Task and Procedure display mode 
44 
Figure 6-4: Selecting a scope 
45 
Figure 6-5: Endoscopic view 
46 
Figure 6-6: Fluoroscopic view 
47 
Figure 6-7: C-Arm controls for positioning the C-Arm 
48 
Figure 6-8: C-Arm Image controls 
49 
Figure 6-9: Contrast agent displayed on fluoroscopic image demonstrating calyces 50 
Figure 6-10: Virtual Instructor 
51 
Figure 6-11: Online task instructions 
52 
Figure 6-12: Camera Mode selected 
53 
Figure 6-13: Endoscopic View before and after draining or flushing 
54 
Figure 6-14: Trainee Report 
55 
Figure 6-15: URO Mentor Patient File 
57 
Figure 7-1: Basic Skills display mode 
58 
Figure 7-2: Clinical Procedure display mode 
59 
Figure 7-3: Internal View 
61 
Figure 7-4: External View 
65 
Figure 7-5: Default View and Show Resection View 
68 
Figure 7-6: Resection zones on Resection Map 
68 
Figure 7-7: Resection progress bar 
69 
Figure 7-8: View clouded with blood and tissue and view cleared 
69 
Figure 8-1: Tools Menu with sub-menu of options 
70 
Figure 8-2: Forceps removing stone fragment 
72 
Figure 8-3: Lithotripter breaking stone into fragments 
73 


[TABLE]
|                                                                                      | Figures   |
|:-------------------------------------------------------------------------------------|:----------|
| Figure 5-4: Task description                                                         | 40        |
| Figure 6-1: Cyberscopy display mode                                                  | 42        |
| Figure 6-2: Task and procedure display mode                                          | 43        |
| Figure 6-3: Task and Procedure display mode                                          | 44        |
| Figure 6-4: Selecting a scope                                                        | 45        |
| Figure 6-5: Endoscopic view                                                          | 46        |
| Figure 6-6: Fluoroscopic view                                                        | 47        |
| Figure 6-7: C-Arm controls for positioning the C-Arm                                 | 48        |
| Figure 6-8: C-Arm Image controls                                                     | 49        |
| Figure 6-9: Contrast agent displayed on fluoroscopic image demonstrating calyces  50 |           |
| Figure 6-10: Virtual Instructor                                                      | 51        |
| Figure 6-11: Online task instructions                                                | 52        |
| Figure 6-12: Camera Mode selected                                                    | 53        |
| Figure 6-13: Endoscopic View before and after draining or flushing                   | 54        |
| Figure 6-14: Trainee Report                                                          | 55        |
| Figure 6-15: URO Mentor Patient File                                                 | 57        |
| Figure 7-1: Basic Skills display mode                                                | 58        |
| Figure 7-2: Clinical Procedure display mode                                          | 59        |
| Figure 7-3: Internal View                                                            | 61        |
| Figure 7-4: External View                                                            | 65        |
| Figure 7-5: Default View and Show Resection View                                     | 68        |
| Figure 7-6: Resection zones on Resection Map                                         | 68        |
| Figure 7-7: Resection progress bar                                                   | 69        |
| Figure 7-8: View clouded with blood and tissue and view cleared                      | 69        |
| Figure 8-1: Tools Menu with sub-menu of options                                      | 70        |
| Figure 8-2: Forceps removing stone fragment                                          | 72        |
| Figure 8-3: Lithotripter breaking stone into fragments                               | 73        |

[OCR]
Figures

Figure 5-4: Task description 40
Figure 6-1: Cyberscopy display mode 42
Figure 6-2: Task and procedure display mode 43
Figure 6-3: Task and Procedure display mode 44
Figure 6-4: Selecting a scope 45
Figure 6-5: Endoscopic view 46
Figure 6-6: Fluoroscopic view 47
Figure 6-7: C-Arm controls for positioning the C-Arm 48
Figure 6-8: C-Arm Image controls 49
Figure 6-9: Contrast agent displayed on fluoroscopic image demonstrating calyces 50
Figure 6-10: Virtual Instructor 51
Figure 6-11: Online task instructions 52
Figure 6-12: Camera Mode selected 53
Figure 6-13: Endoscopic View before and after draining or flushing 54
Figure 6-14: Trainee Report 55
Figure 6-15: URO Mentor Patient File 57
Figure 7-1: Basic Skills display mode 58
Figure 7-2: Clinical Procedure display mode 59
Figure 7-3: Internal View 61
Figure 7-4: External View 65
Figure 7-5: Default View and Show Resection View 68
Figure 7-6: Resection zones on Resection Map 68
Figure 7-7: Resection progress bar 69
Figure 7-8: View clouded with blood and tissue and view cleared 69
Figure 8-1: Tools Menu with sub-menu of options 70
Figure 8-2: Forceps removing stone fragment 72
Figure 8-3: Lithotripter breaking stone into fragments 73

surgicalscience Page viii


# Page 9

Figures
 
 
Page ix
 
Figure 8-4: Laser Lithotripter control panel 
73 
Figure 8-5: Pneumatic Lithotripter control panel 
74 
Figure 8-6: EHL Lithotripter control panel 
74 
Figure 8-7: Electrode control panel 
74 
Figure 8-8: Electrode opening stricture 
75 
Figure 8-9: Stent over the guide wire 
76 
Figure 8-10: Scope and Tool Information window 
76 
Figure 8-11: Working element parallel to camera button 
77 
Figure 8-12: Align Scope screen for resectoscope 
78 
Figure 8-13: View out of focus and view in focus 
79 
Figure 8-14: Zoom percentage 
79 
Figure 9-1: Single-case report without benchmarks 
82 
Figure 9-2: Single-case report with benchmarks 
83 
Figure 9-3: Snapshot viewed from single report 
85 
Figure 9-4: Recorded video viewed from single report 
86 
Figure 9-5: Trainee Report viewed from Reports screen 
88 
Figure 9-6: Playback screen viewed from the Reports page 
89 
Figure 9-7: Case benchmark scoreboard 
90 
Figure 9-8: Session benchmark scoreboard 
91 
Figure 9-9: Benchmark rating scale 
92 
Figure 9-10: Report's learning curve 
93 
Figure 9-11: Export Performance window 
94 
 


[TABLE]
|                                                          |   Figures |
|:---------------------------------------------------------|----------:|
| Figure 8-4: Laser Lithotripter control panel             |        73 |
| Figure 8-5: Pneumatic Lithotripter control panel         |        74 |
| Figure 8-6: EHL Lithotripter control panel               |        74 |
| Figure 8-7: Electrode control panel                      |        74 |
| Figure 8-8: Electrode opening stricture                  |        75 |
| Figure 8-9: Stent over the guide wire                    |        76 |
| Figure 8-10: Scope and Tool Information window           |        76 |
| Figure 8-11: Working element parallel to camera button   |        77 |
| Figure 8-12: Align Scope screen for resectoscope         |        78 |
| Figure 8-13: View out of focus and view in focus         |        79 |
| Figure 8-14: Zoom percentage                             |        79 |
| Figure 9-1: Single-case report without benchmarks        |        82 |
| Figure 9-2: Single-case report with benchmarks           |        83 |
| Figure 9-3: Snapshot viewed from single report           |        85 |
| Figure 9-4: Recorded video viewed from single report     |        86 |
| Figure 9-5: Trainee Report viewed from Reports screen    |        88 |
| Figure 9-6: Playback screen viewed from the Reports page |        89 |
| Figure 9-7: Case benchmark scoreboard                    |        90 |
| Figure 9-8: Session benchmark scoreboard                 |        91 |
| Figure 9-9: Benchmark rating scale                       |        92 |
| Figure 9-10: Report's learning curve                     |        93 |
| Figure 9-11: Export Performance window                   |        94 |

[OCR]
Figures

Figure 8-4: Laser Lithotripter control panel 73
Figure 8-5: Pneumatic Lithotripter control panel 74
Figure 8-6: EHL Lithotripter control panel 74
Figure 8-7: Electrode control panel 74
Figure 8-8: Electrode opening stricture 75
Figure 8-9: Stent over the guide wire 76
Figure 8-10: Scope and Tool Information window 76
Figure 8-11: Working element parallel to camera button 77
Figure 8-12: Align Scope screen for resectoscope 78
Figure 8-13: View out of focus and view in focus 79
Figure 8-14: Zoom percentage 79
Figure 9-1: Single-case report without benchmarks 82
Figure 9-2: Single-case report with benchmarks 83
Figure 9-3: Snapshot viewed from single report 85
Figure 9-4: Recorded video viewed from single report 86
Figure 9-5: Trainee Report viewed from Reports screen 88
Figure 9-6: Playback screen viewed from the Reports page 89
Figure 9-7: Case benchmark scoreboard 90
Figure 9-8: Session benchmark scoreboard 91
Figure 9-9: Benchmark rating scale 92
Figure 9-10: Report's learning curve 93
Figure 9-11: Export Performance window 94
surgicalscience Page ix


# Page 10

Chapter 1 
 Safety Precautions
 
Page 1
 
Chapter 1 Safety Precautions 
Before using the ENDO Mentor Suite simulator, please read these safety precautions 
to ensure proper use of the equipment. These items contain important notes to 
prevent injury to the operator and damage to the equipment. The following precautions 
apply to the GI Mentor, the BRONCH Mentor and the URO Mentor which share the 
ENDO Mentor Suite platform. 
Two symbols are used to indicate specific types of warnings in addition to the general 
note table, which is clearly marked: 
 
 
A warning that indicates a prohibition. 
 
A general warning that emphasizes essential information about something 
that must be done.  
 
The following safety precautions must be adhered to upon setup and using the ENDO 
Mentor Suite simulator. Failure to follow these precautions may result in the removal of 
the warranty and may cause irreversible damage to the simulator or injury to 
operators. 
 
 
Read all the instructions and precautions fully before attempting to 
setup or use the ENDO Mentor Suite simulator. 
 
Follow all warnings and instructions marked on the ENDO Mentor 
Suite simulator.  
 
Do not attempt to open, check, alter, or fix any part of the ENDO 
Mentor Suite system, unless directly asked to do so during a support 
session with a Surgical Science representative. 
 
Unplug the ENDO Mentor Suite simulator when you know an 
electrical storm is approaching.  


[TABLE]
| Chapter 1                                                                          | Safety Precautions                                                                     |
|:-----------------------------------------------------------------------------------|:---------------------------------------------------------------------------------------|
| Chapter 1  Safety Precautions                                                      |                                                                                        |
| Before using the ENDO Mentor Suite simulator, please read these safety precautions |                                                                                        |
| to ensure proper use of the equipment. These items contain important notes to      |                                                                                        |
|                                                                                    | prevent injury to the operator and damage to the equipment. The following precautions  |
| apply to the GI Mentor, the BRONCH Mentor and the URO Mentor which share the       |                                                                                        |
| ENDO Mentor Suite platform.                                                        |                                                                                        |
|                                                                                    | Two symbols are used to indicate specific types of warnings in addition to the general |
| note table, which is clearly marked:                                               |                                                                                        |

[TABLE]
| the warranty and may cause irreversible damage to the simulator or injury to   |
|:-------------------------------------------------------------------------------|
| Read all the instructions and precautions fully before attempting to           |
| setup or use the ENDO Mentor Suite simulator.                                  |
| Follow all warnings and instructions marked on the ENDO Mentor                 |
| Suite simulator.                                                               |
| Do not attempt to open, check, alter, or fix any part of the ENDO              |
| Mentor Suite system, unless directly asked to do so during a support           |
| session with a Surgical Science representative.                                |
| Unplug the ENDO Mentor Suite simulator when you know an                        |
| electrical storm is approaching.                                               |

[OCR]
Chapter 1 Safety Precautions

| Chapter 1 Safety Precautions

Before using the ENDO Mentor Suite simulator, please read these safety precautions
to ensure proper use of the equipment. These items contain important notes to
prevent injury to the operator and damage to the equipment. The following precautions
apply to the GI Mentor, the BRONCH Mentor and the URO Mentor which share the
ENDO Mentor Suite platform.

Two symbols are used to indicate specific types of warnings in addition to the general
note table, which is clearly marked:

@ A warning that indicates a prohibition.

A general warning that emphasizes essential information about something
that must be done.

The following safety precautions must be adhered to upon setup and using the ENDO
Mentor Suite simulator. Failure to follow these precautions may result in the removal of
the warranty and may cause irreversible damage to the simulator or injury to
operators.

Read all the instructions and precautions fully before attempting to
setup or use the ENDO Mentor Suite simulator.

Follow all warnings and instructions marked on the ENDO Mentor
Suite simulator.

Do not attempt to open, check, alter, or fix any part of the ENDO
Mentor Suite system, unless directly asked to do so during a support
session with a Surgical Science representative.

Unplug the ENDO Mentor Suite simulator when you know an
electrical storm is approaching.

surgicalscience Page 1


# Page 11

Chapter 1 
 Safety Precautions
 
Page 2
 
 
Before cleaning, unplug the ENDO Mentor Suite simulator from the 
wall outlet. Use a dry cloth without liquid. Do not use aerosol 
cleaners. 
 
Do not use the ENDO Mentor Suite near water.  
 
When not in use or upon moving, disconnect all scopes from the 
system side connector. Failing to do so may result in irreparable 
damage. 
 
When not in use or upon moving, make sure that the tool tray is at its 
original folded position. Failing to do so may result in damage to the 
system. 
 
Make sure scopes and wires are not protruding before closing the 
drawer. Failing to do so may result in irreparable damage to the 
scopes or wires. 
 
When placing the ENDO Mentor Suite in a room with additional 
simulators, other electrical systems, or large amounts of metal, 
ensure that these items are at least 1 meter away from the ENDO 
Mentor Suite simulator. Failing to do so may result in an improper 
functioning of the simulator. 
 
Do not move the interchangeable cartridge in any way while the 
scope is inserted into the cavity. Doing so may result in irreparable 
scope damage. 
 
The interchangeable cartridge must be inserted and locked in place 
properly prior before attempting scope introduction for all the 
modalities to work. 
 
The bronchoscope’s insertion tube should not be bent unnecessarily 
- neither by attaching it to the hanger clip, nor by leaving it within the 
manikin when not being used. 
 
Do not leave the syringe, master tool, or any other instrument 
inserted in the scope’s working channel unnecessarily. 
 
Place the ENDO Mentor Suite on stable ground only. 


[TABLE]
| Safety Precautions                                                         |
|:---------------------------------------------------------------------------|
| Before cleaning, unplug the ENDO Mentor Suite simulator from the           |
| wall outlet. Use a dry cloth without liquid. Do not use aerosol            |
| cleaners.                                                                  |
| Do not use the ENDO Mentor Suite near water.                               |
| When not in use or upon moving, disconnect all scopes from the             |
| system side connector. Failing to do so may result in irreparable          |
| damage.                                                                    |
| When not in use or upon moving, make sure that the tool tray is at its     |
| original folded position. Failing to do so may result in damage to the     |
| system.                                                                    |
| Make sure scopes and wires are not protruding before closing the           |
| drawer. Failing to do so may result in irreparable damage to the           |
| scopes or wires.                                                           |
| When placing the ENDO Mentor Suite in a room with additional               |
| simulators, other electrical systems, or large amounts of metal,           |
| ensure that these items are at least 1 meter away from the ENDO            |
| Mentor Suite simulator. Failing to do so may result in an improper         |
| functioning of the simulator.                                              |
| Do not move the interchangeable cartridge in any way while the             |
| scope is inserted into the cavity. Doing so may result in irreparable      |
| scope damage.                                                              |
| The interchangeable cartridge must be inserted and locked in place         |
| properly prior before attempting scope introduction for all the            |
| modalities to work.                                                        |
| The bronchoscope’s insertion tube should not be bent unnecessarily         |
| - neither by attaching it to the hanger clip, nor by leaving it within the |
| manikin when not being used.                                               |
| Do not leave the syringe, master tool, or any other instrument             |
| inserted in the scope’s working channel unnecessarily.                     |
| Place the ENDO Mentor Suite on stable ground only.                         |

[OCR]
Chapter 1

Safety Precautions

a

Before cleaning, unplug the ENDO Mentor Suite simulator from the
wall outlet. Use a dry cloth without liquid. Do not use aerosol
cleaners.

Do not use the ENDO Mentor Suite near water.

When not in use or upon moving, disconnect all scopes from the
system side connector. Failing to do so may result in irreparable
damage.

When not in use or upon moving, make sure that the tool tray is at its
original folded position. Failing to do so may result in damage to the
system.

Make sure scopes and wires are not protruding before closing the
drawer. Failing to do so may result in irreparable damage to the
scopes or wires.

When placing the ENDO Mentor Suite in a room with additional
simulators, other electrical systems, or large amounts of metal,
ensure that these items are at least 1 meter away from the ENDO
Mentor Suite simulator. Failing to do so may result in an improper
functioning of the simulator.

Do not move the interchangeable cartridge in any way while the
scope is inserted into the cavity. Doing so may result in irreparable
scope damage.

The interchangeable cartridge must be inserted and locked in place
properly prior before attempting scope introduction for all the
modalities to work.

The bronchoscope’s insertion tube should not be bent unnecessarily
- neither by attaching it to the hanger clip, nor by leaving it within the
manikin when not being used.

Do not leave the syringe, master tool, or any other instrument
inserted in the scope’s working channel unnecessarily.

Place the ENDO Mentor Suite on stable ground only.

surgicalscience

Page 2


# Page 12

Chapter 1 
 Safety Precautions
 
Page 3
 
 
To protect the ENDO Mentor Suite from overheating, the opening on 
the back of the platform should not be covered or blocked.  
 
The ENDO Mentor Suite should not be placed near a radiator or heat 
register. 
 
The ENDO Mentor Suite should be placed in a room with a 
temperature range between 5 and 30 degrees centigrade. Proper 
ventilation is crucial.  
 
Do not allow anything to rest on the power cord or position the ENDO 
Mentor Suite where a cord could be stepped on or pulled out 
accidentally. 
 
Do not overload wall outlets and extension cords. 
 
Never spill liquid of any kind on the simulator. 
 
Avoid placing or dropping anything on the ENDO Mentor Suite. It may 
cause a malfunction or irreparable damage. 
 
Power must be off when handling the system or disconnecting any 
internal part during a support session.  
 
Unplug the ENDO Mentor Suite from the wall outlet and contact 
Surgical Science support under the following conditions:  
• 
When any cord, especially the power supply cord, is damaged 
or frayed. 
• 
If liquid has been spilled into the ENDO Mentor Suite. 
• 
If something has been dropped on the ENDO Mentor Suite. 
 
When opening the system’s back panel and pulling out the computer 
drawer during support – please note that the monitor must be in the 
opposite (front) side of the system and the computer drawer must be 
pulled out cautiously to avoid equilibrium problems. 
 
 


[TABLE]
|                                         | Safety Precautions                                                   |
|:----------------------------------------|:---------------------------------------------------------------------|
|                                         | To protect the ENDO Mentor Suite from overheating, the opening on    |
|                                         | the back of the platform should not be covered or blocked.           |
|                                         | The ENDO Mentor Suite should not be placed near a radiator or heat   |
| register.                               |                                                                      |
|                                         | The ENDO Mentor Suite should be placed in a room with a              |
|                                         | temperature range between 5 and 30 degrees centigrade. Proper        |
| ventilation is crucial.                 |                                                                      |
|                                         | Do not allow anything to rest on the power cord or position the ENDO |
|                                         | Mentor Suite where a cord could be stepped on or pulled out          |
| accidentally.                           |                                                                      |
|                                         | Do not overload wall outlets and extension cords.                    |
|                                         | Never spill liquid of any kind on the simulator.                     |
|                                         | Avoid placing or dropping anything on the ENDO Mentor Suite. It may  |
|                                         | cause a malfunction or irreparable damage.                           |
|                                         | Power must be off when handling the system or disconnecting any      |
| internal part during a support session. |                                                                      |
|                                         | Unplug the ENDO Mentor Suite from the wall outlet and contact        |
|                                         | Surgical Science support under the following conditions:             |
| •                                       | When any cord, especially the power supply cord, is damaged          |

[OCR]
Chapter 1 Safety Precautions

To protect the ENDO Mentor Suite from overheating, the opening on
the back of the platform should not be covered or blocked.

The ENDO Mentor Suite should not be placed near a radiator or heat
register.

The ENDO Mentor Suite should be placed in a room with a
temperature range between 5 and 30 degrees centigrade. Proper
ventilation is crucial.

Do not allow anything to rest on the power cord or position the ENDO
Mentor Suite where a cord could be stepped on or pulled out
accidentally.

Do not overload wall outlets and extension cords.

Never spill liquid of any kind on the simulator.

Avoid placing or dropping anything on the ENDO Mentor Suite. It may
cause a malfunction or irreparable damage.

Power must be off when handling the system or disconnecting any
internal part during a support session.

eeee 6 Pee

Unplug the ENDO Mentor Suite from the wall outlet and contact
Surgical Science support under the following conditions:

° When any cord, especially the power supply cord, is damaged
or frayed.

° If liquid has been spilled into the ENDO Mentor Suite.
° If something has been dropped on the ENDO Mentor Suite.

When opening the system’s back panel and pulling out the computer
drawer during support — please note that the monitor must be in the
opposite (front) side of the system and the computer drawer must be
pulled out cautiously to avoid equilibrium problems.

surgicalscience Page 3


# Page 13

Chapter 2 
 ENDO Mentor Suite System
 
Page 4
 
Chapter 2 ENDO Mentor Suite System 
The ENDO Mentor Suite® is a multidisciplinary platform that provides hands-on 
practice of GI, bronchoscopy, endourology and basic endoscopic and bronchoscopic 
skills for single trainees or an entire team.  
Hardware platform 
The platform consists of:  
• 
Wheeled hardware unit. 
• 
One or more scopes according to system configuration 
(Colonoscope/Duodenoscope/Bronchoscope/Rigid Scopes and Flexible Scope 
for Endourology/ and Resectoscope for Endourology).  
• 
Interchangeable cartridge for inserting scopes. 
• 
Set of tools according to system configuration.  
• 
Triple foot switch. 
• 
Wireless keyboard and mouse. 


[TABLE]
| Chapter 2                                                                     | ENDO Mentor Suite System                                                         |
|:------------------------------------------------------------------------------|:---------------------------------------------------------------------------------|
| Chapter 2 ENDO Mentor Suite System                                            |                                                                                  |
| The ENDO Mentor Suite® is a multidisciplinary platform that provides hands-on |                                                                                  |
|                                                                               | practice of GI, bronchoscopy, endourology and basic endoscopic and bronchoscopic |
| skills for single trainees or an entire team.                                 |                                                                                  |
| Hardware platform                                                             |                                                                                  |
| The platform consists of:                                                     |                                                                                  |

[TABLE]
| Hardware platform         |                                                                        |
|:--------------------------|:-----------------------------------------------------------------------|
| The platform consists of: |                                                                        |
| •                         | Wheeled hardware unit.                                                 |
| •                         | One or more scopes according to system configuration                   |
|                           | (Colonoscope/Duodenoscope/Bronchoscope/Rigid Scopes and Flexible Scope |
|                           | for Endourology/ and Resectoscope for Endourology).                    |
| •                         | Interchangeable cartridge for inserting scopes.                        |
| •                         | Set of tools according to system configuration.                        |
| •                         | Triple foot switch.                                                    |
| •                         | Wireless keyboard and mouse.                                           |

[OCR]
Chapter 2 ENDO Mentor Suite System

| Chapter 2 ENDO Mentor Suite System

The ENDO Mentor Suite® is a multidisciplinary platform that provides hands-on
practice of Gl, bronchoscopy, endourology and basic endoscopic and bronchoscopic
skills for single trainees or an entire team.

Hardware platform

The platform consists of:

° Wheeled hardware unit.

e One or more scopes according to system configuration
(Colonoscope/Duodenoscope/Bronchoscope/Rigid Scopes and Flexible Scope
for Endourology/ and Resectoscope for Endourology).

Interchangeable cartridge for inserting scopes.

Set of tools according to system configuration.

Triple foot switch.

Wireless keyboard and mouse.

surgicalscience Page 4


# Page 14

Chapter 2 
 ENDO Mentor Suite System
 
Page 5
 
 
Figure 2-1: ENDO Mentor Suite - URO Mentor platform 
1 
27” touch screen 
2 
URO interchangeable cartridge (see Figure 2-2 on page 6) 
3 
Wireless keyboard and mouse 
4 
Scope hanger (see Figure 2-4 on page 8) 


[TABLE]
| Chapter 2                                         | ENDO Mentor Suite System                                 |
|:--------------------------------------------------|:---------------------------------------------------------|
| F                                                 |                                                          |
| i                                                 |                                                          |
| gure 2-1: ENDO Mentor Suite - URO Mentor platform |                                                          |
| 1                                                 | 27” touch screen                                         |
| 2                                                 | URO interchangeable cartridge (see Figure 2-2 on page 6) |
| 3                                                 | Wireless keyboard and mouse                              |
| 4                                                 | Scope hanger (see Figure 2-4 on page 8)                  |
|                                                   | Page 5                                                   |

[OCR]
Chapter 2 ENDO Mentor Suite System

Figure 2-1: ENDO Mentor Suite - URO Mentor platform

1 27” touch screen

2 URO interchangeable cartridge (see Figure 2-2 on page 6)
3 Wireless keyboard and mouse
4

Scope hanger (see Figure 2-4 on page 8)

surgicalscience Page 5


# Page 15

Chapter 2 
 ENDO Mentor Suite System
 
Page 6
 
5 
Scope connectors (see Figure 2-5 on page 9) 
6 
Elevation mechanism (see Figure 2-10 on page 13) 
7 
Computer activation button 
8 
Rotating tool tray (see Figure 2-11 on page 15) 
9 
Upper drawer for Bronchoscope, 2 URO rigid scopes and 
wires (tools are stored in this drawer when shipped) 
10 
Lower drawer for Colonoscope, Duodenoscope, URO and GI-
BRONCH interchangeable cartridges 
11 
Foot switch (see Figure 2-14 on page 17) 
12 
Power switch, foot switch connector and USB outlet (on back 
panel) 
URO interchangeable cartridge   
 
Figure 2-2: URO interchangeable cartridge 
Note: An adaptor should be placed on the penis part of the cartridge for the TURP modules. 


[TABLE]
| Chapter 2   |                                                             |
|:------------|:------------------------------------------------------------|
| 5           | Scope connectors (see Figure 2-5 on page 9)                 |
| 6           | Elevation mechanism (see Figure 2-10 on page 13)            |
| 7           | Computer activation button                                  |
| 8           | Rotating tool tray (see Figure 2-11 on page 15)             |
| 9           | Upper drawer for Bronchoscope, 2 URO rigid scopes and       |
|             | wires (tools are stored in this drawer when shipped)        |
| 10          | Lower drawer for Colonoscope, Duodenoscope, URO and GI-     |
|             | BRONCH interchangeable cartridges                           |
| 11          | Foot switch (see Figure 2-14 on page 17)                    |
| 12          | Power switch, foot switch connector and USB outlet (on back |
|             | panel)                                                      |

[OCR]
Chapter 2 ENDO Mentor Suite System

Scope connectors (see Figure 2-5 on page 9)

Elevation mechanism (see Figure 2-10 on page 13)

Computer activation button

Rotating tool tray (see Figure 2-11 on page 15)

Oo ON DOW

Upper drawer for Bronchoscope, 2 URO rigid scopes and
wires (tools are stored in this drawer when shipped)

10 Lower drawer for Colonoscope, Duodenoscope, URO and GI-
BRONCH interchangeable cartridges

11 Foot switch (see Figure 2-14 on page 17)

12 Power switch, foot switch connector and USB outlet (on back
panel)

URO interchangeable cartridge

Figure 2-2: URO interchangeable cartridge

Note: An adaptor should be placed on the penis part of the cartridge for the TURP modules.

surgicalscience Page 6


# Page 16

Chapter 2 
 ENDO Mentor Suite System
 
Page 7
 
GI-BRONCH interchangeable cartridge  
 
Figure 2-3: GI-BRONCH interchangeable cartridge – lower orifice selected 
Two symbols of the upper GI and lower GI tracts are displayed on the GI-BRONCH 
interchangeable cartridge indicating the relevant GI tract segment. Depending on the 
module selected, the LED will light up on the cartridge to designate the GI tract that 
will be used for procedure. 
To switch between the ENDO Mentor Suite interchangeable cartridges: 
1.  Insert your right hand in the groove on the bottom of the interchangeable cartridge 
and your left hand into the edge on the top of the cartridge and gently free the 
cartridge. You should hear a click. 
2.  Pull the cartridge horizontally out. Store it in its designated cavity in the lower 
drawer. 
3.  Insert the desired cartridge with one hand in the groove and the other on the top 
of the cartridge, push it horizontally into place. You should hear a click. 
 
Note: The cartridge must be properly positioned prior to introducing the scopes. 


[TABLE]
| module selected, the LED will light up on the cartridge to designate the GI tract that   |                                                                                     |
|:-----------------------------------------------------------------------------------------|:------------------------------------------------------------------------------------|
| will be used for procedure.                                                              |                                                                                     |
| To switch between the ENDO Mentor Suite interchangeable cartridges:                      |                                                                                     |
| 1.                                                                                       | Insert your right hand in the groove on the bottom of the interchangeable cartridge |
|                                                                                          | and your left hand into the edge on the top of the cartridge and gently free the    |
|                                                                                          | cartridge. You should hear a click.                                                 |
| 2.   Pull the cartridge horizontally out. Store it in its designated cavity in the lower |                                                                                     |
|                                                                                          | drawer.                                                                             |
| 3.                                                                                       | Insert the desired cartridge with one hand in the groove and the other on the top   |
|                                                                                          | of the cartridge, push it horizontally into place. You should hear a click.         |

[OCR_TABLE]
i | etl ell

[OCR]
Chapter 2 ENDO Mentor Suite System

GI-BRONCH interchangeable cartridge

Figure 2-3: GI-BRONCH interchangeable cartridge — lower orifice selected

Two symbols of the upper GI and lower Gl tracts are displayed on the GI-BRONCH
interchangeable cartridge indicating the relevant GI tract segment. Depending on the
module selected, the LED will light up on the cartridge to designate the Gl tract that
will be used for procedure.

To switch between the ENDO Mentor Suite interchangeable cartridges:

1. Insert your right hand in the groove on the bottom of the interchangeable cartridge
and your left hand into the edge on the top of the cartridge and gently free the
cartridge. You should hear a click.

2. Pull the cartridge horizontally out. Store it in its designated cavity in the lower
drawer.

3. Insert the desired cartridge with one hand in the groove and the other on the top
of the cartridge, push it horizontally into place. You should hear a click.

Note: The cartridge must be properly positioned prior to introducing the scopes.

surgicalscience Page 7


# Page 17

Chapter 2 
 ENDO Mentor Suite System
 
Page 8
 
Scope hanger 
 
Figure 2-4: Scope hanger – URO scopes  
The scope hanger units are generic, each scope can fit in any hanger. 
Note: The resectoscope is hung on the tool tray and not on the scope hanger. 
Connecting the scope 
The GI scopes and BRONCH scope are connected to socket C at the front of the 
system.  
The rigid URO scopes are connected to sockets A and B; the BRONCH scope is used 
as a flexible URO scope and is connected to socket C. 
The resectoscope, used in TURP modules, is connected to socket C at the front of the 
system. 
To connect the scope:  
1.  Fit the scope connector exactly in the prongs and recesses of the system 
connector.  


[TABLE]
| Chapter 2                                                                       | ENDO Mentor Suite System                                                             |
|:--------------------------------------------------------------------------------|:-------------------------------------------------------------------------------------|
| Scope hanger                                                                    |                                                                                      |
| F                                                                               |                                                                                      |
| i                                                                               |                                                                                      |
| gure 2-4: Scope hanger – URO scopes                                             |                                                                                      |
| The scope hanger units are generic, each scope can fit in any hanger.           |                                                                                      |
| Note: The resectoscope is hung on the tool tray and not on the scope hanger.    |                                                                                      |
| Connecting the scope                                                            |                                                                                      |
| The GI scopes and BRONCH scope are connected to socket C at the front of the    |                                                                                      |
| system.                                                                         |                                                                                      |
| The rigid URO scopes are connected to sockets A and B; the BRONCH scope is used |                                                                                      |
| as a flexible URO scope and is connected to socket C.                           |                                                                                      |
|                                                                                 | The resectoscope, used in TURP modules, is connected to socket C at the front of the |
| system.                                                                         |                                                                                      |
| To connect the scope:                                                           |                                                                                      |
| 1.   Fit the scope connector exactly in the prongs and recesses of the system   |                                                                                      |
| connector.                                                                      |                                                                                      |
|                                                                                 | Page 8                                                                               |

[OCR]
Chapter 2 ENDO Mentor Suite System

Scope hanger

Figure 2-4: Scope hanger —- URO scopes

The scope hanger units are generic, each scope can fit in any hanger.

Note: The resectoscope is hung on the tool tray and not on the scope hanger.

Connecting the scope

The GI scopes and BRONCH scope are connected to socket C at the front of the
system.

The rigid URO scopes are connected to sockets A and B; the BRONCH scope is used
as a flexible URO scope and is connected to socket C.

The resectoscope, used in TURP modules, is connected to socket C at the front of the
system.
To connect the scope:

1. Fit the scope connector exactly in the prongs and recesses of the system
connector.

surgicalscience Page 8


# Page 18

Chapter 2 
 ENDO Mentor Suite System
 
Page 9
 
2.  Turn the external dial on the scope connector to the right until you hear a click. 
To disconnect the scope: 
1.  Turn the dial to the left and remove the scope connector. 
Note: Bumping against the scope connector while connected may result in damage to both the 
scope and the system. 
 
Figure 2-5: System and scope connectors 
Extensions 
The GI and URO modules require an extension for performing certain procedures. The 
GI modality extension is on the left side of the ENDO Mentor Suite and the URO 
modality extension is on the back of the simulator. 


[TABLE]
| Chapter 2                                                                               | ENDO Mentor Suite System                                                                    |
|:----------------------------------------------------------------------------------------|:--------------------------------------------------------------------------------------------|
| 2.   Turn the external dial on the scope connector to the right until you hear a click. |                                                                                             |
| To disconnect the scope:                                                                |                                                                                             |
| 1.   Turn the dial to the left and remove the scope connector.                          |                                                                                             |
|                                                                                         | Note:  Bumping against the scope connector while connected may result in damage to both the |
| scope and the system.                                                                   |                                                                                             |
| F                                                                                       |                                                                                             |
| i                                                                                       |                                                                                             |
| gure 2-5: System and scope connectors                                                   |                                                                                             |
| Extensions                                                                              |                                                                                             |
|                                                                                         | The GI and URO modules require an extension for performing certain procedures. The          |
| GI modality extension is on the left side of the ENDO Mentor Suite and the URO          |                                                                                             |
| modality extension is on the back of the simulator.                                     |                                                                                             |
|                                                                                         | Page 9                                                                                      |

[OCR]
Chapter 2 ENDO Mentor Suite System

2. Turn the external dial on the scope connector to the right until you hear a click.

To disconnect the scope:
1. Turn the dial to the left and remove the scope connector.

Note: Bumping against the scope connector while connected may result in damage to both the
scope and the system.

Figure 2-5: System and scope connectors

Extensions

The GI and URO modules require an extension for performing certain procedures. The
Gl modality extension is on the left side of the ENDO Mentor Suite and the URO
modality extension is on the back of the simulator.

surgicalscience Page 9


# Page 19

Chapter 2 
 ENDO Mentor Suite System
 
Page 10
 
 
Figure 2-6: URO modality extension 
 
 
Figure 2-7: GI modality extension 


[TABLE]
| Chapter 2                        | ENDO Mentor Suite System   |
|:---------------------------------|:---------------------------|
| F                                |                            |
| i                                |                            |
| gure 2-6: URO modality extension |                            |
| F                                |                            |
| i                                |                            |
| gure 2-7: GI modality extension  |                            |
|                                  | Page 10                    |

[OCR]
Chapter 2 ENDO Mentor Suite System

Figure 2-6: URO modality extension

Figure 2-7: Gl modality extension

surgicalscience Page 10


# Page 20

Chapter 2 
 ENDO Mentor Suite System
 
Page 11
 
To open the extension:  
1.  Press gently the modality extension. It will pop out.  
 
 
2.  Pull it to its full length. 
 
 
Figure 2-8: GI extension fully opened (left), URO extension fully opened (right) 
To close the extension: 
1.  Push the extension until it fits back in place. 
Working positions 
The ENDO Mentor Suite supports different working positions. 
GI Mentor: 
The user is operating in front of the simulator, facing the GI-BRONCH interchangeable 
cartridge. 
 


[TABLE]
| Chapter 2                                                                      | ENDO Mentor Suite System                                                              |
|:-------------------------------------------------------------------------------|:--------------------------------------------------------------------------------------|
| To open the extension:                                                         |                                                                                       |
| 1.   Press gently the modality extension. It will pop out.                     |                                                                                       |
| 2.   Pull it to its full length.                                               |                                                                                       |
| F                                                                              |                                                                                       |
| i                                                                              |                                                                                       |
| gure 2-8: GI extension fully opened (left), URO extension fully opened (right) |                                                                                       |
| To close the extension:                                                        |                                                                                       |
| 1.   Push the extension until it fits back in place.                           |                                                                                       |
| Working positions                                                              |                                                                                       |
| The ENDO Mentor Suite supports different working positions.                    |                                                                                       |
| GI Mentor:                                                                     |                                                                                       |
|                                                                                | The user is operating in front of the simulator, facing the GI-BRONCH interchangeable |
| cartridge.                                                                     |                                                                                       |
|                                                                                | Page 11                                                                               |

[OCR]
Chapter 2 ENDO Mentor Suite System

To open the extension:
1. Press gently the modality extension. It will pop out.

2. Pull it to its full length.

—* | ay 1 |

. =~ a
Figure 2-8: G/ extension fully opened (left), URO extension fully opened (right)

To close the extension:
1. Push the extension until it fits back in place.

Working positions

The ENDO Mentor Suite supports different working positions.
Gl Mentor:

The user is operating in front of the simulator, facing the GI-BRONCH interchangeable
cartridge.

surgicalscience Page 11


# Page 21

Chapter 2 
 ENDO Mentor Suite System
 
Page 12
 
BRONCH Mentor: 
• 
Superior – the user is operating from behind the patient’s head. 
• 
Lateral – the user is operating laterally to the patient. 
URO Mentor: 
The user is operating in front of the simulator, facing the URO interchangeable 
cartridge. 
 
Figure 2-9: URO Mentor working position 
 
The screen and the tool tray are adjustable to conveniently support each working 
position. 


[TABLE]
| Chapter 2                                                                       |
|  ENDO Mentor Suite System                                                       |
|:--------------------------------------------------------------------------------|
| BRONCH Mentor:                                                                  |
| Superior – the user is operating from behind the patient’s head.                |
| •                                                                               |
| Lateral – the user is operating laterally to the patient.                       |
| •                                                                               |
| URO Mentor:                                                                     |
| The user is operating in front of the simulator, facing the URO interchangeable |
| cartridge.                                                                      |
| F                                                                               |
| i                                                                               |
| gure 2-9: URO Mentor working position                                           |
| T                                                                               |
| he screen and the tool tray are adjustable to conveniently support each working |
| position.                                                                       |
| Page 12                                                                         |

[OCR]
Chapter 2 ENDO Mentor Suite System

BRONCH Mentor:

. Superior — the user is operating from behind the patient’s head.
. Lateral - the user is operating laterally to the patient.

URO Mentor:

The user is operating in front of the simulator, facing the URO interchangeable
cartridge.

Figure 2-9: URO Mentor working position

The screen and the tool tray are adjustable to conveniently support each working
position.

surgicalscience Page 12


# Page 22

Chapter 2 
 ENDO Mentor Suite System
 
Page 13
 
Height elevation mechanism 
The height of the ENDO Mentor Suite platform can be adjusted.  
 
Figure 2-10: Height elevation panel – (from left to right) USB port, Height Elevation mechanism, 
Computer On/Off button 
Use the Up and Down arrows on the Height Elevation panel to find the desired height.  
Note: The USB port can be used for example for connecting an external hard drive. 
Turning on the simulator 
1.  Make sure the On/Off Power switch on the back of the simulator is turned on. 
2.  Use the button to the right of the Height Elevation mechanism to turn on the ENDO 
Mentor Suite computer. 
 


[TABLE]
| Chapter 2                                                                         | ENDO Mentor Suite System                                                                       |
|:----------------------------------------------------------------------------------|:-----------------------------------------------------------------------------------------------|
| Height elevation mechanism                                                        |                                                                                                |
| The height of the ENDO Mentor Suite platform can be adjusted.                     |                                                                                                |
| F                                                                                 | gure 2-10: Height elevation panel – (from left to right) USB port, Height Elevation mechanism, |
| i                                                                                 |                                                                                                |
| Computer On/Off button                                                            |                                                                                                |
|                                                                                   | Use the Up and Down arrows on the Height Elevation panel to find the desired height.           |
| Note: The USB port can be used for example for connecting an external hard drive. |                                                                                                |
| Turning on the simulator                                                          |                                                                                                |
| 1.   Make sure the On/Off Power switch on the back of the simulator is turned on. |                                                                                                |
|                                                                                   | 2.   Use the button to the right of the Height Elevation mechanism to turn on the ENDO         |
| Mentor Suite computer.                                                            |                                                                                                |
|                                                                                   | Page 13                                                                                        |

[OCR]
Chapter 2 ENDO Mentor Suite System

Height elevation mechanism

The height of the ENDO Mentor Suite platform can be adjusted.

Figure 2-10: Height elevation panel - (from left to right) USB port, Height Elevation mechanism,
Computer On/Off button

Use the Up and Down arrows on the Height Elevation panel to find the desired height.

Note: The USB port can be used for example for connecting an external hard drive.

Turning on the simulator

1. Make sure the On/Off Power switch on the back of the simulator is turned on.
2. Use the button to the right of the Height Elevation mechanism to turn on the ENDO
Mentor Suite computer.

surgicalscience Page 13


# Page 23

Chapter 2 
 ENDO Mentor Suite System
 
Page 14
 
Tool tray 
The rotating tool tray holds all the tools for the ENDO Mentor Suite system: 
• 
Master Tool – URO Mentor, BRONCH Mentor, GI Mentor 
• 
URO forceps – URO Mentor 
• 
Syringe – BRONCH Mentor 
• 
EBUS needle – BRONCH Mentor 
• 
Red and blue wires – GI Mentor 
• 
Resectoscope – URO Mentor (TURP modules) 
Note: When not being used or upon moving the system, the tool tray must be stored in its 
original position to avoid damage. 
 


[TABLE]
| Tool tray                                                                                 |                                                    |
|:------------------------------------------------------------------------------------------|:---------------------------------------------------|
| The rotating tool tray holds all the tools for the ENDO Mentor Suite system:              |                                                    |
| •                                                                                         | Master Tool – URO Mentor, BRONCH Mentor, GI Mentor |
| •                                                                                         | URO forceps – URO Mentor                           |
| •                                                                                         | Syringe – BRONCH Mentor                            |
| •                                                                                         | EBUS needle – BRONCH Mentor                        |
| •                                                                                         | Red and blue wires – GI Mentor                     |
| •                                                                                         | Resectoscope – URO Mentor (TURP modules)           |
| Note:  When not being used or upon moving the system, the tool tray must be stored in its |                                                    |
|                                                                                           | original position to avoid damage.                 |

[OCR_TABLE]
Chapter

[OCR]
Chapter 2 ENDO Mentor Suite System

Tool tray

The rotating tool tray holds all the tools for the ENDO Mentor Suite system:

Master Tool - URO Mentor, BRONCH Mentor, GI Mentor
URO forceps — URO Mentor

Syringe - BRONCH Mentor

EBUS needle - BRONCH Mentor

Red and blue wires — GI Mentor

Resectoscope - URO Mentor (TURP modules)

Note: When not being used or upon moving the system, the tool tray must be stored in its
original position to avoid damage.

surgicalscience Page 14


# Page 24

Chapter 2 
 ENDO Mentor Suite System
 
Page 15
 
 
Figure 2-11: Tool tray hanger with URO tools  
Note: The resectoscope is positioned on the tool tray so that the camera handle is above the 
TURP Mentor scope clip. 
 
Figure 2-12: Resectoscope hung on the tool tray 


[TABLE]
| Chapter 2                                                                                    | ENDO Mentor Suite System   |
|:---------------------------------------------------------------------------------------------|:---------------------------|
| F                                                                                            |                            |
| i                                                                                            |                            |
| gure 2-11: Tool tray hanger with URO tools                                                   |                            |
| Note: The resectoscope is positioned on the tool tray so that the camera handle is above the |                            |
| TURP Mentor scope clip.                                                                      |                            |
| F                                                                                            |                            |
| i                                                                                            |                            |
| gure 2-12: Resectoscope hung on the tool tray                                                |                            |
|                                                                                              | Page 15                    |

[OCR]
Chapter 2 ENDO Mentor Suite System

Figure 2-11: Tool tray hanger with URO tools

Note: The resectoscope is positioned on the tool tray so that the camera handle is above the
TURP Mentor scope clip.

J j
Figure 2-12: Resectoscope hung on the tool tray

surgicalscience Page 15


# Page 25

Chapter 2 
 ENDO Mentor Suite System
 
Page 16
 
The tool connectors are on the side of the platform under the tool tray. Use the labeled 
outlets to connect the tool cables as shown below. 
 
Figure 2-13: Tool connection outlets 
1 
MT (Master tool) 
2 
UR (URO forceps) 
3 
SR (Syringe) 
4 
EB (EBUS needle) 
 
The red and blue wires do not need to be connected to a tool outlet as they are 
wireless; the white wire needs no connection as it is already connected to the Master 
Tool. 
When not in use, the wires can be stored either in the upper drawer or on the tool tray. 


[TABLE]
| Chapter 2   |                                                                                          | ENDO Mentor Suite System   |
|:------------|:-----------------------------------------------------------------------------------------|:---------------------------|
|             | The tool connectors are on the side of the platform under the tool tray. Use the labeled |                            |
|             | outlets to connect the tool cables as shown below.                                       |                            |
| F           | gure 2-13: Tool connection outlets                                                       |                            |
| i           |                                                                                          |                            |
| 1           | MT (Master tool)                                                                         |                            |
| 2           | UR (URO forceps)                                                                         |                            |
| 3           | SR (Syringe)                                                                             |                            |
| 4           | EB (EBUS needle)                                                                         |                            |
| T           | he red and blue wires do not need to be connected to a tool outlet as they are           |                            |
|             | wireless; the white wire needs no connection as it is already connected to the Master    |                            |
| Tool.       |                                                                                          |                            |
|             | When not in use, the wires can be stored either in the upper drawer or on the tool tray. |                            |
|             |                                                                                          | Page 16                    |

[OCR]
Chapter 2 ENDO Mentor Suite System

The tool connectors are on the side of the platform under the tool tray. Use the labeled
outlets to connect the tool cables as shown below.

Figure 2-13: Tool connection outlets

1 MT (Master tool)

2 UR (URO forceps)
3 SR (Syringe)

4 EB (EBUS needle)

The red and blue wires do not need to be connected to a tool outlet as they are
wireless; the white wire needs no connection as it is already connected to the Master
Tool.

When not in use, the wires can be stored either in the upper drawer or on the tool tray.

surgicalscience Page 16


# Page 26

Chapter 2 
 ENDO Mentor Suite System
 
Page 17
 
Foot switch 
A triple foot switch is provided with the platform and utilized in some of the modules 
for actions such as application of electrosurgical current (left foot switch) or 
application of X-ray (right foot switch).  
The foot switch is utilized in the TURP modules for electrosurgical current: cutting 
(middle foot switch) and coagulation (right foot switch). 
 
Figure 2-14: Foot switch 


[TABLE]
| Chapter 2                                                                              | ENDO Mentor Suite System   |
|:---------------------------------------------------------------------------------------|:---------------------------|
| Foot switch                                                                            |                            |
| A triple foot switch is provided with the platform and utilized in some of the modules |                            |
| for actions such as application of electrosurgical current (left foot switch) or       |                            |
| application of X-ray (right foot switch).                                              |                            |
| The foot switch is utilized in the TURP modules for electrosurgical current: cutting   |                            |
| (middle foot switch) and coagulation (right foot switch).                              |                            |

[OCR]
Chapter 2 ENDO Mentor Suite System

Foot switch

A triple foot switch is provided with the platform and utilized in some of the modules
for actions such as application of electrosurgical current (left foot switch) or
application of X-ray (right foot switch).

The foot switch is utilized in the TURP modules for electrosurgical current: cutting
(middle foot switch) and coagulation (right foot switch).

Figure 2-14: Foot switch

surgicalscience Page 17


# Page 27

Chapter 2 
 ENDO Mentor Suite System
 
Page 18
 
Available scopes 
Different scopes are provided for the following modules:  
• 
URO Tasks & Skills and Complete Procedures 
o 
Rigid cystoscope  
o 
Rigid ureteroscope  
o 
Flexible scope 
• 
TURP Skills and Procedures 
o 
Resectoscope 
Note: The flexible scope simulates both the flexible cystoscope and the flexible ureteroscope. 
 
Make sure the scopes are not protruding before closing the drawer. 
Failing to do so may result in irreparable damage to the scopes. 


[TABLE]
| Chapter 2                                                                                       | ENDO Mentor Suite System   |
|:------------------------------------------------------------------------------------------------|:---------------------------|
| Available scopes                                                                                |                            |
| Different scopes are provided for the following modules:                                        |                            |
| URO Tasks & Skills and Complete Procedures                                                      |                            |
| •                                                                                               |                            |
| Rigid cystoscope                                                                                |                            |
| o                                                                                               |                            |
| Rigid ureteroscope                                                                              |                            |
| o                                                                                               |                            |
| Flexible scope                                                                                  |                            |
| o                                                                                               |                            |
| TURP Skills and Procedures                                                                      |                            |
| •                                                                                               |                            |
| Resectoscope                                                                                    |                            |
| o                                                                                               |                            |
| Note:  The flexible scope simulates both the flexible cystoscope and the flexible ureteroscope. |                            |
| Make sure the scopes are not protruding before closing the drawer.                              |                            |
| Failing to do so may result in irreparable damage to the scopes.                                |                            |
|                                                                                                 | Page 18                    |

[OCR]
Chapter 2 ENDO Mentor Suite System

Available scopes

Different scopes are provided for the following modules:
. URO Tasks & Skills and Complete Procedures

° Rigid cystoscope
° Rigid ureteroscope
° Flexible scope

. TURP Skills and Procedures

° Resectoscope

Note: The flexible scope simulates both the flexible cystoscope and the flexible ureteroscope.

Make sure the scopes are not protruding before closing the drawer.
Failing to do so may result in irreparable damage to the scopes.

surgicalscience Page 18


# Page 28

Chapter 2 
 ENDO Mentor Suite System
 
Page 19
 
Rigid cystoscope 
The rigid cystoscope is used for endoscopy of the urinary bladder via the urethra for 
diagnostic or therapeutic purposes. It allows the user to view stones, strictures and 
abnormal tissues, polyps, tumors or cancer of the urethra or bladder.  
 
Figure 2-15: Rigid Cystoscope 


[TABLE]
| Chapter 2                                                                             | ENDO Mentor Suite System   |
|:--------------------------------------------------------------------------------------|:---------------------------|
| Rigid cystoscope                                                                      |                            |
| The rigid cystoscope is used for endoscopy of the urinary bladder via the urethra for |                            |
| diagnostic or therapeutic purposes. It allows the user to view stones, strictures and |                            |
| abnormal tissues, polyps, tumors or cancer of the urethra or bladder.                 |                            |
| F                                                                                     |                            |
| i                                                                                     |                            |
| gure 2-15: Rigid Cystoscope                                                           |                            |
|                                                                                       | Page 19                    |

[OCR]
Chapter 2 ENDO Mentor Suite System

Rigid cystoscope

The rigid cystoscope is used for endoscopy of the urinary bladder via the urethra for
diagnostic or therapeutic purposes. It allows the user to view stones, strictures and
abnormal tissues, polyps, tumors or cancer of the urethra or bladder.

Figure 2-15: Rigid Cystoscope

surgicalscience Page 19


# Page 29

Chapter 2 
 ENDO Mentor Suite System
 
Page 20
 
Rigid ureteroscope 
The rigid ureteroscope is used to examine the upper urinary tract. It is passed through 
the urethra and bladder and then into the ureter and allows the user to view kidney 
stones and abnormal tissues, polyps, tumors or cancer of the kidney or ureter. 
 
Figure 2-16: Rigid Ureteroscope 


[TABLE]
| Chapter 2                                                                           | ENDO Mentor Suite System                                                                |
|:------------------------------------------------------------------------------------|:----------------------------------------------------------------------------------------|
| Rigid ureteroscope                                                                  |                                                                                         |
|                                                                                     | The rigid ureteroscope is used to examine the upper urinary tract. It is passed through |
| the urethra and bladder and then into the ureter and allows the user to view kidney |                                                                                         |
| stones and abnormal tissues, polyps, tumors or cancer of the kidney or ureter.      |                                                                                         |
| F                                                                                   |                                                                                         |
| i                                                                                   |                                                                                         |
| gure 2-16: Rigid Ureteroscope                                                       |                                                                                         |
|                                                                                     | Page 20                                                                                 |

[OCR]
Chapter 2 ENDO Mentor Suite System

Rigid ureteroscope

The rigid ureteroscope is used to examine the upper urinary tract. It is passed through
the urethra and bladder and then into the ureter and allows the user to view kidney
stones and abnormal tissues, polyps, tumors or cancer of the kidney or ureter.

Figure 2-16: Rigid Ureteroscope

surgicalscience Page 20


# Page 30

Chapter 2 
 ENDO Mentor Suite System
 
Page 21
 
Flexible scope 
The flexible scope is used as both a cystoscope and ureteroscope. Its flexible middle 
tube allows the user to reach difficult parts of the urethra, bladder and urinary tract. 
 
Figure 2-17: Flexible scope 


[TABLE]
| Chapter 2                                                                                | ENDO Mentor Suite System                                                              |
|:-----------------------------------------------------------------------------------------|:--------------------------------------------------------------------------------------|
| Flexible scope                                                                           |                                                                                       |
|                                                                                          | The flexible scope is used as both a cystoscope and ureteroscope. Its flexible middle |
| tube allows the user to reach difficult parts of the urethra, bladder and urinary tract. |                                                                                       |
| F                                                                                        |                                                                                       |
| i                                                                                        |                                                                                       |
| gure 2-17: Flexible scope                                                                |                                                                                       |
|                                                                                          | Page 21                                                                               |

[OCR]
Chapter 2 ENDO Mentor Suite System

Flexible scope

The flexible scope is used as both a cystoscope and ureteroscope. Its flexible middle
tube allows the user to reach difficult parts of the urethra, bladder and urinary tract.

Figure 2-17: Flexible scope

surgicalscience Page 21


# Page 31

Chapter 2 
 ENDO Mentor Suite System
 
Page 22
 
Resectoscope 
 
 
Figure 2-18: Adapted resectoscope  
1 
Camera handle 
2 
Camera buttons 
3 
Zoom ring 
4 
Focus ring 
5 
Working element 
6 
Outflow valve 
7 
Outflow tube 
8 
Inflow valve 
9 
Inflow tube 
 


[TABLE]
| F   |   gure 2-18: Adapted resectoscope |                 |
| i   |                                   |                 |
|:----|----------------------------------:|:----------------|
|     |                                 1 | Camera handle   |
|     |                                 2 | Camera buttons  |
|     |                                 3 | Zoom ring       |
|     |                                 4 | Focus ring      |
|     |                                 5 | Working element |
|     |                                 6 | Outflow valve   |
|     |                                 7 | Outflow tube    |
|     |                                 8 | Inflow valve    |
|     |                                 9 | Inflow tube     |

[OCR]
Chapter 2 ENDO Mentor Suite System

Resectoscope

Figure 2-18: Adapted resectoscope

Camera handle
Camera buttons
Zoom ring

Focus ring
Working element
Outflow valve
Outflow tube

Inflow valve

oO aAnN Oo BR WYN

Inflow tube

surgicalscience Page 22


# Page 32

Chapter 2 
 ENDO Mentor Suite System
 
Page 23
 
Camera 
Resectoscope simulates the use of an endoscopic camera with a camera handle and a 
menu of camera angles. You can manipulate the camera exactly as you would 
manipulate a real endoscopic camera. When the camera is inserted, the screen 
displays a simulated image of the operative field and the image changes responsively 
when you move the camera inward and outward and side to side or rotate the camera. 
 
Figure 2-19: Resectoscope’s camera handle 
1 
Camera handle. Use the camera handle to hold the 
endoscopic camera. Once the scope is inserted, you can roll 
the camera in all directions. It is advisable to select an 
appropriate camera angle from the camera menu before use 
(see Camera angle options on page 61).  
2 
Camera buttons. Currently unavailable. 


[TABLE]
| Chapter 2                                                                    | ENDO Mentor Suite System                                                             |
|:-----------------------------------------------------------------------------|:-------------------------------------------------------------------------------------|
| Camera                                                                       |                                                                                      |
|                                                                              | Resectoscope simulates the use of an endoscopic camera with a camera handle and a    |
| menu of camera angles. You can manipulate the camera exactly as you would    |                                                                                      |
| manipulate a real endoscopic camera. When the camera is inserted, the screen |                                                                                      |
|                                                                              | displays a simulated image of the operative field and the image changes responsively |
|                                                                              | when you move the camera inward and outward and side to side or rotate the camera.   |

[TABLE]
| F   | gure 2-19: Resectoscope’s camera handle                     |
| i   |                                                             |
|:----|:------------------------------------------------------------|
| 1   | Camera handle. Use the camera handle to hold the            |
|     | endoscopic camera. Once the scope is inserted, you can roll |
|     | the camera in all directions. It is advisable to select an  |
|     | appropriate camera angle from the camera menu before use    |
|     | (see Camera angle options on page 61).                      |
| 2   | Camera buttons. Currently unavailable.                      |

[OCR]
Chapter 2 ENDO Mentor Suite System

Camera

Resectoscope simulates the use of an endoscopic camera with a camera handle and a
menu of camera angles. You can manipulate the camera exactly as you would
manipulate a real endoscopic camera. When the camera is inserted, the screen
displays a simulated image of the operative field and the image changes responsively
when you move the camera inward and outward and side to side or rotate the camera.

I

Figure 2-19: Resectoscope’s camera handle

1 Camera handle. Use the camera handle to hold the
endoscopic camera. Once the scope is inserted, you can roll
the camera in all directions. It is advisable to select an
appropriate camera angle from the camera menu before use
(see Camera angle options on page 61).

2 Camera buttons. Currently unavailable.

surgicalscience Page 23


# Page 33

Chapter 2 
 ENDO Mentor Suite System
 
Page 24
 
3 
Zoom ring. Turn the Zoom ring clockwise to zoom in (subject 
appears closer) and counterclockwise to zoom out (subject 
appears farther away). 
4 
Focus ring. Turn the Focus ring to achieve the sharpest 
possible image. 
Tools 
In relevant modules, the URO Mentor has two available tools: Master Tool and forceps. 
Master Tool 
 
Figure 2-20: Master Tool 
To select a virtual tool using the Master Tool: 
1.  Insert the Master Tool slowly into the working channel until the Tools menu 
appears.  
The Tools menu opens with pictures of all available tools.  
To work with Master Tool handle: 
• 
Pull the Master Tool handle back to open, inflate, or fill the tool. 
• 
Push the Master Tool handle forward to close, deflate, or inject using the tool.  


[TABLE]
| Chapter 2   |                                                             |
|:------------|:------------------------------------------------------------|
| 3           | Zoom ring. Turn the Zoom ring clockwise to zoom in (subject |
|             | appears closer) and counterclockwise to zoom out (subject   |
|             | appears farther away).                                      |
| 4           | Focus ring. Turn the Focus ring to achieve the sharpest     |
|             | possible image.                                             |

[OCR]
Chapter 2 ENDO Mentor Suite System

3 Zoom ring. Turn the Zoom ring clockwise to zoom in (subject
appears closer) and counterclockwise to zoom out (subject
appears farther away).

4 Focus ring. Turn the Focus ring to achieve the sharpest
possible image.

Tools

In relevant modules, the URO Mentor has two available tools: Master Tool and forceps.

Master Tool

Figure 2-20: Master Tool

To select a virtual tool using the Master Tool:

1. Insert the Master Tool slowly into the working channel until the Tools menu
appears.
The Tools menu opens with pictures of all available tools.

To work with Master Tool handle:

e Pull the Master Tool handle back to open, inflate, or fill the tool.
. Push the Master Tool handle forward to close, deflate, or inject using the tool.

surgicalscience Page 24


# Page 34

Chapter 2 
 ENDO Mentor Suite System
 
Page 25
 
Forceps 
 
Figure 2-21: Forceps 
To work with forceps handle: 
• 
Slide the handle knob back to open the tool. 
• 
Slide the knob forward to close the tool.  
 


[TABLE]
| Chapter 2                                     | ENDO Mentor Suite System   |
|:----------------------------------------------|:---------------------------|
| Forceps                                       |                            |
| F                                             |                            |
| i                                             |                            |
| gure 2-21: Forceps                            |                            |
| To work with forceps handle:                  |                            |
| Slide the handle knob back to open the tool.  |                            |
| •                                             |                            |
| Slide the knob forward to close the tool.     |                            |
| •                                             |                            |
|                                               | Page 25                    |

[OCR]
Chapter 2 ENDO Mentor Suite System

Forceps

Figure 2-21: Forceps

To work with forceps handle:

. Slide the handle knob back to open the tool.
. Slide the knob forward to close the tool.

surgicalscience Page 25


# Page 35

Chapter 3 
 URO Mentor Library of Modules and Courses
 
Page 26
 
Chapter 3 URO Mentor Library of Modules 
and Courses 
The URO Mentor modules has been developed in close collaboration with the medical 
community to provide a meaningful and valuable training solution. It  provides the most 
comprehensive endourology hands-on training and practice opportunities for 
diagnostic and therapeutic procedures.  
Introduction to the use of endourology scopes and tools is done by working on 
coordination skills and essential tasks for the review of anatomies, followed by the 
practice of actual procedures on a variety of virtual patient cases, each with its own 
unique anatomy and pathologies. 
TURP modules  
TURP Basic Skills 
 
The Basic Skills module enables trainees to acquire core skills 
essential for the TURP procedure.  
This module allows trainees to practice the following skills in a 
non-anatomic environment: camera navigation and 
manipulation using angled optics, resection, and bleeding 
control. 
 
 
 
 
TURP Procedures 
 
 
Cases include hands-on training on clinical cases of 
transurethral resection of the prostate (TURP) procedure. The 
cases present realistic scenarios of benign prostatic 
hyperplasia (BPH) with small to large, median, and side lobes, 
with variations in bleeding severity. 
Accompanied by comprehensive educational aids, trainees 
can practice hands-on resection, visualization of anatomical 
landmarks, management of irrigation fluid and control of 
bleeding. 
 
 


[TABLE]
|                   | TURP modules                                                      |
|:------------------|:------------------------------------------------------------------|
|                   | T                                                                 |
|                   | he Basic Skills module enables trainees to acquire core skills    |
|                   | essential for the TURP procedure.                                 |
|                   | This module allows trainees to practice the following skills in a |
| TURP Basic Skills |                                                                   |
|                   | non-anatomic environment: camera navigation and                   |
|                   | manipulation using angled optics, resection, and bleeding         |
|                   | control.                                                          |

[OCR_TABLE]
Chapter 3

[OCR]
Chapter 3 URO Mentor Library of Modules and Courses

Chapter 3 URO Mentor Library of Modules
and Courses

The URO Mentor modules has been developed in close collaboration with the medical
community to provide a meaningful and valuable training solution. It provides the most
comprehensive endourology hands-on training and practice opportunities for
diagnostic and therapeutic procedures.

Introduction to the use of endourology scopes and tools is done by working on
coordination skills and essential tasks for the review of anatomies, followed by the
practice of actual procedures on a variety of virtual patient cases, each with its own
unique anatomy and pathologies.

TURP modules

The Basic Skills module enables trainees to acquire core skills
essential for the TURP procedure.

TURP Basic Skills | This module allows trainees to practice the following skills in a
non-anatomic environment: camera navigation and
manipulation using angled optics, resection, and bleeding
control.

Cases include hands-on training on clinical cases of
transurethral resection of the prostate (TURP) procedure. The
cases present realistic scenarios of benign prostatic

TURP Procedures hyperplasia (BPH) with small to large, median, and side lobes,
with variations in bleeding severity.

Accompanied by comprehensive educational aids, trainees
can practice hands-on resection, visualization of anatomical
landmarks, management of irrigation fluid and control of
bleeding.

surgicalscience Page 26


# Page 36

Chapter 3 
 URO Mentor Library of Modules and Courses
 
Page 27
 
Endourology modules  
Essential Skills 
 
This module contains a series of coordination exercises in the 
form of a unique game of basketball, available in two difficulty 
levels. The game, cyberscopy, provides practice in the 
following areas: handling scopes and tools, controlling and 
positioning the endoscopic camera, moving and positioning the 
C-arm, achieving depth perception and orientation, and gaining 
navigational confidence and skills. 
 
 
 
 
 
 
Basic Tasks 
 
This module allows for the practicing a selection of exercises in 
increasing levels of difficulty, for the systematic learning of 
basic tasks such as bladder and kidney inspection, as well as 
the full urinary collecting system anatomy, and identification of 
the endourological landmarks.  
It is designed to help trainees learn to recognize the elements 
of the urinary collecting system including scope navigation 
training, how to efficiently use flexible and rigid scopes and 
urological instruments and to understand the methodological 
bladder screening. 
 
 
 
 
 
 
Stone 
Manipulation 
 
 
This module provides training on urolithiasis endoscopic 
treatment and digenetic procedures in a safe, controlled, real-
life simulated environment. 
The module features the simulation of the full endourological 
procedure, including simulation of an interactive C-arm, 
irrigation pressure and contrast material injection. Learners can 
experience a variety of lithotripters and tools such as baskets, 
forceps, EHL, Pneumatic or Laser lithotripters on a variety of 
virtual cases with different anatomies and pathologies. 
 


[TABLE]
|                  | Endourology modules                                              |
|:-----------------|:-----------------------------------------------------------------|
|                  | T                                                                |
|                  | his module contains a series of coordination exercises in the    |
|                  | form of a unique game of basketball, available in two difficulty |
|                  | levels. The game, cyberscopy, provides practice in the           |
| Essential Skills | following areas: handling scopes and tools, controlling and      |
|                  | positioning the endoscopic camera, moving and positioning the    |
|                  | C-arm, achieving depth perception and orientation, and gaining   |
|                  | navigational confidence and skills.                              |

[OCR_TABLE]
Chapter 3

[OCR]
Chapter 3 URO Mentor Library of Modules and Courses

Endourology modules

This module contains a series of coordination exercises in the
form of a unique game of basketball, available in two difficulty
levels. The game, cyberscopy, provides practice in the
Essential Skills | following areas: handling scopes and tools, controlling and
positioning the endoscopic camera, moving and positioning the
C-arm, achieving depth perception and orientation, and gaining
navigational confidence and skills.

This module allows for the practicing a selection of exercises in
increasing levels of difficulty, for the systematic learning of
basic tasks such as bladder and kidney inspection, as well as
the full urinary collecting system anatomy, and identification of
the endourological landmarks.

It is designed to help trainees learn to recognize the elements
Basic Tasks of the urinary collecting system including scope navigation
training, how to efficiently use flexible and rigid scopes and
urological instruments and to understand the methodological
bladder screening.

This module provides training on urolithiasis endoscopic
treatment and digenetic procedures in a safe, controlled, real-
life simulated environment.

The module features the simulation of the full endourological
procedure, including simulation of an interactive C-arm,
irrigation pressure and contrast material injection. Learners can

Stone experience a variety of lithotripters and tools such as baskets,
Manipulation —_| forceps, EHL, Pneumatic or Laser lithotripters on a variety of
virtual cases with different anatomies and pathologies.

surgicalscience Page 27


# Page 37

Chapter 3 
 URO Mentor Library of Modules and Courses
 
Page 28
 
 
 
 
 
Strictures 
Treatment 
 
 
This module provides training for the treatment of a variety of 
ureteral strictures. It is designed to help trainees learn how to 
interpret anatomical and operative findings in a safe, monitored 
environment. 
The module features simulation of the full procedure including 
simulation of real time fluoroscopy, a variety of stricture 
treatments such as ballooning, stenting or laser and using a 
flexible or rigid Ureteroscope or Cystoscope, as needed. 
Learners can choose to work either over the wire or alongside 
the wire, while taking bladder pressure and vision into 
consideration. 
 
 
 
 


[TABLE]
|            | T                                                                 |
|            | his module provides training for the treatment of a variety of    |
|:-----------|:------------------------------------------------------------------|
|            | ureteral strictures. It is designed to help trainees learn how to |
|            | interpret anatomical and operative findings in a safe, monitored  |
|            | environment.                                                      |
|            | The module features simulation of the full procedure including    |
| Strictures |                                                                   |
|            | simulation of real time fluoroscopy, a variety of stricture       |
| Treatment  |                                                                   |
|            | treatments such as ballooning, stenting or laser and using a      |
|            | flexible or rigid Ureteroscope or Cystoscope, as needed.          |
|            | Learners can choose to work either over the wire or alongside     |
|            | the wire, while taking bladder pressure and vision into           |
|            | consideration.                                                    |

[OCR_TABLE]
Chapter 3

[OCR]
Chapter 3 URO Mentor Library of Modules and Courses

This module provides training for the treatment of a variety of
ureteral strictures. It is designed to help trainees learn how to
interpret anatomical and operative findings in a safe, monitored
environment.

Strictures The module features simulation of the full procedure including
Treatment simulation of real time fluoroscopy, a variety of stricture
treatments such as ballooning, stenting or laser and using a
flexible or rigid Ureteroscope or Cystoscope, as needed.
Learners can choose to work either over the wire or alongside
the wire, while taking bladder pressure and vision into
consideration.

surgicalscience Page 28


# Page 38

Chapter 4 
 Getting Started
 
Page 29
 
Chapter 4 Getting Started 
Workflow 
The following chapters will describe how to use the simulator. To get started on any 
simulation case or task, follow this workflow. 
1.  Log in to MentorLearn on the simulator (see page 31). 
2.  Start a simulation case or task (see page 38). 
3.  Perform the simulation case. 
4.  Learn more about the URO Mentor simulator main features and controls (see page 
43). 
a. How to work with fluoroscopy and the C-Arm (see page 47). 
b. How to use educational aids (see page 51). 
c. How to work with tools (see page 58). 
5.  Learn more about the TURP modules main features and controls (on page 58): 
a. How to use angled optics (see page 61) and tool options (on page ). 
b. How to use educational aids (see page 67). 
c. How to use resectoscope (see page 77). 
d. How to use scope’s camera (see page 78). 
6.  When the case is completed, review your performance report and learning curve 
graphs (see Viewing Performance Reports on page 81). 
 


[TABLE]
| Chapter 4                                                                            | Getting Started                                                                     |
|:-------------------------------------------------------------------------------------|:------------------------------------------------------------------------------------|
| Chapter 4 Getting Started                                                            |                                                                                     |
| Workflow                                                                             |                                                                                     |
| The following chapters will describe how to use the simulator. To get started on any |                                                                                     |
| simulation case or task, follow this workflow.                                       |                                                                                     |
| 1.   Log in to MentorLearn on the simulator (see page 31).                           |                                                                                     |
| 2.   Start a simulation case or task (see page 38).                                  |                                                                                     |
| 3.   Perform the simulation case.                                                    |                                                                                     |
|                                                                                      | 4.   Learn more about the URO Mentor simulator main features and controls (see page |
| 43).                                                                                 |                                                                                     |

[TABLE]
| 1.   Log in to MentorLearn on the simulator (see page 31).                          |
|:------------------------------------------------------------------------------------|
| 2.   Start a simulation case or task (see page 38).                                 |
| 3.   Perform the simulation case.                                                   |
| 4.   Learn more about the URO Mentor simulator main features and controls (see page |
| 43).                                                                                |
| a.  How to work with fluoroscopy and the C-Arm (see page 47).                       |
| b.  How to use educational aids (see page 51).                                      |
| c.  How to work with tools (see page 58).                                           |
| 5.   Learn more about the TURP modules main features and controls (on page 58):     |
| a.  How to use angled optics (see page 61) and tool options (on page ).             |
| b.  How to use educational aids (see page 67).                                      |
| c.  How to use resectoscope (see page 77).                                          |
| d.  How to use scope’s camera (see page 78).                                        |
| 6.   When the case is completed, review your performance report and learning curve  |
| graphs (see Viewing Performance Reports on page 81).                                |

[OCR_TABLE]
napter 4

[OCR_TABLE]
lian.

[OCR]
Chapter 4 Getting Started

| Chapter 4 Getting Started
Workflow

The following chapters will describe how to use the simulator. To get started on any
simulation case or task, follow this workflow.

1.

2.
3.
4

Log in to MentorLearn on the simulator (see page 31).

Start_a simulation case or task (see page 38).

Perform the simulation case.

Learn more about the URO Mentor simulator main features and controls (see page
43).

a. How to work with fluoroscopy and the C-Arm (see page 47).
b. How to use educational aids (see page 51).
c. How to work with tools (see page 58).

Learn more about the TURP modules main features and controls (on page 58):

How to use angled optics (see page 61) and tool options (on page ).
How to use educational aids (see page 67).

a

b.

c. How to use resectoscope (see page 77).

d. How to use scope’s camera (see page 78).

When the case is completed, review your performance report and learning curve
graphs (see Viewing Performance Reports on page 81).

surgicalscience Page 29


# Page 39

Chapter 5 
 MentorLearn
 
Page 30
 
Chapter 5 MentorLearn 
MentorLearn overview 
MentorLearn® is a web-based simulator curricula management system, providing the 
optimal solution for managing training and education needs for the Surgical Science 
line of simulators.  
This easy-to-use system facilitates performing the administrative tasks of a simulator-
based curriculum, running a training course or workshop. The system includes a library 
of ready-to-use simulator-based courses and a platform to design new training 
courses. Courses may include online didactic content, proficiency based hands-on 
training, and performance review and assessment. For more information regarding 
using MentorLearn, refer to the MentorLearn Guide for Learners. 
MentorLearn workflow 
All URO Mentor modules, including didactic materials, simulation tasks, simulation 
cases, are accessed from MentorLearn, Surgical Science's web-based simulation 
curricula management system. 
When you want to use didactic materials from a URO Mentor module, you log in to 
MentorLearn and open the materials from MentorLearn. The MentorLearn login page 
appears on the screen when you turn on the system. 
When you want to perform a hands-on training task or case, you open it from 
MentorLearn. MentorLearn opens the URO Mentor task or case for you, closes it when 
you finish the case or task, and shows you a report of your performance afterwards. 
This is the workflow for performing hands-on training: 
• 
Log in to MentorLearn on the simulator (see page 31). 
• 
Review didactic material (see page 37). 
• 
Start a hands-on case or task from MentorLearn (see Starting a simulation case 
or task on page 38). MentorLearn opens it for you to begin the hands-on 
simulation. 
• 
Perform the case or task using the URO Mentor simulator. When you finish the 
case or task, MentorLearn closes it and displays a performance report. 
• 
Review your performance (see Viewing Performance Reports on page 81). 
 


[TABLE]
| Chapter 5                                                                           | MentorLearn                                                                             |
|:------------------------------------------------------------------------------------|:----------------------------------------------------------------------------------------|
| Chapter 5 MentorLearn                                                               |                                                                                         |
| MentorLearn overview                                                                |                                                                                         |
| MentorLearn® is a web-based simulator curricula management system, providing the    |                                                                                         |
| optimal solution for managing training and education needs for the Surgical Science |                                                                                         |
| line of simulators.                                                                 |                                                                                         |
|                                                                                     | This easy-to-use system facilitates performing the administrative tasks of a simulator- |
|                                                                                     | based curriculum, running a training course or workshop. The system includes a library  |
| of ready-to-use simulator-based courses and a platform to design new training       |                                                                                         |
| courses. Courses may include online didactic content, proficiency based hands-on    |                                                                                         |
| training, and performance review and assessment. For more information regarding     |                                                                                         |
| using MentorLearn, refer to the MentorLearn Guide for Learners.                     |                                                                                         |
| MentorLearn workflow                                                                |                                                                                         |
| All URO Mentor modules, including didactic materials, simulation tasks, simulation  |                                                                                         |
| cases, are accessed from MentorLearn, Surgical Science's web-based simulation       |                                                                                         |
| curricula management system.                                                        |                                                                                         |
| When you want to use didactic materials from a URO Mentor module, you log in to     |                                                                                         |
| MentorLearn and open the materials from MentorLearn. The MentorLearn login page     |                                                                                         |
| appears on the screen when you turn on the system.                                  |                                                                                         |
| When you want to perform a hands-on training task or case, you open it from         |                                                                                         |
|                                                                                     | MentorLearn. MentorLearn opens the URO Mentor task or case for you, closes it when      |
| you finish the case or task, and shows you a report of your performance afterwards. |                                                                                         |
| This is the workflow for performing hands-on training:                              |                                                                                         |

[TABLE]
| When you want to perform a hands-on training task or case, you open it from         |                                                                                |
|:------------------------------------------------------------------------------------|:-------------------------------------------------------------------------------|
| MentorLearn. MentorLearn opens the URO Mentor task or case for you, closes it when  |                                                                                |
| you finish the case or task, and shows you a report of your performance afterwards. |                                                                                |
| This is the workflow for performing hands-on training:                              |                                                                                |
| •                                                                                   | Log in to MentorLearn on the simulator (see page 31).                          |
| •                                                                                   | Review didactic material (see page 37).                                        |
| •                                                                                   | Start a hands-on case or task from MentorLearn (see Starting a simulation case |
|                                                                                     | or task on page 38). MentorLearn opens it for you to begin the hands-on        |
|                                                                                     | simulation.                                                                    |
| •                                                                                   | Perform the case or task using the URO Mentor simulator. When you finish the   |
|                                                                                     | case or task, MentorLearn closes it and displays a performance report.         |
| •                                                                                   | Review your performance (see Viewing Performance Reports on page 81).          |

[OCR_TABLE]
tiie biel

[OCR_TABLE]
Mento

[OCR]
Chapter 5 MentorLearn

| Chapter 5 MentorLearn

MentorLearn overview

MentorLearn® is a web-based simulator curricula management system, providing the
optimal solution for managing training and education needs for the Surgical Science
line of simulators.

This easy-to-use system facilitates performing the administrative tasks of a simulator-
based curriculum, running a training course or workshop. The system includes a library
of ready-to-use simulator-based courses and a platform to design new training
courses. Courses may include online didactic content, proficiency based hands-on
training, and performance review and assessment. For more information regarding
using MentorLearn, refer to the MentorLearn Guide for Learners.

MentorLearn workflow

All URO Mentor modules, including didactic materials, simulation tasks, simulation
cases, are accessed from MentorLearn, Surgical Science's web-based simulation
curricula management system.

When you want to use didactic materials from a URO Mentor module, you log in to
MentorLearn and open the materials from MentorLearn. The MentorLearn login page
appears on the screen when you turn on the system.

When you want to perform a hands-on training task or case, you open it from
MentorLearn. MentorLearn opens the URO Mentor task or case for you, closes it when
you finish the case or task, and shows you a report of your performance afterwards.
This is the workflow for performing hands-on training:

e Log in to MentorLearn on the simulator (see page 31).

e Review didactic material (see page 37).

e Start a hands-on case or task from MentorLearn (see Starting a simulation case
or task on page 38). MentorLearn opens it for you to begin the hands-on
simulation.

. Perform the case or task using the URO Mentor simulator. When you finish the
case or task, MentorLearn closes it and displays a performance report.

. Review your performance (see Viewing Performance Reports on page 81).

surgicalscience Page 30


# Page 40

Chapter 5 
 MentorLearn
 
Page 31
 
Logging in to MentorLearn on the simulator 
In order to access functionality on a simulator, you need to first enter the MentorLearn 
system. You require a login name and password to login. When you log in, your Library 
screen is displayed. For more information regarding using MentorLearn, refer to the 
MentorLearn Guide for Learners or MentorLearn Guide for Administrators. 
Note: If you are entering the application for the first time, contact your system administrator 
and ask him to create your user profile.  
To log in: 
 
Figure 6-1: MentorLearn Login screen 
1.  Press Login. 
The Login screen is displayed. 


[TABLE]
| Chapter 5                                                                                 |
|  MentorLearn                                                                              |
|:------------------------------------------------------------------------------------------|
| Logging in to MentorLearn on the simulator                                                |
| In order to access functionality on a simulator, you need to first enter the MentorLearn  |
| system. You require a login name and password to login. When you log in, your Library     |
| screen is displayed. For more information regarding using MentorLearn, refer to the       |
| MentorLearn Guide for Learners or MentorLearn Guide for Administrators.                   |
| Note:                                                                                     |
| If you are entering the application for the first time, contact your system administrator |
| and ask him to create your user profile.                                                  |

[OCR]
Chapter 5 MentorLearn

Logging in to MentorLearn on the simulator

In order to access functionality on a simulator, you need to first enter the MentorLearn
system. You require a login name and password to login. When you log in, your Library
screen is displayed. For more information regarding using MentorLearn, refer to the
MentorLearn Guide for Learners or MentorLearn Guide for Administrators.

Note: If you are entering the application for the first time, contact your system administrator
and ask him to create your user profile.

To log in:

Register to use the system

Select Language

English

Select Theme

Light

Figure 6-1: MentorLearn Login screen

1. Press Login.
The Login screen is displayed.

surgicalscience Page 31


# Page 41

Chapter 5 
 MentorLearn
 
Page 32
 
 
2.  In Login Name, enter your login name. The login name is case sensitive. 
3.  In Password, enter your password. Your password is case sensitive. 
4.  Press Login. 
MentorLearn opens and displays your Library screen. Your first name and last 
name appear in the top right corner of the screen. 


[TABLE]
| Chapter 5                                                                    |
|  MentorLearn                                                                 |
|:-----------------------------------------------------------------------------|
| 2.                                                                           |
| In Login Name, enter your login name. The login name is case sensitive.      |
| 3.                                                                           |
| In Password, enter your password. Your password is case sensitive.           |
| 4.   Press Login.                                                            |
| MentorLearn opens and displays your Library screen. Your first name and last |
| name appear in the top right corner of the screen.                           |
| Page 32                                                                      |

[OCR]
Chapter 5

MentorLearn

PON

surgicalscience | simbionix simulators

Login Name

BhattieWy

Password

LOGIN

Forgot Password?

LOGIN AS A GUEST

RETURN TO MAIN PAGE

In Login Name, enter your login name. The login name is case sensitive.
In Password, enter your password. Your password is case sensitive.

Press Login.

MentorLearn opens and displays your Library screen. Your first name and last

name appear in the top right corner of the screen.

surgicalscience

Page 32


# Page 42

Chapter 5 
 MentorLearn
 
Page 33
 
When you log in to MentorLearn, the MentorLearn menu appears on the left side of 
the screen. 
 
The menu gives you structured access to the MentorLearn functionality. Press any 
menu option to open the associated screen in MentorLearn. Press 
 above the 
MentorLearn menu to hide it. 
Note: The buttons that appear on the MentorLearn menu are dependent on your 
user-type. 
Working locally and on a cloud site 
The cloud configuration is possible only if there is access to the internet. If there is 
temporarily no internet access but you need to use the simulators, you can switch to 
working locally on the simulator.  
When you switch to work locally, MentorLearn switches from the cloud database to a 
local database, meaning:  
• 
Group, user, and assigned course information is not saved to the local simulator. 
If necessary, groups and users must be redefined on each local simulator, and 
training must be reassigned. 
• 
Any data that is created during the time you are working locally is not saved to 
the cloud database after the simulator is switched back to the cloud site. Any 
reports or information on how a user performed a simulator case will not be 
available, new users and groups, and so on, are maintained in the local database 
and are not available when you are in a cloud site. 
 


[TABLE]
| Note: The buttons that appear on the MentorLearn menu are dependent on your              |
|:-----------------------------------------------------------------------------------------|
| user-type.                                                                               |
| Working locally and on a cloud site                                                      |
| The cloud configuration is possible only if there is access to the internet. If there is |
| temporarily no internet access but you need to use the simulators, you can switch to     |
| working locally on the simulator.                                                        |
| When you switch to work locally, MentorLearn switches from the cloud database to a       |
| local database, meaning:                                                                 |

[TABLE]
| working locally on the simulator.                                                  |                                                                                   |
|:-----------------------------------------------------------------------------------|:----------------------------------------------------------------------------------|
| When you switch to work locally, MentorLearn switches from the cloud database to a |                                                                                   |
| local database, meaning:                                                           |                                                                                   |
| •                                                                                  | Group, user, and assigned course information is not saved to the local simulator. |
|                                                                                    | If necessary, groups and users must be redefined on each local simulator, and     |
|                                                                                    | training must be reassigned.                                                      |
| •                                                                                  | Any data that is created during the time you are working locally is not saved to  |
|                                                                                    | the cloud database after the simulator is switched back to the cloud site. Any    |
|                                                                                    | reports or information on how a user performed a simulator case will not be       |
|                                                                                    | available, new users and groups, and so on, are maintained in the local database  |
|                                                                                    | and are not available when you are in a cloud site.                               |

[OCR_TABLE]
Libr:

[OCR]
Chapter 5 MentorLearn

When you log in to MentorLearn, the MentorLearn menu appears on the left side of
he screen.

Library
My Curricula
Reports

My Profile

The menu gives you structured access to the MentorLearn functionality. Press any

menu option to open the associated screen in MentorLearn. Press = above the
MentorLearn menu to hide it.

Note: The buttons that appear on the MentorLearn menu are dependent on your
user-type.

Working locally and on a cloud site

The cloud configuration is possible only if there is access to the internet. If there is
temporarily no internet access but you need to use the simulators, you can switch to
working locally on the simulator.

When you switch to work locally, MentorLearn switches from the cloud database to a
local database, meaning:

Group, user, and assigned course information is not saved to the local simulator.
If necessary, groups and users must be redefined on each local simulator, and
training must be reassigned.

Any data that is created during the time you are working locally is not saved to
the cloud database after the simulator is switched back to the cloud site. Any
reports or information on how a user performed a simulator case will not be
available, new users and groups, and so on, are maintained in the local database
and are not available when you are in a cloud site.

surgicalscience Page 33


# Page 43

Chapter 5 
 MentorLearn
 
Page 34
 
To switch from working on the MentorLearn cloud site to working locally: 
1.  Open MentorLearn on the simulator. MentorLearn is redirected to work locally with 
the selected simulator. The 
 icon on the top of any screen changes to the 
 
icon.  
Note: It is recommended that you switch back to cloud mode as soon as the internet connection 
is restored. 
 
To switch from working locally to working on the MentorLearn cloud site: 
1.  Open the web browser and go to http://Your-site-name.mentorlearn.com    
MentorLearn is redirected to work with the MentorLearn cloud database. The 
 
icon on the top of any screen changes to the 
 icon. 
Accessing a module or course within My Curricula or 
Library 
This section describes how users train using MentorLearn. 
• 
To access training courses and modules that you have been assigned, press My 
Curricula on the MentorLearn menu (left pane). 
 
Figure 5-2: My Curricula screen 
• 
To access all the training courses and modules available in the library, press 
Library on the MentorLearn menu (left pane). 


[TABLE]
| Chapter 5                                                                                     |
|  MentorLearn                                                                                  |
|:----------------------------------------------------------------------------------------------|
| To switch from working on the MentorLearn cloud site to working locally:                      |
| 1.   Open MentorLearn on the simulator. MentorLearn is redirected to work locally with        |
| the selected simulator. The                                                                   |
|  icon on the top of any screen changes to the                                                 |
| icon.                                                                                         |
| Note: It is recommended that you switch back to cloud mode as soon as the internet connection |
| is restored.                                                                                  |
| T                                                                                             |
| o switch from working locally to working on the MentorLearn cloud site:                       |
| 1.   Open the web browser and go to http://Your-site-name.mentorlearn.com                     |
| MentorLearn is redirected to work with the MentorLearn cloud database. The                    |
| icon on the top of any screen changes to the                                                  |
|  icon.                                                                                        |
| Accessing a module or course within My Curricula or                                           |
| Library                                                                                       |
| This section describes how users train using MentorLearn.                                     |
| To access training courses and modules that you have been assigned, press My                  |
| •                                                                                             |
| Curricula on the MentorLearn menu (left pane).                                                |
| F                                                                                             |
| i                                                                                             |
| gure 5-2: My Curricula screen                                                                 |
| To access all the training courses and modules available in the library, press                |
| •                                                                                             |
| Library on the MentorLearn menu (left pane).                                                  |
| Page 34                                                                                       |

[OCR]
Chapter 5 MentorLearn

To switch from working on the MentorLearn cloud site to working locally:
1. Open MentorLearn on the simulator. MentorLearn is redirected to work locally with

the selected simulator. The & icon on the top of any screen changes to the Q
icon.

Note: It is recommended that you switch back to cloud mode as soon as the internet connection
is restored.

To switch from working locally to working on the MentorLearn cloud site:
1. Open the web browser and go to http://Your-site-name.mentorlearn.com

MentorLearn is redirected to work with the MentorLearn cloud database. The Q
icon on the top of any screen changes to the ® icon.

Accessing a module or course within My Curricula or
Library

This section describes how users train using MentorLearn.

e To access training courses and modules that you have been assigned, press My
Curricula on the MentorLearn menu (left pane).

First Year Urology Residents

e
Cal °
*

Essential Skills -Cyberscopy Hall of Fame
Endourology Basle Tasks

Endourology Full Procedure - Stone Manipulation

”

Endourology Full Procedure -Strctures Treatment

Figure 5-2: My Curricula screen

. To access all the training courses and modules available in the library, press
Library on the MentorLearn menu (left pane).

surgicalscience Page 34


# Page 44

Chapter 5 
 MentorLearn
 
Page 35
 
 
Figure 5-3: URO Mentor Library screen  
On the Library screen, MentorLearn displays the list of modules and courses. They are 
categorized as Simbionix Modules, Standard Courses (ready-to-use courses provided 
by experienced educators in collaboration with Surgical Science), and Customized 
Courses (courses you and other educators at your center have created). 


[TABLE]
| Chapter 5   |                                                                                       | MentorLearn   |
|:------------|:--------------------------------------------------------------------------------------|:--------------|
| F           | gure 5-3: URO Mentor Library screen                                                   |               |
| i           |                                                                                       |               |
|             | On the Library screen, MentorLearn displays the list of modules and courses. They are |               |
|             | categorized as Simbionix Modules, Standard Courses (ready-to-use courses provided     |               |
|             | by experienced educators in collaboration with Surgical Science), and Customized      |               |
|             | Courses (courses you and other educators at your center have created).                |               |
|             |                                                                                       | Page 35       |

[OCR]
Chapter 5

MentorLearn

{URO Mentor Q Display a ~

Simbionix Modules
TURP Skills and Procedures

URO Mentor Tasks and Skills

URO Mentor Complete Procedures

AB Encourology Full Procedure -Stone Manipulation
AL Endourology Full Procedure -Stictures Treatment
2

‘Standard Courses

fF) _Ureteroscony Course Using Simbionix URO Mentor

@ waiter resto cystesconr couse for ese Practtorers

Figure 5-3: URO Mentor Library screen

On the Library screen, MentorLearn displays the list of modules and courses. They are
categorized as Simbionix Modules, Standard Courses (ready-to-use courses provided
by experienced educators in collaboration with Surgical Science), and Customized

Courses (courses you and other educators at your center have created).

surgicalscience

Page 35


# Page 45

Chapter 5 
 MentorLearn
 
Page 36
 
Easy Access to courses and modules in the Library 
 
To easily access courses and modules in 
the Library, press the Easy Access arrow 
on the top right side of the screen and 
select an option from the list. 
To search for a specific module or group 
of modules, press the Search button, 
enter a term and press the Search button 
again. To clear the search results, press 
one of the easy access options. 
 
Open a module or course, review didactic material or perform in a hands-on simulation 
case. For more information, see Reviewing didactic materials on page 37 and on 
Starting a simulation case or task on page 38. 
 
1.  To open a module or course, press its row. The module opens, displaying a 
description of the module, its learning objectives, and the educational content of 
the module. 


[TABLE]
| Easy Access to courses and modules in the Library   |
|:----------------------------------------------------|
| To easily access courses and modules in             |
| the Library, press the Easy Access arrow            |
| on the top right side of the screen and             |
| select an option from the list.                     |
| To search for a specific module or group            |
| of modules, press the Search button,                |
| enter a term and press the Search button            |
| again. To clear the search results, press           |
| one of the easy access options.                     |

[OCR_TABLE]
Chapter 5

[OCR]
Chapter 5 MentorLearn

Easy Access to courses and modules in the Library

To easily access courses and modules in
Q_DisplayAll ~ the Library, press the Easy Access arrow
on the top right side of the screen and
select an option from the list.
Display All T wee
o search for a specific module or group
of modules, press the Search button,
Customized Courses enter a term and press the Search button
again. To clear the search results, press
one of the easy access options.
Standard Courses

Modules

Open a module or course, review didactic material or perform in a hands-on simulation
case. For more information, see Reviewing didactic materials on page 37 and on
Starting a simulation case or task on page 38.

1. To open a module or course, press its row. The module opens, displaying a

description of the module, its learning objectives, and the educational content of
the module.

surgicalscience Page 36


# Page 46

Chapter 5 
 MentorLearn
 
Page 37
 
 
Figure 5-4: Opening a module 
Reviewing didactic materials 
The URO Mentor modules and courses include didactic materials preceding the hands-
on training. Materials may include simulation course/curricula and real-life procedure 
videos. 
1.  On the MentorLearn menu, press Library. 
MentorLearn displays the list of Simbionix modules and standard courses in the 
simulator library. 
2.  Open a module or course by pressing its row. The module opens, displaying a 
description of the module and all the items in the module. 
3.  Under Didactics, select the didactic material you want to look at and press its row. 


[TABLE]
| F                                                                                         |
| i                                                                                         |
| gure 5-4: Opening a module                                                                |
|:------------------------------------------------------------------------------------------|
| Reviewing didactic materials                                                              |
| The URO Mentor modules and courses include didactic materials preceding the hands-        |
| on training. Materials may include simulation course/curricula and real-life procedure    |
| videos.                                                                                   |
| 1.   On the MentorLearn menu, press Library.                                              |
| MentorLearn displays the list of Simbionix modules and standard courses in the            |
| simulator library.                                                                        |
| 2.   Open a module or course by pressing its row. The module opens, displaying a          |
| description of the module and all the items in the module.                                |
| 3.   Under Didactics, select the didactic material you want to look at and press its row. |

[OCR]
Chapter 5

MentorLearn

TURP Procedure

‘curculum Deseripion
“Tis module includes hands-on raining on clinial cases of transuretva esecton ofthe prostate (TURP) procedure. The cases present realistic scenarios of benign prostatic hyperplasia
(BPH with small 0 large side and median lobes, wit varatons in bleeding sever,
‘Accompanied by comprehensive educational ais, rainaes ean practice hands-on reseetion, vsualzation of anatomical landmarks, management of igaton fd and contol of bleeding
objectives

+ Learn scope manipulation techniques for safe advancement and landmark visualization

+ Safely handle the loop electrode to avoid capsule perforation and cuts into the bladder, urethra, verumontanum, of sphincter.

+ Achieve a clear endoscopic field while using gation uid

+ Identity bleeding sources and accurately coagulate them wth the loop electrode

+ Perfo a final inspection and landmark visualization following completion of the resection

Mote.

New Assignment

Hands-On

Figure 5-4: Opening a module

Reviewing didactic materials

The URO Mentor modules and courses include didactic materials preceding the hands-
on training. Materials may include simulation course/curricula and real-life procedure

videos.

1. On the MentorLearn menu, press Library.

MentorLearn displays the list of Simbionix modules and standard courses in the
simulator library.
2. Open a module or course by pressing its row. The module opens, displaying a
description of the module and all the items in the module.
3. Under Didactics, select the didactic material you want to look at and press its row.

surgicalscience

Page 37


# Page 47

Chapter 5 
 MentorLearn
 
Page 38
 
 
Note: If the didactic material is in a format that is not supported by the simulator, 
you are prompted to save the file to an external location. PDF, mp4 files, and 
graphic files can be opened on the simulator. Microsoft® PowerPoint® and 
Word® files cannot be opened on a simulator. If you are using MentorLearn 
Cloud, the didactic material may be viewed on another computer by 
accessing your MentorLearn Cloud site. 
 
4.  When you have finished, close the material. 
 
Starting a simulation case or task 
To open a case or task: 
1.  From the MentorLearn menu, press one of the following menu options: 
o 
Library - lists all the courses and modules in the URO Mentor library. If 
other simulator libraries are listed, select Library > URO Mentor. 
o 
My Curricula - lists all your assigned courses and modules. 
2.  Press the Expand arrow 
 on the right side of the screen to display more details 
about the module or course. 


[TABLE]
| Note: If the didactic material is in a format that is not supported by the simulator,   |
|:----------------------------------------------------------------------------------------|
| you are prompted to save the file to an external location. PDF, mp4 files, and          |
| graphic files can be opened on the simulator. Microsoft® PowerPoint® and                |
| Word® files cannot be opened on a simulator. If you are using MentorLearn               |
| Cloud, the didactic material may be viewed on another computer by                       |
| accessing your MentorLearn Cloud site.                                                  |

[OCR]
Chapter 5 MentorLearn

Note: If the didactic material is in a format that is not supported by the simulator,
you are prompted to save the file to an external location. PDF, mp4 files, and
graphic files can be opened on the simulator. Microsoft® PowerPoint® and
Word® files cannot be opened on a simulator. If you are using MentorLearn
Cloud, the didactic material may be viewed on another computer by
accessing your MentorLearn Cloud site.

4. When you have finished, close the material.

Starting a simulation case or task

To open a case or task:
1. From the MentorLearn menu, press one of the following menu options:
° Library - lists all the courses and modules in the URO Mentor library. If

other simulator libraries are listed, select Library > URO Mentor.
° My Curricula - lists all your assigned courses and modules.

2. Press the Expand arrow /“! on the right side of the screen to display more details
about the module or course.

surgicalscience Page 38


# Page 48

Chapter 5 
 MentorLearn
 
Page 39
 
 
3.  Open the module or course you want by pressing its row. 
The details include a description and the objectives of the module or course. 
 
4.  Under Hands-on, select the case or task you want to perform, and press its row. 
The task description or patient file opens. 


[TABLE]
| Chapter 5                                                                            | MentorLearn   |
|:-------------------------------------------------------------------------------------|:--------------|
| 3.   Open the module or course you want by pressing its row.                         |               |
| The details include a description and the objectives of the module or course.        |               |
| 4.   Under Hands-on, select the case or task you want to perform, and press its row. |               |
| The task description or patient file opens.                                          |               |
|                                                                                      | Page 39       |

[OCR]
Chapter 5 MentorLearn

e Endourology Basic Tasks “

Description
10 Endaurology basic tasks. Practice exercises in increasing levels of dificult, forthe systematic earning of basic tasks such as bladder and kidney inspection, as well as the full urinary
collecting systern anatomy, and identification of the endourological landmarks. The URO Mentor™ features authentic rigid and flexible cystoscopes and ureteroscopes, provides training
‘opportunities using a variety of actual scopes with real tool hancles and enables actual inseition into working channels

3. Open the module or course you want by pressing its row.
The details include a description and the objectives of the module or course.

URO Mentor

a

> Endourology Basic Tasks

Objectives

+ Practice rigid and flexible eystoscopy skills

+ Learn to identity endourological landmarks

+ Practice guide wire insertion using different guide wires (Bentson 0.038", hydrophilic)

+ Practice advancing the wie in the ureter under fluoroscopy guidance tothe kidney

+ Perform a systematic bladder Inspection, identifying anatomical targets on the bladder
mucosa

+ Practice taking an aceurate biopsy from the bladder membrane region

+ Practice cautetization skills using an electrode

+ Practice rigid and flexible uretetoscopy skis,

+ Practice kidney navigation skills, advancing the flexible ureteroscope to the kidney and
navigating into the calyees

+ Learn use of fluoroscopic imaging and C-arm

+ Practice extraction of bladder stones

+ Lear to select the correct tools and scopes,

Y More,

10 Endourology Basic Tasks
Didactios

FB endourotogy Basie Tasks
Hands-On

Endourology Task 1 - Cystoscopy
Attempts: 6

Endourology Task 2- Cystoscopy
Attempts: 5

acerca reir Ca
BD siers

4. Under Hands-on, select the case or task you want to perform, and press its row.

The task description or patient file opens.

surgicalscience

Page 39


# Page 49

Chapter 5 
 MentorLearn
 
Page 40
 
 
Figure 5-5: Task description 
5.  Press 
. The simulation case begins. 
When you have completed the simulation case, you are returned to MentorLearn, 
and a report of your performance is displayed. 
6.  If at any time you wish to choose another case, module, or course or another 
MentorLearn Library, press that item in the browse sequence hierarchy above the 
middle pane. 
 
 


[TABLE]
| F                                                                               |
| i                                                                               |
| gure 5-5: Task description                                                      |
|:--------------------------------------------------------------------------------|
| 5.   Press                                                                      |
| . The simulation case begins.                                                   |
| When you have completed the simulation case, you are returned to MentorLearn,   |
| and a report of your performance is displayed.                                  |
| 6.                                                                              |
| If at any time you wish to choose another case, module, or course or another    |
| MentorLearn Library, press that item in the browse sequence hierarchy above the |
| middle pane.                                                                    |

[OCR]
Chapter 5

MentorLearn

Endourology Task 2 — Cystoscopy
Task 2

Use rigid cystoscopes. Mark the following urethral landmarks by using the marking
tool:

«Urethral sphincter

Verumontanum

Prostatic urethra: right lateral lobe, left lateral lobe, Median bar

Identify the following vesical landmarks. Mark them with the marking tool:
* Bladder neck

Bladder trigone

ureteral orifices

Anterior bladder wall

Lateral bladder wall

Bladder dome

Enter the correct term in the location box for each snapshot (taken automatically) in
the trainee report

Note:In order to enable you the freedom to use both hands in the basic tasks, in this
module you may take a snapshot by pressing the tool foot pedal

Created in collaboration with:

Prof Stephen Y. Nakada, University of Wisconsin Hospital, Madison, Wisconsin;
Associate Prof Margaret S. Pearle, University of Texas Southwestern, Dallas;
Assistant Prof Jeffrey Cadeddu, University of Texas Southwestern, Dallas;

Figure 5-5: Task description

5. Press [> J The simulation case begins.

When you have completed the simulation case, you are returned to MentorLearn,
and a report of your performance is displayed.

6. If at any time you wish to choose another case, module, or course or another
MentorLearn Library, press that item in the browse sequence hierarchy above the
middle pane.

€

URO Mentor >  EndourologyBasicTasks > Endourology Task 2— Cystoscopy

surgicalscience

Page 40


# Page 50

Chapter 6 
 URO Mentor Display Modes
 
Page 41
 
Chapter 6 URO Mentor Display Modes  
Before beginning a simulation task or case, it is important to know how to use the 
different components of the simulator correctly in order to achieve the best 
performance results. 
Display modes 
The URO Mentor offers two basic display modes for different procedures: 
• 
Cyberscopy Display Mode 
• 
Task and Procedure Display Mode 
Each display mode has a designated screen layout offering relevant displays, 
procedural features, educational aids, and tool options, to aid the user in performing 
different procedures.  
Cyberscopy display mode 
The Cyberscopy display mode is aimed at optimizing the acquisition of basic URO 
endourology skills, such as hand-eye coordination and scope maneuvering. The non-
anatomical environment enables focusing on these core endourologic essential skills. 


[TABLE]
| Chapter 6                                                                              | URO Mentor Display Modes   |
|:---------------------------------------------------------------------------------------|:---------------------------|
| Chapter 6 URO Mentor Display Modes                                                     |                            |
| Before beginning a simulation task or case, it is important to know how to use the     |                            |
| different components of the simulator correctly in order to achieve the best           |                            |
| performance results.                                                                   |                            |
| Display modes                                                                          |                            |
| The URO Mentor offers two basic display modes for different procedures:                |                            |
| Cyberscopy Display Mode                                                                |                            |
| •                                                                                      |                            |
| Task and Procedure Display Mode                                                        |                            |
| •                                                                                      |                            |
| Each display mode has a designated screen layout offering relevant displays,           |                            |
| procedural features, educational aids, and tool options, to aid the user in performing |                            |
| different procedures.                                                                  |                            |
| Cyberscopy display mode                                                                |                            |
| The Cyberscopy display mode is aimed at optimizing the acquisition of basic URO        |                            |
| endourology skills, such as hand-eye coordination and scope maneuvering. The non-      |                            |
| anatomical environment enables focusing on these core endourologic essential skills.   |                            |

[OCR]
Chapter 6 URO Mentor Display Modes

| Chapter 6 URO Mentor Display Modes

Before beginning a simulation task or case, it is important to know how to use the
different components of the simulator correctly in order to achieve the best
performance results.

Display modes

The URO Mentor offers two basic display modes for different procedures:

. Cyberscopy Display Mode
e Task and Procedure Display Mode

Each display mode has a designated screen layout offering relevant displays,
procedural features, educational aids, and tool options, to aid the user in performing
different procedures.

Cyberscopy display mode

The Cyberscopy display mode is aimed at optimizing the acquisition of basic URO
endourology skills, such as hand-eye coordination and scope maneuvering. The non-
anatomical environment enables focusing on these core endourologic essential skills.

surgicalscience Page 41


# Page 51

Chapter 6 
 URO Mentor Display Modes
 
Page 42
 
 
Figure 6-1: Cyberscopy display mode 
The screen is divided into the following parts: 
① Cyberscopy View  
② Fluoroscopic View 
③ Tools Menu 
④ C-Arm Button 
⑤ Snapshot Buttons  
⑥ Finish Button  
General features 
When the case begins, the Scope screen is displayed. Use the arrows beneath the 
picture of the scope to select the scope you wish to use. 
The Cyberscopy View ① shows the scope view as you navigate inside the cyber 
environment. 
In the Cyberscopy tasks, both a flexible scope and an endourology tool are used. 


[TABLE]
| F                                                                                |
| i                                                                                |
| gure 6-1: Cyberscopy display mode                                                |
|:---------------------------------------------------------------------------------|
| The screen is divided into the following parts:                                  |
| ①  Cyberscopy View                                                               |
| ②  Fluoroscopic View                                                             |
| ③  Tools Menu                                                                    |
| ④  C-Arm Button                                                                  |
| ⑤  Snapshot Buttons                                                              |
| ⑥  Finish Button                                                                 |
| General features                                                                 |
| When the case begins, the Scope screen is displayed. Use the arrows beneath the  |
| picture of the scope to select the scope you wish to use.                        |
| The Cyberscopy View ① shows the scope view as you navigate inside the cyber      |
| environment.                                                                     |
| In the Cyberscopy tasks, both a flexible scope and an endourology tool are used. |

[OCR]
Chapter 6 URO Mentor Display Modes

Flexible Cystoscope Balls left: 15 of 16 Total Time: 00:01:01 Flu Time: 00:00:00

@

Figure 6-1: Cyberscopy display mode

The screen is divided into the following parts:
Cyberscopy View

Fluoroscopic View

Tools Menu

C-Arm Button

Snapshot Buttons

Finish Button

ISOS)

General features

When the case begins, the Scope screen is displayed. Use the arrows beneath the
picture of the scope to select the scope you wish to use.

The Cyberscopy View (1) shows the scope view as you navigate inside the cyber
environment.

In the Cyberscopy tasks, both a flexible scope and an endourology tool are used.

surgicalscience Page 42


# Page 52

Chapter 6 
 URO Mentor Display Modes
 
Page 43
 
Select a tool by pressing its icon in the Tools Menu ③. For a detailed explanation, see 
Selecting a tool on page 70. 
To simulate a tool, insert a wire into the working channel of the scope. 
You may use fluoroscopy to help you find the balls. 
 
Figure 6-2: Task and procedure display mode 


[TABLE]
| Chapter 6                                                                | URO Mentor Display Modes                                                                |
|:-------------------------------------------------------------------------|:----------------------------------------------------------------------------------------|
|                                                                          | Select a tool by pressing its icon in the Tools Menu ③. For a detailed explanation, see |
| Selecting a tool on page 70.                                             |                                                                                         |
| To simulate a tool, insert a wire into the working channel of the scope. |                                                                                         |
| You may use fluoroscopy to help you find the balls.                      |                                                                                         |
| F                                                                        |                                                                                         |
| i                                                                        |                                                                                         |
| gure 6-2: Task and procedure display mode                                |                                                                                         |
|                                                                          | Page 43                                                                                 |

[OCR]
Chapter 6 URO Mentor Display Modes

Select a tool by pressing its icon in the Tools Menu ©. For a detailed explanation, see
Selecting a tool on page 70.

To simulate a tool, insert a wire into the working channel of the scope.

You may use fluoroscopy to help you find the balls.

Flexible Ureteroscope Balls left: 14 of 16 Total Time: 00:02:10 Fluoroscopy Time: 00:00:00

Figure 6-2: Task and procedure display mode

surgicalscience Page 43


# Page 53

Chapter 6 
 URO Mentor Display Modes
 
Page 44
 
Screen layout 
 
Figure 6-3: Task and Procedure display mode 
The screen is divided into the following parts: 
① Endoscopic View  
② Fluoroscopic View 
③ C-Arm Button 
④ Snapshot Buttons 
⑤ Tools Menu  
⑥ Trainee Report 
⑦ Patient File 
⑧ Camera Mode  
⑨ Irrigation Pressure 
⑩ Flush Button 
⑪ Drain Button 
⑫ Syringe Button 
⑬ Scope and Tool Information button 
⑭ Finish Button 


[TABLE]
| ⑥  Trainee Report                 |
|:----------------------------------|
| ⑦  Patient File                   |
| ⑧  Camera Mode                    |
| ⑨  Irrigation Pressure            |
| Flush Button                      |
| Drain Button                      |
| ⑩                                 |
| Syringe Button                    |
| ⑪                                 |
| Scope and Tool Information button |
| ⑫                                 |
| Finish Button                     |
| ⑬                                 |

[OCR]
Chapter 6 URO Mentor Display Modes

Screen layout

Flexible Cystoscope Camera: 0& (3) Total Time:

a. ci— ie iG |) © mmHg

®® ® © ©

Figure 6-3: Task and Procedure display mode

The screen is divided into the following parts:
@ Endoscopic View
Fluoroscopic View
C-Arm Button
Snapshot Buttons
Tools Menu
Trainee Report
Patient File
Camera Mode
Irrigation Pressure
Flush Button
Drain Button
Syringe Button
Scope and Tool Information button
Finish Button

SITIOS SOOOS,

surgicalscience

Page 44


# Page 54

Chapter 6 
 URO Mentor Display Modes
 
Page 45
 
Selecting a scope 
Scope selection is performed before beginning the actual procedure or task or when a 
scope is extracted and is replaced by a different scope. 
To select a scope: 
1.  Use the arrows under the scope to switch between scopes. 
 
Figure 6-4: Selecting a scope 
2.  When the desired scope is displayed on the screen, physically insert the scope into 
the URO Mentor. 
Note: The name of the scope currently in use is displayed above the Endoscopic 
View. 


[TABLE]
| Chapter 6                                                     | URO Mentor Display Modes                                                             |
|:--------------------------------------------------------------|:-------------------------------------------------------------------------------------|
| Selecting a scope                                             |                                                                                      |
|                                                               | Scope selection is performed before beginning the actual procedure or task or when a |
| scope is extracted and is replaced by a different scope.      |                                                                                      |
| To select a scope:                                            |                                                                                      |
| 1.   Use the arrows under the scope to switch between scopes. |                                                                                      |

[OCR]
Chapter 6 URO Mentor Display Modes

Selecting a scope

Scope selection is performed before beginning the actual procedure or task or when a
scope is extracted and is replaced by a different scope.

To select a scope:
1. Use the arrows under the scope to switch between scopes.

Rigid Cystoscope Camera: 08 Total Time: 00:00:00 Fi copy Time: 00:00:00 | MAS

6)

a wi65— iC “Flush )) — mmig

Figure 6-4: Selecting a scope

2. When the desired scope is displayed on the screen, physically insert the scope into
the URO Mentor.

Note: The name of the scope currently in use is displayed above the Endoscopic
View.

surgicalscience Page 45


# Page 55

Chapter 6 
 URO Mentor Display Modes
 
Page 46
 
Endoscopic View  
The Endoscopic View ① shows the real-time endoscope view during the procedure 
you are performing, showing a realistic display of the anatomy as moved through 
bladder and ureter. 
 
Figure 6-5: Endoscopic view 
Fluoroscopic View 
The Fluoroscopic View ② displays the fluoroscopic image of the procedure.  
To display the Fluoroscopic View: 
• 
Press the X-Ray button under the C-Arm or press the X-Ray pedal.  


[TABLE]
| Chapter 6                                                                       |
|  URO Mentor Display Modes                                                       |
|:--------------------------------------------------------------------------------|
| Endoscopic View                                                                 |
| The Endoscopic View ① shows the real-time endoscope view during the procedure   |
| you are performing, showing a realistic display of the anatomy as moved through |
| bladder and ureter.                                                             |
| F                                                                               |
| i                                                                               |
| gure 6-5: Endoscopic view                                                       |
| Fluoroscopic View                                                               |
| The Fluoroscopic View ② displays the fluoroscopic image of the procedure.       |
| To display the Fluoroscopic View:                                               |
| Press the X-Ray button under the C-Arm or press the X-Ray pedal.                |
| •                                                                               |
| Page 46                                                                         |

[OCR]
Chapter 6 URO Mentor Display Modes

Endoscopic View

The Endoscopic View @ shows the real-time endoscope view during the procedure
you are performing, showing a realistic display of the anatomy as moved through
bladder and ureter.

Figure 6-5: Endoscopic view

Fluoroscopic View

The Fluoroscopic View @ displays the fluoroscopic image of the procedure.

To display the Fluoroscopic View:
. Press the X-Ray button under the C-Arm or press the X-Ray pedal.

surgicalscience Page 46


# Page 56

Chapter 6 
 URO Mentor Display Modes
 
Page 47
 
 
Figure 6-6: Fluoroscopic view 
Working with fluoroscopy 
You can adjust the Fluoro image by: 
• 
Adjusting the C-Arm position. 
• 
Adjusting the image itself. 
Adjusting the C-Arm position 
The patient table and C-Arm positions can be adjusted to achieve complete control of 
the fluoroscopic view.  
Any change in the C-Arm and table positions is reflected in the fluoroscopic view. 
To adjust the C-Arm position: 
1.  Press the C-Arm 
 button on the lower right side of the screen.  


[TABLE]
| Chapter 6                                                                            |
|  URO Mentor Display Modes                                                            |
|:-------------------------------------------------------------------------------------|
| F                                                                                    |
| i                                                                                    |
| gure 6-6: Fluoroscopic view                                                          |
| Working with fluoroscopy                                                             |
| You can adjust the Fluoro image by:                                                  |
| Adjusting the C-Arm position.                                                        |
| •                                                                                    |
| Adjusting the image itself.                                                          |
| •                                                                                    |
| Adjusting the C-Arm position                                                         |
| The patient table and C-Arm positions can be adjusted to achieve complete control of |
| the fluoroscopic view.                                                               |
| Any change in the C-Arm and table positions is reflected in the fluoroscopic view.   |
| To adjust the C-Arm position:                                                        |
| 1.   Press the C-Arm                                                                 |
|  button on the lower right side of the screen.                                       |
| Page 47                                                                              |

[OCR]
Chapter 6 URO Mentor Display Modes

Figure 6-6: Fluoroscopic view

Working with fluoroscopy

You can adjust the Fluoro image by:

. Adjusting the C-Arm position.
. Adjusting the image itself.

Adjusting the C-Arm position

The patient table and C-Arm positions can be adjusted to achieve complete control of
the fluoroscopic view.

Any change in the C-Arm and table positions is reflected in the fluoroscopic view.

To adjust the C-Arm position:

1. Press the C-Arm button on the lower right side of the screen.

surgicalscience Page 47


# Page 57

Chapter 6 
 URO Mentor Display Modes
 
Page 48
 
The C-Arm controls are displayed on the left side of the screen and the 
fluoroscopic image on the right side.  
 
Figure 6-7: C-Arm controls for positioning the C-Arm 
2.  Use the C-Arm control arrows to move the C-Arm to obtain the desired 
fluoroscopic image. 
a. Use the arrows to move the C-Arm cranially or caudally. 
b. Use the arrows to move the patient table up and down, right and left. 
c. Use the arrows to move the C-Arm orbitally (left to right and right to left).  
To reset the C-Arm position:  
• 
Press the Reset 
 button. The C-Arm will return to its initial position. 
To return to Endoscopic View: 
• 
Press Close under the C-Arm button 
 on the lower right side of the screen. 


[TABLE]
|                                                                                   | F                                                       |
|                                                                                   | i                                                       |
|                                                                                   | gure 6-7: C-Arm controls for positioning the C-Arm      |
|:----------------------------------------------------------------------------------|:--------------------------------------------------------|
| 2.   Use the C-Arm control arrows to move the C-Arm to obtain the desired         |                                                         |
|                                                                                   | fluoroscopic image.                                     |
| a.  Use the arrows to move the C-Arm cranially or caudally.                       |                                                         |
| b.  Use the arrows to move the patient table up and down, right and left.         |                                                         |
| c.  Use the arrows to move the C-Arm orbitally (left to right and right to left). |                                                         |
| To reset the C-Arm position:                                                      |                                                         |
| •                                                                                 | Press the Reset                                         |
|                                                                                   |  button. The C-Arm will return to its initial position. |
| To return to Endoscopic View:                                                     |                                                         |

[OCR]
Chapter 6 URO Mentor Display Modes

The C-Arm controls are displayed on the left side of the screen and the
fluoroscopic image on the right side.
Flexible Cystoscope Camera: 0& Total Time: 00:00:25 Fluo Time: 00:00:00 | @A3

Image
Craniocaudad: 0 Orbital: 0 all

q

|= mmhg (4

Figure 6-7: C-Arm controls for positioning the C-Arm

2. Use the C-Arm control arrows to move the C-Arm to obtain the desired
fluoroscopic image.

a. Use the arrows to move the C-Arm cranially or caudally.
b. Use the arrows to move the patient table up and down, right and left.
c. Use the arrows to move the C-Arm orbitally (left to right and right to left).

To reset the C-Arm position:

. Press the Reset | Reset button. The C-Arm will return to its initial position.
To return to Endoscopic View:

. Press Close under the C-Arm button on the lower right side of the screen.

surgicalscience Page 48


# Page 58

Chapter 6 
 URO Mentor Display Modes
 
Page 49
 
Adjusting the fluoro image  
The fluoroscopic view can be adjusted to improve visibility by changing the zoom 
level, background contrast intensity, and other parameters. These actions are 
performed using buttons on the Image Control panel. 
1.  Press the Image Control 
 button to open the Image Control panel. 
 
Figure 6-8: C-Arm Image controls 
2.  Press a button to adjust the fluoroscopic image. 
 Rotates the image 
 Flips the image horizontally 
 Flips the image vertically 
 Zooms in to enlarge the image 
 Zooms out to reduce the image size 


[TABLE]
| Chapter 6                                                                        | URO Mentor Display Modes                |
|:---------------------------------------------------------------------------------|:----------------------------------------|
| Adjusting the fluoro image                                                       |                                         |
| The fluoroscopic view can be adjusted to improve visibility by changing the zoom |                                         |
| level, background contrast intensity, and other parameters. These actions are    |                                         |
| performed using buttons on the Image Control panel.                              |                                         |
| 1.   Press the Image Control                                                     | button to open the Image Control panel. |

[OCR]
Chapter 6 URO Mentor Display Modes

Adjusting the fluoro image

The fluoroscopic view can be adjusted to improve visibility by changing the zoom
level, background contrast intensity, and other parameters. These actions are
performed using buttons on the Image Control panel.

1. Press the Image Control a button to open the Image Control panel.

Flexible Cystoscope Camera: L)& Total Time: 00:01:13 Fi

Craniocaudad: 0 Orbital: 0

Figure 6-8: C-Arm Image controls

2. Press a button to adjust the fluoroscopic image.

Rotates the image

Flips the image horizontally

Flips the image vertically

Zooms in to enlarge the image

elle lal

Zooms out to reduce the image size

surgicalscience Page 49


# Page 59

Chapter 6 
 URO Mentor Display Modes
 
Page 50
 
 Displays the negative of the X-ray image 
 Returns the image to its original settings 
 Closes the Image Control panel 
Injecting contrast 
You can simulate the injection of a contrast agent ⑫ on the fluoroscopic image. 
To inject contrast agent: 
1.  Press the Syringe 
 button under the Fluoroscopic view. 
The contrast agent is injected via the scope’s tip. 
2.  Press the X-Ray foot pedal or the X-ray 
 button. 
The contrast agent is displayed on the fluoroscopic image. 
 
Figure 6-9: Contrast agent displayed on fluoroscopic image demonstrating calyces 


[TABLE]
| Closes the Image Control panel                      |
|:----------------------------------------------------|
| Injecting contrast                                  |
| You can simulate the injection of a contrast agent  |
|  on the fluoroscopic image.                         |
| To inject contrast agent:                           |
| ⑫                                                   |
| 1.   Press the Syringe                              |
|  button under the Fluoroscopic view.                |
| The contrast agent is injected via the scope’s tip. |
| 2.   Press the X-Ray foot pedal or the X-ray        |
|  button.                                            |

[OCR]
Chapter 6 URO Mentor Display Modes

[all Displays the negative of the X-ray image
fl Returns the image to its original settings

Closes the Image Control panel

Injecting contrast

You can simulate the injection of a contrast agent @) on the fluoroscopic image.

To inject contrast agent:

1. Press the Syringe EF button under the Fluoroscopic view.

The contrast agent is injected via the scope’s tip.

2. Press the X-Ray foot pedal or the X-ray | X-ay | button.
The contrast agent is displayed on the fluoroscopic image.

Flexible Ureteroscope Ca Total Time: 00:02:52 y Time: 00:00:00

_ f= mmlg

Figure 6-9: Contrast agent displayed on fluoroscopic image demonstrating calyces

surgicalscience Page 50


# Page 60

Chapter 6 
 URO Mentor Display Modes
 
Page 51
 
Note: When a balloon is inserted inside a ureter, the contrast agent is injected via the balloon 
wire and not via the scope’s tip. 
Educational aids 
Virtual Instructor 
The Virtual Instructor aid lights up a warning symbol each time performance is 
compromised, might lead to an unsafe situation, or might result in a clinical 
complication. The Virtual Instructor provides an alert explaining the problem and 
offering a solution. When the performance is corrected, the warning symbol dims and 
the instructions disappear from the screen. 
The Virtual Instructor also displays comments that are not alerts, aiding the training 
process. 
 
Figure 6-10: Virtual Instructor 


[TABLE]
| Chapter 6                                                                                         | URO Mentor Display Modes                                                            |
|:--------------------------------------------------------------------------------------------------|:------------------------------------------------------------------------------------|
| Note:  When a balloon is inserted inside a ureter, the contrast agent is injected via the balloon |                                                                                     |
| wire and not via the scope’s tip.                                                                 |                                                                                     |
| Educational aids                                                                                  |                                                                                     |
| Virtual Instructor                                                                                |                                                                                     |
| The Virtual Instructor aid lights up a warning symbol each time performance is                    |                                                                                     |
| compromised, might lead to an unsafe situation, or might result in a clinical                     |                                                                                     |
| complication. The Virtual Instructor provides an alert explaining the problem and                 |                                                                                     |
|                                                                                                   | offering a solution. When the performance is corrected, the warning symbol dims and |
| the instructions disappear from the screen.                                                       |                                                                                     |
| The Virtual Instructor also displays comments that are not alerts, aiding the training            |                                                                                     |
| process.                                                                                          |                                                                                     |

[OCR_TABLE]
SGV! Vv

[OCR]
Chapter 6 URO Mentor Display Modes

Note: When a balloon is inserted inside a ureter, the contrast agent is injected via the balloon
wire and not via the scope’s tip.

Educational aids

Virtual Instructor

The Virtual Instructor aid lights up a warning symbol each time performance is
compromised, might lead to an unsafe situation, or might result in a clinical
complication. The Virtual Instructor provides an alert explaining the problem and
offering a solution. When the performance is corrected, the warning symbol dims and
the instructions disappear from the screen.

The Virtual Instructor also displays comments that are not alerts, aiding the training
process.

Flexible Ureteroscope Camera: D&

lie eS Se Sac

Laser probe should be placed
3 mm from the tip of the scope

Figure 6-10: Virtual Instructor

surgicalscience Page 51


# Page 61

Chapter 6 
 URO Mentor Display Modes
 
Page 52
 
Online task instructions 
You can view step-by-step instructions for the specific task you are working on at the 
moment.  
Note: This feature is only available for the Basic Tasks module. 
To display online instructions: 
1.  Press the Tasks 
 button located in the top right corner of the screen.  
A small window opens containing the task instructions. 
 
Figure 6-11: Online task instructions 
2.  Press Close to close the window. 
Camera mode  
In Camera mode ⑧, the camera behaves as if it is “locked” with the scope and always 
moves with the scope. This provides a “true view”. The V notch will always be located 
at the top of the image of the screen. 


[TABLE]
| Chapter 6                                                         | URO Mentor Display Modes                                                               |
|:------------------------------------------------------------------|:---------------------------------------------------------------------------------------|
| Online task instructions                                          |                                                                                        |
|                                                                   | You can view step-by-step instructions for the specific task you are working on at the |
| moment.                                                           |                                                                                        |
| Note:  This feature is only available for the Basic Tasks module. |                                                                                        |
| To display online instructions:                                   |                                                                                        |
| 1.   Press the Tasks                                              | button located in the top right corner of the screen.                                  |

[OCR]
Chapter 6 URO Mentor Display Modes

Online task instructions

You can view step-by-step instructions for the specific task you are working on at the
moment.

Note: This feature is only available for the Basic Tasks module.

To display online instructions:

1. Press the Tasks MM] button located in the top right corner of the screen.

A small window opens containing the task instructions.

Rigid Cystoscope Camera: 0&

‘© Mark each of the flowers
‘on the bladder mucous
membrane

@ Take a biopsy from the
‘suspicious bladder
membrane region

© Cauterize the biopsy
site with an electrode

4)

¥

|= mig!

Figure 6-11: Online task instructions

2. Press Close to close the window.

Camera mode

In Camera mode @), the camera behaves as if it is “locked” with the scope and always
moves with the scope. This provides a “true view”. The V notch will always be located
at the top of the image of the screen.

surgicalscience Page 52


# Page 62

Chapter 6 
 URO Mentor Display Modes
 
Page 53
 
To switch to camera mode: 
• 
Press to select the Camera check box above the Endoscopic View. 
 
Figure 6-12: Camera Mode selected 
To exit camera mode: 
• 
Press to clear the Camera check box.  
The camera is in the unlocked mode. The camera will remain upright even though 
the scope moves and the V notch on the scope will move when you deflect the 
scope. 
Irrigating and draining 
If the simulation view becomes opaque due to blood, cut tissue or excessive fluids, 
you can clear the view like in a real-life procedure. 
To drain fluids: 
• 
When using either the flexible or rigid scope, press the Drain 
 button 
while removing the scope.  
• 
When using the flexible scope, remove the scope and then reinsert it. 


[TABLE]
| Chapter 6                                                                           |
|  URO Mentor Display Modes                                                           |
|:------------------------------------------------------------------------------------|
| To switch to camera mode:                                                           |
| Press to select the Camera check box above the Endoscopic View.                     |
| •                                                                                   |
| F                                                                                   |
| i                                                                                   |
| gure 6-12: Camera Mode selected                                                     |
| To exit camera mode:                                                                |
| Press to clear the Camera check box.                                                |
| •                                                                                   |
| The camera is in the unlocked mode. The camera will remain upright even though      |
| the scope moves and the V notch on the scope will move when you deflect the         |
| scope.                                                                              |
| Irrigating and draining                                                             |
| If the simulation view becomes opaque due to blood, cut tissue or excessive fluids, |
| you can clear the view like in a real-life procedure.                               |
| To drain fluids:                                                                    |
| When using either the flexible or rigid scope, press the Drain                      |
|  button                                                                             |
| •                                                                                   |
| while removing the scope.                                                           |
| When using the flexible scope, remove the scope and then reinsert it.               |
| •                                                                                   |
| Page 53                                                                             |

[OCR]
Chapter 6 URO Mentor Display Modes

To switch to camera mode:
. Press to select the Camera check box above the Endoscopic View.

Flexible Ureteroscope |Camera: H& Total Time: 00:04:57 Fluoroscopy Time: 00:00:01

a

= mmig

Figure 6-12: Camera Mode selected
To exit camera mode:
e Press to clear the Camera check box.

The camera is in the unlocked mode. The camera will remain upright even though
the scope moves and the V notch on the scope will move when you deflect the
scope.

Irrigating and draining

If the simulation view becomes opaque due to blood, cut tissue or excessive fluids,
you can clear the view like in a real-life procedure.

To drain fluids:
. When using either the flexible or rigid scope, press the Drain (rain) button

while removing the scope.
. When using the flexible scope, remove the scope and then reinsert it.

surgicalscience Page 53


# Page 63

Chapter 6 
 URO Mentor Display Modes
 
Page 54
 
 
 
Figure 6-13: Endoscopic View before and after draining or flushing 
To flush from scope tip: 
• 
Press once the Flush 
 button to flush 20cc of fluid. 
To increase or decrease the irrigation pressure: 
• 
Press – or + on either side of the mmHg button. The increase or decrease is 
reflected on the blue slider as well as in the amount of pressure used for 
flushing/irrigating. 
 
Taking snapshots 
You can take a snapshot ④ of either the fluoroscopic image or the endoscopic image 
at any time. The snapshots are saved in the Trainee Report. 
To take a snapshot: 
• 
Press the Snapshot 
 button beside the image you wish to capture. 


[TABLE]
| Chapter 6                                        |                                                                                    | URO Mentor Display Modes   |
|:-------------------------------------------------|:-----------------------------------------------------------------------------------|:---------------------------|
|                                                  | F                                                                                  |                            |
|                                                  | i                                                                                  |                            |
|                                                  | gure 6-13: Endoscopic View before and after draining or flushing                   |                            |
| To flush from scope tip:                         |                                                                                    |                            |
| •                                                | Press once the Flush                                                               |                            |
|                                                  |  button to flush 20cc of fluid.                                                    |                            |
| To increase or decrease the irrigation pressure: |                                                                                    |                            |
| •                                                | Press – or + on either side of the mmHg button. The increase or decrease is        |                            |
|                                                  | reflected on the blue slider as well as in the amount of pressure used for         |                            |
|                                                  | flushing/irrigating.                                                               |                            |
| Taking snapshots                                 |                                                                                    |                            |
|                                                  | You can take a snapshot ④ of either the fluoroscopic image or the endoscopic image |                            |
|                                                  | at any time. The snapshots are saved in the Trainee Report.                        |                            |
| To take a snapshot:                              |                                                                                    |                            |
| •                                                | Press the Snapshot                                                                 |                            |
|                                                  |  button beside the image you wish to capture.                                      |                            |
|                                                  |                                                                                    | Page 54                    |

[OCR]
Chapter 6 URO Mentor Display Modes

Figure 6-13: Endoscopic View before and after draining or flushing

To flush from scope tip:

. Press once the Flush C Flush} button to flush 20cc of fluid.

To increase or decrease the irrigation pressure:

. Press - or + on either side of the mmHg button. The increase or decrease is
reflected on the blue slider as well as in the amount of pressure used for
flushing/irrigating.

Taking snapshots

You can take a snapshot (@) of either the fluoroscopic image or the endoscopic image
at any time. The snapshots are saved in the Trainee Report.

To take a snapshot:

. Press the Snapshot button beside the image you wish to capture.

surgicalscience Page 54


# Page 64

Chapter 6 
 URO Mentor Display Modes
 
Page 55
 
Analyzing and documenting clinical findings 
The URO Mentor allows you to browse through the captured images of pathological 
conditions you located and identified in the Basic Tasks and Procedure cases. You can 
then analyze these images in order to make a diagnosis and document this information 
in the Trainee Report ⑥.  
To document pathological conditions: 
1. Press the Trainee Report 
 button. 
The Trainee Report is displayed. 
  
Figure 6-14: Trainee Report 
2.  Use the Next and Back arrow buttons to browse between captured images.  
3.  You can delete a captured image by pressing the Delete 
 button. 


[TABLE]
| Chapter 6                            |                                                                                       | URO Mentor Display Modes   |
|:-------------------------------------|:--------------------------------------------------------------------------------------|:---------------------------|
|                                      | Analyzing and documenting clinical findings                                           |                            |
|                                      | The URO Mentor allows you to browse through the captured images of pathological       |                            |
|                                      | conditions you located and identified in the Basic Tasks and Procedure cases. You can |                            |
|                                      | then analyze these images in order to make a diagnosis and document this information  |                            |
| in the Trainee Report ⑥.             |                                                                                       |                            |
| To document pathological conditions: |                                                                                       |                            |
| 1.                                   | button.                                                                               |                            |
| Press the Trainee Report             |                                                                                       |                            |

[OCR]
Chapter 6 URO Mentor Display Modes

Analyzing and documenting clinical findings

The URO Mentor allows you to browse through the captured images of pathological
conditions you located and identified in the Basic Tasks and Procedure cases. You can
then analyze these images in order to make a diagnosis and document this information
in the Trainee Report ©).

To document pathological conditions:

1. Press the Trainee Report El button.

The Trainee Report is displayed.

Case 5 Trainee Report

< wr 8

Right Ureter

Figure 6-14: Trainee Report

2. Use the Next and Back arrow buttons to browse between captured images.
3. You can delete a captured image by pressing the Delete %&! button.

surgicalscience Page 55


# Page 65

Chapter 6 
 URO Mentor Display Modes
 
Page 56
 
4.  When you have entered a diagnosis for all the captured images, press Close to 
return to the case. 
Viewing patient file 
Press the Patient File 
 button ⑦ to view the case’s patient file. The patient file 
includes the patient histories, biological test results, and imaging results. You can open 
the file without ending the current session. Press Close to resume the procedure. 
 


[TABLE]
| Chapter 6                                                                          | URO Mentor Display Modes                                                                   |
|:-----------------------------------------------------------------------------------|:-------------------------------------------------------------------------------------------|
| 4.   When you have entered a diagnosis for all the captured images, press Close to |                                                                                            |
| return to the case.                                                                |                                                                                            |
| Viewing patient file                                                               |                                                                                            |
| Press the Patient File                                                             | button ⑦ to view the case’s patient file. The patient file                                 |
|                                                                                    | includes the patient histories, biological test results, and imaging results. You can open |
| the file without ending the current session. Press Close to resume the procedure.  |                                                                                            |

[OCR]
Chapter 6 URO Mentor Display Modes

4. When you have entered a diagnosis for all the captured images, press Close to
return to the case.

Viewing patient file

Press the Patient File button (7) to view the case’s patient file. The patient file
includes the patient histories, biological test results, and imaging results. You can open
the file without ending the current session. Press Close to resume the procedure.

Stone Manipulation Case 5 >)

PATIENT HISTORY LAB TESTS IMAGING
Case 5

‘A 54 year old male suffering from chronic right flank pain, Physical examination is
unremarkable.The patient has no fever.

n collaboration with Prof E. Lechevallier, Department of Urology, Salvator
Marseille, France.

surgicalscience Page 56


# Page 66

Chapter 6 
 URO Mentor Display Modes
 
Page 57
 
 
 
Figure 6-15: URO Mentor Patient File 


[TABLE]
| Chapter 6                          | URO Mentor Display Modes   |
|:-----------------------------------|:---------------------------|
| F                                  |                            |
| i                                  |                            |
| gure 6-15: URO Mentor Patient File |                            |
|                                    | Page 57                    |

[OCR]
Chapter 6 URO Mentor Display Modes
Stone Manipulation Case 5 e — —
Figure 6-15: URO Mentor Patient File
surgicalscience Page 57


# Page 67

Chapter 7 
 TURP Display Modes
 
Page 58
 
Chapter 7 TURP Display Modes 
The TURP modules consists of two screen displays, each on different monitors: 
• 
Basic Skills display mode  
• 
Clinical Procedure display mode  
Basic Skills display mode 
The Basic Skills display mode is composed of essential endourology skills in a non-
anatomic setting, available in two levels of difficulty. The game provides practice in 
handling scopes and tools, controlling and positioning the endoscopic camera, 
achieving depth perception and orientation and gaining navigational confidence and 
skills.  
 
Figure 7-1: Basic Skills display mode 
The Primary View shows the scope view as you navigate inside the cyber environment. 


[TABLE]
| Chapter 7                                                                              | TURP Display Modes                                                                  |
|:---------------------------------------------------------------------------------------|:------------------------------------------------------------------------------------|
| Chapter 7 TURP Display Modes                                                           |                                                                                     |
| The TURP modules consists of two screen displays, each on different monitors:          |                                                                                     |
| Basic Skills display mode                                                              |                                                                                     |
| •                                                                                      |                                                                                     |
| Clinical Procedure display mode                                                        |                                                                                     |
| •                                                                                      |                                                                                     |
| Basic Skills display mode                                                              |                                                                                     |
| The Basic Skills display mode is composed of essential endourology skills in a non-    |                                                                                     |
| anatomic setting, available in two levels of difficulty. The game provides practice in |                                                                                     |
| handling scopes and tools, controlling and positioning the endoscopic camera,          |                                                                                     |
| achieving depth perception and orientation and gaining navigational confidence and     |                                                                                     |
| skills.                                                                                |                                                                                     |
| F                                                                                      |                                                                                     |
| i                                                                                      |                                                                                     |
| gure 7-1: Basic Skills display mode                                                    |                                                                                     |
|                                                                                        | The Primary View shows the scope view as you navigate inside the cyber environment. |
|                                                                                        | Page 58                                                                             |

[OCR]
Chapter 7 TURP Display Modes

| Chapter 7 TURP Display Modes

The TURP modules consists of two screen displays, each on different monitors:

e Basic Skills display mode
e Clinical Procedure display mode

Basic Skills display mode

The Basic Skills display mode is composed of essential endourology skills in a non-
anatomic setting, available in two levels of difficulty. The game provides practice in
handling scopes and tools, controlling and positioning the endoscopic camera,
achieving depth perception and orientation and gaining navigational confidence and
skills.

Figure 7-1: Basic Skills display mode

The Primary View shows the scope view as you navigate inside the cyber environment.

surgicalscience Page 58


# Page 68

Chapter 7 
 TURP Display Modes
 
Page 59
 
On  the left pane: 
• 
Elapsed time – displays the time that has elapsed since starting the case. 
• 
The circles are filled in green upon the completion of a task component. On 
completion of all the components of the task, press X in the upper right corner of 
the screen. You can select the task at a different level of difficulty or repeat the 
task at the same level. 
General buttons 
Press 
 to review the task instructions. 
Press 
 to mute or unmute the volume. 
Clinical Procedure display mode 
Clinical Procedure display mode shows the real-time simulated resectoscope view 
during the procedure you are performing, showing a realistic display of the anatomy as 
moved through the urethra, to visualize the verumontanum, two side lobes of the 
prostate, the bladder and the ureteral orifices. The simulated video image changes 
responsively when you move or rotate the resectoscope. When the resectoscope has 
been inserted sufficiently, the simulation will start at the urethra.  
 
Figure 7-2: Clinical Procedure display mode 


[TABLE]
| Chapter 7                                                                            |
|  TURP Display Modes                                                                  |
|:-------------------------------------------------------------------------------------|
| On  the left pane:                                                                   |
| Elapsed time – displays the time that has elapsed since starting the case.           |
| •                                                                                    |
| The circles are filled in green upon the completion of a task component. On          |
| •                                                                                    |
| completion of all the components of the task, press X in the upper right corner of   |
| the screen. You can select the task at a different level of difficulty or repeat the |
| task at the same level.                                                              |

[OCR_TABLE]
On the lef

[OCR]
Chapter 7 TURP Display Modes

On the left pane:

e Elapsed time - displays the time that has elapsed since starting the case.

e The circles are filled in green upon the completion of a task component. On
completion of all the components of the task, press X in the upper right corner of
the screen. You can select the task at a different level of difficulty or repeat the
task at the same level.

General buttons

Press = to review the task instructions.

)
Press to mute or unmute the volume.

Clinical Procedure display mode

Clinical Procedure display mode shows the real-time simulated resectoscope view
during the procedure you are performing, showing a realistic display of the anatomy as
moved through the urethra, to visualize the verumontanum, two side lobes of the
prostate, the bladder and the ureteral orifices. The simulated video image changes
responsively when you move or rotate the resectoscope. When the resectoscope has
been inserted sufficiently, the simulation will start at the urethra.

Figure 7-2: Clinical Procedure display mode

surgicalscience Page 59


# Page 69

Chapter 7 
 TURP Display Modes
 
Page 60
 
1 
Internal View 
2 
Elapsed Time Indicator 
3 
Camera Angle Options 
4 
Tool Menu Options 
5 
Simulation Aids 
6 
External View 
7 
Screen Layout Options 
8 
External View Options 
9 
Virtual Instructor 
10 
General Buttons 
Screen display layout 
The screen display ⑦ is by default split into 2 panes: External View and Internal View. 
You can use the different layout options to display one view or both views 
simultaneously.  
 
Internal View – full screen of internal view  
 
Normal View (default) – split screen of external view 
and internal view 
 
External View – full screen of external view  
When displayed side by side, by default, the movement of the anatomy and the 
selected tools are synchronized.  
Press 
 - to unlock the views so that the movement of the anatomy and tools are 
not synchronized. 


[TABLE]
|   Chapter 7 |                        |
|------------:|:-----------------------|
|           1 | Internal View          |
|           2 | Elapsed Time Indicator |
|           3 | Camera Angle Options   |
|           4 | Tool Menu Options      |
|           5 | Simulation Aids        |
|           6 | External View          |
|           7 | Screen Layout Options  |
|           8 | External View Options  |
|           9 | Virtual Instructor     |
|          10 | General Buttons        |

[OCR]
Chapter 7 TURP Display Modes

=

Internal View

Elapsed Time Indicator
Camera Angle Options
Tool Menu Options
Simulation Aids
External View

Screen Layout Options

External View Options

oon Oo KR WD

Virtual Instructor

=
fo}

General Buttons

Screen display layout

The screen display () is by default split into 2 panes: External View and Internal View.
You can use the different layout options to display one view or both views
simultaneously.

| Internal View - full screen of internal view

Normal View (default) — split screen of external view
and internal view

iJ External View - full screen of external view

When displayed side by side, by default, the movement of the anatomy and the
selected tools are synchronized.

q
Press - to unlock the views so that the movement of the anatomy and tools are
not synchronized.

surgicalscience Page 60


# Page 70

Chapter 7 
 TURP Display Modes
 
Page 61
 
Internal View 
The Internal View ① shows the real-time simulated view of the resectoscope view 
during the exercise or procedure you are performing, showing a realistic display of the 
anatomy. The simulated video image changes responsively when you move or rotate 
the resectoscope. 
Elapsed Time indicator  
Elapsed Time indicator ➁ shows you how much time has elapsed since the beginning 
of the procedure (from the first time the camera is inserted into the portal). 
 
Figure 7-3: Internal View  
Camera angle options ③ 
TURP Mentor gives you the option to train using the degree of angled optics used in 
the OR. Angled optics  make it easier to visualize corners, tubes, and the upper and 
lower part of the urethra, bladder and prostate. 
The virtual resectoscopic optical system includes several available angles: 0°, 12°, and 
30°. 


[TABLE]
| Chapter 7                                                                       | TURP Display Modes                                                                      |
|:--------------------------------------------------------------------------------|:----------------------------------------------------------------------------------------|
| Internal View                                                                   |                                                                                         |
| The Internal View ① shows the real-time simulated view of the resectoscope view |                                                                                         |
|                                                                                 | during the exercise or procedure you are performing, showing a realistic display of the |
| anatomy. The simulated video image changes responsively when you move or rotate |                                                                                         |
| the resectoscope.                                                               |                                                                                         |
| Elapsed Time indicator                                                          |                                                                                         |
|                                                                                 | Elapsed Time indicator ② shows you how much time has elapsed since the beginning        |
| of the procedure (from the first time the camera is inserted into the portal).  |                                                                                         |

[OCR]
Chapter 7 TURP Display Modes

Internal View

The Internal View (1) shows the real-time simulated view of the resectoscope view
during the exercise or procedure you are performing, showing a realistic display of the
anatomy. The simulated video image changes responsively when you move or rotate
the resectoscope.

Elapsed Time indicator

Elapsed Time indicator (2) shows you how much time has elapsed since the beginning
of the procedure (from the first time the camera is inserted into the portal).

Figure 7-3: Internal View

Camera angle options (6)

TURP Mentor gives you the option to train using the degree of angled optics used in
the OR. Angled optics make it easier to visualize corners, tubes, and the upper and
lower part of the urethra, bladder and prostate.

The virtual resectoscopic optical system includes several available angles: 0°, 12°, and
30°.

surgicalscience Page 61


# Page 71

Chapter 7 
 TURP Display Modes
 
Page 62
 
• 
Press 0° for a straight view. This camera option does not work with angled optics. 
  
• 
Press 12° for a slightly flexed view. This camera option works with 12° angled 
option; it makes it easier to visualize angles and corners. 
 
• 
Press 30° for an even more flexed view than the 12° camera option. This camera 
option works with 30° angled option. 


[TABLE]
| Chapter 7                                                                           |
|  TURP Display Modes                                                                 |
|:------------------------------------------------------------------------------------|
| Press 0° for a straight view. This camera option does not work with angled optics.  |
| •                                                                                   |
| Press 12° for a slightly flexed view. This camera option works with 12° angled      |
| •                                                                                   |
| option; it makes it easier to visualize angles and corners.                         |
| Press 30° for an even more flexed view than the 12° camera option. This camera      |
| •                                                                                   |
| option works with 30° angled option.                                                |
| Page 62                                                                             |

[OCR]
Chapter 7 TURP Display Modes

e Press 0° for a straight view. This camera option does not work with angled optics.

e Press 12° for a slightly flexed view. This camera option works with 12° angled
option; it makes it easier to visualize angles and corners.

e Press 30° for an even more flexed view than the 12° camera option. This camera
option works with 30° angled option.

surgical Page 62


# Page 72

Chapter 7 
 TURP Display Modes
 
Page 63
 
 
To change the camera angle, select an angle on the left pane. 
For more information about working with the camera, see Camera on page 23. 
The Zoom percentage is displayed below the camera angles. 
Tool Menu options ④ 
The physical insertion of tools into the simulator is simulated using the real adapted 
resectoscope. You have the option of resecting with either a Monopolar loop or a 
Bipolar loop. The Tool Options are available on the Left pane. 
Note: It is recommended to select the tool prior to beginning the procedure.  
To select a tool: 
1.  Before inserting the resectoscope, press Select Tool. 
2.  Choose a tool: 
  Press this button to work with the monopolar loop for 
cutting/coagulating with electricity.  


[TABLE]
| To change the camera angle, select an angle on the left pane.                          |
|:---------------------------------------------------------------------------------------|
| For more information about working with the camera, see Camera on page 23.             |
| The Zoom percentage is displayed below the camera angles.                              |
| Tool Menu options ④                                                                    |
| The physical insertion of tools into the simulator is simulated using the real adapted |
| resectoscope. You have the option of resecting with either a Monopolar loop or a       |
| Bipolar loop. The Tool Options are available on the Left pane.                         |
| Note: It is recommended to select the tool prior to beginning the procedure.           |
| To select a tool:                                                                      |
| 1.   Before inserting the resectoscope, press Select Tool.                             |
| 2.   Choose a tool:                                                                    |

[OCR]
Chapter 7 TURP Display Modes

To change the camera angle, select an angle on the left pane.

For more information about working with the camera, see Camera on page 23.

The Zoom percentage is displayed below the camera angles.

Tool Menu options (@)

The physical insertion of tools into the simulator is simulated using the real adapted

resectoscope. You have the option of resecting with either a Monopolar loop or a
Bipolar loop. The Tool Options are available on the Left pane.

Note: It is recommended to select the tool prior to beginning the procedure.

To select a tool:

1. Before inserting the resectoscope, press Select Tool.
2. Choose a tool:

Monopolar Loop

Press this button to work with the monopolar loop for
cutting/coagulating with electricity.

surgicalscience Page 63


# Page 73

Chapter 7 
 TURP Display Modes
 
Page 64
 
  Press this button to work with the bipolar loop for 
cutting/coagulating with electricity.  
On the left pane, the tool is selected. 
Note: The Select Tool is disabled while the scope is in use. 
3.  To switch the tool, pull the scope out, press Select Tool and select another tool. 
Applying electricity 
Electricity can be used to cut/resect or coagulate the pathology. 
• 
To cut - apply electricity by pressing on the Electricity (middle) footswitch when 
retracting the working channel or pulling the entire resectoscope.  
• 
To coagulate - apply electricity by pressing on the Electricity (right) footswitch 
when retracting the working channel or pulling the entire resectoscope. 
WARNING: Never extend or push when applying electricity. 


[TABLE]
| Chapter 7                                                                               |
|  TURP Display Modes                                                                     |
|:----------------------------------------------------------------------------------------|
| Press this button to work with the bipolar loop for                                     |
| cutting/coagulating with electricity.                                                   |
| On the left pane, the tool is selected.                                                 |
| Note: The Select Tool is disabled while the scope is in use.                            |
| 3.   To switch the tool, pull the scope out, press Select Tool and select another tool. |
| Applying electricity                                                                    |
| Electricity can be used to cut/resect or coagulate the pathology.                       |
| To cut - apply electricity by pressing on the Electricity (middle) footswitch when      |
| •                                                                                       |
| retracting the working channel or pulling the entire resectoscope.                      |
| To coagulate - apply electricity by pressing on the Electricity (right) footswitch      |
| •                                                                                       |
| when retracting the working channel or pulling the entire resectoscope.                 |
| WARNING: Never extend or push when applying electricity.                                |
| Page 64                                                                                 |

[OCR]
Chapter 7 TURP Display Modes

Bipolar Loop A

Press this button to work with the bipolar loop for
cutting/coagulating with electricity.

On the left pane, the tool is selected.

Note: The Select Tool is disabled while the scope is in use.

3. To switch the tool, pull the scope out, press Select Tool and select another tool.
Applying electricity

Electricity can be used to cut/resect or coagulate the pathology.

e¢ To cut - apply electricity by pressing on the Electricity (middle) footswitch when
retracting the working channel or pulling the entire resectoscope.

e¢ To coagulate - apply electricity by pressing on the Electricity (right) footswitch
when retracting the working channel or pulling the entire resectoscope.

WARNING: Never extend or push when applying electricity.

surgicalscience Page 64


# Page 74

Chapter 7 
 TURP Display Modes
 
Page 65
 
External View 
 
Figure 7-4: External View 
When the simulation begins, an external view ⑥ of the anatomy and instruments is 
displayed. It realistically shows scope navigation and manipulation during the 
procedure within the relevant anatomy.  
External View controls ⑧ 
You can manipulate the External View using the navigational buttons on the top of the 
screen. 
 To rotate: 
1.  Press the Rotate button to select. 
2.  Click and drag the mouse in different directions to turn the anatomical atlas 3-
dimentionally around that point. 


[TABLE]
| Chapter 7                                                                             | TURP Display Modes                                                                    |
|:--------------------------------------------------------------------------------------|:--------------------------------------------------------------------------------------|
| External View                                                                         |                                                                                       |
| F                                                                                     |                                                                                       |
| i                                                                                     |                                                                                       |
| gure 7-4: External View                                                               |                                                                                       |
| When the simulation begins, an external view ⑥ of the anatomy and instruments is      |                                                                                       |
| displayed. It realistically shows scope navigation and manipulation during the        |                                                                                       |
| procedure within the relevant anatomy.                                                |                                                                                       |
| External View controls ⑧                                                              |                                                                                       |
|                                                                                       | You can manipulate the External View using the navigational buttons on the top of the |
| screen.                                                                               |                                                                                       |
| To rotate:                                                                            |                                                                                       |
| 1.   Press the Rotate button to select.                                               |                                                                                       |
| 2.   Click and drag the mouse in different directions to turn the anatomical atlas 3- |                                                                                       |
| dimentionally around that point.                                                      |                                                                                       |
|                                                                                       | Page 65                                                                               |

[OCR]
Chapter 7 TURP Display Modes

External View

Figure 7-4: External View

When the simulation begins, an external view (6) of the anatomy and instruments is
displayed. It realistically shows scope navigation and manipulation during the
procedure within the relevant anatomy.

External View controls

You can manipulate the External View using the navigational buttons on the top of the
screen.

ge To rotate:

Press the Rotate button to select.
2. Click and drag the mouse in different directions to turn the anatomical atlas 3-
dimentionally around that point.

surgicalscience Page 65


# Page 75

Chapter 7 
 TURP Display Modes
 
Page 66
 
OR 
Slide your finger in different directions on the screen to turn the anatomical atlas 
3-dimentionally around that point. 
 To zoom: 
1.  Press the Zoom button to select. 
2.  Tap and slide your finger up to zoom in or down to zoom out. 
OR 
Click and drag the mouse up to zoom in and down to zoom out.  
 To pan: 
1.  Press the Pan button to select. 
2.  Slide with your finger on the screen to move the anatomical atlas up, down, right 
and left. 
OR 
Click and drag the mouse up, down, right, and left. 
 To reset: 
1.  Press the Reset button to reset the anatomical atlas to its default display. 
Virtual instructor 
The Virtual Instructor ⑨ displays at the bottom of the screen: 
• 
 - a warning each time performance is compromised or might lead to an 
unsafe situation. 
• 
 - a notification each time a complication has occurred.  
 
The Virtual Instructor also displays comments that are not alerts, aiding the training 
process. 


[TABLE]
| Chapter 7                                                         | TURP Display Modes                                                                     |
|:------------------------------------------------------------------|:---------------------------------------------------------------------------------------|
| OR                                                                |                                                                                        |
|                                                                   | Slide your finger in different directions on the screen to turn the anatomical atlas   |
| 3-dimentionally around that point.                                |                                                                                        |
| To zoom:                                                          |                                                                                        |
| 1.   Press the Zoom button to select.                             |                                                                                        |
| 2.   Tap and slide your finger up to zoom in or down to zoom out. |                                                                                        |
| OR                                                                |                                                                                        |
|                                                                   | Click and drag the mouse up to zoom in and down to zoom out.                           |
| To pan:                                                           |                                                                                        |
| 1.   Press the Pan button to select.                              |                                                                                        |
|                                                                   | 2.   Slide with your finger on the screen to move the anatomical atlas up, down, right |
| and left.                                                         |                                                                                        |
| OR                                                                |                                                                                        |
|                                                                   | Click and drag the mouse up, down, right, and left.                                    |
| To reset:                                                         |                                                                                        |
|                                                                   | 1.   Press the Reset button to reset the anatomical atlas to its default display.      |
| Virtual instructor                                                |                                                                                        |
| The Virtual Instructor ⑨ displays at the bottom of the screen:    |                                                                                        |
| •                                                                 | - a warning each time performance is compromised or might lead to an                   |
| unsafe situation.                                                 |                                                                                        |
| •                                                                 | - a notification each time a complication has occurred.                                |
| T                                                                 | he Virtual Instructor also displays comments that are not alerts, aiding the training  |
| process.                                                          |                                                                                        |
|                                                                   | Page 66                                                                                |

[OCR]
Chapter 7 TURP Display Modes

OR

Slide your finger in different directions on the screen to turn the anatomical atlas
3-dimentionally around that point.

el To zoom:

Press the Zoom button to select.
2. Tap and slide your finger up to zoom in or down to zoom out.

OR
Click and drag the mouse up to zoom in and down to zoom out.

GG To pan:

Press the Pan button to select.
2. Slide with your finger on the screen to move the anatomical atlas up, down, right
and left.

OR
Click and drag the mouse up, down, right, and left.

ie To reset:

Press the Reset button to reset the anatomical atlas to its default display.

Virtual instructor
The Virtual Instructor (©) displays at the bottom of the screen:

. (w) - a warning each time performance is compromised or might lead to an
unsafe situation.

. IN - anotification each time a complication has occurred.

The Virtual Instructor also displays comments that are not alerts, aiding the training
process.

surgicalscience Page 66


# Page 76

Chapter 7 
 TURP Display Modes
 
Page 67
 
General buttons 
The general buttons (10) appear on the bottom right of the screen and include the 
following functions: 
 
The Mute button turns the sound on and off. 
 
The Case File button opens the current virtual patient’s 
case file or the task instructions.  
 
The Finish button ends the current simulation and 
returns to the performance section. Once exiting the 
case, it is not possible to continue the same simulation 
session. The button appears on the top right of the 
screen. 
Simulation Aids 
There are 3 simulation aids ⑤: 
• 
Resection Assist 
• 
Resection Progress Bar 
• 
Clear View 
 
  Resection Assist 
Press this button to show the resection map. Different colors on the map show the 
optimal place for resection, where cutting will penetrate too deep into the capsule or 
landmarks, and where you can continue to resect. 
Press this button again to hide the resection map. 


[TABLE]
| The general buttons (10) appear on the bottom right of the screen and include the   |
|:------------------------------------------------------------------------------------|
| following functions:                                                                |
| The Mute button turns the sound on and off.                                         |
| The Case File button opens the current virtual patient’s                            |
| case file or the task instructions.                                                 |
| The Finish button ends the current simulation and                                   |
| returns to the performance section. Once exiting the                                |
| case, it is not possible to continue the same simulation                            |
| session. The button appears on the top right of the                                 |
| screen.                                                                             |

[OCR]
Chapter 7 TURP Display Modes

General buttons

The general buttons (10) appear on the bottom right of the screen and include the
following functions:

4) The Mute button turns the sound on and off.

The Case File button opens the current virtual patient’s
case file or the task instructions.

The Finish button ends the current simulation and
returns to the performance section. Once exiting the
case, it is not possible to continue the same simulation
session. The button appears on the top right of the
screen.

Simulation Aids
There are 3 simulation aids G):

e Resection Assist
e Resection Progress Bar
e =©Clear View

Press this button to show the resection map. Different colors on the map show the
optimal place for resection, where cutting will penetrate too deep into the capsule or
landmarks, and where you can continue to resect.

Press this button again to hide the resection map.

surgicalscience Page 67


# Page 77

Chapter 7 
 TURP Display Modes
 
Page 68
 
  
 
Figure 7-5: Default View and Show Resection View 
Use the colors and zones on the Resection map to direct you where to continue 
resecting and which areas to avoid.   
 
Figure 7-6: Resection zones on Resection Map 
• 
Green – Resect 
• 
Yellow/orange – Getting closer to capsule 
• 
Red – Capsule. Do not resect 
 Resection progress bar 
 Resection Progress Bar 
The resection progress bar shows how much of the prostate has been resected. The 
bar fills reflecting the percentage of prostate resected which is displayed below the 
bar. 


[TABLE]
| Chapter 7                                                                             | TURP Display Modes   |
|:--------------------------------------------------------------------------------------|:---------------------|
| F                                                                                     |                      |
| i                                                                                     |                      |
| gure 7-5: Default View and Show Resection View                                        |                      |
| Use the colors and zones on the Resection map to direct you where to continue         |                      |
| resecting and which areas to avoid.                                                   |                      |
| F                                                                                     |                      |
| i                                                                                     |                      |
| gure 7-6: Resection zones on Resection Map                                            |                      |
| Green – Resect                                                                        |                      |
| •                                                                                     |                      |
| Yellow/orange – Getting closer to capsule                                             |                      |
| •                                                                                     |                      |
| Red – Capsule. Do not resect                                                          |                      |
| •                                                                                     |                      |
| Resection progress bar                                                                |                      |
| Resection Progress Bar                                                                |                      |
| The resection progress bar shows how much of the prostate has been resected. The      |                      |
| bar fills reflecting the percentage of prostate resected which is displayed below the |                      |
| bar.                                                                                  |                      |
|                                                                                       | Page 68              |

[OCR]
Chapter 7 TURP Display Modes

Figure 7-5: Default View and Show Resection View

Use the colors and zones on the Resection map to direct you where to continue
resecting and which areas to avoid.

Figure 7-6: Resection zones on Resection Map

. Green — Resect
Yellow/orange — Getting closer to capsule
Red - Capsule. Do not resect

Resection progress bar

[=] Resection Progress Bar | Resection Progress Bar

The resection progress bar shows how much of the prostate has been resected. The
bar fills reflecting the percentage of prostate resected which is displayed below the
bar.

surgicalscience Page 68


# Page 78

Chapter 7 
 TURP Display Modes
 
Page 69
 
 
Figure 7-7: Resection progress bar 
Clearing the simulation view 
  Clear View 
Press this button to clear the view of blood and murky fluid. 
  
 
Figure 7-8: View clouded with blood and tissue and view cleared 
Inflow and Outflow Valves 
If the view becomes obscured due to blood or murky fluid, adjust the valves to get the 
optimal flow of fluids. Make sure the Inflow valve is open. Move the Outflow valve 
handle until the view is clear (discarding the existing fluid).  
If bladder is full, first remove and then reinsert the resectoscope to empty bladder and 
restore adequate flow. 


[TABLE]
| Chapter 7                                                                                | TURP Display Modes   |
|:-----------------------------------------------------------------------------------------|:---------------------|
| F                                                                                        |                      |
| i                                                                                        |                      |
| gure 7-7: Resection progress bar                                                         |                      |
| Clearing the simulation view                                                             |                      |
| Clear View                                                                               |                      |
| Press this button to clear the view of blood and murky fluid.                            |                      |
| F                                                                                        |                      |
| i                                                                                        |                      |
| gure 7-8: View clouded with blood and tissue and view cleared                            |                      |
| Inflow and Outflow Valves                                                                |                      |
| If the view becomes obscured due to blood or murky fluid, adjust the valves to get the   |                      |
| optimal flow of fluids. Make sure the Inflow valve is open. Move the Outflow valve       |                      |
| handle until the view is clear (discarding the existing fluid).                          |                      |
| If bladder is full, first remove and then reinsert the resectoscope to empty bladder and |                      |
| restore adequate flow.                                                                   |                      |
|                                                                                          | Page 69              |

[OCR]
Chapter 7 TURP Display Modes

Figure 7-7: Resection progress bar

Clearing the simulation view

|
Clear View

Press this button to clear the view of blood and murky fluid.

Figure 7-8: View clouded with blood and tissue and view cleared

Inflow and Outflow Valves

If the view becomes obscured due to blood or murky fluid, adjust the valves to get the
optimal flow of fluids. Make sure the Inflow valve is open. Move the Outflow valve
handle until the view is clear (discarding the existing fluid).

If bladder is full, first remove and then reinsert the resectoscope to empty bladder and
restore adequate flow.

surgicalscience Page 69


# Page 79

Chapter 8 
 Working with Tools
 
Page 70
 
Chapter 8 Working with Tools 
Each procedure, depending upon the patient’s history and pathologies, will require the 
use of different scopes, tools and actions. 
Tools menu 
The Tools Menu ⑤ is located on the left side of the screen. Placing the cursor over 
each icon opens a small window with the name of the tool category. Select the 
appropriate category to open sub-menus. 
 
Figure 8-1: Tools Menu with sub-menu of options 
The physical tools and wires are found on the URO Mentor’s tool tray. Any one of the 
three tool wires can simulate the tools in the Tools Menu. 
Selecting a tool 
To select a tool: 
1.  Press the icon of the tool you want to use on the Tools Menu. A sub-menu opens. 
2.  From the sub-menu, select an item by pressing it. 
3.  If there is an additional sub-menu providing different tool diameter, select the 
appropriate diameter by pressing it.  


[TABLE]
| Chapter 8                                                                           | Working with Tools                                                                     |
|:------------------------------------------------------------------------------------|:---------------------------------------------------------------------------------------|
| Chapter 8 Working with Tools                                                        |                                                                                        |
|                                                                                     | Each procedure, depending upon the patient’s history and pathologies, will require the |
| use of different scopes, tools and actions.                                         |                                                                                        |
| Tools menu                                                                          |                                                                                        |
| The Tools Menu ⑤ is located on the left side of the screen. Placing the cursor over |                                                                                        |
| each icon opens a small window with the name of the tool category. Select the       |                                                                                        |
| appropriate category to open sub-menus.                                             |                                                                                        |

[OCR]
Chapter 8 Working with Tools

| Chapter 8 Working with Tools

Each procedure, depending upon the patient's history and pathologies, will require the
use of different scopes, tools and actions.

Tools menu

The Tools Menu G) is located on the left side of the screen. Placing the cursor over
each icon opens a small window with the name of the tool category. Select the
appropriate category to open sub-menus.

Time: 00:00:02

ydropailic 0.038

rophilic Angled 0.035

Figure 8-7: Tools Menu with sub-menu of options

The physical tools and wires are found on the URO Mentor’s tool tray. Any one of the
three tool wires can simulate the tools in the Tools Menu.

Selecting a tool

To select a tool:

1. Press the icon of the tool you want to use on the Tools Menu. A sub-menu opens.

2. From the sub-menu, select an item by pressing it.

3. If there is an additional sub-menu providing different tool diameter, select the
appropriate diameter by pressing it.

surgicalscience Page 70


# Page 80

Chapter 8 
 Working with Tools
 
Page 71
 
Working simultaneously with more than one 
endoscopic tool 
When working with a second, additional device, a second scope should be mounted on 
the tool tray and its working channel used for the second device. 
 
Working with baskets, forceps and balloons 
The two handles on the tool tray simulate the handles that operate the baskets, 
forceps and balloons once they have been selected and inserted. 
 
 
 To work with a basket, forceps, or balloon: 
1.  Advance the tool into place using the tool wire or scope. 
2.  Select the appropriate handle on the tool tray. 
3.  Open and close the tool on the screen by:  
• 
Forceps handle: sliding the knob on the handle backward and forward.  


[TABLE]
| Chapter 8                                                                          |
|  Working with Tools                                                                |
|:-----------------------------------------------------------------------------------|
| Working simultaneously with more than one                                          |
| endoscopic tool                                                                    |
| When working with a second, additional device, a second scope should be mounted on |
| the tool tray and its working channel used for the second device.                  |
| Working with baskets, forceps and balloons                                         |
| The two handles on the tool tray simulate the handles that operate the baskets,    |
| forceps and balloons once they have been selected and inserted.                    |
| To work with a basket, forceps, or balloon:                                        |
| 1.   Advance the tool into place using the tool wire or scope.                     |
| 2.   Select the appropriate handle on the tool tray.                               |
| 3.   Open and close the tool on the screen by:                                     |
| Forceps handle: sliding the knob on the handle backward and forward.               |
| •                                                                                  |
| Page 71                                                                            |

[OCR]
Chapter 8 Working with Tools

Working simultaneously with more than one
endoscopic tool

When working with a second, additional device, a second scope should be mounted on
the tool tray and its working channel used for the second device.

Working with baskets, forceps and balloons

The two handles on the tool tray simulate the handles that operate the baskets,
forceps and balloons once they have been selected and inserted.

Fea L~ Lr To work with a basket, forceps, or balloon:

Advance the tool into place using the tool wire or scope.
Select the appropriate handle on the tool tray.
Open and close the tool on the screen by:

wn>

Forceps handle: sliding the knob on the handle backward and forward.

surgicalscience Page 71


# Page 81

Chapter 8 
 Working with Tools
 
Page 72
 
 
 
Figure 8-2: Forceps removing stone fragment 
Working with lithotripters and electrodes 
Each of the lithotripters that are simulated on the URO Mentor has its own unique 
energy control panel that is displayed under the Endoscopic View. Use this control 
panel to set energy levels/power. 


[TABLE]
| Chapter 8                         |                                                                                    | Working with Tools   |
|:----------------------------------|:-----------------------------------------------------------------------------------|:---------------------|
| F                                 | gure 8-2: Forceps removing stone fragment                                          |                      |
| i                                 |                                                                                    |                      |
|                                   | Working with lithotripters and electrodes                                          |                      |
|                                   | Each of the lithotripters that are simulated on the URO Mentor has its own unique  |                      |
|                                   | energy control panel that is displayed under the Endoscopic View. Use this control |                      |
| panel to set energy levels/power. |                                                                                    |                      |
|                                   |                                                                                    | Page 72              |

[OCR]
Chapter 8 Working with Tools

Figure 8-2: Forceps removing stone fragment

Working with lithotripters and electrodes

Each of the lithotripters that are simulated on the URO Mentor has its own unique

energy control panel that is displayed under the Endoscopic View. Use this control
panel to set energy levels/power.

surgicalscience Page 72


# Page 82

Chapter 8 
 Working with Tools
 
Page 73
 
 
Figure 8-3: Lithotripter breaking stone into fragments 
 To operate a laser lithotripter:  
1.  Select a laser lithotripter from the Tools Menu. 
The following energy control panel is displayed. 
 
Figure 8-4: Laser Lithotripter control panel 
1 Power  2 Energy per Pulse  3 Frequency 
2.  Press – or + buttons to increase or decrease the energy and frequency levels. 
The energy per second (power) is displayed in Joules/Sec. 
3.  Press the Tools foot pedal to operate the lithotripter. 
 To operate a pneumatic lithotripter:  
1.  Select a pneumatic lithotripter from the Tools Menu. 
The following energy control panel is displayed. 


[TABLE]
| Chapter 8                                                                          | Working with Tools   |
|:-----------------------------------------------------------------------------------|:---------------------|
| F                                                                                  |                      |
| i                                                                                  |                      |
| gure 8-3: Lithotripter breaking stone into fragments                               |                      |
| To operate a laser lithotripter:                                                   |                      |
| 1.   Select a laser lithotripter from the Tools Menu.                              |                      |
| The following energy control panel is displayed.                                   |                      |
| F                                                                                  |                      |
| i                                                                                  |                      |
| gure 8-4: Laser Lithotripter control panel                                         |                      |
| 1                                                                                  |                      |
|                                                                                    |                      |
| Power  2 Energy per Pulse  3 Frequency                                             |                      |
| 2.   Press – or + buttons to increase or decrease the energy and frequency levels. |                      |
| The energy per second (power) is displayed in Joules/Sec.                          |                      |
| 3.   Press the Tools foot pedal to operate the lithotripter.                       |                      |
| To operate a pneumatic lithotripter:                                               |                      |
| 1.   Select a pneumatic lithotripter from the Tools Menu.                          |                      |
| The following energy control panel is displayed.                                   |                      |
|                                                                                    | Page 73              |

[OCR]
Chapter 8 Working with Tools

Figure 8-3: Lithotripter breaking stone into fragments

To operate a laser lithotripter:

1.

3.

Select a laser lithotripter from the Tools Menu.

The following energy control panel is displayed.

i Baw - Bec - Bac

Jt _ 7) 2 =

2 3

Figure 8-4: Laser Lithotripter control panel

7 Power 2 Energy per Pulse 3 Frequency
Press — or + buttons to increase or decrease the energy and frequency levels.

The energy per second (power) is displayed in Joules/Sec.
Press the Tools foot pedal to operate the lithotripter.

To operate a pneumatic lithotripter:

1.

Select a pneumatic lithotripter from the Tools Menu.

The following energy control panel is displayed.

surgicalscience Page 73


# Page 83

Chapter 8 
 Working with Tools
 
Page 74
 
 
Figure 8-5: Pneumatic Lithotripter control panel 
1 Power  2 Single Pulse  3 Continuous Pulse 
2.  Press the – and + buttons to increase or decrease the level of power.  
3.  Press the appropriate pulse button to operate the tool – either a single pulse or a 
continuous series of pulses. 
4.  Press the Tools foot pedal to operate the lithotripter. 
 To operate an EHL lithotripter:  
1.  Select an EHL lithotripter from the Tools Menu. 
The following energy control panel is displayed. 
 
Figure 8-6: EHL Lithotripter control panel 
1 Power  2 Single Hit  3 Double Hit  4 Crescendo  5 Continuous 
2.  Press the – and + buttons to increase or decrease the level of power.  
3.  Choose one of the operating methods from the 4 available working modes. 
4.  Press the Tools foot pedal to operate the lithotripter. 
Electrodes can also be used to open strictures or break apart stones. 
 To operate electrodes: 
1.  Advance the electrode into place using the tool wire and the scope. 
2.  From the control panel under the Fluoroscopic View, select either cut or coagulate. 
 
Figure 8-7: Electrode control panel 
3.  Press the Tools foot pedal to operate the electrode. 


[TABLE]
| Chapter 8                                                                                | Working with Tools   |
|:-----------------------------------------------------------------------------------------|:---------------------|
| F                                                                                        |                      |
| i                                                                                        |                      |
| gure 8-5: Pneumatic Lithotripter control panel                                           |                      |
| 1                                                                                        |                      |
|                                                                                          |                      |
| Power  2 Single Pulse  3 Continuous Pulse                                                |                      |
| 2.   Press the – and + buttons to increase or decrease the level of power.               |                      |
| 3.   Press the appropriate pulse button to operate the tool – either a single pulse or a |                      |
| continuous series of pulses.                                                             |                      |
| 4.   Press the Tools foot pedal to operate the lithotripter.                             |                      |
| To operate an EHL lithotripter:                                                          |                      |
| 1.   Select an EHL lithotripter from the Tools Menu.                                     |                      |
| The following energy control panel is displayed.                                         |                      |
| F                                                                                        |                      |
| i                                                                                        |                      |
| gure 8-6: EHL Lithotripter control panel                                                 |                      |
| 1                                                                                        |                      |
|                                                                                          |                      |
| Power  2 Single Hit  3 Double Hit  4 Crescendo  5 Continuous                             |                      |
| 2.   Press the – and + buttons to increase or decrease the level of power.               |                      |
| 3.   Choose one of the operating methods from the 4 available working modes.             |                      |
| 4.   Press the Tools foot pedal to operate the lithotripter.                             |                      |
| Electrodes can also be used to open strictures or break apart stones.                    |                      |
| To operate electrodes:                                                                   |                      |
| 1.   Advance the electrode into place using the tool wire and the scope.                 |                      |
| 2.   From the control panel under the Fluoroscopic View, select either cut or coagulate. |                      |
| F                                                                                        |                      |
| i                                                                                        |                      |
| gure 8-7: Electrode control panel                                                        |                      |
| 3.   Press the Tools foot pedal to operate the electrode.                                |                      |
|                                                                                          | Page 74              |

[OCR]
Chapter 8 Working with Tools

Figure 8-5: Pneumatic Lithotripter control pane!

7 Power 2 Single Pulse 3 Continuous Pulse

2. Press the —- and + buttons to increase or decrease the level of power.

3. Press the appropriate pulse button to operate the tool — either a single pulse or a
continuous series of pulses.

4. Press the Tools foot pedal to operate the lithotripter.

To operate an EHL lithotripter:
1. Select an EHL lithotripter from the Tools Menu.

The following energy control panel is displayed.

Figure 8-6: EHL Lithotripter contro! panel

7 Power 2 Single Hit 3 Double Hit 4 Crescendo 5 Continuous
2. Press the - and + buttons to increase or decrease the level of power.
3. Choose one of the operating methods from the 4 available working modes.
4. Press the Tools foot pedal to operate the lithotripter.
Electrodes can also be used to open strictures or break apart stones.

=a To operate electrodes:

Advance the electrode into place using the tool wire and the scope.
2. From the control panel under the Fluoroscopic View, select either cut or coagulate.

i“ — mimrig| 4

Figure 8-7: Electrode contro! panel

3. Press the Tools foot pedal to operate the electrode.

surgicalscience Page 74


# Page 84

Chapter 8 
 Working with Tools
 
Page 75
 
 
Figure 8-8: Electrode opening stricture 
Working with stents 
 /Stents can be used to widen the ureter walls so that fluid can pass between the 
kidney and bladder.  
 To operate a stent: 
1.  Extract the scope. 
2.  Select a stent type (e.g. Pigtail) and size from the Tools Menu according to the 
patient’s characteristics. 
3.  Re-insert the scope. 
The stent is displayed on the screen. 


[TABLE]
| F                                                                                     |
| i                                                                                     |
| gure 8-8: Electrode opening stricture                                                 |
|:--------------------------------------------------------------------------------------|
| Working with stents                                                                   |
| /Stents can be used to widen the ureter walls so that fluid can pass between the      |
| kidney and bladder.                                                                   |
| To operate a stent:                                                                   |
| 1.   Extract the scope.                                                               |
| 2.   Select a stent type (e.g. Pigtail) and size from the Tools Menu according to the |
| patient’s characteristics.                                                            |
| 3.   Re-insert the scope.                                                             |

[OCR]
Chapter 8 Working with Tools

Figure 8-8: Electrode opening stricture

Working with stents

/Stents can be used to widen the ureter walls so that fluid can pass between the
kidney and bladder.

ra To operate a stent:

Extract the scope.

2. Select a stent type (e.g. Pigtail) and size from the Tools Menu according to the
patient’s characteristics.

3. Re-insert the scope.

The stent is displayed on the screen.

surgicalscience Page 75


# Page 85

Chapter 8 
 Working with Tools
 
Page 76
 
 
Figure 8-9: Stent over the guide wire 
Information on scopes and tools 
As you perform a procedure or task, you can view information about the scope and/or 
tools that you have selected and are currently using. 
To view online information about scopes and tools:  
1.  Press the 
 button on the control panel under the Endoscopic view. 
A window opens displaying information about the currently selected scope and 
tools. 
 
Figure 8-10: Scope and Tool Information window 


[TABLE]
| F                                                                                   |                                                        |
| i                                                                                   |                                                        |
| gure 8-9: Stent over the guide wire                                                 |                                                        |
|:------------------------------------------------------------------------------------|:-------------------------------------------------------|
| Information on scopes and tools                                                     |                                                        |
| As you perform a procedure or task, you can view information about the scope and/or |                                                        |
| tools that you have selected and are currently using.                               |                                                        |
| To view online information about scopes and tools:                                  |                                                        |
| 1.   Press the                                                                      | button on the control panel under the Endoscopic view. |

[OCR]
Chapter 8 Working with Tools

Figure 8-9: Stent over the guide wire

Information on scopes and tools

As you perform a procedure or task, you can view information about the scope and/or
tools that you have selected and are currently using.

To view online information about scopes and tools:

1. Press the ail button on the control panel under the Endoscopic view.

A window opens displaying information about the currently selected scope and
tools.

®

| Flexible Ureteroscope Lithotripter: Holmium-YAG 20W

| View angle: 0.00 Fiber Diameter: 0.200mm

|| Field of view: 90.00 Laser: Pulse duration: 250-350ysec
| WC Diameter: 3.6f

M Outer Diameter: 2.50 mm

»

Figure 8-10: Scope and Tool Information window

surgicalscience Page 76


# Page 86

Chapter 8 
 Working with Tools
 
Page 77
 
2.  To close the window, press OK. 
Working with resectoscope 
The resectoscope is used for TURP modules. 
Aligning the resectoscope 
To align the resectoscope:  
1.  Align the scope so that the camera button and the working element handles are 
parallel.  
 
Figure 8-11: Working element parallel to camera button 
2.  Insert the scope into the penis component on the cartridge. 
The arrow should be positioned at the top of the simulation screen (12o’clock). 


[TABLE]
| Chapter 8                                                                          | Working with Tools   |
|:-----------------------------------------------------------------------------------|:---------------------|
| 2.   To close the window, press OK.                                                |                      |
| Working with resectoscope                                                          |                      |
| The resectoscope is used for TURP modules.                                         |                      |
| Aligning the resectoscope                                                          |                      |
| To align the resectoscope:                                                         |                      |
| 1.   Align the scope so that the camera button and the working element handles are |                      |
| parallel.                                                                          |                      |

[OCR]
Chapter 8 Working with Tools

2. To close the window, press OK.
Working with resectoscope

The resectoscope is used for TURP modules.

Aligning the resectoscope

To align the resectoscope:
1. Align the scope so that the camera button and the working element handles are
parallel.

Figure 8-17: Working element parallel to camera button
2. Insert the scope into the penis component on the cartridge.

The arrow should be positioned at the top of the simulation screen (120’clock).

surgicalscience Page 77


# Page 87

Chapter 8 
 Working with Tools
 
Page 78
 
 
Figure 8-12: Align Scope screen for resectoscope 
Inserting and positioning the camera 
The case starts with a camera view displayed on the screen. However, the camera 
may need to be manipulated to display the correct view of the anatomy. 
To position the camera: 
1.  Move the camera handle to adjust the operative view seen on the screen. 
2.  Rotating it rotates the horizon too. Change the camera angle, if necessary, to see 
behind objects. 
 
3.  You can now: 
o 
Move the camera handle to adjust the operative view seen on the screen. 
o 
Rotate the camera (using the rotatable handle). 
Note: Currently, the button on the scope handle is not functionable. 


[TABLE]
| F                                                                                       |
| i                                                                                       |
| gure 8-12: Align Scope screen for resectoscope                                          |
|:----------------------------------------------------------------------------------------|
| Inserting and positioning the camera                                                    |
| The case starts with a camera view displayed on the screen. However, the camera         |
| may need to be manipulated to display the correct view of the anatomy.                  |
| To position the camera:                                                                 |
| 1.   Move the camera handle to adjust the operative view seen on the screen.            |
| 2.   Rotating it rotates the horizon too. Change the camera angle, if necessary, to see |
| behind objects.                                                                         |
| 3.   You can now:                                                                       |

[OCR]
Chapter 8 Working with Tools

Figure 8-12: Align Scope screen for resectoscope

Inserting and positioning the camera

The case starts with a camera view displayed on the screen. However, the camera
may need to be manipulated to display the correct view of the anatomy.

To position the camera:

1. Move the camera handle to adjust the operative view seen on the screen.
2. Rotating it rotates the horizon too. Change the camera angle, if necessary, to see
behind objects.

3. You can now:

° Move the camera handle to adjust the operative view seen on the screen.
lo) Rotate the camera (using the rotatable handle).

Note: Currently, the button on the scope handle is not functionable.

surgicalscience Page 78


# Page 88

Chapter 8 
 Working with Tools
 
Page 79
 
Focusing the simulation display 
Use the focus wheel in front of the camera to adjust the focus of the simulation display 
(Internal View).  
  
 
Figure 8-13: View out of focus and view in focus 
Zooming the simulation display 
Use the zoom ring in front of the camera to zoom in or out of the simulation display 
(Internal View). The zoom percentage is displayed under the angled optics. 
 
Figure 8-14: Zoom percentage 
Ending the case or task 
Press X in the upper right corner of the screen to end the current simulation. A 
message is displayed asking you if you are sure you want to finish.  


[TABLE]
| Chapter 8                                                                            | Working with Tools                                                                       |
|:-------------------------------------------------------------------------------------|:-----------------------------------------------------------------------------------------|
| Focusing the simulation display                                                      |                                                                                          |
|                                                                                      | Use the focus wheel in front of the camera to adjust the focus of the simulation display |
| (Internal View).                                                                     |                                                                                          |
| F                                                                                    |                                                                                          |
| i                                                                                    |                                                                                          |
| gure 8-13: View out of focus and view in focus                                       |                                                                                          |
| Zooming the simulation display                                                       |                                                                                          |
| Use the zoom ring in front of the camera to zoom in or out of the simulation display |                                                                                          |
| (Internal View). The zoom percentage is displayed under the angled optics.           |                                                                                          |
| F                                                                                    |                                                                                          |
| i                                                                                    |                                                                                          |
| gure 8-14: Zoom percentage                                                           |                                                                                          |
| Ending the case or task                                                              |                                                                                          |
| Press X in the upper right corner of the screen to end the current simulation. A     |                                                                                          |
| message is displayed asking you if you are sure you want to finish.                  |                                                                                          |
|                                                                                      | Page 79                                                                                  |

[OCR]
Chapter 8 Working with Tools

Focusing the simulation display

Use the focus wheel in front of the camera to adjust the focus of the simulation display
(Internal View).

Figure 8-13: View out of focus and view in focus

Zooming the simulation display

Use the zoom ring in front of the camera to zoom in or out of the simulation display
(Internal View). The zoom percentage is displayed under the angled optics.

ANGLES

;0°

Figure 8-14: Zoom percentage

Ending the case or task

Press X in the upper right corner of the screen to end the current simulation. A
message is displayed asking you if you are sure you want to finish.

surgicalscience Page 79


# Page 89

Chapter 8 
 Working with Tools
 
Page 80
 
• 
Press Yes – to end the case or task. Your performance is saved and can be 
viewed on the Reports page. 
• 
Press No – to return to the previous screen. Your performance will not be saved. 
 


[TABLE]
| Chapter 8                                                                         |
|  Working with Tools                                                               |
|:----------------------------------------------------------------------------------|
| Press Yes – to end the case or task. Your performance is saved and can be         |
| •                                                                                 |
| viewed on the Reports page.                                                       |
| Press No – to return to the previous screen. Your performance will not be saved.  |
| •                                                                                 |
| Page 80                                                                           |

[OCR]
Chapter 8 Working with Tools

e Press Yes — to end the case or task. Your performance is saved and can be
viewed on the Reports page.
. Press No - to return to the previous screen. Your performance will not be saved.

surgicalscience Page 80


# Page 90

Chapter 9 
 Viewing Performance Reports
 
Page 81
 
Chapter 9 Viewing Performance Reports 
Overview 
Performance reports are displayed after each simulation case or task, allowing you to 
monitor and track your training progress. 
Note: MentorLearn produces reports for simulation cases only; reports are not produced 
relating to the completion of any didactic material included in a course. 
When you press Finish to end a task or case, your performance report is displayed 
automatically. All of your reports are listed on the MentorLearn Reports screen. 
Viewing reports 
To view performance reports: 
1.  Press Reports on the MentorLearn menu to access the Reports screen. 
 
2.  The entries in the reports table appear in chronological order – the most recently 
performed sessions appear at the top of the list. Each row in the reports table 
represents a single session, meaning that if a user completed a particular 
simulation case three times, three entries (rows) for that case are displayed. 
3.  To display a shorter, more focused list of sessions in the Reports table, use the 
search at the top of the table or define a filter in the right pane. To restore the full, 
unfiltered list of reports, clear the selected checkbox(es). 


[TABLE]
| Chapter 9                                                                              | Viewing Performance Reports                                                           |
|:---------------------------------------------------------------------------------------|:--------------------------------------------------------------------------------------|
| Chapter 9 Viewing Performance Reports                                                  |                                                                                       |
| Overview                                                                               |                                                                                       |
|                                                                                        | Performance reports are displayed after each simulation case or task, allowing you to |
| monitor and track your training progress.                                              |                                                                                       |
| Note: MentorLearn produces reports for simulation cases only; reports are not produced |                                                                                       |
| relating to the completion of any didactic material included in a course.              |                                                                                       |
| When you press Finish to end a task or case, your performance report is displayed      |                                                                                       |
| automatically. All of your reports are listed on the MentorLearn Reports screen.       |                                                                                       |
| Viewing reports                                                                        |                                                                                       |
| To view performance reports:                                                           |                                                                                       |
| 1.   Press Reports on the MentorLearn menu to access the Reports screen.               |                                                                                       |

[TABLE]
| 2.   The entries in the reports table appear in chronological order – the most recently   |
|:------------------------------------------------------------------------------------------|
| performed sessions appear at the top of the list. Each row in the reports table           |
| represents a single session, meaning that if a user completed a particular                |
| simulation case three times, three entries (rows) for that case are displayed.            |
| 3.   To display a shorter, more focused list of sessions in the Reports table, use the    |
| search at the top of the table or define a filter in the right pane. To restore the full, |
| unfiltered list of reports, clear the selected checkbox(es).                              |

[OCR]
Chapter 9 Viewing Performance Reports

| Chapter 9 Viewing Performance Reports

Overview

Performance reports are displayed after each simulation case or task, allowing you to
monitor and track your training progress.

Note: MentorLearn produces reports for simulation cases only; reports are not produced
relating to the completion of any didactic material included in a course.

When you press Finish to end a task or case, your performance report is displayed
automatically. All of your reports are listed on the MentorLearn Reports screen.

Viewing reports

To view performance reports:
1. Press Reports on the MentorLearn menu to access the Reports screen.

Oo * Group Name Module/Course case ate

o* Main, Library Assignments, First Year Urology Client Administrator Endourology Full Procedure- Stone Manipulation Case 2 12/10/2021 16:49:9
Residents Stone Mi ion

oOo * Main, Library Assignments, First Year Urology Client Administrator Endourology Basic Tasks
Residents

oOo * Main, Library Assignments, First Year Urology Client Administrator Endourology Basic Tasks 12/10/2021 16:44:2,
Residents

oOo * Main, Library Assignments, First Year Urology Client Administrator Essential Skills -Cyberscopy Hall of Fame ~ Level 1 12/10/2021 16:40:40
Residents Hall of Fame

oOo * Main, Library Assignments, First Year Urology Client Administrator Essential Skills -Cyberscopy Hall of Fame ~ Level 1 7/10/2021 15:34:53

Residents, Fall of Fame

2. The entries in the reports table appear in chronological order — the most recently
performed sessions appear at the top of the list. Each row in the reports table
represents a single session, meaning that if a user completed a particular
simulation case three times, three entries (rows) for that case are displayed.

3. To display a shorter, more focused list of sessions in the Reports table, use the
search at the top of the table or define a filter in the right pane. To restore the full,
unfiltered list of reports, clear the selected checkbox(es).

surgicalscience Page 81


# Page 91

Chapter 9 
 Viewing Performance Reports
 
Page 82
 
4.  To bookmark a report, press
to the left of its name. You can then easily return 
to the report when needed. To remove the bookmark, press the star 
 again. If 
desired you can filter only starred reports or only unstarred reports. On the right 
pane, select the Starred check box to view only those starred reports. Clear the 
check box to view all the reports. 
Note: When you exit MentorLearn, those bookmarked reports are saved and will be 
displayed the next time you open MentorLearn. 
5.  To scroll through the list of reports, use the Next and Previous arrows at the 
bottom of the Reports screen.  
6.  To open a single-case report, press its row in the Reports table. 
 
Figure 9-1: Single-case report without benchmarks 


[TABLE]
| Chapter 9                                                                           |
|  Viewing Performance Reports                                                        |
|:------------------------------------------------------------------------------------|
| 4.   To bookmark a report, press                                                    |
| to the left of its name. You can then easily return                                 |
| to the report when needed. To remove the bookmark, press the star                   |
|  again. If                                                                          |
| desired you can filter only starred reports or only unstarred reports. On the right |
| pane, select the Starred check box to view only those starred reports. Clear the    |
| check box to view all the reports.                                                  |
| Note: When you exit MentorLearn, those bookmarked reports are saved and will be     |
| displayed the next time you open MentorLearn.                                       |
| 5.   To scroll through the list of reports, use the Next and Previous arrows at the |
| bottom of the Reports screen.                                                       |
| 6.   To open a single-case report, press its row in the Reports table.              |
| F                                                                                   |
| i                                                                                   |
| gure 9-1: Single-case report without benchmarks                                     |
| Page 82                                                                             |

[OCR]
Chapter 9

Viewing Performance Reports

4. To bookmark a report, press Ki. the left of its name. You can then easily return

5.

to the report when needed. To remove the bookmark, press the star * again. If
desired you can filter only starred reports or only unstarred reports. On the right
pane, select the Starred check box to view only those starred reports. Clear the

check box to view all the reports.

Note: When you exit MentorLearn, those bookmarked reports are saved and will be

displayed the next time you open MentorLearn.

To scroll through the list of reports, use the Next and Previous arrows at the

bottom of the Reports screen.

6. To open a single-case report, press its row in the Reports table.

General

Ergonomics

Educational Aids

Resection

Bleeding Control

safety

Figure 9-7: Single-case report without benchmarks

surgicalscience

Page 82


# Page 92

Chapter 9 
 Viewing Performance Reports
 
Page 83
 
 
Figure 9-2: Single-case report with benchmarks 
1 
Report Header displays information about the report, 
including the user who performed the case, the name of 
the case performed, and the module that contains the 
performed case. 
The session number is displayed in the report header. 
2 
Scoreboard displays information about your total score 
for the task/case. For more information, see 
Understanding the scoreboard on page 90.  
3 
Video options display options for viewing, downloading 
and deleting the recorded video of your simulation 
performance. For more information, see Viewing 
recorded videos on page 86.  


[TABLE]
| gure 9-2: Single-case report with benchmarks   |                                                        |
|:-----------------------------------------------|:-------------------------------------------------------|
| 1                                              | Report Header displays information about the report,   |
|                                                | including the user who performed the case, the name of |
|                                                | the case performed, and the module that contains the   |
|                                                | performed case.                                        |
|                                                | The session number is displayed in the report header.  |
| 2                                              | Scoreboard displays information about your total score |
|                                                | for the task/case. For more information, see           |
|                                                | Understanding the scoreboard on page 90.               |
| 3                                              | Video options display options for viewing, downloading |
|                                                | and deleting the recorded video of your simulation     |
|                                                | performance. For more information, see Viewing         |
|                                                | recorded videos on page 86.                            |

[OCR]
Chapter 9 Viewing Performance Reports

8
>
[~ Benchmarks:
eal Te 022? a © —6
deiommel 5

Figure 9-2: Single-case report with benchmarks

1 Report Header displays information about the report,
including the user who performed the case, the name of
the case performed, and the module that contains the
performed case.

The session number is displayed in the report header.
2 Scoreboard displays information about your total score

for the task/case. For more information, see
Understanding the scoreboard on page 90.

3 Video options display options for viewing, downloading
and deleting the recorded video of your simulation
performance. For more information, see Viewing
recorded videos on page 86.

surgicalscience Page 83


# Page 93

Chapter 9 
 Viewing Performance Reports
 
Page 84
 
4 
Metric column: the metrics included in the report. The 
available categories and metrics vary between simulators 
and simulation modules and cases. 
If a report has benchmarks, metrics with a defined skill 
level appear in the Benchmark section at the top of the 
list.  
Press the Up arrow at the end of the metric’s row to hide 
the associated metrics; press the Down arrow at the end 
of the metric category’s row to display the metrics. 
5 
Result column: the result of the metrics as recorded 
during the user's performance of a simulation case. Press 
a result to display additional information. For a detailed 
explanation, see Viewing additional information on page 
85. 
6 
Score column: The score as calculated on a normalized 
scale of 1-5. For a detailed explanation, see 
Understanding benchmarks and rating scales on page 91. 
7 
Learning Curve Graph for a selected metric: a colorful 
graph is displayed on the right side of the Report screen 
if the user has completed two or more sessions of the 
specific simulation case. For a detailed explanation of the 
graph, see Understanding learning curve graphs on page 
92. 
Additional information if available such as a snapshot is 
displayed under the graph. 
8 
Print: press 
 to print the report to print the report. The 
button is located in the upper left corner of the screen. 
 


[TABLE]
| 4   | Metric column: the metrics included in the report. The      |
|:----|:------------------------------------------------------------|
|     | available categories and metrics vary between simulators    |
|     | and simulation modules and cases.                           |
|     | If a report has benchmarks, metrics with a defined skill    |
|     | level appear in the Benchmark section at the top of the     |
|     | list.                                                       |
|     | Press the Up arrow at the end of the metric’s row to hide   |
|     | the associated metrics; press the Down arrow at the end     |
|     | of the metric category’s row to display the metrics.        |
| 5   | Result column: the result of the metrics as recorded        |
|     | during the user's performance of a simulation case. Press   |
|     | a result to display additional information. For a detailed  |
|     | explanation, see Viewing additional information on page     |
|     | 85.                                                         |
| 6   | Score column: The score as calculated on a normalized       |
|     | scale of 1-5. For a detailed explanation, see               |
|     | Understanding benchmarks and rating scales on page 91.      |
| 7   | Learning Curve Graph for a selected metric: a colorful      |
|     | graph is displayed on the right side of the Report screen   |
|     | if the user has completed two or more sessions of the       |
|     | specific simulation case. For a detailed explanation of the |
|     | graph, see Understanding learning curve graphs on page      |
|     | 92.                                                         |
|     | Additional information if available such as a snapshot is   |
|     | displayed under the graph.                                  |
| 8   |                                                             |
|     | Print: press                                                |
|     |  to print the report to print the report. The               |
|     | button is located in the upper left corner of the screen.   |

[OCR]
Chapter 9

Viewing Performance Reports

Metric column: the metrics included in the report. The
available categories and metrics vary between simulators
and simulation modules and cases.

If a report has benchmarks, metrics with a defined skill
level appear in the Benchmark section at the top of the
list.

Press the Up arrow at the end of the metric’s row to hide
the associated metrics; press the Down arrow at the end
of the metric category’s row to display the metrics.

Result column: the result of the metrics as recorded
during the user's performance of a simulation case. Press
a result to display additional information. For a detailed
explanation, see Viewing additional information on page
85.

Score column: The score as calculated on a normalized
scale of 1-5. For a detailed explanation, see
Understanding benchmarks and rating scales on page 91.

Learning Curve Graph for a selected metric: a colorful
graph is displayed on the right side of the Report screen
if the user has completed two or more sessions of the
specific simulation case. For a detailed explanation of the
graph, see Understanding learning curve graphs on page
92.

Additional information if available such as a snapshot is
displayed under the graph.

Print: press Fic print the report to print the report. The
button is located in the upper left corner of the screen.

surgicalscience

Page 84


# Page 94

Chapter 9 
 Viewing Performance Reports
 
Page 85
 
Viewing additional information 
1.  Press a metric’s result or click Additional Info to display details about the metric 
such as how it is measured or a captured snapshot.  
 
2.  Double-click the captured snapshot to display it in a separate window. 
 
Figure 9-3: Snapshot viewed from single report 


[TABLE]
| Chapter 9                                                                                 | Viewing Performance Reports   |
|:------------------------------------------------------------------------------------------|:------------------------------|
| Viewing additional information                                                            |                               |
| 1.   Press a metric’s result or click Additional Info to display details about the metric |                               |
| such as how it is measured or a captured snapshot.                                        |                               |
| 2.   Double-click the captured snapshot to display it in a separate window.               |                               |
| F                                                                                         |                               |
| i                                                                                         |                               |
| gure 9-3: Snapshot viewed from single report                                              |                               |
|                                                                                           | Page 85                       |

[OCR]
Chapter 9 Viewing Performance Reports

Viewing additional information

1. Press a metric’s result or click Additional Info to display details about the metric
such as how it is measured or a captured snapshot.

Client Administrator

Video

Scope/Tool Handling

Safety Parameters

2. Double-click the captured snapshot to display it in a separate window.

x

Figure 9-3: Snapshot viewed from single report

surgicalscience Page 85


# Page 95

Chapter 9 
 Viewing Performance Reports
 
Page 86
 
Viewing recorded videos 
You can view a video of your simulation performance. You can download the video to 
review your performance at a later time or delete the recorded video. 
To view the performance video: 
1.  In the Video section of the report, press Video.  
The recorded video of your simulation case performance is displayed. 
 
2.  Double-click it to display in a separate window. 
 
Figure 9-4: Recorded video viewed from single report 


[TABLE]
| Chapter 9                                                                          | Viewing Performance Reports   |
|:-----------------------------------------------------------------------------------|:------------------------------|
| Viewing recorded videos                                                            |                               |
| You can view a video of your simulation performance. You can download the video to |                               |
| review your performance at a later time or delete the recorded video.              |                               |
| To view the performance video:                                                     |                               |
| 1.                                                                                 |                               |
| In the Video section of the report, press Video.                                   |                               |

[OCR]
Chapter 9 Viewing Performance Reports

Viewing recorded videos

You can view a video of your simulation performance. You can download the video to
review your performance at a later time or delete the recorded video.

To view the performance video:
1. In the Video section of the report, press Video.

The recorded video of your simulation case performance is displayed.

Client Administrator

Scope/Tool Handling

Safety Parameters

2. Double-click it to display in a separate window.

‘B30 SYSTEMS

fous Bw]

Figure 9-4: Recorded video viewed from single report

surgicalscience Page 86


# Page 96

Chapter 9 
 Viewing Performance Reports
 
Page 87
 
3.  Use the buttons under the video to play, pause, or view in full screen. 
4.  Press outside the video to close it and return to the single report. 
To download the performance video: 
1.  Press 
 in the top left corner of the screen and select Video>Download. 
OR 
Press 
 under the video and select Download Video. 
2.  Browse to select the file location where you want the video to be downloaded. 
3.  Press Save. 
The video is downloaded to the selected location. 
To delete the performance video: 
1.  Press 
 and select Video>Delete.  
The recorded video is deleted. 
Note: A message will appear when there is no more storage space for the recorded videos on 
your local drive. It is recommended to download those videos you wish to save to another 
drive on the computer or to an external drive (e.g. flash drive, or external hard disk) and 
then delete them.  
Browsing between sessions 
Use the Previous and Next arrows to browse between different report sessions. 
MentorLearn allows you to browse between the sessions performed of the same case 
within a certain course/module. Therefore, if a learner performed a case independently 
3 times for a module listed in the Library and then performed the same case an 
additional two times within the framework of a course, these sessions will not be linked 
together. The learner would need to browse separately between the sessions 
performed in the module and sessions performed within the framework of the course. 


[TABLE]
| Chapter 9                                                                    | Viewing Performance Reports                                                                 |
|:-----------------------------------------------------------------------------|:--------------------------------------------------------------------------------------------|
| 3.   Use the buttons under the video to play, pause, or view in full screen. |                                                                                             |
| 4.   Press outside the video to close it and return to the single report.    |                                                                                             |
| To download the performance video:                                           |                                                                                             |
| 1.   Press                                                                   | in the top left corner of the screen and select Video>Download.                             |
| OR                                                                           |                                                                                             |
| Press                                                                        | under the video and select Download Video.                                                  |
|                                                                              | 2.   Browse to select the file location where you want the video to be downloaded.          |
| 3.   Press Save.                                                             |                                                                                             |
| The video is downloaded to the selected location.                            |                                                                                             |
| To delete the performance video:                                             |                                                                                             |
| 1.   Press                                                                   | and select Video>Delete.                                                                    |
| The recorded video is deleted.                                               |                                                                                             |
|                                                                              | Note:  A message will appear when there is no more storage space for the recorded videos on |
|                                                                              | your local drive. It is recommended to download those videos you wish to save to another    |
|                                                                              | drive on the computer or to an external drive (e.g. flash drive, or external hard disk) and |
| then delete them.                                                            |                                                                                             |
| Browsing between sessions                                                    |                                                                                             |
|                                                                              | Use the Previous and Next arrows to browse between different report sessions.               |
|                                                                              | MentorLearn allows you to browse between the sessions performed of the same case            |
|                                                                              | within a certain course/module. Therefore, if a learner performed a case independently      |
|                                                                              | 3 times for a module listed in the Library and then performed the same case an              |
|                                                                              | additional two times within the framework of a course, these sessions will not be linked    |
|                                                                              | together. The learner would need to browse separately between the sessions                  |
|                                                                              | performed in the module and sessions performed within the framework of the course.          |
|                                                                              | Page 87                                                                                     |

[OCR_TABLE]
To downlo:

[OCR]
Chapter 9 Viewing Performance Reports

3. Use the buttons under the video to play, pause, or view in full screen.
4. Press outside the video to close it and return to the single report.

To download the performance video:

1. Press [3] in the top left corner of the screen and select Video>Download.
OR

Press | under the video and select Download Video.

Browse to select the file location where you want the video to be downloaded.
Press Save.

on

The video is downloaded to the selected location.

To delete the performance video:

1. Press | | and select Video>Delete.

The recorded video is deleted.

Note: A message will appear when there is no more storage space for the recorded videos on
your local drive. It is recommended to download those videos you wish to save to another
drive on the computer or to an external drive (e.g. flash drive, or external hard disk) and
then delete them.

Browsing between sessions

Use the Previous and Next arrows to browse between different report sessions.

MentorLearn allows you to browse between the sessions performed of the same case
within a certain course/module. Therefore, if a learner performed a case independently
3 times for a module listed in the Library and then performed the same case an
additional two times within the framework of a course, these sessions will not be linked
together. The learner would need to browse separately between the sessions
performed in the module and sessions performed within the framework of the course.

surgicalscience Page 87


# Page 97

Chapter 9 
 Viewing Performance Reports
 
Page 88
 
Additional report types 
Viewing user saved snapshots 
You can view saved snapshots and your comments relating to snapshots. 
1.  Press the underlined blue value in the result column of the Trainee Report. 
 
Figure 9-5: Trainee Report viewed from Reports screen 
2.  If upon completing a case and saving its performance you entered and saved 
comments relating to snapshots you took, you can later view them.  
Note: No editing of the text or deleting of the images is possible at this stage. 
3.  Use the arrows to browse through the snapshots. 
4.  Press Close. 


[TABLE]
| Chapter 9                                                                         |
|  Viewing Performance Reports                                                      |
|:----------------------------------------------------------------------------------|
| Additional report types                                                           |
| Viewing user saved snapshots                                                      |
| You can view saved snapshots and your comments relating to snapshots.             |
| 1.   Press the underlined blue value in the result column of the Trainee Report.  |
| F                                                                                 |
| i                                                                                 |
| gure 9-5: Trainee Report viewed from Reports screen                               |
| 2.                                                                                |
| If upon completing a case and saving its performance you entered and saved        |
| comments relating to snapshots you took, you can later view them.                 |
| Note: No editing of the text or deleting of the images is possible at this stage. |
| 3.   Use the arrows to browse through the snapshots.                              |
| 4.   Press Close.                                                                 |
| Page 88                                                                           |

[OCR]
Chapter 9 Viewing Performance Reports

Additional report types

Viewing user saved snapshots

You can view saved snapshots and your comments relating to snapshots.
1. Press the underlined blue value in the result column of the Trainee Report.
Case 5 Trainee Report

‘Scope positioned just below mid uretral stone

< 27 >

ight Ureter

Figure 9-5: Trainee Report viewed from Reports screen

2. If upon completing a case and saving its performance you entered and saved
comments relating to snapshots you took, you can later view them.

Note: No editing of the text or deleting of the images is possible at this stage.

3. Use the arrows to browse through the snapshots.
4. Press Close.

surgicalscience Page 88


# Page 98

Chapter 9 
 Viewing Performance Reports
 
Page 89
 
Viewing performance playback 
You can view a recording of your complete performance of the procedure. 
Note: Playback can be reviewed only on the simulator station on which it was performed.  
1.  Press the underlined blue PLAY in the result column of the Playback of performed 
procedure.  
The performance procedure playback begins playing. 
 
Figure 9-6: Playback screen viewed from the Reports page 
2.  The following actions are available in the Playback screen: 
• 
To pause the recording, press the Pause 
 button. 
• 
To play the recording, press the Play 
 button.  
• 
To wind back, press the Back 
 button. 
• 
To advance fast forward, press the Forward 
 button. 
3.  Press 
 to return to the Report page. 


[TABLE]
| Chapter 9   |                                                                                          | Viewing Performance Reports   |
|:------------|:-----------------------------------------------------------------------------------------|:------------------------------|
|             | Viewing performance playback                                                             |                               |
|             | You can view a recording of your complete performance of the procedure.                  |                               |
|             | Note:  Playback can be reviewed only on the simulator station on which it was performed. |                               |
|             | 1.   Press the underlined blue PLAY in the result column of the Playback of performed    |                               |
|             | procedure.                                                                               |                               |
|             | The performance procedure playback begins playing.                                       |                               |
|             | F                                                                                        |                               |
|             | i                                                                                        |                               |
|             | gure 9-6: Playback screen viewed from the Reports page                                   |                               |
|             | 2.   The following actions are available in the Playback screen:                         |                               |
| •           | To pause the recording, press the Pause                                                  |                               |
|             |  button.                                                                                 |                               |
| •           | To play the recording, press the Play                                                    |                               |
|             |  button.                                                                                 |                               |
| •           | To wind back, press the Back                                                             |                               |
|             |  button.                                                                                 |                               |
| •           | To advance fast forward, press the Forward                                               |                               |
|             |  button.                                                                                 |                               |
| 3.   Press  | to return to the Report page.                                                            |                               |
|             |                                                                                          | Page 89                       |

[OCR]
Chapter 9 Viewing Performance Reports

Viewing performance playback

You can view a recording of your complete performance of the procedure.

Note: Playback can be reviewed only on the simulator station on which it was performed.

1. Press the underlined blue PLAY in the result column of the Playback of performed
procedure.

The performance procedure playback begins playing.

Playback od

Rigid Cystoscope Total Time: 00:00:14 Fluoroscopy Time: 00:00:00

1 mmiig &

Figure 9-6: Playback screen viewed from the Reports page

2. The following actions are available in the Playback screen:

. To pause the recording, press the Pause Oo button.

e To play the recording, press the Play kX oS button.

. To wind back, press the Back i) button.

. To advance fast forward, press the Forward >) button.

3. Press to return to the Report page.

surgicalscience Page 89


# Page 99

Chapter 9 
 Viewing Performance Reports
 
Page 90
 
Understanding the scoreboard 
The benchmark scoreboard displays a summary of your performance in a clear and 
colorful way.  
 
Figure 9-7: Case benchmark scoreboard 
It includes the following components: 
• 
Proficient: shows if you reached the required skill level or not for the simulation 
case.  
• 
Best Score: is calculated as a weighted average of the scores for each of the 
benchmark metrics. In the above report, 86% = the average score of the metrics 
for the case/task (e.g. total time, total path, accuracy rate, horizontal view). The 
best score is displayed in a percentage.  
o 
The default is that the benchmarks have the same weights. However, the 
best score can be customized so that certain metrics have more weight 
than others. 
o 
Some metrics may be set as critical (must pass) and if you don’t pass the 
metric, you receive a total score of “Failed”. For example, if a case/task 
must be performed with no complications and 2 complications occurred, 
your total score would be “Failed”:  
• 
Non-consecutive: indicates how many times you need to attain the required skill 
level to achieve proficiency. For example, if you are required to achieve the skill 
level once and you accomplished it, your score would be Non-consecutive: 1 of 
1. 


[TABLE]
| F                                     |                                                                                      |
| i                                     |                                                                                      |
| gure 9-7: Case benchmark scoreboard   |                                                                                      |
|:--------------------------------------|:-------------------------------------------------------------------------------------|
| It includes the following components: |                                                                                      |
| •                                     | Proficient: shows if you reached the required skill level or not for the simulation  |
|                                       | case.                                                                                |
| •                                     | Best Score: is calculated as a weighted average of the scores for each of the        |
|                                       | benchmark metrics. In the above report, 86% = the average score of the metrics       |
|                                       | for the case/task (e.g. total time, total path, accuracy rate, horizontal view). The |
|                                       | best score is displayed in a percentage.                                             |

[TABLE]
| Best Score: is calculated as a weighted average of the scores for each of the        |
|:-------------------------------------------------------------------------------------|
| benchmark metrics. In the above report, 86% = the average score of the metrics       |
| for the case/task (e.g. total time, total path, accuracy rate, horizontal view). The |
| best score is displayed in a percentage.                                             |
| The default is that the benchmarks have the same weights. However, the               |
| o                                                                                    |
| best score can be customized so that certain metrics have more weight                |
| than others.                                                                         |
| Some metrics may be set as critical (must pass) and if you don’t pass the            |
| o                                                                                    |
| metric, you receive a total score of “Failed”. For example, if a case/task           |
| must be performed with no complications and 2 complications occurred,                |
| your total score would be “Failed”:                                                  |
| Non-consecutive: indicates how many times you need to attain the required skill      |

[OCR_TABLE]
Underst

[OCR_TABLE]
ine bencn

[OCR]
Chapter 9 Viewing Performance Reports

Understanding the scoreboard

The benchmark scoreboard displays a summary of your performance in a clear and
colorful way.

Case proficiency Proficiency established by: Default (Media

eco

Yes 2 0f 1 3
Proficient: Non consecutive: Attempts:

Figure 9-7: Case benchmark scoreboard

It includes the following components:

. Proficient: shows if you reached the required skill level or not for the simulation
case.

. Best Score: is calculated as a weighted average of the scores for each of the

benchmark metrics. In the above report, 86% = the average score of the metrics
for the case/task (e.g. total time, total path, accuracy rate, horizontal view). The
best score is displayed in a percentage.

° The default is that the benchmarks have the same weights. However, the
best score can be customized so that certain metrics have more weight
than others.

° Some metrics may be set as critical (must pass) and if you don’t pass the
metric, you receive a total score of “Failed”. For example, if a case/task
must be performed with no complications and 2 complications occurred,
your total score would be “Failed”:

. Non-consecutive: indicates how many times you need to attain the required skill
level to achieve proficiency. For example, if you are required to achieve the skill
level once and you accomplished it, your score would be Non-consecutive: 1 of
1.

surgicalscience Page 90


# Page 100

Chapter 9 
 Viewing Performance Reports
 
Page 91
 
• 
Consecutive: indicates how many consecutive times you are required to attain a 
skill level. For example, if you are required to achieve the skill level in two 
consecutive times and you succeeded the first time, the result would show 
Consecutive: 1 of 2. If you succeed in the next attempt, the score will show 
Consecutive: 2 of 2. If you failed at the second attempt, you would have to start 
again since the requirement is for 2 consecutive successful attempts. 
• 
Attempts: how many attempts/sessions/repetitions of this case you performed. 
 
The session components are displayed below the case/task components: 
 
Figure 9-8: Session benchmark scoreboard 
Proficient: shows if you reached the required skill level or not for this session of the 
case/task.  
Score: is calculated as a weighted average of the scores for each of the benchmark 
metrics for this session. In the above report, 86% = the average score of the metrics 
for the session (e.g. total time, total path, accuracy rate, horizontal view). The score is 
displayed in percentages.  
Understanding benchmarks and rating scales 
Metrics with a defined skill level appear in the Benchmark section. Each metric is 
displayed on a rating scale showing at a quick glance if you have passed or failed the 
required level for this metric.  


[TABLE]
| Viewing Performance Reports                                                       |
|:----------------------------------------------------------------------------------|
| Consecutive: indicates how many consecutive times you are required to attain a    |
| skill level. For example, if you are required to achieve the skill level in two   |
| consecutive times and you succeeded the first time, the result would show         |
| Consecutive: 1 of 2. If you succeed in the next attempt, the score will show      |
| Consecutive: 2 of 2. If you failed at the second attempt, you would have to start |
| again since the requirement is for 2 consecutive successful attempts.             |
| Attempts: how many attempts/sessions/repetitions of this case you performed.      |

[TABLE]
| F                                                                                           |
| i                                                                                           |
| gure 9-8: Session benchmark scoreboard                                                      |
|:--------------------------------------------------------------------------------------------|
| Proficient: shows if you reached the required skill level or not for this session of the    |
| case/task.                                                                                  |
| Score: is calculated as a weighted average of the scores for each of the benchmark          |
| metrics for this session. In the above report, 86% = the average score of the metrics       |
| for the session (e.g. total time, total path, accuracy rate, horizontal view). The score is |
| displayed in percentages.                                                                   |
| Understanding benchmarks and rating scales                                                  |
| Metrics with a defined skill level appear in the Benchmark section. Each metric is          |
| displayed on a rating scale showing at a quick glance if you have passed or failed the      |
| required level for this metric.                                                             |

[OCR_TABLE]
SWNT I

nanmrmr

[OCR]
Chapter 9 Viewing Performance Reports

. Consecutive: indicates how many consecutive times you are required to attain a
skill level. For example, if you are required to achieve the skill level in two
consecutive times and you succeeded the first time, the result would show
Consecutive: 1 of 2. If you succeed in the next attempt, the score will show
Consecutive: 2 of 2. If you failed at the second attempt, you would have to start
again since the requirement is for 2 consecutive successful attempts.

. Attempts: how many attempts/sessions/repetitions of this case you performed.

The session components are displayed below the case/task components:

Session proficiency

86%

Yes
Proficient Score

Figure 9-8: Session benchmark scoreboard

Proficient: shows if you reached the required skill level or not for this session of the
case/task.

Score: is calculated as a weighted average of the scores for each of the benchmark
metrics for this session. In the above report, 86% = the average score of the metrics
for the session (e.g. total time, total path, accuracy rate, horizontal view). The score is
displayed in percentages.

Understanding benchmarks and rating scales

Metrics with a defined skill level appear in the Benchmark section. Each metric is
displayed on a rating scale showing at a quick glance if you have passed or failed the
required level for this metric.

surgicalscience Page 91


# Page 101

Chapter 9 
 Viewing Performance Reports
 
Page 92
 
 
Figure 9-9: Benchmark rating scale 
The rating scale includes the following components: 
• 
Proficiency (where the score = exactly 4) is exactly the value for which the area 
turns from yellow to green. If your result is exactly or better than the proficiency 
value, your score falls in the green area. 
 
• 
If you are not proficient, your score is in the orange-yellow area: 
 
• 
Scores are calculated on a normalized scale of 1-5: 
o 
<2 = poor 
o 
2.0 - <4.0 = average 
o 
4.0 - <4.5 = expert (score = 4 exactly when you reach proficiency) 
o 
> 4.5 = superior 
• 
Press the rating scale; additional information is displayed in the right pane. 
Understanding learning curve graphs 
If you have completed two or more sessions of the specific simulation case, the graph 
shows the learning curve for the selected metric.  
Note: If benchmarks are defined, the graph is colored using the same color scheme as the 
rating scale. 
The y axis charts the results for the selected metric and the x axis charts the 
repetitions or attempts of this case. 


[TABLE]
| F                                                   |                                                                                      |
| i                                                   |                                                                                      |
| gure 9-9: Benchmark rating scale                    |                                                                                      |
|:----------------------------------------------------|:-------------------------------------------------------------------------------------|
| The rating scale includes the following components: |                                                                                      |
| •                                                   | Proficiency (where the score = exactly 4) is exactly the value for which the area    |
|                                                     | turns from yellow to green. If your result is exactly or better than the proficiency |
|                                                     | value, your score falls in the green area.                                           |
| •                                                   | If you are not proficient, your score is in the orange-yellow area:                  |
| •                                                   | Scores are calculated on a normalized scale of 1-5:                                  |

[OCR_TABLE]
DCHCIITial nk

[OCR]
Chapter 9 Viewing Performance Reports

Benchmarks s
Number of correct hits 10Hits EN © Score: 5.00
Accuracy rate- target hits (%) 100% NINN © Score: 5.00
Maintaining the horizontal view while using the 0° camera (%) 97.2% SMM — Score: 4.50
Total path length of camera (cm 126.6cm INH — Score: 4.29
Total time 00:00:51 NN ore: 5.00

Figure 9-9: Benchmark rating scale

The rating scale includes the following components:

. Proficiency (where the score = exactly 4) is exactly the value for which the area
turns from yellow to green. If your result is exactly or better than the proficiency

. 97.2%
value, your score falls in the green area.
. If you are not proficient, your score is in the orange-yellow area:

2Hits

. Scores are calculated on a normalized scale of 1-5:

<2 = poor

2.0 - <4.0 = average

4.0 - <4.5 = expert (score = 4 exactly when you reach proficiency)
> 4.5 = superior

. Press the rating scale; additional information is displayed in the right pane.

fe)
fe)
fe)
fe)

Understanding learning curve graphs

If you have completed two or more sessions of the specific simulation case, the graph

shows the learning curve for the selected metric.

Note: If benchmarks are defined, the graph is colored using the same color scheme as the
rating scale.

The y axis charts the results for the selected metric and the x axis charts the
repetitions or attempts of this case.

surgicalscience


# Page 102

Chapter 9 
 Viewing Performance Reports
 
Page 93
 
When benchmarks are defined, you can see your progress in attaining proficiency for 
the specific metric.  
Press a metric in order to display its graph. 
 
If the curve is the orange-yellow area, you haven’t achieved proficiency for this metric.  
If the curve is in the green area, you are proficient in this metric. 
 
Figure 9-10: Report's learning curve 


[TABLE]
| Chapter 9                                                             | Viewing Performance Reports                                                               |
|:----------------------------------------------------------------------|:------------------------------------------------------------------------------------------|
|                                                                       | When benchmarks are defined, you can see your progress in attaining proficiency for       |
| the specific metric.                                                  |                                                                                           |
| Press a metric in order to display its graph.                         |                                                                                           |
|                                                                       | If the curve is the orange-yellow area, you haven’t achieved proficiency for this metric. |
| If the curve is in the green area, you are proficient in this metric. |                                                                                           |

[OCR]
Chapter 9 Viewing Performance Reports

When benchmarks are defined, you can see your progress in attaining proficiency for
the specific metric.

Press a metric in order to display its graph.

10 Hits [ME — Score: 5.00

Number of correct hits

If the curve is the orange-yellow area, you haven't achieved proficiency for this metric.

If the curve is in the green area, you are proficient in this metric.

Number of correct hits

10
8
a 6
ew
2
# #2 #3
Sessions

*Only the sessions in which the event occurred are displayed

Figure 9-10: Report's learning curve

surgicalscience Page 93


# Page 103

Chapter 9 
 Viewing Performance Reports
 
Page 94
 
Exporting performance results 
Performance results can be exported to a file. The data is saved as CSV (comma 
separated values) file, which can be viewed using Microsoft® Excel®. 
To export data: 
1.  Press Reports on the MentorLearn menu to access the Reports screen. 
2.  Select the reports you want to export. 
3.  Press 
 and select Reports>Export Performance.  
 
Figure 9-11: Export Performance window 
4.  In the Export Performance window, define the format of the report as well as the 
time period that should be included in the exported file and press Export. 
5.  Select a location where MentorLearn will save the exported file, and then press 
Save. 
MentorLearn generates the performance data and saves the exported file in the 
specified location. 


[TABLE]
| Chapter 9                                   |                                                                                | Viewing Performance Reports   |
|:--------------------------------------------|:-------------------------------------------------------------------------------|:------------------------------|
| Exporting performance results               |                                                                                |                               |
|                                             | Performance results can be exported to a file. The data is saved as CSV (comma |                               |
|                                             | separated values) file, which can be viewed using Microsoft® Excel®.           |                               |
| To export data:                             |                                                                                |                               |
|                                             | 1.   Press Reports on the MentorLearn menu to access the Reports screen.       |                               |
| 2.   Select the reports you want to export. |                                                                                |                               |
| 3.   Press                                  | and select Reports>Export Performance.                                         |                               |

[TABLE]
|                                                                                      | F                                                                                |
|                                                                                      | i                                                                                |
|                                                                                      | gure 9-11: Export Performance window                                             |
|:-------------------------------------------------------------------------------------|:---------------------------------------------------------------------------------|
| 4.                                                                                   | In the Export Performance window, define the format of the report as well as the |
|                                                                                      | time period that should be included in the exported file and press Export.       |
| 5.   Select a location where MentorLearn will save the exported file, and then press |                                                                                  |
|                                                                                      | Save.                                                                            |
|                                                                                      | MentorLearn generates the performance data and saves the exported file in the    |
|                                                                                      | specified location.                                                              |

[OCR]
Chapter 9 Viewing Performance Reports

Exporting performance results

Performance results can be exported to a file. The data is saved as CSV (comma
separated values) file, which can be viewed using Microsoft® Excel®.

To export data:
1. Press Reports on the MentorLearn menu to access the Reports screen.
2. Select the reports you want to export.

3. Press 3 | and select Reports>Export Performance.

Export Performance x

Export Perform
2 selected

d Format

rows export ba

CO Export time in seconds

12/24/2020 a

1/24/2021 [3]

CANCEL EXPORT

Figure 9-11: Export Performance window

4. In the Export Performance window, define the format of the report as well as the
time period that should be included in the exported file and press Export.

5. Select a location where MentorLearn will save the exported file, and then press
Save.

MentorLearn generates the performance data and saves the exported file in the
specified location.

surgicalscience Page 94


# Page 104

Chapter 10 
 Technical Support
 
Page 95
 
Chapter 10 Technical Support 
SURGICAL SCIENCE SUPPORT POLICY 
Surgical Science assigns the highest priority to customer support. We are committed 
to doing our utmost to provide our clients with reliable support and assistance 24 
hours a day, 7 days a week. This support is available in real time via telephone or 
email. 
Surgical Science Call Center 
Customer service 24/7: +1-216-270-2020 
email: support@surgicalscience.com 
 


[TABLE]
| Chapter 10                                                                          | Technical Support   |
|:------------------------------------------------------------------------------------|:--------------------|
| Chapter 10 Technical Support                                                        |                     |
| SURGICAL SCIENCE SUPPORT POLICY                                                     |                     |
| Surgical Science assigns the highest priority to customer support. We are committed |                     |
| to doing our utmost to provide our clients with reliable support and assistance 24  |                     |
| hours a day, 7 days a week. This support is available in real time via telephone or |                     |
| email.                                                                              |                     |
| Surgical Science Call Center                                                        |                     |
| Customer service 24/7: +1-216-270-2020                                              |                     |
| email: support@surgicalscience.com                                                  |                     |

[OCR_TABLE]
Chapter 10

[OCR]
Chapter 10 Technical Support

| Chapter 10 Technical Support

SURGICAL SCIENCE SUPPORT POLICY

Surgical Science assigns the highest priority to customer support. We are committed
to doing our utmost to provide our clients with reliable support and assistance 24
hours a day, 7 days a week. This support is available in real time via telephone or
email.

Surgical Science Call Center

Customer service 24/7: +1-216-270-2020

email: support@surgicalscience.com

surgicalscience Page 95


# Page 105

Chapter 11 
 End-User Software License Agreement
 
Page 96
 
Chapter 11 End-User Software License 
Agreement 
URO Mentor® 
1.  DEFINITIONS 
This End-User License Agreement ("Agreement") is a legal agreement between you 
(either an individual or a single entity) and Surgical Science Sweden AB ("Surgical 
Science") for URO Mentor® or such upgrade or future versions thereof identified in the 
Particulars or the License Key Issue Note, which includes computer software and may 
include associated media, printed materials, and electronic documentation 
("Software"). 
 
11.  GRANT 
Surgical Science hereby grants to you a non-exclusive, non-transferable license to 
install and use one copy of the Software, or any prior version for the same operating 
system in accordance with the applicable license type (the type of license in your case 
can be found in the order form / invoice as well as in the License Key Issue Note from 
Surgical Science). The License hereby granted is subject to the following conditions. 
 
111.  CONDITIONS 
1  EXTENT OF LICENSE 
1.1  If you have acquired a hardware identity-based license you may install and use one 
copy of the Software, or any prior version for the same operating system on the single 
computer for which the License Key is issued. 


[TABLE]
| Chapter 11           |                                                                                         | End-User Software License Agreement   |
|:---------------------|:----------------------------------------------------------------------------------------|:--------------------------------------|
|                      | Chapter 11 End-User Software License                                                    |                                       |
|                      | Agreement                                                                               |                                       |
| URO Mentor®          |                                                                                         |                                       |
| 1.  DEFINITIONS      |                                                                                         |                                       |
|                      | This End-User License Agreement ("Agreement") is a legal agreement between you          |                                       |
|                      | (either an individual or a single entity) and Surgical Science Sweden AB ("Surgical     |                                       |
|                      | Science") for URO Mentor® or such upgrade or future versions thereof identified in the  |                                       |
|                      | Particulars or the License Key Issue Note, which includes computer software and may     |                                       |
|                      | include associated media, printed materials, and electronic documentation               |                                       |
| ("Software").        |                                                                                         |                                       |
| 1                    |                                                                                         |                                       |
| 1.  GRANT            |                                                                                         |                                       |
|                      | Surgical Science hereby grants to you a non-exclusive, non-transferable license to      |                                       |
|                      | install and use one copy of the Software, or any prior version for the same operating   |                                       |
|                      | system in accordance with the applicable license type (the type of license in your case |                                       |
|                      | can be found in the order form / invoice as well as in the License Key Issue Note from  |                                       |
|                      | Surgical Science). The License hereby granted is subject to the following conditions.   |                                       |
| 1                    |                                                                                         |                                       |
| 11.  CONDITIONS      |                                                                                         |                                       |
| 1  EXTENT OF LICENSE |                                                                                         |                                       |
|                      | 1.1  If you have acquired a hardware identity-based license you may install and use one |                                       |
|                      | copy of the Software, or any prior version for the same operating system on the single  |                                       |
|                      | computer for which the License Key is issued.                                           |                                       |
|                      |                                                                                         | Page 96                               |

[OCR]
Chapter 11 End-User Software License Agreement

Chapter 11 End-User Software License
Agreement

URO Mentor®

1. DEFINITIONS

This End-User License Agreement ("Agreement") is a legal agreement between you
(either an individual or a single entity) and Surgical Science Sweden AB ("Surgical
Science") for URO Mentor® or such upgrade or future versions thereof identified in the
Particulars or the License Key Issue Note, which includes computer software and may
include associated media, printed materials, and electronic documentation
("Software").

11. GRANT

Surgical Science hereby grants to you a non-exclusive, non-transferable license to
install and use one copy of the Software, or any prior version for the same operating
system in accordance with the applicable license type (the type of license in your case
can be found in the order form / invoice as well as in the License Key Issue Note from
Surgical Science). The License hereby granted is subject to the following conditions.

111. CONDITIONS
1 EXTENT OF LICENSE

1.1 If you have acquired a hardware identity-based license you may install and use one
copy of the Software, or any prior version for the same operating system on the single
computer for which the License Key is issued.

surgicalscience Page 96


# Page 106

Chapter 11 
 End-User Software License Agreement
 
Page 97
 
1.2  If you have acquired a hardware key ("dongle") based node locked license you 
may install and use one copy of the Software, or any prior version for the same 
operating system on the single computer to which the Hardware Key, for which the 
License Key is issued, is attached. Note that you are not obligated to remove the 
installed Software from the computer even if the Hardware Key is removed. However, 
you are not entitled to use the Software on that computer unless the Hardware key is 
reattached. 
1.3  If you have acquired a floating license, you may install one copy of the Software or 
any prior version for the same operating system on any number of computers and 
simultaneously use no more than the number of Software permitted in the License Key 
Issue Note. The rights of installation and use of Software is restricted to the site 
defined in the License Key Issue Note. 
1.4  If the Software is labeled as an upgrade, you must be properly licensed to use a 
product identified by Surgical Science as being eligible for the upgrade in order to use 
the Software. Software labeled as an upgrade replaces and/or supplements the 
product that formed the basis for your eligibility for the upgrade. You may use the 
resulting upgraded product only in accordance with the terms of this Agreement. 
1.5  If the Software is labeled as an upgrade, you must be properly licensed to use a 
product identified by Surgical Science as being eligible for the upgrade in order to use 
the Software. Software labeled as an upgrade replaces and/or supplements the 
product that formed the basis for your eligibility for the upgrade. You may use the 
resulting upgraded product only in accordance with the terms of this Agreement. 
1.6  This license is personal to you and you shall not assign or transfer any interest in it 
or grant any right under it to any third party or seek to exercise this license for the 
benefit or on the data of any third party. 
2  CONFIDENCE OF THE SOFTWARE AND COPYRIGHT 
2.1  The Software, all associated documentation, and all copies are secret and 
confidential to Surgical Science and shall be retained under the effective control of you 
during the period of this Agreement. Disclosures shall be limited to those members of 
your staff (including temporary staff) who need access to the Software to enable you 
to exercise this license. You shall take all measures necessary to maintain confidence 
and secrecy in the Software during the period of this license and after its termination, 
however such termination may arise. 


[TABLE]
| Chapter 11                                                                              | End-User Software License Agreement                                                          |
|:----------------------------------------------------------------------------------------|:---------------------------------------------------------------------------------------------|
| 1.2  If you have acquired a hardware key ("dongle") based node locked license you       |                                                                                              |
| may install and use one copy of the Software, or any prior version for the same         |                                                                                              |
| operating system on the single computer to which the Hardware Key, for which the        |                                                                                              |
| License Key is issued, is attached. Note that you are not obligated to remove the       |                                                                                              |
|                                                                                         | installed Software from the computer even if the Hardware Key is removed. However,           |
|                                                                                         | you are not entitled to use the Software on that computer unless the Hardware key is         |
| reattached.                                                                             |                                                                                              |
|                                                                                         | 1.3  If you have acquired a floating license, you may install one copy of the Software or    |
| any prior version for the same operating system on any number of computers and          |                                                                                              |
|                                                                                         | simultaneously use no more than the number of Software permitted in the License Key          |
| Issue Note. The rights of installation and use of Software is restricted to the site    |                                                                                              |
| defined in the License Key Issue Note.                                                  |                                                                                              |
| 1.4  If the Software is labeled as an upgrade, you must be properly licensed to use a   |                                                                                              |
|                                                                                         | product identified by Surgical Science as being eligible for the upgrade in order to use     |
| the Software. Software labeled as an upgrade replaces and/or supplements the            |                                                                                              |
| product that formed the basis for your eligibility for the upgrade. You may use the     |                                                                                              |
| resulting upgraded product only in accordance with the terms of this Agreement.         |                                                                                              |
| 1.5  If the Software is labeled as an upgrade, you must be properly licensed to use a   |                                                                                              |
|                                                                                         | product identified by Surgical Science as being eligible for the upgrade in order to use     |
| the Software. Software labeled as an upgrade replaces and/or supplements the            |                                                                                              |
| product that formed the basis for your eligibility for the upgrade. You may use the     |                                                                                              |
| resulting upgraded product only in accordance with the terms of this Agreement.         |                                                                                              |
|                                                                                         | 1.6  This license is personal to you and you shall not assign or transfer any interest in it |
| or grant any right under it to any third party or seek to exercise this license for the |                                                                                              |
| benefit or on the data of any third party.                                              |                                                                                              |
| 2  CONFIDENCE OF THE SOFTWARE AND COPYRIGHT                                             |                                                                                              |
| 2.1  The Software, all associated documentation, and all copies are secret and          |                                                                                              |
|                                                                                         | confidential to Surgical Science and shall be retained under the effective control of you    |
|                                                                                         | during the period of this Agreement. Disclosures shall be limited to those members of        |
|                                                                                         | your staff (including temporary staff) who need access to the Software to enable you         |
|                                                                                         | to exercise this license. You shall take all measures necessary to maintain confidence       |
|                                                                                         | and secrecy in the Software during the period of this license and after its termination,     |
| however such termination may arise.                                                     |                                                                                              |

[OCR_TABLE]
Chapter 11

[OCR_TABLE]
1.2 If you |

[OCR_TABLE]
License Ke
inetallad Cc

[OCR]
Chapter 11 End-User Software License Agreement

1.2 If you have acquired a hardware key ("dongle") based node locked license you
may install and use one copy of the Software, or any prior version for the same
operating system on the single computer to which the Hardware Key, for which the
License Key is issued, is attached. Note that you are not obligated to remove the
installed Software from the computer even if the Hardware Key is removed. However,
you are not entitled to use the Software on that computer unless the Hardware key is
reattached.

1.3 If you have acquired a floating license, you may install one copy of the Software or
any prior version for the same operating system on any number of computers and
simultaneously use no more than the number of Software permitted in the License Key
Issue Note. The rights of installation and use of Software is restricted to the site
defined in the License Key Issue Note.

1.4 If the Software is labeled as an upgrade, you must be properly licensed to use a
product identified by Surgical Science as being eligible for the upgrade in order to use
the Software. Software labeled as an upgrade replaces and/or supplements the
product that formed the basis for your eligibility for the upgrade. You may use the
resulting upgraded product only in accordance with the terms of this Agreement.

1.5 If the Software is labeled as an upgrade, you must be properly licensed to use a
product identified by Surgical Science as being eligible for the upgrade in order to use
the Software. Software labeled as an upgrade replaces and/or supplements the
product that formed the basis for your eligibility for the upgrade. You may use the
resulting upgraded product only in accordance with the terms of this Agreement.

1.6 This license is personal to you and you shall not assign or transfer any interest in it
or grant any right under it to any third party or seek to exercise this license for the
benefit or on the data of any third party.

2 CONFIDENCE OF THE SOFTWARE AND COPYRIGHT

2.1 The Software, all associated documentation, and all copies are secret and
confidential to Surgical Science and shall be retained under the effective control of you
during the period of this Agreement. Disclosures shall be limited to those members of
your staff (including temporary staff) who need access to the Software to enable you
to exercise this license. You shall take all measures necessary to maintain confidence
and secrecy in the Software during the period of this license and after its termination,
however such termination may arise.

surgicalscience Page 97


# Page 107

Chapter 11 
 End-User Software License Agreement
 
Page 98
 
2.2  All title and copyrights and patents in and to the Software (including but not 
limited to any images, photographs, animations, video, audio, music, text, techniques 
and "applets" incorporated into the Software), the accompanying printed materials, 
and any copies of the Software are owned by Surgical Science or its suppliers. The 
Software is protected by copyright laws and patents laws as well as by international 
treaty provisions. Therefore, you must treat the Software like any other copyrighted or 
patented material. You may not copy the printed materials accompanying the 
Software. 
3  OWNERSHIP OF SOFTWARE 
3.1  Subject to the rights granted to you by this Agreement, you acknowledge that all 
and any proprietary rights in the software (including but not limited to copyrights, 
patents, trademarks and trade secrets) and in all associated documentation and other 
material related to the Software in each case now existing or to be developed by 
Surgical Science shall remain the sole property of Surgical Science. 
3.2  Usage Data. You acknowledge and agree that Surgical Science may derive or 
create data and information about the use of the Software by you and your users 
("Usage Data") and Surgical Science may use and disclose Usage Data to its third-
party service providers in order to improve the Software. Personal data related to any 
identifiable individual is not collected by Surgical Science. 
4  SUPPORT SERVICES 
4.1  Surgical Science may provide you with support services related to the Software 
("Support Services"). Use of Support Services is governed by the Surgical Science 
policies and programs described in the user manual, in "online" documentation, and/or 
in other Surgical Science-provided materials. Any supplemental software provided to 
you as part of the Support Services shall be considered part of the Software and 
subject to the terms and conditions of this Agreement. With respect to technical 
information you provide to Surgical Science as part of the Support Services, Surgical 
Science may use such information for its business purposes, including for product 
support and development. Surgical Science will not utilize such technical information in 
a form that personally identifies you. 


[TABLE]
| Chapter 11                                                                           | End-User Software License Agreement                                                      |
|:-------------------------------------------------------------------------------------|:-----------------------------------------------------------------------------------------|
| 2.2  All title and copyrights and patents in and to the Software (including but not  |                                                                                          |
|                                                                                      | limited to any images, photographs, animations, video, audio, music, text, techniques    |
| and "applets" incorporated into the Software), the accompanying printed materials,   |                                                                                          |
| and any copies of the Software are owned by Surgical Science or its suppliers. The   |                                                                                          |
|                                                                                      | Software is protected by copyright laws and patents laws as well as by international     |
|                                                                                      | treaty provisions. Therefore, you must treat the Software like any other copyrighted or  |
| patented material. You may not copy the printed materials accompanying the           |                                                                                          |
| Software.                                                                            |                                                                                          |
| 3  OWNERSHIP OF SOFTWARE                                                             |                                                                                          |
|                                                                                      | 3.1  Subject to the rights granted to you by this Agreement, you acknowledge that all    |
| and any proprietary rights in the software (including but not limited to copyrights, |                                                                                          |
|                                                                                      | patents, trademarks and trade secrets) and in all associated documentation and other     |
| material related to the Software in each case now existing or to be developed by     |                                                                                          |
| Surgical Science shall remain the sole property of Surgical Science.                 |                                                                                          |
| 3.2  Usage Data. You acknowledge and agree that Surgical Science may derive or       |                                                                                          |
| create data and information about the use of the Software by you and your users      |                                                                                          |
| ("Usage Data") and Surgical Science may use and disclose Usage Data to its third-    |                                                                                          |
|                                                                                      | party service providers in order to improve the Software. Personal data related to any   |
| identifiable individual is not collected by Surgical Science.                        |                                                                                          |
| 4  SUPPORT SERVICES                                                                  |                                                                                          |
| 4.1  Surgical Science may provide you with support services related to the Software  |                                                                                          |
| ("Support Services"). Use of Support Services is governed by the Surgical Science    |                                                                                          |
|                                                                                      | policies and programs described in the user manual, in "online" documentation, and/or    |
|                                                                                      | in other Surgical Science-provided materials. Any supplemental software provided to      |
| you as part of the Support Services shall be considered part of the Software and     |                                                                                          |
| subject to the terms and conditions of this Agreement. With respect to technical     |                                                                                          |
|                                                                                      | information you provide to Surgical Science as part of the Support Services, Surgical    |
| Science may use such information for its business purposes, including for product    |                                                                                          |
|                                                                                      | support and development. Surgical Science will not utilize such technical information in |
| a form that personally identifies you.                                               |                                                                                          |

[OCR_TABLE]
2.2 All title

[OCR_TABLE]
and "apple
and any co

[OCR]
Chapter 11 End-User Software License Agreement

2.2 All title and copyrights and patents in and to the Software (including but not
limited to any images, photographs, animations, video, audio, music, text, techniques
and "applets" incorporated into the Software), the accompanying printed materials,
and any copies of the Software are owned by Surgical Science or its suppliers. The
Software is protected by copyright laws and patents laws as well as by international
treaty provisions. Therefore, you must treat the Software like any other copyrighted or
patented material. You may not copy the printed materials accompanying the
Software.

3 OWNERSHIP OF SOFTWARE

3.1 Subject to the rights granted to you by this Agreement, you acknowledge that all
and any proprietary rights in the software (including but not limited to copyrights,
patents, trademarks and trade secrets) and in all associated documentation and other
material related to the Software in each case now existing or to be developed by
Surgical Science shall remain the sole property of Surgical Science.

3.2 Usage Data. You acknowledge and agree that Surgical Science may derive or
create data and information about the use of the Software by you and your users
("Usage Data") and Surgical Science may use and disclose Usage Data to its third-
party service providers in order to improve the Software. Personal data related to any
identifiable individual is not collected by Surgical Science.

4 SUPPORT SERVICES

4.1 Surgical Science may provide you with support services related to the Software
("Support Services"). Use of Support Services is governed by the Surgical Science
policies and programs described in the user manual, in "online" documentation, and/or
in other Surgical Science-provided materials. Any supplemental software provided to
you as part of the Support Services shall be considered part of the Software and
subject to the terms and conditions of this Agreement. With respect to technical
information you provide to Surgical Science as part of the Support Services, Surgical
Science may use such information for its business purposes, including for product
support and development. Surgical Science will not utilize such technical information in
a form that personally identifies you.

surgicalscience Page 98


# Page 108

Chapter 11 
 End-User Software License Agreement
 
Page 99
 
5  INTEGRITY OF THE SOFTWARE 
5.1  You shall not, directly or indirectly in any form or manner, copy, distribute, 
reproduce, incorporate or allow unauthorized use or access to the Software or modify, 
decompile, reverse engineer, disassemble or otherwise attempt to derive a source 
code or similar information from Software, except as explicitly permitted under this 
Agreement. 
5.2  The Software is licensed as a single product. Its component parts may not be 
separated for use on more than one computer. 
5.3  You shall ensure that all copies of and extracts from the Software and its 
associated documentation made or disclosed by you carry Surgical Science’ copyright 
notice in the form shown on the original, or such other copyright notices as Surgical 
Science may specify from time to time and shall ensure that no such notice is deleted. 
6  RIGHT OF ACCESS 
6.1  For the purpose only of verifying your compliance with these conditions, you 
hereby irrevocable grants permission for Surgical Science and its authorized 
representatives during normal business hours to enter the premises from time to time 
wholly or partly occupied by you and in each case there to access, operate, and 
inspect computer equipment and to access, inspect and take copies of documents and 
records (including magnetic and other media). Surgical Science shall exercise this right 
only for the above purpose and shall observe strict confidence in all information which 
it obtains as a result of such inspections except to the extent that disclosure to third 
parties is necessary for the purposes of protecting Surgical Science’ rights in the 
Software. 


[TABLE]
| Chapter 11                                                                            | End-User Software License Agreement                                                      |
|:--------------------------------------------------------------------------------------|:-----------------------------------------------------------------------------------------|
| 5  INTEGRITY OF THE SOFTWARE                                                          |                                                                                          |
| 5.1  You shall not, directly or indirectly in any form or manner, copy, distribute,   |                                                                                          |
|                                                                                       | reproduce, incorporate or allow unauthorized use or access to the Software or modify,    |
| decompile, reverse engineer, disassemble or otherwise attempt to derive a source      |                                                                                          |
| code or similar information from Software, except as explicitly permitted under this  |                                                                                          |
| Agreement.                                                                            |                                                                                          |
| 5.2  The Software is licensed as a single product. Its component parts may not be     |                                                                                          |
| separated for use on more than one computer.                                          |                                                                                          |
| 5.3  You shall ensure that all copies of and extracts from the Software and its       |                                                                                          |
|                                                                                       | associated documentation made or disclosed by you carry Surgical Science’ copyright      |
| notice in the form shown on the original, or such other copyright notices as Surgical |                                                                                          |
|                                                                                       | Science may specify from time to time and shall ensure that no such notice is deleted.   |
| 6  RIGHT OF ACCESS                                                                    |                                                                                          |
| 6.1  For the purpose only of verifying your compliance with these conditions, you     |                                                                                          |
| hereby irrevocable grants permission for Surgical Science and its authorized          |                                                                                          |
|                                                                                       | representatives during normal business hours to enter the premises from time to time     |
| wholly or partly occupied by you and in each case there to access, operate, and       |                                                                                          |
|                                                                                       | inspect computer equipment and to access, inspect and take copies of documents and       |
|                                                                                       | records (including magnetic and other media). Surgical Science shall exercise this right |
|                                                                                       | only for the above purpose and shall observe strict confidence in all information which  |
|                                                                                       | it obtains as a result of such inspections except to the extent that disclosure to third |
| parties is necessary for the purposes of protecting Surgical Science’ rights in the   |                                                                                          |
| Software.                                                                             |                                                                                          |

[OCR_TABLE]
5 INTEGRI

[OCR]
Chapter 11 End-User Software License Agreement

5 INTEGRITY OF THE SOFTWARE

5.1 You shall not, directly or indirectly in any form or manner, copy, distribute,
reproduce, incorporate or allow unauthorized use or access to the Software or modify,
decompile, reverse engineer, disassemble or otherwise attempt to derive a source
code or similar information from Software, except as explicitly permitted under this
Agreement.

5.2 The Software is licensed as a single product. Its component parts may not be
separated for use on more than one computer.

5.3 You shall ensure that all copies of and extracts from the Software and its
associated documentation made or disclosed by you carry Surgical Science’ copyright
notice in the form shown on the original, or such other copyright notices as Surgical
Science may specify from time to time and shall ensure that no such notice is deleted.

6 RIGHT OF ACCESS

6.1 For the purpose only of verifying your compliance with these conditions, you
hereby irrevocable grants permission for Surgical Science and its authorized
representatives during normal business hours to enter the premises from time to time
wholly or partly occupied by you and in each case there to access, operate, and
inspect computer equipment and to access, inspect and take copies of documents and
records (including magnetic and other media). Surgical Science shall exercise this right
only for the above purpose and shall observe strict confidence in all information which
it obtains as a result of such inspections except to the extent that disclosure to third
parties is necessary for the purposes of protecting Surgical Science’ rights in the
Software.

surgicalscience Page 99


# Page 109

Chapter 11 
 End-User Software License Agreement
 
Page 100
 
7  WARRANTY AND LIMITATION OF LIABILITY 
7.1  Surgical Science warrants that (i) the Software will perform substantially in 
accordance with the accompanying written materials for a period of ninety (90) days 
from the date of receipt, and (ii) any Support Services provided by Surgical Science 
shall be substantially as described in applicable written materials provided to you by 
Surgical Science, and Surgical Science support engineers will make commercially 
reasonable efforts to solve any problem issues. Some jurisdictions do not allow 
limitations on duration of an implied warranty, so the above limitation may not apply to 
you. To the extent allowed by applicable law, implied warranties on the Software, if 
any, are limited to ninety (90) days. 
The above said warranty is void if failure of the Software has resulted from accident, 
abuse, or misapplication. Any replacement Software will be warranted for the 
remainder of the original warranty period or thirty (30) days, whichever is longer. 
Neither these remedies nor any Support Services offered by Surgical Science are 
available without proof of purchase from an authorized source. 
7.2  To the maximum extent permitted by applicable law, Surgical Science and its 
suppliers disclaim all other warranties and conditions, either express or implied, 
including, but not limited to, implied warranties of fitness for a particular purpose, title, 
and non-infringement, with regard to the Software, and the provision of or failure to 
provide Support Services. 
7.3  To the maximum extent permitted by applicable law, in no event shall Surgical 
Science or its suppliers be liable for any special, incidental, indirect, or consequential 
damages whatsoever (including, without limitation, damages for loss of business 
profits, business interruption or loss of business information) arising out of the use of 
or inability to use the Software or the provision of or failure to provide Support 
Services. However, if you have entered into a Surgical Science Support Services 
agreement, Surgical Science’ entire liability regarding Support Services shall be 
governed by the terms of that agreement. 
7.4  Surgical Science’ entire liability under any provision of this Agreement and your 
exclusive remedy shall be, at Surgical Science’ sole discretion to, either (i) return of the 
amount actually paid by you for the Software, if any, or (ii) repair or replacement of the 
Software that does not meet Surgical Science’ warranty and which is returned to 
Surgical Science with a copy of your receipt. 


[TABLE]
| Chapter 11                                                                             | End-User Software License Agreement                                                           |
|:---------------------------------------------------------------------------------------|:----------------------------------------------------------------------------------------------|
| 7  WARRANTY AND LIMITATION OF LIABILITY                                                |                                                                                               |
| 7.1  Surgical Science warrants that (i) the Software will perform substantially in     |                                                                                               |
|                                                                                        | accordance with the accompanying written materials for a period of ninety (90) days           |
| from the date of receipt, and (ii) any Support Services provided by Surgical Science   |                                                                                               |
|                                                                                        | shall be substantially as described in applicable written materials provided to you by        |
| Surgical Science, and Surgical Science support engineers will make commercially        |                                                                                               |
| reasonable efforts to solve any problem issues. Some jurisdictions do not allow        |                                                                                               |
|                                                                                        | limitations on duration of an implied warranty, so the above limitation may not apply to      |
| you. To the extent allowed by applicable law, implied warranties on the Software, if   |                                                                                               |
| any, are limited to ninety (90) days.                                                  |                                                                                               |
|                                                                                        | The above said warranty is void if failure of the Software has resulted from accident,        |
| abuse, or misapplication. Any replacement Software will be warranted for the           |                                                                                               |
| remainder of the original warranty period or thirty (30) days, whichever is longer.    |                                                                                               |
| Neither these remedies nor any Support Services offered by Surgical Science are        |                                                                                               |
| available without proof of purchase from an authorized source.                         |                                                                                               |
| 7.2  To the maximum extent permitted by applicable law, Surgical Science and its       |                                                                                               |
| suppliers disclaim all other warranties and conditions, either express or implied,     |                                                                                               |
|                                                                                        | including, but not limited to, implied warranties of fitness for a particular purpose, title, |
| and non-infringement, with regard to the Software, and the provision of or failure to  |                                                                                               |
| provide Support Services.                                                              |                                                                                               |
| 7.3  To the maximum extent permitted by applicable law, in no event shall Surgical     |                                                                                               |
|                                                                                        | Science or its suppliers be liable for any special, incidental, indirect, or consequential    |
| damages whatsoever (including, without limitation, damages for loss of business        |                                                                                               |
|                                                                                        | profits, business interruption or loss of business information) arising out of the use of     |
| or inability to use the Software or the provision of or failure to provide Support     |                                                                                               |
| Services. However, if you have entered into a Surgical Science Support Services        |                                                                                               |
| agreement, Surgical Science’ entire liability regarding Support Services shall be      |                                                                                               |
| governed by the terms of that agreement.                                               |                                                                                               |
| 7.4  Surgical Science’ entire liability under any provision of this Agreement and your |                                                                                               |
|                                                                                        | exclusive remedy shall be, at Surgical Science’ sole discretion to, either (i) return of the  |
|                                                                                        | amount actually paid by you for the Software, if any, or (ii) repair or replacement of the    |
| Software that does not meet Surgical Science’ warranty and which is returned to        |                                                                                               |
| Surgical Science with a copy of your receipt.                                          |                                                                                               |

[OCR_TABLE]
Chapter 11

[OCR_TABLE]
7 WARRAT

[OCR_TABLE]
IA Qiyirnin

[OCR_TABLE]
fe —h—e ws

accordanc

[OCR]
Chapter 11 End-User Software License Agreement

7 WARRANTY AND LIMITATION OF LIABILITY

7.1 Surgical Science warrants that (i) the Software will perform substantially in
accordance with the accompanying written materials for a period of ninety (90) days
from the date of receipt, and (ii) any Support Services provided by Surgical Science
shall be substantially as described in applicable written materials provided to you by
Surgical Science, and Surgical Science support engineers will make commercially
reasonable efforts to solve any problem issues. Some jurisdictions do not allow
limitations on duration of an implied warranty, so the above limitation may not apply to
you. To the extent allowed by applicable law, implied warranties on the Software, if
any, are limited to ninety (90) days.

The above said warranty is void if failure of the Software has resulted from accident,
abuse, or misapplication. Any replacement Software will be warranted for the
remainder of the original warranty period or thirty (30) days, whichever is longer.
Neither these remedies nor any Support Services offered by Surgical Science are
available without proof of purchase from an authorized source.

7.2 To the maximum extent permitted by applicable law, Surgical Science and its
suppliers disclaim all other warranties and conditions, either express or implied,
including, but not limited to, implied warranties of fitness for a particular purpose, title,
and non-infringement, with regard to the Software, and the provision of or failure to
provide Support Services.

7.3 To the maximum extent permitted by applicable law, in no event shall Surgical
Science or its suppliers be liable for any special, incidental, indirect, or consequential
damages whatsoever (including, without limitation, damages for loss of business
profits, business interruption or loss of business information) arising out of the use of
or inability to use the Software or the provision of or failure to provide Support
Services. However, if you have entered into a Surgical Science Support Services
agreement, Surgical Science’ entire liability regarding Support Services shall be
governed by the terms of that agreement.

7.4 Surgical Science’ entire liability under any provision of this Agreement and your
exclusive remedy shall be, at Surgical Science’ sole discretion to, either (i) return of the
amount actually paid by you for the Software, if any, or (ii) repair or replacement of the
Software that does not meet Surgical Science’ warranty and which is returned to
Surgical Science with a copy of your receipt.

surgicalscience Page 100


# Page 110

Chapter 11 
 End-User Software License Agreement
 
Page 101
 
8  TERMINATION 
8.1  If this license is a Trial license, you shall be entitled to return the Software to 
Surgical Science on or before Trial Expiry Date specified in the License Key Issue Note 
and, in that event, this Agreement shall then terminate. Unless otherwise agreed under 
special conditions, no license fee or other charges shall be payable by you in respect 
of the trial. 
8.2  Unless terminated pursuant to 8.3 below this Agreement shall continue until the 
expiry date, if any, specified in the Particulars or the License Key Issue Note. 
8.3  This Agreement may be terminated by Surgical Science at any time by written 
notice of termination: 
8.3.1.  if you shall expressly or impliedly repudiate this license by refusing or 
threatening to refuse to observe any of the conditions to which this license is subject; 
or 
8.3.2  if you shall fail to make payment of any amount due to and invoiced by Surgical 
Science or to observe any of the conditions to which this license is subject and, after 
your attention has been drawn by notice to such failure, shall fail to remedy the matter 
to Surgical Science's reasonable satisfaction within thirty days of the giving or such 
notice; or 
8.3.3  if you shall have a receiver or administrative receiver or administrator appointed 
or shall enter into liquidation whether compulsory or voluntary or if you or any member 
of your partnership shall be unable to pay its debts as and when they fall due or any 
judgment or execution or other process issued in respect of any judgment against you 
is unsatisfied for fourteen days. 
8.4  On expiry, surrender or other termination of this Agreement, however such 
termination may arise, you shall cease to load, store, copy or use the Software, shall 
delete the Software from the any computers on which the Software is installed or 
copied and at Surgical Science's option shall either surrender the Software and all 
documentation and other related materials to Surgical Science or shall destroy the 
Software with all documentation and other related materials and deliver to Surgical 
Science a certificate of comprehensive destruction. You shall continue after 
termination to observe and enforce confidence and secrecy in respect of the Software 
and its documentation and related materials for the benefit of Surgical Science, and 
however termination may occur it shall not prejudice any right of action or remedy 
which may have accrued prior to termination. 


[TABLE]
| Chapter 11                                                                               | End-User Software License Agreement                                                       |
|:-----------------------------------------------------------------------------------------|:------------------------------------------------------------------------------------------|
| 8  TERMINATION                                                                           |                                                                                           |
| 8.1  If this license is a Trial license, you shall be entitled to return the Software to |                                                                                           |
|                                                                                          | Surgical Science on or before Trial Expiry Date specified in the License Key Issue Note   |
|                                                                                          | and, in that event, this Agreement shall then terminate. Unless otherwise agreed under    |
|                                                                                          | special conditions, no license fee or other charges shall be payable by you in respect    |
| of the trial.                                                                            |                                                                                           |
| 8.2  Unless terminated pursuant to 8.3 below this Agreement shall continue until the     |                                                                                           |
| expiry date, if any, specified in the Particulars or the License Key Issue Note.         |                                                                                           |
| 8.3  This Agreement may be terminated by Surgical Science at any time by written         |                                                                                           |
| notice of termination:                                                                   |                                                                                           |
| 8.3.1.  if you shall expressly or impliedly repudiate this license by refusing or        |                                                                                           |
|                                                                                          | threatening to refuse to observe any of the conditions to which this license is subject;  |
| or                                                                                       |                                                                                           |
|                                                                                          | 8.3.2  if you shall fail to make payment of any amount due to and invoiced by Surgical    |
|                                                                                          | Science or to observe any of the conditions to which this license is subject and, after   |
|                                                                                          | your attention has been drawn by notice to such failure, shall fail to remedy the matter  |
| to Surgical Science's reasonable satisfaction within thirty days of the giving or such   |                                                                                           |
| notice; or                                                                               |                                                                                           |
|                                                                                          | 8.3.3  if you shall have a receiver or administrative receiver or administrator appointed |
|                                                                                          | or shall enter into liquidation whether compulsory or voluntary or if you or any member   |
| of your partnership shall be unable to pay its debts as and when they fall due or any    |                                                                                           |
|                                                                                          | judgment or execution or other process issued in respect of any judgment against you      |
| is unsatisfied for fourteen days.                                                        |                                                                                           |
| 8.4  On expiry, surrender or other termination of this Agreement, however such           |                                                                                           |
|                                                                                          | termination may arise, you shall cease to load, store, copy or use the Software, shall    |
| delete the Software from the any computers on which the Software is installed or         |                                                                                           |
| copied and at Surgical Science's option shall either surrender the Software and all      |                                                                                           |
| documentation and other related materials to Surgical Science or shall destroy the       |                                                                                           |
| Software with all documentation and other related materials and deliver to Surgical      |                                                                                           |
| Science a certificate of comprehensive destruction. You shall continue after             |                                                                                           |
|                                                                                          | termination to observe and enforce confidence and secrecy in respect of the Software      |
| and its documentation and related materials for the benefit of Surgical Science, and     |                                                                                           |
| however termination may occur it shall not prejudice any right of action or remedy       |                                                                                           |
| which may have accrued prior to termination.                                             |                                                                                           |

[OCR_TABLE]
Q TERMIN

[OCR_TABLE]
8.1 If this |
Surgical Sc

[OCR]
Chapter 11 End-User Software License Agreement

8 TERMINATION

8.1 If this license is a Trial license, you shall be entitled to return the Software to
Surgical Science on or before Trial Expiry Date specified in the License Key Issue Note
and, in that event, this Agreement shall then terminate. Unless otherwise agreed under
special conditions, no license fee or other charges shall be payable by you in respect
of the trial.

8.2 Unless terminated pursuant to 8.3 below this Agreement shall continue until the
expiry date, if any, specified in the Particulars or the License Key Issue Note.

8.3 This Agreement may be terminated by Surgical Science at any time by written
notice of termination:

8.3.1. if you shall expressly or impliedly repudiate this license by refusing or
threatening to refuse to observe any of the conditions to which this license is subject;
or

8.3.2 if you shall fail to make payment of any amount due to and invoiced by Surgical
Science or to observe any of the conditions to which this license is subject and, after
your attention has been drawn by notice to such failure, shall fail to remedy the matter
to Surgical Science's reasonable satisfaction within thirty days of the giving or such
notice; or

8.3.3 if you shall have a receiver or administrative receiver or administrator appointed
or shall enter into liquidation whether compulsory or voluntary or if you or any member
of your partnership shall be unable to pay its debts as and when they fall due or any
judgment or execution or other process issued in respect of any judgment against you
is unsatisfied for fourteen days.

8.4 On expiry, surrender or other termination of this Agreement, however such
termination may arise, you shall cease to load, store, copy or use the Software, shall
delete the Software from the any computers on which the Software is installed or
copied and at Surgical Science's option shall either surrender the Software and all
documentation and other related materials to Surgical Science or shall destroy the
Software with all documentation and other related materials and deliver to Surgical
Science a certificate of comprehensive destruction. You shall continue after
termination to observe and enforce confidence and secrecy in respect of the Software
and its documentation and related materials for the benefit of Surgical Science, and
however termination may occur it shall not prejudice any right of action or remedy
which may have accrued prior to termination.

surgicalscience Page 101


# Page 111

Chapter 11 
 End-User Software License Agreement
 
Page 102
 
9.  MISCELLANEOUS 
9.1  This Agreement is governed by Swedish law and any disputes arising out of or in 
connection to this Agreement shall be submitted to the exclusive jurisdiction of the 
Swedish courts. 
9.2  The headings to these Conditions are included for convenience only and do not 
affect their interpretation. 
9.3  Should you have any questions concerning this Agreement, or if you desire to 
contact Surgical Science for any reason, please contact Surgical Science (write or e-
mail): Surgical Science Sweden AB, Drakegatan 7, SE-412 50 Göteborg, Sweden, 
[info@surgical-science.com]. 
 
 


[TABLE]
| Chapter 11                                                                            | End-User Software License Agreement                                                  |
|:--------------------------------------------------------------------------------------|:-------------------------------------------------------------------------------------|
| 9.  MISCELLANEOUS                                                                     |                                                                                      |
|                                                                                       | 9.1  This Agreement is governed by Swedish law and any disputes arising out of or in |
| connection to this Agreement shall be submitted to the exclusive jurisdiction of the  |                                                                                      |
| Swedish courts.                                                                       |                                                                                      |
| 9.2  The headings to these Conditions are included for convenience only and do not    |                                                                                      |
| affect their interpretation.                                                          |                                                                                      |
| 9.3  Should you have any questions concerning this Agreement, or if you desire to     |                                                                                      |
| contact Surgical Science for any reason, please contact Surgical Science (write or e- |                                                                                      |
| mail): Surgical Science Sweden AB, Drakegatan 7, SE-412 50 Göteborg, Sweden,          |                                                                                      |
| [info@surgical-science.com].                                                          |                                                                                      |

[OCR_TABLE]
LHaVlel tt

[OCR]
Chapter 11 End-User Software License Agreement

9. MISCELLANEOUS

9.1 This Agreement is governed by Swedish law and any disputes arising out of or in
connection to this Agreement shall be submitted to the exclusive jurisdiction of the
Swedish courts.

9.2 The headings to these Conditions are included for convenience only and do not
affect their interpretation.

9.3 Should you have any questions concerning this Agreement, or if you desire to
contact Surgical Science for any reason, please contact Surgical Science (write or e-
mail): Surgical Science Sweden AB, Drakegatan 7, SE-412 50 Géteborg, Sweden,
[info@surgical-science.com].

surgicalscience Page 102


# Page 112

Index
 
 
Page 103
 
Index 
A 
Accessing a module or course • 34 
easy access buttons • 36 
Adjusting 
c-arm position • 47 
fluoro image • 49 
Adjusting height • 13 
Adjusting platform height • 13 
Aligning the scopes 
resectoscope • 77 
Analyzing clinical findings 
URO Mentor • 55 
Angled optics • 61 
Applying electricity • 64 
B 
Basic Skills display mode • 58 
Baskets • 71 
Benchmarks 
report graph • 92 
report rating scale • 91 
report scoreboard • 90 
Bipolar loop • 64 
Bladder • 59 
emptying • 69 
Bookmarking reports • 82 
C 
Camera • 23 
positioning the camera • 78 
Camera angles • 62 
Camera mode • 44, 52 
Camera, locked • 53 
C-Arm 
adjusting position • 47 
image controls • 49 
resetting position • 48 
C-Arm button • 42, 44 
Caudal • 48 
Changing camera angle • 62 
Clear View • 69 
Clearing the simulation view • 69 
Clinical Procedure display mode • 59 
general buttons • 67 
Cloud configuration • 33 
Connecting the scope • 8 
Consecutive times • 91 
Contrast agent, injecting • 50 
Cranial • 48 
Cyberscopy display mode • 41 
Cyberscopy view • 42 
Cystoscope 
rigid • 19 
D 
Didactic materials • 37 
Documenting pathologies • 55 
Drain button • 44 
Draining fluids • 53 
E 
Educational aids • 51 
Elapsed time indicator • 61 
Electrodes • 74 
ENDO Mentor Suite 
URO Mentor platform • 5 
Endoscopic view • 44, 46 
Endourology modules 
Basic Tasks • 27 
Essential Skills • 27 


[TABLE]
|                                   | Index                                |
|:----------------------------------|:-------------------------------------|
|                                   | C-Arm                                |
|                                   |                                      |
| Index                             | adjusting position • 47              |
|                                   | image controls • 49                  |
|                                   | resetting position • 48              |
|                                   |                                      |
| A                                 | C-Arm button • 42, 44                |
|                                   | Caudal • 48                          |
|                                   | Changing camera angle • 62           |
| Accessing a module or course • 34 |                                      |
| easy access buttons • 36          | Clear View • 69                      |
| Adjusting                         | Clearing the simulation view • 69    |
| c-arm position • 47               | Clinical Procedure display mode • 59 |
| fluoro image • 49                 | general buttons • 67                 |
| Adjusting height • 13             | Cloud configuration • 33             |
| Adjusting platform height • 13    | Connecting the scope • 8             |
| Aligning the scopes               | Consecutive times • 91               |
| resectoscope • 77                 | Contrast agent, injecting • 50       |
| Analyzing clinical findings       | Cranial • 48                         |
| URO Mentor • 55                   |                                      |
|                                   | Cyberscopy display mode • 41         |
| Angled optics • 61                |                                      |
|                                   | Cyberscopy view • 42                 |
| Applying electricity • 64         |                                      |
|                                   | Cystoscope                           |
|                                   | rigid • 19                           |

[OCR]
Index

| Index esting post
adjusting position « 47
image controls « 49
resetting position « 48

A C-Arm button « 42, 44
Caudal « 48
Accessing a module or course « 34 Changing camera angle + 62
easy access buttons » 36 Clear View « 69
Adjusting Clearing the simulation view « 69
c-arm position « 47 Clinical Procedure display mode « 59
fluoro image « 49 general buttons « 67
Adjusting height « 13 Cloud configuration « 33
Adjusting platform height « 13 Connecting the scope e 8
Aligning the scopes Consecutive times « 91
resectoscope « 77 Contrast agent, injecting « 50
Analyzing clinical findings Cranial « 48
URO Mentor ¢ 55 Cyberscopy display mode « 41
Angled optics « 61 Cyberscopy view « 42
Applying electricity « 64 Cystoscope
rigid « 19
B
D
Basic Skills display mode « 58
Baskets « 71 Didactic materials « 37
Benchmarks Documenting pathologies » 55
report graph + 92 Drain button « 44
report rating scale « 91 Draining fluids » 53

report scoreboard « 90

Bipolar loop « 64

Bladder « 59 E
emptying « 69

Bookmarking reports « 82 Educational aids « 51

Elapsed time indicator « 61

C.. Electrodes « 74
ENDO Mentor Suite

URO Mentor platform « 5
Endoscopic view « 44, 46
Endourology modules

Basic Tasks « 27

Essential Skills « 27

Camera e 23

positioning the camera e 78
Camera angles « 62
Camera mode e 44, 52
Camera, locked « 53

surgicalscience Page 103


# Page 113

Index
 
 
Page 104
 
Stone Manipulation • 27 
Strictures Treatment • 28 
Exporting performance results • 94 
External View • 65 
controls • 65 
F 
Flexible cystoscope • 21 
Flexible ureteroscope • 21 
Fluoro image 
adjusting • 49 
Fluoroscopic view 
URO Mentor • 42, 44, 46 
Fluoroscopy 
working with • 47 
Flush button • 44 
Flushing • 54 
Focus wheel • 79 
Foot • 17 
Foot switch • 17 
Forceps • 25, 71 
handle • 71 
removing stone fragment • 72 
G 
General buttons 
TURP modules • 67 
Getting started • 29 
GI-BRONCH interchangeable panel • 7 
H 
Hardware • 4 
Height elevation mechanism • 13 
How to use the simulator 
URO Mentor • 41 
I 
Inflow valve • 69 
Injecting contrast • 50 
Inserting the camera • 78 
Internal view • 61 
Irrigating • 54 
Irrigation pressure • 44, 54 
L 
Lateral working position • 11 
Lithotripters • 72 
EHL • 74 
laser • 73 
pneumatic • 73 
M 
Master tool • 24 
MentorLearn 
Library screen • 35 
overview • 30 
patient file • 39 
starting case or task • 38 
workflow • 30 
Modality extensions • 9 
Monopolar loop • 63 
More than one endoscopic tool • 71 
O 
Opening a module • 37 
Orbital • 48 
Outflow valve 
for flow of fluids • 69 


[TABLE]
| Stone Manipulation • 27            |                              |
|:-----------------------------------|:-----------------------------|
|                                    | I                            |
| Strictures Treatment • 28          |                              |
| Exporting performance results • 94 |                              |
|                                    | Inflow valve • 69            |
| External View • 65                 |                              |
|                                    | Injecting contrast • 50      |
| controls • 65                      |                              |
|                                    | Inserting the camera • 78    |
|                                    | Internal view • 61           |
|                                    |                              |
| F                                  | Irrigating • 54              |
|                                    | Irrigation pressure • 44, 54 |
| Flexible cystoscope • 21           |                              |

[OCR_TABLE]
Stricture
xporting

[OCR]
Index

Stone Manipulation « 27 /

Strictures Treatment « 28
Exporting performance results « 94
External View « 65

controls ¢ 65

Inflow valve « 69
Injecting contrast ¢ 50
Inserting the camera « 78
ee Internal view e« 61
F Irrigating « 54
Irrigation pressure e 44, 54

Flexible cystoscope « 21
Flexible ureteroscope e 21
Fluoro image L

adjusting » 49

Fluoroscopic view Lateral working position « 11
URO Mentor « 42, 44, 46 Lithotripters « 72

Fluoroscopy EHL « 74
working with « 47 laser ¢ 73

Flush button « 44 pneumatic « 73

Flushing « 54

Focus wheel e 79

Foot « 17 M

Foot switch « 17
Forceps « 25, 71 Master tool « 24

handle « 71 MentorLearn

removing stone fragment « 72 Library screen ¢ 35
overview « 30
patient file + 39
G starting case or task « 38
workflow « 30
Modality extensions « 9
Monopolar loop « 63
More than one endoscopic tool « 71

General buttons
TURP modules « 67
Getting started « 29
GI-BRONCH interchangeable panel « 7

oO

H Opening a module « 37

Orbital « 48
Outflow valve
for flow of fluids » 69

Hardware e 4
Height elevation mechanism « 13
How to use the simulator

URO Mentor « 41

surgicalscience Page 104


# Page 114

Index
 
 
Page 105
 
P 
Panning 3D Map • 66 
Patient file • 39 
URO Mentor • 44, 56 
Playback, procedure • 89 
Positioning the camera • 78 
Prostate • 59 
R 
Reports with benchmarks 
learning curve graph • 92 
rating scale • 91 
scoreboard • 90 
Resecting 
applying electricity • 64 
areas to resect • 68 
Resection Assist • 67 
Resection map • 67 
Resection progress bar • 68 
Resectoscope 
aligning • 77 
camera • 23 
Resectoscope • 22 
Resectoscope view • 61 
Resetting 
c-arm position • 48 
Resetting 3D Map • 66 
Reviewing 
didactic materials • 37 
Rigid cystoscope • 19 
Rigid ureteroscope • 20 
Rotating 3D Map • 65 
S 
Scope 
connectors • 9 
hangers • 8 
Scope and tool information button • 44 
Scopes • 18 
view information • 76 
Screen display layout • 60 
Selecting 
scope • 45 
Selecting tools • 63 
Simulated video • 59, 61 
Simulation aids • 67 
Simulation display • 59 
Simulator 
hardware • 4 
Single-case report • 82 
Snapshot buttons • 42, 44 
Snapshots • 54, 85 
browsing through • 55 
deleting • 56 
Starting a simulation case or task • 38 
Stents • 75 
Step-by-step instructions 
URO Mentor • 52 
Superior working position • 11 
Switching interchangeable panels • 7 
Syringe button • 44 
T 
Task and Procedure display mode 
URO Mentor • 43 
Task instructions 
URO Mentor • 52 
Technical support • 95 
Tool Menu options • 63 
Tool tray • 14 
connection outlets • 16 
resectoscope • 15 
Tools • 24 
selecting 
TURP modules • 63 
URO Mentor • 70 


[TABLE]
|                             | Index                                   |
|:----------------------------|:----------------------------------------|
|                             | hangers • 8                             |
| P                           |                                         |
|                             | Scope and tool information button • 44  |
|                             | Scopes • 18                             |
| Panning 3D Map • 66         |                                         |
|                             | view information • 76                   |
| Patient file • 39           |                                         |
|                             | Screen display layout • 60              |
| URO Mentor • 44, 56         |                                         |
|                             | Selecting                               |
| Playback, procedure • 89    |                                         |
|                             | scope • 45                              |
| Positioning the camera • 78 |                                         |
|                             | Selecting tools • 63                    |
| Prostate • 59               |                                         |
|                             | Simulated video • 59, 61                |
|                             | Simulation aids • 67                    |
|                             | Simulation display • 59                 |
| R                           |                                         |
|                             | Simulator                               |
|                             | hardware • 4                            |
| Reports with benchmarks     |                                         |
|                             | Single-case report • 82                 |
| learning curve graph • 92   |                                         |
|                             | Snapshot buttons • 42, 44               |
| rating scale • 91           |                                         |
|                             | Snapshots • 54, 85                      |
| scoreboard • 90             |                                         |
|                             | browsing through • 55                   |
| Resecting                   |                                         |
|                             | deleting • 56                           |
| applying electricity • 64   |                                         |
|                             | Starting a simulation case or task • 38 |
| areas to resect • 68        |                                         |
|                             | Stents • 75                             |
| Resection Assist • 67       |                                         |
|                             | Step-by-step instructions               |
| Resection map • 67          |                                         |
|                             | URO Mentor • 52                         |
| Resection progress bar • 68 |                                         |
|                             | Superior working position • 11          |
| Resectoscope                |                                         |
|                             | Switching interchangeable panels • 7    |
| aligning • 77               |                                         |
|                             | Syringe button • 44                     |
| camera • 23                 |                                         |
| Resectoscope • 22           |                                         |

[OCR]
Index

P

Panning 3D Map e 66
Patient file » 39

URO Mentor e 44, 56
Playback, procedure « 89
Positioning the camera e 78
Prostate « 59

R

Reports with benchmarks
learning curve graph e 92
rating scale « 91
scoreboard « 90

Resecting
applying electricity « 64
areas to resect « 68

Resection Assist ¢ 67

Resection map « 67

Resection progress bar « 68

Resectoscope
aligning « 77
camera ¢ 23

Resectoscope « 22

Resectoscope view e 61

Resetting
c-arm position « 48

Resetting 3D Map « 66

Reviewing
didactic materials » 37

Rigid cystoscope e 19

Rigid ureteroscope « 20

Rotating 3D Map e 65

Ss

Scope
connectors « 9

hangers « 8

Scope and tool information button « 44

Scopes « 18

view information » 76
Screen display layout « 60
Selecting

scope e 45
Selecting tools « 63
Simulated video « 59, 61
Simulation aids ¢ 67
Simulation display « 59
Simulator

hardware e 4
Single-case report « 82
Snapshot buttons e 42, 44
Snapshots « 54, 85

browsing through e 55

deleting « 56

Starting a simulation case or task ¢ 38

Stents ¢ 75

Step-by-step instructions
URO Mentor e 52
Superior working position e 11

Switching interchangeable panels e 7

Syringe button « 44

a

Task and Procedure display mode

URO Mentor e 43
Task instructions
URO Mentor e 52
Technical support « 95
Tool Menu options « 63
Tool tray « 14
connection outlets « 16
resectoscope e 15
Tools « 24
selecting
TURP modules « 63
URO Mentor « 70

surgicalscience

Page 105


# Page 115

Index
 
 
Page 106
 
view information about 
URO Mentor • 76 
working with 
URO Mentor • 70 
Tools menu 
URO Mentor • 42, 44, 70 
Total score • 90, 91 
Trainee report 
URO Mentor • 44, 55 
Training with MentorLearn within a 
module or course • 34 
Turning on the simulator • 13 
TURP Basic Skills module • 26 
TURP display mode 
basic skills • 58 
clinical procedure • 59 
TURP Procedures module • 26 
U 
Ureteroscope 
rigid • 20 
Urethra • 59 
URO interchangeable panel • 6 
URO Mentor 
how to use • 41 
URO Mentor display modes • 41 
cyberscopy • 41 
task and procedure • 43 
V 
Videos • 86 
Viewing 
additional information in report • 85 
performance reports • 81 
procedure playback • 89 
saved snapshots • 88 
snapshots • 85 
videos • 86 
Virtual instructor 
TURP modules • 66 
URO Mentor • 51 
W 
Workflow • 29 
Working 
locally • 33 
on the cloud site • 33 
Working locally configuration • 33 
Working positions • 11 
Working with 
fluoroscopy • 47 
more than one tool simultaneously • 71 
Z 
Zoom wheel • 79 
Zooming 
3D Map • 66 
 


[TABLE]
|                                    | Index                                  |
|:-----------------------------------|:---------------------------------------|
| view information about             | Virtual instructor                     |
| URO Mentor • 76                    | TURP modules • 66                      |
| working with                       | URO Mentor • 51                        |
| URO Mentor • 70                    |                                        |
| Tools menu                         |                                        |
|                                    |                                        |
| URO Mentor • 42, 44, 70            | W                                      |
| Total score • 90, 91               |                                        |
| Trainee report                     |                                        |
|                                    | Workflow • 29                          |
| URO Mentor • 44, 55                |                                        |
|                                    | Working                                |
| Training with MentorLearn within a |                                        |
|                                    | locally • 33                           |
| module or course • 34              | on the cloud site • 33                 |
| Turning on the simulator • 13      | Working locally configuration • 33     |
| TURP Basic Skills module • 26      | Working positions • 11                 |
| TURP display mode                  | Working with                           |
| basic skills • 58                  | fluoroscopy • 47                       |
| clinical procedure • 59            | more than one tool simultaneously • 71 |
| TURP Procedures module • 26        |                                        |

[OCR]
Index

view information about
URO Mentor « 76
working with
URO Mentor « 70
Tools menu
URO Mentor e 42, 44, 70
Total score « 90, 91
Trainee report
URO Mentor e 44, 55
Training with MentorLearn within a
module or course « 34
Turning on the simulator « 13
TURP Basic Skills module « 26
TURP display mode
basic skills « 58
clinical procedure « 59
TURP Procedures module « 26

U

Ureteroscope
rigid « 20
Urethra ¢ 59
URO interchangeable panel « 6
URO Mentor
how to use e 41
URO Mentor display modes e 41
cyberscopy e 41
task and procedure « 43

V

Videos « 86

Viewing
additional information in report « 85
performance reports « 81
procedure playback « 89
saved snapshots « 88
snapshots « 85
videos « 86

Virtual instructor
TURP modules « 66
URO Mentor ¢ 51

WwW

Workflow e« 29
Working

locally * 33

on the cloud site « 33

Working locally configuration « 33
Working positions « 11
Working with

fluoroscopy « 47

more than one tool simultaneously «

Zz

Zoom wheel e 79
Zooming
3D Map « 66

71

surgicalscience

Page 106