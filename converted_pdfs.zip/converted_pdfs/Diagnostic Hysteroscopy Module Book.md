

# Page 1

Diagnostic Hysteroscopy  
Proctor Book 
Overview 
The Diagnostic Hysteroscopy module offers a comprehensive learning experience 
across diverse clinical scenarios of hysteroscopy, including anatomical variations 
and various pathologies.   
Accompanied by comprehensive educational aids, trainees develop proficiency in 
instrument handling while navigating through the cervical canal into the uterus, 
using cameras and angled optics. During the procedure, trainees practice 
visualizing anatomical landmarks, managing irrigation fluid and fluid deficiencies, 
and managing complications such as controlling bleeding and preventing 
perforation. Throughout the procedure, trainees can monitor the patient's 
discomfort scale to ensure optimal care. 
 
Unique Features: 
• 
Simulates the maneuver of vaginoscopy and advancement through the 
cervical canal into the uterus 
• 
Different angled optics 
• 
Presents real time fluid management system display, allowing trainees to 
track uterine fluid deficit effectively 
• 
Monitors patient discomfort levels for best practice 
• 
Progress bar tracking of percentage of uterine visualized 
• 
On-screen warning and complication messages  
• 
Proctor preset for random light failure 
• 
Performance review provides feedback of safety measures and 
complication handling for post-procedure debriefing 
 


[TABLE]
| Diagnostic Hysteroscopy                                                             |
|:------------------------------------------------------------------------------------|
| Proctor Book                                                                        |
| Overview                                                                            |
| The Diagnostic Hysteroscopy module offers a comprehensive learning experience       |
| across diverse clinical scenarios of hysteroscopy, including anatomical variations  |
| and various pathologies.                                                            |
| Accompanied by comprehensive educational aids, trainees develop proficiency in      |
| instrument handling while navigating through the cervical canal into the uterus,    |
| using cameras and angled optics. During the procedure, trainees practice            |
| visualizing anatomical landmarks, managing irrigation fluid and fluid deficiencies, |
| and managing complications such as controlling bleeding and preventing              |
| perforation. Throughout the procedure, trainees can monitor the patient's           |
| discomfort scale to ensure optimal care.                                            |

[TABLE]
| U                 |                                                                          |
| nique Features:   |                                                                          |
|:------------------|:-------------------------------------------------------------------------|
| •                 | Simulates the maneuver of vaginoscopy and advancement through the        |
|                   | cervical canal into the uterus                                           |
| •                 | Different angled optics                                                  |
| •                 | Presents real time fluid management system display, allowing trainees to |
|                   | track uterine fluid deficit effectively                                  |
| •                 | Monitors patient discomfort levels for best practice                     |
| •                 | Progress bar tracking of percentage of uterine visualized                |
| •                 | On-screen warning and complication messages                              |
| •                 | Proctor preset for random light failure                                  |
| •                 | Performance review provides feedback of safety measures and              |
|                   | complication handling for post-procedure debriefing                      |

[OCR_TABLE]
Viagn
Droctrc

[OCR]
Diagnostic Hysteroscopy
Proctor Book

Overview

The Diagnostic Hysteroscopy module offers a comprehensive learning experience
across diverse clinical scenarios of hysteroscopy, including anatomical variations
and various pathologies.

Accompanied by comprehensive educational aids, trainees develop proficiency in
instrument handling while navigating through the cervical canal into the uterus,
using cameras and angled optics. During the procedure, trainees practice
visualizing anatomical landmarks, managing irrigation fluid and fluid deficiencies,
and managing complications such as controlling bleeding and preventing
perforation. Throughout the procedure, trainees can monitor the patient's
discomfort scale to ensure optimal care.

Unique Features:

° Simulates the maneuver of vaginoscopy and advancement through the
cervical canal into the uterus

° Different angled optics

° Presents real time fluid management system display, allowing trainees to
track uterine fluid deficit effectively

° Monitors patient discomfort levels for best practice

° Progress bar tracking of percentage of uterine visualized

. On-screen warning and complication messages

° Proctor preset for random light failure

° Performance review provides feedback of safety measures and

complication handling for post-procedure debriefing

surgicalscience


# Page 2

Diagnostic Hysteroscopy 
Proctor Book 
 
Page 2 
 
Acknowledgements 
This module was created in collaboration with: 
• 
Noam Smorgick MD, Shamir Medical Center, Tel Aviv University, Israel 
• 
Antoni Sierant, MD, Postgraduate Medical Education Center CMKP, 
Warsaw, Poland 
Case Description 
Case 
Description 
Case 1  
Anteverted uterus 
Case 2 
Bicornuate uterus 
Case 3 
Intra uterine device (IUD) and small polyp in the right 
posterior wall 
Case 4 
Caesarean section niche 
Case 5 
Uterine adhesions 
Case 6 
Retroverted uterus 
 
 
 
 
 
 
 
 
 
 
 
 


[TABLE]
| Case Description   |      |                                                         |
|:-------------------|:-----|:--------------------------------------------------------|
|                    | Case | Description                                             |
| Case 1             |      | Anteverted uterus                                       |
| Case 2             |      | Bicornuate uterus                                       |
|                    |      | Intra uterine device (IUD) and small polyp in the right |
| Case 3             |      |                                                         |
|                    |      | posterior wall                                          |
| Case 4             |      | Caesarean section niche                                 |
| Case 5             |      | Uterine adhesions                                       |
| Case 6             |      | Retroverted uterus                                      |

[OCR_TABLE]
Ac

Thie

[OCR]
Diagnostic Hysteroscopy
Proctor Book

Acknowledgements

This module was created in collaboration with:

. Noam Smorgick MD, Shamir Medical Center, Tel Aviv University, Israel
. Antoni Sierant, MD, Postgraduate Medical Education Center CMKP,
Warsaw, Poland

Case Description

Case Description
Case 1 Anteverted uterus
Case 2 Bicornuate uterus
Case 3 Intra uterine device (IUD) and small polyp in the right
posterior wall
Case 4 Caesarean section niche
Case 5 Uterine adhesions
Case 6 Retroverted uterus

surgicalscience Page 2


# Page 3

Diagnostic Hysteroscopy 
Proctor Book 
 
Page 3 
 
Module-Specific Hardware 
Device 
Physical Hardware 
Resectoscope / 
Hysteroscope 
 
 
Keyboard Shortcuts 
Shortcut Key 
Description 
CTRL+F 
Freeze the hysteroscope location to enable a live 
screen view without the need to manually hold the 
scope 
 
 
 
 
 
 
 
 
 


[TABLE]
|                          |                   |       |                                                   | Diagnostic Hysteroscopy   |
|:-------------------------|:------------------|:------|:--------------------------------------------------|:--------------------------|
|                          |                   |       |                                                   | Proctor Book              |
| Module-Specific Hardware |                   |       |                                                   |                           |
|                          | Device            |       | Physical Hardware                                 |                           |
|                          | Resectoscope /    |       |                                                   |                           |
|                          | Hysteroscope      |       |                                                   |                           |
| K                        | eyboard Shortcuts |       |                                                   |                           |
|                          | Shortcut Key      |       | Description                                       |                           |
|                          |                   |       | Freeze the hysteroscope location to enable a live |                           |
|                          | CTRL+F            |       |                                                   |                           |
|                          |                   |       | screen view without the need to manually hold the |                           |
|                          |                   | scope |                                                   |                           |
|                          |                   |       |                                                   | Page 3                    |

[OCR]
Diagnostic Hysteroscopy
Proctor Book

Module-Specific Hardware

Device Physical Hardware

Resectoscope /

Hysteroscope
Keyboard Shortcuts
Shortcut Key Description
Freeze the hysteroscope location to enable a live
CTRL+F screen view without the need to manually hold the
scope

surgicalscience Page 3


# Page 4

Diagnostic Hysteroscopy 
Proctor Book 
 
Page 4 
 
Performance Report 
Device 
Physical Hardware 
Time & Economy 
Procedure time 
Total procedure time, measured from scope 
entrance until exit from case (hh:mm:ss) 
Ergonomics 
Working angle 00 /120 / 300 
Percentage of time trainee worked with angle 
Educational Aids 
Percent time worked in Clear 
View mode 
Measures percentage of time the Clear View 
mode was turned on 
Snapshots taken during 
procedure 
Presents the snapshots taken during the 
procedure 
Fluid Management & Bleeding 
Total time uterus collapsed 
Measures the total time the uterus was 
deflated and collapsed during procedure (sec) 
Number of times fluid 
balance was checked 
Indicates the number of times the fluid 
balance was checked during procedure   
Safety 
Substantial contacts with the 
uterine walls 
Presents the number of incidents the 
hysteroscope hit the uterine walls 
Substantial contacts with the 
cervical wall 
Presents the number of incidents the 
hysteroscope hit the cervical wall  
Endometrial perforation 
incident 
Indicates if an endometrial perforation 
occurred during procedure (Yes/No)  
 
 


[TABLE]
| Performance Report            |                                               |
|:------------------------------|:----------------------------------------------|
| Device                        | Physical Hardware                             |
| Time & Economy                |                                               |
| Procedure time                | Total procedure time, measured from scope     |
|                               | entrance until exit from case (hh:mm:ss)      |
| Ergonomics                    |                                               |
| Working angle 00 /120 / 300   | Percentage of time trainee worked with angle  |
| Educational Aids              |                                               |
| Percent time worked in Clear  | Measures percentage of time the Clear View    |
| View mode                     | mode was turned on                            |
| Snapshots taken during        | Presents the snapshots taken during the       |
| procedure                     | procedure                                     |
| Fluid Management & Bleeding   |                                               |
| Total time uterus collapsed   | Measures the total time the uterus was        |
|                               | deflated and collapsed during procedure (sec) |
| Number of times fluid         | Indicates the number of times the fluid       |
| balance was checked           | balance was checked during procedure          |
| Safety                        |                                               |
| Substantial contacts with the | Presents the number of incidents the          |
| uterine walls                 | hysteroscope hit the uterine walls            |
| Substantial contacts with the | Presents the number of incidents the          |
| cervical wall                 | hysteroscope hit the cervical wall            |
| Endometrial perforation       | Indicates if an endometrial perforation       |
| incident                      | occurred during procedure (Yes/No)            |

[OCR]
Diagnostic Hysteroscopy
Proctor Book

Performance Report

Device

Physical Hardware

Time & Economy

Procedure time

Total procedure time, measured from scope
entrance until exit from case (hh:mm:ss)

Ergonomics

Working angle 0°/12°/ 30°

Percentage of time trainee worked with angle

Educational Aids

Percent time worked in Clear
View mode

Measures percentage of time the Clear View
mode was turned on

Snapshots taken during
procedure

Presents the snapshots taken during the
procedure

Fluid Management & Bleeding

Total time uterus collapsed

Measures the total time the uterus was
deflated and collapsed during procedure (sec)

Number of times fluid
balance was checked

Indicates the number of times the fluid
balance was checked during procedure

Safety

Substantial contacts with the
uterine walls

Presents the number of incidents the
hysteroscope hit the uterine walls

Substantial contacts with the
cervical wall

Presents the number of incidents the
hysteroscope hit the cervical wall

Endometrial perforation
incident

Indicates if an endometrial perforation
occurred during procedure (Yes/No)

surgicalscience

Page 4


# Page 5

Diagnostic Hysteroscopy 
Proctor Book 
 
Page 5 
 
Visualization 
Percent visualization of 
uterus 
Measures the percentage of uterus visualized 
during the procedure 
Left tubal ostium 
Indicates if the left tubal ostium was visualized 
(Yes/No)  
Right tubal ostium 
Indicates if the right tubal ostium was 
visualized (Yes/No) 
Total path of camera  
Measures the total distance that was traveled 
with the camera during the procedure (mm) 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 


[TABLE]
|                          | Diagnostic Hysteroscopy                           |
|:-------------------------|:--------------------------------------------------|
|                          | Proctor Book                                      |
| Visualization            |                                                   |
| Percent visualization of | Measures the percentage of uterus visualized      |
| uterus                   | during the procedure                              |
| Left tubal ostium        | Indicates if the left tubal ostium was visualized |
|                          | (Yes/No)                                          |
| Right tubal ostium       | Indicates if the right tubal ostium was           |
|                          | visualized (Yes/No)                               |
| Total path of camera     | Measures the total distance that was traveled     |
|                          | with the camera during the procedure (mm)         |

[OCR]
Diagnostic Hysteroscopy
Proctor Book

Visualization

Percent visualization of Measures the percentage of uterus visualized

uterus during the procedure

Left tubal ostium Indicates if the left tubal ostium was visualized
(Yes/No)

Right tubal ostium Indicates if the right tubal ostium was

visualized (Yes/No)

Total path of camera Measures the total distance that was traveled
with the camera during the procedure (mm)

surgicalscience Page 5


# Page 6

Diagnostic Hysteroscopy 
Proctor Book 
 
Page 6 
 
Main Features and Controls 
Feature 
Button 
Description 
Patient file 
 
Review the case objectives 
Sound  
 
Mute the sound 
3D map 
 
Dynamic external view of the 
uterus and current position of 
the hysteroscope during the 
procedure 
3D slicer 
 
Slice through the external view 
3D anatomy using a scroll bar 
Camera angle 
 
Selection of camera angle  
00, 120 or 300 
Tool selection 
 
 
Select monopolar or bipolar 
loop 
Visualization 
progress bar 
  
Percent of uterus visualized 
Clear View mode 
 
Clear the view for helping 
diagnose bleeding sources 
Fix light failure 
 
Available when preset failure 
enabled. Press to fix light 
failure 
 
 
 


[TABLE]
| Main Features and Controls   |        |                                |
|:-----------------------------|:-------|:-------------------------------|
| Feature                      | Button | Description                    |
| Patient file                 |        | Review the case objectives     |
| Sound                        |        | Mute the sound                 |
| 3D map                       |        | Dynamic external view of the   |
|                              |        | uterus and current position of |
|                              |        | the hysteroscope during the    |
|                              |        | procedure                      |

[OCR]
Diagnostic Hysteroscopy
Proctor Book

Main Features and Controls

Feature Button Description

Patient file al Review the case objectives

Sound Mute the sound

3D map Dynamic external view of the
uterus and current position of
the hysteroscope during the
procedure

3D slicer Slice through the external view

3D anatomy using a scroll bar

Camera angle

ANGLES

Selection of camera angle
0°, 12° or 30°

Tool selection

ri)

Select monopolar or bipolar
loop

Visualization
progress bar

Percent of uterus visualized

Clear View mode

Clear the view for helping
diagnose bleeding sources

Fix light failure

12” 30°
8

+t
+

Available when preset failure
enabled. Press to fix light
failure

surgicalscience

Page 6


# Page 7

Diagnostic Hysteroscopy 
Proctor Book 
 
Page 7 
 
Patient 
discomfort scale 
 
Live indication on patient 
discomfort during procedure 
Check Fluid 
 
 
Opens Fluid Management 
System for pressure set and 
fluid inflow and deficit tracking 
 
 


[TABLE]
|                  | Diagnostic Hysteroscopy           |
|:-----------------|:----------------------------------|
|                  | Proctor Book                      |
| Patient          | Live indication on patient        |
| discomfort scale | discomfort during procedure       |
| Check Fluid      | Opens Fluid Management            |
|                  | System for pressure set and       |
|                  | fluid inflow and deficit tracking |

[OCR]
Diagnostic Hysteroscopy
Proctor Book

Patient a. | Live indication on patient
discomfort scale discomfort during procedure
Check Fluid Ez Opens Fluid Management
System for pressure set and

fluid inflow and deficit tracking

surgicalscience Page 7