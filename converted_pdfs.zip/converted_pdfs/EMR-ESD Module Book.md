

# Page 1

EMR/ESD Proctor Book 
Overview 
This module is designed to provide skilled endoscopists and trainees 
with training model for safe endoscopic removal techniques, of 
suspicious lesions that require resection:  
• 
EMR - Endoscopic Mucosal Resection 
• 
ESD - Endoscopic Submucosal Dissection 
Unique Features: 
• 
Interactive step-by-step and guided tasks 
• 
Complete virtual patient environment with realistic anatomy 
and physiology  
• 
On-demand Electronic Image Enhancement mode that 
allows for the examination of the vascular pattern  
• 
Moderate sedation and hemodynamic complication 
management  
• 
The user can perform the procedure according to his clinical 
discretion, while using common injection materials, resection 
and coagulation tools 
• 
Errors and complications are implemented with on-screen 
messages 
• 
Educational solution - Objective performance metrics with 
benchmarks and score setting options 


[TABLE]
| EMR/ESD Proctor Book                                                 |
|:---------------------------------------------------------------------|
| Overview                                                             |
| This module is designed to provide skilled endoscopists and trainees |
| with training model for safe endoscopic removal techniques, of       |
| suspicious lesions that require resection:                           |

[TABLE]
| This module is designed to provide skilled endoscopists and trainees   |                                                               |
|:-----------------------------------------------------------------------|:--------------------------------------------------------------|
| with training model for safe endoscopic removal techniques, of         |                                                               |
| suspicious lesions that require resection:                             |                                                               |
| •                                                                      | EMR - Endoscopic Mucosal Resection                            |
| •                                                                      | ESD - Endoscopic Submucosal Dissection                        |
| Unique Features:                                                       |                                                               |
| •                                                                      | Interactive step-by-step and guided tasks                     |
| •                                                                      | Complete virtual patient environment with realistic anatomy   |
|                                                                        | and physiology                                                |
| •                                                                      | On-demand Electronic Image Enhancement mode that              |
|                                                                        | allows for the examination of the vascular pattern            |
| •                                                                      | Moderate sedation and hemodynamic complication                |
|                                                                        | management                                                    |
| •                                                                      | The user can perform the procedure according to his clinical  |
|                                                                        | discretion, while using common injection materials, resection |
|                                                                        | and coagulation tools                                         |
| •                                                                      | Errors and complications are implemented with on-screen       |
|                                                                        | messages                                                      |
| •                                                                      | Educational solution - Objective performance metrics with     |
|                                                                        | benchmarks and score setting options                          |

[OCR_TABLE]
| EMR/

[OCR]
| EMR/ESD Proctor Book

Overview

This module is designed to provide skilled endoscopists and trainees
with training model for safe endoscopic removal techniques, of
suspicious lesions that require resection:

e EMR - Endoscopic Mucosal Resection
e ESD - Endoscopic Submucosal Dissection

Unique Features:

e Interactive step-by-step and guided tasks

e Complete virtual patient environment with realistic anatomy
and physiology

e On-demand Electronic Image Enhancement mode that
allows for the examination of the vascular pattern

e Moderate sedation and hemodynamic complication
management

e The user can perform the procedure according to his clinical
discretion, while using common injection materials, resection
and coagulation tools

e Errors and complications are implemented with on-screen
messages

e Educational solution - Objective performance metrics with
benchmarks and score setting options


# Page 2

GI Mentor 
 
Page 2 
 
Acknowledgements 
The module was created in collaboration with: 
• 
Prof. Frieder Berr, MD, Dept. of Medicine I with Paracelsus 
Medical University Salzburg, Austria. 
• 
Harold Jacob, MD, Dept. of Gastroenterology, Hadassah 
Medical Center, Jerusalem, Israel.  
• 
Prof. Ian M. Gralnek, MD, MSHS, FASGE, Institute of 
Gastroenterology and Hepatology, Emek Medical Center, 
Israel.  
• 
Maite Herraiz, MD, Clinica Universidad de Navarra, Spain 
• 
Pr Thierry Ponchon, MD, PhD, Edouard Herriot University 
Hospital, Lyon, France.  
• 
Madhu, Sanaka, MD, Cleveland Clinic, USA 
• 
Amit Bhatt, MD, Cleveland Clinic, USA 
• 
Ajaypal Singh, MD, Rush University Medical Center, Chicago, 
USA 
 


[TABLE]
| Acknowledgements                              |                                                             |
|:----------------------------------------------|:------------------------------------------------------------|
| The module was created in collaboration with: |                                                             |
| •                                             | Prof. Frieder Berr, MD, Dept. of Medicine I with Paracelsus |
|                                               | Medical University Salzburg, Austria.                       |
| •                                             | Harold Jacob, MD, Dept. of Gastroenterology, Hadassah       |
|                                               | Medical Center, Jerusalem, Israel.                          |
| •                                             | Prof. Ian M. Gralnek, MD, MSHS, FASGE, Institute of         |
|                                               | Gastroenterology and Hepatology, Emek Medical Center,       |
|                                               | Israel.                                                     |
| •                                             | Maite Herraiz, MD, Clinica Universidad de Navarra, Spain    |
| •                                             | Pr Thierry Ponchon, MD, PhD, Edouard Herriot University     |
|                                               | Hospital, Lyon, France.                                     |
| •                                             | Madhu, Sanaka, MD, Cleveland Clinic, USA                    |
| •                                             | Amit Bhatt, MD, Cleveland Clinic, USA                       |
| •                                             | Ajaypal Singh, MD, Rush University Medical Center, Chicago, |
|                                               | USA                                                         |

[OCR_TABLE]
GI Mentor

[OCR]
Gl Mentor

Acknowledgements

The module was created in collaboration with:

e Prof. Frieder Berr, MD, Dept. of Medicine | with Paracelsus
Medical University Salzburg, Austria.

e Harold Jacob, MD, Dept. of Gastroenterology, Hadassah
Medical Center, Jerusalem, Israel.

e Prof. lan M. Gralnek, MD, MSHS, FASGE, Institute of
Gastroenterology and Hepatology, Emek Medical Center,
Israel.

e Maite Herraiz, MD, Clinica Universidad de Navarra, Spain

e Pr Thierry Ponchon, MD, PhD, Edouard Herriot University
Hospital, Lyon, France.

e Madhu, Sanaka, MD, Cleveland Clinic, USA

e Amit Bhatt, MD, Cleveland Clinic, USA

e Ajaypal Singh, MD, Rush University Medical Center, Chicago,
USA

Page 2 surgicalscience


# Page 3

EMR/ESD Proctor Book
 
 
Page 3 
 
Case Description 
 
Case 
Description 
Notes 
EMR 
1 
Step-by-step EMR task 
Lower GI 
2 
Case in the Lower GI 
 
3 
Case in the Upper GI 
 
ESD 
4 
Marking task - Guided 
Upper GI 
5 
Marking task - Non-
guided 
Upper GI 
6 
Incision task - Guided 
Upper GI 
7 
Incision task - Non-
guided 
Upper GI 
 
 


[TABLE]
| Case Description   |                        |          |
|:-------------------|:-----------------------|:---------|
| Case               | Description            | Notes    |
| 1                  | Step-by-step EMR task  | Lower GI |
| 2                  | Case in the Lower GI   |          |
| 3                  | Case in the Upper GI   |          |
| 4                  | Marking task - Guided  | Upper GI |
|                    | Marking task - Non-    | Upper GI |
| 5                  | guided                 |          |
| 6                  | Incision task - Guided | Upper GI |
|                    |                        | Upper GI |
|                    | Incision task - Non-   |          |
| 7                  | guided                 |          |

[OCR]
EMR/ESD Proctor Book

Case Description

Case Description Notes
1 Step-by-step EMR task Lower G
a
Pa 2 Case in the Lower GI
3 Case in the Upper Gl
4 Marking task - Guided Upper G
Marking task - Non- Upper G
5 guided
® Incision task - Guided Upper G
Upper G
Incision task - Non-
7 guided

surgicalscience

Page 3


# Page 4

GI Mentor 
 
Page 4 
 
Tools Menu 
Tools Group 
Tool Names/Sizes 
Injection Needle 
• 5ml or 10ml syringe 
• Optional addition of dye to the 
injection medium 
• Injection medium: Saline 
Snare 
• 20mm width  
Needle Knife 
• Up to 2mm adjustable needle 
length 
Complications 
Risk of Perforation Due to Thermal Damage  
Trigger 
• Applying electricity with the Snare too close to 
the GI wall when grabbing the lesion 
• Applying electricity with the needle knife tip too 
deep or too long with no movement 
How to 
Identify 
• Warning notification for potential thermal 
damage 
• When applying electricity, no cutting effect or 
smoke appears  
How to 
Resolve 
• Stop electricity application (don’t press the 
pedal) 
• Snare: Gently pull the grabbed lesion away from 
the wall toward the center of the lumen and only 
then apply electricity 
• Needle knife: Retract the tool to a closer/more 
superficial area to cut/mark 


[TABLE]
| Tools Menu       |                                    |
|:-----------------|:-----------------------------------|
| Tools Group      | Tool Names/Sizes                   |
| Injection Needle | 5ml or 10ml syringe                |
|                  | •                                  |
|                  | •  Optional addition of dye to the |
|                  | injection medium                   |
|                  | Injection medium: Saline           |
|                  | •                                  |
| Snare            | 20mm width                         |
|                  | •                                  |
| Needle Knife     | •  Up to 2mm adjustable needle     |
|                  | length                             |

[TABLE]
| Complications                             |    |                                                    |
|:------------------------------------------|:---|:---------------------------------------------------|
| Risk of Perforation Due to Thermal Damage |    |                                                    |
|                                           | •  | Applying electricity with the Snare too close to   |
| Trigger                                   |    |                                                    |
|                                           |    | the GI wall when grabbing the lesion               |
|                                           | •  | Applying electricity with the needle knife tip too |
|                                           |    | deep or too long with no movement                  |
|                                           |    | •  Warning notification for potential thermal      |
| How to                                    |    |                                                    |
|                                           |    | damage                                             |
| Identify                                  |    |                                                    |
|                                           |    | •  When applying electricity, no cutting effect or |
|                                           |    | smoke appears                                      |
|                                           | •  | Stop electricity application (don’t press the      |
| How to                                    |    |                                                    |
|                                           |    | pedal)                                             |
| Resolve                                   |    |                                                    |
|                                           | •  | Snare: Gently pull the grabbed lesion away from    |
|                                           |    | the wall toward the center of the lumen and only   |
|                                           |    | then apply electricity                             |
|                                           |    | •  Needle knife: Retract the tool to a closer/more |
|                                           |    | superficial area to cut/mark                       |

[OCR]
Gl Mentor

Tools Menu
Tools Group Tool Names/Sizes
Injection Needle e 5ml or 10ml syringe
e Optional addition of dye to the
injection medium
e Injection medium: Saline
Snare e 20mm width
Needle Knife e Upto 2mm adjustable needle
length

Complications

Risk of Perforation Due to Thermal Damage

Trigger | °* Applying electricity with the Snare too close to
the GI wall when grabbing the lesion

e Applying electricity with the needle knife tip too
deep or too long with no movement

Howto |° Warning notification for potential thermal

Identify damage

e When applying electricity, no cutting effect or
smoke appears

Howto |° Stop electricity application (don’t press the

Resolve pedal)

e Snare: Gently pull the grabbed lesion away from
the wall toward the center of the lumen and only
then apply electricity

e Needle knife: Retract the tool to a closer/more
superficial area to cut/mark

Page 4 surgicalscience


# Page 5

EMR/ESD Proctor Book
 
 
Page 5 
 
Risk of Perforation Due to Local Pressure 
Trigger 
• Applying excessive local pressure on the tissues 
using the scope or tool 
• Advancing the scope with a protruding tool 
Location 
• Anywhere in the GI tract 
How to 
Identify 
• Visual indication (in the main view) of high 
proximity to the wall  
• Warning notification for Extensive Local Pressure 
or Movement with Protruding Tool 
How to 
Resolve 
• 
For application of extensive local pressure – Pull 
the scope toward the center of the lumen 
• 
For advancing with protruding tool – Retract the 
tool before advancing the scope 
Thermal Damage in Wrong Area 
Trigger 
• Applying electricity with tool, in unrecommended 
areas 
How to 
Identify 
• Visual indication (in the main view) of working far 
outside the border of the lesion or on the lesion 
itself 
• Warning notification for marking/incising the 
wrong area 
How to 
Resolve 
• 
Stop electricity application (stop pressing the 
pedal) 
• 
Needle knife: Retract the tool and navigate closer 
to the lesion border/guided area for 
cutting/marking 


[TABLE]
| Risk of Perforation Due to Local Pressure   |    |                                                      |
|:--------------------------------------------|:---|:-----------------------------------------------------|
|                                             | •  | Applying excessive local pressure on the tissues     |
| Trigger                                     |    |                                                      |
|                                             |    | using the scope or tool                              |
|                                             | •  | Advancing the scope with a protruding tool           |
|                                             | •  | Anywhere in the GI tract                             |
| Location                                    |    |                                                      |
|                                             | •  | Visual indication (in the main view) of high         |
| How to                                      |    |                                                      |
|                                             |    | proximity to the wall                                |
| Identify                                    |    |                                                      |
|                                             |    | •  Warning notification for Extensive Local Pressure |
|                                             |    | or Movement with Protruding Tool                     |

[OCR]
EMR/ESD Proctor Book

Risk of Perforation Due to Local Pressure

Trigger | * Applying excessive local pressure on the tissues
using the scope or tool
e Advancing the scope with a protruding tool
Location | * Anywhere in the Gl tract
Howto | ° Visual indication (in the main view) of high
Identify proximity to the wall
e Warning notification for Extensive Local Pressure
or Movement with Protruding Tool
Howto |° For application of extensive local pressure — Pull
Resolve the scope toward the center of the lumen

For advancing with protruding tool - Retract the
tool before advancing the scope

Thermal Dam

age in Wrong Area

Trigger | °* Applying electricity with tool, in unrecommended
areas
Howto |° Visual indication (in the main view) of working far
Identify outside the border of the lesion or on the lesion
itself
e Warning notification for marking/incising the
wrong area
Howto |° Stop electricity application (stop pressing the
Resolve pedal)

Needle knife: Retract the tool and navigate closer
to the lesion border/guided area for
cutting/marking

surgicalscience

Page 5


# Page 6

GI Mentor 
 
Page 6 
 
Performance Report 
Metric 
Definition 
Relevance 
Total time 
 
All 
Time to reach polyp 
 
EMR 
Time to reach Cecum / 
2nd Duodenum 
 
EMR 
% of time spent with 
clear view 
 
All 
Total time spent with 
excessive local 
pressure 
 
All 
Moved too fast 
 
The number of times that 
the scope was navigated 
too fast 
All 
Moving with tool 
pointing out 
The number of times the 
scope was advanced with a 
protruding tool 
All 
Level of 
consciousness during 
procedure 
% of procedure time that 
the patient was in each 
level of consciousness 
EMR 
Consciousness checks 
during procedure 
The number of times that 
the trainee checked the 
patient’s consciousness 
level 
EMR 
Vital signs above / 
below alert threshold 
The number of times that 
vital signs alert was 
triggered  
EMR 
Use of sedatives 
Details of sedatives 
administration: Type and 
Total amount 
EMR 


[TABLE]
| Performance Report    |                           |           |
|:----------------------|:--------------------------|:----------|
| Metric                | Definition                | Relevance |
| Total time            |                           | All       |
| Time to reach polyp   |                           | EMR       |
| Time to reach Cecum / |                           | EMR       |
| 2nd Duodenum          |                           |           |
| % of time spent with  |                           | All       |
| clear view            |                           |           |
| Total time spent with |                           | All       |
| excessive local       |                           |           |
| pressure              |                           |           |
| Moved too fast        | The number of times that  | All       |
|                       | the scope was navigated   |           |
|                       | too fast                  |           |
| Moving with tool      | The number of times the   | All       |
| pointing out          | scope was advanced with a |           |
|                       | protruding tool           |           |
| Level of              | % of procedure time that  | EMR       |
| consciousness during  | the patient was in each   |           |
| procedure             | level of consciousness    |           |
| Consciousness checks  | The number of times that  | EMR       |
| during procedure      | the trainee checked the   |           |
|                       | patient’s consciousness   |           |
|                       | level                     |           |
| Vital signs above /   | The number of times that  | EMR       |
| below alert threshold | vital signs alert was     |           |
|                       | triggered                 |           |
| Use of sedatives      | Details of sedatives      | EMR       |
|                       | administration: Type and  |           |
|                       | Total amount              |           |

[OCR]
Gl Mentor

Performance Report

Metric Definition Relevance
Total time All
Time to reach polyp EMR
Time to reach Cecum / EMR
2-4 Duodenum
% of time spent with All
clear view
Total time spent with All
excessive local
pressure
Moved too fast The number of times that All
the scope was navigated
too fast
Moving with tool The number of times the All
pointing out scope was advanced with a
protruding tool
Level of % of procedure time that EMR
consciousness during | the patient was in each
procedure level of consciousness
Consciousness checks | The number of times that EMR
during procedure the trainee checked the
patient’s consciousness
level
Vital signs above / The number of times that EMR
below alert threshold vital signs alert was
triggered
Use of sedatives Details of sedatives EMR

administration: Type and

Total amount

Page 6

surgicalscience


# Page 7

EMR/ESD Proctor Book
 
 
Page 7 
 
Reversal agents used 
Details of reversal agents 
administered: Type and 
Total amount 
EMR 
Oxygen supplement 
during procedure 
% of procedure time that 
the patient received oxygen 
supplement (per level: 
L/min) 
EMR 
Enhanced Imaging 
used 
Yes/No 
All 
Lesion was classified 
Yes/No and the correct 
type according to Paris 
classification 
EMR 
Injected volume 
The total amount of volume 
that was injected to elevate 
the lesion 
EMR 
Grabbing attempts 
using Snare 
The number of times that 
the snare was closed (or 
started to) around the 
lesion 
EMR 
Lesion was resected 
Yes/No and electrical 
settings that were used 
EMR 
Resected lesion was 
extracted 
Yes/No and extraction 
method - Snare/Suction 
EMR 
Snapshot taken during 
the procedure 
The number of times that a 
snapshot was taken, 
information includes the 
images 
ESD 
Risk of perforation 
occurred 
The number of times that 
electricity was applied with 
Snare too close to the 
intestinal wall (EMR) or too 
deep/too long with the 
Needle Knife (ESD) 
All 


[TABLE]
|                       |                              | EMR/ESD Proctor Book   |
|:----------------------|:-----------------------------|:-----------------------|
| Reversal agents used  | Details of reversal agents   | EMR                    |
|                       | administered: Type and       |                        |
|                       | Total amount                 |                        |
| Oxygen supplement     | % of procedure time that     | EMR                    |
| during procedure      | the patient received oxygen  |                        |
|                       | supplement (per level:       |                        |
|                       | L/min)                       |                        |
| Enhanced Imaging      | Yes/No                       | All                    |
| used                  |                              |                        |
| Lesion was classified | Yes/No and the correct       | EMR                    |
|                       | type according to Paris      |                        |
|                       | classification               |                        |
| Injected volume       | The total amount of volume   | EMR                    |
|                       | that was injected to elevate |                        |
|                       | the lesion                   |                        |
| Grabbing attempts     | The number of times that     | EMR                    |
| using Snare           | the snare was closed (or     |                        |
|                       | started to) around the       |                        |
|                       | lesion                       |                        |
| Lesion was resected   | Yes/No and electrical        | EMR                    |
|                       | settings that were used      |                        |
| Resected lesion was   | Yes/No and extraction        | EMR                    |
| extracted             | method - Snare/Suction       |                        |
| Snapshot taken during | The number of times that a   | ESD                    |
| the procedure         | snapshot was taken,          |                        |
|                       | information includes the     |                        |
|                       | images                       |                        |
| Risk of perforation   | The number of times that     | All                    |
| occurred              | electricity was applied with |                        |
|                       | Snare too close to the       |                        |
|                       | intestinal wall (EMR) or too |                        |
|                       | deep/too long with the       |                        |
|                       | Needle Knife (ESD)           |                        |

[OCR]
EMR/ESD Proctor Book

Reversal agents used Details of reversal agents EMR
administered: Type and
Total amount
Oxygen supplement % of procedure time that EMR
during procedure the patient received oxygen
supplement (per level:
L/min)
Enhanced Imaging Yes/No All
used
Lesion was classified Yes/No and the correct EMR
ype according to Paris
classification
Injected volume The total amount of volume | EMR
hat was injected to elevate
he lesion
Grabbing attempts The number of times that EMR
using Snare he snare was closed (or
started to) around the
esion
Lesion was resected Yes/No and electrical EMR
settings that were used
Resected lesion was Yes/No and extraction EMR
extracted method - Snare/Suction
Snapshot taken during | The number of times that a | ESD
the procedure snapshot was taken,
information includes the
images
Risk of perforation The number of times that All

occurred

electricity was applied with
Snare too close to the
intestinal wall (EMR) or too
deep/too long with the
Needle Knife (ESD)

surgicalscience

Page 7


# Page 8

GI Mentor 
 
Page 8 
 
Improper electrical 
settings used 
The number of times that 
wrong electrical settings 
were used  
ESD 
Lesion was fully 
marked 
Yes/No 
ESD: 
Marking 
tasks 
Wrong area was 
marked 
The number of times that 
the wrong area was marked  
ESD: 
Marking 
tasks 
Number of marked 
dots 
The number of dots that 
were coagulated to mark 
the lesion 
ESD: 
Marking 
tasks 
% of lesion 
circumference was 
marked 
 
ESD: 
Marking 
tasks 
Average distance 
between dots 
The average distance (in 
mm) between coagulation 
marks 
ESD: 
Marking 
tasks 
Full circumference was 
incised 
Yes/No 
ESD: 
Incision 
tasks 
% of circumference 
that was incised 
 
ESD: 
Incision 
tasks 
Wrong area was 
incised 
The number of times that 
wrong area was cut 
ESD: 
Incision 
tasks 


[TABLE]
| GI Mentor              |                           |          |
|:-----------------------|:--------------------------|:---------|
| Improper electrical    | The number of times that  | ESD      |
| settings used          | wrong electrical settings |          |
|                        | were used                 |          |
| Lesion was fully       | Yes/No                    | ESD:     |
| marked                 |                           | Marking  |
|                        |                           | tasks    |
| Wrong area was         | The number of times that  | ESD:     |
| marked                 | the wrong area was marked | Marking  |
|                        |                           | tasks    |
| Number of marked       | The number of dots that   | ESD:     |
| dots                   | were coagulated to mark   | Marking  |
|                        | the lesion                | tasks    |
| % of lesion            |                           | ESD:     |
| circumference was      |                           | Marking  |
| marked                 |                           | tasks    |
| Average distance       | The average distance (in  | ESD:     |
| between dots           | mm) between coagulation   | Marking  |
|                        | marks                     | tasks    |
| Full circumference was | Yes/No                    | ESD:     |
| incised                |                           | Incision |
|                        |                           | tasks    |
| % of circumference     |                           | ESD:     |
| that was incised       |                           | Incision |
|                        |                           | tasks    |
| Wrong area was         | The number of times that  | ESD:     |
| incised                | wrong area was cut        | Incision |
|                        |                           | tasks    |

[OCR]
Gl Mentor

Improper electrical The number of times that ESD
settings used wrong electrical settings
were used
Lesion was fully Yes/No ESD:
marked Marking
asks
Wrong area was The number of times that ESD:
marked the wrong area was marked | Marking
asks
Number of marked The number of dots that ESD:
dots were coagulated to mark Marking
the lesion asks
% of lesion ESD:
circumference was Marking
marked asks
Average distance The average distance (in ESD:
between dots mm) between coagulation Marking
marks asks
Full circumference was | Yes/No ESD:
incised Incision
asks
% of circumference ESD:
that was incised Incision
asks
Wrong area was The number of times that ESD:
incised wrong area was cut Incision
asks

Page 8

surgicalscience


# Page 9

EMR/ESD Proctor Book
 
 
Page 9 
 
Main Features and In-Scene Buttons  
Feature 
Description 
Patient File 
Review the patient’s medical history and 
case objectives 
3D map 
Dynamic external view of the GI tract 
and the current position of the 
endoscope during the procedure 
Enhanced Imaging 
button 
Filter on the scope’s camera view to 
enhance the visualization of vascular 
patterns 
Classification of the 
lesion 
Classification of the tumor according to 
Paris Classification of superficial 
neoplastic lesions 
Snapshot button 
Captures and saves snapshots of the 
scope’s display while working. You can 
then view the images in the trainee 
report.  
Distal Attachment 
Addition of distal attachment at the 
scope tip, allows traction of tissue for 
better visualization while working 
Irrigation 
Applying water-jet forward irrigation 
using the foot pedal 
 


[TABLE]
| Main Features and In-Scene Buttons   |                                          |
|:-------------------------------------|:-----------------------------------------|
| Feature                              | Description                              |
| Patient File                         | Review the patient’s medical history and |
|                                      | case objectives                          |
| 3D map                               | Dynamic external view of the GI tract    |
|                                      | and the current position of the          |
|                                      | endoscope during the procedure           |
| Enhanced Imaging                     | Filter on the scope’s camera view to     |
| button                               | enhance the visualization of vascular    |
|                                      | patterns                                 |
| Classification of the                | Classification of the tumor according to |
| lesion                               | Paris Classification of superficial      |
|                                      | neoplastic lesions                       |
| Snapshot button                      | Captures and saves snapshots of the      |
|                                      | scope’s display while working. You can   |
|                                      | then view the images in the trainee      |
|                                      | report.                                  |
| Distal Attachment                    | Addition of distal attachment at the     |
|                                      | scope tip, allows traction of tissue for |
|                                      | better visualization while working       |
| Irrigation                           | Applying water-jet forward irrigation    |
|                                      | using the foot pedal                     |

[OCR]
EMR/ESD Proctor Book

Main Features and In-Scene Buttons

Feature Description

Patient File Review the patient’s medical history and
case objectives

3D map Dynamic external view of the Gl tract
and the current position of the
endoscope during the procedure

Enhanced Imaging Filter on the scope’s camera view to

button enhance the visualization of vascular
patterns

Classification of the Classification of the tumor according to

lesion Paris Classification of superficial

neoplastic lesions

Snapshot button Captures and saves snapshots of the
scope’s display while working. You can
then view the images in the trainee
report.

Distal Attachment Addition of distal attachment at the
scope tip, allows traction of tissue for
better visualization while working

Irrigation Applying water-jet forward irrigation
using the foot pedal

surgicalscience Page 9