

# Page 1

ENDO Suite - BRONCH Mentor
 
Simulator
User Guide


[TABLE]
| ENDO Suite - BRONCH Mentor   |
|:-----------------------------|
| Simulator                    |
| User Guide                   |

[OCR]
User Guide

surgical


# Page 2

 
 
 
 
ENDO SUITE -  
BRONCH MENTOR® 
User Guide 
 
 
October 2024 
 
 
08-BRUG-W1024 
 
 


[TABLE]
| E              |
|                |
|                |
| NDO SUITE -    |
|:---------------|
| BRONCH MENTOR® |
| User Guide     |
| O              |
| ctober 2024    |
| 0              |
|                |
| 8-BRUG-W1024   |

[OCR]
ENDO SUITE -
BRONCH MENTOR®

User Guide
October 2024

08-BRUG-W1024

surgicalscience


# Page 3

Contents
 
Page ii
 
Contents 
 
Chapter 1 
Safety Precautions 
1 
Chapter 2 
System Overview 
4 
Growing library of modules 
4 
Working modes 
4 
Training management system 
4 
Chapter 3 
ENDO Mentor Suite System 
5 
Hardware platform 
5 
GI-BRONCH interchangeable cartridge 
7 
URO interchangeable cartridge 
8 
Scope hanger 
9 
Connecting the scope 
10 
Extensions 
11 
Working positions 
11 
Height elevation mechanism 
12 
Turning on the simulator 
12 
Tool tray 
13 
Foot switch 
15 
Available endoscope 
15 


[TABLE]
| Chapter 3                           |   5 |
| ENDO Mentor Suite System            |     |
|:------------------------------------|----:|
| Hardware platform                   |   5 |
| GI-BRONCH interchangeable cartridge |   7 |
| URO interchangeable cartridge       |   8 |
| Scope hanger                        |   9 |
| Connecting the scope                |  10 |
| Extensions                          |  11 |
| Working positions                   |  11 |
| Height elevation mechanism          |  12 |
| Turning on the simulator            |  12 |
| Tool tray                           |  13 |
| Foot switch                         |  15 |

[OCR]
Contents

| Contents

Chapter 1 Safety Precautions 1
Chapter 2 System Overview 4
Growing library of modules 4
Working modes 4
Training management system 4
Chapter 3. ENDO Mentor Suite System 5
Hardware platform 5
GI-BRONCH interchangeable cartridge 7
URO interchangeable cartridge 8
Scope hanger 9
Connecting the scope 10
Extensions 11
Working positions 11
Height elevation mechanism 12
Turning on the simulator 12
Tool tray 13
Foot switch 15
Available endoscope 15
surgicalscience Page ii


# Page 4

Contents
 
Page iii
 
Bronchoscope 
15 
Auxiliary tools and connectors 
16 
BRONCH Mentor tools 
16 
Chapter 4 
BRONCH Express Platform 
20 
Simulation unit 
22 
Bronchoscope 
23 
Auxiliary tools 
24 
Setup 
24 
BRONCH Express basic display mode 
31 
BRONCH Express unique features 
33 
Chapter 5 
Getting Started 
35 
Essential workflow 
35 
Chapter 6 
MentorLearn 
36 
MentorLearn workflow 
36 
Logging in to MentorLearn on the simulator 
37 
Working locally and on a cloud site 
39 
Accessing a module or course within My Curricula or Library 
40 
Easy Access to courses and modules in the Library 
42 
Reviewing didactic materials 
43 


[TABLE]
|                                                             |   Contents |
|:------------------------------------------------------------|-----------:|
| Bronchoscope                                                |         15 |
| Auxiliary tools and connectors                              |         16 |
| BRONCH Mentor tools                                         |         16 |
| Chapter 4                                                   |         20 |
| BRONCH Express Platform                                     |            |
| Simulation unit                                             |         22 |
| Bronchoscope                                                |         23 |
| Auxiliary tools                                             |         24 |
| Setup                                                       |         24 |
| BRONCH Express basic display mode                           |         31 |
| BRONCH Express unique features                              |         33 |
| Chapter 5                                                   |         35 |
| Getting Started                                             |            |
| Essential workflow                                          |         35 |
| Chapter 6                                                   |         36 |
| MentorLearn                                                 |            |
| MentorLearn workflow                                        |         36 |
| Logging in to MentorLearn on the simulator                  |         37 |
| Working locally and on a cloud site                         |         39 |
| Accessing a module or course within My Curricula or Library |         40 |
| Easy Access to courses and modules in the Library           |         42 |
| Reviewing didactic materials                                |         43 |

[OCR]
Contents

Bronchoscope 15
Auxiliary tools and connectors 16
BRONCH Mentor tools 16
Chapter 4 BRONCH Express Platform 20
Simulation unit 22
Bronchoscope 23
Auxiliary tools 24
Setup 24
BRONCH Express basic display mode 31
BRONCH Express unique features 33
Chapter5 Getting Started 35
Essential workflow 35
Chapter6  MentorLearn 36
MentorLearn workflow 36
Logging in to MentorLearn on the simulator 37
Working locally and on a cloud site 39
Accessing a module or course within My Curricula or Library 40
Easy Access to courses and modules in the Library 42
Reviewing didactic materials 43
surgicalscience Page iii


# Page 5

Contents
 
Page iv
 
Starting a simulation case or task 
44 
Viewing course/module completion status 
46 
Completion status for modules/courses with benchmarks 
47 
Proficiency scoreboard for cases/tasks with benchmarks 
48 
Chapter 7 
BRONCH Mentor Display Modes 
50 
Pre-procedure options 
50 
Enhanced clinical display mode 
51 
Simulation environment 
51 
Screen layout - Single modality (WLB/Video) 
52 
Features and educational aids - single modality 
52 
Screen layout - dual modality (WLB/Video, EBUS) 
65 
Features and educational aids - dual modality 
66 
Unique task features – dual modality 
75 
Procedure Restricted display mode 
80 
Simulation environment 
80 
Screen layout - single modality (WLB/Video) 
81 
Screen layout - dual modality (WLB/Video, EBUS) 
82 
Features 
82 
Designated Tasks display mode 
84 
Simulation environment 
84 


[TABLE]
|                                                        |   Contents |
|:-------------------------------------------------------|-----------:|
| Starting a simulation case or task                     |         44 |
| Viewing course/module completion status                |         46 |
| Completion status for modules/courses with benchmarks  |         47 |
| Proficiency scoreboard for cases/tasks with benchmarks |         48 |
| Chapter 7                                              |         50 |
| BRONCH Mentor Display Modes                            |            |
| Pre-procedure options                                  |         50 |
| Enhanced clinical display mode                         |         51 |
| Simulation environment                                 |         51 |
| Screen layout - Single modality (WLB/Video)            |         52 |
| Features and educational aids - single modality        |         52 |
| Screen layout - dual modality (WLB/Video, EBUS)        |         65 |
| Features and educational aids - dual modality          |         66 |
| Unique task features – dual modality                   |         75 |
| Procedure Restricted display mode                      |         80 |
| Simulation environment                                 |         80 |
| Screen layout - single modality (WLB/Video)            |         81 |
| Screen layout - dual modality (WLB/Video, EBUS)        |         82 |
| Features                                               |         82 |
| Designated Tasks display mode                          |         84 |
| Simulation environment                                 |         84 |

[OCR]
Contents

Starting a simulation case or task 44
Viewing course/module completion status 46
Completion status for modules/courses with benchmarks 47
Proficiency scoreboard for cases/tasks with benchmarks 48
Chapter 7 =BRONCH Mentor Display Modes 50
Pre-procedure options 50
Enhanced clinical display mode 51
Simulation environment 51
Screen layout - Single modality (WLB/Video) 52
Features and educational aids - single modality 52
Screen layout - dual modality (WLB/Video, EBUS) 65
Features and educational aids - dual modality 66
Unique task features — dual modality 75
Procedure Restricted display mode 80
Simulation environment 80
Screen layout - single modality (WLB/Video) 81
Screen layout - dual modality (WLB/Video, EBUS) 82
Features 82
Designated Tasks display mode 84
Simulation environment 84
surgicalscience Page iv


# Page 6

Contents
 
Page v
 
Screen layout 
84 
General features and educational aids 
85 
Unique task features 
87 
Chapter 8 
Virtual Patient Monitoring and Management 
97 
Patient management region 
97 
Vital signs monitoring 
97 
Consciousness level monitoring 
98 
Oxygen supplement 
99 
Moderate sedation administration 
99 
Administered sedatives list 
100 
General anesthesia option 
101 
Chapter 9 
Working with Auxiliary Tools 
103 
Working with the Master Tool 
103 
Using the Virtual Activation feature 
105 
Working with the syringe 
106 
Working with multiple tools 
110 
Working with tools requiring electricity 
111 
Chapter 10 
Viewing Performance Reports 
113 
Viewing reports 
113 
Browsing between sessions 
116 


[TABLE]
|                                           |   Contents |
|:------------------------------------------|-----------:|
| Screen layout                             |         84 |
| General features and educational aids     |         85 |
| Unique task features                      |         87 |
| Chapter 8                                 |         97 |
| Virtual Patient Monitoring and Management |            |
| Patient management region                 |         97 |
| Vital signs monitoring                    |         97 |
| Consciousness level monitoring            |         98 |
| Oxygen supplement                         |         99 |
| Moderate sedation administration          |         99 |
| Administered sedatives list               |        100 |
| General anesthesia option                 |        101 |
| Chapter 9                                 |        103 |
| Working with Auxiliary Tools              |            |
| Working with the Master Tool              |        103 |
| Using the Virtual Activation feature      |        105 |
| Working with the syringe                  |        106 |
| Working with multiple tools               |        110 |
| Working with tools requiring electricity  |        111 |
| Chapter 10                                |        113 |
| Viewing Performance Reports               |            |
| Viewing reports                           |        113 |
| Browsing between sessions                 |        116 |

[OCR]
Contents

Screen layout 84
General features and educational aids 85
Unique task features 87
Chapter 8 Virtual Patient Monitoring and Management 97
Patient management region 97
Vital signs monitoring 97
Consciousness level monitoring 98
Oxygen supplement 99
Moderate sedation administration 99
Administered sedatives list 100
General anesthesia option 101
Chapter 9 Working with Auxiliary Tools 103
Working with the Master Tool 103
Using the Virtual Activation feature 105
Working with the syringe 106
Working with multiple tools 110
Working with tools requiring electricity 111
Chapter 10 Viewing Performance Reports 113
Viewing reports 113
Browsing between sessions 116
surgicalscience Page v


# Page 7

Contents
 
Page vi
 
Viewing recorded videos 
116 
Understanding the scoreboard 
118 
Understanding benchmarks and rating scales 
120 
Understanding learning curve graphs 
120 
Exporting performance results 
122 
Chapter 11 
Technical Support 
123 
SURGICAL SCIENCE SUPPORT POLICY 
123 
Surgical Science Call Center 
123 
Chapter 12 
End-User Software License Agreement 
124 
BRONCH Mentor® 
124 
1  EXTENT OF LICENSE 
124 
2  CONFIDENCE OF THE SOFTWARE AND COPYRIGHT 
125 
3  OWNERSHIP OF SOFTWARE 
126 
4  SUPPORT SERVICES 
126 
5  INTEGRITY OF THE SOFTWARE 
127 
6  RIGHT OF ACCESS 
127 
7  WARRANTY AND LIMITATION OF LIABILITY 
128 
8  TERMINATION 
129 
9.  MISCELLANEOUS 
130 
Index 
131 


[TABLE]
|                                             |   Contents |
|:--------------------------------------------|-----------:|
| Viewing recorded videos                     |        116 |
| Understanding the scoreboard                |        118 |
| Understanding benchmarks and rating scales  |        120 |
| Understanding learning curve graphs         |        120 |
| Exporting performance results               |        122 |
| Chapter 11                                  |        123 |
| Technical Support                           |            |
| SURGICAL SCIENCE SUPPORT POLICY             |        123 |
| Surgical Science Call Center                |        123 |
| Chapter 12                                  |        124 |
| End-User Software License Agreement         |            |
| BRONCH Mentor®                              |        124 |
| 1  EXTENT OF LICENSE                        |        124 |
| 2  CONFIDENCE OF THE SOFTWARE AND COPYRIGHT |        125 |
| 3  OWNERSHIP OF SOFTWARE                    |        126 |
| 4  SUPPORT SERVICES                         |        126 |
| 5  INTEGRITY OF THE SOFTWARE                |        127 |
| 6  RIGHT OF ACCESS                          |        127 |
| 7  WARRANTY AND LIMITATION OF LIABILITY     |        128 |
| 8  TERMINATION                              |        129 |
| 9.  MISCELLANEOUS                           |        130 |
| Index                                       |        131 |

[OCR]
Contents

Viewing recorded videos 116
Understanding the scoreboard 118
Understanding benchmarks and rating scales 120
Understanding learning curve graphs 120
Exporting performance results 122
Chapter 11 Technical Support 123
SURGICAL SCIENCE SUPPORT POLICY 123
Surgical Science Call Center 123
Chapter 12 End-User Software License Agreement 124
BRONCH Mentor® 124

1 EXTENT OF LICENSE 124

2 CONFIDENCE OF THE SOFTWARE AND COPYRIGHT 125

3 OWNERSHIP OF SOFTWARE 126

4 SUPPORT SERVICES 126

5 INTEGRITY OF THE SOFTWARE 127

6 RIGHT OF ACCESS 127

7 WARRANTY AND LIMITATION OF LIABILITY 128

8 TERMINATION 129

9. MISCELLANEOUS 130
Index 131
surgicalscience Page vi


# Page 8

Figures
 
Page vii
 
Figures 
 
Figure 3-1: ENDO Mentor Suite - GI Mentor platform ......................................................... 6 
Figure 3-2: GI-BRONCH interchangeable cartridge – lower orifice selected ................... 7 
Figure 3-3: URO interchangeable cartridge ......................................................................... 8 
Figure 3-4: Scope hanger  – Bronchoscope ........................................................................ 9 
Figure 3-5: System and scope connectors ......................................................................... 10 
Figure 3-6:  Lateral working position (left), Superior working position (right) ................ 11 
Figure 3-7: Height elevation panel – (from left to right) USB port, Height Elevation 
mechanism, Computer On/Off button ................................................................................. 12 
Figure 3-8: Tool tray hanger with BRONCH tools .............................................................. 13 
Figure 3-9: Tool connection outlets .................................................................................... 14 
Figure 3-10: Foot switch ....................................................................................................... 15 
Figure 3-11: Bronchoscope ................................................................................................... 16 
Figure 3-12: Master Tool ...................................................................................................... 17 
Figure 3-13: Syringe .............................................................................................................. 17 
Figure 4-1: The BRONCH Express carry-on case .............................................................. 20 
Figure 4-2: BRONCH Express platform ............................................................................... 21 
Figure 4-3: Simulation unit components ............................................................................ 22 
Figure 4-4: BRONCH Express bronchoscope .................................................................... 23 
Figure 4-5: Bronchoscope’s insertion tube storage trail .................................................. 25 
Figure 4-6: Removing the rods to detach the cover ......................................................... 26 
Figure 4-7: Simulation unit connectors .............................................................................. 28 
Figure 4-8: Bronchoscope connected to simulation unit ................................................. 29 
Figure 4-9: Laptop connectors ........................................................................................... 30 
Figure 4-10: BRONCH Express basic display mode ........................................................... 31 
Figure 6-1: MentorLearn Login screen ............................................................................... 37 


[TABLE]
| Figures                                                                                                                                |
|:---------------------------------------------------------------------------------------------------------------------------------------|
| Figures                                                                                                                                |
| F                                                                                                                                      |
| igure 3-1: ENDO Mentor Suite - GI Mentor platform ......................................................... 6                          |
| Figure 3-2: GI-BRONCH interchangeable cartridge – lower orifice selected ................... 7                                         |
| Figure 3-3: URO interchangeable cartridge ......................................................................... 8                  |
| Figure 3-4: Scope hanger  – Bronchoscope ........................................................................ 9                    |
| Figure 3-5: System and scope connectors ......................................................................... 10                   |
| Figure 3-6:  Lateral working position (left), Superior working position (right) ................ 11                                    |
| Figure 3-7: Height elevation panel – (from left to right) USB port, Height Elevation                                                   |
| mechanism, Computer On/Off button ................................................................................. 12                 |
| Figure 3-8: Tool tray hanger with BRONCH tools .............................................................. 13                       |
| Figure 3-9: Tool connection outlets .................................................................................... 14            |
| Figure 3-10: Foot switch ....................................................................................................... 15    |
| Figure 3-11: Bronchoscope ................................................................................................... 16       |
| Figure 3-12: Master Tool ...................................................................................................... 17     |
| Figure 3-13: Syringe .............................................................................................................. 17 |
| Figure 4-1: The BRONCH Express carry-on case .............................................................. 20                         |
| Figure 4-2: BRONCH Express platform ............................................................................... 21                 |
| Figure 4-3: Simulation unit components ............................................................................ 22                 |
| Figure 4-4: BRONCH Express bronchoscope .................................................................... 23                        |
| Figure 4-5: Bronchoscope’s insertion tube storage trail .................................................. 25                          |
| Figure 4-6: Removing the rods to detach the cover ......................................................... 26                         |
| Figure 4-7: Simulation unit connectors .............................................................................. 28               |
| Figure 4-8: Bronchoscope connected to simulation unit ................................................. 29                             |
| Figure 4-9: Laptop connectors ........................................................................................... 30           |
| Figure 4-10: BRONCH Express basic display mode ........................................................... 31                          |
| Figure 6-1: MentorLearn Login screen ............................................................................... 37                |

[OCR]
Figures

| Figures

Figure 3-1: ENDO Mentor Suite - Gl Mentor platform... cece eseeeeeeseeeeeeeseeseeecseeneeeee 6
Figure 3-2: GI-BRONCH interchangeable cartridge — lower orifice selected ............. 7
Figure 3-3: URO interchangeable Cartridge... ee eeeesessesceeecseeeceecseeeeeeeeeeeeeeeseeaeeesseeeeeeees 8
Figure 3-4: Scope hanger — BronchoSCope «uu... eseeeeeseeseeeeeeeseeecseceeeeeeeesesaeeeseeaceecseeeeeeee 9
Figure 3-5: System and SCOPE CONNECHOSS........eeeeseseeeeseesceecscesseecseeeeeceseeseeeceeseeaseeeaeeess 10
Figure 3-6: Lateral working position (left), Superior working position (right) ................ 11
Figure 3-7: Height elevation panel — (from left to right) USB port, Height Elevation

mechanism, Computer On/Off DUttON 0... eee eeeeeeeeseeeeeeeeeeseseeseeacsecseeeeseesesaeeeeseeseeaeseeneenes 12
Figure 3-8: Tool tray hanger with BRONCH tools «00.0... cesesecseeeeecseeeeeeeeseeecseeaeeeseeeeeeees 13
Figure 3-9: Tool CONNECTION OUTIETS oe eeeeeseeeeeeeeeeeeeeseescsccaceaeeecseeaeeeeseeaceesetsceaeseeaeeees 14
Figure 3-10: Foot SWitCH...... eee eeeeseseseeseesceecseesseecseeaeseeseesceacsecseeassecsesaeseeseeaeeasseeaseaseeeneeess 15

Figure 3-11: Bronchoscope
Figure 3-12: Master Tool ..
Figure 3-13: Syringe....
Figure 4-1: The BRONCH Express carry-on case
Figure 4-2: BRONCH Express platform..
Figure 4-3: Simulation unit components...
Figure 4-4: BRONCH Express bronchoscope..

Figure 4-5: Bronchoscope’s insertion tube storage trail

Figure 4-6: Removing the rods to detach the cover... 26
Figure 4-7: Simulation UNit CONNECTOSS ........ eee eeeeeseeeeeeeseeececesceaceecsecseeeeeeseseceeseeaseeseeees 28
Figure 4-8: Bronchoscope connected to SiMUIAatiON UNit 0... eee eeeeeeeeeeeeeeeeeeeeeeeee 29
Figure 4-9: Laptop CONNECHOSS .......eeeeeescsseeseeeesceececcseeseseeseescsacseeaceecsecseeaeseeseeaceeseeaseaeeeees 30
Figure 4-10: BRONCH Express basic display MOC... eeseeseeceseeeeeeeeeseeetseeseeeeeeeeeeees 31
Figure 6-1: MentorLearn LOGIN SCrEEN ue eeseesceecseeseeceseescsecsceacecsecseeeeseeseeaeeeeseeaseeseeees 37

surgicalscience Page vii


# Page 9

Figures
 
Page viii
 
Figure 6-2: My Curricula page ............................................................................................ 40 
Figure 6-3: BRONCH Mentor Library page ......................................................................... 41 
Figure 6-4: Opening a module ............................................................................................ 43 
Figure 6-5: Task description or patient file ........................................................................ 46 
Figure 6-6: Modules/courses with no benchmarks........................................................... 47 
Figure 6-7: Completion status for modules/courses with benchmarks .......................... 47 
Figure 6-8: Module/Course Description page with benchmarks ..................................... 48 
Figure 6-9: Completion status for cases/tasks with benchmarks ................................... 48 
Figure 6-10: Required Skill Level information .................................................................... 49 
Figure 7-1: Pre-Procedure screen ........................................................................................ 51 
Figure 7-2: White Light Bronchoscopy (Video) layout ...................................................... 52 
Figure 7-3: Primary view – bronchoscopic display ........................................................... 53 
Figure 7-4: Compass feature enabled ................................................................................ 54 
Figure 7-5: Labeled airways ................................................................................................ 55 
Figure 7-6: Transparent wall revealing lymph nodes ........................................................ 56 
Figure 7-7: Tool panel .......................................................................................................... 56 
Figure 7-8: Display content options ................................................................................... 58 
Figure 7-9: 3D Map display ................................................................................................. 59 
Figure 7-10: Anatomy atlas display .................................................................................... 60 
Figure 7-11: Anatomy atlas filtering window ....................................................................... 61 
Figure 7-12: Virtual instructor button ON with real time warning .................................... 62 
Figure 7-13: Real time alert .................................................................................................. 63 
Figure 7-14: Main view – freeze feature ............................................................................. 64 
Figure 7-15: Video Bronchoscopy and Endobronchial Ultrasound layout ...................... 65 
Figure 7-16: Main View – bronchoscopic and EBUS display ............................................ 66 
Figure 7-17: Labeled anatomical structures on the ultrasound display .......................... 68 
Figure 7-18: Doppler region on ultrasound image ............................................................. 69 


[TABLE]
| Figures                                                                                                                              |
|:-------------------------------------------------------------------------------------------------------------------------------------|
| Figure 6-2: My Curricula page ............................................................................................ 40        |
| Figure 6-3: BRONCH Mentor Library page ......................................................................... 41                  |
| Figure 6-4: Opening a module ............................................................................................ 43         |
| Figure 6-5: Task description or patient file ........................................................................ 46             |
| Figure 6-6: Modules/courses with no benchmarks........................................................... 47                         |
| Figure 6-7: Completion status for modules/courses with benchmarks .......................... 47                                      |
| Figure 6-8: Module/Course Description page with benchmarks ..................................... 48                                  |
| Figure 6-9: Completion status for cases/tasks with benchmarks ................................... 48                                 |
| Figure 6-10: Required Skill Level information .................................................................... 49                |
| Figure 7-1: Pre-Procedure screen ........................................................................................ 51         |
| Figure 7-2: White Light Bronchoscopy (Video) layout ...................................................... 52                        |
| Figure 7-3: Primary view – bronchoscopic display ........................................................... 53                      |
| Figure 7-4: Compass feature enabled ................................................................................ 54              |
| Figure 7-5: Labeled airways ................................................................................................ 55      |
| Figure 7-6: Transparent wall revealing lymph nodes ........................................................ 56                       |
| Figure 7-7: Tool panel .......................................................................................................... 56 |
| Figure 7-8: Display content options ................................................................................... 58           |
| Figure 7-9: 3D Map display ................................................................................................. 59      |
| Figure 7-10: Anatomy atlas display .................................................................................... 60           |
| Figure 7-11: Anatomy atlas filtering window ....................................................................... 61               |
| Figure 7-12: Virtual instructor button ON with real time warning .................................... 62                             |
| Figure 7-13: Real time alert .................................................................................................. 63   |
| Figure 7-14: Main view – freeze feature ............................................................................. 64             |
| Figure 7-15: Video Bronchoscopy and Endobronchial Ultrasound layout ...................... 65                                        |
| Figure 7-16: Main View – bronchoscopic and EBUS display ............................................ 66                              |
| Figure 7-17: Labeled anatomical structures on the ultrasound display .......................... 68                                   |
| Figure 7-18: Doppler region on ultrasound image ............................................................. 69                     |

[OCR]
Figures

Figure 6-2:

Figure 6-3:

Figure 6-4:

Figure 6-5:

Figure 6-6:

Figure 6-7:

Figure 6-8:

Figure 6-9:

Figure 6-10: Required Skill Level information..

Figure 7-1:

1

Figure 7-2:

Figure 7-3:

Figure 7-4:

Figure 7-5:

Figure 7-6:

Figure 7-7:

Figure 7-8:

Figure 7-9:

Figure 7-
Figure 7-

Figure 7-1

Figure 7-
Figure 7-
Figure 7-
Figure 7-
Figure 7-
Figure 7-

MY CUrriCUla PAGE ..... eee eteeeeeeteeeeeeeseescsecsceseecseeseeeeseeaceacsecaeeacseeseeeeeeeaeeatseeaeee 40
BRONCH Mentor Library page ........c cs eeessesseeesceceeceecseeeceeeeeeeseesceeeeeseeeseeseeees 41

Opening a module ...

Task description or patient file .46
Modules/courses with no benchmarks... .47
Completion status for modules/courses with benchmarks .47
Module/Course Description page with benchmarks. 48
Completion status for cases/tasks with benchmarks.. 48

.49

Pre-Procedure screen.. 91
White Light Bronchoscopy (Video) layout.... .52
Primary view — bronchoscopic display ...........:.seseceesesseeeseeeeeceecseeeceeeeeeeeeeeees 53
Compass feature Cnabled........ ce eeseeeeeseeeeeeseeseeeceeseeeesesseeeeseeseeeceeseeeeeeees 54
Labeled airwayS ........ ce ecssscescseesseeceecesseseescescecseesseecseseeeeesesaeeessceaeeeesesaeeeseeeaes 55
Transparent wall revealing IYMPh NOCES..........seeeeseeseeeceseeeeeeeeeeceeeeeseeeeeeees 56
TOO] Panel oe. seeeesseescsceeeseeeeseeseseesesscecseeaseacseeseeeeseescacseeseeesesseeeeeeesesaeaeaeee 56
Display CONTENt OPTIONS ..... eee eseeeteeseeseeecsceseeecseeseeeeseesesecaeeseeecseesseeeeeeaes 58
3D Map display ......... ee eeesseeseeeesseectseseeseseeseescsecseesseecseseeseeseeseecseeseeeseeeeeeeeeeeaes 59
O: Anatomy atlas display occ eeeseseseeseesceeescesceececseeeeeecsesaeeetseeaeeeeseeseeeeseeats 60
1: Anatomy atlas filtering WINKOW...... ee eeeeeeeseeeeeeeeeseeeeeeeeeeeseesceecseeaeeeseeeaeeaes 61
2: Virtual instructor button ON with real time Warning............eeseeeeeeeeeeeeees 62
3: Real time alert... cece eee cececscsesetecsesssesscsesssesessesseesessesseesesseseeenees 63
4: Main view — freeze feature... cece ces cseeeceeecsensceescsesesenscsesesenseseeenenes 64
5: Video Bronchoscopy and Endobronchial Ultrasound layout ........ eee 65
6: Main View — bronchoscopic and EBUS display ........... ce sseeeeeeceseeeeteeeeeeeeeees 66
7: Labeled anatomical structures on the ultrasound display .......... eee 68
8: Doppler region on UltraSOUNC IMAGE... eeeseeeeeeseeeeeeseeseeeeeeeaceeceeseeeeeeees 69

surgicalscience Page viii


# Page 10

Figures
 
Page ix
 
Figure 7-19: Enhanced 3D Map and its controls ............................................................... 72 
Figure 7-20: Lymph Node Classification Map ................................................................... 73 
Figure 7-21: Tutorial movies ran from Complementary Display selection ...................... 74 
Figure 7-22: Tutorial movies ran from Instructions display .............................................. 75 
Figure 7-23: Selectable CT browser .................................................................................. 76 
Figure 7-24: Landmark list ................................................................................................... 77 
Figure 7-25: An overview display ....................................................................................... 78 
Figure 7-26: Step-by-Step instructions display ................................................................ 78 
Figure 7-27: Immediate Feedback for EBUS-TBNA .......................................................... 79 
Figure 7-28: Full screen mode – single modality bronchoscopy ...................................... 81 
Figure 7-29: Procedure Restricted display mode – dual modality ................................... 82 
Figure 7-30: Designated Tasks Display Mode screen ...................................................... 84 
Figure 7-31: Instructions display per task .......................................................................... 86 
Figure 7-32: Task 1 – Cyberscopy screen layout .............................................................. 87 
Figure 7-33: Directional Guidance feature ......................................................................... 88 
Figure 7-34: Task 3 – Bronchial segments recognition .................................................... 89 
Figure 7-35: Naming convention selection ........................................................................ 89 
Figure 7-36: Bronchial segments labeling indication ......................................................... 91 
Figure 7-37: Task 4 – Lymph node stations recognition ................................................... 91 
Figure 7-38: Focusing on an arrow ..................................................................................... 92 
Figure 7-39: Labeling a lymph node ................................................................................... 93 
Figure 7-40: Lymph nodes identification indications ........................................................ 93 
Figure 7-41: Enhanced 3D Map - Task 4 ........................................................................... 94 
Figure 7-42: Task 5 step by step diagnostic maneuvers ................................................. 95 
Figure 7-43: On-screen performance feedback ............................................................... 96 
Figure 8-1: Patient management region ............................................................................. 97 
Figure 8-2: Vital signs deviation alert ................................................................................. 98 


[TABLE]
| Figures                                                                                                                           |
|:----------------------------------------------------------------------------------------------------------------------------------|
| Figure 7-19: Enhanced 3D Map and its controls ............................................................... 72                  |
| Figure 7-20: Lymph Node Classification Map ................................................................... 73                 |
| Figure 7-21: Tutorial movies ran from Complementary Display selection ...................... 74                                   |
| Figure 7-22: Tutorial movies ran from Instructions display .............................................. 75                      |
| Figure 7-23: Selectable CT browser .................................................................................. 76          |
| Figure 7-24: Landmark list ................................................................................................... 77 |
| Figure 7-25: An overview display ....................................................................................... 78       |
| Figure 7-26: Step-by-Step instructions display ................................................................ 78                |
| Figure 7-27: Immediate Feedback for EBUS-TBNA .......................................................... 79                       |
| Figure 7-28: Full screen mode – single modality bronchoscopy ...................................... 81                            |
| Figure 7-29: Procedure Restricted display mode – dual modality ................................... 82                             |
| Figure 7-30: Designated Tasks Display Mode screen ...................................................... 84                       |
| Figure 7-31: Instructions display per task .......................................................................... 86          |
| Figure 7-32: Task 1 – Cyberscopy screen layout .............................................................. 87                  |
| Figure 7-33: Directional Guidance feature ......................................................................... 88            |
| Figure 7-34: Task 3 – Bronchial segments recognition .................................................... 89                      |
| Figure 7-35: Naming convention selection ........................................................................ 89              |
| Figure 7-36: Bronchial segments labeling indication ......................................................... 91                  |
| Figure 7-37: Task 4 – Lymph node stations recognition ................................................... 91                      |
| Figure 7-38: Focusing on an arrow ..................................................................................... 92        |
| Figure 7-39: Labeling a lymph node ................................................................................... 93         |
| Figure 7-40: Lymph nodes identification indications ........................................................ 93                   |
| Figure 7-41: Enhanced 3D Map - Task 4 ........................................................................... 94              |
| Figure 7-42: Task 5 step by step diagnostic maneuvers ................................................. 95                        |
| Figure 7-43: On-screen performance feedback ............................................................... 96                    |
| Figure 8-1: Patient management region ............................................................................. 97            |
| Figure 8-2: Vital signs deviation alert ................................................................................. 98      |

[OCR]
Figures

Figure 7-19:
Figure 7-20:
Figure 7-21:
Figure 7-22:
Figure 7-23:
Figure 7-24:
Figure 7-25:
Figure 7-26:
Figure 7-27:
Figure 7-28:

Enhanced 3D Map and its Controls ......... ec eeeseseeeeseeeecceeeeeeeceeeseeeeeeeseeeeeeeeees 72
Lymph Node Classification Map .... we 73

Tutorial movies ran from Complementary Display selection ..
Tutorial movies ran from Instructions display...
Selectable CT browser
Landmark list....
An overview display ..
Step-by-Step instructions display.
Immediate Feedback for EBUS-TBNA..... .79

Full screen mode - single modality bronchoscopy

Figure 7-29: Procedure Restricted display mode —- dual modality..... 82
Figure 7-30: Designated Tasks Display Mode SCr@@N..........eesceseesceecseeeeeeeeeeceeeeeeaseeeeeees 84
Figure 7-31: Instructions display Per task... eeeeseseeeeseeeeeeeeeseeeceecseeeeseeseseceeeseeaseeeseees 86
Figure 7-32: Task 1— Cyberscopy SCreen layOUt 0... ee eeseesseeteesceeceeeeeeeseseceecseeaseeeeeees 87
Figure 7-33: Directional Guidance feature... ee eeeeeeeseesceeeeeescescsecseeeceeeseseesetseeaseeeseees 88
Figure 7-34: Task 3 - Bronchial segments reCOQnition ......... eee eeeeseeseeeeeeeeeeeeeeeeeaeeeeeeeee 89
Figure 7-35: Naming Convention SeleCtion .........eeeeeeeeeseeceeeeeeseeececseeeceeeseeaeeeeseeaseeseees 89
Figure 7-36: Bronchial segments labeling indication... eseseeeseeeeceseeeeecteeseeeeeeeeeeees 91
Figure 7-37: Task 4 — Lymph node stations recognition ......... ce seeeeseeeeeeeeeeeeeeeeeeeeeeeeeees 91
Figure 7-38: FOCUSING ON AN AFOW........eseseeeseseeseecceeeseeseeeescescscescesceecseeseeeeseeaesaeeetseeaceeeseees 92
Figure 7-39: Labeling a lyMph N0de....... es eeseseesceecsseseeeescesceecseeaceecsecseeeeeesesaesetseeaceesseees 93
Figure 7-40: Lymph nodes identification INdiCAatiONS........ ee ees eeeeeseeeeeeeeeeeeeeeeeeeeeeeeeee 93
Figure 7-41: Enhanced 3D Map - Task 4 oo... eeeecssessseeseesceseeeesceecsecseeeeseeaesaceecseeaseeseeees 94
Figure 7-42: Task 5 step by step diagnostic MANCUVETS uuu... eee eseeeeeeeeeeeeeeeeeaeeeeeeeee 95
Figure 7-43: On-screen performance feedback ......... ce eesessceceseeeeeceeceeeeeeeeeseceecseeaseeeeeees 96
Figure 8-1: Patient MaNaGeEMENt FEGiON 0.0... eseceeesseeeeeseesceecseesceececseeeeeeeseeeceeseeaseeseeees 97
Figure 8-2: Vital SiIQns deviation Alert... ee esse ceseeeeeseesceeceeaeeececseeeeseesesaeeesseeaeeesseees 98

surgicalscience Page ix


# Page 11

Figures
 
Page x
 
Figure 8-3: Checking consciousness ................................................................................. 98 
Figure 8-4: Moderate sedation – sedative selection ...................................................... 100 
Figure 8-5: Administered Sedatives list ............................................................................ 101 
Figure 8-6: General Anesthesia indication in Patient Management region ................... 101 
Figure 8-7: Introducing the scope through an ET Tube ................................................. 102 
Figure 9-1: Tool selection menu in Diagnostic Bronchoscopy ....................................... 104 
Figure 9-2: Selected tool active and its Tool panel displayed ....................................... 105 
Figure 9-3: BAL tool panel ................................................................................................. 108 
Figure 9-4: BAL procedure – instilling saline ................................................................... 109 
Figure 9-5: Needle tool panel ............................................................................................. 110 
Figure 9-6: Cauterization probes tool panels ................................................................... 112 
Figure 10-1: Reports screen ............................................................................................... 113 
Figure 10-2: Viewing performance reports ....................................................................... 114 
Figure 10-3: Viewing video of simulation performance ................................................... 117 
Figure 10-4: Case benchmark scoreboard ....................................................................... 118 
Figure 10-5: Session benchmark scoreboard ................................................................... 119 
Figure 10-6: Benchmark rating scale ................................................................................ 120 
Figure 10-7: Report's learning curve .................................................................................. 121 
 


[TABLE]
| Figures                                                                                                                          |
|:---------------------------------------------------------------------------------------------------------------------------------|
| Figure 8-3: Checking consciousness ................................................................................. 98          |
| Figure 8-4: Moderate sedation – sedative selection ...................................................... 100                    |
| Figure 8-5: Administered Sedatives list ............................................................................ 101         |
| Figure 8-6: General Anesthesia indication in Patient Management region ................... 101                                   |
| Figure 8-7: Introducing the scope through an ET Tube ................................................. 102                       |
| Figure 9-1: Tool selection menu in Diagnostic Bronchoscopy ....................................... 104                           |
| Figure 9-2: Selected tool active and its Tool panel displayed ....................................... 105                        |
| Figure 9-3: BAL tool panel ................................................................................................. 108 |
| Figure 9-4: BAL procedure – instilling saline ................................................................... 109            |
| Figure 9-5: Needle tool panel ............................................................................................. 110  |
| Figure 9-6: Cauterization probes tool panels ................................................................... 112             |
| Figure 10-1: Reports screen ............................................................................................... 113  |
| Figure 10-2: Viewing performance reports ....................................................................... 114             |
| Figure 10-3: Viewing video of simulation performance ................................................... 117                     |
| Figure 10-4: Case benchmark scoreboard ....................................................................... 118               |
| Figure 10-5: Session benchmark scoreboard ................................................................... 119                |
| Figure 10-6: Benchmark rating scale ................................................................................ 120         |
| Figure 10-7: Report's learning curve .................................................................................. 121      |

[OCR]
Figures

Figure 8-3: Checking CONSCIOUSNESS ..........eeseessesceecsseseeeeseesccesceaceecsecseeeseeseeaeeeeseeaceeeaeees 98

Figure 8-4: Moderate sedation — sedative selection ...

Figure 8-5: Administered Sedatives list....
Figure 8-6: General Anesthesia indication in Patient Management region
Figure 8-7: Introducing the scope through an ET Tube.
Figure 9-1: Tool selection menu in Diagnostic Bronchoscopy.
Figure 9-2: Selected tool active and its Tool panel displayed.
Figure 9-3: BAL tool panel.

Figure 9-4: BAL procedure - instilling saline

Figure 9-5: Needle tool panel..... .-110
Figure 9-6: Cauterization probes tool panels.. 112
Figure 10-1: REPOrts SCrEON ou... eee eeeeeseesceeeeeesceeeseeseeeeseeseacsceseeacseeseeesseeaesasaeseeaceeaeeeseeee 113
Figure 10-2: Viewing performance reports ........ eee eeseeseeseeeeseesceecseeeeeeeseeseecseeaseeeeeeetenee 114
Figure 10-3: Viewing video of simulation performance ....... ce eeeeseeeseeeeeeteeeeeeeteeeeeeeee 117
Figure 10-4: Case benchmark SCOreDOAM «00... ee eeeeteeeeseeseeeeseesceeseeeeeeeseeeesecseeaseeeeeeeteees 118
Figure 10-5: Session benchmark SCOreDOAMC....... ee eeeeeeeeeceeesceecseeeeeeeseeseeeseeaseeeeeaeeetee 119
Figure 10-6: Benchmark rating SCal@...... ees eeeeeseeeeeeseesceecseesceecseeeeseeseeaceecseeseeeeeseeeess 120
Figure 10-7: Report's learning CUrVE.......eeeeesseceseeseeeeeeeseeecseeseeseeeeseeeeseeseeseaeseeaceeseeeseeees 121

surgicalscience Page x


# Page 12

Chapter 1 
 Safety Precautions
 
Page 1
 
Chapter 1 Safety Precautions 
Before using the ENDO Mentor Suite simulator, please read these safety precautions 
to ensure proper use of the equipment. These items contain important notes to 
prevent injury to the operator and damage to the equipment. The following precautions 
apply to both the GI Mentor and the BRONCH Mentor which share the ENDO Mentor 
Suite platform. 
Two symbols are used to indicate specific types of warnings in addition to the general 
note table, which is clearly marked: 
 
 
A warning that indicates a prohibition. 
 
A general warning that emphasizes essential information about something 
that must be done.  
 
The following safety precautions must be adhered to upon setup and using the ENDO 
Mentor Suite simulator. Failure to follow these precautions may result in the removal of 
the warranty and may cause irreversible damage to the simulator or injury to 
operators. 
 
 
Read all the instructions and precautions fully before attempting to 
setup or use the ENDO Mentor Suite simulator. 
 
Follow all warnings and instructions marked on the ENDO Mentor 
Suite simulator.  
 
 
Do not attempt to open, check, alter, or fix any part of the ENDO 
Mentor Suite system, unless directly asked to do so during a support 
session with a Surgical Science representative. 
 
Unplug the ENDO Mentor Suite simulator when you know an 
electrical storm is approaching.  


[TABLE]
| Chapter 1                                                                          | Safety Precautions                                                                     |
|:-----------------------------------------------------------------------------------|:---------------------------------------------------------------------------------------|
| Chapter 1  Safety Precautions                                                      |                                                                                        |
| Before using the ENDO Mentor Suite simulator, please read these safety precautions |                                                                                        |
| to ensure proper use of the equipment. These items contain important notes to      |                                                                                        |
|                                                                                    | prevent injury to the operator and damage to the equipment. The following precautions  |
| apply to both the GI Mentor and the BRONCH Mentor which share the ENDO Mentor      |                                                                                        |
| Suite platform.                                                                    |                                                                                        |
|                                                                                    | Two symbols are used to indicate specific types of warnings in addition to the general |
| note table, which is clearly marked:                                               |                                                                                        |

[TABLE]
| the warranty and may cause irreversible damage to the simulator or injury to   |
|:-------------------------------------------------------------------------------|
| Read all the instructions and precautions fully before attempting to           |
| setup or use the ENDO Mentor Suite simulator.                                  |
| Follow all warnings and instructions marked on the ENDO Mentor                 |
| Suite simulator.                                                               |
| Do not attempt to open, check, alter, or fix any part of the ENDO              |
| Mentor Suite system, unless directly asked to do so during a support           |
| session with a Surgical Science representative.                                |
| Unplug the ENDO Mentor Suite simulator when you know an                        |
| electrical storm is approaching.                                               |

[OCR]
Chapter 1 Safety Precautions

| Chapter 1 Safety Precautions

Before using the ENDO Mentor Suite simulator, please read these safety precautions
to ensure proper use of the equipment. These items contain important notes to
prevent injury to the operator and damage to the equipment. The following precautions
apply to both the GI Mentor and the BRONCH Mentor which share the ENDO Mentor
Suite platform.

Two symbols are used to indicate specific types of warnings in addition to the general
note table, which is clearly marked:

@ A warning that indicates a prohibition.

A general warning that emphasizes essential information about something
that must be done.

The following safety precautions must be adhered to upon setup and using the ENDO
Mentor Suite simulator. Failure to follow these precautions may result in the removal of
the warranty and may cause irreversible damage to the simulator or injury to
operators.

Read all the instructions and precautions fully before attempting to
setup or use the ENDO Mentor Suite simulator.

Follow all warnings and instructions marked on the ENDO Mentor
Suite simulator.

Do not attempt to open, check, alter, or fix any part of the ENDO
Mentor Suite system, unless directly asked to do so during a support
session with a Surgical Science representative.

Unplug the ENDO Mentor Suite simulator when you know an
electrical storm is approaching.

surgicalscience Page 1


# Page 13

Chapter 1 
 Safety Precautions
 
Page 2
 
 
Before cleaning, unplug the ENDO Mentor Suite simulator from the 
wall outlet. Use a dry cloth without liquid. Do not use aerosol 
cleaners. 
 
Do not use the ENDO Mentor Suite near water.  
 
When not in use or upon moving, disconnect all scopes from the 
system side connector. Failing to do so may result in irreparable 
damage. 
 
When not in use or upon moving, make sure that the tool tray is at its 
original folded position. Failing to do so may result in damage to the 
system. 
 
Make sure scopes and wires are not protruding before closing the 
drawer. Failing to do so may result in irreparable damage to the 
scopes or wires. 
 
When placing the ENDO Mentor Suite in a room with additional 
simulators, other electrical systems, or large amounts of metal, 
ensure that these items are at least 1 meter away from the ENDO 
Mentor Suite simulator. Failing to do so may result in an improper 
functioning of the simulator. 
 
Do not move the interchangeable cartridge in any way while the 
scope is inserted into the cavity. Doing so may result in irreparable 
scope damage. 
 
The interchangeable cartridge must be inserted and locked in place 
properly before attempting scope introduction for all the modalities 
to work. 
 
The bronchoscope’s insertion tube should not be bent unnecessarily 
- neither by attaching it to the hanger clip, nor by leaving it within the 
manikin when not being used. 
 
Do not leave the syringe, master tool, or any other instrument 
inserted in the scope’s working channel unnecessarily. 
 
Place the ENDO Mentor Suite on stable ground only. 


[TABLE]
| Safety Precautions                                                         |
|:---------------------------------------------------------------------------|
| Before cleaning, unplug the ENDO Mentor Suite simulator from the           |
| wall outlet. Use a dry cloth without liquid. Do not use aerosol            |
| cleaners.                                                                  |
| Do not use the ENDO Mentor Suite near water.                               |
| When not in use or upon moving, disconnect all scopes from the             |
| system side connector. Failing to do so may result in irreparable          |
| damage.                                                                    |
| When not in use or upon moving, make sure that the tool tray is at its     |
| original folded position. Failing to do so may result in damage to the     |
| system.                                                                    |
| Make sure scopes and wires are not protruding before closing the           |
| drawer. Failing to do so may result in irreparable damage to the           |
| scopes or wires.                                                           |
| When placing the ENDO Mentor Suite in a room with additional               |
| simulators, other electrical systems, or large amounts of metal,           |
| ensure that these items are at least 1 meter away from the ENDO            |
| Mentor Suite simulator. Failing to do so may result in an improper         |
| functioning of the simulator.                                              |
| Do not move the interchangeable cartridge in any way while the             |
| scope is inserted into the cavity. Doing so may result in irreparable      |
| scope damage.                                                              |
| The interchangeable cartridge must be inserted and locked in place         |
| properly before attempting scope introduction for all the modalities       |
| to work.                                                                   |
| The bronchoscope’s insertion tube should not be bent unnecessarily         |
| - neither by attaching it to the hanger clip, nor by leaving it within the |
| manikin when not being used.                                               |
| Do not leave the syringe, master tool, or any other instrument             |
| inserted in the scope’s working channel unnecessarily.                     |
| Place the ENDO Mentor Suite on stable ground only.                         |

[OCR]
Chapter 1

Safety Precautions

a5

Before cleaning, unplug the ENDO Mentor Suite simulator from the
wall outlet. Use a dry cloth without liquid. Do not use aerosol
cleaners.

Do not use the ENDO Mentor Suite near water.

When not in use or upon moving, disconnect all scopes from the
system side connector. Failing to do so may result in irreparable
damage.

When not in use or upon moving, make sure that the tool tray is at its
original folded position. Failing to do so may result in damage to the
system.

Make sure scopes and wires are not protruding before closing the
drawer. Failing to do so may result in irreparable damage to the
scopes or wires.

When placing the ENDO Mentor Suite in a room with additional
simulators, other electrical systems, or large amounts of metal,
ensure that these items are at least 1 meter away from the ENDO
Mentor Suite simulator. Failing to do so may result in an improper
functioning of the simulator.

Do not move the interchangeable cartridge in any way while the
scope is inserted into the cavity. Doing so may result in irreparable
scope damage.

The interchangeable cartridge must be inserted and locked in place
properly before attempting scope introduction for all the modalities
to work.

The bronchoscope’s insertion tube should not be bent unnecessarily
- neither by attaching it to the hanger clip, nor by leaving it within the
manikin when not being used.

Do not leave the syringe, master tool, or any other instrument
inserted in the scope’s working channel unnecessarily.

Place the ENDO Mentor Suite on stable ground only.

surgicalscience

Page 2


# Page 14

Chapter 1 
 Safety Precautions
 
Page 3
 
 
To protect the ENDO Mentor Suite from overheating, the opening on 
the back of the platform should not be covered or blocked.  
 
The ENDO Mentor Suite should not be placed near a radiator or heat 
register. 
 
The ENDO Mentor Suite should be placed in a room with a 
temperature range between 5 and 30 degrees centigrade. Proper 
ventilation is crucial.  
 
Do not allow anything to rest on the power cord or position the ENDO 
Mentor Suite where a cord could be stepped on or pulled out 
accidentally. 
 
Do not overload wall outlets and extension cords. 
 
Never spill liquid of any kind on the simulator. 
 
Avoid placing or dropping anything on the ENDO Mentor Suite. It may 
cause a malfunction or irreparable damage. 
 
Power must be off when handling the system or disconnecting any 
internal part during a support session.  
 
Unplug the ENDO Mentor Suite from the wall outlet and contact 
Surgical Science support under the following conditions:  
• 
When any cord, especially the power supply cord, is damaged 
or frayed. 
• 
If liquid has been spilled into the ENDO Mentor Suite. 
• 
If something has been dropped on the ENDO Mentor Suite. 
 
When opening the system’s back panel and pulling out the computer 
drawer during support – please note that the monitor must be in the 
opposite (front) side of the system and the computer drawer must be 
pulled out cautiously to avoid equilibrium problems. 
 


[TABLE]
|                                         | Safety Precautions                                                   |
|:----------------------------------------|:---------------------------------------------------------------------|
|                                         | To protect the ENDO Mentor Suite from overheating, the opening on    |
|                                         | the back of the platform should not be covered or blocked.           |
|                                         | The ENDO Mentor Suite should not be placed near a radiator or heat   |
| register.                               |                                                                      |
|                                         | The ENDO Mentor Suite should be placed in a room with a              |
|                                         | temperature range between 5 and 30 degrees centigrade. Proper        |
| ventilation is crucial.                 |                                                                      |
|                                         | Do not allow anything to rest on the power cord or position the ENDO |
|                                         | Mentor Suite where a cord could be stepped on or pulled out          |
| accidentally.                           |                                                                      |
|                                         | Do not overload wall outlets and extension cords.                    |
|                                         | Never spill liquid of any kind on the simulator.                     |
|                                         | Avoid placing or dropping anything on the ENDO Mentor Suite. It may  |
|                                         | cause a malfunction or irreparable damage.                           |
|                                         | Power must be off when handling the system or disconnecting any      |
| internal part during a support session. |                                                                      |
|                                         | Unplug the ENDO Mentor Suite from the wall outlet and contact        |
|                                         | Surgical Science support under the following conditions:             |
| •                                       | When any cord, especially the power supply cord, is damaged          |

[OCR]
Chapter 1

Safety Precautions

eeee oe ?ese

To protect the ENDO Mentor Suite from overheating, the opening on
the back of the platform should not be covered or blocked.

The ENDO Mentor Suite should not be placed near a radiator or heat
register.

The ENDO Mentor Suite should be placed in a room with a
temperature range between 5 and 30 degrees centigrade. Proper
ventilation is crucial.

Do not allow anything to rest on the power cord or position the ENDO
Mentor Suite where a cord could be stepped on or pulled out
accidentally.

Do not overload wall outlets and extension cords.

Never spill liquid of any kind on the simulator.

Avoid placing or dropping anything on the ENDO Mentor Suite. It may
cause a malfunction or irreparable damage.

Power must be off when handling the system or disconnecting any
internal part during a support session.

Unplug the ENDO Mentor Suite from the wall outlet and contact
Surgical Science support under the following conditions:

° When any cord, especially the power supply cord, is damaged
or frayed.

° If liquid has been spilled into the ENDO Mentor Suite.
° If something has been dropped on the ENDO Mentor Suite.

When opening the system’s back panel and pulling out the computer
drawer during support — please note that the monitor must be in the
opposite (front) side of the system and the computer drawer must be
pulled out cautiously to avoid equilibrium problems.

surgicalscience

Page 3


# Page 15

Chapter 2 
 System Overview
 
Page 4
 
Chapter 2 System Overview 
The ENDO Mentor Suite® is a multidisciplinary platform that provides hands-on 
practice of multiple BRONCH procedures as well as complete bronchoscopy 
procedures and basic endoscopic and bronchoscopic skills for single trainees or an 
entire team.  
The system is aimed at enhancing operational and medical decision-making, improving 
skills such as hand-eye coordination, and expanding medical knowledge. 
Growing library of modules 
The BRONCH Mentor® training system has been developed in collaboration with 
medical experts from around the world. It incorporates a variety of practice 
opportunities and provides an extensive bronchoscopic training curriculum made up of 
basic skills and simulation of full procedures.  
Working modes 
BRONCH Mentor has two main working modes:  
• 
Training mode – is designed to provide trainees with an extensive and complete 
simulation environment of the bronchoscopy procedure.  
• 
Management mode – is reserved for instructors to manage trainees, create training 
programs, analyze trainees’ results, and monitor their progress. For more 
information, refer to the MentorLearn Guide for Administrators. 
Training management system  
MentorLearn is a newly developed training management system, offering a 
comprehensive solution for managing training, simulation curricula and users for the 
Surgical Science line of simulators.  
The MentorLearn system was designed to offer web-based access and management, 
connecting all simulator stations, or it can be utilized as a standalone management 
system for one or more simulators. For more information, see MentorLearn on page 36. 


[TABLE]
| Chapter 2                                                                          | System Overview                                                                      |
|:-----------------------------------------------------------------------------------|:-------------------------------------------------------------------------------------|
| Chapter 2  System Overview                                                         |                                                                                      |
| The ENDO Mentor Suite® is a multidisciplinary platform that provides hands-on      |                                                                                      |
| practice of multiple BRONCH procedures as well as complete bronchoscopy            |                                                                                      |
| procedures and basic endoscopic and bronchoscopic skills for single trainees or an |                                                                                      |
| entire team.                                                                       |                                                                                      |
|                                                                                    | The system is aimed at enhancing operational and medical decision-making, improving  |
| skills such as hand-eye coordination, and expanding medical knowledge.             |                                                                                      |
| Growing library of modules                                                         |                                                                                      |
| The BRONCH Mentor® training system has been developed in collaboration with        |                                                                                      |
| medical experts from around the world. It incorporates a variety of practice       |                                                                                      |
|                                                                                    | opportunities and provides an extensive bronchoscopic training curriculum made up of |
| basic skills and simulation of full procedures.                                    |                                                                                      |
| Working modes                                                                      |                                                                                      |
| BRONCH Mentor has two main working modes:                                          |                                                                                      |

[TABLE]
| Working modes                             |                                                                                   |
|:------------------------------------------|:----------------------------------------------------------------------------------|
| BRONCH Mentor has two main working modes: |                                                                                   |
| •                                         | Training mode – is designed to provide trainees with an extensive and complete    |
|                                           | simulation environment of the bronchoscopy procedure.                             |
| •                                         | Management mode – is reserved for instructors to manage trainees, create training |
|                                           | programs, analyze trainees’ results, and monitor their progress. For more         |
|                                           | information, refer to the MentorLearn Guide for Administrators.                   |

[OCR_TABLE]
pvilay'

[OCR_TABLE]
The ENDO

[OCR]
Chapter 2 System Overview

| Chapter 2 System Overview

The ENDO Mentor Suite® is a multidisciplinary platform that provides hands-on
practice of multiple BRONCH procedures as well as complete bronchoscopy
procedures and basic endoscopic and bronchoscopic skills for single trainees or an
entire team.

The system is aimed at enhancing operational and medical decision-making, improving
skills such as hand-eye coordination, and expanding medical knowledge.

Growing library of modules

The BRONCH Mentor® training system has been developed in collaboration with
medical experts from around the world. It incorporates a variety of practice
opportunities and provides an extensive bronchoscopic training curriculum made up of
basic skills and simulation of full procedures.

Working modes

BRONCH Mentor has two main working modes:

e Training mode - is designed to provide trainees with an extensive and complete
simulation environment of the bronchoscopy procedure.

e Management mode - is reserved for instructors to manage trainees, create training
programs, analyze trainees’ results, and monitor their progress. For more
information, refer to the MentorLearn Guide for Administrators.

Training management system

MentorLearn is a newly developed training management system, offering a
comprehensive solution for managing training, simulation curricula and users for the
Surgical Science line of simulators.

The MentorLearn system was designed to offer web-based access and management,
connecting all simulator stations, or it can be utilized as a standalone management
system for one or more simulators. For more information, see MentorLearn on page 36.

surgicalscience Page 4


# Page 16

Chapter 3 
 ENDO Mentor Suite System
 
Page 5
 
Chapter 3 ENDO Mentor Suite System  
The ENDO Mentor Suite® is a multidisciplinary platform that provides hands-on 
practice of multiple GI procedures as well as complete bronchoscopy procedures and 
basic endoscopic and bronchoscopic skills for single trainees or an entire team.  
Hardware platform 
The platform consists of:  
• 
Wheeled hardware unit.  
• 
One or more scopes according to system configuration 
(Colonoscope/Duodenoscope/Bronchoscope/Rigid Scopes and Flexible Scope 
for Endourology).  
• 
Interchangeable cartridge for inserting scopes. 
• 
Set of tools according to system configuration.  
• 
Triple foot switch. 
• 
Wireless keyboard and mouse. 


[TABLE]
| Chapter 3                                                                        | ENDO Mentor Suite System                                                           |
|:---------------------------------------------------------------------------------|:-----------------------------------------------------------------------------------|
| Chapter 3  ENDO Mentor Suite System                                              |                                                                                    |
| The ENDO Mentor Suite® is a multidisciplinary platform that provides hands-on    |                                                                                    |
|                                                                                  | practice of multiple GI procedures as well as complete bronchoscopy procedures and |
| basic endoscopic and bronchoscopic skills for single trainees or an entire team. |                                                                                    |
| Hardware platform                                                                |                                                                                    |
| The platform consists of:                                                        |                                                                                    |

[TABLE]
| Hardware platform         |                                                                        |
|:--------------------------|:-----------------------------------------------------------------------|
| The platform consists of: |                                                                        |
| •                         | Wheeled hardware unit.                                                 |
| •                         | One or more scopes according to system configuration                   |
|                           | (Colonoscope/Duodenoscope/Bronchoscope/Rigid Scopes and Flexible Scope |
|                           | for Endourology).                                                      |
| •                         | Interchangeable cartridge for inserting scopes.                        |
| •                         | Set of tools according to system configuration.                        |
| •                         | Triple foot switch.                                                    |
| •                         | Wireless keyboard and mouse.                                           |

[OCR]
Chapter 3 ENDO Mentor Suite System

| Chapter 3 ENDO Mentor Suite System

The ENDO Mentor Suite® is a multidisciplinary platform that provides hands-on
practice of multiple Gl procedures as well as complete bronchoscopy procedures and
basic endoscopic and bronchoscopic skills for single trainees or an entire team.

Hardware platform

The platform consists of:

° Wheeled hardware unit.

e One or more scopes according to system configuration
(Colonoscope/Duodenoscope/Bronchoscope/Rigid Scopes and Flexible Scope
for Endourology).

Interchangeable cartridge for inserting scopes.

Set of tools according to system configuration.

Triple foot switch.

Wireless keyboard and mouse.

surgicalscience Page 5


# Page 17

Chapter 3 
 ENDO Mentor Suite System
 
Page 6
 
 
Figure 3-1: ENDO Mentor Suite - GI Mentor platform 
1 
27” touch screen 
2 
GI-BRONCH interchangeable cartridge (see Figure 3-2 on page 
7) 
3 
Wireless keyboard and mouse (not shown) 
4 
Scope hanger (see Figure 3-4 on page 9) 


[TABLE]
| F   | gure 3-1: ENDO Mentor Suite - GI Mentor platform   |                                                             |
| i   |                                                    |                                                             |
|:----|:---------------------------------------------------|:------------------------------------------------------------|
|     | 1                                                  | 27” touch screen                                            |
|     | 2                                                  | GI-BRONCH interchangeable cartridge (see Figure 3-2 on page |
|     |                                                    | 7)                                                          |
|     | 3                                                  | Wireless keyboard and mouse (not shown)                     |
|     | 4                                                  | Scope hanger (see Figure 3-4 on page 9)                     |

[OCR]
Chapter 3 ENDO Mentor Suite System

Figure 3-1: ENDO Mentor Suite - Gl Mentor platform

1 27” touch screen

2 GI-BRONCH interchangeable cartridge (see Figure 3-2 on page
2)

3 Wireless keyboard and mouse (not shown)

4 Scope hanger (see Figure 3-4 on page 9)

surgicalscience Page 6


# Page 18

Chapter 3 
 ENDO Mentor Suite System
 
Page 7
 
5 
Scope connectors (see Figure 3-5 on page 10) 
6 
Elevation mechanism (see Figure 3-7 on page 12) 
7 
Computer activation button 
8 
Rotating tool tray (see Figure 3-8 on page 13) 
9 
Upper drawer for Bronchoscope, 2 URO rigid scopes and wires 
(tools are stored in this drawer when shipped) 
10 
Lower drawer for Colonoscope, Duodenoscope, URO and GI-
BRONCH interchangeable cartridges 
11 
Foot switch (see Figure 3-10 on page 15) 
12 
Power switch, foot switch connector and USB outlet (on back 
panel) 
GI-BRONCH interchangeable cartridge  
 
Figure 3-2: GI-BRONCH interchangeable cartridge – lower orifice selected 


[TABLE]
| Chapter 3   |                                                             |
|:------------|:------------------------------------------------------------|
| 5           | Scope connectors (see Figure 3-5 on page 10)                |
| 6           | Elevation mechanism (see Figure 3-7 on page 12)             |
| 7           | Computer activation button                                  |
| 8           | Rotating tool tray (see Figure 3-8 on page 13)              |
| 9           | Upper drawer for Bronchoscope, 2 URO rigid scopes and wires |
|             | (tools are stored in this drawer when shipped)              |
| 10          | Lower drawer for Colonoscope, Duodenoscope, URO and GI-     |
|             | BRONCH interchangeable cartridges                           |
| 11          | Foot switch (see Figure 3-10 on page 15)                    |
| 12          | Power switch, foot switch connector and USB outlet (on back |
|             | panel)                                                      |

[OCR]
Chapter 3 ENDO Mentor Suite System

Scope connectors (see Figure 3-5 on page 10)
Elevation mechanism (see Figure 3-7 on page 12)
Computer activation button

Rotating tool tray (see Figure 3-8 on page 13)

Oo ON DOW

Upper drawer for Bronchoscope, 2 URO rigid scopes and wires
(tools are stored in this drawer when shipped)

10 Lower drawer for Colonoscope, Duodenoscope, URO and GI-
BRONCH interchangeable cartridges

11 Foot switch (see Figure 3-10 on page 15)

12 Power switch, foot switch connector and USB outlet (on back
panel)

GI-BRONCH interchangeable cartridge

Figure 3-2: GI-BRONCH interchangeable cartridge — lower orifice selected

surgicalscience Page 7


# Page 19

Chapter 3 
 ENDO Mentor Suite System
 
Page 8
 
Two symbols of the upper GI and lower GI tracts are displayed on the GI-BRONCH 
interchangeable cartridge indicating the relevant GI tract segment. Depending on the 
module selected, the LED will light up on the cartridge to designate the GI tract that 
will be used for procedure. 
URO interchangeable cartridge   
 
Figure 3-3: URO interchangeable cartridge 
To switch between the ENDO Mentor Suite interchangeable cartridges: 
1.  Insert your right hand in the groove on the bottom of the interchangeable cartridge 
and your left hand into the edge on the top of the cartridge and gently free the 
cartridge. You should hear a click. 
2.  Pull the cartridge horizontally out. Store it in its designated cavity in the lower 
drawer. 
3.  Insert the desired cartridge with one hand in the groove and the other on the top 
of the cartridge, push it horizontally into place. You should hear a click. 
 
Note: The cartridge must be properly positioned prior to introducing the scopes. 


[TABLE]
| Chapter 3                                                                              | ENDO Mentor Suite System                                                             |
|:---------------------------------------------------------------------------------------|:-------------------------------------------------------------------------------------|
| Two symbols of the upper GI and lower GI tracts are displayed on the GI-BRONCH         |                                                                                      |
|                                                                                        | interchangeable cartridge indicating the relevant GI tract segment. Depending on the |
| module selected, the LED will light up on the cartridge to designate the GI tract that |                                                                                      |
| will be used for procedure.                                                            |                                                                                      |
| URO interchangeable cartridge                                                          |                                                                                      |

[TABLE]
| F                                                                                        |                                                                                     |
| i                                                                                        |                                                                                     |
| gure 3-3: URO interchangeable cartridge                                                  |                                                                                     |
|:-----------------------------------------------------------------------------------------|:------------------------------------------------------------------------------------|
| To switch between the ENDO Mentor Suite interchangeable cartridges:                      |                                                                                     |
| 1.                                                                                       | Insert your right hand in the groove on the bottom of the interchangeable cartridge |
|                                                                                          | and your left hand into the edge on the top of the cartridge and gently free the    |
|                                                                                          | cartridge. You should hear a click.                                                 |
| 2.   Pull the cartridge horizontally out. Store it in its designated cavity in the lower |                                                                                     |
|                                                                                          | drawer.                                                                             |
| 3.                                                                                       | Insert the desired cartridge with one hand in the groove and the other on the top   |
|                                                                                          | of the cartridge, push it horizontally into place. You should hear a click.         |

[OCR]
Chapter 3 ENDO Mentor Suite System

Two symbols of the upper GI and lower Gl tracts are displayed on the GI-BRONCH
interchangeable cartridge indicating the relevant GI tract segment. Depending on the
module selected, the LED will light up on the cartridge to designate the Gl tract that
will be used for procedure.

URO interchangeable cartridge

Figure 3-3: URO interchangeable cartridge

To switch between the ENDO Mentor Suite interchangeable cartridges:

1. Insert your right hand in the groove on the bottom of the interchangeable cartridge
and your left hand into the edge on the top of the cartridge and gently free the
cartridge. You should hear a click.

2. Pull the cartridge horizontally out. Store it in its designated cavity in the lower
drawer.

3. Insert the desired cartridge with one hand in the groove and the other on the top
of the cartridge, push it horizontally into place. You should hear a click.

Note: The cartridge must be properly positioned prior to introducing the scopes.

surgicalscience Page 8


# Page 20

Chapter 3 
 ENDO Mentor Suite System
 
Page 9
 
Scope hanger 
 
Figure 3-4: Scope hanger  – Bronchoscope 
The scope hanger units are generic, the bronchoscope can fit in any hanger. 


[TABLE]
| Chapter 3                                                                   | ENDO Mentor Suite System   |
|:----------------------------------------------------------------------------|:---------------------------|
| Scope hanger                                                                |                            |
| F                                                                           |                            |
| i                                                                           |                            |
| gure 3-4: Scope hanger  – Bronchoscope                                      |                            |
| The scope hanger units are generic, the bronchoscope can fit in any hanger. |                            |
|                                                                             | Page 9                     |

[OCR]
Chapter 3 ENDO Mentor Suite System

Scope hanger

Figure 3-4: Scope hanger — Bronchoscope

The scope hanger units are generic, the bronchoscope can fit in any hanger.

surgicalscience Page 9


# Page 21

Chapter 3 
 ENDO Mentor Suite System
 
Page 10
 
Connecting the scope 
The GI scopes and BRONCH scope are connected to socket C at the front of the 
system.  
The rigid URO scopes are connected to sockets A and B; the BRONCH scope is used 
as a flexible URO scope and is connected to socket C. 
To connect the scope:  
1.  Fit the scope connector exactly in the prongs and recesses of the system 
connector.  
2.  Turn the external dial on the scope connector to the right until you hear a click. 
To disconnect the scope: 
1.  Turn the dial to the left and remove the scope connector. 
Note: Bumping against the scope connector while connected may result in damage to both the 
scope and the system. 
 
Figure 3-5: System and scope connectors 


[TABLE]
| Chapter 3                                                                               | ENDO Mentor Suite System                                                                    |
|:----------------------------------------------------------------------------------------|:--------------------------------------------------------------------------------------------|
| Connecting the scope                                                                    |                                                                                             |
| The GI scopes and BRONCH scope are connected to socket C at the front of the            |                                                                                             |
| system.                                                                                 |                                                                                             |
| The rigid URO scopes are connected to sockets A and B; the BRONCH scope is used         |                                                                                             |
| as a flexible URO scope and is connected to socket C.                                   |                                                                                             |
| To connect the scope:                                                                   |                                                                                             |
| 1.   Fit the scope connector exactly in the prongs and recesses of the system           |                                                                                             |
| connector.                                                                              |                                                                                             |
| 2.   Turn the external dial on the scope connector to the right until you hear a click. |                                                                                             |
| To disconnect the scope:                                                                |                                                                                             |
| 1.   Turn the dial to the left and remove the scope connector.                          |                                                                                             |
|                                                                                         | Note:  Bumping against the scope connector while connected may result in damage to both the |
| scope and the system.                                                                   |                                                                                             |

[OCR]
Chapter 3 ENDO Mentor Suite System

Connecting the scope

The GI scopes and BRONCH scope are connected to socket C at the front of the
system.

The rigid URO scopes are connected to sockets A and B; the BRONCH scope is used

as a flexible URO scope and is connected to socket C.

To connect the scope:

1. Fit the scope connector exactly in the prongs and recesses of the system
connector.

2. Turn the external dial on the scope connector to the right until you hear a click.

To disconnect the scope:

1. Turn the dial to the left and remove the scope connector.

Note: Bumping against the scope connector while connected may result in damage to both the
scope and the system.

Figure 3-5: System and scope connectors

surgicalscience Page 10


# Page 22

Chapter 3 
 ENDO Mentor Suite System
 
Page 11
 
Extensions 
The GI Mentor and URO Mentor modules require an extension for performing certain 
procedures. The GI modality extension is on the left side of the ENDO Mentor Suite 
and the URO modality extension is on the back of the simulator. 
Working positions 
The ENDO Mentor Suite supports different working positions: 
BRONCH Mentor: 
• 
Superior – the user is operating from behind the patient’s head. 
• 
Lateral – the user is operating laterally to the patient. 
 
 
Figure 3-6:  Lateral working position (left), Superior working position (right) 


[TABLE]
| Chapter 3                                                                          | ENDO Mentor Suite System   |
|:-----------------------------------------------------------------------------------|:---------------------------|
| Extensions                                                                         |                            |
| The GI Mentor and URO Mentor modules require an extension for performing certain   |                            |
| procedures. The GI modality extension is on the left side of the ENDO Mentor Suite |                            |
| and the URO modality extension is on the back of the simulator.                    |                            |
| Working positions                                                                  |                            |
| The ENDO Mentor Suite supports different working positions:                        |                            |
| BRONCH Mentor:                                                                     |                            |

[OCR]
Chapter 3 ENDO Mentor Suite System

Extensions

The GI Mentor and URO Mentor modules require an extension for performing certain
procedures. The GI modality extension is on the left side of the ENDO Mentor Suite

and the URO modality extension is on the back of the simulator.

Working positions

The ENDO Mentor Suite supports different working positions:
BRONCH Mentor:

. Superior — the user is operating from behind the patient’s head.
. Lateral - the user is operating laterally to the patient.

sn

Figure 3-6: Lateral working position (left), Superior working position (right)

surgicalscience

Page 11


# Page 23

Chapter 3 
 ENDO Mentor Suite System
 
Page 12
 
GI Mentor: 
The user is operating in front of the simulator, facing the GI-BRONCH interchangeable 
cartridge. 
URO Mentor: 
The user is operating in front of the simulator, facing the URO interchangeable 
cartridge. 
The screen and the tool tray are adjustable to conveniently support each working 
position. 
Height elevation mechanism  
The height of the ENDO Mentor Suite platform can be adjusted.  
 
Figure 3-7: Height elevation panel – (from left to right) USB port, Height Elevation mechanism, 
Computer On/Off button 
Use the Up and Down arrows on the Height Elevation panel to find the desired height.  
Note: The USB port can be used for example for connecting an external hard drive. 
Turning on the simulator 
1.  Make sure the On/Off Power switch on the back of the simulator is turned on. 
2.  Use the button to the right of the Height Elevation mechanism to turn on the ENDO 
Mentor Suite computer. 
 


[TABLE]
| Chapter 3                                                                        | ENDO Mentor Suite System                                                              |
|:---------------------------------------------------------------------------------|:--------------------------------------------------------------------------------------|
| GI Mentor:                                                                       |                                                                                       |
|                                                                                  | The user is operating in front of the simulator, facing the GI-BRONCH interchangeable |
| cartridge.                                                                       |                                                                                       |
| URO Mentor:                                                                      |                                                                                       |
| The user is operating in front of the simulator, facing the URO interchangeable  |                                                                                       |
| cartridge.                                                                       |                                                                                       |
| The screen and the tool tray are adjustable to conveniently support each working |                                                                                       |
| position.                                                                        |                                                                                       |
| Height elevation mechanism                                                       |                                                                                       |
| The height of the ENDO Mentor Suite platform can be adjusted.                    |                                                                                       |

[OCR]
Chapter 3 ENDO Mentor Suite System

GI Mentor:

The user is operating in front of the simulator, facing the GI-BRONCH interchangeable
cartridge.

URO Mentor:

The user is operating in front of the simulator, facing the URO interchangeable
cartridge.

The screen and the tool tray are adjustable to conveniently support each working
position.

Height elevation mechanism

The height of the ENDO Mentor Suite platform can be adjusted.

Figure 3-7: Height elevation panel — (from left to right) USB port, Height Elevation mechanism,
Computer On/Off button

Use the Up and Down arrows on the Height Elevation panel to find the desired height.

Note: The USB port can be used for example for connecting an external hard drive.

Turning on the simulator

1. Make sure the On/Off Power switch on the back of the simulator is turned on.
2. Use the button to the right of the Height Elevation mechanism to turn on the ENDO
Mentor Suite computer.

surgicalscience Page 12


# Page 24

Chapter 3 
 ENDO Mentor Suite System
 
Page 13
 
Tool tray 
The rotating tool tray holds all the tools for the ENDO Mentor Suite system: 
• 
Master Tool – all platforms 
• 
URO forceps – URO Mentor 
• 
Syringe – BRONCH Mentor 
• 
EBUS needle – BRONCH Mentor 
• 
Red and blue wires – GI Mentor 
Note: When not being used or upon moving the system, the tool tray must be stored in its 
original position to avoid damage. 
 
 
Figure 3-8: Tool tray hanger with BRONCH tools  


[TABLE]
| Tool tray                                                                                 |                                    |
|:------------------------------------------------------------------------------------------|:-----------------------------------|
| The rotating tool tray holds all the tools for the ENDO Mentor Suite system:              |                                    |
| •                                                                                         | Master Tool – all platforms        |
| •                                                                                         | URO forceps – URO Mentor           |
| •                                                                                         | Syringe – BRONCH Mentor            |
| •                                                                                         | EBUS needle – BRONCH Mentor        |
| •                                                                                         | Red and blue wires – GI Mentor     |
| Note:  When not being used or upon moving the system, the tool tray must be stored in its |                                    |
|                                                                                           | original position to avoid damage. |

[OCR]
Chapter 3 ENDO Mentor Suite System

Tool tray

The rotating tool tray holds all the tools for the ENDO Mentor Suite system:

Master Tool - all platforms

URO forceps — URO Mentor
Syringe - BRONCH Mentor
EBUS needle - BRONCH Mentor
Red and blue wires — GI Mentor

Note: When not being used or upon moving the system, the tool tray must be stored in its
original position to avoid damage.

Figure 3-8: Tool tray hanger with BRONCH tools

surgicalscience Page 13


# Page 25

Chapter 3 
 ENDO Mentor Suite System
 
Page 14
 
The tool connectors are on the side of the platform under the tool tray. Use the labeled 
outlets to connect the tool cables as shown below. 
 
Figure 3-9: Tool connection outlets 
1 
MT (Master tool) 
2 
UR (URO forceps) 
3 
SR (Syringe) 
4 
EB (EBUS needle) 


[TABLE]
| Chapter 3   |                                                                                          | ENDO Mentor Suite System   |
|:------------|:-----------------------------------------------------------------------------------------|:---------------------------|
|             | The tool connectors are on the side of the platform under the tool tray. Use the labeled |                            |
|             | outlets to connect the tool cables as shown below.                                       |                            |
| F           | gure 3-9: Tool connection outlets                                                        |                            |
| i           |                                                                                          |                            |
| 1           | MT (Master tool)                                                                         |                            |
| 2           | UR (URO forceps)                                                                         |                            |
| 3           | SR (Syringe)                                                                             |                            |
| 4           | EB (EBUS needle)                                                                         |                            |
|             |                                                                                          | Page 14                    |

[OCR]
Chapter 3 ENDO Mentor Suite System

The tool connectors are on the side of the platform under the tool tray. Use the labeled
outlets to connect the tool cables as shown below.

Figure 3-9: Tool connection outlets

1 MT (Master tool)

2 UR (URO forceps)
3 SR (Syringe)

4 EB (EBUS needle)

surgicalscience Page 14


# Page 26

Chapter 3 
 ENDO Mentor Suite System
 
Page 15
 
Foot switch 
A triple foot switch is provided with the system. Utilization can change per simulation 
module/case.  
Common uses of the foot switch: 
• 
Browsing and selecting from list menus 
• 
Activating the tool’s Virtual Activation option and the selecting tool’s state 
• 
Confirming user actions  
• 
Activating additional modalities such as applying electricity  
 
Figure 3-10: Foot switch 
 
Available endoscope 
 
Make sure the scope is not protruding before closing of the drawer. 
Failing to do so may result in irreparable damage to the scope. 
Bronchoscope 
The bronchoscope, used with the BRONCH Mentor, is an actual bronchoscope 
modified for simulation purposes.  


[TABLE]
| Chapter 3                                                                               |
|  ENDO Mentor Suite System                                                               |
|:----------------------------------------------------------------------------------------|
| Foot switch                                                                             |
| A triple foot switch is provided with the system. Utilization can change per simulation |
| module/case.                                                                            |
| Common uses of the foot switch:                                                         |
| Browsing and selecting from list menus                                                  |
| •                                                                                       |
| Activating the tool’s Virtual Activation option and the selecting tool’s state          |
| •                                                                                       |
| Confirming user actions                                                                 |
| •                                                                                       |
| Activating additional modalities such as applying electricity                           |
| •                                                                                       |
| F                                                                                       |
| i                                                                                       |
| gure 3-10: Foot switch                                                                  |
| A                                                                                       |
| vailable endoscope                                                                      |
| Make sure the scope is not protruding before closing of the drawer.                     |
| Failing to do so may result in irreparable damage to the scope.                         |
| Bronchoscope                                                                            |
| The bronchoscope, used with the BRONCH Mentor, is an actual bronchoscope                |
| modified for simulation purposes.                                                       |
| Page 15                                                                                 |

[OCR_TABLE]
Chapter 3

[OCR]
Chapter 3 ENDO Mentor Suite System

Foot switch

A triple foot switch is provided with the system. Utilization can change per simulation

module/case.
Common uses of the foot switch:

Browsing and selecting from list menus

Activating the tool’s Virtual Activation option and the selecting tool's state
Confirming user actions

Activating additional modalities such as applying electricity

Figure 3-10: Foot switch

Available endoscope

@ Make sure the scope is not protruding before closing of the drawer.

Failing to do so may result in irreparable damage to the scope.

Bronchoscope

The bronchoscope, used with the BRONCH Mentor, is an actual bronchoscope
modified for simulation purposes.

surgicalscience

Page 15


# Page 27

Chapter 3 
 ENDO Mentor Suite System
 
Page 16
 
 
 
 
1 – Working Channel  
2 – Up-Down 
(Flex/Extend) Lever 
3 – V Button  
4 – C Button 
5 – Freeze Button 
6 – Suction Button  
7 – Insertion Tube 
 
Figure 3-11: Bronchoscope 
Auxiliary tools and connectors 
BRONCH Mentor tools 
The BRONCH Mentor has three basic tools: Master Tool, syringe and EBUS needle. 


[TABLE]
| 1                    |
|  – Working Channel   |
|:---------------------|
| 2 – Up-Down          |
| (Flex/Extend) Lever  |
| 3 – V Button         |
| 4 – C Button         |
| 5 – Freeze Button    |
| 6 – Suction Button   |
| 7 – Insertion Tube   |

[OCR]
Chapter 3 ENDO Mentor Suite System

1 - Working Channel

4
2 - Up-Down
5 (Flex/Extend) Lever
6 3-V Button
4-C Button

5 — Freeze Button
6 - Suction Button

7 - Insertion Tube

Figure 3-11: Bronchoscope

Auxiliary tools and connectors

BRONCH Mentor tools

The BRONCH Mentor has three basic tools: Master Tool, syringe and EBUS needle.

surgicalscience Page 16


# Page 28

Chapter 3 
 ENDO Mentor Suite System
 
Page 17
 
Master Tool 
 
Figure 3-12: Master Tool 
To select a virtual tool using the Master Tool: 
1.  Insert the Master Tool slowly into the working channel until the Tools menu 
appears.  
The Tools menu opens with pictures of all available tools.  
To work with Master Tool handle: 
• 
Pull the Master Tool handle back to open, inflate, or fill the tool. 
• 
Push the Master Tool handle forward to close, deflate, or inject using the tool.  
Syringe 
 
Figure 3-13: Syringe 
The syringe can be utilized for several purposes:  


[TABLE]
| Chapter 3                                                                          |
|  ENDO Mentor Suite System                                                          |
|:-----------------------------------------------------------------------------------|
| Master Tool                                                                        |
| F                                                                                  |
| i                                                                                  |
| gure 3-12: Master Tool                                                             |
| To select a virtual tool using the Master Tool:                                    |
| 1.                                                                                 |
| Insert the Master Tool slowly into the working channel until the Tools menu        |
| appears.                                                                           |
| The Tools menu opens with pictures of all available tools.                         |
| To work with Master Tool handle:                                                   |
| Pull the Master Tool handle back to open, inflate, or fill the tool.               |
| •                                                                                  |
| Push the Master Tool handle forward to close, deflate, or inject using the tool.   |
| •                                                                                  |
| Syringe                                                                            |
| F                                                                                  |
| i                                                                                  |
| gure 3-13: Syringe                                                                 |
| The syringe can be utilized for several purposes:                                  |
| Page 17                                                                            |

[OCR]
Chapter 3 ENDO Mentor Suite System

Master Tool

Figure 3-12: Master Tool

To select a virtual tool using the Master Tool:

1. Insert the Master Tool slowly into the working channel until the Tools menu
appears.

The Tools menu opens with pictures of all available tools.

To work with Master Tool handle:

e Pull the Master Tool handle back to open, inflate, or fill the tool.
. Push the Master Tool handle forward to close, deflate, or inject using the tool.
Syringe

Figure 3-13: Syringe

The syringe can be utilized for several purposes:

surgicalscience Page 17


# Page 29

Chapter 3 
 ENDO Mentor Suite System
 
Page 18
 
• 
Administering saline and other fluids. 
• 
Retrieving saline. 
• 
Applying and releasing vacuum for needle aspirations. 
To work with Syringe: 
• 
Pull the syringe piston back to fill, apply vacuum for needle aspiration, or retrieve 
saline during BAL. 
• 
Push the syringe piston forward to inject or release vacuum for needle aspiration. 
Note:  To administer a second dosage, remove the syringe from the working channel, retract the 
piston so the syringe is ‘filled’, and reinsert it into the scope’s working channel. 


[TABLE]
| Chapter 3                                                                              |
|  ENDO Mentor Suite System                                                              |
|:---------------------------------------------------------------------------------------|
| Administering saline and other fluids.                                                 |
| •                                                                                      |
| Retrieving saline.                                                                     |
| •                                                                                      |
| Applying and releasing vacuum for needle aspirations.                                  |
| •                                                                                      |
| To work with Syringe:                                                                  |
| Pull the syringe piston back to fill, apply vacuum for needle aspiration, or retrieve  |
| •                                                                                      |
| saline during BAL.                                                                     |
| Push the syringe piston forward to inject or release vacuum for needle aspiration.     |
| •                                                                                      |

[OCR_TABLE]
> ee

[OCR]
Chapter 3 ENDO Mentor Suite System

e Administering saline and other fluids.
e Retrieving saline.
e Applying and releasing vacuum for needle aspirations.

To work with Syringe:

e Pull the syringe piston back to fill, apply vacuum for needle aspiration, or retrieve
saline during BAL.
e Push the syringe piston forward to inject or release vacuum for needle aspiration.

Note: To administer a second dosage, remove the syringe from the working channel, retract the
piston so the syringe is ‘filled’, and reinsert it into the scope’s working channel.

surgicalscience Page 18


# Page 30

Chapter 3 
 ENDO Mentor Suite System
 
Page 19
 
EBUS needle 
The EBUS Needle is a real EBUS needle modified to fit the simulation needs. All original 
functionality is maintained, except for the stylet which is virtual. 
1 – Cable connects to the fourth socket of the 
tool tray (furthest from system). 
 
2 – Needle controls account for needle 
motion out and in of the sheath. The secure 
lock slider provides extra safety in securing 
the needle, optional length adjustment and 
motion stopper. 
The gray mechanical stopper sets the 
maximum needle length and cannot be 
removed. 
Note: The needle click-locked state is at the 
upper most position of the needle handle. 
When in this position, the needle is 
completely inside the sheath. 
A mechanical click divides this position from 
the rest of the sheath. 
3 – Sheath controls are used to set the 
measurement of sheath protrusion out of the 
working channel and fix it. 
4 – Fixation to working channel by inserting 
and fixating the EBUS Needle to the scope’s 
working channel using the slide lock. 
Note: The slide lock must be released when 
inserting the needle and then fit and locked 
to the adapter. 
a – The adapter should be thrust over the 
scope’s working channel extension prior to 
starting an EBUS case. 


[TABLE]
| EBUS needle                                                                              |
|:-----------------------------------------------------------------------------------------|
| The EBUS Needle is a real EBUS needle modified to fit the simulation needs. All original |
| functionality is maintained, except for the stylet which is virtual.                     |
| 1 – Cable connects to the fourth socket of the                                           |
| tool tray (furthest from system).                                                        |
| 2 – Needle controls account for needle                                                   |
| motion out and in of the sheath. The secure                                              |
| lock slider provides extra safety in securing                                            |
| the needle, optional length adjustment and                                               |
| motion stopper.                                                                          |
| The gray mechanical stopper sets the                                                     |
| maximum needle length and cannot be                                                      |
| removed.                                                                                 |
| Note: The needle click-locked state is at the                                            |
| upper most position of the needle handle.                                                |
| When in this position, the needle is                                                     |
| completely inside the sheath.                                                            |
| A mechanical click divides this position from                                            |
| the rest of the sheath.                                                                  |
| 3 – Sheath controls are used to set the                                                  |
| measurement of sheath protrusion out of the                                              |
| working channel and fix it.                                                              |
| 4 – Fixation to working channel by inserting                                             |
| and fixating the EBUS Needle to the scope’s                                              |
| working channel using the slide lock.                                                    |
| Note: The slide lock must be released when                                               |
| inserting the needle and then fit and locked                                             |
| to the adapter.                                                                          |
| a – The adapter should be thrust over the                                                |
| scope’s working channel extension prior to                                               |
| starting an EBUS case.                                                                   |

[OCR_TABLE]
gn

[OCR]
Chapter 3 ENDO Mentor Suite System

EBUS needle

The EBUS Needle is a real EBUS needle modified to fit the simulation needs. All original
functionality is maintained, except for the stylet which is virtual.

1- Cable connects to the fourth socket of the
tool tray (furthest from system). @

2 —-Needle controls account for needle
motion out and in of the sheath. The secure 4
lock slider provides extra safety in securing

the needle, optional length adjustment and

motion stopper.

The gray mechanical stopper sets the
maximum needle length and cannot be @
removed.

Note: The needle click-locked state is at the ~?P
upper most position of the needle handle. ‘1
When in this position, the needle is

completely inside the sheath.

A mechanical click divides this position from
the rest of the sheath.

|
3 - Sheath controls are used to set the ©) :
measurement of sheath protrusion out of the
working channel and fix it. |

4 - Fixation to working channel by inserting
and fixating the EBUS Needle to the scope’s
working channel using the slide lock.

Note: The slide lock must be released when }
inserting the needle and then fit and locked @ if a

to the adapter.

a- The adapter should be thrust over the
scope’s working channel extension prior to
starting an EBUS case.

surgicalscience Page 19


# Page 31

Chapter 4 
 BRONCH Express Platform
 
Page 20
 
Chapter 4 BRONCH Express Platform 
The BRONCH Express® is a portable desktop simulator that was jointly developed by 
CHEST (ACCP – The American College of CHEST Physician) and Surgical Science.  
This innovative simulation platform is permanently mounted within a carry-on case 
with a detachable top. A designated laptop is an integral part of the system. 
 
Figure 4-1: The BRONCH Express carry-on case 
Note: The laptop is packed separately in a designated laptop case that can be mounted on the 
carry-on handle.  
 


[TABLE]
| Chapter 4                                                                         | BRONCH Express Platform   |
|:----------------------------------------------------------------------------------|:--------------------------|
| Chapter 4  BRONCH Express Platform                                                |                           |
| The BRONCH Express® is a portable desktop simulator that was jointly developed by |                           |
| CHEST (ACCP – The American College of CHEST Physician) and Surgical Science.      |                           |
| This innovative simulation platform is permanently mounted within a carry-on case |                           |
| with a detachable top. A designated laptop is an integral part of the system.     |                           |

[OCR]
Chapter 4 BRONCH Express Platform

| Chapter 4 BRONCH Express Platform

The BRONCH Express® is a portable desktop simulator that was jointly developed by
CHEST (ACCP - The American College of CHEST Physician) and Surgical Science.

This innovative simulation platform is permanently mounted within a carry-on case
with a detachable top. A designated laptop is an integral part of the system.

BRONCH Express

CHEST

Simbionix

Figure 4-1: The BRONCH Express carry-on case

Note: The laptop is packed separately in a designated laptop case that can be mounted on the
carry-on handle.

surgicalscience Page 20


# Page 32

Chapter 4 
 BRONCH Express Platform
 
Page 21
 
 
Figure 4-2: BRONCH Express platform 
①  Laptop  
➁  Simulation  body unit 
③  Emulated bronchoscope 
④  Insertion point 
⑤  Detachable cover 


[TABLE]
| Chapter 4                         | BRONCH Express Platform   |
|:----------------------------------|:--------------------------|
| F                                 |                           |
| i                                 |                           |
| gure 4-2: BRONCH Express platform |                           |
| ①                                 |                           |
|  Laptop                           |                           |
| ➁                                 |                           |
|  Simulation  body unit            |                           |
| ③                                 |                           |
|  Emulated bronchoscope            |                           |
| ④                                 |                           |
|  Insertion point                  |                           |
| ⑤  Detachable cover               |                           |
|                                   | Page 21                   |

[OCR]
Chapter 4 BRONCH Express Platform

Figure 4-2: BRONCH Express platform

@ Laptop

@ Simulation body unit
@ Emulated bronchoscope
@® Insertion point

© Detachable cover

surgicalscience Page 21


# Page 33

Chapter 4 
 BRONCH Express Platform
 
Page 22
 
Simulation unit 
 
 
Figure 4-3: Simulation unit components 
1 
Detachable Cover  
2 
Cover Detachment Rods 
3 
Storage Compartment 
4 
Tool and Laptop Connectors 
5  
Scope Connector 
6 
Insertion Point 


[TABLE]
|   gure 4-3: Simulation unit components |                            |
|---------------------------------------:|:---------------------------|
|                                      1 | Detachable Cover           |
|                                      2 | Cover Detachment Rods      |
|                                      3 | Storage Compartment        |
|                                      4 | Tool and Laptop Connectors |
|                                      5 | Scope Connector            |
|                                      6 | Insertion Point            |

[OCR]
Chapter 4

BRONCH Express Platform

Simulation unit

BRONCH Express

Figure 4-3: Simulation unit components

oun Pp WN A

Detachable Cover

Cover Detachment Rods
Storage Compartment

Tool and Laptop Connectors
Scope Connector

Insertion Point

surgicalscience

Page 22


# Page 34

Chapter 4 
 BRONCH Express Platform
 
Page 23
 
Bronchoscope 
The bronchoscope, used with the BRONCH Express, is an emulated bronchoscope, 
offering realistic look and feel and complete functionality. 
 
1 – Working Channel  
2 – Up-Down 
(Flex/Extend) Lever 
3 – Back Button  
4 – Front Button 
5 – Insertion Tube 
 
Figure 4-4: BRONCH Express bronchoscope 


[TABLE]
| 1 – Working Channel   |
|:----------------------|
| 2 – Up-Down           |
| (Flex/Extend) Lever   |
| 3 – Back Button       |
| 4 – Front Button      |
| 5 – Insertion Tube    |

[OCR]
Chapter 4 BRONCH Express Platform

Bronchoscope
The bronchoscope, used with the BRONCH Express, is an emulated bronchoscope,
offering realistic look and feel and complete functionality.

1- Working Channel

2 - Up-Down
(Flex/Extend) Lever

3 - Back Button
4 - Front Button

5 - Insertion Tube

Figure 4-4: BRONCH Express bronchoscope

surgicalscience Page 23


# Page 35

Chapter 4 
 BRONCH Express Platform
 
Page 24
 
Auxiliary tools 
The same auxiliary tools are used with the BRONCH Express as with the BRONCH 
Mentor: 
• 
Master tool – for a detailed explanation, see page 17. 
• 
EBUS needle – for a detailed explanation, see page 19. 
Setup  
The following tools and cables are provided with the BRONCH Express platform: 
• 
Emulated bronchoscope 
• 
EBUS needle, provided with the Essential EBUS module 
• 
Master tool, provided with the Diagnostic Bronchoscopy module 
• 
USB cable 
• 
Laptop power cable 
• 
Laptop case 
To set up: 
1.  Open the BRONCH Express carry-on case. 
 
2.  Remove the bronchoscope, EBUS needle and all other tools and cables from the 
storage compartment. 


[TABLE]
| Chapter 4                                                                         |
|  BRONCH Express Platform                                                          |
|:----------------------------------------------------------------------------------|
| Auxiliary tools                                                                   |
| The same auxiliary tools are used with the BRONCH Express as with the BRONCH      |
| Mentor:                                                                           |
| Master tool – for a detailed explanation, see page 17.                            |
| •                                                                                 |
| EBUS needle – for a detailed explanation, see page 19.                            |
| •                                                                                 |
| Setup                                                                             |
| The following tools and cables are provided with the BRONCH Express platform:     |
| Emulated bronchoscope                                                             |
| •                                                                                 |
| EBUS needle, provided with the Essential EBUS module                              |
| •                                                                                 |
| Master tool, provided with the Diagnostic Bronchoscopy module                     |
| •                                                                                 |
| USB cable                                                                         |
| •                                                                                 |
| Laptop power cable                                                                |
| •                                                                                 |
| Laptop case                                                                       |
| •                                                                                 |
| To set up:                                                                        |
| 1.   Open the BRONCH Express carry-on case.                                       |
| 2.   Remove the bronchoscope, EBUS needle and all other tools and cables from the |
| storage compartment.                                                              |
| Page 24                                                                           |

[OCR]
Chapter 4 BRONCH Express Platform

Auxiliary tools

The same auxiliary tools are used with the BRONCH Express as with the BRONCH
Mentor:

e Master tool — for a detailed explanation, see page 17.
e EBUS needle - for a detailed explanation, see page 19.

Setup
The following tools and cables are provided with the BRONCH Express platform:

Emulated bronchoscope
EBUS needle, provided with the Essential EBUS module

Master tool, provided with the Diagnostic Bronchoscopy module
USB cable

Laptop power cable

Laptop case

To set up:
1. Open the BRONCH Express carry-on case.

P
a4
ie
2
x
ai
ae
gy
z
fe}
4
a

2. Remove the bronchoscope, EBUS needle and all other tools and cables from the
storage compartment.

surgicalscience Page 24


# Page 36

Chapter 4 
 BRONCH Express Platform
 
Page 25
 
Note:  When repacking the simulator, the bronchoscope’s insertion tube should be inserted into 
its storage trail (below) in order to maintain this part intact. 
 
Figure 4-5: Bronchoscope’s insertion tube storage trail 


[TABLE]
| Chapter 4                                                        | BRONCH Express Platform                                                                        |
|:-----------------------------------------------------------------|:-----------------------------------------------------------------------------------------------|
|                                                                  | Note:  When repacking the simulator, the bronchoscope’s insertion tube should be inserted into |
| its storage trail (below) in order to maintain this part intact. |                                                                                                |
| F                                                                |                                                                                                |
| i                                                                |                                                                                                |
| gure 4-5: Bronchoscope’s insertion tube storage trail            |                                                                                                |
|                                                                  | Page 25                                                                                        |

[OCR]
Chapter 4 BRONCH Express Platform

Note: When repacking the simulator, the bronchoscope’s insertion tube should be inserted into
its storage trail (below) in order to maintain this part intact.

Figure 4-5: Bronchoscope’s insertion tube storage trail

surgicalscience Page 25


# Page 37

Chapter 4 
 BRONCH Express Platform
 
Page 26
 
 
3.  Detach the top by pulling out the metal rods on both side trails. To remove a rod, 
pull up its edge and slide it out in a wriggle movement. 
 
Figure 4-6: Removing the rods to detach the cover 
Note:  Put the rods back into their housing after detaching the cover. 
4.  Position the simulation unit on a flat, stable table at a convenient working height. 


[TABLE]
| Chapter 4                                                                                 | BRONCH Express Platform   |
|:------------------------------------------------------------------------------------------|:--------------------------|
| 3.   Detach the top by pulling out the metal rods on both side trails. To remove a rod,   |                           |
| pull up its edge and slide it out in a wriggle movement.                                  |                           |
| F                                                                                         |                           |
| i                                                                                         |                           |
| gure 4-6: Removing the rods to detach the cover                                           |                           |
| Note:  Put the rods back into their housing after detaching the cover.                    |                           |
| 4.   Position the simulation unit on a flat, stable table at a convenient working height. |                           |
|                                                                                           | Page 26                   |

[OCR]
Chapter 4 BRONCH Express Platform

3. Detach the top by pulling out the metal rods on both side trails. To remove a rod,
pull up its edge and slide it out in a wriggle movement.

Figure 4-6: Removing the rods to detach the cover

Note: Put the rods back into their housing after detaching the cover.

4. Position the simulation unit on a flat, stable table at a convenient working height.

surgical Page 26


# Page 38

Chapter 4 
 BRONCH Express Platform
 
Page 27
 
 
5.  Place the opened laptop, in a stable manner, on the distal side of the simulation 
unit. 


[TABLE]
| Chapter 4                                                                              | BRONCH Express Platform   |
|:---------------------------------------------------------------------------------------|:--------------------------|
| 5.   Place the opened laptop, in a stable manner, on the distal side of the simulation |                           |
| unit.                                                                                  |                           |
|                                                                                        | Page 27                   |

[OCR]
Chapter 4 BRONCH Express Platform

5. Place the opened laptop, in a stable manner, on the distal side of the simulation
unit.

surgicalscience Page 27


# Page 39

Chapter 4 
 BRONCH Express Platform
 
Page 28
 
 
6.  Connect the USB cable to its simulation unit connector below (labeled Laptop) and 
to the laptop USB connector (1 on Figure 4-9). 
 
Figure 4-7: Simulation unit connectors 


[TABLE]
| Chapter 4                                      | BRONCH Express Platform                                                                |
|:-----------------------------------------------|:---------------------------------------------------------------------------------------|
|                                                | 6.   Connect the USB cable to its simulation unit connector below (labeled Laptop) and |
| to the laptop USB connector (1 on Figure 4-9). |                                                                                        |
| F                                              |                                                                                        |
| i                                              |                                                                                        |
| gure 4-7: Simulation unit connectors           |                                                                                        |
|                                                | Page 28                                                                                |

[OCR]
Chapter 4 BRONCH Express Platform

6. Connect the USB cable to its simulation unit connector below (labeled Laptop) and
to the laptop USB connector (1 on Figure 4-9).

Figure 4-7: Simulation unit connectors

surgicalscience Page 28


# Page 40

Chapter 4 
 BRONCH Express Platform
 
Page 29
 
7.  Connect the EBUS needle/Master tool to its connector (labeled Tool), matching the 
red mark on the tool side to the red mark on the simulation unit connector and 
gently pushing in. 
 
8.  Connect the bronchoscope cable to its connector (labeled Scope), adjusting the 
red mark on the scope side to the red mark on the simulation unit connector and 
gently pushing in. 
 
Figure 4-8: Bronchoscope connected to simulation unit 
9.  Connect the power supply cable to the laptop (2 on Figure 4-9) and to the power 
socket on the wall.  


[TABLE]
| Chapter 4                                                                           | BRONCH Express Platform                                                                |
|:------------------------------------------------------------------------------------|:---------------------------------------------------------------------------------------|
|                                                                                     | 7.   Connect the EBUS needle/Master tool to its connector (labeled Tool), matching the |
|                                                                                     | red mark on the tool side to the red mark on the simulation unit connector and         |
| gently pushing in.                                                                  |                                                                                        |
| 8.   Connect the bronchoscope cable to its connector (labeled Scope), adjusting the |                                                                                        |
|                                                                                     | red mark on the scope side to the red mark on the simulation unit connector and        |
| gently pushing in.                                                                  |                                                                                        |
| F                                                                                   |                                                                                        |
| i                                                                                   |                                                                                        |
| gure 4-8: Bronchoscope connected to simulation unit                                 |                                                                                        |
|                                                                                     | 9.   Connect the power supply cable to the laptop (2 on Figure 4-9) and to the power   |
| socket on the wall.                                                                 |                                                                                        |
|                                                                                     | Page 29                                                                                |

[OCR]
Chapter 4 BRONCH Express Platform

7. Connect the EBUS needle/Master tool to its connector (labeled Tool), matching the
red mark on the tool side to the red mark on the simulation unit connector and
gently pushing in.

8. Connect the bronchoscope cable to its connector (labeled Scope), adjusting the
red mark on the scope side to the red mark on the simulation unit connector and
gently pushing in.

Figure 4-8: Bronchoscope connected to simulation unit

9. Connect the power supply cable to the laptop (2 on Figure 4-9) and to the power
socket on the wall.

surgicalscience Page 29


# Page 41

Chapter 4 
 BRONCH Express Platform
 
Page 30
 
 
Figure 4-9: Laptop connectors 
Note: The power supply cable should always be connected to the wall socket. It is 
not recommended to work with the laptop using its battery. 
To start training: 
1.  Turn on the laptop by pressing the power button (3 on Figure 4-9). 
2.  Release the EBUS adapter from the EBUS needle and thrust it over the scope’s 
working channel, if practicing the Essential EBUS module. 
3.  Log in to MentorLearn and start one of the cases. 
4.  Introduce the scope through the mouth orifice at a 12:00 o’clock orientation (make 
sure that the handle is straight forward and your thumb on the lever faces your 
chest). 
Note: Scope introduction must always be performed at a 12:00 o’clock orientation 
(or 6:00 o’clock if working from the lateral position). 


[TABLE]
|                                                                                   | Note: The power supply cable should always be connected to the wall socket. It is   |
|:----------------------------------------------------------------------------------|:------------------------------------------------------------------------------------|
|                                                                                   | not recommended to work with the laptop using its battery.                          |
| To start training:                                                                |                                                                                     |
| 1.   Turn on the laptop by pressing the power button (3 on Figure 4-9).           |                                                                                     |
| 2.   Release the EBUS adapter from the EBUS needle and thrust it over the scope’s |                                                                                     |
|                                                                                   | working channel, if practicing the Essential EBUS module.                           |
| 3.   Log in to MentorLearn and start one of the cases.                            |                                                                                     |
| 4.                                                                                | Introduce the scope through the mouth orifice at a 12:00 o’clock orientation (make  |
|                                                                                   | sure that the handle is straight forward and your thumb on the lever faces your     |

[OCR]
Chapter 4 BRONCH Express Platform

Figure 4-9: Laptop connectors

Note: The power supply cable should always be connected to the wall socket. It is
not recommended to work with the laptop using its battery.

To start training:

1. Turn on the laptop by pressing the power button (3 on Figure 4-9).

2. Release the EBUS adapter from the EBUS needle and thrust it over the scope’s
working channel, if practicing the Essential EBUS module.

Log in to MentorLearn and start one of the cases.

Introduce the scope through the mouth orifice at a 12:00 o’clock orientation (make
sure that the handle is straight forward and your thumb on the lever faces your
chest).

PY

Note: Scope introduction must always be performed at a 12:00 o'clock orientation
(or 6:00 o'clock if working from the lateral position).

surgicalscience Page 30


# Page 42

Chapter 4 
 BRONCH Express Platform
 
Page 31
 
BRONCH Express basic display mode 
The BRONCH Express offers a basic display mode for the clinical cases, with slight 
variations for designated tasks. 
The basic display mode consists of the following components: 
 
Figure 4-10: BRONCH Express basic display mode 
①  Title bar with Task/Case identifier 
②  Main View – displays WLB (video) or EBUS (Ultrasound), depending on the  
selected module.  
③  Complementary Display I  – changes according to selected module. In the Essential 
EBUS module, the WLB (video) View is displayed. 
④  Complementary Display II – educational aids or other supplement data are 
available, according to selected module. 
⑤  Main View controls will change according to the selected module. In the EBUS 
module, the following controls are available:  
• 
Labels – for a detailed explanation, see page 68. 
• 
Doppler – for a detailed explanation, see page 69. 
• 
Balloon – for a detailed explanation, see page 67. 
• 
Stop Breathing – for a detailed explanation, see page 54. 
• 
⑥  Tool Panel (displayed upon tool/EBUS needle introduction):  
• 
Needle Lock/Unlock indication 
• 
Needle Stylet In/Out buttons 
• 
Tool - Physical/Virtual activation  
• 
Tool state indication/Virtual state control 


[TABLE]
| ④  Complementary Display II – educational aids or other supplement data are   |                                                                                 |
|:------------------------------------------------------------------------------|:--------------------------------------------------------------------------------|
| available, according to selected module.                                      |                                                                                 |
|                                                                               | ⑤  Main View controls will change according to the selected module. In the EBUS |
| module, the following controls are available:                                 |                                                                                 |
| •                                                                             | Labels – for a detailed explanation, see page 68.                               |
| •                                                                             | Doppler – for a detailed explanation, see page 69.                              |
| •                                                                             | Balloon – for a detailed explanation, see page 67.                              |
| •                                                                             | Stop Breathing – for a detailed explanation, see page 54.                       |
| •                                                                             | ⑥  Tool Panel (displayed upon tool/EBUS needle introduction):                   |
| •                                                                             | Needle Lock/Unlock indication                                                   |
| •                                                                             | Needle Stylet In/Out buttons                                                    |
| •                                                                             | Tool - Physical/Virtual activation                                              |
| •                                                                             | Tool state indication/Virtual state control                                     |

[OCR_TABLE]
Variations
The basic

[OCR]
Chapter 4 BRONCH Express Platform

BRONCH Express basic display mode

The BRONCH Express offers a basic display mode for the clinical cases, with slight
variations for designated tasks.

The basic display mode consists of the following components:

Simbi nix

Figure 4-10: BRONCH Express basic display mode

@ Title bar with Task/Case identifier

@ Main View - displays WLB (video) or EBUS (Ultrasound), depending on the
selected module.

@ Complementary Display | - changes according to selected module. In the Essential
EBUS module, the WLB (video) View is displayed.

@ Complementary Display Il - educational aids or other supplement data are
available, according to selected module.

© Main View controls will change according to the selected module. In the EBUS
module, the following controls are available:

e Labels — for a detailed explanation, see page 68.

Doppler — for a detailed explanation, see page 69.

Balloon - for a detailed explanation, see page 67.

Stop Breathing — for a detailed explanation, see page 54.

© Tool Panel (displayed upon tool/EBUS needle introduction):

Needle Lock/Unlock indication

Needle Stylet In/Out buttons

Tool - Physical/Virtual activation

Tool state indication/Virtual state control

surgicalscience Page 31


# Page 43

Chapter 4 
 BRONCH Express Platform
 
Page 32
 
• 
⑦  Complementary Display Selection Controls 
Note: The Complementary Display selection changes per different modules/tasks. 
The following list describes the controls for Essential EBUS cases.  
• 
CT – Axial (default display) – for a detailed explanation, see Imaging results/CT 
browser on page 61. 
• 
CT – Coronal plane  
• 
CT – Sagittal plane 
• 
3D Map – for a detailed explanation, see page 58. 
• 
IASLC Lymph Node Stations Map – for a detailed explanation, see page 73. 
⑧  3D Map Options (displayed upon selection of 3D Map in the Complementary 
Display) 
• 
Buttons defining mouse drag functionality: 
Rotate (default), Zoom, Pan. For a detailed explanation, see Controlling the 3D Map 
view on page 59. 
• 
Reset – resets to default position. For a detailed explanation, see Controlling the 
3D Map view on page 59. 
⑨  General Buttons 
• 
Patient file – for a detailed explanation, see General buttons on page 64. 
• 
Exit – for a detailed explanation, see General buttons on page 64. 
Note: The differences in the Designated Tasks Display Mode are mostly in the 
availability of controls or educational aids. Redundant displays per the 
specific task may be removed.  


[TABLE]
| Chapter 4                                                                            |
|  BRONCH Express Platform                                                             |
|:-------------------------------------------------------------------------------------|
| ⑦  Complementary Display Selection Controls                                          |
| •                                                                                    |
| Note: The Complementary Display selection changes per different modules/tasks.       |
| The following list describes the controls for Essential EBUS cases.                  |
| CT – Axial (default display) – for a detailed explanation, see Imaging results/CT    |
| •                                                                                    |
| browser on page 61.                                                                  |
| CT – Coronal plane                                                                   |
| •                                                                                    |
| CT – Sagittal plane                                                                  |
| •                                                                                    |
| 3D Map – for a detailed explanation, see page 58.                                    |
| •                                                                                    |
| IASLC Lymph Node Stations Map – for a detailed explanation, see page 73.             |
| •                                                                                    |
| ⑧  3D Map Options (displayed upon selection of 3D Map in the Complementary           |
| Display)                                                                             |
| Buttons defining mouse drag functionality:                                           |
| •                                                                                    |
| Rotate (default), Zoom, Pan. For a detailed explanation, see Controlling the 3D Map  |
| view on page 59.                                                                     |
| Reset – resets to default position. For a detailed explanation, see Controlling the  |
| •                                                                                    |
| 3D Map view on page 59.                                                              |
| ⑨  General Buttons                                                                   |
| Patient file – for a detailed explanation, see General buttons on page 64.           |
| •                                                                                    |
| Exit – for a detailed explanation, see General buttons on page 64.                   |
| •                                                                                    |
| Note: The differences in the Designated Tasks Display Mode are mostly in the         |
| availability of controls or educational aids. Redundant displays per the             |

[OCR_TABLE]
Chapter 4

[OCR]
Chapter 4 BRONCH Express Platform

@ Complementary Display Selection Controls

Note: The Complementary Display selection changes per different modules/tasks.
The following list describes the controls for Essential EBUS cases.

CT - Axial (default display) - for a detailed explanation, see Imaging results/CT
browser on page 61.

e CT-Coronal plane

e CT -Sagittal plane

e 3D Map - for a detailed explanation, see page 58.

e IASLC Lymph Node Stations Map - for a detailed explanation, see page 73.

3D Map Options (displayed upon selection of 3D Map in the Complementary

Display)

e Buttons defining mouse drag functionality:
Rotate (default), Zoom, Pan. For a detailed explanation, see Controlling the 3D Map
view on page 59.

e Reset — resets to default position. For a detailed explanation, see Controlling the
3D Map view on page 59.

@© General Buttons

e Patient file - for a detailed explanation, see General buttons on page 64.

e ~=Exit - for a detailed explanation, see General buttons on page 64.

Note: The differences in the Designated Tasks Display Mode are mostly in the
availability of controls or educational aids. Redundant displays per the
specific task may be removed.

surgicalscience Page 32


# Page 44

Chapter 4 
 BRONCH Express Platform
 
Page 33
 
BRONCH Express unique features  
The following features are unique to the BRONCH Express, differentiating it from the 
BRONCH Mentor: 
a. There is no option to add gastrointestinal simulation modules to the BRONCH 
Express platform. 
b. This simulation platform is not affected by electromagnetic disturbances and may 
be placed next to metal bodies without interference.  
c. Optional Working positions: 
• 
The selection of Posterior/Lateral working position is available in most if not 
all tasks and cases.  
• 
The selected working position must be complemented with the 
corresponding positioning of the simulation unit and laptop on the table. 
Default working position is always the Posterior one. 
• 
Switching the working position is available only when the scope is 
completely outside the simulation unit. 
 
To switch to the Lateral working position: 
• 
When the scope insertion tube is completely outside the simulation unit, 
press the Ctrl+Alt+L keys to switch to the Lateral position. The scope view 
is rotated 180 degrees, as in picture A.  
 
Note: In this working position, the scope must be inserted in a 6:00 o’clock 
orientation whenever it is being introduced. 
 
To restore the Posterior working position: 
• 
When the scope insertion tube is completely outside the simulation unit, 
press the Ctrl+Alt+P keys to restore the default Posterior working position. 
Scope view is rotated back to 0 degrees.  


[TABLE]
| Chapter 4                                                                            |
|  BRONCH Express Platform                                                             |
|:-------------------------------------------------------------------------------------|
| BRONCH Express unique features                                                       |
| The following features are unique to the BRONCH Express, differentiating it from the |
| BRONCH Mentor:                                                                       |
| There is no option to add gastrointestinal simulation modules to the BRONCH          |
| a.                                                                                   |
| Express platform.                                                                    |
| b.  This simulation platform is not affected by electromagnetic disturbances and may |
| be placed next to metal bodies without interference.                                 |
| c.  Optional Working positions:                                                      |

[TABLE]
| Express platform.                                                                    |                                                                                 |
|:-------------------------------------------------------------------------------------|:--------------------------------------------------------------------------------|
| b.  This simulation platform is not affected by electromagnetic disturbances and may |                                                                                 |
| be placed next to metal bodies without interference.                                 |                                                                                 |
| c.  Optional Working positions:                                                      |                                                                                 |
| •                                                                                    | The selection of Posterior/Lateral working position is available in most if not |
|                                                                                      | all tasks and cases.                                                            |
| •                                                                                    | The selected working position must be complemented with the                     |
|                                                                                      | corresponding positioning of the simulation unit and laptop on the table.       |
|                                                                                      | Default working position is always the Posterior one.                           |
| •                                                                                    | Switching the working position is available only when the scope is              |
|                                                                                      | completely outside the simulation unit.                                         |
|                                                                                      | To switch to the Lateral working position:                                      |
| •                                                                                    | When the scope insertion tube is completely outside the simulation unit,        |
|                                                                                      | press the Ctrl+Alt+L keys to switch to the Lateral position. The scope view     |
|                                                                                      | is rotated 180 degrees, as in picture A.                                        |

[OCR]
Chapter 4 BRONCH Express Platform

BRONCH Express unique features

The following features are unique to the BRONCH Express, differentiating it from the
BRONCH Mentor:

a. There is no option to add gastrointestinal simulation modules to the BRONCH
Express platform.

b. This simulation platform is not affected by electromagnetic disturbances and may
be placed next to metal bodies without interference.

c. Optional Working positions:

e The selection of Posterior/Lateral working position is available in most if not
all tasks and cases.

e The selected working position must be complemented with the
corresponding positioning of the simulation unit and laptop on the table.
Default working position is always the Posterior one.

e Switching the working position is available only when the scope is
completely outside the simulation unit.

To switch to the Lateral working position:

e When the scope insertion tube is completely outside the simulation unit,
press the Ctrl+Alt+L keys to switch to the Lateral position. The scope view
is rotated 180 degrees, as in picture A.

Note: In this working position, the scope must be inserted in a 6:00 o’clock
orientation whenever it is being introduced.

To restore the Posterior working position:

e When the scope insertion tube is completely outside the simulation unit,
press the Ctrl+Alt+P keys to restore the default Posterior working position.
Scope view is rotated back to 0 degrees.

surgicalscience Page 33


# Page 45

Chapter 4 
 BRONCH Express Platform
 
Page 34
 
Note: In this working position, the scope must be inserted in a 12:00 o’clock 
orientation whenever it is being introduced. 
 
Note: Introducing the scope in any other orientation than 12:00 o’clock (when in 
Posterior working position) or 6:00 o’clock (when in Lateral working position) 
may result in orientation inaccuracy while training. 
 
d. The simulation starts when the scope enters the trachea. Upper airways intubation 
is not part of the real-time simulation.  
e. Patient Management and the Syringe for endobronchial fluids delivery are not part 
of the BRONCH Express simulation. 
f. 
Secondary controls and options, available with the BRONCH Mentor, may not be 
part of the  BRONCH Express simulation. 
g. The BRONCH Express bronchoscope has two buttons on the control unit rather 
than three in the BRONCH Mentor bronchoscope. However, these buttons serve 
the same purposes:  
• 
Virtual activation of tools, when available:  
Back button - to turn the virtual activation On/Off  
Front button - to change the tool’s state (Open/Close, In/Out, etc.) 
• 
Menu selection when available:  
Back button - to browse the menu entries  
Front button - to select and confirm dialog box messages 
• 
EBUS Needle stylet removal: 
Front button - to remove the stylet after passing the needle through the tissue into 
the lymph node 
Note: Whenever the EBUS needle is introduced into the scope’s working channel, 
the stylet is considered inside the needle. 
• 
Capturing snapshots when available: 
Front button - to save a snapshot of the main display to the performance report. 
Note: Capturing snapshots is available only for clinical cases and not for tasks. 


[TABLE]
|                                                                                | may result in orientation inaccuracy while training.                                 |
|:-------------------------------------------------------------------------------|:-------------------------------------------------------------------------------------|
| d                                                                              | .  The simulation starts when the scope enters the trachea. Upper airways intubation |
|                                                                                | is not part of the real-time simulation.                                             |
| e.                                                                             | Patient Management and the Syringe for endobronchial fluids delivery are not part    |
|                                                                                | of the BRONCH Express simulation.                                                    |
| f.                                                                             | Secondary controls and options, available with the BRONCH Mentor, may not be         |
|                                                                                | part of the  BRONCH Express simulation.                                              |
| g.  The BRONCH Express bronchoscope has two buttons on the control unit rather |                                                                                      |
|                                                                                | than three in the BRONCH Mentor bronchoscope. However, these buttons serve           |
|                                                                                | the same purposes:                                                                   |

[OCR_TABLE]
Note: |
fe

[OCR]
Chapter 4 BRONCH Express Platform

Note: In this working position, the scope must be inserted in a 12:00 o'clock
orientation whenever it is being introduced.

Note: Introducing the scope in any other orientation than 12:00 o’clock (when in
Posterior working position) or 6:00 o’clock (when in Lateral working position)
may result in orientation inaccuracy while training.

d. The simulation starts when the scope enters the trachea. Upper airways intubation
is not part of the real-time simulation.

e. Patient Management and the Syringe for endobronchial fluids delivery are not part
of the BRONCH Express simulation.

f. Secondary controls and options, available with the BRONCH Mentor, may not be
part of the BRONCH Express simulation.

g. The BRONCH Express bronchoscope has two buttons on the control unit rather
than three in the BRONCH Mentor bronchoscope. However, these buttons serve
the same purposes:

e Virtual activation of tools, when available:
Back button - to turn the virtual activation On/Off
Front button - to change the tool's state (Open/Close, In/Out, etc.)
¢ Menu selection when available:
Back button - to browse the menu entries
Front button - to select and confirm dialog box messages
¢ EBUS Needle stylet removal:
Front button - to remove the stylet after passing the needle through the tissue into
the lymph node

Note: Whenever the EBUS needle is introduced into the scope’s working channel,
the stylet is considered inside the needle.

e Capturing snapshots when available:
Front button - to save a snapshot of the main display to the performance report.

Note: Capturing snapshots is available only for clinical cases and not for tasks.

surgicalscience Page 34


# Page 46

Chapter 5 
 Getting Started
 
Page 35
 
Chapter 5 Getting Started 
Essential workflow 
The following chapters will describe how to use the simulator. To get started, on any 
simulation case or task follow this workflow. 
1.  Log in to the simulator (see page 37). 
2.  Select a module or course and review its didactic materials if available (see page 
43). 
3.  Start a simulation case or task (see page 44). 
4.  Perform the virtual patient simulation: inspecting, diagnosing and treating as you 
see fit. Multiple educational aids and helpers are at your disposal (see pages 52 
and 85).  
5.  Once you have completed treating the virtual patient, click Finish to exit the 
simulation. 
6.  Review your performance report and learning curve graphs (see page 113). 


[TABLE]
| Chapter 5                                                                               | Getting Started                                                                   |
|:----------------------------------------------------------------------------------------|:----------------------------------------------------------------------------------|
| Chapter 5  Getting Started                                                              |                                                                                   |
| Essential workflow                                                                      |                                                                                   |
| The following chapters will describe how to use the simulator. To get started, on any   |                                                                                   |
| simulation case or task follow this workflow.                                           |                                                                                   |
| 1.   Log in to the simulator (see page 37).                                             |                                                                                   |
| 2.   Select a module or course and review its didactic materials if available (see page |                                                                                   |
| 43).                                                                                    |                                                                                   |
| 3.   Start a simulation case or task (see page 44).                                     |                                                                                   |
| 4.   Perform the virtual patient simulation: inspecting, diagnosing and treating as you |                                                                                   |
|                                                                                         | see fit. Multiple educational aids and helpers are at your disposal (see pages 52 |
| and 85).                                                                                |                                                                                   |
| 5.   Once you have completed treating the virtual patient, click Finish to exit the     |                                                                                   |
| simulation.                                                                             |                                                                                   |
| 6.   Review your performance report and learning curve graphs (see page 113).           |                                                                                   |

[OCR]
Chapter 5 Getting Started

| Chapter 5 Getting Started

Essential workflow

The following chapters will describe how to use the simulator. To get started, on any
simulation case or task follow this workflow.

1. Login to the simulator (see page 37).

2. Selecta module or course and review its didactic materials if available (see page
43).

3. Start.a simulation case or task (see page 44).

4. Perform the virtual patient simulation: inspecting, diagnosing and treating as you
see fit. Multiple educational aids and helpers are at your disposal (see pages 52
and 85).

5. Once you have completed treating the virtual patient, click Finish to exit the
simulation.

6. Review your performance report and learning curve graphs (see page 113).

surgicalscience Page 35


# Page 47

Chapter 6 
 MentorLearn
 
Page 36
 
Chapter 6 MentorLearn 
MentorLearn is a web-based simulator curricula management system, providing the 
optimal solution for managing training and education needs for the Surgical Science 
line of simulators. 
This easy-to-use system facilitates performing the administrative tasks of a simulator-
based curriculum, running a training course or workshop. The system includes a library 
of ready-to-use simulator-based courses and a platform to design new training 
courses. Courses may include online didactic content, proficiency based hands-on 
training, and performance review and assessment. For more information regarding 
using MentorLearn, refer to the MentorLearn Guide for Learners. 
MentorLearn workflow 
All BRONCH Mentor modules, including didactic materials, simulation tasks, simulation 
cases etc. are accessed from MentorLearn, Surgical Science's web-based simulation 
curricula management system. 
When you want to use didactic materials from a BRONCH Mentor module, you log in to 
MentorLearn and open the materials from MentorLearn. The MentorLearn login page 
appears on the screen when you turn on the system. 
When you want to perform a hands-on training task or case, you open it from 
MentorLearn. MentorLearn opens the BRONCH Mentor task or case for you, closes it 
when you finish the case or task, and shows you a report of your performance 
afterwards. This is the workflow for performing hands-on training. 
• 
Log in to MentorLearn (see page 37) 
• 
Review didactic materials (see page 43) 
• 
Start a simulation case or task (see page 44). MentorLearn opens it for you to 
begin the hands-on simulation. 
• 
Perform the case or task using the BRONCH Mentor simulator (see page 103). 
When you finish the case or task, MentorLearn closes it and displays a 
performance report. 
• 
Review your performance report (see page 113). 


[TABLE]
| Chapter 6                                                                           | MentorLearn                                                                             |
|:------------------------------------------------------------------------------------|:----------------------------------------------------------------------------------------|
| Chapter 6  MentorLearn                                                              |                                                                                         |
| MentorLearn is a web-based simulator curricula management system, providing the     |                                                                                         |
| optimal solution for managing training and education needs for the Surgical Science |                                                                                         |
| line of simulators.                                                                 |                                                                                         |
|                                                                                     | This easy-to-use system facilitates performing the administrative tasks of a simulator- |
|                                                                                     | based curriculum, running a training course or workshop. The system includes a library  |
| of ready-to-use simulator-based courses and a platform to design new training       |                                                                                         |
| courses. Courses may include online didactic content, proficiency based hands-on    |                                                                                         |
| training, and performance review and assessment. For more information regarding     |                                                                                         |
| using MentorLearn, refer to the MentorLearn Guide for Learners.                     |                                                                                         |
| MentorLearn workflow                                                                |                                                                                         |
|                                                                                     | All BRONCH Mentor modules, including didactic materials, simulation tasks, simulation   |
| cases etc. are accessed from MentorLearn, Surgical Science's web-based simulation   |                                                                                         |
| curricula management system.                                                        |                                                                                         |
|                                                                                     | When you want to use didactic materials from a BRONCH Mentor module, you log in to      |
| MentorLearn and open the materials from MentorLearn. The MentorLearn login page     |                                                                                         |
| appears on the screen when you turn on the system.                                  |                                                                                         |
| When you want to perform a hands-on training task or case, you open it from         |                                                                                         |
| MentorLearn. MentorLearn opens the BRONCH Mentor task or case for you, closes it    |                                                                                         |
| when you finish the case or task, and shows you a report of your performance        |                                                                                         |
| afterwards. This is the workflow for performing hands-on training.                  |                                                                                         |

[TABLE]
| When you want to perform a hands-on training task or case, you open it from      |                                                                                |
|:---------------------------------------------------------------------------------|:-------------------------------------------------------------------------------|
| MentorLearn. MentorLearn opens the BRONCH Mentor task or case for you, closes it |                                                                                |
| when you finish the case or task, and shows you a report of your performance     |                                                                                |
| afterwards. This is the workflow for performing hands-on training.               |                                                                                |
| •                                                                                | Log in to MentorLearn (see page 37)                                            |
| •                                                                                | Review didactic materials (see page 43)                                        |
| •                                                                                | Start a simulation case or task (see page 44). MentorLearn opens it for you to |
|                                                                                  | begin the hands-on simulation.                                                 |
| •                                                                                | Perform the case or task using the BRONCH Mentor simulator (see page 103).     |
|                                                                                  | When you finish the case or task, MentorLearn closes it and displays a         |
|                                                                                  | performance report.                                                            |
| •                                                                                | Review your performance report (see page 113).                                 |

[OCR_TABLE]
Chapter 6

[OCR_TABLE]
| wi iIMiY’

[OCR_TABLE]
Miantorl a

[OCR]
Chapter 6 MentorLearn

| Chapter 6 MentorLearn

MentorLearn is a web-based simulator curricula management system, providing the
optimal solution for managing training and education needs for the Surgical Science
line of simulators.

This easy-to-use system facilitates performing the administrative tasks of a simulator-
based curriculum, running a training course or workshop. The system includes a library
of ready-to-use simulator-based courses and a platform to design new training
courses. Courses may include online didactic content, proficiency based hands-on
training, and performance review and assessment. For more information regarding
using MentorLearn, refer to the MentorLearn Guide for Learners.

MentorLearn workflow

All BRONCH Mentor modules, including didactic materials, simulation tasks, simulation
cases etc. are accessed from MentorLearn, Surgical Science's web-based simulation
curricula management system.

When you want to use didactic materials from a BRONCH Mentor module, you log in to
MentorLearn and open the materials from MentorLearn. The MentorLearn login page
appears on the screen when you turn on the system.

When you want to perform a hands-on training task or case, you open it from
MentorLearn. MentorLearn opens the BRONCH Mentor task or case for you, closes it
when you finish the case or task, and shows you a report of your performance
afterwards. This is the workflow for performing hands-on training.

e Log in to MentorLearn (see page 37)
e Review didactic materials (see page 43)

e  Starta simulation case or task (see page 44). MentorLearn opens it for you to
begin the hands-on simulation.

e Perform the case or task using the BRONCH Mentor simulator (see page 103).
When you finish the case or task, MentorLearn closes it and displays a
performance report.

e Review your performance report (see page 113).

surgicalscience Page 36


# Page 48

Chapter 6 
 MentorLearn
 
Page 37
 
Logging in to MentorLearn on the simulator 
In order to access functionality on a simulator, you need to first enter the MentorLearn 
system. You require a login name and password to login. When you log in, the Library 
page is displayed. For more information regarding using MentorLearn, refer to the 
MentorLearn Guide for Learners or MentorLearn Guide for Administrators. 
To log in: 
 
Figure 6-1: MentorLearn Login screen 
1.  Press Login. 
The Login screen is displayed. 


[TABLE]
| Chapter 6                                                                            | MentorLearn                                                                              |
|:-------------------------------------------------------------------------------------|:-----------------------------------------------------------------------------------------|
| Logging in to MentorLearn on the simulator                                           |                                                                                          |
|                                                                                      | In order to access functionality on a simulator, you need to first enter the MentorLearn |
| system. You require a login name and password to login. When you log in, the Library |                                                                                          |
| page is displayed. For more information regarding using MentorLearn, refer to the    |                                                                                          |
| MentorLearn Guide for Learners or MentorLearn Guide for Administrators.              |                                                                                          |
| To log in:                                                                           |                                                                                          |
| F                                                                                    |                                                                                          |
| i                                                                                    |                                                                                          |
| gure 6-1: MentorLearn Login screen                                                   |                                                                                          |
| 1.   Press Login.                                                                    |                                                                                          |
| The Login screen is displayed.                                                       |                                                                                          |
|                                                                                      | Page 37                                                                                  |

[OCR]
Chapter 6 MentorLearn

Logging in to MentorLearn on the simulator

In order to access functionality on a simulator, you need to first enter the MentorLearn
system. You require a login name and password to login. When you log in, the Library
page is displayed. For more information regarding using MentorLearn, refer to the
MentorLearn Guide for Learners or MentorLearn Guide for Administrators.

To log in:

Register to use the system

Select Language

English

Select Theme

Light

Figure 6-1: MentorLearn Login screen

1. Press Login.
The Login screen is displayed.

surgicalscience Page 37


# Page 49

Chapter 6 
 MentorLearn
 
Page 38
 
 
2.  In Login Name, enter your login name. The login name is case sensitive. 
3.  In Password, enter your password. Your password is case sensitive. 
4.  Press Login. 
MentorLearn opens and displays your Library page. Your first name and last name 
appear in the top right corner of the screen. 


[TABLE]
| Chapter 6                                                                       |
|  MentorLearn                                                                    |
|:--------------------------------------------------------------------------------|
| 2.                                                                              |
| In Login Name, enter your login name. The login name is case sensitive.         |
| 3.                                                                              |
| In Password, enter your password. Your password is case sensitive.              |
| 4.   Press Login.                                                               |
| MentorLearn opens and displays your Library page. Your first name and last name |
| appear in the top right corner of the screen.                                   |
| Page 38                                                                         |

[OCR]
Chapter 6

MentorLearn

PON

surgicalscience | simbionix simulators

Login Name

BhattieWy

Password

LOGIN

Forgot Password?

LOGIN AS A GUEST

RETURN TO MAIN PAGE

In Login Name, enter your login name. The login name is case sensitive.
In Password, enter your password. Your password is case sensitive.

Press Login.

MentorLearn opens and displays your Library page. Your first name and last name

appear in the top right corner of the screen.

surgicalscience

Page 38


# Page 50

Chapter 6 
 MentorLearn
 
Page 39
 
When you log in to MentorLearn, the MentorLearn menu appears on the left side of 
the screen. 
 
The menu gives you structured access to the MentorLearn functionality. Click any 
menu option to open the associated screen in MentorLearn. Click 
 above the 
MentorLearn menu to hide it. 
Note: The buttons that appear on the MentorLearn menu are dependent on your 
user-type. 
Working locally and on a cloud site 
The cloud configuration is possible only if there is access to the internet. If there is 
temporarily no internet access but you need to use the simulators, you can switch to 
working locally on the simulator.  
When you switch to work locally, MentorLearn switches from the cloud database to a 
local database, meaning:  
Group, user, and assigned course information is not saved to the local simulator. If 
necessary, groups and users must be redefined on each local simulator, and training 
must be reassigned. 
Any data that is created during the time you are working locally is not saved to the 
cloud database after the simulator is switched back to the cloud site. Any reports or 
information on how a user performed a simulator case will not be available, new users 
and groups, and so on, are maintained in the local database and are not available when 
you are on a cloud site. 
 


[TABLE]
| Note: The buttons that appear on the MentorLearn menu are dependent on your              |
|:-----------------------------------------------------------------------------------------|
| user-type.                                                                               |
| Working locally and on a cloud site                                                      |
| The cloud configuration is possible only if there is access to the internet. If there is |
| temporarily no internet access but you need to use the simulators, you can switch to     |
| working locally on the simulator.                                                        |
| When you switch to work locally, MentorLearn switches from the cloud database to a       |
| local database, meaning:                                                                 |
| Group, user, and assigned course information is not saved to the local simulator. If     |
| necessary, groups and users must be redefined on each local simulator, and training      |
| must be reassigned.                                                                      |
| Any data that is created during the time you are working locally is not saved to the     |
| cloud database after the simulator is switched back to the cloud site. Any reports or    |
| information on how a user performed a simulator case will not be available, new users    |
| and groups, and so on, are maintained in the local database and are not available when   |
| you are on a cloud site.                                                                 |

[OCR_TABLE]
Libr:

[OCR]
Chapter 6 MentorLearn

When you log in to MentorLearn, the MentorLearn menu appears on the left side of
the screen.

Library
My Curricula
Reports

My Profile

The menu gives you structured access to the MentorLearn functionality. Click any

menu option to open the associated screen in MentorLearn. Click =| above the
MentorLearn menu to hide it.

Note: The buttons that appear on the MentorLearn menu are dependent on your
user-type.

Working locally and on a cloud site

The cloud configuration is possible only if there is access to the internet. If there is
temporarily no internet access but you need to use the simulators, you can switch to
working locally on the simulator.

When you switch to work locally, MentorLearn switches from the cloud database to a
local database, meaning:

Group, user, and assigned course information is not saved to the local simulator. If
necessary, groups and users must be redefined on each local simulator, and training
must be reassigned.

Any data that is created during the time you are working locally is not saved to the
cloud database after the simulator is switched back to the cloud site. Any reports or
information on how a user performed a simulator case will not be available, new users
and groups, and so on, are maintained in the local database and are not available when
you are on a cloud site.

surgicalscience Page 39


# Page 51

Chapter 6 
 MentorLearn
 
Page 40
 
To switch from working on the MentorLearn cloud site to working locally: 
1.  Open MentorLearn on the simulator. MentorLearn is redirected to work locally with 
the selected simulator. The 
 icon on the top of any screen changes to the 
 
icon.  
Note: It is recommended that you switch back to cloud mode as soon as the 
internet connection is restored. 
 
To switch from working locally to working on the MentorLearn cloud site: 
1.  Open the web browser and go to http://Your-site-name.mentorlearn.com. 
MentorLearn is redirected to work with the MentorLearn cloud database. The 
 
icon on the top of any screen changes to the 
 icon. 
Accessing a module or course within My Curricula or 
Library 
This section describes how users train using MentorLearn. 
• 
To access training courses and modules that you have been assigned, click My 
Curricula on the MentorLearn menu (left pane). 
 
Figure 6-2: My Curricula page 
• 
To access all the training courses and modules available in the library, click Library 
on the MentorLearn menu (left pane). 


[TABLE]
| Chapter 6                                                                               |
|  MentorLearn                                                                            |
|:----------------------------------------------------------------------------------------|
| To switch from working on the MentorLearn cloud site to working locally:                |
| 1.   Open MentorLearn on the simulator. MentorLearn is redirected to work locally with  |
| the selected simulator. The                                                             |
|  icon on the top of any screen changes to the                                           |
| icon.                                                                                   |
| Note: It is recommended that you switch back to cloud mode as soon as the               |
| internet connection is restored.                                                        |
| T                                                                                       |
| o switch from working locally to working on the MentorLearn cloud site:                 |
| 1.   Open the web browser and go to http://Your-site-name.mentorlearn.com.              |
| MentorLearn is redirected to work with the MentorLearn cloud database. The              |
| icon on the top of any screen changes to the                                            |
|  icon.                                                                                  |
| Accessing a module or course within My Curricula or                                     |
| Library                                                                                 |
| This section describes how users train using MentorLearn.                               |
| To access training courses and modules that you have been assigned, click My            |
| •                                                                                       |
| Curricula on the MentorLearn menu (left pane).                                          |
| F                                                                                       |
| i                                                                                       |
| gure 6-2: My Curricula page                                                             |
| To access all the training courses and modules available in the library, click Library  |
| •                                                                                       |
| on the MentorLearn menu (left pane).                                                    |
| Page 40                                                                                 |

[OCR]
Chapter 6 MentorLearn

To switch from working on the MentorLearn cloud site to working locally:
1. Open MentorLearn on the simulator. MentorLearn is redirected to work locally with

the selected simulator. The & icon on the top of any screen changes to the Q
icon.

Note: It is recommended that you switch back to cloud mode as soon as the
internet connection is restored.

To switch from working locally to working on the MentorLearn cloud site:
1. Open the web browser and go to http://Your-site-name.mentorlearn.com.

MentorLearn is redirected to work with the MentorLearn cloud database. The Q

icon on the top of any screen changes to the C icon.

Accessing a module or course within My Curricula or
Library

This section describes how users train using MentorLearn.

e To access training courses and modules that you have been assigned, click My
Curricula on the MentorLearn menu (left pane).

Figure 6-2: My Curricula page

e Toaccess all the training courses and modules available in the library, click Library
on the MentorLearn menu (left pane).

surgicalscience Page 40


# Page 52

Chapter 6 
 MentorLearn
 
Page 41
 
 
Figure 6-3: BRONCH Mentor Library page  
On the BRONCH Mentor Library page, MentorLearn displays the list of modules 
and courses. They are categorized as Simbionix Modules, Standard Courses 
(ready-to-use courses provided by experienced educators in collaboration with 
Surgical Science), and Customized Courses (courses you and other educators at 
your center have created). 


[TABLE]
| F                                                                             |
| i                                                                             |
| gure 6-3: BRONCH Mentor Library page                                          |
|:------------------------------------------------------------------------------|
| On the BRONCH Mentor Library page, MentorLearn displays the list of modules   |
| and courses. They are categorized as Simbionix Modules, Standard Courses      |
| (ready-to-use courses provided by experienced educators in collaboration with |
| Surgical Science), and Customized Courses (courses you and other educators at |
| your center have created).                                                    |

[OCR_TABLE]
Simbionix
Skills and Ta:

[OCR]
Chapter 6 MentorLearn

Simbionix Modules
Skills and Tasks

Essential Bronchoscopy

5

;

CHEST (ACCP) 01

Standard Courses

Figure 6-3: BRONCH Mentor Library page

On the BRONCH Mentor Library page, MentorLearn displays the list of modules
and courses. They are categorized as Simbionix Modules, Standard Courses
(ready-to-use courses provided by experienced educators in collaboration with
Surgical Science), and Customized Courses (courses you and other educators at
your center have created).

surgicalscience Page 41


# Page 53

Chapter 6 
 MentorLearn
 
Page 42
 
Easy Access to courses and modules in the Library 
 
To easily access courses and modules in 
the Library, click the Easy Access arrow 
on the top right side of the screen and 
select an option from the list. 
To search for a specific module or group 
of modules, click the Search button, 
enter a term and click the Search button 
again. To clear the search results, click 
one of the easy access options. 
 
 
Open a module or course, review didactic material or perform a hands-on simulation 
case. For more information, see Reviewing didactic materials (on page 43) and Starting 
a simulation case or task (on page 44).  
1.  To open a module or course, press its row. The module opens, displaying a 
description of the module, its learning objectives, and the educational content of 
the module. 


[TABLE]
| Easy Access to courses and modules in the Library   |
|:----------------------------------------------------|
| To easily access courses and modules in             |
| the Library, click the Easy Access arrow            |
| on the top right side of the screen and             |
| select an option from the list.                     |
| To search for a specific module or group            |
| of modules, click the Search button,                |
| enter a term and click the Search button            |
| again. To clear the search results, click           |
| one of the easy access options.                     |

[OCR_TABLE]
Cnapter 0

[OCR]
Chapter 6 MentorLearn

Easy Access to courses and modules in the Library

To easily access courses and modules in

Q_DisplayAll ~ the Library, click the Easy Access arrow
on the top right side of the screen and
select an option from the list.

To search for a specific module or group
of modules, click the Search button,
Customized Courses enter a term and click the Search button
again. To clear the search results, click
one of the easy access options.

Display All

Standard Courses

Modules

Open a module or course, review didactic material or perform a hands-on simulation

case. For more information, see Reviewing didactic materials (on page 43) and Starting
a simulation case or task (on page 44).

1. To open a module or course, press its row. The module opens, displaying a
description of the module, its learning objectives, and the educational content of
the module.

surgicalscience Page 42


# Page 54

Chapter 6 
 MentorLearn
 
Page 43
 
 
Figure 6-4: Opening a module 
Reviewing didactic materials 
The BRONCH Mentor modules and courses may include didactic materials preceding 
the hands-on training. Materials can also be added by the site using the simulator, per 
simulation course/curricula, including video tutorials, real-life procedure videos, 
reading material and more. 
1.  On the MentorLearn menu, press Library. 
MentorLearn displays the list of Simbionix modules and standard courses in the 
simulator library. 
2.  Open a module or course by pressing its row. The module opens, displaying a 
description of the module and all the items in the module. 
3.  In the Didactics category of each course assignment, select the didactic material 
you want to look at and press its row. 


[TABLE]
|                                                                                         | F                                                                                 |
|                                                                                         | i                                                                                 |
|                                                                                         | gure 6-4: Opening a module                                                        |
|:----------------------------------------------------------------------------------------|:----------------------------------------------------------------------------------|
| Reviewing didactic materials                                                            |                                                                                   |
| The BRONCH Mentor modules and courses may include didactic materials preceding          |                                                                                   |
| the hands-on training. Materials can also be added by the site using the simulator, per |                                                                                   |
| simulation course/curricula, including video tutorials, real-life procedure videos,     |                                                                                   |
| reading material and more.                                                              |                                                                                   |
| 1.   On the MentorLearn menu, press Library.                                            |                                                                                   |
|                                                                                         | MentorLearn displays the list of Simbionix modules and standard courses in the    |
|                                                                                         | simulator library.                                                                |
| 2.   Open a module or course by pressing its row. The module opens, displaying a        |                                                                                   |
|                                                                                         | description of the module and all the items in the module.                        |
| 3.                                                                                      | In the Didactics category of each course assignment, select the didactic material |
|                                                                                         | you want to look at and press its row.                                            |

[OCR]
Chapter 6 MentorLearn

< sro > Emerge

Emergency Bronchoscopy

Description

This module of Emergency and ICU scenarios offers cases cf endobronchial bleeding aspirated foreign bodies and therapeutic aspiration (bronchoscopic pulmonary tlle)

The modu provides a comprehensive dinical environment for hands-on practice of bronchoscopic emergency scenarios within the contoled environment ofthe simulation. The Emergency
module offers practitioners the opportunity te encounter these enieal and streeeful situations where they ean perform, or even ere without consequences.

objectives
+ To practice the complete workflow of inspection, diagnosic and treatment of endobronctial blooding situations
+ Topractice the complete workflow of inspection, diagnosis and treatment of freign body aspiration situations
+ To practi the complete workflow of inspection, diagnosis and treatment for therapeutic asplati of pulmonary secretions
+ Tossess the clinical scenario and apply therapeutic methods eccordingly
+ Topractice foelgnbody removal using a selection of tools
+ To safely andeffciently salve endobronchial bleeding stustlans using a variety of tools
+ To practice therapeutic aspiration procedures using a selection of scopes and methods
+ Tomaintain the virtual patient's condition, voiding respiratory or hemodynamic deterioration while applying therapeutic measures
+ Toperfom ina trueto-Me environment where operational or einical mistakes can be made and learnt from
+ To gain experencein allagpects of endobrenchia bleeding, foreign body retrieval and therapeutic aspration cases prior to performing on real patents

Mere.
Clinical Cases
Hands-On

Case
case2
Case3

case 4

ll ees eel el

cases

Figure 6-4: Opening a module

Reviewing didactic materials

The BRONCH Mentor modules and courses may include didactic materials preceding
the hands-on training. Materials can also be added by the site using the simulator, per
simulation course/curricula, including video tutorials, real-life procedure videos,
reading material and more.

1. On the MentorLearn menu, press Library.
MentorLearn displays the list of Simbionix modules and standard courses in the
simulator library.

2. Open a module or course by pressing its row. The module opens, displaying a
description of the module and all the items in the module.

3. In the Didactics category of each course assignment, select the didactic material
you want to look at and press its row.

surgicalscience Page 43


# Page 55

Chapter 6 
 MentorLearn
 
Page 44
 
 
Note: If the didactic material is in a format that is not supported by the simulator, 
you are prompted to save the file to an external location. PDF, mp4 files, and 
graphic files can be opened on the simulator. Microsoft® PowerPoint® and 
Word® files cannot be opened on a simulator. If you are using MentorLearn 
Cloud, the didactic material may be viewed on another computer by 
accessing your MentorLearn Cloud site. 
4.  When you have finished, close the material. 
Starting a simulation case or task 
To open a case or task: 
1.  From the MentorLearn menu, press one of the following menu options: 
o 
Library - lists all the courses and modules in the BRONCH Mentor library. If 
other simulator libraries are listed, select Library > BRONCH Mentor. 
o 
My Curricula - lists all your assigned courses and modules. 
2.  Click the Expand arrow 
 on the right side of the screen to display more details 
about the module or course. 
 


[TABLE]
| Note: If the didactic material is in a format that is not supported by the simulator,   |
|:----------------------------------------------------------------------------------------|
| you are prompted to save the file to an external location. PDF, mp4 files, and          |
| graphic files can be opened on the simulator. Microsoft® PowerPoint® and                |
| Word® files cannot be opened on a simulator. If you are using MentorLearn               |
| Cloud, the didactic material may be viewed on another computer by                       |
| accessing your MentorLearn Cloud site.                                                  |

[OCR]
Chapter 6 MentorLearn

Dr. Tim Murgu, CHEST faculty

Note: If the didactic material is in a format that is not supported by the simulator,
you are prompted to save the file to an external location. PDF, mp4 files, and
graphic files can be opened on the simulator. Microsoft® PowerPoint® and
Word® files cannot be opened on a simulator. If you are using MentorLearn
Cloud, the didactic material may be viewed on another computer by
accessing your MentorLearn Cloud site.

4. When you have finished, close the material.

Starting a simulation case or task

To open a case or task:
1. From the MentorLearn menu, press one of the following menu options:
° Library - lists all the courses and modules in the BRONCH Mentor library. If

other simulator libraries are listed, select Library > BRONCH Mentor.
° My Curricula - lists all your assigned courses and modules.

2. Click the Expand arrow ¥! on the right side of the screen to display more details

about the module or course.

Essential Bronchoscopy K

Description

acquiring detated anatomi ge ofthe bronchial tree and agoning anatomical stuctures, and

surgicalscience Page 44


# Page 56

Chapter 6 
 MentorLearn
 
Page 45
 
3.  Open the module or course you want by pressing its row. 
The curriculum description and objectives appear, with a list of didactic materials 
and hands-on tasks and cases. 
 
4.  Under the Hands-on category, select the case or task you want to perform, and 
press its row. 
The patient file or task description file opens. 


[TABLE]
| Chapter 6                                                                          | MentorLearn                                                                         |
|:-----------------------------------------------------------------------------------|:------------------------------------------------------------------------------------|
| 3.   Open the module or course you want by pressing its row.                       |                                                                                     |
|                                                                                    | The curriculum description and objectives appear, with a list of didactic materials |
| and hands-on tasks and cases.                                                      |                                                                                     |
| 4.   Under the Hands-on category, select the case or task you want to perform, and |                                                                                     |
| press its row.                                                                     |                                                                                     |
| The patient file or task description file opens.                                   |                                                                                     |
|                                                                                    | Page 45                                                                             |

[OCR]
Chapter 6

MentorLearn

3. Open the module or course you want by pressing its row.

The curriculum description and objectives appear, with a list of didactic materials

and hands-on tasks and cases.

Essential Bronchoscopy

Description
§ Essential Bronchoscopy sil tasks.

This module provides designated skill tasks to accelerate the trainees learning curve while acquiring andintegrating necessary bronchoscopic capabilites.

“The module provides highly constwuctive and didactic traning environments, almed at improving hand-eye coordination and scope navigation, enhancing 3D cognitive perception, acquiring
Aetaled anatomicalknowledge ofthe honchial ree and sdoining snatemiesl structures, and practicing step-by-step tissue sampling

objectives
+ To improve hand-eye coordhation
«+ To acquire basic bronchoscope maneuvering capabilities
+ To enharce 30 anatomical perception
+ To perform a comprehensive, methodical, bronchoscopic inspection
+ To gain familiarity with bronchial anatomy and identify each bronchial segment by name
+ To ain famiiaty with agjoning mediastinal, Nar, ntertobar and lobar lymph node stations, under the IASLC map (2008)
+ To practice the step-by step performance of ferceps biopsy, cytology rushing and tansbronehial needle ospration
+ To cbjectvely assess one's bronchoscopie skils level
+ To cbjectvely assess ene's knowledge of bronchial anatomy
+ To chjectvely assess one’s knowledge of lymph nodes location and classification (according to IASLC 2009)

v Moe.

Assignment For Essential Bronchoscopy

Hands-On

T2sK3-Lung Antony Bronchial Seorents
Tas -Lung Anatomy yh Nodes

[ARID task s- siopy- step diagnostic Manewers

4. Under the Hands-on category, select the case or task you want to perform, and

press its row.
The patient file or task description file opens.

surgicalscience

Page 45


# Page 57

Chapter 6 
 MentorLearn
 
Page 46
 
 
Figure 6-5: Task description or patient file 
5.  Press 
. The simulation case begins. 
When you have completed the simulation case, you are returned to MentorLearn, 
and a report of your performance is displayed (see  Viewing Performance Reports 
on page 113). 
6.  If at any time you wish to choose another case, module, or course or another 
MentorLearn Library, click that item in the browse sequence hierarchy above the 
middle pane. 
 
Viewing course/module completion status 
In some modules and courses, benchmarks have been defined for evaluating 
performance. A skill level for different performance metrics, based on expert-derived 
goals, is used as a point of reference against which the learner’s performance is 
measured.  


[TABLE]
| F                                                                               |
| i                                                                               |
| gure 6-5: Task description or patient file                                      |
|:--------------------------------------------------------------------------------|
| 5.   Press                                                                      |
| . The simulation case begins.                                                   |
| When you have completed the simulation case, you are returned to MentorLearn,   |
| and a report of your performance is displayed (see  Viewing Performance Reports |
| on page 113).                                                                   |
| 6.                                                                              |
| If at any time you wish to choose another case, module, or course or another    |
| MentorLearn Library, click that item in the browse sequence hierarchy above the |
| middle pane.                                                                    |

[OCR_TABLE]
Task

[OCR]
Chapter 6

MentorLearn

Viewing course/module completion status

Task 1 - Basic Scope Manipulation

Task 1, Basic Scope Manipulation

eye coordination.

Introduce the scope through the mouth until reaching a “Start” sign.

Navigate the scope in a narrowing industrial lumen, following a guiding light.

Keep insertion tube straight and use the control unit's roll and lever to keep scope’s
tip in mid-lumen and avoid wall contact.

Your score will drop with each wall contact based on lumen’s width.

The path is randomly selected by the software each time you start.

Good Luck!

This task was developed in conjunction with and endorsed by the American
Association for Bronchology and Interventional Pulmonology — AABIP

Learn to navigate the bronchoscope in a cyber environment to further develop hand-

Figure 6-5: Task description or patient file

Press > J The simulation case begins.

When you have completed the simulation case, you are returned to MentorLearn,
and a report of your performance is displayed (see Viewing Performance Reports

on page 113).

If at any time you wish to choose another case, module, or course or another
MentorLearn Library, click that item in the browse sequence hierarchy above the

middle pane.

€ BRONCH Mentor >  EssentialBronchoscopy > ‘Task 1 - Basic Scope Manipulation

In some modules and courses, benchmarks have been defined for evaluating
performance. A skill level for different performance metrics, based on expert-derived
goals, is used as a point of reference against which the learner’s performance is
measured.

surgicalscience

Page 46


# Page 58

Chapter 6 
 MentorLearn
 
Page 47
 
A summary of your current performance is displayed for modules and courses that 
have benchmarks. Opening those modules/courses displays a detailed explanation 
about your performance in specific cases/tasks. You can view at a glance how far you 
are from reaching the required skill level and what is required to achieve the 
benchmark standard.  
Completion status for modules/courses with benchmarks 
If no benchmarks have been defined for a module or course, the module/course 
appears on the Library page as follows:  
 
Figure 6-6: Modules/courses with no benchmarks 
If benchmarks have been defined for a module or course, its “Completion Status” or 
current proficiency status appears after its name: 
 
Figure 6-7: Completion status for modules/courses with benchmarks 
Proficient  
• 
Yes indicates you achieved proficiency in the module/course by completing all 
cases at the required skill level. 
• 
No indicates you have not yet achieved proficiency since not all the cases have 
been completed at the required skill level.  
The Completion indicator (percentage) increases as you pass (achieve proficiency in) 
more and more of the cases. 
When you expand a module/course by clicking the Completion or Proficiency icons, 
information about the course’s status is displayed. 
 


[TABLE]
| Chapter 6                                                                       | MentorLearn                                                                          |
|:--------------------------------------------------------------------------------|:-------------------------------------------------------------------------------------|
| A summary of your current performance is displayed for modules and courses that |                                                                                      |
| have benchmarks. Opening those modules/courses displays a detailed explanation  |                                                                                      |
|                                                                                 | about your performance in specific cases/tasks. You can view at a glance how far you |
| are from reaching the required skill level and what is required to achieve the  |                                                                                      |
| benchmark standard.                                                             |                                                                                      |
| Completion status for modules/courses with benchmarks                           |                                                                                      |
| If no benchmarks have been defined for a module or course, the module/course    |                                                                                      |
| appears on the Library page as follows:                                         |                                                                                      |

[OCR_TABLE]
ahoiit voll

[OCR]
Chapter 6 MentorLearn

A summary of your current performance is displayed for modules and courses that
have benchmarks. Opening those modules/courses displays a detailed explanation
about your performance in specific cases/tasks. You can view at a glance how far you
are from reaching the required skill level and what is required to achieve the
benchmark standard.

Completion status for modules/courses with benchmarks

If no benchmarks have been defined for a module or course, the module/course
appears on the Library page as follows:

Figure 6-6: Modules/courses with no benchmarks

If benchmarks have been defined for a module or course, its “Completion Status” or
current proficiency status appears after its name:

i Essential Bronchoscopy

Figure 6-7: Completion status for modules/courses with benchmarks

Proficient

e Yes indicates you achieved proficiency in the module/course by completing all
cases at the required skill level.

e¢ Noindicates you have not yet achieved proficiency since not all the cases have
been completed at the required skill level.

The Completion indicator (percentage) increases as you pass (achieve proficiency in)
more and more of the cases.

When you expand a module/course by clicking the Completion or Proficiency icons,
information about the course’s status is displayed.

4 ] Essential Bronchoscopy a

Des

”
ognitve perception,

surgicalscience Page 47


# Page 59

Chapter 6 
 MentorLearn
 
Page 48
 
Figure 6-8: Module/Course Description page with benchmarks 
Proficiency scoreboard for cases/tasks with benchmarks 
A variety of indicators provide information about your proficiency status in the 
cases/tasks you have performed, allowing you to better understand what your goals 
are in order to achieve the benchmark standards.  
 
Figure 6-9: Completion status for cases/tasks with benchmarks 
Proficient: Yes indicates that you have achieved the required skill level for each of the 
case’s metrics with a defined skill level the required number of times; No indicates that 
you haven’t achieved the required skill level. 
Best Score: the best score you achieved for the case. 
Non-consecutive/consecutive: the number of times you achieved the required skill 
level in consecutive/non-consecutive attempts (depending on the defined 
requirement).  
Attempts: the number of times you attempted to pass the case. 
 
Required Skill Level: Click the underlined text to display a list of the required skill 
levels. You are required to achieve this skill level on each of the metrics to achieve 
proficiency for the case. 


[TABLE]
| Chapter 6                                                                                 | MentorLearn   |
|:------------------------------------------------------------------------------------------|:--------------|
| F                                                                                         |               |
| i                                                                                         |               |
| gure 6-8: Module/Course Description page with benchmarks                                  |               |
| Proficiency scoreboard for cases/tasks with benchmarks                                    |               |
| A variety of indicators provide information about your proficiency status in the          |               |
| cases/tasks you have performed, allowing you to better understand what your goals         |               |
| are in order to achieve the benchmark standards.                                          |               |
| F                                                                                         |               |
| i                                                                                         |               |
| gure 6-9: Completion status for cases/tasks with benchmarks                               |               |
| Proficient: Yes indicates that you have achieved the required skill level for each of the |               |
| case’s metrics with a defined skill level the required number of times; No indicates that |               |
| you haven’t achieved the required skill level.                                            |               |
| Best Score: the best score you achieved for the case.                                     |               |
| Non-consecutive/consecutive: the number of times you achieved the required skill          |               |
| level in consecutive/non-consecutive attempts (depending on the defined                   |               |
| requirement).                                                                             |               |
| Attempts: the number of times you attempted to pass the case.                             |               |
| Required Skill Level: Click the underlined text to display a list of the required skill   |               |
| levels. You are required to achieve this skill level on each of the metrics to achieve    |               |
| proficiency for the case.                                                                 |               |
|                                                                                           | Page 48       |

[OCR]
Chapter 6 MentorLearn

Figure 6-8: Module/Course Description page with benchmarks

Proficiency scoreboard for cases/tasks with benchmarks

A variety of indicators provide information about your proficiency status in the
cases/tasks you have performed, allowing you to better understand what your goals
are in order to achieve the benchmark standards.

Hands-On

Task 1 - Basic Scope Manipulation

Task 2 - Guided Anatomical Navigation
Task 3 - Lung Anatomy, Bronchial Segments

Task 4-Lung A
‘

omy, Lymph Nodes

be eel eel ee

Task 5 - Step-by-Step Diagnostic Maneuvers

Figure 6-9: Completion status for cases/tasks with benchmarks

Proficient: Yes indicates that you have achieved the required skill level for each of the
case’s metrics with a defined skill level the required number of times; No indicates that
you haven't achieved the required skill level.

Best Score: the best score you achieved for the case.

Non-consecutive/consecutive: the number of times you achieved the required skill
level in consecutive/non-consecutive attempts (depending on the defined
requirement).

Attempts: the number of times you attempted to pass the case.

Required Skill Level: Click the underlined text to display a list of the required skill
levels. You are required to achieve this skill level on each of the metrics to achieve
proficiency for the case.

surgicalscience Page 48


# Page 60

Chapter 6 
 MentorLearn
 
Page 49
 
 
Figure 6-10: Required Skill Level information 
 


[TABLE]
| Chapter 6                                   | MentorLearn   |
|:--------------------------------------------|:--------------|
| F                                           |               |
| i                                           |               |
| gure 6-10: Required Skill Level information |               |
|                                             | Page 49       |

[OCR]
Chapter 6 MentorLearn

Task 3 - Lung Anatomy, Bronchial Segments
Proficient: No, Best Score: -, Non consecutive: 0 of 1, Consecutive: 0 of 1,

Required Skill Level
Total time <= 405
Bronchial segments correctly identified on Ist attempt >= 27 Segments

Figure 6-10: Required Skill Level information

surgicalscience Page 49


# Page 61

Chapter 7 
 BRONCH Mentor Display Modes
 
Page 50
 
Chapter 7 BRONCH Mentor Display Modes 
The BRONCH Mentor offers three basic display modes: 
• 
Enhanced Clinical Display Mode 
• 
Procedure Restricted Clinical Display Mode 
• 
Designated Tasks Display Modes 
 
Each workspace has a designated screen layout offering relevant displays, optional 
procedural features, educational aids, and tool options. These different modes join to 
provide a flexible training environment, where users of varying experience level can 
each find a matching simulation environment.  
Pre-procedure options  
After pressing 
, the selected case or task is loading and the Pre-Procedure screen 
is displayed for clinical cases. You can select pre-procedure options for the case, 
based on the selected module or case, such as: user position (posterior or lateral), 
Scope type, General anesthesia or Moderate sedation, and pre-medication options.  
  
 


[TABLE]
| Chapter 7                                                                              |
|  BRONCH Mentor Display Modes                                                           |
|:---------------------------------------------------------------------------------------|
| Chapter 7  BRONCH Mentor Display Modes                                                 |
| The BRONCH Mentor offers three basic display modes:                                    |
| Enhanced Clinical Display Mode                                                         |
| •                                                                                      |
| Procedure Restricted Clinical Display Mode                                             |
| •                                                                                      |
| Designated Tasks Display Modes                                                         |
| •                                                                                      |
| E                                                                                      |
| ach workspace has a designated screen layout offering relevant displays, optional      |
| procedural features, educational aids, and tool options. These different modes join to |
| provide a flexible training environment, where users of varying experience level can   |
| each find a matching simulation environment.                                           |
| Pre-procedure options                                                                  |
| After pressing                                                                         |
| , the selected case or task is loading and the Pre-Procedure screen                    |
| is displayed for clinical cases. You can select pre-procedure options for the case,    |
| based on the selected module or case, such as: user position (posterior or lateral),   |
| Scope type, General anesthesia or Moderate sedation, and pre-medication options.       |
| Page 50                                                                                |

[OCR_TABLE]
BAL news

[OCR]
Chapter 7 BRONCH Mentor Display Modes

| Chapter 7 BRONCH Mentor Display Modes

The BRONCH Mentor offers three basic display modes:

e Enhanced Clinical Display Mode
e Procedure Restricted Clinical Display Mode
e Designated Tasks Display Modes

Each workspace has a designated screen layout offering relevant displays, optional
procedural features, educational aids, and tool options. These different modes join to
provide a flexible training environment, where users of varying experience level can
each find a matching simulation environment.

Pre-procedure options

After pressing >) the selected case or task is loading and the Pre-Procedure screen
is displayed for clinical cases. You can select pre-procedure options for the case,
based on the selected module or case, such as: user position (posterior or lateral),
Scope type, General anesthesia or Moderate sedation, and pre-medication options.

surgicalscience Page 50


# Page 62

Chapter 7 
 BRONCH Mentor Display Modes
 
Page 51
 
Figure 7-1: Pre-Procedure screen 
To select pre-procedure options: 
1.  Select the checkbox next to the option you wish to work with for each criterion.  
2.  When Moderate Sedation is selected, you can indicate the sedatives and/or topical 
anesthesia you wish to use by selecting the checkbox adjacent to the drug’s name.   
Upon starting the case these pre-medication options are considered to have been 
administered 2 minutes prior to the simulation beginning. 
Some of the options might be disabled, indicating that for this case, there is no 
such choice.  
Note: Each criterion has a set default, so it is possible to just start the case without changing 
anything.  
3.  Press the Continue 
 button to begin the simulated case itself. 
Enhanced clinical display mode   
 This simulation display mode provides a comprehensive educational environment for 
clinical procedures training. Multiple supporting views and educational aids are offered 
in order to enhance the learning process. 
Simulation environment 
The simulation environment includes: 
• 
Available image modalities – featuring one or more image modalities which are 
used in the different bronchoscopic procedures. 
• 
Comprehensive patient environment - featuring detailed anatomy and physiology, 
complete patient management and active patient monitoring. 
• 
A choice of didactic features – including aids which enhance anatomical 
knowledge such as bronchial segments labeling and an anatomy atlas. Aids which 
promote three-dimensional orientation such as a dynamic 3D Map, visualizing the 
scope within the bronchial tree, and an anatomy compass. Aids promoting safe 
and efficient performance, such as real-time guidance and alerts with patient 
safety, performance efficacy and equipment safety.  
 
There are two main types for this display mode: 
• 
Single image modality – White Light Bronchoscopy, WLB (Video) 


[TABLE]
| To select pre-procedure options:                                                       |
|:---------------------------------------------------------------------------------------|
| 1.   Select the checkbox next to the option you wish to work with for each criterion.  |
| 2.   When Moderate Sedation is selected, you can indicate the sedatives and/or topical |
| anesthesia you wish to use by selecting the checkbox adjacent to the drug’s name.      |
| Upon starting the case these pre-medication options are considered to have been        |
| administered 2 minutes prior to the simulation beginning.                              |
| Some of the options might be disabled, indicating that for this case, there is no      |
| such choice.                                                                           |

[OCR_TABLE]
Vy Verewt jf

1. Select
2. When |

arnnnthk

[OCR]
Chapter 7 BRONCH Mentor Display Modes

Figure 7-1: Pre-Procedure screen

To select pre-procedure options:

1. Select the checkbox next to the option you wish to work with for each criterion.

2. When Moderate Sedation is selected, you can indicate the sedatives and/or topical
anesthesia you wish to use by selecting the checkbox adjacent to the drug’s name.

Upon starting the case these pre-medication options are considered to have been
administered 2 minutes prior to the simulation beginning.

Some of the options might be disabled, indicating that for this case, there is no
such choice.

Note: Each criterion has a set default, so it is possible to just start the case without changing
anything.

Continue

3. Press the Continue button to begin the simulated case itself.

Enhanced clinical display mode

This simulation display mode provides a comprehensive educational environment for
clinical procedures training. Multiple supporting views and educational aids are offered
in order to enhance the learning process.

Simulation environment

The simulation environment includes:

e Available image modalities - featuring one or more image modalities which are
used in the different bronchoscopic procedures.

e¢ Comprehensive patient environment - featuring detailed anatomy and physiology,
complete patient management and active patient monitoring.

e Achoice of didactic features — including aids which enhance anatomical
knowledge such as bronchial segments labeling and an anatomy atlas. Aids which
promote three-dimensional orientation such as a dynamic 3D Map, visualizing the
scope within the bronchial tree, and an anatomy compass. Aids promoting safe
and efficient performance, such as real-time guidance and alerts with patient
safety, performance efficacy and equipment safety.

There are two main types for this display mode:
e Single image modality - White Light Bronchoscopy, WLB (Video)

surgicalscience Page 51


# Page 63

Chapter 7 
 BRONCH Mentor Display Modes
 
Page 52
 
• 
Multiple image modalities, such as –  WLB and Endobronchial Ultrasound (EBUS) 
Screen layout - Single modality (WLB/Video)  
 
Figure 7-2: White Light Bronchoscopy (Video) layout 
The screen is divided into the following parts: 
① Main View  
➁ Main View Options 
③ Tool Panel 
④ Complementary Displays 
⑤ Virtual Instructor 
⑥ Patient Management Region 
⑦ General Buttons  
 
Features and educational aids - single modality 
Note: Some of the below features and aids are always available, while some are unique for a 
certain module, case or task. 


[TABLE]
| Chapter 7                                                                                    |
|  BRONCH Mentor Display Modes                                                                 |
|:---------------------------------------------------------------------------------------------|
| Multiple image modalities, such as –  WLB and Endobronchial Ultrasound (EBUS)                |
| •                                                                                            |
| Screen layout - Single modality (WLB/Video)                                                  |
| F                                                                                            |
| i                                                                                            |
| gure 7-2: White Light Bronchoscopy (Video) layout                                            |
| The screen is divided into the following parts:                                              |
| ①  Main View                                                                                 |
| ➁  Main View Options                                                                         |
| ③  Tool Panel                                                                                |
| ④  Complementary Displays                                                                    |
| ⑤  Virtual Instructor                                                                        |
| ⑥  Patient Management Region                                                                 |
| ⑦  General Buttons                                                                           |
| Features and educational aids - single modality                                              |
| Note:  Some of the below features and aids are always available, while some are unique for a |
| certain module, case or task.                                                                |
| Page 52                                                                                      |

[OCR]
Chapter 7 BRONCH Mentor Display Modes

e Multiple image modalities, such as - WLB and Endobronchial Ultrasound (EBUS)

Screen layout - Single modality (WLB/Video)

Figure 7-2: White Light Bronchoscopy (Video) layout

The screen is divided into the following parts:
Main View

Main View Options

Tool Panel

Complementary Displays

Virtual Instructor

Patient Management Region

General Buttons

QOOLHOHO

Features and educational aids - single modality

Note: Some of the below features and aids are always available, while some are unique for a
certain module, case or task.

surgicalscience Page 52


# Page 64

Chapter 7 
 BRONCH Mentor Display Modes
 
Page 53
 
Main View ① 
The Main View  displays the real time bronchoscope’s view during the procedure you 
are performing, showing the endobronchial view with coughing, fluid squirting, 
bleeding, sampling tools used and more.  
 
Figure 7-3: Primary view – bronchoscopic display 
Elapsed time  
The elapsed time indicator displays the amount of time that has elapsed since starting 
the procedure. It is located in the top right corner of the main view. 
Main View options ② 
Full screen  
 Press the Full Screen button to enlarge the main view display and 
set a Procedure Restricted training environment, where all the educational aids are 
removed. For a detailed explanation, see Procedure Restricted display mode on page 
80. 
 


[TABLE]
| Chapter 7                                                                           | BRONCH Mentor Display Modes                                                            |
|:------------------------------------------------------------------------------------|:---------------------------------------------------------------------------------------|
| Main View ①                                                                         |                                                                                        |
|                                                                                     | The Main View  displays the real time bronchoscope’s view during the procedure you    |
| are performing, showing the endobronchial view with coughing, fluid squirting,      |                                                                                        |
| bleeding, sampling tools used and more.                                             |                                                                                        |
| F                                                                                   |                                                                                        |
| i                                                                                   |                                                                                        |
| gure 7-3: Primary view – bronchoscopic display                                      |                                                                                        |
| Elapsed time                                                                        |                                                                                        |
|                                                                                     | The elapsed time indicator displays the amount of time that has elapsed since starting |
| the procedure. It is located in the top right corner of the main view.              |                                                                                        |
| Main View options ②                                                                 |                                                                                        |
| Full screen                                                                         |                                                                                        |
|                                                                                     | Press the Full Screen button to enlarge the main view display and                      |
| set a Procedure Restricted training environment, where all the educational aids are |                                                                                        |
|                                                                                     | removed. For a detailed explanation, see Procedure Restricted display mode on page     |
| 80.                                                                                 |                                                                                        |
|                                                                                     | Page 53                                                                                |

[OCR_TABLE]
IMe Wall) \

ara narfnrr

[OCR]
Chapter 7 BRONCH Mentor Display Modes

Main View (1)

The Main View © displays the real time bronchoscope’s view during the procedure you
are performing, showing the endobronchial view with coughing, fluid squirting,
bleeding, sampling tools used and more.

00:00:64!

Figure 7-3: Primary view - bronchoscopic display

Elapsed time

The elapsed time indicator displays the amount of time that has elapsed since starting
the procedure. It is located in the top right corner of the main view.

Main View options 2)
Full screen

Press the Full Screen button to enlarge the main view display and
set a Procedure Restricted training environment, where all the educational aids are
removed. For a detailed explanation, see Procedure Restricted display mode on page
80.

surgicalscience Page 53


# Page 65

Chapter 7 
 BRONCH Mentor Display Modes
 
Page 54
 
Anatomy compass  
The anatomy compass is displayed over the WLB/Video main view.  
 Press the Compass button to display the anatomical compass, 
dynamically indicating body coordinates: Anterior, Posterior, Right, and Left. 
 
Figure 7-4: Compass feature enabled 
Stop Breathing 
Use the stop breathing function to stop the virtual patient's breathing, for easier 
performance of challenging tasks. 
 Press this button to stop the virtual patient's breathing, allowing 
for easier performance of the educational/clinical task. 
Automatic Airway labeling 
Use the labels function to automatically display each bronchial segment name over the 
main view. Two labeling conventions are available: descriptive-numeric and advanced-
numeric. 
To automatically label airways: 
1.  Press the Labels 
 button. The two convention buttons are displayed. 
 
2.  Press either Descriptive numeric 
 or Advanced numeric 
. 


[TABLE]
| Chapter 7                                                                           | BRONCH Mentor Display Modes                                                           |
|:------------------------------------------------------------------------------------|:--------------------------------------------------------------------------------------|
| Anatomy compass                                                                     |                                                                                       |
| The anatomy compass is displayed over the WLB/Video main view.                      |                                                                                       |
|                                                                                     | Press the Compass button to display the anatomical compass,                           |
| dynamically indicating body coordinates: Anterior, Posterior, Right, and Left.      |                                                                                       |
| F                                                                                   |                                                                                       |
| i                                                                                   |                                                                                       |
| gure 7-4: Compass feature enabled                                                   |                                                                                       |
| Stop Breathing                                                                      |                                                                                       |
| Use the stop breathing function to stop the virtual patient's breathing, for easier |                                                                                       |
| performance of challenging tasks.                                                   |                                                                                       |
|                                                                                     | Press this button to stop the virtual patient's breathing, allowing                   |
| for easier performance of the educational/clinical task.                            |                                                                                       |
| Automatic Airway labeling                                                           |                                                                                       |
|                                                                                     | Use the labels function to automatically display each bronchial segment name over the |
|                                                                                     | main view. Two labeling conventions are available: descriptive-numeric and advanced-  |
| numeric.                                                                            |                                                                                       |
| To automatically label airways:                                                     |                                                                                       |
| 1.   Press the Labels                                                               | button. The two convention buttons are displayed.                                     |
| 2.   Press either Descriptive numeric                                               | or Advanced numeric                                                                   |
|                                                                                     | .                                                                                     |
|                                                                                     | Page 54                                                                               |

[OCR]
Chapter 7 BRONCH Mentor Display Modes

Anatomy compass

The anatomy compass is displayed over the WLB/Video main view.

Press the Compass button to display the anatomical compass,
dynamically indicating body coordinates: Anterior, Posterior, Right, and Left.

0:00:64]

Figure 7-4: Compass feature enabled

Stop Breathing

Use the stop breathing function to stop the virtual patient's breathing, for easier
performance of challenging tasks.

Press this button to stop the virtual patient's breathing, allowing
for easier performance of the educational/clinical task.
Automatic Airway labeling

Use the labels function to automatically display each bronchial segment name over the
main view. Two labeling conventions are available: descriptive-numeric and advanced-
numeric.

To automatically label airways:
1. Press the Labels PF Label | button. The two convention buttons are displayed.

LA LL
l l

ther Descriptive numeric il ,
2. Press either Descriptive numeric Ml or Advanced numeric ill.

surgicalscience Page 54


# Page 66

Chapter 7 
 BRONCH Mentor Display Modes
 
Page 55
 
The bronchial segment names, according to the selected labeling convention, are 
automatically displayed on the Main View inside the anatomy. 
Note: The Advanced numeric convention goes one level deeper within the bronchial tree, 
allowing the study of the bronchial anatomy at the RB1a, RB1b level. 
3.  Press again the Labels button to hide the Labels display. 
 
Figure 7-5: Labeled airways 
 
Transparency 
The transparency feature makes the airway wall transparent, revealing lymph nodes 
and vascular structures behind it. 
The transparency region is only visible when the scope is close to the immediate area 
of a lymph node. 
Note: This feature is only available in cases where lymph nodes can be sampled.  
To make an airway wall transparent: 
1.  Press the Transparency 
 button. 
2.  Advance the scope to the immediate area of a lymph node. 
The airway wall turns transparent revealing lymph nodes and vascular structures 
behind it. 


[TABLE]
| Chapter 7                           |                                                                                         | BRONCH Mentor Display Modes   |
|:------------------------------------|:----------------------------------------------------------------------------------------|:------------------------------|
|                                     | The bronchial segment names, according to the selected labeling convention, are         |                               |
|                                     | automatically displayed on the Main View inside the anatomy.                            |                               |
|                                     | Note:  The Advanced numeric convention goes one level deeper within the bronchial tree, |                               |
|                                     | allowing the study of the bronchial anatomy at the RB1a, RB1b level.                    |                               |
|                                     | 3.   Press again the Labels button to hide the Labels display.                          |                               |
| F                                   |                                                                                         |                               |
| i                                   |                                                                                         |                               |
| gure 7-5: Labeled airways           |                                                                                         |                               |
| Transparency                        |                                                                                         |                               |
|                                     | The transparency feature makes the airway wall transparent, revealing lymph nodes       |                               |
| and vascular structures behind it.  |                                                                                         |                               |
|                                     | The transparency region is only visible when the scope is close to the immediate area   |                               |
| of a lymph node.                    |                                                                                         |                               |
|                                     | Note:  This feature is only available in cases where lymph nodes can be sampled.        |                               |
| To make an airway wall transparent: |                                                                                         |                               |
| 1.   Press the Transparency         | button.                                                                                 |                               |
|                                     | 2.   Advance the scope to the immediate area of a lymph node.                           |                               |
|                                     | The airway wall turns transparent revealing lymph nodes and vascular structures         |                               |
| behind it.                          |                                                                                         |                               |
|                                     |                                                                                         | Page 55                       |

[OCR]
Chapter 7 BRONCH Mentor Display Modes

The bronchial segment names, according to the selected labeling convention, are
automatically displayed on the Main View inside the anatomy.

Note: The Advanced numeric convention goes one level deeper within the bronchial tree,
allowing the study of the bronchial anatomy at the RB1a, RB1b level.

3. Press again the Labels button to hide the Labels display.

00:05:20}

Figure 7-5: Labeled airways

Transparency

The transparency feature makes the airway wall transparent, revealing lymph nodes
and vascular structures behind it.

The transparency region is only visible when the scope is close to the immediate area
of a lymph node.

Note: This feature is only available in cases where lymph nodes can be sampled.

To make an airway wall transparent:

1. Press the Transparency button.
2. Advance the scope to the immediate area of a lymph node.

The airway wall turns transparent revealing lymph nodes and vascular structures
behind it.

surgicalscience Page 55


# Page 67

Chapter 7 
 BRONCH Mentor Display Modes
 
Page 56
 
 
Figure 7-6: Transparent wall revealing lymph nodes 
 
Tool panel ③ 
 
Figure 7-7: Tool panel 
Based on the tool selected in the tool menu after inserting a tool, the corresponding 
tool panel will appear. Control options and the tool states are indicated in the tool 
panel, per the active tool. Some of the tools can be virtually activated in addition to the 
manually activation option (using the master tool handle). 
Virtual Activation was designed to facilitate easy solo training. When activated, the 
virtual control of the tool overrides the master tool handle’s control. Tools can be 
virtually activated via the touch screen, foot switch, or scope’s buttons. For a detailed 
explanation, see Using the Virtual Activation feature on page 105. 


[TABLE]
| F                                                                                           |
| i                                                                                           |
| gure 7-7: Tool panel                                                                        |
|:--------------------------------------------------------------------------------------------|
| Based on the tool selected in the tool menu after inserting a tool, the corresponding       |
| tool panel will appear. Control options and the tool states are indicated in the tool       |
| panel, per the active tool. Some of the tools can be virtually activated in addition to the |
| manually activation option (using the master tool handle).                                  |
| Virtual Activation was designed to facilitate easy solo training. When activated, the       |
| virtual control of the tool overrides the master tool handle’s control. Tools can be        |
| virtually activated via the touch screen, foot switch, or scope’s buttons. For a detailed   |
| explanation, see Using the Virtual Activation feature on page 105.                          |

[OCR]
Chapter 7 BRONCH Mentor Display Modes

00:01:08]

Figure 7-6: Transparent wall revealing lymph nodes

Tool panel @)

Figure 7-7: Tool panel

Based on the tool selected in the tool menu after inserting a tool, the corresponding
tool panel will appear. Control options and the tool states are indicated in the tool
panel, per the active tool. Some of the tools can be virtually activated in addition to the
manually activation option (using the master tool handle).

Virtual Activation was designed to facilitate easy solo training. When activated, the
virtual control of the tool overrides the master tool handle’s control. Tools can be
virtually activated via the touch screen, foot switch, or scope’s buttons. For a detailed
explanation, see Using the Virtual Activation feature on page 105.

surgicalscience Page 56


# Page 68

Chapter 7 
 BRONCH Mentor Display Modes
 
Page 57
 
Complementary displays and their controls ④ 
There are two complementary display windows. Each of the windows allows you to 
select from several available displays.   
• 
3D Map – an external dynamic 3D visualization of the scope within the bronchial 
tree. For a detailed explanation, see 3D Map on page 58. 
• 
Anatomy atlas – a static display of the chest anatomy divided into layers of organs 
and anatomical structures. For a detailed explanation, see Anatomy atlas on page 
60. 
Note: For certain modules or cases an Enhanced 3D Map is available 
instead of the 3D Map, adding additional anatomic layers to the dynamic 
display of the 3D Map, such as the cardiovascular system or the lymph 
node stations. For a detailed explanation, see Enhanced 3D Map on page 
71. 
• 
Imaging results/CT Browser – shows relevant images for the virtual patient such as 
x-rays, CT scan slices and actual CT scans. For a detailed explanation, see 
Imaging results/CT browser on page 61. 


[TABLE]
| Complementary displays and their controls ④                                    |                                                                                     |
|:-------------------------------------------------------------------------------|:------------------------------------------------------------------------------------|
| There are two complementary display windows. Each of the windows allows you to |                                                                                     |
| select from several available displays.                                        |                                                                                     |
| •                                                                              | 3D Map – an external dynamic 3D visualization of the scope within the bronchial     |
|                                                                                | tree. For a detailed explanation, see 3D Map on page 58.                            |
| •                                                                              | Anatomy atlas – a static display of the chest anatomy divided into layers of organs |
|                                                                                | and anatomical structures. For a detailed explanation, see Anatomy atlas on page    |
|                                                                                | 60.                                                                                 |
|                                                                                | Note: For certain modules or cases an Enhanced 3D Map is available                  |

[TABLE]
| tree. For a detailed explanation, see 3D Map on page 58.                            |
|:------------------------------------------------------------------------------------|
| Anatomy atlas – a static display of the chest anatomy divided into layers of organs |
| and anatomical structures. For a detailed explanation, see Anatomy atlas on page    |
| Note: For certain modules or cases an Enhanced 3D Map is available                  |
| instead of the 3D Map, adding additional anatomic layers to the dynamic             |
| display of the 3D Map, such as the cardiovascular system or the lymph               |
| node stations. For a detailed explanation, see Enhanced 3D Map on page              |
| 71.                                                                                 |
| Imaging results/CT Browser – shows relevant images for the virtual patient such as  |

[OCR_TABLE]
Chapter 7

[OCR]
Chapter 7 BRONCH Mentor Display Modes

Complementary displays and their controls @

There are two complementary display windows. Each of the windows allows you to
select from several available displays.

e 3D Map - an external dynamic 3D visualization of the scope within the bronchial
tree. For a detailed explanation, see 3D Map on page 58.
e Anatomy atlas - a static display of the chest anatomy divided into layers of organs
and anatomical structures. For a detailed explanation, see Anatomy atlas on page
60.
Note: For certain modules or cases an Enhanced 3D Map is available
instead of the 3D Map, adding additional anatomic layers to the dynamic
display of the 3D Map, such as the cardiovascular system or the lymph
node stations. For a detailed explanation, see Enhanced 3D Map on page
71.
e Imaging results/CT Browser - shows relevant images for the virtual patient such as
x-rays, CT scan slices and actual CT scans. For a detailed explanation, see
Imaging results/CT browser on page 61.

surgicalscience Page 57


# Page 69

Chapter 7 
 BRONCH Mentor Display Modes
 
Page 58
 
Selecting display content 
To select display content: 
1.  Press the down 
 arrow in the top-left corner of the complementary display 
window.  
A drop-down list of options is displayed.  
2.  Select the desired display content or press Close to close the list without selecting 
new display content. 
 
Figure 7-8: Display content options 
Note: Once a complementary display is shown, its control options are displayed to its right. 
 
3D Map 
The dynamic 3D map shows an external view of the virtual patient’s anatomy, including 
dynamic physiology and the bronchoscope's location within the bronchial anatomy 
during the procedure. 


[TABLE]
| Chapter 7                                 | BRONCH Mentor Display Modes                                                                   |
|:------------------------------------------|:----------------------------------------------------------------------------------------------|
| Selecting display content                 |                                                                                               |
| To select display content:                |                                                                                               |
| 1.   Press the down                       | arrow in the top-left corner of the complementary display                                     |
| window.                                   |                                                                                               |
| A drop-down list of options is displayed. |                                                                                               |
|                                           | 2.   Select the desired display content or press Close to close the list without selecting    |
| new display content.                      |                                                                                               |
| F                                         |                                                                                               |
| i                                         |                                                                                               |
| gure 7-8: Display content options         |                                                                                               |
|                                           | Note:  Once a complementary display is shown, its control options are displayed to its right. |
| 3D Map                                    |                                                                                               |
|                                           | The dynamic 3D map shows an external view of the virtual patient’s anatomy, including         |
|                                           | dynamic physiology and the bronchoscope's location within the bronchial anatomy               |
| during the procedure.                     |                                                                                               |
|                                           | Page 58                                                                                       |

[OCR]
Chapter 7 BRONCH Mentor Display Modes

Selecting display content
To select display content:

1. Press the down wi arrow in the top-left corner of the complementary display
window.
A drop-down list of options is displayed.

2. Select the desired display content or press Close to close the list without selecting
new display content.

3D Map
Anatomy Atlas

Imaging Results

Figure 7-8: Display content options

Note: Once a complementary display is shown, its control options are displayed to its right.

3D Map

The dynamic 3D map shows an external view of the virtual patient’s anatomy, including
dynamic physiology and the bronchoscope's location within the bronchial anatomy
during the procedure.

surgicalscience Page 58


# Page 70

Chapter 7 
 BRONCH Mentor Display Modes
 
Page 59
 
 
Figure 7-9: 3D Map display 
Controlling the 3D Map view 
You can manipulate the 3D Map view using the touch screen:  
 To rotate: 
1.  Press the Rotate button to select. 
2.  Slide your finger in different directions on the screen to turn the anatomy 3-
dimentionally around that point. 
 To zoom: 
1.  Press the Zoom button to select. 
2.  Slide your finger up and down to zoom in and out. 
 To zoom a region: 
1.  Press the Window button to select. 
2.  Slide your finger to indicate the desired region for zooming within the 3D map. 
 To pan: 
1.  Press the Pan button to select. 
2.  Slide your finger on the screen to move the 3D map. 
 To reset: 
1.  Press the Reset button to reset the image to its default display. 


[TABLE]
| Chapter 7                             |                                                                                      | BRONCH Mentor Display Modes   |
|:--------------------------------------|:-------------------------------------------------------------------------------------|:------------------------------|
| F                                     | gure 7-9: 3D Map display                                                             |                               |
| i                                     |                                                                                      |                               |
| Controlling the 3D Map view           |                                                                                      |                               |
|                                       | You can manipulate the 3D Map view using the touch screen:                           |                               |
|                                       | To rotate:                                                                           |                               |
|                                       | 1.   Press the Rotate button to select.                                              |                               |
|                                       | 2.   Slide your finger in different directions on the screen to turn the anatomy 3-  |                               |
|                                       | dimentionally around that point.                                                     |                               |
|                                       | To zoom:                                                                             |                               |
| 1.   Press the Zoom button to select. |                                                                                      |                               |
|                                       | 2.   Slide your finger up and down to zoom in and out.                               |                               |
|                                       | To zoom a region:                                                                    |                               |
|                                       | 1.   Press the Window button to select.                                              |                               |
|                                       | 2.   Slide your finger to indicate the desired region for zooming within the 3D map. |                               |
|                                       | To pan:                                                                              |                               |
| 1.   Press the Pan button to select.  |                                                                                      |                               |
|                                       | 2.   Slide your finger on the screen to move the 3D map.                             |                               |
|                                       | To reset:                                                                            |                               |
|                                       | 1.   Press the Reset button to reset the image to its default display.               |                               |
|                                       |                                                                                      | Page 59                       |

[OCR]
Chapter 7 BRONCH Mentor Display Modes

Figure 7-9: 3D Map display

Controlling the 3D Map view

You can manipulate the 3D Map view using the touch screen:

To rotate:

1. Press the Rotate button to select.
2. Slide your finger in different directions on the screen to turn the anatomy 3-
dimentionally around that point.

s)
pe AT To 200m:

1. Press the Zoom button to select.
2. Slide your finger up and down to zoom in and out.

i f .
ER Window To zoom a region:

\
1. Press the Window button to select.
2. Slide your finger to indicate the desired region for zooming within the 3D map.

To pan:
1

. Press the Pan button to select.
2. Slide your finger on the screen to move the 3D map.

To reset:

1. Press the Reset button to reset the image to its default display.

surgicalscience Page 59


# Page 71

Chapter 7 
 BRONCH Mentor Display Modes
 
Page 60
 
 To invert the 3D Map: 
1.  Press the Inverse button to vertically flip the map. 
Note: In certain modules or cases, the 3D Map is more elaborated and includes blood vessels or 
lymph nodes. 
Anatomy atlas 
The anatomy atlas is a static display of the chest anatomy divided into layers of organs 
and anatomical structures. You can view all of the layers or filter out certain layers or 
even specific parts of a layer for your convenience. 
 
Figure 7-10: Anatomy atlas display 
The anatomy atlas can be manipulated using the same control buttons detailed in the 
Controlling the 3D Map view section on page 59.  
Filtering the anatomic layers 
To filter the anatomic layers: 
 The Filter button opens a selectable list of layers.  
 


[TABLE]
|                                                                                           | To invert the 3D Map:                                                                    |
|:------------------------------------------------------------------------------------------|:-----------------------------------------------------------------------------------------|
| 1.   Press the Inverse button to vertically flip the map.                                 |                                                                                          |
| Note:                                                                                     | In certain modules or cases, the 3D Map is more elaborated and includes blood vessels or |
|                                                                                           | lymph nodes.                                                                             |
| Anatomy atlas                                                                             |                                                                                          |
| The anatomy atlas is a static display of the chest anatomy divided into layers of organs  |                                                                                          |
| and anatomical structures. You can view all of the layers or filter out certain layers or |                                                                                          |
| even specific parts of a layer for your convenience.                                      |                                                                                          |

[OCR]
Chapter 7 BRONCH Mentor Display Modes

== Inverse

To invert the 3D Map:
1. Press the Inverse button to vertically flip the map.

Note: In certain modules or cases, the 3D Map is more elaborated and includes blood vessels or
lymph nodes.

Anatomy atlas

The anatomy atlas is a static display of the chest anatomy divided into layers of organs
and anatomical structures. You can view all of the layers or filter out certain layers or
even specific parts of a layer for your convenience.

Figure 7-10: Anatomy atlas display

The anatomy atlas can be manipulated using the same control buttons detailed in the
Controlling the 3D Map view section on page 59.

Filtering the anatomic layers
To filter the anatomic layers:

|
The Filter button opens a selectable list of layers.

surgicalscience Page 60


# Page 72

Chapter 7 
 BRONCH Mentor Display Modes
 
Page 61
 
 
 
Figure 7-11: Anatomy atlas filtering window 
• 
Select or clear the checkboxes in order to display layers or items within a layer.  
• 
Press the + or – signs to open or close a layer’s component list. 
• 
Select the All check box to select all the layers. 
• 
Select the None check box to select none the layers. 
• 
Select Close to close the layers list. 
Imaging results/CT browser 
The imaging results option shows clinically relevant images for the virtual patient such 
as X-rays, single slices from a CT scan, or an actual CT scan. 
 
Viewing the CT scan 
 
Use the buttons to the right of the display to select the 
plane. 


[TABLE]
|    | F                                                                                  |
|    | i                                                                                  |
|    | gure 7-11: Anatomy atlas filtering window                                          |
|:---|:-----------------------------------------------------------------------------------|
| •  | Select or clear the checkboxes in order to display layers or items within a layer. |
| •  | Press the + or – signs to open or close a layer’s component list.                  |
| •  | Select the All check box to select all the layers.                                 |
| •  | Select the None check box to select none the layers.                               |
| •  | Select Close to close the layers list.                                             |

[OCR]
Chapter 7

BRONCH Mentor Display Modes

Anatomy Atlas layers

© [Y Lymph nodes- 1ASLC
(M) 1, 1L - Highest mediastinal
[W 2k, 2 - Upper paratracheal
[W 4p, 4L - Lower paratracheal
[ 7-Subcarinal

10R, 10L - Hilar

(Y) 11Rs, 11Ri, 111 - Interlobar

(M 12k, 121 - Lobar

[i 13k, 13L - Segmental

© © Blood vessels
[

Heart

© (Y) Parenchyma
M Pleura
Bones

[ Diaphragm

{Y) Esophagus

Figure 7-11: Anatomy atlas filtering window

Imaging results/CT browser

Select or clear the checkboxes in order to display layers or items within a layer.
Press the + or - signs to open or close a layer’s component list.

Select the All check box to select all the layers.

Select the None check box to select none the layers.

Select Close to close the layers list.

The imaging results option shows clinically relevant images for the virtual patient such
as X-rays, single slices from a CT scan, or an actual CT scan.

Viewing the CT scan

Use the buttons to the right of the display to select the

plane.

surgicalscience

Page 61


# Page 73

Chapter 7 
 BRONCH Mentor Display Modes
 
Page 62
 
Browsing the CT slices  
To browse through CT slices: 
 Press inside the CT view window and drag up or down. 
Patient management region ⑥  
The patient management region incorporates patient monitoring and management that 
is complementary to the bronchoscopy procedure such as moderate sedation, 
consciousness and vital signs monitoring, oxygen administration. For a detailed 
explanation, see Virtual Patient Monitoring and Management on page 97. 
 
Real time guidance, warnings and alerts 
Virtual Instructor ⑤ 
The Virtual Instructor provides real-time warnings, comments, and recommendations 
regarding procedure performance efficiency as well as mild patient condition notices. 
The virtual instructor can be turned off or on using the virtual instructor button. 
The Virtual Instructor issues a warning each time performance is compromised, might 
lead to an unsafe situation, or might result in a clinical complication. The Virtual 
Instructor provides an alert explaining the problem and offering a solution. When the 
performance is corrected, or after several seconds, the warning disappear from the 
screen.  
 
Figure 7-12: Virtual instructor button ON with real time warning 
Real time alerts 
Real time alerts relate to patient safety and are issued when patient safety might be 
compromised due to sedation or procedure performance.  
The real time alerts appear in the main bronchoscopy view and are displayed 
regardless of the virtual instructor on-off state. 


[TABLE]
| Chapter 7                                                                       | BRONCH Mentor Display Modes                                                       |
|:--------------------------------------------------------------------------------|:----------------------------------------------------------------------------------|
| Browsing the CT slices                                                          |                                                                                   |
| To browse through CT slices:                                                    |                                                                                   |
| Press inside the CT view window and drag up or down.                            |                                                                                   |
| Patient management region ⑥                                                     |                                                                                   |
|                                                                                 | The patient management region incorporates patient monitoring and management that |
| is complementary to the bronchoscopy procedure such as moderate sedation,       |                                                                                   |
| consciousness and vital signs monitoring, oxygen administration. For a detailed |                                                                                   |
| explanation, see Virtual Patient Monitoring and Management on page 97.          |                                                                                   |

[OCR_TABLE]
Chapter 7

[OCR]
Chapter 7 BRONCH Mentor Display Modes

Browsing the CT slices

To browse through CT slices:
Press inside the CT view window and drag up or down.

Patient management region 6)

The patient management region incorporates patient monitoring and management that
is complementary to the bronchoscopy procedure such as moderate sedation,
consciousness and vital signs monitoring, oxygen administration. For a detailed
explanation, see Virtual Patient Monitoring and Management on page 97.

Real time guidance, warnings and alerts

Virtual Instructor G)

The Virtual Instructor provides real-time warnings, comments, and recommendations
regarding procedure performance efficiency as well as mild patient condition notices.
The virtual instructor can be turned off or on using the virtual instructor button.

The Virtual Instructor issues a warning each time performance is compromised, might
lead to an unsafe situation, or might result in a clinical complication. The Virtual
Instructor provides an alert explaining the problem and offering a solution. When the
performance is corrected, or after several seconds, the warning disappear from the
screen.

© Unrecovered SpO2 drop

Figure 7-12: Virtual instructor button ON with real time warning

Real time alerts

Real time alerts relate to patient safety and are issued when patient safety might be
compromised due to sedation or procedure performance.

The real time alerts appear in the main bronchoscopy view and are displayed
regardless of the virtual instructor on-off state.

surgicalscience Page 62


# Page 74

Chapter 7 
 BRONCH Mentor Display Modes
 
Page 63
 
 
Figure 7-13: Real time alert 
Note: The real time alerts, as well as the virtual instructor warnings, are not displayed when 
working in Full screen (Procedure Restricted) mode. 
 
Additional features 
Freeze 
Much like the Freeze feature in real bronchoscopes, pressing the F button on the 
scope freezes the main image and opens a small window with a live WLB/Video view. 
Pressing Freeze also saves a snapshot that can later be viewed in the performance 
section. Pressing Freeze the second time will release it and restore it to normal view. 
Note: This feature is also available in Full screen mode. 


[TABLE]
| Chapter 7                                                                                       | BRONCH Mentor Display Modes                                                             |
|:------------------------------------------------------------------------------------------------|:----------------------------------------------------------------------------------------|
| F                                                                                               |                                                                                         |
| i                                                                                               |                                                                                         |
| gure 7-13: Real time alert                                                                      |                                                                                         |
| Note:  The real time alerts, as well as the virtual instructor warnings, are not displayed when |                                                                                         |
| working in Full screen (Procedure Restricted) mode.                                             |                                                                                         |
| A                                                                                               |                                                                                         |
| dditional features                                                                              |                                                                                         |
| Freeze                                                                                          |                                                                                         |
| Much like the Freeze feature in real bronchoscopes, pressing the F button on the                |                                                                                         |
|                                                                                                 | scope freezes the main image and opens a small window with a live WLB/Video view.       |
| Pressing Freeze also saves a snapshot that can later be viewed in the performance               |                                                                                         |
|                                                                                                 | section. Pressing Freeze the second time will release it and restore it to normal view. |
| Note:  This feature is also available in Full screen mode.                                      |                                                                                         |
|                                                                                                 | Page 63                                                                                 |

[OCR]
Chapter 7 BRONCH Mentor Display Modes

Figure 7-13: Real time alert

Note: The real time alerts, as well as the virtual instructor warnings, are not displayed when
working in Full screen (Procedure Restricted) mode.

Additional features

Freeze

Much like the Freeze feature in real bronchoscopes, pressing the F button on the
scope freezes the main image and opens a small window with a live WLB/Video view.
Pressing Freeze also saves a snapshot that can later be viewed in the performance
section. Pressing Freeze the second time will release it and restore it to normal view.

Note: This feature is also available in Full screen mode.

surgicalscience Page 63


# Page 75

Chapter 7 
 BRONCH Mentor Display Modes
 
Page 64
 
 
Figure 7-14: Main view – freeze feature 
General buttons ⑦ 
The general buttons appear on the bottom right of the BRONCH Mentor simulator 
screen and include the following functions: 
 
The Mute button toggles sound on and off. 
 
The Case File button opens the current virtual patient’s 
case file.  
 
The Help button opens the online help (check its 
availability based on the software version). 
 
The Finish button ends the current simulation and 
returns to the previous screen or the performance 
section if the performance was saved. 
 


[TABLE]
| The general buttons appear on the bottom right of the BRONCH Mentor simulator   |
|:--------------------------------------------------------------------------------|
| screen and include the following functions:                                     |
| The Mute button toggles sound on and off.                                       |
| The Case File button opens the current virtual patient’s                        |
| case file.                                                                      |
| The Help button opens the online help (check its                                |
| availability based on the software version).                                    |
| The Finish button ends the current simulation and                               |
| returns to the previous screen or the performance                               |
| section if the performance was saved.                                           |

[OCR]
Chapter 7 BRONCH Mentor Display Modes

Figure 7-14: Main view — freeze feature

General buttons Y)

The general buttons appear on the bottom right of the BRONCH Mentor simulator
screen and include the following functions:

wa) The Mute button toggles sound on and off.

The Case File button opens the current virtual patient’s
case file.

The Help button opens the online help (check its
availability based on the software version).

The Finish button ends the current simulation and
returns to the previous screen or the performance
section if the performance was saved.

surgicalscience Page 64


# Page 76

Chapter 7 
 BRONCH Mentor Display Modes
 
Page 65
 
Screen layout - dual modality (WLB/Video, EBUS)  
 
Figure 7-15: Video Bronchoscopy and Endobronchial Ultrasound layout 
① Main View  
➁ Main View Options 
③ Tool Panel 
④ Complementary Displays 
⑤ Virtual Instructor 
⑥ Patient Management Region 
⑦ General Buttons  


[TABLE]
| Chapter 7                                                         | BRONCH Mentor Display Modes   |
|:------------------------------------------------------------------|:------------------------------|
| Screen layout - dual modality (WLB/Video, EBUS)                   |                               |
| F                                                                 |                               |
| i                                                                 |                               |
| gure 7-15: Video Bronchoscopy and Endobronchial Ultrasound layout |                               |
| ①  Main View                                                      |                               |
| ➁  Main View Options                                              |                               |
| ③  Tool Panel                                                     |                               |
| ④  Complementary Displays                                         |                               |
| ⑤  Virtual Instructor                                             |                               |
| ⑥  Patient Management Region                                      |                               |
| ⑦  General Buttons                                                |                               |
|                                                                   | Page 65                       |

[OCR]
Chapter 7 BRONCH Mentor Display Modes

Screen layout - dual modality (WLB/Video, EBUS)

Figure 7-15: Video Bronchoscopy and Endobronchial Ultrasound layout

@
@
®
@
13)
©
@

Main View

Main View Options

Tool Panel

Complementary Displays
Virtual Instructor

Patient Management Region
General Buttons

surgicalscience Page 65


# Page 77

Chapter 7 
 BRONCH Mentor Display Modes
 
Page 66
 
Features and educational aids - dual modality 
Main View ① 
 
Figure 7-16: Main View – bronchoscopic and EBUS display  
• 
The scope’s view is displayed upon starting; the ultrasound display appears when 
View US button is selected. 
• 
A small video display appears by default when the US is on. 
• 
The green dot next to the ultrasound slide signifies the needle entry point. 
• 
In the top right corner of the main view, the elapsed time indicator is displayed.  
Note: The endoscope used is a side-viewing scope, as in reality. 
Main View options ② 
 Stop Breathing – stop the virtual patient's breathing. For a detailed 
explanation, see Stop Breathing on page 54. 


[TABLE]
| F   | gure 7-16: Main View – bronchoscopic and EBUS display                              |
| i   |                                                                                    |
|:----|:-----------------------------------------------------------------------------------|
| •   | The scope’s view is displayed upon starting; the ultrasound display appears when   |
|     | View US button is selected.                                                        |
| •   | A small video display appears by default when the US is on.                        |
| •   | The green dot next to the ultrasound slide signifies the needle entry point.       |
| •   | In the top right corner of the main view, the elapsed time indicator is displayed. |

[OCR]
Chapter 7 BRONCH Mentor Display Modes

Features and educational aids - dual modality

Main View (1)

Figure 7-16: Main View - bronchoscopic and EBUS display

e The scope’s view is displayed upon starting; the ultrasound display appears when
View US button is selected.

e Asmall video display appears by default when the US is on.

e The green dot next to the ultrasound slide signifies the needle entry point.

e Inthe top right corner of the main view, the elapsed time indicator is displayed.

Note: The endoscope used is a side-viewing scope, as in reality.

Main View options 2)

EEE Stop Breathing - stop the virtual patient's breathing. For a detailed

explanation, see Stop Breathing on page 54.

surgicalscience Page 66


# Page 78

Chapter 7 
 BRONCH Mentor Display Modes
 
Page 67
 
 Full screen – enlarges the main view display and removes all the aids 
from the screen. For a detailed explanation, see Procedure Restricted display mode on 
page 80. 
 Displaying the ultrasound image 
In the EBUS module, the ultrasound image is displayed in the Main View. When the 
ultrasound is displayed, the scope’s WLB/Video appears by default in the upper left 
corner of the EBUS view.  
Note: The overlaid WLB/Video display can be hidden, as WLB/Video can also be displayed, upon 
selection, in the upper complementary display pane. 
To display the ultrasound image: 
1.  Press the View US button. 
The ultrasound image is displayed in the Main View, with an overlaid WLB/Video 
display. 
To hide the overlaid WLB/Video display: 
1.  Press the small round button in the upper left corner of the minimized WLB/Video 
view. 
 
 Balloon Simulation 
Adding a Balloon around the EBUS scope’s tip can be simulated, allowing for wall 
contact enhancement of the EBUS transducer. 
To simulate adding a balloon: 
Press the Balloon button. The simulated balloon around the scope’s tip appears 
already inflated. 


[TABLE]
| Chapter 7                               |                                                                                              | BRONCH Mentor Display Modes                                           |
|:----------------------------------------|:---------------------------------------------------------------------------------------------|:----------------------------------------------------------------------|
|                                         |                                                                                              | Full screen – enlarges the main view display and removes all the aids |
|                                         | from the screen. For a detailed explanation, see Procedure Restricted display mode on        |                                                                       |
| page 80.                                |                                                                                              |                                                                       |
|                                         | Displaying the ultrasound image                                                              |                                                                       |
|                                         | In the EBUS module, the ultrasound image is displayed in the Main View. When the             |                                                                       |
|                                         | ultrasound is displayed, the scope’s WLB/Video appears by default in the upper left          |                                                                       |
| corner of the EBUS view.                |                                                                                              |                                                                       |
|                                         | Note: The overlaid WLB/Video display can be hidden, as WLB/Video can also be displayed, upon |                                                                       |
|                                         | selection, in the upper complementary display pane.                                          |                                                                       |
| To display the ultrasound image:        |                                                                                              |                                                                       |
| 1.   Press the View US button.          |                                                                                              |                                                                       |
|                                         | The ultrasound image is displayed in the Main View, with an overlaid WLB/Video               |                                                                       |
| display.                                |                                                                                              |                                                                       |
| To hide the overlaid WLB/Video display: |                                                                                              |                                                                       |
|                                         | 1.   Press the small round button in the upper left corner of the minimized WLB/Video        |                                                                       |
| view.                                   |                                                                                              |                                                                       |
|                                         | Balloon Simulation                                                                           |                                                                       |
|                                         | Adding a Balloon around the EBUS scope’s tip can be simulated, allowing for wall             |                                                                       |
|                                         | contact enhancement of the EBUS transducer.                                                  |                                                                       |
| To simulate adding a balloon:           |                                                                                              |                                                                       |
|                                         | Press the Balloon button. The simulated balloon around the scope’s tip appears               |                                                                       |
| already inflated.                       |                                                                                              |                                                                       |
|                                         |                                                                                              | Page 67                                                               |

[OCR]
Chapter 7 BRONCH Mentor Display Modes

Full screen - enlarges the main view display and removes all the aids

from the screen. For a detailed explanation, see Procedure Restricted display mode on
page 80.

LA view 0s | Displaying the ultrasound image

In the EBUS module, the ultrasound image is displayed in the Main View. When the

ultrasound is displayed, the scope’s WLB/Video appears by default in the upper left
corner of the EBUS view.

Note: The overlaid WLB/Video display can be hidden, as WLB/Video can also be displayed, upon
selection, in the upper complementary display pane.

To display the ultrasound image:
1. Press the View US button.

The ultrasound image is displayed in the Main View, with an overlaid WLB/Video
display.

To hide the overlaid WLB/Video display:

1. Press the small round button in the upper left corner of the minimized WLB/Video
view.

Balloon Simulation

Adding a Balloon around the EBUS scope’s tip can be simulated, allowing for wall
contact enhancement of the EBUS transducer.

To simulate adding a balloon:

Press the Balloon button. The simulated balloon around the scope’s tip appears
already inflated.

surgicalscience Page 67


# Page 79

Chapter 7 
 BRONCH Mentor Display Modes
 
Page 68
 
 Automatic labeling 
To label anatomical structures and organs on the ultrasound display: 
1.  Press the Labels button. The Labeling feature is on. 
2.  Press inside the structure you wish to label on the ultrasound image. 
The label is displayed over the ultrasound image (and airway labels are also 
displayed over the WLB/Video). 
 
 
Figure 7-17: Labeled anatomical structures on the ultrasound display 
3.  Press the Labels button again. The labels function is off and labels are removed 
from the ultrasound image. 
Note: Labels will also be cleared whenever the structure they labeled moved from its labeled 
location.  
 


[TABLE]
| Chapter 7   |                                                                                               | BRONCH Mentor Display Modes   |
|:------------|:----------------------------------------------------------------------------------------------|:------------------------------|
|             | Automatic labeling                                                                            |                               |
|             | To label anatomical structures and organs on the ultrasound display:                          |                               |
|             | 1.   Press the Labels button. The Labeling feature is on.                                     |                               |
|             | 2.   Press inside the structure you wish to label on the ultrasound image.                    |                               |
|             | The label is displayed over the ultrasound image (and airway labels are also                  |                               |
|             | displayed over the WLB/Video).                                                                |                               |
| F           | gure 7-17: Labeled anatomical structures on the ultrasound display                            |                               |
| i           |                                                                                               |                               |
|             | 3.   Press the Labels button again. The labels function is off and labels are removed         |                               |
|             | from the ultrasound image.                                                                    |                               |
|             | Note:  Labels will also be cleared whenever the structure they labeled moved from its labeled |                               |
| location.   |                                                                                               |                               |
|             |                                                                                               | Page 68                       |

[OCR]
Chapter 7 BRONCH Mentor Display Modes

« label
Eee Automatic labeling

To label anatomical structures and organs on the ultrasound display:

1. Press the Labels button. The Labeling feature is on.
2. Press inside the structure you wish to label on the ultrasound image.

The label is displayed over the ultrasound image (and airway labels are also
displayed over the WLB/Video).

Figure 7-17: Labeled anatomical structures on the ultrasound display

3. Press the Labels button again. The labels function is off and labels are removed
from the ultrasound image.

Note: Labels will also be cleared whenever the structure they labeled moved from its labeled
location.

surgicalscience Page 68


# Page 80

Chapter 7 
 BRONCH Mentor Display Modes
 
Page 69
 
 Doppler  
A Doppler feature is available, coloring blood flow according to its angular relation to 
the ultrasound transducer. 
To use the Doppler feature: 
1.  Press the Doppler button.  
A region of interest marked by a green contour appears over the ultrasound image. 
 
Figure 7-18: Doppler region on ultrasound image 
2.  Press inside the Doppler region and drag to move it on the ultrasound image. 
3.  Press the Doppler button again to turn off the doppler function. 
Note: The doppler type simulated is power doppler, in which there is no color differentiation 
based on flow direction. 
 Rotate ultrasound 
The Rotate US button rotates the ultrasound view 90˚ clockwise each time the button 
is pressed. 


[TABLE]
| Chapter 7                      |                                                                                                | BRONCH Mentor Display Modes   |
|:-------------------------------|:-----------------------------------------------------------------------------------------------|:------------------------------|
|                                | Doppler                                                                                        |                               |
|                                | A Doppler feature is available, coloring blood flow according to its angular relation to       |                               |
| the ultrasound transducer.     |                                                                                                |                               |
| To use the Doppler feature:    |                                                                                                |                               |
| 1.   Press the Doppler button. |                                                                                                |                               |
|                                | A region of interest marked by a green contour appears over the ultrasound image.              |                               |
| F                              | gure 7-18: Doppler region on ultrasound image                                                  |                               |
| i                              |                                                                                                |                               |
|                                | 2.   Press inside the Doppler region and drag to move it on the ultrasound image.              |                               |
|                                | 3.   Press the Doppler button again to turn off the doppler function.                          |                               |
|                                | Note:  The doppler type simulated is power doppler, in which there is no color differentiation |                               |
|                                | based on flow direction.                                                                       |                               |
|                                | Rotate ultrasound                                                                              |                               |
|                                | The Rotate US button rotates the ultrasound view 90˚ clockwise each time the button            |                               |
| is pressed.                    |                                                                                                |                               |
|                                |                                                                                                | Page 69                       |

[OCR]
Chapter 7 BRONCH Mentor Display Modes

A Doppl
LE po ppier

A Doppler feature is available, coloring blood flow according to its angular relation to
the ultrasound transducer.

To use the Doppler feature:
1. Press the Doppler button.

A region of interest marked by a green contour appears over the ultrasound image.

Figure 7-18: Doppler region on ultrasound image

2. Press inside the Doppler region and drag to move it on the ultrasound image.
3. Press the Doppler button again to turn off the doppler function.

Note: The doppler type simulated is power doppler, in which there is no color differentiation
based on flow direction.

ay a C
Rotate ultrasound

The Rotate US button rotates the ultrasound view 90° clockwise each time the button
is pressed.

surgicalscience Page 69


# Page 81

Chapter 7 
 BRONCH Mentor Display Modes
 
Page 70
 
 
 Gain/Contrast 
The Gain/Contrast function allows for manual adjustment of the ultrasound image gain 
and contrast.  
1.  Press the Gain/Contrast button. 
2.  Touch the screen, inside the ultrasound image and drag to manually adjust. Drag 
horizontally to adjust the gain and vertically to adjust the contrast. 
3.  Press the Gain/Contrast button again to turn off the function. 
 
 Ultrasound depth 
The Depth button allows for selection of the desired ultrasound depth.  
1.  Press the Depth button. 
The depth selection control is displayed.  
 
2.  Use the arrows to select the desired depth. 
3.  Press the Depth button again to close the depth selection control. 
 Switch scope  
The Switch scope function switches the designated EBUS scope to a forward viewing 
bronchoscope, through which a radial EBUS probe can be inserted. The Switch scope 
button is enabled only when the scope is completely out.  
Note: The Switch scope function is available for Essential EBUS Task 1. 
 
Tool panel ③ 
The tool panel is displayed when there is an active tool in the simulation. Control 
options and the tool states are indicated in the tool panel, per the active tool.  


[TABLE]
| Gain/Contrast                                                                        |
|:-------------------------------------------------------------------------------------|
| The Gain/Contrast function allows for manual adjustment of the ultrasound image gain |
| and contrast.                                                                        |
| 1.   Press the Gain/Contrast button.                                                 |
| 2.   Touch the screen, inside the ultrasound image and drag to manually adjust. Drag |
| horizontally to adjust the gain and vertically to adjust the contrast.               |
| 3.   Press the Gain/Contrast button again to turn off the function.                  |

[OCR]
Chapter 7 BRONCH Mentor Display Modes

Gain/Contrast

The Gain/Contrast function allows for manual adjustment of the ultrasound image gain
and contrast.

1. Press the Gain/Contrast button.

2. Touch the screen, inside the ultrasound image and drag to manually adjust. Drag
horizontally to adjust the gain and vertically to adjust the contrast.

3. Press the Gain/Contrast button again to turn off the function.

WE Ultrasound depth

The Depth button allows for selection of the desired ultrasound depth.
1. Press the Depth button.

The depth selection control is displayed.

2. Use the arrows to select the desired depth.
3. Press the Depth button again to close the depth selection control.

Switch scope

The Switch scope function switches the designated EBUS scope to a forward viewing
bronchoscope, through which a radial EBUS probe can be inserted. The Switch scope
button is enabled only when the scope is completely out.

Note: The Switch scope function is available for Essential EBUS Task 1.

Tool panel @)

The tool panel is displayed when there is an active tool in the simulation. Control
options and the tool states are indicated in the tool panel, per the active tool.

surgicalscience Page 70


# Page 82

Chapter 7 
 BRONCH Mentor Display Modes
 
Page 71
 
EBUS Needle and Syringe are available while working with this display mode. For a 
detailed explanation about using the syringe, see Working with the syringe on page 
106. 
Note: The EBUS Needle is provided with the EBUS modules and is described in the 
corresponding Module Book. 
Complementary displays and their controls ④ 
There are two complementary display windows. Each of the windows allows you to 
select from several available displays that are relevant to the module or case you are 
practicing.   
Note: The availability of the following options is determined by the selected task or case. 
Bronchoscope video 
This selection will display the WLB/Video in the complementary display pane. Note that 
the WLB/Video content is available only for the upper complementary display.  
 
Enhanced 3D Map 
The Enhanced 3D Map is a dynamic 3D visualization of the scope within the bronchial 
anatomy, showing additional anatomic layers of the 3D Map (such as blood vessels 
and heart).  
Note: The scope’s ultrasound plane is also visible on the enhanced 3D Map. 


[TABLE]
| Chapter 7                                                                                    | BRONCH Mentor Display Modes                                                            |
|:---------------------------------------------------------------------------------------------|:---------------------------------------------------------------------------------------|
| EBUS Needle and Syringe are available while working with this display mode. For a            |                                                                                        |
| detailed explanation about using the syringe, see Working with the syringe on page           |                                                                                        |
| 106.                                                                                         |                                                                                        |
| Note:  The EBUS Needle is provided with the EBUS modules and is described in the             |                                                                                        |
| corresponding Module Book.                                                                   |                                                                                        |
| Complementary displays and their controls ④                                                  |                                                                                        |
| There are two complementary display windows. Each of the windows allows you to               |                                                                                        |
|                                                                                              | select from several available displays that are relevant to the module or case you are |
| practicing.                                                                                  |                                                                                        |
| Note:  The availability of the following options is determined by the selected task or case. |                                                                                        |
| Bronchoscope video                                                                           |                                                                                        |
|                                                                                              | This selection will display the WLB/Video in the complementary display pane. Note that |
| the WLB/Video content is available only for the upper complementary display.                 |                                                                                        |

[OCR]
Chapter 7 BRONCH Mentor Display Modes

EBUS Needle and Syringe are available while working with this display mode. For a
detailed explanation about using the syringe, see Working with the syringe on page
106.

Note: The EBUS Needle is provided with the EBUS modules and is described in the
corresponding Module Book.

Complementary displays and their controls (@)

There are two complementary display windows. Each of the windows allows you to
select from several available displays that are relevant to the module or case you are
practicing.

Note: The availability of the following options is determined by the selected task or case.

Bronchoscope video

This selection will display the WLB/Video in the complementary display pane. Note that
the WLB/Video content is available only for the upper complementary display.

Enhanced 3D Map

The Enhanced 3D Map is a dynamic 3D visualization of the scope within the bronchial
anatomy, showing additional anatomic layers of the 3D Map (such as blood vessels
and heart).

Note: The scope’s ultrasound plane is also visible on the enhanced 3D Map.

surgicalscience Page 71


# Page 83

Chapter 7 
 BRONCH Mentor Display Modes
 
Page 72
 
 
Figure 7-19: Enhanced 3D Map and its controls 
The view can be manipulated using the same control buttons detailed in the section 
Controlling the 3D Map view on page 59.  
Filtering 
You can view all the layers of the enhanced 3D map or filter them.  
For a detailed explanation on how to filter layers or parts of the enhanced 3D map, see 
Filtering the anatomic layers on page 60. 
 
Anatomy atlas  
This view shows a static 3D display of the chest anatomy divided into layers of organs 
and anatomical structures. For a detailed explanation, see Anatomy atlas on page 60. 
Imaging results/CT Browser 
This view shows relevant images for the virtual patient such as x-rays, CT scan slices 
or the actual CT scan. For a detailed explanation, see Imaging results/CT browser on 
page 61. 
A unique CT browser with slice selection option is available for certain tasks. For a 
detailed explanation, see Selectable CT browser on page 75.  


[TABLE]
| F                                                                                       |
| i                                                                                       |
| gure 7-19: Enhanced 3D Map and its controls                                             |
|:----------------------------------------------------------------------------------------|
| The view can be manipulated using the same control buttons detailed in the section      |
| Controlling the 3D Map view on page 59.                                                 |
| F                                                                                       |
| i                                                                                       |
| l                                                                                       |
| tering                                                                                  |
| You can view all the layers of the enhanced 3D map or filter them.                      |
| For a detailed explanation on how to filter layers or parts of the enhanced 3D map, see |
| Filtering the anatomic layers on page 60.                                               |
| Anatomy atlas                                                                           |
| This view shows a static 3D display of the chest anatomy divided into layers of organs  |
| and anatomical structures. For a detailed explanation, see Anatomy atlas on page 60.    |
| Imaging results/CT Browser                                                              |
| This view shows relevant images for the virtual patient such as x-rays, CT scan slices  |
| or the actual CT scan. For a detailed explanation, see Imaging results/CT browser on    |
| page 61.                                                                                |
| A unique CT browser with slice selection option is available for certain tasks. For a   |
| detailed explanation, see Selectable CT browser on page 75.                             |

[OCR]
Chapter 7 BRONCH Mentor Display Modes

TH Window
W Pan
) Reset

#4 Filter

Figure 7-19: Enhanced 3D Map and its controls

The view can be manipulated using the same control buttons detailed in the section
Controlling the 3D Map view on page 59.

Filtering
You can view all the layers of the enhanced 3D map or filter them.

For a detailed explanation on how to filter layers or parts of the enhanced 3D map, see
Filtering the anatomic layers on page 60.

Anatomy atlas

This view shows a static 3D display of the chest anatomy divided into layers of organs
and anatomical structures. For a detailed explanation, see Anatomy atlas on page 60.

Imaging results/CT Browser

This view shows relevant images for the virtual patient such as x-rays, CT scan slices
or the actual CT scan. For a detailed explanation, see Imaging results/CT browser on
page 61.

A unique CT browser with slice selection option is available for certain tasks. For a
detailed explanation, see Selectable CT browser on page 75.

surgicalscience Page 72


# Page 84

Chapter 7 
 BRONCH Mentor Display Modes
 
Page 73
 
Lymph Node Classification Map  
The lymph node map depicts the lymph node classification system according to the 
IASLC Map of 2009, to support learning and understanding the bronchial vascular-
nodal interrelationship. 
 
Figure 7-20: Lymph Node Classification Map 
Tutorial movies 
Tutorial video clips are available for some cases or tasks. 
There are two ways to play tutorial movies, based on the simulation environment: 
To display video clip through Complementary Displays selection: 
1.  Select Tutorial Video from the Complementary Display menu. 


[TABLE]
| Chapter 7                                                                        | BRONCH Mentor Display Modes   |
|:---------------------------------------------------------------------------------|:------------------------------|
| Lymph Node Classification Map                                                    |                               |
| The lymph node map depicts the lymph node classification system according to the |                               |
| IASLC Map of 2009, to support learning and understanding the bronchial vascular- |                               |
| nodal interrelationship.                                                         |                               |
| F                                                                                |                               |
| i                                                                                |                               |
| gure 7-20: Lymph Node Classification Map                                         |                               |
| Tutorial movies                                                                  |                               |
| Tutorial video clips are available for some cases or tasks.                      |                               |
| There are two ways to play tutorial movies, based on the simulation environment: |                               |
| To display video clip through Complementary Displays selection:                  |                               |
| 1.   Select Tutorial Video from the Complementary Display menu.                  |                               |
|                                                                                  | Page 73                       |

[OCR]
Chapter 7 BRONCH Mentor Display Modes

Lymph Node Classification Map

The lymph node map depicts the lymph node classification system according to the
IASLC Map of 2009, to support learning and understanding the bronchial vascular-
nodal interrelationship.

Figure 7-20: Lymph Node Classification Map

Tutorial movies
Tutorial video clips are available for some cases or tasks.
There are two ways to play tutorial movies, based on the simulation environment:

To display video clip through Complementary Displays selection:
1. Select Tutorial Video from the Complementary Display menu.

surgicalscience Page 73


# Page 85

Chapter 7 
 BRONCH Mentor Display Modes
 
Page 74
 
 
Figure 7-21: Tutorial movies ran from Complementary Display selection 
2.  Use the right-side buttons to: 
• 
Press Play on the side of the video screen to play the video clip after you have 
paused or stopped it. 
• 
Press Next to view the next video section or Previous to view the previous video 
section. 
3.  Use the buttons on the bottom of the video player to play/pause or stop the video 
clip. 
Note: Essential EBUS Task 1 is an example of a task in which running such video clips is 
optional. 
To display video clip from a Step-by-Step Instructions display: 
1.  Click the Video Clip 
 button on the bottom on the Instructions view to run the 
video. 
The video clip opens over the Step-by-Step instructions display. 


[TABLE]
| Chapter 7                                                                                 |
|  BRONCH Mentor Display Modes                                                              |
|:------------------------------------------------------------------------------------------|
| F                                                                                         |
| i                                                                                         |
| gure 7-21: Tutorial movies ran from Complementary Display selection                       |
| 2.   Use the right-side buttons to:                                                       |
| Press Play on the side of the video screen to play the video clip after you have          |
| •                                                                                         |
| paused or stopped it.                                                                     |
| Press Next to view the next video section or Previous to view the previous video          |
| •                                                                                         |
| section.                                                                                  |
| 3.   Use the buttons on the bottom of the video player to play/pause or stop the video    |
| clip.                                                                                     |
| Note:  Essential EBUS Task 1 is an example of a task in which running such video clips is |
| optional.                                                                                 |
| To display video clip from a Step-by-Step Instructions display:                           |
| 1.   Click the Video Clip                                                                 |
|  button on the bottom on the Instructions view to run the                                 |
| video.                                                                                    |
| The video clip opens over the Step-by-Step instructions display.                          |
| Page 74                                                                                   |

[OCR]
Chapter 7 BRONCH Mentor Display Modes

Figure 7-21: Tutorial movies ran from Complementary Display selection
2. Use the right-side buttons to:

e Press Play on the side of the video screen to play the video clip after you have
paused or stopped it.

e Press Next to view the next video section or Previous to view the previous video
section.

3. Use the buttons on the bottom of the video player to play/pause or stop the video
clip.

Note: Essential EBUS Task 1 is an example of a task in which running such video clips is
optional.

To display video clip from a Step-by-Step Instructions display:

1. Click the Video Clip 3 button on the bottom on the Instructions view to run the
video.

The video clip opens over the Step-by-Step instructions display.

surgicalscience Page 74


# Page 86

Chapter 7 
 BRONCH Mentor Display Modes
 
Page 75
 
 
Figure 7-22: Tutorial movies ran from Instructions display 
2.  Use the Play/Pause and Stop buttons on the bottom of the video player to start, 
stop, or pause the video clip. 
3.  Use the Close button at the top to close the video player. 
Note: Essential EBUS Task 3 is an example for running such a video tutorial. 
Unique task features – dual modality 
Selectable CT browser 
A unique CT browser with a slice selection option is available for certain tasks such as 
Essential EBUS Task 1 and Task 2. 
In addition to the regular CT browsing functionality, this display has a checkbox at the 
top of the CT view, allowing for selection of a single CT slice. 


[TABLE]
| F                                                                                        |
| i                                                                                        |
| gure 7-22: Tutorial movies ran from Instructions display                                 |
|:-----------------------------------------------------------------------------------------|
| 2.   Use the Play/Pause and Stop buttons on the bottom of the video player to start,     |
| stop, or pause the video clip.                                                           |
| 3.   Use the Close button at the top to close the video player.                          |
| Note:  Essential EBUS Task 3 is an example for running such a video tutorial.            |
| Unique task features – dual modality                                                     |
| Selectable CT browser                                                                    |
| A unique CT browser with a slice selection option is available for certain tasks such as |
| Essential EBUS Task 1 and Task 2.                                                        |
| In addition to the regular CT browsing functionality, this display has a checkbox at the |
| top of the CT view, allowing for selection of a single CT slice.                         |

[OCR]
Chapter 7 BRONCH Mentor Display Modes

Verify that
secure lock

Figure 7-22: Tutorial movies ran from Instructions display

2. Use the Play/Pause and Stop buttons on the bottom of the video player to start,
stop, or pause the video clip.
3. Use the Close button at the top to close the video player.

Note: Essential EBUS Task 3 is an example for running such a video tutorial.

Unique task features — dual modality

Selectable CT browser

A unique CT browser with a slice selection option is available for certain tasks such as
Essential EBUS Task 1 and Task 2.

In addition to the regular CT browsing functionality, this display has a checkbox at the
top of the CT view, allowing for selection of a single CT slice.

surgicalscience Page 75


# Page 87

Chapter 7 
 BRONCH Mentor Display Modes
 
Page 76
 
 
Figure 7-23: Selectable CT browser 
To select a CT slice: 
1.  Scroll the CT and find the desired CT slice, in any of the available CT planes. 
2.  Use the touch screen or the mouse to select the checkbox at the top right of the 
CT display, indicating that the currently displayed CT slice is your selection. 
Once you have marked the checkbox selecting a certain slice, additional browsing 
is optional and will not override the selected slice. In order to change the CT slice 
selection, select the checkbox when the newly desired slice is displayed. 
Landmark list 
The Landmark List display is available for certain tasks such as Essential EBUS Task 1 
and Task 2. 
The list is initially disabled and becomes enabled after freezing an image with the 
scope’s Freeze button.   


[TABLE]
| Chapter 7                                                                             | BRONCH Mentor Display Modes                                                            |
|:--------------------------------------------------------------------------------------|:---------------------------------------------------------------------------------------|
| F                                                                                     |                                                                                        |
| i                                                                                     |                                                                                        |
| gure 7-23: Selectable CT browser                                                      |                                                                                        |
| To select a CT slice:                                                                 |                                                                                        |
| 1.   Scroll the CT and find the desired CT slice, in any of the available CT planes.  |                                                                                        |
| 2.   Use the touch screen or the mouse to select the checkbox at the top right of the |                                                                                        |
|                                                                                       | CT display, indicating that the currently displayed CT slice is your selection.        |
|                                                                                       | Once you have marked the checkbox selecting a certain slice, additional browsing       |
|                                                                                       | is optional and will not override the selected slice. In order to change the CT slice  |
| selection, select the checkbox when the newly desired slice is displayed.             |                                                                                        |
| Landmark list                                                                         |                                                                                        |
|                                                                                       | The Landmark List display is available for certain tasks such as Essential EBUS Task 1 |
| and Task 2.                                                                           |                                                                                        |
| The list is initially disabled and becomes enabled after freezing an image with the   |                                                                                        |
| scope’s Freeze button.                                                                |                                                                                        |
|                                                                                       | Page 76                                                                                |

[OCR]
Chapter 7 BRONCH Mentor Display Modes

Figure 7-23: Selectable CT browser

To select a CT slice:

1. Scroll the CT and find the desired CT slice, in any of the available CT planes.

2. Use the touch screen or the mouse to select the checkbox at the top right of the
CT display, indicating that the currently displayed CT slice is your selection.

Once you have marked the checkbox selecting a certain slice, additional browsing
is optional and will not override the selected slice. In order to change the CT slice
selection, select the checkbox when the newly desired slice is displayed.

Landmark list

The Landmark List display is available for certain tasks such as Essential EBUS Task 1
and Task 2.

The list is initially disabled and becomes enabled after freezing an image with the
scope’s Freeze button.

surgicalscience Page 76


# Page 88

Chapter 7 
 BRONCH Mentor Display Modes
 
Page 77
 
 
Figure 7-24: Landmark list 
 
To select and save a landmark: 
1.  Use the touch screen or the mouse to select the desired landmark.  
Once you have selected a landmark and a CT slice (see Selectable CT browser on 
page 75), the Save button on the right becomes enabled. It allows you to save a 
landmark, consisting of an image, a landmark name and a CT slice.  
The Browse button on the right becomes enabled after you have saved one or 
more landmarks, allowing you to review and discard saved landmarks. 
For a detailed explanation, see Essential EBUS Module Book.  
Instructions, overviews and step-by-step instructions 
Different sorts of instructions and overviews can be displayed in the Complementary 
Display panes. The instruction or overview type is determined per the case or task you 
are running. 
An Overview includes text and images and can be browsed using the arrow at the 
bottom of the display.  


[TABLE]
| o select and save a landmark:                                                   |
|:--------------------------------------------------------------------------------|
| 1.   Use the touch screen or the mouse to select the desired landmark.          |
| Once you have selected a landmark and a CT slice (see Selectable CT browser on  |
| page 75), the Save button on the right becomes enabled. It allows you to save a |
| landmark, consisting of an image, a landmark name and a CT slice.               |
| The Browse button on the right becomes enabled after you have saved one or      |
| more landmarks, allowing you to review and discard saved landmarks.             |
| For a detailed explanation, see Essential EBUS Module Book.                     |

[OCR]
Chapter 7 BRONCH Mentor Display Modes

Landmark List

Figure 7-24: Landmark list

To select and save a landmark:
1. Use the touch screen or the mouse to select the desired landmark.
Once you have selected a landmark and a CT slice (see Selectable CT browser on

page 75), the Save button on the right becomes enabled. It allows you to save a
landmark, consisting of an image, a landmark name and a CT slice.

The Browse button on the right becomes enabled after you have saved one or
more landmarks, allowing you to review and discard saved landmarks.

For a detailed explanation, see Essential EBUS Module Book.

Instructions, overviews and step-by-step instructions

Different sorts of instructions and overviews can be displayed in the Complementary
Display panes. The instruction or overview type is determined per the case or task you
are running.

An Overview includes text and images and can be browsed using the arrow at the
bottom of the display.

surgicalscience Page 77


# Page 89

Chapter 7 
 BRONCH Mentor Display Modes
 
Page 78
 
 
Figure 7-25: An overview display 
Note: Overview instructions are available on Essential EBUS Task 3. 
A Step-by-Step is a dynamic, contextual, set of instructions that responds to user 
actions. For a detailed explanation, see Step-by-step instructions (Essential 
Bronchoscopy - Task 5) on page 95. 
 
Figure 7-26: Step-by-Step instructions display 
Note: Step-by-Step instructions are available on Essential EBUS Task 3. 


[TABLE]
| Chapter 7                                                                          | BRONCH Mentor Display Modes   |
|:-----------------------------------------------------------------------------------|:------------------------------|
| F                                                                                  |                               |
| i                                                                                  |                               |
| gure 7-25: An overview display                                                     |                               |
| Note:  Overview instructions are available on Essential EBUS Task 3.               |                               |
| A Step-by-Step is a dynamic, contextual, set of instructions that responds to user |                               |
| actions. For a detailed explanation, see Step-by-step instructions (Essential      |                               |
| Bronchoscopy - Task 5) on page 95.                                                 |                               |
| F                                                                                  |                               |
| i                                                                                  |                               |
| gure 7-26: Step-by-Step instructions display                                       |                               |
| Note:  Step-by-Step instructions are available on Essential EBUS Task 3.           |                               |
|                                                                                    | Page 78                       |

[OCR]
Chapter 7 BRONCH Mentor Display Modes

EBUS Need

so

. EBUS needle fixation to scope’s working channel

. Sheath length controls

n length is

Figure 7-25: An overview display

Note: Overview instructions are available on Essential EBUS Task 3.

A Step-by-Step is a dynamic, contextual, set of instructions that responds to user
actions. For a detailed explanation, see Step-by-step instructions (Essential
Bronchoscopy - Task 5) on page 95.

Navigate to the desired sampling location using the scope’s video.

Figure 7-26: Step-by-Step instructions display

Note: Step-by-Step instructions are available on Essential EBUS Task 3.

surgicalscience Page 78


# Page 90

Chapter 7 
 BRONCH Mentor Display Modes
 
Page 79
 
You can use the button at the bottom of the Step-by-Step instructions to run tutorial 
movies (see details in Tutorial movies on page 73). 
Immediate feedback  
Immediate performance feedback appears upon the completion of an instructed 
EBUS-TBNA sampling (i.e. fully extracting the EBUS needle from the scope’s working 
channel). Detailed performance information is shown to allow immediate self-
assessment and improvement in the sampling procedure. 
 
Figure 7-27: Immediate Feedback for EBUS-TBNA 
 
Note: Immediate Feedback is available on Essential EBUS Task 3. 
 
Virtual Instructor and real time warnings ⑤ 
The virtual instructor and real time warnings provide real-time warnings, comments, 
and recommendations regarding procedure performance efficiency as well as mild 
patient condition notices. For a detailed explanation, see Virtual Instructor ⑤ on page 
62. 
Patient safety alerts relate to patient safety and are issued when patient safety might 
be compromised due to sedation or procedure performance. For a detailed 
explanation, see Real time alerts on page 62. 


[TABLE]
| Chapter 7                                                                    | BRONCH Mentor Display Modes                                                           |
|:-----------------------------------------------------------------------------|:--------------------------------------------------------------------------------------|
|                                                                              | You can use the button at the bottom of the Step-by-Step instructions to run tutorial |
| movies (see details in Tutorial movies on page 73).                          |                                                                                       |
| Immediate feedback                                                           |                                                                                       |
| Immediate performance feedback appears upon the completion of an instructed  |                                                                                       |
|                                                                              | EBUS-TBNA sampling (i.e. fully extracting the EBUS needle from the scope’s working    |
| channel). Detailed performance information is shown to allow immediate self- |                                                                                       |
| assessment and improvement in the sampling procedure.                        |                                                                                       |

[OCR_TABLE]
RhAantoar 7

[OCR_TABLE]
HIIOS UIA

[OCR]
Chapter 7 BRONCH Mentor Display Modes

You can use the button at the bottom of the Step-by-Step instructions to run tutorial
movies (see details in Tutorial movies on page 73).

Immediate feedback

Immediate performance feedback appears upon the completion of an instructed
EBUS-TBNA sampling (i.e. fully extracting the EBUS needle from the scope’s working
channel). Detailed performance information is shown to allow immediate self-
assessment and improvement in the sampling procedure.

Sampling quality and efficacy

EBUS-TBNA sample number 2

Sample was obtained

LN Station 4L

Sheath length out of scope 5mm

Needle length used during sampling 14mm
Needle passes performed 4 times

Suction duration 0 sec

Maneuver performed correctly

Figure 7-27: Immediate Feedback for EBUS-TBNA

Note: Immediate Feedback is available on Essential EBUS Task 3.

Virtual Instructor and real time warnings G)

The virtual instructor and real time warnings provide real-time warnings, comments,
and recommendations regarding procedure performance efficiency as well as mild
patient condition notices. For a detailed explanation, see Virtual Instructor (5) on page
62.

Patient safety alerts relate to patient safety and are issued when patient safety might
be compromised due to sedation or procedure performance. For a detailed
explanation, see Real time alerts on page 62.

surgicalscience Page 79


# Page 91

Chapter 7 
 BRONCH Mentor Display Modes
 
Page 80
 
Patient management region ⑥  
The patient management region incorporates patient monitoring and management that 
is complementary to the bronchoscopy procedure such as moderate sedation, 
consciousness and vital signs monitoring, oxygen administration. For a detailed 
explanation, see Virtual Patient Monitoring and Management on page 97. 
Additional features 
Freeze – freezes the main view and opens a small window with a live view of the 
scope. For a detailed explanation, see Freeze on page 63. 
General buttons ⑦ 
For a detailed explanation about the different buttons, see General Buttons on page 
64. 
Procedure Restricted display mode  
The Procedure Restricted Display Mode or Full Screen mode takes after a real 
procedure clinical environment, where educational aids are not available. 
Note: This display mode is available only for virtual patient cases (i.e. simulated clinical 
procedures) and not for designated tasks. 
To display the Procedure Restricted Display Mode: 
 Press the Full Screen button. 
Press the Exit Full Screen button to switch back to enhanced simulation display mode. 
Simulation environment  
The Procedure Restricted Display Mode or Full Screen mode consists of a restricted 
simulation environment. There are no educational aids, or reduced physiology to make 
the simulated procedure easier to perform. The patient management components 
appear on the right and the active tool panel on the left. All patient monitoring and 
management options, including checking consciousness, are grouped in the patient 
management region, as elaborated below. 


[TABLE]
| Chapter 7                               |                                                                                               | BRONCH Mentor Display Modes   |
|:----------------------------------------|:----------------------------------------------------------------------------------------------|:------------------------------|
| Patient management region ⑥             |                                                                                               |                               |
|                                         | The patient management region incorporates patient monitoring and management that             |                               |
|                                         | is complementary to the bronchoscopy procedure such as moderate sedation,                     |                               |
|                                         | consciousness and vital signs monitoring, oxygen administration. For a detailed               |                               |
|                                         | explanation, see Virtual Patient Monitoring and Management on page 97.                        |                               |
| Additional features                     |                                                                                               |                               |
|                                         | Freeze – freezes the main view and opens a small window with a live view of the               |                               |
|                                         | scope. For a detailed explanation, see Freeze on page 63.                                     |                               |
| General buttons ⑦                       |                                                                                               |                               |
|                                         | For a detailed explanation about the different buttons, see General Buttons on page           |                               |
| 64.                                     |                                                                                               |                               |
|                                         | Procedure Restricted display mode                                                             |                               |
|                                         | The Procedure Restricted Display Mode or Full Screen mode takes after a real                  |                               |
|                                         | procedure clinical environment, where educational aids are not available.                     |                               |
|                                         | Note:  This display mode is available only for virtual patient cases (i.e. simulated clinical |                               |
|                                         | procedures) and not for designated tasks.                                                     |                               |
|                                         | To display the Procedure Restricted Display Mode:                                             |                               |
|                                         | Press the Full Screen button.                                                                 |                               |
|                                         | Press the Exit Full Screen button to switch back to enhanced simulation display mode.         |                               |
| Simulation environment                  |                                                                                               |                               |
|                                         | The Procedure Restricted Display Mode or Full Screen mode consists of a restricted            |                               |
|                                         | simulation environment. There are no educational aids, or reduced physiology to make          |                               |
|                                         | the simulated procedure easier to perform. The patient management components                  |                               |
|                                         | appear on the right and the active tool panel on the left. All patient monitoring and         |                               |
|                                         | management options, including checking consciousness, are grouped in the patient              |                               |
| management region, as elaborated below. |                                                                                               |                               |

[OCR_TABLE]
Is compien
consciouer

[OCR]
Chapter 7 BRONCH Mentor Display Modes

Patient management region ©

The patient management region incorporates patient monitoring and management that
is complementary to the bronchoscopy procedure such as moderate sedation,
consciousness and vital signs monitoring, oxygen administration. For a detailed
explanation, see Virtual Patient Monitoring and Management on page 97.

Additional features

Freeze - freezes the main view and opens a small window with a live view of the
scope. For a detailed explanation, see Freeze on page 63.

General buttons Y)

For a detailed explanation about the different buttons, see General Buttons on page
64.

Procedure Restricted display mode

The Procedure Restricted Display Mode or Full Screen mode takes after a real
procedure clinical environment, where educational aids are not available.

Note: This display mode is available only for virtual patient cases (i.e. simulated clinical
procedures) and not for designated tasks.

To display the Procedure Restricted Display Mode:

= 4
= full Screen Press the Full Screen button.

Press the Exit Full Screen button to switch back to enhanced simulation display mode.

Simulation environment

The Procedure Restricted Display Mode or Full Screen mode consists of a restricted
simulation environment. There are no educational aids, or reduced physiology to make
the simulated procedure easier to perform. The patient management components
appear on the right and the active tool panel on the left. All patient monitoring and
management options, including checking consciousness, are grouped in the patient
management region, as elaborated below.

surgicalscience Page 80


# Page 92

Chapter 7 
 BRONCH Mentor Display Modes
 
Page 81
 
Note: All the features that were cleared upon selecting the restricted display mode, will be 
restored upon returning to the enhanced display mode.  
Screen layout - single modality (WLB/Video) 
 
Figure 7-28: Full screen mode – single modality bronchoscopy 
① Main View  
➁ Tool Panel 
③ Vital Signs 
④ Moderate Sedation Administration 
⑤ Consciousness Level  
⑥ Oxygen Supplement  
⑦ Exit Full Screen Button 


[TABLE]
| Chapter 7                                                                                     | BRONCH Mentor Display Modes   |
|:----------------------------------------------------------------------------------------------|:------------------------------|
| Note:  All the features that were cleared upon selecting the restricted display mode, will be |                               |
| restored upon returning to the enhanced display mode.                                         |                               |
| Screen layout - single modality (WLB/Video)                                                   |                               |
| F                                                                                             |                               |
| i                                                                                             |                               |
| gure 7-28: Full screen mode – single modality bronchoscopy                                    |                               |
| ①  Main View                                                                                  |                               |
| ➁  Tool Panel                                                                                 |                               |
| ③  Vital Signs                                                                                |                               |
| ④  Moderate Sedation Administration                                                           |                               |
| ⑤  Consciousness Level                                                                        |                               |
| ⑥  Oxygen Supplement                                                                          |                               |
| ⑦  Exit Full Screen Button                                                                    |                               |
|                                                                                               | Page 81                       |

[OCR]
Chapter 7 BRONCH Mentor Display Modes

Note: All the features that were cleared upon selecting the restricted display mode, will be
restored upon returning to the enhanced display mode.

Screen layout - single modality (WLB/Video)

Figure 7-28: Full screen mode - single modality bronchoscopy

@
@
®
@
©
©
@

Main View

Tool Panel

Vital Signs

Moderate Sedation Administration
Consciousness Level

Oxygen Supplement

Exit Full Screen Button

surgicalscience Page 81


# Page 93

Chapter 7 
 BRONCH Mentor Display Modes
 
Page 82
 
Screen layout - dual modality (WLB/Video, EBUS) 
 
Figure 7-29: Procedure Restricted display mode – dual modality  
① Main View - EBUS 
➁ Overlaid WLB/Video  
③ Tool Panel 
④ Vital Signs  
⑤ Moderate Sedation  
⑥ Consciousness Level 
⑦ Oxygen Supplement   
⑧ Exit Full Screen Button 
Features 
Main View ①   
The Main View shows the currently active bronchoscope view, be it WLB/Video or 
EBUS. 


[TABLE]
| Chapter 7                                                                      | BRONCH Mentor Display Modes   |
|:-------------------------------------------------------------------------------|:------------------------------|
| Screen layout - dual modality (WLB/Video, EBUS)                                |                               |
| F                                                                              |                               |
| i                                                                              |                               |
| gure 7-29: Procedure Restricted display mode – dual modality                   |                               |
| ①  Main View - EBUS                                                            |                               |
| ➁  Overlaid WLB/Video                                                          |                               |
| ③  Tool Panel                                                                  |                               |
| ④  Vital Signs                                                                 |                               |
| ⑤  Moderate Sedation                                                           |                               |
| ⑥  Consciousness Level                                                         |                               |
| ⑦  Oxygen Supplement                                                           |                               |
| ⑧  Exit Full Screen Button                                                     |                               |
| Features                                                                       |                               |
| Main View ①                                                                    |                               |
| The Main View shows the currently active bronchoscope view, be it WLB/Video or |                               |
| EBUS.                                                                          |                               |
|                                                                                | Page 82                       |

[OCR]
Chapter 7 BRONCH Mentor Display Modes

Screen layout - dual modality (WLB/Video, EBUS)

Figure 7-29: Procedure Restricted display mode — dual modality
@
@
@
@
®
©
@

Features

Main View - EBUS
Overlaid WLB/Video
Tool Panel

Vital Signs

Moderate Sedation
Consciousness Level
Oxygen Supplement
Exit Full Screen Button

Main View (1)

The Main View shows the currently active bronchoscope view, be it WLB/Video or
EBUS.

surgicalscience Page 82


# Page 94

Chapter 7 
 BRONCH Mentor Display Modes
 
Page 83
 
Overlaid WLB/Video ②  
The Overlaid WLB\Video displays the WLB/Video view on the upper left, whenever the 
ultrasound view is the active one. 
Note: Unlike the enhanced display mode, the small WLB/Video display cannot be put off in the 
restricted display mode. 
Tool panel ③ 
The EBUS Needle and the syringe are used to simulate tools during the simulation.  
For a detailed explanation about using the syringe, see Working with the syringe on 
page 106. 
Note: The EBUS Needle is provided with the EBUS modules and is described in the 
corresponding Module Book. 
 
Patient management controls ④⑤⑥⑦ 
The patient management controls are displayed on the right side of the Main view. 
Press the arrow next to relevant control title to expand the control. 
• 
Vital Signs ④ – includes current patient Heart Rate, Blood Pressure, Respiratory 
Rate, and SpO2 as well as an ECG line. For a detailed explanation, see page 97. 
• 
Moderate Sedation ⑤ – Sedatives can be administered and are recorded in the 
sedatives list. For a detailed explanation, see page 98. 
• 
Consciousness Level ⑥ – Consciousness levels, according to the Ramsey scale, 
can be checked each time you expand this control, that will automatically close 
after a few seconds. For a detailed explanation, see page 98. 
• 
Oxygen Supplement ⑦ – The right and left arrows can be used to set the oxygen 
supplement flow rate. For a detailed explanation, see page 99. 
Exit Full Screen button ⑧ 
Press the Exit Full Screen button to return to the Enhanced Clinical Display Mode with 
all of its educational aids. 


[TABLE]
| Chapter 7                                                                           | BRONCH Mentor Display Modes                                                                   |
|:------------------------------------------------------------------------------------|:----------------------------------------------------------------------------------------------|
| Overlaid WLB/Video ②                                                                |                                                                                               |
|                                                                                     | The Overlaid WLB\Video displays the WLB/Video view on the upper left, whenever the            |
| ultrasound view is the active one.                                                  |                                                                                               |
|                                                                                     | Note:  Unlike the enhanced display mode, the small WLB/Video display cannot be put off in the |
| restricted display mode.                                                            |                                                                                               |
| Tool panel ③                                                                        |                                                                                               |
| The EBUS Needle and the syringe are used to simulate tools during the simulation.   |                                                                                               |
| For a detailed explanation about using the syringe, see Working with the syringe on |                                                                                               |
| page 106.                                                                           |                                                                                               |
| Note: The EBUS Needle is provided with the EBUS modules and is described in the     |                                                                                               |
| corresponding Module Book.                                                          |                                                                                               |

[TABLE]
|                                                                                   | atient management controls ④⑤⑥⑦                                                  |
|:----------------------------------------------------------------------------------|:---------------------------------------------------------------------------------|
| The patient management controls are displayed on the right side of the Main view. |                                                                                  |
| Press the arrow next to relevant control title to expand the control.             |                                                                                  |
| •                                                                                 | Vital Signs ④ – includes current patient Heart Rate, Blood Pressure, Respiratory |
|                                                                                   | Rate, and SpO2 as well as an ECG line. For a detailed explanation, see page 97.  |
| •                                                                                 | Moderate Sedation ⑤ – Sedatives can be administered and are recorded in the      |
|                                                                                   | sedatives list. For a detailed explanation, see page 98.                         |
| •                                                                                 | Consciousness Level ⑥ – Consciousness levels, according to the Ramsey scale,     |
|                                                                                   | can be checked each time you expand this control, that will automatically close  |
|                                                                                   | after a few seconds. For a detailed explanation, see page 98.                    |
| •                                                                                 | Oxygen Supplement ⑦ – The right and left arrows can be used to set the oxygen    |
|                                                                                   | supplement flow rate. For a detailed explanation, see page 99.                   |

[OCR_TABLE]
The Overle

[OCR]
Chapter 7 BRONCH Mentor Display Modes

Overlaid WLB/Video (2)

The Overlaid WLB\Video displays the WLB/Video view on the upper left, whenever the
ultrasound view is the active one.

Note: Unlike the enhanced display mode, the small WLB/Video display cannot be put off in the
restricted display mode.

Tool panel @)

The EBUS Needle and the syringe are used to simulate tools during the simulation.

For a detailed explanation about using the syringe, see Working with the syringe on
page 106.

Note: The EBUS Needle is provided with the EBUS modules and is described in the
corresponding Module Book.

Patient management controls 4X)

The patient management controls are displayed on the right side of the Main view.
Press the arrow next to relevant control title to expand the control.

¢ Vital Signs @ - includes current patient Heart Rate, Blood Pressure, Respiratory
Rate, and SpO2 as well as an ECG line. For a detailed explanation, see page 97.

¢ Moderate Sedation G) - Sedatives can be administered and are recorded in the
sedatives list. For a detailed explanation, see page 98.

¢ Consciousness Level @) - Consciousness levels, according to the Ramsey scale,
can be checked each time you expand this control, that will automatically close
after a few seconds. For a detailed explanation, see page 98.

¢ Oxygen Supplement (7) - The right and left arrows can be used to set the oxygen
supplement flow rate. For a detailed explanation, see page 99.

Exit Full Screen button

Press the Exit Full Screen button to return to the Enhanced Clinical Display Mode with
all of its educational aids.

surgicalscience Page 83


# Page 95

Chapter 7 
 BRONCH Mentor Display Modes
 
Page 84
 
Designated Tasks display mode  
There are Designated Tasks in different modules. As their purpose is focusing on 
designated skills or knowledge, their display mode offers at times additional options 
which will be described below.  
Simulation environment 
In general, the designated tasks simulation environment is a didactic focused 
environment with limited physiology. The availability of complementary displays 
content is configured per designated task.  
No full screen view option is available. These focused simulation environments are 
aimed at directing the trainee towards focusing on one task at a time and accelerating 
the learning process towards acquiring the required skills. 
Since the Essential Bronchoscopy Module is a module focusing solely on designated 
tasks, this module’s tasks are described below. 
Screen layout 
 
Figure 7-30: Designated Tasks Display Mode screen  


[TABLE]
| Chapter 7                                                                             | BRONCH Mentor Display Modes                                                            |
|:--------------------------------------------------------------------------------------|:---------------------------------------------------------------------------------------|
| Designated Tasks display mode                                                         |                                                                                        |
| There are Designated Tasks in different modules. As their purpose is focusing on      |                                                                                        |
| designated skills or knowledge, their display mode offers at times additional options |                                                                                        |
| which will be described below.                                                        |                                                                                        |
| Simulation environment                                                                |                                                                                        |
| In general, the designated tasks simulation environment is a didactic focused         |                                                                                        |
| environment with limited physiology. The availability of complementary displays       |                                                                                        |
| content is configured per designated task.                                            |                                                                                        |
| No full screen view option is available. These focused simulation environments are    |                                                                                        |
|                                                                                       | aimed at directing the trainee towards focusing on one task at a time and accelerating |
| the learning process towards acquiring the required skills.                           |                                                                                        |
| Since the Essential Bronchoscopy Module is a module focusing solely on designated     |                                                                                        |
| tasks, this module’s tasks are described below.                                       |                                                                                        |
| Screen layout                                                                         |                                                                                        |

[OCR]
Chapter 7 BRONCH Mentor Display Modes

Designated Tasks display mode

There are Designated Tasks in different modules. As their purpose is focusing on
designated skills or knowledge, their display mode offers at times additional options
which will be described below.

Simulation environment

In general, the designated tasks simulation environment is a didactic focused
environment with limited physiology. The availability of complementary displays
content is configured per designated task.

No full screen view option is available. These focused simulation environments are
aimed at directing the trainee towards focusing on one task at a time and accelerating
the learning process towards acquiring the required skills.

Since the Essential Bronchoscopy Module is a module focusing solely on designated
tasks, this module’s tasks are described below.

Screen layout

Figure 7-30: Designated Tasks Display Mode screen

surgicalscience Page 84


# Page 96

Chapter 7 
 BRONCH Mentor Display Modes
 
Page 85
 
The screen is divided into the following parts: 
① Main View  
➁ Main View Options 
③ Tool Panel  
④ Upper Complementary Display  
⑤ Complementary Display Controls 
⑥ Lower Complementary Display  
⑦ General Buttons  
Note: The above screen layout applies to all the Essential Bronchoscopy module tasks except 
Task 1 which is performed in a non-anatomical environment and has a different layout 
(see Cyberscopy navigation (Essential Bronchoscopy - Task 1) on page 87). 
General features and educational aids 
Main View ①  
The Main View  displays the real time WLB/Video view during the procedure you are 
performing. 
Main View options ②  
A number of features and educational aids are available in most of the tasks of the 
Designated Tasks Display Mode: 
• 
Compass – displays an anatomical compass over the WLB main view. For a 
detailed explanation, see Anatomy compass on page 54. 
• 
Automatic labels – labels each bronchial segment by name. For a detailed 
explanation, see Automatic Airway labeling on page 54. 
• 
Stop Breathing – stops the virtual patient's breathing. For a detailed explanation, 
see Stop Breathing on page 54. 
Tool panel ③  
Tool panel is mostly unavailable for tasks, except for tasks focusing on diagnostic 
maneuvers such as Essential Task 5. 
In that task the tool panels will work just as in the Enhanced Clinical Display Mode (for 
a detailed explanation, see Tool Panel on page 56). 
 


[TABLE]
| Chapter 7                                       | BRONCH Mentor Display Modes                                                                  |
|:------------------------------------------------|:---------------------------------------------------------------------------------------------|
| The screen is divided into the following parts: |                                                                                              |
| ①  Main View                                    |                                                                                              |
| ➁  Main View Options                            |                                                                                              |
| ③  Tool Panel                                   |                                                                                              |
| ④  Upper Complementary Display                  |                                                                                              |
| ⑤  Complementary Display Controls               |                                                                                              |
| ⑥  Lower Complementary Display                  |                                                                                              |
| ⑦  General Buttons                              |                                                                                              |
|                                                 | Note:  The above screen layout applies to all the Essential Bronchoscopy module tasks except |
|                                                 | Task 1 which is performed in a non-anatomical environment and has a different layout         |

[TABLE]
| Main View options ②                                                                 |                                                                                     |
|:------------------------------------------------------------------------------------|:------------------------------------------------------------------------------------|
| A number of features and educational aids are available in most of the tasks of the |                                                                                     |
| Designated Tasks Display Mode:                                                      |                                                                                     |
| •                                                                                   | Compass – displays an anatomical compass over the WLB main view. For a              |
|                                                                                     | detailed explanation, see Anatomy compass on page 54.                               |
| •                                                                                   | Automatic labels – labels each bronchial segment by name. For a detailed            |
|                                                                                     | explanation, see Automatic Airway labeling on page 54.                              |
| •                                                                                   | Stop Breathing – stops the virtual patient's breathing. For a detailed explanation, |
|                                                                                     | see Stop Breathing on page 54.                                                      |

[OCR_TABLE]
AU) IVICAITT V
@) Main \

[OCR]
Chapter 7 BRONCH Mentor Display Modes

The screen is divided into the following parts:
@ Main View

@ Main View Options

® Tool Panel

@ Upper Complementary Display

© Complementary Display Controls

© Lower Complementary Display

@ General Buttons

Note: The above screen layout applies to all the Essential Bronchoscopy module tasks except
Task 1 which is performed in a non-anatomical environment and has a different layout
(see Cyberscopy navigation (Essential Bronchoscopy - Task 1) on page 87).

General features and educational aids

Main View (1)

The Main View © displays the real time WLB/Video view during the procedure you are
performing.

Main View options 2)

A number of features and educational aids are available in most of the tasks of the
Designated Tasks Display Mode:

e¢ Compass - displays an anatomical compass over the WLB main view. For a
detailed explanation, see Anatomy compass on page 54.

e Automatic labels — labels each bronchial segment by name. For a detailed
explanation, see Automatic Airway labeling on page 54.

e Stop Breathing — stops the virtual patient's breathing. For a detailed explanation,

see Stop Breathing on page 54.
Tool panel @)

Tool panel is mostly unavailable for tasks, except for tasks focusing on diagnostic
maneuvers such as Essential Task 5.

In that task the tool panels will work just as in the Enhanced Clinical Display Mode (for
a detailed explanation, see Tool Panel on page 56).

surgicalscience Page 85


# Page 97

Chapter 7 
 BRONCH Mentor Display Modes
 
Page 86
 
Complementary displays ④⑥ 
There are two display panes which complement the main view. Controls for each 
display are located to the right of each pane. 
Note: The availability of complementary displays may change per each module or task.  
• 
3D Map – an external dynamic 3D visualization of the scope within the bronchial 
tree. For a detailed explanation, see 3D Map on page 58. The Enhanced 3D Map is 
a 3D Map enhanced with additional anatomic layers (such as blood vessels, heart, 
lymph nodes). For a detailed explanation, see Enhanced 3D Map (Essential 
Bronchoscopy - Task 4) on page 94. 
• 
Instructions – for the selected task are displayed in the lower complementary 
display. 
 
 
Figure 7-31: Instructions display per task 
• 
Step-by-Step Instructions – contextual instructions (Task 5) are displayed in the 
lower complementary display. For a detailed explanation, see Step-by-step 
instructions (Essential Bronchoscopy - Task 5) on page 95. 
General buttons ⑦  
For a detailed explanation of the different buttons, see General buttons ⑦ on page 64. 


[TABLE]
| There are two display panes which complement the main view. Controls for each         |                                                                                  |
|:--------------------------------------------------------------------------------------|:---------------------------------------------------------------------------------|
| display are located to the right of each pane.                                        |                                                                                  |
| Note:  The availability of complementary displays may change per each module or task. |                                                                                  |
| •                                                                                     | 3D Map – an external dynamic 3D visualization of the scope within the bronchial  |
|                                                                                       | tree. For a detailed explanation, see 3D Map on page 58. The Enhanced 3D Map is  |
|                                                                                       | a 3D Map enhanced with additional anatomic layers (such as blood vessels, heart, |
|                                                                                       | lymph nodes). For a detailed explanation, see Enhanced 3D Map (Essential         |
|                                                                                       | Bronchoscopy - Task 4) on page 94.                                               |
| •                                                                                     | Instructions – for the selected task are displayed in the lower complementary    |
|                                                                                       | display.                                                                         |

[OCR_TABLE]
Chapter 7

[OCR]
Chapter 7 BRONCH Mentor Display Modes

Complementary displays 46)

There are two display panes which complement the main view. Controls for each
display are located to the right of each pane.

Note: The availability of complementary displays may change per each module or task.

e 3D Map - an external dynamic 3D visualization of the scope within the bronchial
tree. For a detailed explanation, see 3D Map on page 58. The Enhanced 3D Map is
a 3D Map enhanced with additional anatomic layers (such as blood vessels, heart,
lymph nodes). For a detailed explanation, see Enhanced 3D Map (Essential
Bronchoscopy - Task 4) on page 94.

e Instructions — for the selected task are displayed in the lower complementary
display.

gment by name: focus on
lect the correct name

e buttons (V- to browse,

ch (right to bro nd

left to select)

Figure 7-31: Instructions display per task

e Step-by-Step Instructions - contextual instructions (Task 5) are displayed in the
lower complementary display. For a detailed explanation, see Step-by-step
instructions (Essential Bronchoscopy - Task 5) on page 95.

General buttons Y)

For a detailed explanation of the different buttons, see General buttons (@) on page 64.

surgicalscience Page 86


# Page 98

Chapter 7 
 BRONCH Mentor Display Modes
 
Page 87
 
Unique task features 
Cyberscopy navigation (Essential Bronchoscopy - Task 1)  
This Cyberscopy task is designed for basic scope maneuvering training. The user is 
expected to navigate the scope following a ball in a certain route, while keeping the 
scope in the middle of the lumen and avoiding wall contact. 
 
Figure 7-32: Task 1 – Cyberscopy screen layout 
The screen is divided into the following parts: 
① Main View  
② Score Bar 
③ Immediate Performance Feedback  
④ Final Score 
⑤ General Buttons  
 
Main View ① - This is the bronchoscope view which you use to navigate following the 
ball down a narrowing lumen, until the end of the route. The route is selected randomly 
by the software each time you start a navigation.  
Note: If you lose the ball, you took a wrong turn; withdraw the scope until you find the ball. 


[TABLE]
| Chapter 7                                                                             | BRONCH Mentor Display Modes   |
|:--------------------------------------------------------------------------------------|:------------------------------|
| Unique task features                                                                  |                               |
| Cyberscopy navigation (Essential Bronchoscopy - Task 1)                               |                               |
| This Cyberscopy task is designed for basic scope maneuvering training. The user is    |                               |
| expected to navigate the scope following a ball in a certain route, while keeping the |                               |
| scope in the middle of the lumen and avoiding wall contact.                           |                               |

[OCR]
Chapter 7 BRONCH Mentor Display Modes

Unique task features

Cyberscopy navigation (Essential Bronchoscopy - Task 1)
This Cyberscopy task is designed for basic scope maneuvering training. The user is

expected to navigate the scope following a ball in a certain route, while keeping the
scope in the middle of the lumen and avoiding wall contact.

oT

eat 1 50%
4 Time in Contactwith Wall: 3%

Wall ontacs Distibutien
Wide umen:
Medion Lumen: 1

Figure 7-32: Task 1- Cyberscopy screen layout

The screen is divided into the following parts:
@ Main View

(2) Score Bar

(3) Immediate Performance Feedback

(4) Final Score

©) General Buttons

Main View (1) - This is the bronchoscope view which you use to navigate following the
ball down a narrowing lumen, until the end of the route. The route is selected randomly
by the software each time you start a navigation.

Note: If you lose the ball, you took a wrong turn; withdraw the scope until you find the ball.

surgicalscience Page 87


# Page 99

Chapter 7 
 BRONCH Mentor Display Modes
 
Page 88
 
Score Bar ② - When you start a navigation the score is a perfect 100. Each time you 
contact the wall, you lose points and the score bar is lowered.  
Immediate Performance Feedback ③ - Upon reaching route’s end, the final score is 
calculated and the relevant parameters and their values are displayed.  
Final Score ④ – The final score is set based on the following factors: time to complete 
navigation, number of wall hits per lumen width, percentage of the time scope was in 
mid-lumen, and percentage of the time scope was in contact with the wall. 
Note: The displayed navigation score will be cleared when you withdraw the scope to start 
another navigation. All navigation scores are saved when you save your performance. 
Directional guidance (Essential Bronchoscopy - Task 2) 
In this task, the user practices scope navigation within the anatomical environment. 
The user is expected to perform a complete airway inspection, using the directional 
guidance to demonstrate scope maneuvering ability for each carina. 
 
 - Directional guidance feature is active by default and a light 
bulb image appears in each carina upon scope approach. 
The scope camera is indicated by a negative of the same light bulb or “viewfinder”.  
The object of this task is to perform anatomical navigation maneuvers, aided by fitting 
the light bulb images through the negative “viewfinder”, using scope’s roll, flex and 
extend. The light bulb lights and chime is sounded once the maneuver was performed 
satisfactorily, or turns dark, when it was not. Multiple trials are optional until 
succeeding. 
   
 
Figure 7-33: Directional Guidance feature 


[TABLE]
| Chapter 7                                                                                  | BRONCH Mentor Display Modes                                                             |
|:-------------------------------------------------------------------------------------------|:----------------------------------------------------------------------------------------|
| Score Bar ➁ - When you start a navigation the score is a perfect 100. Each time you        |                                                                                         |
| contact the wall, you lose points and the score bar is lowered.                            |                                                                                         |
| Immediate Performance Feedback ③ - Upon reaching route’s end, the final score is           |                                                                                         |
| calculated and the relevant parameters and their values are displayed.                     |                                                                                         |
|                                                                                            | Final Score ④ – The final score is set based on the following factors: time to complete |
|                                                                                            | navigation, number of wall hits per lumen width, percentage of the time scope was in    |
| mid-lumen, and percentage of the time scope was in contact with the wall.                  |                                                                                         |
| Note:  The displayed navigation score will be cleared when you withdraw the scope to start |                                                                                         |
|                                                                                            | another navigation. All navigation scores are saved when you save your performance.     |
| Directional guidance (Essential Bronchoscopy - Task 2)                                     |                                                                                         |
| In this task, the user practices scope navigation within the anatomical environment.       |                                                                                         |
| The user is expected to perform a complete airway inspection, using the directional        |                                                                                         |
| guidance to demonstrate scope maneuvering ability for each carina.                         |                                                                                         |

[OCR_TABLE]
contact th

[OCR]
Chapter 7 BRONCH Mentor Display Modes

Score Bar (@) - When you start a navigation the score is a perfect 100. Each time you
contact the wall, you lose points and the score bar is lowered.

Immediate Performance Feedback (8) - Upon reaching route’s end, the final score is
calculated and the relevant parameters and their values are displayed.

Final Score (4) - The final score is set based on the following factors: time to complete
navigation, number of wall hits per lumen width, percentage of the time scope was in
mid-lumen, and percentage of the time scope was in contact with the wall.

Note: The displayed navigation score will be cleared when you withdraw the scope to start
another navigation. All navigation scores are saved when you save your performance.

Directional guidance (Essential Bronchoscopy - Task 2)

In this task, the user practices scope navigation within the anatomical environment.
The user is expected to perform a complete airway inspection, using the directional
guidance to demonstrate scope maneuvering ability for each carina.

im - Directional guidance feature is active by default and a light
bulb image appears in each carina upon scope approach.

The scope camera is indicated by a negative of the same light bulb or “viewfinder”.

The object of this task is to perform anatomical navigation maneuvers, aided by fitting
the light bulb images through the negative “viewfinder”, using scope’s roll, flex and
extend. The light bulb lights and chime is sounded once the maneuver was performed
satisfactorily, or turns dark, when it was not. Multiple trials are optional until
succeeding.

Figure 7-33: Directional Guidance feature

surgicalscience Page 88


# Page 100

Chapter 7 
 BRONCH Mentor Display Modes
 
Page 89
 
Manually labeling segments and lymph nodes (Essential Bronchoscopy - 
Task 3, Task 4) 
The purpose of Task 3 is to become familiar with the bronchial anatomy and to identify 
each bronchial segment by name, using one of two optional naming conventions. 
 
Figure 7-34: Task 3 – Bronchial segments recognition 
To manually label a bronchial segment (Task 3): 
1.  When the task begins, the following window is displayed.  
 
Figure 7-35: Naming convention selection 
2.  Select the naming convention you wish to use either Numeric Descriptive or 
Advanced Numeric and press Continue. 


[TABLE]
| Chapter 7                                                                       | BRONCH Mentor Display Modes                                                            |
|:--------------------------------------------------------------------------------|:---------------------------------------------------------------------------------------|
| Manually labeling segments and lymph nodes (Essential Bronchoscopy -            |                                                                                        |
| Task 3, Task 4)                                                                 |                                                                                        |
|                                                                                 | The purpose of Task 3 is to become familiar with the bronchial anatomy and to identify |
| each bronchial segment by name, using one of two optional naming conventions.   |                                                                                        |
| F                                                                               |                                                                                        |
| i                                                                               |                                                                                        |
| gure 7-34: Task 3 – Bronchial segments recognition                              |                                                                                        |
| To manually label a bronchial segment (Task 3):                                 |                                                                                        |
| 1.   When the task begins, the following window is displayed.                   |                                                                                        |
| F                                                                               |                                                                                        |
| i                                                                               |                                                                                        |
| gure 7-35: Naming convention selection                                          |                                                                                        |
| 2.   Select the naming convention you wish to use either Numeric Descriptive or |                                                                                        |
| Advanced Numeric and press Continue.                                            |                                                                                        |
|                                                                                 | Page 89                                                                                |

[OCR]
Chapter 7 BRONCH Mentor Display Modes

Manually labeling segments and lymph nodes (Essential Bronchoscopy -
Task 3, Task 4)

The purpose of Task 3 is to become familiar with the bronchial anatomy and to identify
each bronchial segment by name, using one of two optional naming conventions.

ue

immed
ia

it

RL

i

Ww

Figure 7-34: Task 3 — Bronchial segments recognition

To manually label a bronchial segment (Task 3):
1. When the task begins, the following window is displayed.

Select Naming Convention:

Numeric-Descriptive (RB1 apical) Advanced Numeric (RB1a, RB1b)

Continue

Figure 7-35: Naming convention selection

2. Select the naming convention you wish to use either Numeric Descriptive or
Advanced Numeric and press Continue.

surgical Page 89


# Page 101

Chapter 7 
 BRONCH Mentor Display Modes
 
Page 90
 
Note: The Advanced numeric convention goes one level deeper within the bronchial tree, 
allowing the study of the bronchial anatomy at the RB1a, RB1b level. 
3.  Focus the scope on a question mark by steadily centering it in the view from a 
certain distance.  
 
The question mark turns green and the list of lobes and bronchial segments is 
displayed. 
4.  Select the correct segment name from the list using the touch screen, scope 
buttons, or the foot switch: 
• 
Scope: Browse the list using the V button; select using the C button. 
• 
Foot switch: Use the Right foot switch to browse the list; use the Left foot 
switch to select. 
• 
Touch screen: Tap to select. 
Note: After naming a segment within a lobe and as long as the scope remains in the same lobe, 
the menu opens with the lobar submenu already opened. 
A correctly identified bronchial segment is labeled in light blue. A message is 
displayed when an incorrect option is selected, allowing for a total of three 
attempts. Upon the third incorrect identification, the software will automatically 
label the segment in gray.  


[TABLE]
| Chapter 7   |                                                                                                | BRONCH Mentor Display Modes                                                  |
|:------------|:-----------------------------------------------------------------------------------------------|:-----------------------------------------------------------------------------|
|             | Note:  The Advanced numeric convention goes one level deeper within the bronchial tree,        |                                                                              |
|             | allowing the study of the bronchial anatomy at the RB1a, RB1b level.                           |                                                                              |
|             | 3.   Focus the scope on a question mark by steadily centering it in the view from a            |                                                                              |
|             | certain distance.                                                                              |                                                                              |
|             | The question mark turns green and the list of lobes and bronchial segments is                  |                                                                              |
|             | displayed.                                                                                     |                                                                              |
|             | 4.   Select the correct segment name from the list using the touch screen, scope               |                                                                              |
|             | buttons, or the foot switch:                                                                   |                                                                              |
|             | •                                                                                              | Scope: Browse the list using the V button; select using the C button.        |
|             | •                                                                                              | Foot switch: Use the Right foot switch to browse the list; use the Left foot |
|             |                                                                                                | switch to select.                                                            |
|             | •                                                                                              | Touch screen: Tap to select.                                                 |
|             | Note:  After naming a segment within a lobe and as long as the scope remains in the same lobe, |                                                                              |
|             | the menu opens with the lobar submenu already opened.                                          |                                                                              |
|             | A correctly identified bronchial segment is labeled in light blue. A message is                |                                                                              |
|             | displayed when an incorrect option is selected, allowing for a total of three                  |                                                                              |
|             | attempts. Upon the third incorrect identification, the software will automatically             |                                                                              |
|             | label the segment in gray.                                                                     |                                                                              |
|             |                                                                                                | Page 90                                                                      |

[OCR_TABLE]
allow

[OCR_TABLE]
3. FOCUS

[OCR]
Chapter 7 BRONCH Mentor Display Modes

Note: The Advanced numeric convention goes one level deeper within the bronchial tree,
allowing the study of the bronchial anatomy at the RB1a, RB1b level.

3. Focus the scope on a question mark by steadily centering it in the view from a
certain distance.

Trachea

(MB
8 Intermediate
RUL
NL
RU
uu
ny

The question mark turns green and the list of lobes and bronchial segments is
displayed.

4. Select the correct segment name from the list using the touch screen, scope
buttons, or the foot switch:

Scope: Browse the list using the V button; select using the C button.
Foot switch: Use the Right foot switch to browse the list; use the Left foot
switch to select.

e Touch screen: Tap to select.

Note: After naming a segment within a lobe and as long as the scope remains in the same lobe,
the menu opens with the lobar submenu already opened.

A correctly identified bronchial segment is labeled in light blue. A message is
displayed when an incorrect option is selected, allowing for a total of three
attempts. Upon the third incorrect identification, the software will automatically
label the segment in gray.

surgicalscience Page 90


# Page 102

Chapter 7 
 BRONCH Mentor Display Modes
 
Page 91
 
 
Figure 7-36: Bronchial segments labeling indication 
The purpose of Task 4 is to become familiar with the adjoining lymph node stations 
and mediastinal vascular structures, under the IASLC map (2009). The user is 
expected to identify each lymph node station by name, after visualizing it through the 
bronchial airway wall. 
 
Figure 7-37: Task 4 – Lymph node stations recognition 


[TABLE]
| Chapter 7                                                                              | BRONCH Mentor Display Modes   |
|:---------------------------------------------------------------------------------------|:------------------------------|
| F                                                                                      |                               |
| i                                                                                      |                               |
| gure 7-36: Bronchial segments labeling indication                                      |                               |
| The purpose of Task 4 is to become familiar with the adjoining lymph node stations     |                               |
| and mediastinal vascular structures, under the IASLC map (2009). The user is           |                               |
| expected to identify each lymph node station by name, after visualizing it through the |                               |
| bronchial airway wall.                                                                 |                               |
| F                                                                                      |                               |
| i                                                                                      |                               |
| gure 7-37: Task 4 – Lymph node stations recognition                                    |                               |
|                                                                                        | Page 91                       |

[OCR]
Chapter 7 BRONCH Mentor Display Modes

Figure 7-36: Bronchial segments labeling indication

The purpose of Task 4 is to become familiar with the adjoining lymph node stations
and mediastinal vascular structures, under the IASLC map (2009). The user is
expected to identify each lymph node station by name, after visualizing it through the
bronchial airway wall.

Figure 7-37: Task 4- Lymph node stations recognition

surgical Page 91


# Page 103

Chapter 7 
 BRONCH Mentor Display Modes
 
Page 92
 
To label a lymph node (Task 4): 
Note: The lymph node station classification is according to the IASLC map (2009). 
1.  Focus the scope steadily, from a certain distance, on an arrow. The arrow performs 
an animation, following which the airway wall becomes transparent revealing the 
lymph node and the vascular structures behind it. 
 
 
Figure 7-38: Focusing on an arrow 
The lymph node selection menu is displayed, and the same lymph node that is 
viewed through the airway wall is highlighted blue in the 3D view and shown on 
the CT image. 


[TABLE]
| Chapter 7                                                                          | BRONCH Mentor Display Modes                                                             |
|:-----------------------------------------------------------------------------------|:----------------------------------------------------------------------------------------|
| To label a lymph node (Task 4):                                                    |                                                                                         |
| Note:  The lymph node station classification is according to the IASLC map (2009). |                                                                                         |
|                                                                                    | 1.   Focus the scope steadily, from a certain distance, on an arrow. The arrow performs |
|                                                                                    | an animation, following which the airway wall becomes transparent revealing the         |
| lymph node and the vascular structures behind it.                                  |                                                                                         |
| F                                                                                  |                                                                                         |
| i                                                                                  |                                                                                         |
| gure 7-38: Focusing on an arrow                                                    |                                                                                         |
|                                                                                    | The lymph node selection menu is displayed, and the same lymph node that is             |
|                                                                                    | viewed through the airway wall is highlighted blue in the 3D view and shown on          |
| the CT image.                                                                      |                                                                                         |
|                                                                                    | Page 92                                                                                 |

[OCR]
Chapter 7 BRONCH Mentor Display Modes

To label a lymph node (Task 4):

Note: The lymph node station classification is according to the IASLC map (2009).

1. Focus the scope steadily, from a certain distance, on an arrow. The arrow performs
an animation, following which the airway wall becomes transparent revealing the
lymph node and the vascular structures behind it.

Figure 7-38: Focusing on an arrow

The lymph node selection menu is displayed, and the same lymph node that is
viewed through the airway wall is highlighted blue in the 3D view and shown on
the CT image.

surgicalscience Page 92


# Page 104

Chapter 7 
 BRONCH Mentor Display Modes
 
Page 93
 
 
Figure 7-39: Labeling a lymph node 
2.  Browse and select the correct lymph node station using the touch screen, scope 
buttons, or the foot switch (to learn how, see page 90). 
Note: There may be multiple lymph nodes belonging to the same lymph node station. 
Correctly identified lymph node station labels are coloured bright green both in the 
bronchoscopic view and on the enhanced 3D Map.  
 
 
Figure 7-40: Lymph nodes identification indications 


[TABLE]
| Chapter 7                                                                           | BRONCH Mentor Display Modes                                                          |
|:------------------------------------------------------------------------------------|:-------------------------------------------------------------------------------------|
| F                                                                                   |                                                                                      |
| i                                                                                   |                                                                                      |
| gure 7-39: Labeling a lymph node                                                    |                                                                                      |
| 2.   Browse and select the correct lymph node station using the touch screen, scope |                                                                                      |
| buttons, or the foot switch (to learn how, see page 90).                            |                                                                                      |
| Note:  There may be multiple lymph nodes belonging to the same lymph node station.  |                                                                                      |
|                                                                                     | Correctly identified lymph node station labels are coloured bright green both in the |
| bronchoscopic view and on the enhanced 3D Map.                                      |                                                                                      |
| F                                                                                   |                                                                                      |
| i                                                                                   |                                                                                      |
| gure 7-40: Lymph nodes identification indications                                   |                                                                                      |
|                                                                                     | Page 93                                                                              |

[OCR]
Chapter 7 BRONCH Mentor Display Modes

Figure 7-39: Labeling a lymph node

2. Browse and select the correct lymph node station using the touch screen, scope
buttons, or the foot switch (to learn how, see page 90).

Note: There may be multiple lymph nodes belonging to the same lymph node station.

Correctly identified lymph node station labels are coloured bright green both in the
bronchoscopic view and on the enhanced 3D Map.

Figure 7-40: Lymph nodes identification indications

surgical Page 93


# Page 105

Chapter 7 
 BRONCH Mentor Display Modes
 
Page 94
 
Incorrect Labeling of Segments/Lymph Nodes  
You are allowed three attempts to identify a segment/lymph node; an incorrect 
identification message is prompted. After three incorrect attempts, the system 
automatically identifies the segment/lymph node with the correct name and colors it 
gray, both in the bronchoscopic view and on the enhanced 3D Map. 
To close the message:  
Press the OK button by tapping the touch screen, pressing the scope's C button or 
depressing the left foot switch.  
 
Note: Segments/lymph nodes identified, whether by the user or by the system, are disabled in 
the selection menu and skipped when browsing. 
Enhanced 3D Map (Essential Bronchoscopy - Task 4)  
The Enhanced 3D Map is an external dynamic display of bronchial anatomy with 
additional anatomic layers than the 3D Map, such as lymph nodes, blood vessels, and 
heart. 
 
Figure 7-41: Enhanced 3D Map - Task 4 
The view can be manipulated using the same control buttons detailed in the 3D Map 
section on page 58.  


[TABLE]
| Incorrect Labeling of Segments/Lymph Nodes                                                    |
|:----------------------------------------------------------------------------------------------|
| You are allowed three attempts to identify a segment/lymph node; an incorrect                 |
| identification message is prompted. After three incorrect attempts, the system                |
| automatically identifies the segment/lymph node with the correct name and colors it           |
| gray, both in the bronchoscopic view and on the enhanced 3D Map.                              |
| To close the message:                                                                         |
| Press the OK button by tapping the touch screen, pressing the scope's C button or             |
| depressing the left foot switch.                                                              |
| Note:  Segments/lymph nodes identified, whether by the user or by the system, are disabled in |
| the selection menu and skipped when browsing.                                                 |
| Enhanced 3D Map (Essential Bronchoscopy - Task 4)                                             |
| The Enhanced 3D Map is an external dynamic display of bronchial anatomy with                  |
| additional anatomic layers than the 3D Map, such as lymph nodes, blood vessels, and           |
| heart.                                                                                        |

[OCR]
Chapter 7 BRONCH Mentor Display Modes

Incorrect Labeling of Segments/Lymph Nodes

You are allowed three attempts to identify a segment/lymph node; an incorrect
identification message is prompted. After three incorrect attempts, the system
automatically identifies the segment/lymph node with the correct name and colors it
gray, both in the bronchoscopic view and on the enhanced 3D Map.

To close the message:

Press the OK button by tapping the touch screen, pressing the scope's C button or
depressing the left foot switch.

Note: Segments/lymph nodes identified, whether by the user or by the system, are disabled in
the selection menu and skipped when browsing.

Enhanced 3D Map (Essential Bronchoscopy - Task 4)

The Enhanced 3D Map is an external dynamic display of bronchial anatomy with
additional anatomic layers than the 3D Map, such as lymph nodes, blood vessels, and
heart.

Figure 7-41: Enhanced 3D Map - Task 4

The view can be manipulated using the same control buttons detailed in the 3D Map
section on page 58.

surgicalscience Page 94


# Page 106

Chapter 7 
 BRONCH Mentor Display Modes
 
Page 95
 
Filtering 
You can view all of the layers of the enhanced 3D map or filter out selected 
cardiovascular structures as with the Anatomy Atlas.  
For a detailed explanation how to filter layers, see Anatomy atlas on page 60. 
Step-by-step instructions (Essential Bronchoscopy - Task 5)  
Task 5 offers procedural training of common diagnostic maneuvers: forceps biopsy, 
cytology brushing and transbronchial needle aspiration. 
You are expected to follow the step-by-step instructions to obtain tissue samples from 
a defined region. Each sampling attempt is followed by immediate performance 
feedback about the quality and efficacy of the maneuver. 
 
Figure 7-42: Task 5 step by step diagnostic maneuvers 
The step-by-step instructions are based on the sampling tool selection and guide you 
through each diagnostic maneuver. The relevant step-by-step instructions, displayed 
in the lower complementary display, will progress with you as you sample.   


[TABLE]
| Chapter 7                                                                         | BRONCH Mentor Display Modes                                                            |
|:----------------------------------------------------------------------------------|:---------------------------------------------------------------------------------------|
| Filtering                                                                         |                                                                                        |
| You can view all of the layers of the enhanced 3D map or filter out selected      |                                                                                        |
| cardiovascular structures as with the Anatomy Atlas.                              |                                                                                        |
| For a detailed explanation how to filter layers, see Anatomy atlas on page 60.    |                                                                                        |
| Step-by-step instructions (Essential Bronchoscopy - Task 5)                       |                                                                                        |
| Task 5 offers procedural training of common diagnostic maneuvers: forceps biopsy, |                                                                                        |
| cytology brushing and transbronchial needle aspiration.                           |                                                                                        |
|                                                                                   | You are expected to follow the step-by-step instructions to obtain tissue samples from |
| a defined region. Each sampling attempt is followed by immediate performance      |                                                                                        |
| feedback about the quality and efficacy of the maneuver.                          |                                                                                        |

[OCR]
Chapter 7 BRONCH Mentor Display Modes

Filtering

You can view all of the layers of the enhanced 3D map or filter out selected
cardiovascular structures as with the Anatomy Atlas.

For a detailed explanation how to filter layers, see Anatomy atlas on page 60.

Step-by-step instructions (Essential Bronchoscopy - Task 5)

Task 5 offers procedural training of common diagnostic maneuvers: forceps biopsy,
cytology brushing and transbronchial needle aspiration.

You are expected to follow the step-by-step instructions to obtain tissue samples from
a defined region. Each sampling attempt is followed by immediate performance
feedback about the quality and efficacy of the maneuver.

Figure 7-42: Task 5 step by step diagnostic maneuvers

The step-by-step instructions are based on the sampling tool selection and guide you
through each diagnostic maneuver. The relevant step-by-step instructions, displayed
in the lower complementary display, will progress with you as you sample.

surgicalscience Page 95


# Page 107

Chapter 7 
 BRONCH Mentor Display Modes
 
Page 96
 
Immediate feedback (Essential Bronchoscopy - Task 5) 
Immediate performance feedback appears upon the completion of each diagnostic 
maneuver (i.e. fully extracting the endoscopic tool from the scope’s working channel). 
Detailed performance information is shown to allow immediate self-assessment and 
improvement in the use of the selected sampling tool. 
 
Figure 7-43: On-screen performance feedback 
Press the reel 
 button to play a tutorial video of the active tool (see detailed 
explanation on Tutorial movies on page 73).  


[TABLE]
| Chapter 7                                                                        | BRONCH Mentor Display Modes                                                            |
|:---------------------------------------------------------------------------------|:---------------------------------------------------------------------------------------|
| Immediate feedback (Essential Bronchoscopy - Task 5)                             |                                                                                        |
| Immediate performance feedback appears upon the completion of each diagnostic    |                                                                                        |
|                                                                                  | maneuver (i.e. fully extracting the endoscopic tool from the scope’s working channel). |
| Detailed performance information is shown to allow immediate self-assessment and |                                                                                        |
| improvement in the use of the selected sampling tool.                            |                                                                                        |

[OCR]
Chapter 7 BRONCH Mentor Display Modes

Immediate feedback (Essential Bronchoscopy - Task 5)

Immediate performance feedback appears upon the completion of each diagnostic
maneuver (i.e. fully extracting the endoscopic tool from the scope’s working channel).
Detailed performance information is shown to allow immediate self-assessment and
improvement in the use of the selected sampling tool.

Sampling quality and efficacy

Needle sample number 1

Sample was not achieved

Needle sample number 2

Sample was achieved

Sample depth range 2.49 to 13.00 mm
Suction duration 35 sec.

Incorrect performance of maneuver

Needle was uncovered while in working channel

Figure 7-43: On-screen performance feedback

Press the reel KE button to play a tutorial video of the active tool (see detailed
explanation on Tutorial movies on page 73).

surgicalscience Page 96


# Page 108

Chapter 8 
 Virtual Patient Monitoring and Management
 
Page 97
 
Chapter 8 Virtual Patient Monitoring and 
Management  
The BRONCH Mentor provides a complete patient environment, simulating a 
responsive virtual patient, including moderate sedation, oxygen supplement, altering 
consciousness level and vital signs, and respiratory or hemodynamic complications.  
Note: Some modules allow selecting between moderate sedation and general anesthesia, prior 
to starting the simulated case. 
Patient management region 
The patient management region consists of all the patient care elements that are part 
of the bronchoscopic procedure.  
 
Figure 8-1: Patient management region 
The Patient Management Region contains the following components: 
① Vital Signs – see page 97. 
➁ Consciousness Level – see page 98. 
③ Oxygen Supplement– see page 99. 
④ Moderate Sedation Administration – see page 99. 
⑤ Administered sedatives list  – see page 100.   
 
Vital signs monitoring  
① - The vital signs section includes current patient Heart Rate, Blood Pressure, 
Respiratory Rate, and SpO2 as well as an ECG line. 
The vital signs change based on the procedure performed, the way the user is 
performing it, virtual patient’s attributes, and certain random variants. 


[TABLE]
| Chapter 8                             |                                                                                             | Virtual Patient Monitoring and Management   |
|:--------------------------------------|:--------------------------------------------------------------------------------------------|:--------------------------------------------|
|                                       | Chapter 8  Virtual Patient Monitoring and                                                   |                                             |
|                                       | Management                                                                                  |                                             |
|                                       | The BRONCH Mentor provides a complete patient environment, simulating a                     |                                             |
|                                       | responsive virtual patient, including moderate sedation, oxygen supplement, altering        |                                             |
|                                       | consciousness level and vital signs, and respiratory or hemodynamic complications.          |                                             |
|                                       | Note:  Some modules allow selecting between moderate sedation and general anesthesia, prior |                                             |
|                                       | to starting the simulated case.                                                             |                                             |
|                                       | Patient management region                                                                   |                                             |
|                                       | The patient management region consists of all the patient care elements that are part       |                                             |
| of the bronchoscopic procedure.       |                                                                                             |                                             |
| F                                     |                                                                                             |                                             |
| i                                     |                                                                                             |                                             |
| gure 8-1: Patient management region   |                                                                                             |                                             |
|                                       | The Patient Management Region contains the following components:                            |                                             |
| ①  Vital Signs – see page 97.         |                                                                                             |                                             |
| ➁  Consciousness Level – see page 98. |                                                                                             |                                             |
| ③  Oxygen Supplement– see page 99.    |                                                                                             |                                             |
|                                       | ④  Moderate Sedation Administration – see page 99.                                          |                                             |
|                                       | ⑤  Administered sedatives list  – see page 100.                                             |                                             |
| Vital signs monitoring                |                                                                                             |                                             |
|                                       | ① - The vital signs section includes current patient Heart Rate, Blood Pressure,            |                                             |
|                                       | Respiratory Rate, and SpO2 as well as an ECG line.                                          |                                             |
|                                       | The vital signs change based on the procedure performed, the way the user is                |                                             |
|                                       | performing it, virtual patient’s attributes, and certain random variants.                   |                                             |
|                                       |                                                                                             | Page 97                                     |

[OCR]
Chapter 8 Virtual Patient Monitoring and Management

Chapter 8 Virtual Patient Monitoring and
Management

The BRONCH Mentor provides a complete patient environment, simulating a
responsive virtual patient, including moderate sedation, oxygen supplement, altering
consciousness level and vital signs, and respiratory or hemodynamic complications.

Note: Some modules allow selecting between moderate sedation and general anesthesia, prior
to starting the simulated case.

Patient management region

The patient management region consists of all the patient care elements that are part
of the bronchoscopic procedure.

Figure 8-1: Patient management region

The Patient Management Region contains the following components:
@ Vital Signs - see page 97.

@ Consciousness Level - see page 98.

@ Oxygen Supplement- see page 99.

@ Moderate Sedation Administration - see page 99.

© Administered sedatives list - see page 100.

Vital signs monitoring

@ - The vital signs section includes current patient Heart Rate, Blood Pressure,
Respiratory Rate, and SpO2 as well as an ECG line.

The vital signs change based on the procedure performed, the way the user is
performing it, virtual patient’s attributes, and certain random variants.

surgicalscience Page 97


# Page 109

Chapter 8 
 Virtual Patient Monitoring and Management
 
Page 98
 
When a vital sign deviates from its normal range, an exclamation mark will appear 
adjacent to the relevant vital sign requiring the user's attention.  
 
Figure 8-2: Vital signs deviation alert 
If not attended, the deviation might deteriorate into aggravating hemodynamic 
complications or respiratory depression events. 
Warnings will escalate accordingly, first to virtual instructor warnings and then to real 
time alerts regarding patient safety over the main bronchoscopy view (see Virtual 
Instructor on page 62 and Real time alerts on page 62). 
Note: Warnings will not appear when operating in Procedure Restricted Display Mode (i.e. full 
screen mode). 
Consciousness level monitoring  
② - Monitoring the consciousness level, according to the Ramsey scale, can be done 
by pressing the Consciousness button. The consciousness level is affected by the 
sedation administered as explained in Moderate sedation administration on page 99. 
Virtual patient’s susceptibility to sedation changes per virtual patient, but also within 
the same virtual patient. Each time the case is run, the virtual patient’s will be affected 
differently by same dosage of sedatives, thanks to an added random factor. 
 
Figure 8-3: Checking consciousness  
The consciousness levels are: 
1 - Anxious and agitated, or restless, or both 
2 - Cooperative, orientated, and tranquil 


[TABLE]
| Chapter 8                                                                                      | Virtual Patient Monitoring and Management                                                   |
|:-----------------------------------------------------------------------------------------------|:--------------------------------------------------------------------------------------------|
| When a vital sign deviates from its normal range, an exclamation mark will appear              |                                                                                             |
| adjacent to the relevant vital sign requiring the user's attention.                            |                                                                                             |
| F                                                                                              |                                                                                             |
| i                                                                                              |                                                                                             |
| gure 8-2: Vital signs deviation alert                                                          |                                                                                             |
| If not attended, the deviation might deteriorate into aggravating hemodynamic                  |                                                                                             |
| complications or respiratory depression events.                                                |                                                                                             |
| Warnings will escalate accordingly, first to virtual instructor warnings and then to real      |                                                                                             |
| time alerts regarding patient safety over the main bronchoscopy view (see Virtual              |                                                                                             |
| Instructor on page 62 and Real time alerts on page 62).                                        |                                                                                             |
| Note:  Warnings will not appear when operating in Procedure Restricted Display Mode (i.e. full |                                                                                             |
| screen mode).                                                                                  |                                                                                             |
| Consciousness level monitoring                                                                 |                                                                                             |
| ➁ - Monitoring the consciousness level, according to the Ramsey scale, can be done             |                                                                                             |
| by pressing the Consciousness button. The consciousness level is affected by the               |                                                                                             |
| sedation administered as explained in Moderate sedation administration on page 99.             |                                                                                             |
| Virtual patient’s susceptibility to sedation changes per virtual patient, but also within      |                                                                                             |
|                                                                                                | the same virtual patient. Each time the case is run, the virtual patient’s will be affected |
| differently by same dosage of sedatives, thanks to an added random factor.                     |                                                                                             |
| F                                                                                              |                                                                                             |
| i                                                                                              |                                                                                             |
| gure 8-3: Checking consciousness                                                               |                                                                                             |
| The consciousness levels are:                                                                  |                                                                                             |
| 1 - Anxious and agitated, or restless, or both                                                 |                                                                                             |
| 2 - Cooperative, orientated, and tranquil                                                      |                                                                                             |
|                                                                                                | Page 98                                                                                     |

[OCR_TABLE]
adjacent tc

[OCR]
Chapter 8 Virtual Patient Monitoring and Management

When a vital sign deviates from its normal range, an exclamation mark will appear
adjacent to the relevant vital sign requiring the user's attention.

Figure 8-2: Vital signs deviation alert

If not attended, the deviation might deteriorate into aggravating hemodynamic
complications or respiratory depression events.

Warnings will escalate accordingly, first to virtual instructor warnings and then to real
time alerts regarding patient safety over the main bronchoscopy view (see Virtual
Instructor on page 62 and Real time alerts on page 62).

Note: Warnings will not appear when operating in Procedure Restricted Display Mode (i.e. full
screen mode).

Consciousness level monitoring

@ - Monitoring the consciousness level, according to the Ramsey scale, can be done
by pressing the Consciousness button. The consciousness level is affected by the
sedation administered as explained in Moderate sedation administration on page 99.
Virtual patient’s susceptibility to sedation changes per virtual patient, but also within
the same virtual patient. Each time the case is run, the virtual patient’s will be affected
differently by same dosage of sedatives, thanks to an added random factor.

6 - No response to stimulus

Figure 8-3: Checking consciousness

The consciousness levels are:

1 - Anxious and agitated, or restless, or both
2 - Cooperative, orientated, and tranquil

surgicalscience Page 98


# Page 110

Chapter 8 
 Virtual Patient Monitoring and Management
 
Page 99
 
3 - Responds to commands only 
4 - Brisk response to tactile or loud auditory stimulus 
5 - Sluggish response to tactile or loud auditory stimulus 
6 - No response to stimulus 
Oxygen supplement  
③ - Administering oxygen supplement of up to 10 L/min is available, helping to keep 
the virtual patient's SpO2 within the desired range. 
To administrate oxygen: 
Use the right and left arrows to set the oxygen flow rate in units of liter per minute. 
Note: The simulated procedure starts without any Oxygen supplement. 
Moderate sedation administration 
④ - As moderate sedation is mostly an integral part of the bronchoscopy procedure, 
the BRONCH Mentor offers commonly used sedatives and their reversal agents to 
simulate this aspect of the bronchoscopy. However, under no circumstances should 
this be perceived as a course in moderate sedation.  
 
The sedatives and reversal agents available are: 
Group 
Sedative 
Reversal agent 
Benzodiazepines 
Midazolam 
Diazepam 
Flumazenil 
 
Narcotics 
Fentanyl 
Morphine Sulfate 
Meperidine 
Naloxone 
 
Other 
Propofol  
 
 


[TABLE]
| Chapter 8                                                                               | Virtual Patient Monitoring and Management                                           |
|:----------------------------------------------------------------------------------------|:------------------------------------------------------------------------------------|
| 3 - Responds to commands only                                                           |                                                                                     |
| 4 - Brisk response to tactile or loud auditory stimulus                                 |                                                                                     |
| 5 - Sluggish response to tactile or loud auditory stimulus                              |                                                                                     |
| 6 - No response to stimulus                                                             |                                                                                     |
| Oxygen supplement                                                                       |                                                                                     |
|                                                                                         | ③ - Administering oxygen supplement of up to 10 L/min is available, helping to keep |
| the virtual patient's SpO2 within the desired range.                                    |                                                                                     |
| To administrate oxygen:                                                                 |                                                                                     |
| Use the right and left arrows to set the oxygen flow rate in units of liter per minute. |                                                                                     |
| Note:  The simulated procedure starts without any Oxygen supplement.                    |                                                                                     |
| Moderate sedation administration                                                        |                                                                                     |
|                                                                                         | ④ - As moderate sedation is mostly an integral part of the bronchoscopy procedure,  |
| the BRONCH Mentor offers commonly used sedatives and their reversal agents to           |                                                                                     |
|                                                                                         | simulate this aspect of the bronchoscopy. However, under no circumstances should    |
| this be perceived as a course in moderate sedation.                                     |                                                                                     |

[TABLE]
| T   | he sedatives and reversal agents available are:   |                  |                |
|:----|:--------------------------------------------------|:-----------------|:---------------|
|     | Group                                             | Sedative         | Reversal agent |
|     | Benzodiazepines                                   | Midazolam        | Flumazenil     |
|     |                                                   | Diazepam         |                |
|     | Narcotics                                         | Fentanyl         | Naloxone       |
|     |                                                   | Morphine Sulfate |                |
|     |                                                   | Meperidine       |                |
|     | Other                                             | Propofol         |                |

[OCR_TABLE]
3 - Respor

[OCR]
Chapter 8 Virtual Patient Monitoring and Management

3 - Responds to commands only

4 - Brisk response to tactile or loud auditory stimulus

5 - Sluggish response to tactile or loud auditory stimulus
6 - No response to stimulus

Oxygen supplement

@® - Administering oxygen supplement of up to 10 L/min is available, helping to keep
the virtual patient's SpO2 within the desired range.

To administrate oxygen:
Use the right and left arrows to set the oxygen flow rate in units of liter per minute.

Note: The simulated procedure starts without any Oxygen supplement.

Moderate sedation administration

@ - As moderate sedation is mostly an integral part of the bronchoscopy procedure,
the BRONCH Mentor offers commonly used sedatives and their reversal agents to
simulate this aspect of the bronchoscopy. However, under no circumstances should
this be perceived as a course in moderate sedation.

The sedatives and reversal agents available are:

Group Sedative Reversal agent
Benzodiazepines Midazolam Flumazenil
Diazepam
Narcotics Fentanyl Naloxone
Morphine Sulfate
Meperidine
Other Propofol

surgicalscience Page 99


# Page 111

Chapter 8 
 Virtual Patient Monitoring and Management
 
Page 100
 
At the beginning of the procedure, the sedative list is available and the reversal agents 
are disabled. Once a sedative from a certain group is administered, the other sedatives 
of this group become disabled for the duration of the case run and the reversal agent 
for that group of sedatives is enabled.  
Once a reversal agent has been used, all sedatives become disabled. 
Propofol can be used as a third agent as long as the other two sedatives haven't 
exceeded a certain amount.  
 
Figure 8-4: Moderate sedation – sedative selection 
To administer sedation:  
1. Select the desired sedative from the list of available drugs. 
2. Use the Left and Right arrows if you wish to administer a different dosage. 
3. Press the syringe icon to administer the drug. 
Note: The drug affect much like in real life, will start affecting the virtual patient after the 
appropriate period of time. Such will be also the decay of its affect.  
4. Administered sedatives will appear in the Administered Sedatives list. 
Sedatives can also be administered prior to starting a simulated case, using the Pre-
Procedure options (see Pre-procedure options on page 50). Such sedatives will be 
considered as given two minutes before the simulation started. 
Administered sedatives list  
⑤ - The Administered Sedatives List displays the sedative name, dosage, time since 
the drug was administered, and the total dosage of each drug administered. 


[TABLE]
| Chapter 8                                                                        | Virtual Patient Monitoring and Management                                                 |
|:---------------------------------------------------------------------------------|:------------------------------------------------------------------------------------------|
|                                                                                  | At the beginning of the procedure, the sedative list is available and the reversal agents |
|                                                                                  | are disabled. Once a sedative from a certain group is administered, the other sedatives   |
|                                                                                  | of this group become disabled for the duration of the case run and the reversal agent     |
| for that group of sedatives is enabled.                                          |                                                                                           |
| Once a reversal agent has been used, all sedatives become disabled.              |                                                                                           |
| Propofol can be used as a third agent as long as the other two sedatives haven't |                                                                                           |
| exceeded a certain amount.                                                       |                                                                                           |

[OCR_TABLE]
AL UTE VE

en | fe

[OCR]
Chapter 8 Virtual Patient Monitoring and Management

At the beginning of the procedure, the sedative list is available and the reversal agents
are disabled. Once a sedative from a certain group is administered, the other sedatives
of this group become disabled for the duration of the case run and the reversal agent
for that group of sedatives is enabled.

Once a reversal agent has been used, all sedatives become disabled.

Propofol can be used as a third agent as long as the other two sedatives haven't
exceeded a certain amount.

Midazolam < > areal

Midazolam Dose TimeSince Total

Morphine Sulfate
Fentanyl
Diazepam

Meperidine

Figure 8-4: Moderate sedation — sedative selection

To administer sedation:

1. Select the desired sedative from the list of available drugs.

2. Use the Left and Right arrows if you wish to administer a different dosage.
3. Press the syringe icon to administer the drug.

Note: The drug affect much like in real life, will start affecting the virtual patient after the
appropriate period of time. Such will be also the decay of its affect.

4. Administered sedatives will appear in the Administered Sedatives list.

Sedatives can also be administered prior to starting a simulated case, using the Pre-
Procedure options (see Pre-procedure options on page 50). Such sedatives will be
considered as given two minutes before the simulation started.

Administered sedatives list

© - The Administered Sedatives List displays the sedative name, dosage, time since
the drug was administered, and the total dosage of each drug administered.

surgicalscience Page 100


# Page 112

Chapter 8 
 Virtual Patient Monitoring and Management
 
Page 101
 
 
Figure 8-5: Administered Sedatives list 
General anesthesia option 
In some of the modules, additional patient management regiments other than 
Moderate Sedation are optional.  
The selection, when available, is done in the Pre-Procedure stage, prior to starting the 
simulated procedure (for detailed explanation, see Pre-procedure options on page 50). 
Such an optional regiment is General Anesthesia with an ET Tube, or with a Rigid 
Scope. 
The selected Patient Management regiment is manifested on the Patient Management 
Region, the simulated case itself, and the captured performance metrics. 
 
Figure 8-6: General Anesthesia indication in Patient Management region 
Note: You will not deal with patient management, encounter cough, or encounter hemodynamic 
complications if you have selected the General Anesthesia option. 


[TABLE]
| F                                                                                        |
| i                                                                                        |
| gure 8-5: Administered Sedatives list                                                    |
|:-----------------------------------------------------------------------------------------|
| General anesthesia option                                                                |
| In some of the modules, additional patient management regiments other than               |
| Moderate Sedation are optional.                                                          |
| The selection, when available, is done in the Pre-Procedure stage, prior to starting the |
| simulated procedure (for detailed explanation, see Pre-procedure options on page 50).    |
| Such an optional regiment is General Anesthesia with an ET Tube, or with a Rigid         |
| Scope.                                                                                   |
| The selected Patient Management regiment is manifested on the Patient Management         |
| Region, the simulated case itself, and the captured performance metrics.                 |

[OCR]
Chapter 8 Virtual Patient Monitoring and Management

Midazolam

Figure 8-5: Administered Sedatives list

General anesthesia option

In some of the modules, additional patient management regiments other than
Moderate Sedation are optional.

The selection, when available, is done in the Pre-Procedure stage, prior to starting the
simulated procedure (for detailed explanation, see Pre-procedure options on page 50).
Such an optional regiment is General Anesthesia with an ET Tube, or with a Rigid
Scope.

The selected Patient Management regiment is manifested on the Patient Management
Region, the simulated case itself, and the captured performance metrics.

Patient is under General Anesthesia

Figure 8-6: General Anesthesia indication in Patient Management region

Note: You will not deal with patient management, encounter cough, or encounter hemodynamic
complications if you have selected the General Anesthesia option.

surgicalscience Page 101


# Page 113

Chapter 8 
 Virtual Patient Monitoring and Management
 
Page 102
 
 
Figure 8-7: Introducing the scope through an ET Tube 
 
 


[TABLE]
| Chapter 8                                          | Virtual Patient Monitoring and Management   |
|:---------------------------------------------------|:--------------------------------------------|
| F                                                  |                                             |
| i                                                  |                                             |
| gure 8-7: Introducing the scope through an ET Tube |                                             |
|                                                    | Page 102                                    |

[OCR]
Chapter 8 Virtual Patient Monitoring and Management

Figure 8-7: Introducing the scope through an ET Tube

surgicalscience Page 102


# Page 114

Chapter 9 
 Working with Auxiliary Tools
 
Page 103
 
Chapter 9 Working with Auxiliary Tools 
The BRONCH Mentor platform supports working with actual auxiliary tools through the 
scope working channel. Such auxiliary tools include the Syringe, the EBUS Needle, and 
the Master tool. The Master tool is used to simulate multiple tools during the 
simulation. For a detailed explanation on the Master Tool, see Master Tool on page 17. 
All the simulated bronchoscopic tools should be physically inserted into the working 
channel in order to become active in the simulation.   
Some simulated tools can also be activated virtually without using the handle. The 
virtual activation is designed to make solo training simpler and can be controlled using 
the touch screen, scope buttons, or foot switch. See more about Virtual Activation on 
page 105. 
Working with the Master Tool  
To select a tool: 
1.  Insert the master tool slowly into the working channel.  
The available Tools menu opens over the Main view.  
Note: The wire insertion required is much less than in a real procedure. Once introduced into 
the working channel, the simulated tool is considered as being almost out of the working 
channel’s distal end. 
2.  Press to select one of the tool types and open a submenu with the available tools 
for this tool type.  
3.  Use the scroll arrows to scroll the available options and select the tool you wish to 
use. 


[TABLE]
| Chapter 9                                                                                      | Working with Auxiliary Tools                                                             |
|:-----------------------------------------------------------------------------------------------|:-----------------------------------------------------------------------------------------|
| Chapter 9  Working with Auxiliary Tools                                                        |                                                                                          |
| The BRONCH Mentor platform supports working with actual auxiliary tools through the            |                                                                                          |
| scope working channel. Such auxiliary tools include the Syringe, the EBUS Needle, and          |                                                                                          |
| the Master tool. The Master tool is used to simulate multiple tools during the                 |                                                                                          |
| simulation. For a detailed explanation on the Master Tool, see Master Tool on page 17.         |                                                                                          |
| All the simulated bronchoscopic tools should be physically inserted into the working           |                                                                                          |
| channel in order to become active in the simulation.                                           |                                                                                          |
| Some simulated tools can also be activated virtually without using the handle. The             |                                                                                          |
| virtual activation is designed to make solo training simpler and can be controlled using       |                                                                                          |
| the touch screen, scope buttons, or foot switch. See more about Virtual Activation on          |                                                                                          |
| page 105.                                                                                      |                                                                                          |
| Working with the Master Tool                                                                   |                                                                                          |
| To select a tool:                                                                              |                                                                                          |
| 1.                                                                                             |                                                                                          |
| Insert the master tool slowly into the working channel.                                        |                                                                                          |
| The available Tools menu opens over the Main view.                                             |                                                                                          |
| Note:  The wire insertion required is much less than in a real procedure. Once introduced into |                                                                                          |
|                                                                                                | the working channel, the simulated tool is considered as being almost out of the working |
| channel’s distal end.                                                                          |                                                                                          |
| 2.   Press to select one of the tool types and open a submenu with the available tools         |                                                                                          |
| for this tool type.                                                                            |                                                                                          |
| 3.   Use the scroll arrows to scroll the available options and select the tool you wish to     |                                                                                          |
| use.                                                                                           |                                                                                          |

[OCR]
Chapter 9 Working with Auxiliary Tools

| Chapter 9 Working with Auxiliary Tools

The BRONCH Mentor platform supports working with actual auxiliary tools through the
scope working channel. Such auxiliary tools include the Syringe, the EBUS Needle, and
the Master tool. The Master tool is used to simulate multiple tools during the

simulation. For a detailed explanation on the Master Tool, see Master Tool on page 17.

All the simulated bronchoscopic tools should be physically inserted into the working
channel in order to become active in the simulation.

Some simulated tools can also be activated virtually without using the handle. The
virtual activation is designed to make solo training simpler and can be controlled using
the touch screen, scope buttons, or foot switch. See more about Virtual Activation on
page 105.

Working with the Master Tool

To select a tool:
1. Insert the master tool slowly into the working channel.

The available Tools menu opens over the Main view.

Note: The wire insertion required is much less than in a real procedure. Once introduced into
the working channel, the simulated tool is considered as being almost out of the working
channel's distal end.

2. Press to select one of the tool types and open a submenu with the available tools
for this tool type.

3. Use the scroll arrows to scroll the available options and select the tool you wish to
use.

surgicalscience Page 103


# Page 115

Chapter 9 
 Working with Auxiliary Tools
 
Page 104
 
 
Figure 9-1: Tool selection menu in Diagnostic Bronchoscopy  
Note: Inserting the wire into the working channel without selecting a tool from the menu results 
in the automatic selection of the last tool used, unless this is the first insertion of the tool; 
then you must select a tool. 
Based on the selection, the active tool appears in the simulation and its 
corresponding tool panel is displayed in the Tool Panel, to the left of the main view. 


[TABLE]
| Chapter 9                                                                                         |
|  Working with Auxiliary Tools                                                                     |
|:--------------------------------------------------------------------------------------------------|
| F                                                                                                 |
| i                                                                                                 |
| gure 9-1: Tool selection menu in Diagnostic Bronchoscopy                                          |
| Note:                                                                                             |
| Inserting the wire into the working channel without selecting a tool from the menu results        |
| in the automatic selection of the last tool used, unless this is the first insertion of the tool; |
| then you must select a tool.                                                                      |
| Based on the selection, the active tool appears in the simulation and its                         |
| corresponding tool panel is displayed in the Tool Panel, to the left of the main view.            |
| Page 104                                                                                          |

[OCR]
Chapter 9 Working with Auxiliary Tools

sh Aspiration Needle

Alligator ip

Figure 9-1: Tool selection menu in Diagnostic Bronchoscopy

Note: Inserting the wire into the working channel without selecting a tool from the menu results
in the automatic selection of the last tool used, unless this is the first insertion of the tool;
then you must select a tool.

Based on the selection, the active tool appears in the simulation and its
corresponding tool panel is displayed in the Tool Panel, to the left of the main view.

surgicalscience Page 104


# Page 116

Chapter 9 
 Working with Auxiliary Tools
 
Page 105
 
 
Figure 9-2: Selected tool active and its Tool panel displayed 
Note: Tool selection options may vary per module or case. 
 
To work with Master Tool handle: 
• 
Pull the Master Tool handle back to open, inflate, or fill the tool. 
• 
Push the Master Tool handle forward to close, deflate, or inject with the tool.  
To finish working with a selected tool or change your tool selection: 
1.  Remove the Master Tool from the working channel of the bronchoscope. 
2.  Upon reintroducing the Master Tool, you will again be prompted to select the 
endoscopic tool you wish to use. 
Using the Virtual Activation feature 
The tools simulated by the master tool can also be controlled virtually rather than 
physically working the master tool handle, given that the tool has several states that 
are controlled using the handle, such as brush, forceps, needle, etc. 


[TABLE]
| Chapter 9                                                                              |
|  Working with Auxiliary Tools                                                          |
|:---------------------------------------------------------------------------------------|
| F                                                                                      |
| i                                                                                      |
| gure 9-2: Selected tool active and its Tool panel displayed                            |
| Note:  Tool selection options may vary per module or case.                             |
| T                                                                                      |
| o work with Master Tool handle:                                                        |
| Pull the Master Tool handle back to open, inflate, or fill the tool.                   |
| •                                                                                      |
| Push the Master Tool handle forward to close, deflate, or inject with the tool.        |
| •                                                                                      |
| To finish working with a selected tool or change your tool selection:                  |
| 1.   Remove the Master Tool from the working channel of the bronchoscope.              |
| 2.   Upon reintroducing the Master Tool, you will again be prompted to select the      |
| endoscopic tool you wish to use.                                                       |
| Using the Virtual Activation feature                                                   |
| The tools simulated by the master tool can also be controlled virtually rather than    |
| physically working the master tool handle, given that the tool has several states that |
| are controlled using the handle, such as brush, forceps, needle, etc.                  |
| Page 105                                                                               |

[OCR]
Chapter 9 Working with Auxiliary Tools

00:02:59

Figure 9-2: Selected tool active and its Tool panel displayed

Note: Tool selection options may vary per module or case.

To work with Master Tool handle:

e Pull the Master Tool handle back to open, inflate, or fill the tool.
e Push the Master Tool handle forward to close, deflate, or inject with the tool.

To finish working with a selected tool or change your tool selection:

1. Remove the Master Tool from the working channel of the bronchoscope.

2. Upon reintroducing the Master Tool, you will again be prompted to select the
endoscopic tool you wish to use.

Using the Virtual Activation feature

The tools simulated by the master tool can also be controlled virtually rather than
physically working the master tool handle, given that the tool has several states that
are controlled using the handle, such as brush, forceps, needle, etc.

surgical Page 105


# Page 117

Chapter 9 
 Working with Auxiliary Tools
 
Page 106
 
 
 
To activate/deactivate the virtual activation feature: 
• 
Tap the Virtual Activation icon on the touch screen. 
• 
Press the V button on the scope. 
• 
Depress the Right Foot Switch. 
To control the selected tool state (open/close, in/out): 
• 
Tap the desired motion status on the touch screen. 
• 
Press the C button on the scope. 
• 
Depress the Left Foot Switch. 
Note: When virtual activation is on, the master tool handle is inactive.Turning the virtual 
activation off will return control to the master tool handle. 
Working with the syringe   
The syringe can be utilized for several purposes:  
• 
Administering fluids and drugs such as Saline, Lidocaine, or Epinephrine 
Endobronchially. 
• 
Retrieving saline administered during BAL performance. 
• 
Applying and releasing vacuum during needle aspiration procedures (see in 
Working with multiple tools on page 110). 
Administering fluids and drugs endobronchially 
To administer Saline, Lidocaine, or Epinephrine: 
1.  Insert the opened syringe into the scope’s working channel.  


[TABLE]
| To activate/deactivate the virtual activation feature:   |                                                      |
|:---------------------------------------------------------|:-----------------------------------------------------|
| •                                                        | Tap the Virtual Activation icon on the touch screen. |
| •                                                        | Press the V button on the scope.                     |
| •                                                        | Depress the Right Foot Switch.                       |
| To control the selected tool state (open/close, in/out): |                                                      |
| •                                                        | Tap the desired motion status on the touch screen.   |
| •                                                        | Press the C button on the scope.                     |
| •                                                        | Depress the Left Foot Switch.                        |

[TABLE]
| Working with the syringe                          |                                                                           |
|:--------------------------------------------------|:--------------------------------------------------------------------------|
| The syringe can be utilized for several purposes: |                                                                           |
| •                                                 | Administering fluids and drugs such as Saline, Lidocaine, or Epinephrine  |
|                                                   | Endobronchially.                                                          |
| •                                                 | Retrieving saline administered during BAL performance.                    |
| •                                                 | Applying and releasing vacuum during needle aspiration procedures (see in |
|                                                   | Working with multiple tools on page 110).                                 |

[OCR]
Chapter 9 Working with Auxiliary Tools

To activate/deactivate the virtual activation feature:
e Tap the Virtual Activation icon on the touch screen.
e Press the V button on the scope.
e Depress the Right Foot Switch.

To control the selected tool state (open/close, in/out):

e Tap the desired motion status on the touch screen.
e Press the C button on the scope.
e Depress the Left Foot Switch.

Note: When virtual activation is on, the master tool handle is inactive. Turning the virtual
activation off will return control to the master tool handle.

Working with the syringe

The syringe can be utilized for several purposes:

e Administering fluids and drugs such as Saline, Lidocaine, or Epinephrine
Endobronchially.

e Retrieving saline administered during BAL performance.

e Applying and releasing vacuum during needle aspiration procedures (see in
Working with multiple tools on page 110).

Administering fluids and drugs endobronchially

To administer Saline, Lidocaine, or Epinephrine:
1. Insert the opened syringe into the scope’s working channel.

surgicalscience Page 106


# Page 118

Chapter 9 
 Working with Auxiliary Tools
 
Page 107
 
The syringe tool panel opens. 
Note: The syringe needs to be open when inserted. 
 
 
Syringe tool panel – Lidocaine 
Syringe tool panel - Saline 
2.  From the fluids list, select the desired fluid or drug. 
3.  From the attribute list, select its attribute, such as concentration or temperature. 
4.  Use the dosage selection arrows to indicate the capacity of the filled syringe.  
Note: The same physical syringe simulates different size syringes, according to your dosage 
selection. The amount injected is calculated according to your choice of dosage/syringe 
size. 
5.  Inject using the syringe piston. Virtual activation is not available for the syringe. 
Note:  To administer a second dosage, remove the syringe, retract the piston (i.e. refill the 
syringe), and reinsert it into the scope’s working channel 
The syringe animation corresponds to the injection. Under the syringe image is a 
list of the total amount of administered fluids and drugs, as well as the total 
amount of retrieved saline. These values accumulate during case performance and 
are displayed each time the syringe is active. 


[TABLE]
| Chapter 9                                                                                     |
|  Working with Auxiliary Tools                                                                 |
|:----------------------------------------------------------------------------------------------|
| The syringe tool panel opens.                                                                 |
| Note:  The syringe needs to be open when inserted.                                            |
| Syringe tool panel – Lidocaine                                                                |
| Syringe tool panel - Saline                                                                   |
| 2.   From the fluids list, select the desired fluid or drug.                                  |
| 3.   From the attribute list, select its attribute, such as concentration or temperature.     |
| 4.   Use the dosage selection arrows to indicate the capacity of the filled syringe.          |
| Note:  The same physical syringe simulates different size syringes, according to your dosage  |
| selection. The amount injected is calculated according to your choice of dosage/syringe       |
| size.                                                                                         |
| 5.                                                                                            |
| Inject using the syringe piston. Virtual activation is not available for the syringe.         |
| Note:  To administer a second dosage, remove the syringe, retract the piston (i.e. refill the |
| syringe), and reinsert it into the scope’s working channel                                    |
| The syringe animation corresponds to the injection. Under the syringe image is a              |
| list of the total amount of administered fluids and drugs, as well as the total               |
| amount of retrieved saline. These values accumulate during case performance and               |
| are displayed each time the syringe is active.                                                |
| Page 107                                                                                      |

[OCR]
Chapter 9 Working with Auxiliary Tools

The syringe tool panel opens.

Note: The syringe needs to be open when inserted.

—_*

Lidocaine

Syringe tool panel - Lidocaine Syringe tool panel - Saline

2. From the fluids list, select the desired fluid or drug.
3. From the attribute list, select its attribute, such as concentration or temperature.
4. Use the dosage selection arrows to indicate the capacity of the filled syringe.

Note: The same physical syringe simulates different size syringes, according to your dosage
selection. The amount injected is calculated according to your choice of dosage/syringe
size.

5. Inject using the syringe piston. Virtual activation is not available for the syringe.

Note: To administer a second dosage, remove the syringe, retract the piston (i.e. refill the
syringe), and reinsert it into the scope’s working channel

The syringe animation corresponds to the injection. Under the syringe image is a
list of the total amount of administered fluids and drugs, as well as the total
amount of retrieved saline. These values accumulate during case performance and
are displayed each time the syringe is active.

surgicalscience Page 107


# Page 119

Chapter 9 
 Working with Auxiliary Tools
 
Page 108
 
Performing Bronchi Alveolar Lavage (BAL) 
When performing BAL, the syringe can be used for both instilling and retrieving the 
saline.  
To instil saline during BAL: 
1.  Wedge the scope in the desired airway. 
2.  Insert the opened syringe into the scope’s working channel, and selected Saline 
and BAL from the fluids and the attributes lists. 
3.  Use the dosage selection arrows if you wish to change the syringe size. Available 
syringe sizes for BAL are 20, 30, 40 and 50 cc. 
Note: In pediatric cases, the BAL doses, as well as all other doses (and their affect), are 
different. 
 
Figure 9-3: BAL tool panel 
4.  Instill the heated saline slowly and continuously using the syringe. 


[TABLE]
| Chapter 9                                                                              |
|  Working with Auxiliary Tools                                                          |
|:---------------------------------------------------------------------------------------|
| Performing Bronchi Alveolar Lavage (BAL)                                               |
| When performing BAL, the syringe can be used for both instilling and retrieving the    |
| saline.                                                                                |
| To instil saline during BAL:                                                           |
| 1.   Wedge the scope in the desired airway.                                            |
| 2.                                                                                     |
| Insert the opened syringe into the scope’s working channel, and selected Saline        |
| and BAL from the fluids and the attributes lists.                                      |
| 3.   Use the dosage selection arrows if you wish to change the syringe size. Available |
| syringe sizes for BAL are 20, 30, 40 and 50 cc.                                        |
| Note:                                                                                  |
| In pediatric cases, the BAL doses, as well as all other doses (and their affect), are  |
| different.                                                                             |

[OCR]
Chapter 9 Working with Auxiliary Tools

Performing Bronchi Alveolar Lavage (BAL)

When performing BAL, the syringe can be used for both instilling and retrieving the
saline.

To instil saline during BAL:

1. Wedge the scope in the desired airway.

2. Insert the opened syringe into the scope’s working channel, and selected Saline
and BAL from the fluids and the attributes lists.

3. Use the dosage selection arrows if you wish to change the syringe size. Available
syringe sizes for BAL are 20, 30, 40 and 50 cc.

Note: In pediatric cases, the BAL doses, as well as all other doses (and their affect), are
different.

Figure 9-3: BAL tool panel

4. Instill the heated saline slowly and continuously using the syringe.

surgicalscience Page 108


# Page 120

Chapter 9 
 Working with Auxiliary Tools
 
Page 109
 
 
Figure 9-4: BAL procedure – instilling saline 
Note: If you wish to instill additional aliquots, remove the syringe from the working channel, fill it 
and reinsert while maintaining your wedge position. As long as you maintain the scope’s 
wedge position, it is considered the same BAL procedure.  
To retrieve saline during BAL:  
There are two ways to retrieve instilled saline using BAL. One uses the scope’s suction 
button and the other uses the syringe. 
Retrieve saline using the suction button:  
1.  Select Suction Trap On in the syringe tool panel (Figure 9-3). 
2.  Press the suction button intermittently to retrieve the saline into the trap. 
Retrieve saline using the syringe: 
1.  Following the syringe injection of saline during BAL, pull back the syringe piston to 
slowly retrieve saline into the syringe. 
The syringe animation in the syringe tool panel corresponds to the saline retrieved.  
Note: For both retrieval methods, the total amount of retrieved saline is displayed under the 
syringe image.  


[TABLE]
| F                                                                                              | gure 9-4: BAL procedure – instilling saline                                                      |
| i                                                                                              |                                                                                                  |
|:-----------------------------------------------------------------------------------------------|:-------------------------------------------------------------------------------------------------|
| Note:                                                                                          | If you wish to instill additional aliquots, remove the syringe from the working channel, fill it |
|                                                                                                | and reinsert while maintaining your wedge position. As long as you maintain the scope’s          |
|                                                                                                | wedge position, it is considered the same BAL procedure.                                         |
| To retrieve saline during BAL:                                                                 |                                                                                                  |
|                                                                                                | There are two ways to retrieve instilled saline using BAL. One uses the scope’s suction          |
| button and the other uses the syringe.                                                         |                                                                                                  |
| Retrieve saline using the suction button:                                                      |                                                                                                  |
| 1.   Select Suction Trap On in the syringe tool panel (Figure 9-3).                            |                                                                                                  |
| 2.   Press the suction button intermittently to retrieve the saline into the trap.             |                                                                                                  |
| Retrieve saline using the syringe:                                                             |                                                                                                  |
|                                                                                                | 1.   Following the syringe injection of saline during BAL, pull back the syringe piston to       |
|                                                                                                | slowly retrieve saline into the syringe.                                                         |
|                                                                                                | The syringe animation in the syringe tool panel corresponds to the saline retrieved.             |
| Note:  For both retrieval methods, the total amount of retrieved saline is displayed under the |                                                                                                  |
|                                                                                                | syringe image.                                                                                   |

[OCR]
Chapter 9 Working with Auxiliary Tools

Figure 9-4: BAL procedure -— instilling saline

Note: If you wish to instill additional aliquots, remove the syringe from the working channel, fill it
and reinsert while maintaining your wedge position. As long as you maintain the scope’s
wedge position, it is considered the same BAL procedure.

To retrieve saline during BAL:

There are two ways to retrieve instilled saline using BAL. One uses the scope’s suction
button and the other uses the syringe.

Retrieve saline using the suction button:

1. Select Suction Trap On in the syringe tool panel (Figure 9-3).
2. Press the suction button intermittently to retrieve the saline into the trap.

Retrieve saline using the syringe:

1. Following the syringe injection of saline during BAL, pull back the syringe piston to
slowly retrieve saline into the syringe.

The syringe animation in the syringe tool panel corresponds to the saline retrieved.

Note: For both retrieval methods, the total amount of retrieved saline is displayed under the
syringe image.

surgicalscience Page 109


# Page 121

Chapter 9 
 Working with Auxiliary Tools
 
Page 110
 
Working with multiple tools 
Some simulated procedures may require more than one auxiliary tool for their 
simulation. Such is the case with Trans Bronchial Needle Aspiration (TBNA), where the 
Master Tool is used as an Aspirating Needle and the Syringe is used to apply vacuum. 
Note: The EBUS-TBNA simulation uses the syringe in a similar way to apply vacuum while 
sampling with the EBUS needle. However, applying vacuum while using the EBUS needle 
is only optional.  
 
Figure 9-5: Needle tool panel 
When working with the aspirating needle, its properties are controlled with the master 
tool handle (or virtual activation), the screen selection, and the physical syringe. 
To control the needle in and out of its sheath: 
Use the master tool handle or the virtual activation (see Using the Virtual Activation 
feature on page 105). 
To lock the needle: 
1.  Press the Lock button on the screen.  


[TABLE]
| Chapter 9                                                                               | Working with Auxiliary Tools                                                          |
|:----------------------------------------------------------------------------------------|:--------------------------------------------------------------------------------------|
| Working with multiple tools                                                             |                                                                                       |
| Some simulated procedures may require more than one auxiliary tool for their            |                                                                                       |
|                                                                                         | simulation. Such is the case with Trans Bronchial Needle Aspiration (TBNA), where the |
|                                                                                         | Master Tool is used as an Aspirating Needle and the Syringe is used to apply vacuum.  |
| Note:  The EBUS-TBNA simulation uses the syringe in a similar way to apply vacuum while |                                                                                       |
|                                                                                         | sampling with the EBUS needle. However, applying vacuum while using the EBUS needle   |

[OCR]
Chapter 9 Working with Auxiliary Tools

Working with multiple tools

Some simulated procedures may require more than one auxiliary tool for their
simulation. Such is the case with Trans Bronchial Needle Aspiration (TBNA), where the
Master Tool is used as an Aspirating Needle and the Syringe is used to apply vacuum.

Note: The EBUS-TBNA simulation uses the syringe in a similar way to apply vacuum while
sampling with the EBUS needle. However, applying vacuum while using the EBUS needle
is only optional.

Figure 9-5: Needle tool panel

When working with the aspirating needle, its properties are controlled with the master
tool handle (or virtual activation), the screen selection, and the physical syringe.
To control the needle in and out of its sheath:

Use the master tool handle or the virtual activation (see Using the Virtual Activation
feature on page 105).

To lock the needle:
1. Press the Lock button on the screen.

surgicalscience Page 110


# Page 122

Chapter 9 
 Working with Auxiliary Tools
 
Page 111
 
The needle can only be locked when extracted completely out of its sheath. An 
unlocked needle cannot stab through the airway wall.  
To secure proximally: 
1.  Press the Secure Proximally button on the touch screen. This allows you to push 
the scope and needle together as one unit. 
To apply and release suction:  
Use the actual syringe without inserting it into the working channel.  
1.  Pull the syringe piston open to aspirate (i.e. apply suction to the aspirating needle).  
The corresponding Aspirate/Release status is indicated in the needle tool panel on 
the screen. 
2.  Push the syringe piston closed to release. 
If the syringe is already opened, close it and reopen to Aspirate. (It is the actual 
pulling of the piston that is considered as applying vacuum.) 
Note: The Lock and Secure Proximally features can only be selected using the touch screen. 
Working with tools requiring electricity  
Tools requiring electricity are simulated using the master tool. The Master tool handle 
and virtual activation may or may not be applicable, according to the properties of 
each tool.  
Both contact and non-contact tools are simulated.  
The electric current is applied using the left foot switch for all tools.  


[TABLE]
| The needle can only be locked when extracted completely out of its sheath. An                |
|:---------------------------------------------------------------------------------------------|
| unlocked needle cannot stab through the airway wall.                                         |
| To secure proximally:                                                                        |
| 1.   Press the Secure Proximally button on the touch screen. This allows you to push         |
| the scope and needle together as one unit.                                                   |
| To apply and release suction:                                                                |
| Use the actual syringe without inserting it into the working channel.                        |
| 1.   Pull the syringe piston open to aspirate (i.e. apply suction to the aspirating needle). |
| The corresponding Aspirate/Release status is indicated in the needle tool panel on           |
| the screen.                                                                                  |
| 2.   Push the syringe piston closed to release.                                              |
| If the syringe is already opened, close it and reopen to Aspirate. (It is the actual         |
| pulling of the piston that is considered as applying vacuum.)                                |
| Note:  The Lock and Secure Proximally features can only be selected using the touch screen.  |
| Working with tools requiring electricity                                                     |
| Tools requiring electricity are simulated using the master tool. The Master tool handle      |
| and virtual activation may or may not be applicable, according to the properties of          |
| each tool.                                                                                   |
| Both contact and non-contact tools are simulated.                                            |
| The electric current is applied using the left foot switch for all tools.                    |

[OCR]
Chapter 9 Working with Auxiliary Tools

The needle can only be locked when extracted completely out of its sheath. An
unlocked needle cannot stab through the airway wall.

To secure proximally:

1. Press the Secure Proximally button on the touch screen. This allows you to push
the scope and needle together as one unit.

To apply and release suction:

Use the actual syringe without inserting it into the working channel.

1. Pull the syringe piston open to aspirate (i.e. apply suction to the aspirating needle).

The corresponding Aspirate/Release status is indicated in the needle tool panel on
the screen.

2. Push the syringe piston closed to release.

If the syringe is already opened, close it and reopen to Aspirate. (It is the actual
pulling of the piston that is considered as applying vacuum.)

Note: The Lock and Secure Proximally features can only be selected using the touch screen.

Working with tools requiring electricity

Tools requiring electricity are simulated using the master tool. The Master tool handle
and virtual activation may or may not be applicable, according to the properties of
each tool.

Both contact and non-contact tools are simulated.
The electric current is applied using the left foot switch for all tools.

surgicalscience Page 111


# Page 123

Chapter 9 
 Working with Auxiliary Tools
 
Page 112
 
 
 
Electrocautery probe 
tool panel  
Argon Plasma Coagulation 
probe tool panel 
Figure 9-6: Cauterization probes tool panels 
Tool attributes such as Mode, Output Intensity and Flow rate are controlled using the 
touch screen. 
Duration of applying electricity and the accumulated total time are displayed below, 
whenever the tool is active in the simulation. 
Note: Attributes selection availability may vary per tool. When a selection is dimmed (such as 
Cut and Blend in the EC probe tool panel above), it is unavailable for the tool you are 
working with in this module or case. 
   


[TABLE]
|                                                                                                 | E                                                                                       | Argon Plasma Coagulation   |
|                                                                                                 | l                                                                                       |                            |
|                                                                                                 | ectrocautery probe                                                                      |                            |
|:------------------------------------------------------------------------------------------------|:----------------------------------------------------------------------------------------|:---------------------------|
|                                                                                                 | tool panel                                                                              | probe tool panel           |
| F                                                                                               | gure 9-6: Cauterization probes tool panels                                              |                            |
| i                                                                                               |                                                                                         |                            |
| Tool attributes such as Mode, Output Intensity and Flow rate are controlled using the           |                                                                                         |                            |
| touch screen.                                                                                   |                                                                                         |                            |
| Duration of applying electricity and the accumulated total time are displayed below,            |                                                                                         |                            |
| whenever the tool is active in the simulation.                                                  |                                                                                         |                            |
| Note:  Attributes selection availability may vary per tool. When a selection is dimmed (such as |                                                                                         |                            |
|                                                                                                 | Cut and Blend in the EC probe tool panel above), it is unavailable for the tool you are |                            |

[OCR]
Chapter 9 Working with Auxiliary Tools

Flectrocautery probe Argon Plasma Coagulation
tool panel probe tool panel
Figure 9-6: Cauterization probes tool panels

Tool attributes such as Mode, Output Intensity and Flow rate are controlled using the
touch screen.

Duration of applying electricity and the accumulated total time are displayed below,
whenever the tool is active in the simulation.

Note: Attributes selection availability may vary per tool. When a selection is dimmed (such as
Cut and Blend in the EC probe tool panel above), it is unavailable for the tool you are
working with in this module or case.

surgicalscience Page 112


# Page 124

Chapter 10 
 Viewing Performance Reports
 
Page 113
 
Chapter 10 Viewing Performance Reports 
Performance reports are displayed after each simulation case or task, allowing you to 
monitor and track your training progress. 
Note: MentorLearn produces reports for simulation cases only; reports are not produced 
relating to the completion of any didactic material included in a course. 
When you press Finish to end a task or case, your performance report is displayed 
automatically. All of your reports are listed on the MentorLearn Reports screen. 
Viewing reports 
To view performance reports: 
1.  Click Reports on the MentorLearn menu to access the Reports screen. 
 
Figure 10-1: Reports screen 


[TABLE]
| Chapter 10                                                                              | Viewing Performance Reports                                                           |
|:----------------------------------------------------------------------------------------|:--------------------------------------------------------------------------------------|
| Chapter 10  Viewing Performance Reports                                                 |                                                                                       |
|                                                                                         | Performance reports are displayed after each simulation case or task, allowing you to |
| monitor and track your training progress.                                               |                                                                                       |
| Note:  MentorLearn produces reports for simulation cases only; reports are not produced |                                                                                       |
| relating to the completion of any didactic material included in a course.               |                                                                                       |
| When you press Finish to end a task or case, your performance report is displayed       |                                                                                       |
| automatically. All of your reports are listed on the MentorLearn Reports screen.        |                                                                                       |
| Viewing reports                                                                         |                                                                                       |
| To view performance reports:                                                            |                                                                                       |
| 1.   Click Reports on the MentorLearn menu to access the Reports screen.                |                                                                                       |

[OCR]
Chapter 10 Viewing Performance Reports

| Chapter 10 Viewing Performance Reports

Performance reports are displayed after each simulation case or task, allowing you to
monitor and track your training progress.

Note: MentorLearn produces reports for simulation cases only; reports are not produced
relating to the completion of any didactic material included in a course.

When you press Finish to end a task or case, your performance report is displayed
automatically. All of your reports are listed on the MentorLearn Reports screen.

Viewing reports

To view performance reports:
1. Click Reports on the MentorLearn menu to access the Reports screen.

Figure 10-1: Reports screen

surgicalscience Page 113


# Page 125

Chapter 10 
 Viewing Performance Reports
 
Page 114
 
2.  The entries in the reports table appear in chronological order – the most recently 
performed sessions appear at the top of the list. Each row in the reports table 
represents a single session, meaning that if a user completed a particular 
simulation case three times, three entries (rows) for that case are displayed. 
3.  To display a shorter, more focused list of sessions in the Reports table, use the 
search at the top of the table or define a filter in the right pane. 
4.  To bookmark a report, click the star to the left of its name. The report is 
bookmarked and the star is filled
. To remove the bookmark, click the star 
again. If desired, you can filter only starred reports. In the right pane, select the 
Starred check box to view only those starred reports. Clear the check box to view 
all the reports. 
Note: When you exit MentorLearn, those bookmarked reports are saved and will be 
displayed the next time you open MentorLearn. 
5.  To open a single-case report, press its row in the Reports table. 
 
Figure 10-2: Viewing performance reports 
1 
Report Header displays information about the report, including 
the user who performed the case, the name of the case 
performed, and the module that contains the performed case. 
The session number is displayed in the report header.  


[TABLE]
| Chapter 10                                                                              | Viewing Performance Reports                                                           |
|:----------------------------------------------------------------------------------------|:--------------------------------------------------------------------------------------|
| 2.   The entries in the reports table appear in chronological order – the most recently |                                                                                       |
|                                                                                         | performed sessions appear at the top of the list. Each row in the reports table       |
| represents a single session, meaning that if a user completed a particular              |                                                                                       |
| simulation case three times, three entries (rows) for that case are displayed.          |                                                                                       |
| 3.   To display a shorter, more focused list of sessions in the Reports table, use the  |                                                                                       |
| search at the top of the table or define a filter in the right pane.                    |                                                                                       |
| 4.   To bookmark a report, click the star to the left of its name. The report is        |                                                                                       |
| bookmarked and the star is filled                                                       | . To remove the bookmark, click the star                                              |
|                                                                                         | again. If desired, you can filter only starred reports. In the right pane, select the |
|                                                                                         | Starred check box to view only those starred reports. Clear the check box to view     |
| all the reports.                                                                        |                                                                                       |

[OCR]
Chapter 10 Viewing Performance Reports

2. The entries in the reports table appear in chronological order — the most recently

performed sessions appear at the top of the list. Each row in the reports table
represents a single session, meaning that if a user completed a particular
simulation case three times, three entries (rows) for that case are displayed.
To display a shorter, more focused list of sessions in the Reports table, use the
search at the top of the table or define a filter in the right pane.

To bookmark a report, click the star to the left of its name. The report is

bookmarked and the star is filled *. To remove the bookmark, click the star
again. If desired, you can filter only starred reports. In the right pane, select the
Starred check box to view only those starred reports. Clear the check box to view
all the reports.

Note: When you exit MentorLearn, those bookmarked reports are saved and will be
displayed the next time you open MentorLearn.

5. To open a single-case report, press its row in the Reports table.

ase proficiency Posten

@ fe) °
2
@ Oo
Ye 08
3=
‘| General -

Figure 10-2: Viewing performance reports

Report Header displays information about the report, including
the user who performed the case, the name of the case
performed, and the module that contains the performed case.

The session number is displayed in the report header.

surgicalscience Page 114


# Page 126

Chapter 10 
 Viewing Performance Reports
 
Page 115
 
2 
Scoreboard displays information about your total score for the 
task/case. For more information, see Understanding the 
scoreboard on page 118. 
3 
Video options display options for viewing, downloading, and 
deleting the recorded video of your simulation performance. 
For more information, see Viewing recorded videos on page 
116. 
4 
Metric column: the metrics included in the report. The 
available categories and metrics vary between simulators and 
simulation modules and cases. 
If a report has benchmarks, metrics with a defined skill level 
appear in the Benchmark section at the top of the list.  
Click the Up arrow at the end of the metric’s row to hide the 
associated metrics; click the Down arrow at the end of the 
metric category’s row to display the metrics. 
5 
Result column: the result of the metrics as recorded during the 
user's performance of a simulation case. Click a result to 
display additional information.  
For a detailed explanation of a benchmark result’s rating scale, 
see Understanding benchmarks and rating scales on page 120. 
6 
Score column: The score is calculated on a normalized scale of 
1-5. For a detailed explanation, see Understanding 
benchmarks and rating scales on page 120. 
7 
Learning Curve Graph for a selected metric: a colorful graph is 
displayed on the right side of the Report screen if the user has 
completed two or more sessions of the specific simulation 
case. For a detailed explanation of the graph, see 
Understanding learning curve graphs on page 120.  
8 
Print: click 
 to print the report. 
Displaying additional information 
Click a metric’s result or click Additional Info to display details about the metric such as 
how it is measured or a captured snapshot. Double-click the snapshot to display in a 
separate window. 


[TABLE]
| Chapter 10   | Viewing Performance Reports                                      |
|:-------------|:-----------------------------------------------------------------|
| 2            | Scoreboard displays information about your total score for the   |
|              | task/case. For more information, see Understanding the           |
|              | scoreboard on page 118.                                          |
| 3            | Video options display options for viewing, downloading, and      |
|              | deleting the recorded video of your simulation performance.      |
|              | For more information, see Viewing recorded videos on page        |
|              | 116.                                                             |
| 4            | Metric column: the metrics included in the report. The           |
|              | available categories and metrics vary between simulators and     |
|              | simulation modules and cases.                                    |
|              | If a report has benchmarks, metrics with a defined skill level   |
|              | appear in the Benchmark section at the top of the list.          |
|              | Click the Up arrow at the end of the metric’s row to hide the    |
|              | associated metrics; click the Down arrow at the end of the       |
|              | metric category’s row to display the metrics.                    |
| 5            | Result column: the result of the metrics as recorded during the  |
|              | user's performance of a simulation case. Click a result to       |
|              | display additional information.                                  |
|              | For a detailed explanation of a benchmark result’s rating scale, |
|              | see Understanding benchmarks and rating scales on page 120.      |
| 6            | Score column: The score is calculated on a normalized scale of   |
|              | 1-5. For a detailed explanation, see Understanding               |
|              | benchmarks and rating scales on page 120.                        |
| 7            | Learning Curve Graph for a selected metric: a colorful graph is  |
|              | displayed on the right side of the Report screen if the user has |
|              | completed two or more sessions of the specific simulation        |
|              | case. For a detailed explanation of the graph, see               |
|              | Understanding learning curve graphs on page 120.                 |
| 8            |                                                                  |
|              | Print: click                                                     |
|              |  to print the report.                                            |

[OCR]
Chapter 10

Viewing Performance Reports

8

Scoreboard displays information about your total score for the
task/case. For more information, see Understanding the
scoreboard on page 118.

Video options display options for viewing, downloading, and
deleting the recorded video of your simulation performance.
For more information, see Viewing recorded videos on page
116.

Metric column: the metrics included in the report. The
available categories and metrics vary between simulators and
simulation modules and cases.

If a report has benchmarks, metrics with a defined skill level
appear in the Benchmark section at the top of the list.

Click the Up arrow at the end of the metric’s row to hide the
associated metrics; click the Down arrow at the end of the
metric category's row to display the metrics.

Result column: the result of the metrics as recorded during the
user's performance of a simulation case. Click a result to
display additional information.

For a detailed explanation of a benchmark result’s rating scale,
see Understanding benchmarks and rating scales on page 120.

Score column: The score is calculated on a normalized scale of
1-5. For a detailed explanation, see Understanding
benchmarks and rating scales on page 120.

Learning Curve Graph for a selected metric: a colorful graph is
displayed on the right side of the Report screen if the user has
completed two or more sessions of the specific simulation
case. For a detailed explanation of the graph, see
Understanding learning curve graphs on page 120.

Print: click &) to print the report.

Displaying additional information

Click a metric’s result or click Additional Info to display details about the metric such as
how it is measured or a captured snapshot. Double-click the snapshot to display in a
separate window.

surgicalscience Page 115


# Page 127

Chapter 10 
 Viewing Performance Reports
 
Page 116
 
 
Browsing between sessions 
Use the Previous and Next arrows to browse between different report sessions. 
MentorLearn allows you to browse between the sessions performed of the same case 
within a certain course/module. Therefore, if a learner performed a case independently 
3 times for a module listed in the Library and then performed the same case an 
additional two times within the framework of a course, these sessions will not be linked 
together. The learner would need to browse separately between the sessions 
performed in the module and sessions performed within the framework of the course. 
Viewing recorded videos 
You can view a video of your simulation performance. You can download the video to 
review your performance at a later time or delete the recorded video. 
To view the performance video:  
1.  In the Video section of the report, press Video.  
The recorded video of your performance of the simulation case is displayed. 


[TABLE]
| Browsing between sessions                                                                |                                                  |
|:-----------------------------------------------------------------------------------------|:-------------------------------------------------|
| Use the Previous and Next arrows to browse between different report sessions.            |                                                  |
| MentorLearn allows you to browse between the sessions performed of the same case         |                                                  |
| within a certain course/module. Therefore, if a learner performed a case independently   |                                                  |
| 3 times for a module listed in the Library and then performed the same case an           |                                                  |
| additional two times within the framework of a course, these sessions will not be linked |                                                  |
| together. The learner would need to browse separately between the sessions               |                                                  |
| performed in the module and sessions performed within the framework of the course.       |                                                  |
| Viewing recorded videos                                                                  |                                                  |
| You can view a video of your simulation performance. You can download the video to       |                                                  |
| review your performance at a later time or delete the recorded video.                    |                                                  |
| To view the performance video:                                                           |                                                  |
| 1.                                                                                       | In the Video section of the report, press Video. |

[OCR_TABLE]
James Johnson

‘Stemnnaiin tek

we

[OCR]
Chapter 10 Viewing Performance Reports

Patient management

Browsing between sessions

Use the Previous and Next arrows to browse between different report sessions.

MentorLearn allows you to browse between the sessions performed of the same case
within a certain course/module. Therefore, if a learner performed a case independently
3 times for a module listed in the Library and then performed the same case an
additional two times within the framework of a course, these sessions will not be linked
together. The learner would need to browse separately between the sessions
performed in the module and sessions performed within the framework of the course.

Viewing recorded videos

You can view a video of your simulation performance. You can download the video to
review your performance at a later time or delete the recorded video.

To view the performance video:
1. In the Video section of the report, press Video.

The recorded video of your performance of the simulation case is displayed.

surgicalscience Page 116


# Page 128

Chapter 10 
 Viewing Performance Reports
 
Page 117
 
 
Figure 10-3: Viewing video of simulation performance 
2.  Use the buttons under the video to play, pause, or view in full screen. 
3.  Click outside the video to close it and return to the single report. 
To download the performance video:  
1.  Press 
 in the top left corner of the screen and select Video>Download. 
OR 
Press 
 under the video and select Download Video. 
2.  Browse to select the file location where you want the video to be downloaded. 
3.  Press Save.  
The video is downloaded to the selected location. 
To delete the performance video:  
1.  Press 
 and select Video>Delete. 
The recorded video is deleted. 


[TABLE]
| Chapter 10                                                                   | Viewing Performance Reports                                                        |
|:-----------------------------------------------------------------------------|:-----------------------------------------------------------------------------------|
| F                                                                            | gure 10-3: Viewing video of simulation performance                                 |
| i                                                                            |                                                                                    |
| 2.   Use the buttons under the video to play, pause, or view in full screen. |                                                                                    |
| 3.   Click outside the video to close it and return to the single report.    |                                                                                    |
| To download the performance video:                                           |                                                                                    |
| 1.   Press                                                                   | in the top left corner of the screen and select Video>Download.                    |
| OR                                                                           |                                                                                    |
| Press                                                                        | under the video and select Download Video.                                         |
|                                                                              | 2.   Browse to select the file location where you want the video to be downloaded. |
| 3.   Press Save.                                                             |                                                                                    |
| The video is downloaded to the selected location.                            |                                                                                    |
| To delete the performance video:                                             |                                                                                    |
| 1.   Press                                                                   | and select Video>Delete.                                                           |
| The recorded video is deleted.                                               |                                                                                    |
|                                                                              | Page 117                                                                           |

[OCR]
Chapter 10 Viewing Performance Reports

Figure 10-3: Viewing video of simulation performance

2. Use the buttons under the video to play, pause, or view in full screen.
3. Click outside the video to close it and return to the single report.

To download the performance video:

1. Press | | in the top left corner of the screen and select Video>Download.
OR

Press | | under the video and select Download Video.

2. Browse to select the file location where you want the video to be downloaded.
3. Press Save.

The video is downloaded to the selected location.

To delete the performance video:

1. Press A and select Video>Delete.

The recorded video is deleted.

surgicalscience Page 117


# Page 129

Chapter 10 
 Viewing Performance Reports
 
Page 118
 
Note: A message will appear when there is no more storage space for the recorded 
videos on your local drive. It is recommended to download those videos you 
wish to save to another drive on the computer or to an external drive (e.g. 
USB stick or external hard disk) and then delete them. 
Understanding the scoreboard 
The benchmark scoreboard displays a summary of your performance in a clear and 
colorful way.  
It includes the following components for the simulation case/task: 
 
Figure 10-4: Case benchmark scoreboard 
• 
Proficient: shows if you reached the required skill level or not for the simulation 
case.  
• 
Best Score: is calculated as a weighted average of the scores for each of the 
benchmark metrics. In the above report, 80% = the average score of the metrics 
for the case/task (e.g. total time, total path, accuracy rate, horizontal view). The 
best score is displayed in a percentage.  
o 
The default is that the benchmarks have the same weights. However, the 
total score can be customized so that certain metrics have more weight 
than others. 
o 
Some metrics may be set as critical (must pass) and if you don’t pass the 
metric, you receive a total score of “Failed”. For example, if a case/task 
must be performed with no complications and 2 complications occurred, 
your total score would be “Failed”:  


[TABLE]
| F                                      |                                                                                      |
| i                                      |                                                                                      |
| gure 10-4: Case benchmark scoreboard   |                                                                                      |
|:---------------------------------------|:-------------------------------------------------------------------------------------|
| •                                      | Proficient: shows if you reached the required skill level or not for the simulation  |
|                                        | case.                                                                                |
| •                                      | Best Score: is calculated as a weighted average of the scores for each of the        |
|                                        | benchmark metrics. In the above report, 80% = the average score of the metrics       |
|                                        | for the case/task (e.g. total time, total path, accuracy rate, horizontal view). The |
|                                        | best score is displayed in a percentage.                                             |

[TABLE]
| Best Score: is calculated as a weighted average of the scores for each of the        |
|:-------------------------------------------------------------------------------------|
| benchmark metrics. In the above report, 80% = the average score of the metrics       |
| for the case/task (e.g. total time, total path, accuracy rate, horizontal view). The |
| best score is displayed in a percentage.                                             |
| The default is that the benchmarks have the same weights. However, the               |
| o                                                                                    |
| total score can be customized so that certain metrics have more weight               |
| than others.                                                                         |
| Some metrics may be set as critical (must pass) and if you don’t pass the            |
| o                                                                                    |
| metric, you receive a total score of “Failed”. For example, if a case/task           |
| must be performed with no complications and 2 complications occurred,                |
| your total score would be “Failed”:                                                  |

[OCR]
Chapter 10 Viewing Performance Reports

Note: A message will appear when there is no more storage space for the recorded
videos on your local drive. It is recommended to download those videos you
wish to save to another drive on the computer or to an external drive (e.g.
USB stick or external hard disk) and then delete them.

Understanding the scoreboard

The benchmark scoreboard displays a summary of your performance in a clear and
colorful way.

It includes the following components for the simulation case/task:

Case proficiency Proficiency established by: Default (Me

© oO af

Yes 86% 2 of 1 3

Proficient Best Score: Non consecutive: Attempts:

Figure 10-4: Case benchmark scoreboard

. Proficient: shows if you reached the required skill level or not for the simulation
case.
. Best Score: is calculated as a weighted average of the scores for each of the

benchmark metrics. In the above report, 80% = the average score of the metrics
for the case/task (e.g. total time, total path, accuracy rate, horizontal view). The
best score is displayed in a percentage.

° The default is that the benchmarks have the same weights. However, the
total score can be customized so that certain metrics have more weight
than others.

° Some metrics may be set as critical (must pass) and if you don’t pass the
metric, you receive a total score of “Failed”. For example, if a case/task
must be performed with no complications and 2 complications occurred,
your total score would be “Failed”:

surgicalscience Page 118


# Page 130

Chapter 10 
 Viewing Performance Reports
 
Page 119
 
• 
Non-consecutive: indicates how many times you need to attain the required 
skill level to achieve proficiency. For example, if you are required to achieve 
the skill level once and you accomplished it, your score would be Non-
consecutive: 1 of 1. 
• 
Consecutive: indicates how many consecutive times you are required to attain 
a skill level. For example, if you are required to achieve the skill level in two 
consecutive times and you succeeded the first time, the result would show 
Consecutive: 1 of 2. If you succeed in the next attempt, the score will show 
Consecutive: 2 of 2. If you failed at the second attempt, you would have to 
start again since the requirement is for 2 consecutive successful attempts. 
• 
Attempts: how many attempts/sessions/repetitions of this case you performed. 
The session components are displayed below the case/task components: 
 
Figure 10-5: Session benchmark scoreboard 
• 
Proficient: shows if you reached the required skill level or not for this session of 
the case/task.  
• 
Score: is calculated as a weighted average of the scores for each of the 
benchmark metrics for this session. In the above report, 93.5% = the average 
score of the metrics for the session (e.g. total time, total path, accuracy rate, 
horizontal view). The score is displayed in a percentage.  


[TABLE]
| Non-consecutive: indicates how many times you need to attain the required         |
|:----------------------------------------------------------------------------------|
| skill level to achieve proficiency. For example, if you are required to achieve   |
| the skill level once and you accomplished it, your score would be Non-            |
| consecutive: 1 of 1.                                                              |
| Consecutive: indicates how many consecutive times you are required to attain      |
| a skill level. For example, if you are required to achieve the skill level in two |
| consecutive times and you succeeded the first time, the result would show         |
| Consecutive: 1 of 2. If you succeed in the next attempt, the score will show      |
| Consecutive: 2 of 2. If you failed at the second attempt, you would have to       |
| start again since the requirement is for 2 consecutive successful attempts.       |
| Attempts: how many attempts/sessions/repetitions of this case you performed.      |

[TABLE]
|    | F   | gure 10-5: Session benchmark scoreboard                                              |
|    | i   |                                                                                      |
|:---|:----|:-------------------------------------------------------------------------------------|
| •  |     | Proficient: shows if you reached the required skill level or not for this session of |
|    |     | the case/task.                                                                       |
| •  |     | Score: is calculated as a weighted average of the scores for each of the             |
|    |     | benchmark metrics for this session. In the above report, 93.5% = the average         |
|    |     | score of the metrics for the session (e.g. total time, total path, accuracy rate,    |
|    |     | horizontal view). The score is displayed in a percentage.                            |

[OCR_TABLE]
Chapter 10

[OCR_TABLE]
ME
(ore)

[OCR]
Chapter 10 Viewing Performance Reports

Non-consecutive: indicates how many times you need to attain the required
skill level to achieve proficiency. For example, if you are required to achieve
the skill level once and you accomplished it, your score would be Non-
consecutive: 1 of 1.

Consecutive: indicates how many consecutive times you are required to attain
a skill level. For example, if you are required to achieve the skill level in two
consecutive times and you succeeded the first time, the result would show
Consecutive: 1 of 2. If you succeed in the next attempt, the score will show
Consecutive: 2 of 2. If you failed at the second attempt, you would have to
start again since the requirement is for 2 consecutive successful attempts.
Attempts: how many attempts/sessions/repetitions of this case you performed.

The session components are displayed below the case/task components:

Session proficiency

86%

Yes
Proficient Score

Figure 10-5: Session benchmark scoreboard

Proficient: shows if you reached the required skill level or not for this session of
the case/task.

Score: is calculated as a weighted average of the scores for each of the
benchmark metrics for this session. In the above report, 93.5% = the average
score of the metrics for the session (e.g. total time, total path, accuracy rate,
horizontal view). The score is displayed in a percentage.

surgicalscience

Page 119


# Page 131

Chapter 10 
 Viewing Performance Reports
 
Page 120
 
Understanding benchmarks and rating scales 
Metrics with a defined skill level appear in the Benchmark section. Each metric is 
displayed on a rating scale showing at a quick glance if you have passed or failed the 
required level for this metric.  
 
Figure 10-6: Benchmark rating scale 
The rating scale includes the following components: 
• 
Proficiency (where the score = exactly 4) is exactly the value for which the area 
turns from yellow to green. If your result is exactly or better than the proficiency 
value, your score falls in the green area. 
 
• 
If you failed, your score is in the orange area. 
 
• 
Scores are calculated on a normalized scale of 1-5: 
o 
<2 = poor 
o 
2.0 - <4.0 = average 
o 
4.0 - <4.5 = expert (score = 4 exactly when you reach proficiency) 
o 
> 4.5 = superior 
• 
Click the rating scale; additional information is displayed in the right pane. 
 
Understanding learning curve graphs 
If you have completed two or more sessions of the specific simulation case, the graph 
shows the learning curve for the selected metric.  


[TABLE]
| Chapter 10                                                                             |
|  Viewing Performance Reports                                                           |
|:---------------------------------------------------------------------------------------|
| Understanding benchmarks and rating scales                                             |
| Metrics with a defined skill level appear in the Benchmark section. Each metric is     |
| displayed on a rating scale showing at a quick glance if you have passed or failed the |
| required level for this metric.                                                        |
| F                                                                                      |
| i                                                                                      |
| gure 10-6: Benchmark rating scale                                                      |
| The rating scale includes the following components:                                    |
| Proficiency (where the score = exactly 4) is exactly the value for which the area      |
| •                                                                                      |
| turns from yellow to green. If your result is exactly or better than the proficiency   |
| value, your score falls in the green area.                                             |
| If you failed, your score is in the orange area.                                       |
|                                                                                        |
| •                                                                                      |
| Scores are calculated on a normalized scale of 1-5:                                    |
| •                                                                                      |
| <2 = poor                                                                              |
| o                                                                                      |
| 2.0 - <4.0 = average                                                                   |
| o                                                                                      |
| 4.0 - <4.5 = expert (score = 4 exactly when you reach proficiency)                     |
| o                                                                                      |
| > 4.5 = superior                                                                       |
| o                                                                                      |
| Click the rating scale; additional information is displayed in the right pane.         |
| •                                                                                      |
| Understanding learning curve graphs                                                    |
| If you have completed two or more sessions of the specific simulation case, the graph  |
| shows the learning curve for the selected metric.                                      |
| Page 120                                                                               |

[OCR_TABLE]
NAARtrFIRC 1;

[OCR]
Chapter 10 Viewing Performance Reports

Understanding benchmarks and rating scales

Metrics with a defined skill level appear in the Benchmark section. Each metric is
displayed on a rating scale showing at a quick glance if you have passed or failed the
required level for this metric.

Benchmarks a
Number of correct hits 10Hits MM — Score: 5.00
Accuracy rate - target hits (% 100% —rF Score: 5.00
Maintaining the horizontal view while using the 0° camera 97.2% MM Score: 4.50
Total path length of camera (cm) 126.6cm NM Score: 4.29
Total time 00:00:51 Score: 5.00

Figure 10-6: Benchmark rating scale
The rating scale includes the following components:

e Proficiency (where the score = exactly 4) is exactly the value for which the area
turns from yellow to green. If your result is exactly or better than the proficiency

97.2% nm
2Hits m7

value, your score falls in the green area.

e If you failed, your score is in the orange area.

. Scores are calculated on a normalized scale of 1-5:
° <2 = poor
° 2.0 - <4.0 = average
° 4.0 - <4.5 = expert (score = 4 exactly when you reach proficiency)
° > 4.5 = superior

. Click the rating scale; additional information is displayed in the right pane.

Understanding learning curve graphs

If you have completed two or more sessions of the specific simulation case, the graph
shows the learning curve for the selected metric.

surgicalscience Page 120


# Page 132

Chapter 10 
 Viewing Performance Reports
 
Page 121
 
Note: If benchmarks are defined, the graph is colored using the same color scheme as the 
rating scale. 
The y axis charts the results for the selected metric and the x axis charts the 
repetitions or attempts of this case. 
When benchmarks are defined, you can see your progress in attaining proficiency for 
the specific metric.  
• 
Click a metric in order to display its graph. 
 
• 
If the curve is the orange-yellow area, you haven’t achieved proficiency for this 
metric.  
• 
If the curve is in the green area, you are proficient for this metric. 
 
Figure 10-7: Report's learning curve 


[TABLE]
| Chapter 10                                                                               | Viewing Performance Reports                                                         |
|:-----------------------------------------------------------------------------------------|:------------------------------------------------------------------------------------|
| Note: If benchmarks are defined, the graph is colored using the same color scheme as the |                                                                                     |
| rating scale.                                                                            |                                                                                     |
| The y axis charts the results for the selected metric and the x axis charts the          |                                                                                     |
| repetitions or attempts of this case.                                                    |                                                                                     |
|                                                                                          | When benchmarks are defined, you can see your progress in attaining proficiency for |
| the specific metric.                                                                     |                                                                                     |

[OCR]
Chapter 10 Viewing Performance Reports

Note: If benchmarks are defined, the graph is colored using the same color scheme as the
rating scale.

The y axis charts the results for the selected metric and the x axis charts the
repetitions or attempts of this case.

When benchmarks are defined, you can see your progress in attaining proficiency for
the specific metric.

. Click a metric in order to display its graph.
Number of correct hits 10Hts ‘Score: 5.00

. If the curve is the orange-yellow area, you haven't achieved proficiency for this
metric.

. If the curve is in the green area, you are proficient for this metric.

Number of correct hits

Hits
nf Dw

#1 #2

tt
wo

Sessions

*Only the sessions in which the event occurred are displayed

Figure 10-7: Report's learning curve

surgicalscience Page 121


# Page 133

Chapter 10 
 Viewing Performance Reports
 
Page 122
 
Exporting performance results 
Performance results can be exported to a file. The data is saved as CSV (comma 
separated values) file, which can be viewed using Microsoft® Excel®. 
To export data: 
1.  Press Reports on the MentorLearn menu to access the Reports screen. 
2.  Select the reports you want to export. 
3.  Press 
 and then select Reports>Export Performance.  
 
4.  In the Export Performance window, define the format of the report as well as the 
time period that should be included in the exported file and click Export. 
5.  Select a location where MentorLearn will save the exported file, and then click 
Save. 
MentorLearn generates the performance data and saves the exported file in the 
specified location. 


[TABLE]
| Chapter 10                                                               | Viewing Performance Reports                                                    |
|:-------------------------------------------------------------------------|:-------------------------------------------------------------------------------|
| Exporting performance results                                            |                                                                                |
|                                                                          | Performance results can be exported to a file. The data is saved as CSV (comma |
| separated values) file, which can be viewed using Microsoft® Excel®.     |                                                                                |
| To export data:                                                          |                                                                                |
| 1.   Press Reports on the MentorLearn menu to access the Reports screen. |                                                                                |
| 2.   Select the reports you want to export.                              |                                                                                |
| 3.   Press                                                               | and then select Reports>Export Performance.                                    |

[TABLE]
| 4.                                                                                   | In the Export Performance window, define the format of the report as well as the   |
|:-------------------------------------------------------------------------------------|:-----------------------------------------------------------------------------------|
|                                                                                      | time period that should be included in the exported file and click Export.         |
| 5.   Select a location where MentorLearn will save the exported file, and then click |                                                                                    |
|                                                                                      | Save.                                                                              |
|                                                                                      | MentorLearn generates the performance data and saves the exported file in the      |
|                                                                                      | specified location.                                                                |

[OCR]
Chapter 10

Viewing Performance Reports

Exporting performance results

Performance results can be exported to a file. The data is saved as CSV (comma
separated values) file, which can be viewed using Microsoft® Excel®.

To export data:

1. Press Reports on the MentorLearn menu to access the Reports screen.
2. Select the reports you want to export.

3. Press 3 | and then select Reports>Export Performance.

Export Performance

rows export

x

C Export time in seconds

22472020

CANCEL EXPORT

4. In the Export Performance window, define the format of the report as well as the
time period that should be included in the exported file and click Export.
5. Select a location where MentorLearn will save the exported file, and then click

Save.

MentorLearn generates the performance data and saves the exported file in the

specified location.

surgicalscience

Page 122


# Page 134

Chapter 11 
 Technical Support
 
Page 123
 
Chapter 11 Technical Support 
SURGICAL SCIENCE SUPPORT POLICY 
Surgical Science assigns the highest priority to customer support. We are committed 
to doing our utmost to provide our clients with reliable support and assistance 24 
hours a day, 7 days a week. This support is available in real time via telephone or 
email. 
Surgical Science Call Center 
Customer service 24/7: +1-216-270-2020 
email: support@surgicalscience.com 
 
 
 
 
 
 
 
 


[TABLE]
| Chapter 11                                                                          | Technical Support   |
|:------------------------------------------------------------------------------------|:--------------------|
| Chapter 11 Technical Support                                                        |                     |
| SURGICAL SCIENCE SUPPORT POLICY                                                     |                     |
| Surgical Science assigns the highest priority to customer support. We are committed |                     |
| to doing our utmost to provide our clients with reliable support and assistance 24  |                     |
| hours a day, 7 days a week. This support is available in real time via telephone or |                     |
| email.                                                                              |                     |
| Surgical Science Call Center                                                        |                     |
| Customer service 24/7: +1-216-270-2020                                              |                     |
| email: support@surgicalscience.com                                                  |                     |

[OCR_TABLE]
Chapter 11

[OCR]
Chapter 11 Technical Support

| Chapter 11 Technical Support
SURGICAL SCIENCE SUPPORT POLICY

Surgical Science assigns the highest priority to customer support. We are committed
to doing our utmost to provide our clients with reliable support and assistance 24
hours a day, 7 days a week. This support is available in real time via telephone or
email.

Surgical Science Call Center

Customer service 24/7: +1-216-270-2020

email: support@surgicalscience.com

surgicalscience Page 123


# Page 135

Chapter 12 
 End-User Software License Agreement
 
Page 124
 
Chapter 12 End-User Software License 
Agreement 
BRONCH Mentor® 
1.  DEFINITIONS 
This End-User License Agreement ("Agreement") is a legal agreement between you 
(either an individual or a single entity) and Surgical Science Sweden AB ("Surgical 
Science") for BRONCH Mentor® or such upgrade or future versions thereof identified in 
the Particulars or the License Key Issue Note, which includes computer software and 
may include associated media, printed materials, and electronic documentation 
("Software"). 
 
11.  GRANT 
Surgical Science hereby grants to you a non-exclusive, non-transferable license to 
install and use one copy of the Software, or any prior version for the same operating 
system in accordance with the applicable license type (the type of license in your case 
can be found in the order form / invoice as well as in the License Key Issue Note from 
Surgical Science). The License hereby granted is subject to the following conditions. 
 
111.  CONDITIONS 
1  EXTENT OF LICENSE 
1.1  If you have acquired a hardware identity-based license you may install and use one 
copy of the Software, or any prior version for the same operating system on the single 
computer for which the License Key is issued. 


[TABLE]
| Chapter 12           |                                                                                         | End-User Software License Agreement   |
|:---------------------|:----------------------------------------------------------------------------------------|:--------------------------------------|
|                      | Chapter 12  End-User Software License                                                   |                                       |
|                      | Agreement                                                                               |                                       |
| BRONCH Mentor®       |                                                                                         |                                       |
| 1.  DEFINITIONS      |                                                                                         |                                       |
|                      | This End-User License Agreement ("Agreement") is a legal agreement between you          |                                       |
|                      | (either an individual or a single entity) and Surgical Science Sweden AB ("Surgical     |                                       |
|                      | Science") for BRONCH Mentor® or such upgrade or future versions thereof identified in   |                                       |
|                      | the Particulars or the License Key Issue Note, which includes computer software and     |                                       |
|                      | may include associated media, printed materials, and electronic documentation           |                                       |
| ("Software").        |                                                                                         |                                       |
| 1                    |                                                                                         |                                       |
| 1.  GRANT            |                                                                                         |                                       |
|                      | Surgical Science hereby grants to you a non-exclusive, non-transferable license to      |                                       |
|                      | install and use one copy of the Software, or any prior version for the same operating   |                                       |
|                      | system in accordance with the applicable license type (the type of license in your case |                                       |
|                      | can be found in the order form / invoice as well as in the License Key Issue Note from  |                                       |
|                      | Surgical Science). The License hereby granted is subject to the following conditions.   |                                       |
| 1                    |                                                                                         |                                       |
| 11.  CONDITIONS      |                                                                                         |                                       |
| 1  EXTENT OF LICENSE |                                                                                         |                                       |
|                      | 1.1  If you have acquired a hardware identity-based license you may install and use one |                                       |
|                      | copy of the Software, or any prior version for the same operating system on the single  |                                       |
|                      | computer for which the License Key is issued.                                           |                                       |
|                      |                                                                                         | Page 124                              |

[OCR]
Chapter 12 End-User Software License Agreement

Chapter 12 End-User Software License
Agreement

BRONCH Mentor®

1. DEFINITIONS

This End-User License Agreement ("Agreement") is a legal agreement between you
(either an individual or a single entity) and Surgical Science Sweden AB ("Surgical
Science") for BRONCH Mentor® or such upgrade or future versions thereof identified in
the Particulars or the License Key Issue Note, which includes computer software and
may include associated media, printed materials, and electronic documentation
("Software").

11. GRANT

Surgical Science hereby grants to you a non-exclusive, non-transferable license to
install and use one copy of the Software, or any prior version for the same operating
system in accordance with the applicable license type (the type of license in your case
can be found in the order form / invoice as well as in the License Key Issue Note from
Surgical Science). The License hereby granted is subject to the following conditions.

111. CONDITIONS
1 EXTENT OF LICENSE

1.1 If you have acquired a hardware identity-based license you may install and use one
copy of the Software, or any prior version for the same operating system on the single
computer for which the License Key is issued.

surgicalscience Page 124


# Page 136

Chapter 12 
 End-User Software License Agreement
 
Page 125
 
1.2  If you have acquired a hardware key ("dongle") based node locked license you 
may install and use one copy of the Software, or any prior version for the same 
operating system on the single computer to which the Hardware Key, for which the 
License Key is issued, is attached. Note that you are not obligated to remove the 
installed Software from the computer even if the Hardware Key is removed. However, 
you are not entitled to use the Software on that computer unless the Hardware key is 
reattached. 
1.3  If you have acquired a floating license, you may install one copy of the Software or 
any prior version for the same operating system on any number of computers and 
simultaneously use no more than the number of Software permitted in the License Key 
Issue Note. The rights of installation and use of Software is restricted to the site 
defined in the License Key Issue Note. 
1.4  If the Software is labeled as an upgrade, you must be properly licensed to use a 
product identified by Surgical Science as being eligible for the upgrade in order to use 
the Software. Software labeled as an upgrade replaces and/or supplements the 
product that formed the basis for your eligibility for the upgrade. You may use the 
resulting upgraded product only in accordance with the terms of this Agreement. 
1.5  If the Software is labeled as an upgrade, you must be properly licensed to use a 
product identified by Surgical Science as being eligible for the upgrade in order to use 
the Software. Software labeled as an upgrade replaces and/or supplements the 
product that formed the basis for your eligibility for the upgrade. You may use the 
resulting upgraded product only in accordance with the terms of this Agreement. 
1.6  This license is personal to you and you shall not assign or transfer any interest in it 
or grant any right under it to any third party or seek to exercise this license for the 
benefit or on the data of any third party. 
2  CONFIDENCE OF THE SOFTWARE AND COPYRIGHT 
2.1  The Software, all associated documentation, and all copies are secret and 
confidential to Surgical Science and shall be retained under the effective control of you 
during the period of this Agreement. Disclosures shall be limited to those members of 
your staff (including temporary staff) who need access to the Software to enable you 
to exercise this license. You shall take all measures necessary to maintain confidence 
and secrecy in the Software during the period of this license and after its termination, 
however such termination may arise. 


[TABLE]
| Chapter 12                                                                              | End-User Software License Agreement                                                          |
|:----------------------------------------------------------------------------------------|:---------------------------------------------------------------------------------------------|
| 1.2  If you have acquired a hardware key ("dongle") based node locked license you       |                                                                                              |
| may install and use one copy of the Software, or any prior version for the same         |                                                                                              |
| operating system on the single computer to which the Hardware Key, for which the        |                                                                                              |
| License Key is issued, is attached. Note that you are not obligated to remove the       |                                                                                              |
|                                                                                         | installed Software from the computer even if the Hardware Key is removed. However,           |
|                                                                                         | you are not entitled to use the Software on that computer unless the Hardware key is         |
| reattached.                                                                             |                                                                                              |
|                                                                                         | 1.3  If you have acquired a floating license, you may install one copy of the Software or    |
| any prior version for the same operating system on any number of computers and          |                                                                                              |
|                                                                                         | simultaneously use no more than the number of Software permitted in the License Key          |
| Issue Note. The rights of installation and use of Software is restricted to the site    |                                                                                              |
| defined in the License Key Issue Note.                                                  |                                                                                              |
| 1.4  If the Software is labeled as an upgrade, you must be properly licensed to use a   |                                                                                              |
|                                                                                         | product identified by Surgical Science as being eligible for the upgrade in order to use     |
| the Software. Software labeled as an upgrade replaces and/or supplements the            |                                                                                              |
| product that formed the basis for your eligibility for the upgrade. You may use the     |                                                                                              |
| resulting upgraded product only in accordance with the terms of this Agreement.         |                                                                                              |
| 1.5  If the Software is labeled as an upgrade, you must be properly licensed to use a   |                                                                                              |
|                                                                                         | product identified by Surgical Science as being eligible for the upgrade in order to use     |
| the Software. Software labeled as an upgrade replaces and/or supplements the            |                                                                                              |
| product that formed the basis for your eligibility for the upgrade. You may use the     |                                                                                              |
| resulting upgraded product only in accordance with the terms of this Agreement.         |                                                                                              |
|                                                                                         | 1.6  This license is personal to you and you shall not assign or transfer any interest in it |
| or grant any right under it to any third party or seek to exercise this license for the |                                                                                              |
| benefit or on the data of any third party.                                              |                                                                                              |
| 2  CONFIDENCE OF THE SOFTWARE AND COPYRIGHT                                             |                                                                                              |
| 2.1  The Software, all associated documentation, and all copies are secret and          |                                                                                              |
|                                                                                         | confidential to Surgical Science and shall be retained under the effective control of you    |
|                                                                                         | during the period of this Agreement. Disclosures shall be limited to those members of        |
|                                                                                         | your staff (including temporary staff) who need access to the Software to enable you         |
|                                                                                         | to exercise this license. You shall take all measures necessary to maintain confidence       |
|                                                                                         | and secrecy in the Software during the period of this license and after its termination,     |
| however such termination may arise.                                                     |                                                                                              |

[OCR_TABLE]
Chapter IZ

[OCR_TABLE]
1.2 If you |

[OCR_TABLE]
License Ke
inetallad Cc

[OCR]
Chapter 12 End-User Software License Agreement

1.2 If you have acquired a hardware key ("dongle") based node locked license you
may install and use one copy of the Software, or any prior version for the same
operating system on the single computer to which the Hardware Key, for which the
License Key is issued, is attached. Note that you are not obligated to remove the
installed Software from the computer even if the Hardware Key is removed. However,
you are not entitled to use the Software on that computer unless the Hardware key is
reattached.

1.3 If you have acquired a floating license, you may install one copy of the Software or
any prior version for the same operating system on any number of computers and
simultaneously use no more than the number of Software permitted in the License Key
Issue Note. The rights of installation and use of Software is restricted to the site
defined in the License Key Issue Note.

1.4 If the Software is labeled as an upgrade, you must be properly licensed to use a
product identified by Surgical Science as being eligible for the upgrade in order to use
the Software. Software labeled as an upgrade replaces and/or supplements the
product that formed the basis for your eligibility for the upgrade. You may use the
resulting upgraded product only in accordance with the terms of this Agreement.

1.5 If the Software is labeled as an upgrade, you must be properly licensed to use a
product identified by Surgical Science as being eligible for the upgrade in order to use
the Software. Software labeled as an upgrade replaces and/or supplements the
product that formed the basis for your eligibility for the upgrade. You may use the
resulting upgraded product only in accordance with the terms of this Agreement.

1.6 This license is personal to you and you shall not assign or transfer any interest in it
or grant any right under it to any third party or seek to exercise this license for the
benefit or on the data of any third party.

2 CONFIDENCE OF THE SOFTWARE AND COPYRIGHT

2.1 The Software, all associated documentation, and all copies are secret and
confidential to Surgical Science and shall be retained under the effective control of you
during the period of this Agreement. Disclosures shall be limited to those members of
your staff (including temporary staff) who need access to the Software to enable you
to exercise this license. You shall take all measures necessary to maintain confidence
and secrecy in the Software during the period of this license and after its termination,
however such termination may arise.

surgicalscience Page 125


# Page 137

Chapter 12 
 End-User Software License Agreement
 
Page 126
 
2.2  All title and copyrights and patents in and to the Software (including but not 
limited to any images, photographs, animations, video, audio, music, text, techniques 
and "applets" incorporated into the Software), the accompanying printed materials, 
and any copies of the Software are owned by Surgical Science or its suppliers. The 
Software is protected by copyright laws and patents laws as well as by international 
treaty provisions. Therefore, you must treat the Software like any other copyrighted or 
patented material. You may not copy the printed materials accompanying the 
Software. 
3  OWNERSHIP OF SOFTWARE 
3.1  Subject to the rights granted to you by this Agreement, you acknowledge that all 
and any proprietary rights in the software (including but not limited to copyrights, 
patents, trademarks and trade secrets) and in all associated documentation and other 
material related to the Software in each case now existing or to be developed by 
Surgical Science shall remain the sole property of Surgical Science. 
3.2  Usage Data. You acknowledge and agree that Surgical Science may derive or 
create data and information about the use of the Software by you and your users 
("Usage Data") and Surgical Science may use and disclose Usage Data to its third-
party service providers in order to improve the Software. Personal data related to any 
identifiable individual is not collected by Surgical Science. 
4  SUPPORT SERVICES 
4.1  Surgical Science may provide you with support services related to the Software 
("Support Services"). Use of Support Services is governed by the Surgical Science 
policies and programs described in the user manual, in "online" documentation, and/or 
in other Surgical Science-provided materials. Any supplemental software provided to 
you as part of the Support Services shall be considered part of the Software and 
subject to the terms and conditions of this Agreement. With respect to technical 
information you provide to Surgical Science as part of the Support Services, Surgical 
Science may use such information for its business purposes, including for product 
support and development. Surgical Science will not utilize such technical information in 
a form that personally identifies you. 


[TABLE]
| Chapter 12                                                                           | End-User Software License Agreement                                                      |
|:-------------------------------------------------------------------------------------|:-----------------------------------------------------------------------------------------|
| 2.2  All title and copyrights and patents in and to the Software (including but not  |                                                                                          |
|                                                                                      | limited to any images, photographs, animations, video, audio, music, text, techniques    |
| and "applets" incorporated into the Software), the accompanying printed materials,   |                                                                                          |
| and any copies of the Software are owned by Surgical Science or its suppliers. The   |                                                                                          |
| Software is protected by copyright laws and patents laws as well as by international |                                                                                          |
|                                                                                      | treaty provisions. Therefore, you must treat the Software like any other copyrighted or  |
| patented material. You may not copy the printed materials accompanying the           |                                                                                          |
| Software.                                                                            |                                                                                          |
| 3  OWNERSHIP OF SOFTWARE                                                             |                                                                                          |
|                                                                                      | 3.1  Subject to the rights granted to you by this Agreement, you acknowledge that all    |
| and any proprietary rights in the software (including but not limited to copyrights, |                                                                                          |
|                                                                                      | patents, trademarks and trade secrets) and in all associated documentation and other     |
| material related to the Software in each case now existing or to be developed by     |                                                                                          |
| Surgical Science shall remain the sole property of Surgical Science.                 |                                                                                          |
| 3.2  Usage Data. You acknowledge and agree that Surgical Science may derive or       |                                                                                          |
| create data and information about the use of the Software by you and your users      |                                                                                          |
| ("Usage Data") and Surgical Science may use and disclose Usage Data to its third-    |                                                                                          |
|                                                                                      | party service providers in order to improve the Software. Personal data related to any   |
| identifiable individual is not collected by Surgical Science.                        |                                                                                          |
| 4  SUPPORT SERVICES                                                                  |                                                                                          |
| 4.1  Surgical Science may provide you with support services related to the Software  |                                                                                          |
| ("Support Services"). Use of Support Services is governed by the Surgical Science    |                                                                                          |
|                                                                                      | policies and programs described in the user manual, in "online" documentation, and/or    |
|                                                                                      | in other Surgical Science-provided materials. Any supplemental software provided to      |
| you as part of the Support Services shall be considered part of the Software and     |                                                                                          |
| subject to the terms and conditions of this Agreement. With respect to technical     |                                                                                          |
|                                                                                      | information you provide to Surgical Science as part of the Support Services, Surgical    |
| Science may use such information for its business purposes, including for product    |                                                                                          |
|                                                                                      | support and development. Surgical Science will not utilize such technical information in |
| a form that personally identifies you.                                               |                                                                                          |

[OCR_TABLE]
TL ae ee eee AN

[OCR_TABLE]
2.2 All title

[OCR_TABLE]
and "apple
and any co

[OCR]
Chapter 12 End-User Software License Agreement

2.2 All title and copyrights and patents in and to the Software (including but not
limited to any images, photographs, animations, video, audio, music, text, techniques
and "applets" incorporated into the Software), the accompanying printed materials,
and any copies of the Software are owned by Surgical Science or its suppliers. The
Software is protected by copyright laws and patents laws as well as by international
treaty provisions. Therefore, you must treat the Software like any other copyrighted or
patented material. You may not copy the printed materials accompanying the
Software.

3 OWNERSHIP OF SOFTWARE

3.1 Subject to the rights granted to you by this Agreement, you acknowledge that all
and any proprietary rights in the software (including but not limited to copyrights,
patents, trademarks and trade secrets) and in all associated documentation and other
material related to the Software in each case now existing or to be developed by
Surgical Science shall remain the sole property of Surgical Science.

3.2 Usage Data. You acknowledge and agree that Surgical Science may derive or
create data and information about the use of the Software by you and your users
("Usage Data") and Surgical Science may use and disclose Usage Data to its third-
party service providers in order to improve the Software. Personal data related to any
identifiable individual is not collected by Surgical Science.

4 SUPPORT SERVICES

4.1 Surgical Science may provide you with support services related to the Software
("Support Services"). Use of Support Services is governed by the Surgical Science
policies and programs described in the user manual, in "online" documentation, and/or
in other Surgical Science-provided materials. Any supplemental software provided to
you as part of the Support Services shall be considered part of the Software and
subject to the terms and conditions of this Agreement. With respect to technical
information you provide to Surgical Science as part of the Support Services, Surgical
Science may use such information for its business purposes, including for product
support and development. Surgical Science will not utilize such technical information in
a form that personally identifies you.

surgicalscience Page 126


# Page 138

Chapter 12 
 End-User Software License Agreement
 
Page 127
 
5  INTEGRITY OF THE SOFTWARE 
5.1  You shall not, directly or indirectly in any form or manner, copy, distribute, 
reproduce, incorporate or allow unauthorized use or access to the Software or modify, 
decompile, reverse engineer, disassemble or otherwise attempt to derive a source 
code or similar information from Software, except as explicitly permitted under this 
Agreement. 
5.2  The Software is licensed as a single product. Its component parts may not be 
separated for use on more than one computer. 
5.3  You shall ensure that all copies of and extracts from the Software and its 
associated documentation made or disclosed by you carry Surgical Science’ copyright 
notice in the form shown on the original, or such other copyright notices as Surgical 
Science may specify from time to time and shall ensure that no such notice is deleted. 
6  RIGHT OF ACCESS 
6.1  For the purpose only of verifying your compliance with these conditions, you 
hereby irrevocable grants permission for Surgical Science and its authorized 
representatives during normal business hours to enter the premises from time to time 
wholly or partly occupied by you and in each case there to access, operate, and 
inspect computer equipment and to access, inspect and take copies of documents and 
records (including magnetic and other media). Surgical Science shall exercise this right 
only for the above purpose and shall observe strict confidence in all information which 
it obtains as a result of such inspections except to the extent that disclosure to third 
parties is necessary for the purposes of protecting Surgical Science’ rights in the 
Software. 


[TABLE]
| Chapter 12                                                                            | End-User Software License Agreement                                                      |
|:--------------------------------------------------------------------------------------|:-----------------------------------------------------------------------------------------|
| 5  INTEGRITY OF THE SOFTWARE                                                          |                                                                                          |
| 5.1  You shall not, directly or indirectly in any form or manner, copy, distribute,   |                                                                                          |
|                                                                                       | reproduce, incorporate or allow unauthorized use or access to the Software or modify,    |
| decompile, reverse engineer, disassemble or otherwise attempt to derive a source      |                                                                                          |
| code or similar information from Software, except as explicitly permitted under this  |                                                                                          |
| Agreement.                                                                            |                                                                                          |
| 5.2  The Software is licensed as a single product. Its component parts may not be     |                                                                                          |
| separated for use on more than one computer.                                          |                                                                                          |
| 5.3  You shall ensure that all copies of and extracts from the Software and its       |                                                                                          |
|                                                                                       | associated documentation made or disclosed by you carry Surgical Science’ copyright      |
| notice in the form shown on the original, or such other copyright notices as Surgical |                                                                                          |
|                                                                                       | Science may specify from time to time and shall ensure that no such notice is deleted.   |
| 6  RIGHT OF ACCESS                                                                    |                                                                                          |
| 6.1  For the purpose only of verifying your compliance with these conditions, you     |                                                                                          |
| hereby irrevocable grants permission for Surgical Science and its authorized          |                                                                                          |
|                                                                                       | representatives during normal business hours to enter the premises from time to time     |
| wholly or partly occupied by you and in each case there to access, operate, and       |                                                                                          |
|                                                                                       | inspect computer equipment and to access, inspect and take copies of documents and       |
|                                                                                       | records (including magnetic and other media). Surgical Science shall exercise this right |
|                                                                                       | only for the above purpose and shall observe strict confidence in all information which  |
|                                                                                       | it obtains as a result of such inspections except to the extent that disclosure to third |
| parties is necessary for the purposes of protecting Surgical Science’ rights in the   |                                                                                          |
| Software.                                                                             |                                                                                          |

[OCR_TABLE]
5 INTEGRI

[OCR]
Chapter 12 End-User Software License Agreement

5 INTEGRITY OF THE SOFTWARE

5.1 You shall not, directly or indirectly in any form or manner, copy, distribute,
reproduce, incorporate or allow unauthorized use or access to the Software or modify,
decompile, reverse engineer, disassemble or otherwise attempt to derive a source
code or similar information from Software, except as explicitly permitted under this
Agreement.

5.2 The Software is licensed as a single product. Its component parts may not be
separated for use on more than one computer.

5.3 You shall ensure that all copies of and extracts from the Software and its
associated documentation made or disclosed by you carry Surgical Science’ copyright
notice in the form shown on the original, or such other copyright notices as Surgical
Science may specify from time to time and shall ensure that no such notice is deleted.

6 RIGHT OF ACCESS

6.1 For the purpose only of verifying your compliance with these conditions, you
hereby irrevocable grants permission for Surgical Science and its authorized
representatives during normal business hours to enter the premises from time to time
wholly or partly occupied by you and in each case there to access, operate, and
inspect computer equipment and to access, inspect and take copies of documents and
records (including magnetic and other media). Surgical Science shall exercise this right
only for the above purpose and shall observe strict confidence in all information which
it obtains as a result of such inspections except to the extent that disclosure to third
parties is necessary for the purposes of protecting Surgical Science’ rights in the
Software.

surgicalscience Page 127


# Page 139

Chapter 12 
 End-User Software License Agreement
 
Page 128
 
7  WARRANTY AND LIMITATION OF LIABILITY 
7.1  Surgical Science warrants that (i) the Software will perform substantially in 
accordance with the accompanying written materials for a period of ninety (90) days 
from the date of receipt, and (ii) any Support Services provided by Surgical Science 
shall be substantially as described in applicable written materials provided to you by 
Surgical Science, and Surgical Science support engineers will make commercially 
reasonable efforts to solve any problem issues. Some jurisdictions do not allow 
limitations on duration of an implied warranty, so the above limitation may not apply to 
you. To the extent allowed by applicable law, implied warranties on the Software, if 
any, are limited to ninety (90) days. 
The above said warranty is void if failure of the Software has resulted from accident, 
abuse, or misapplication. Any replacement Software will be warranted for the 
remainder of the original warranty period or thirty (30) days, whichever is longer. 
Neither these remedies nor any Support Services offered by Surgical Science are 
available without proof of purchase from an authorized source. 
7.2  To the maximum extent permitted by applicable law, Surgical Science and its 
suppliers disclaim all other warranties and conditions, either express or implied, 
including, but not limited to, implied warranties of fitness for a particular purpose, title, 
and non-infringement, with regard to the Software, and the provision of or failure to 
provide Support Services. 
7.3  To the maximum extent permitted by applicable law, in no event shall Surgical 
Science or its suppliers be liable for any special, incidental, indirect, or consequential 
damages whatsoever (including, without limitation, damages for loss of business 
profits, business interruption or loss of business information) arising out of the use of 
or inability to use the Software or the provision of or failure to provide Support 
Services. However, if you have entered into a Surgical Science Support Services 
agreement, Surgical Science’ entire liability regarding Support Services shall be 
governed by the terms of that agreement. 
7.4  Surgical Science’ entire liability under any provision of this Agreement and your 
exclusive remedy shall be, at Surgical Science’ sole discretion to, either (i) return of the 
amount actually paid by you for the Software, if any, or (ii) repair or replacement of the 
Software that does not meet Surgical Science’ warranty and which is returned to 
Surgical Science with a copy of your receipt. 


[TABLE]
| Chapter 12                                                                             | End-User Software License Agreement                                                           |
|:---------------------------------------------------------------------------------------|:----------------------------------------------------------------------------------------------|
| 7  WARRANTY AND LIMITATION OF LIABILITY                                                |                                                                                               |
| 7.1  Surgical Science warrants that (i) the Software will perform substantially in     |                                                                                               |
|                                                                                        | accordance with the accompanying written materials for a period of ninety (90) days           |
| from the date of receipt, and (ii) any Support Services provided by Surgical Science   |                                                                                               |
|                                                                                        | shall be substantially as described in applicable written materials provided to you by        |
| Surgical Science, and Surgical Science support engineers will make commercially        |                                                                                               |
| reasonable efforts to solve any problem issues. Some jurisdictions do not allow        |                                                                                               |
|                                                                                        | limitations on duration of an implied warranty, so the above limitation may not apply to      |
| you. To the extent allowed by applicable law, implied warranties on the Software, if   |                                                                                               |
| any, are limited to ninety (90) days.                                                  |                                                                                               |
|                                                                                        | The above said warranty is void if failure of the Software has resulted from accident,        |
| abuse, or misapplication. Any replacement Software will be warranted for the           |                                                                                               |
| remainder of the original warranty period or thirty (30) days, whichever is longer.    |                                                                                               |
| Neither these remedies nor any Support Services offered by Surgical Science are        |                                                                                               |
| available without proof of purchase from an authorized source.                         |                                                                                               |
| 7.2  To the maximum extent permitted by applicable law, Surgical Science and its       |                                                                                               |
| suppliers disclaim all other warranties and conditions, either express or implied,     |                                                                                               |
|                                                                                        | including, but not limited to, implied warranties of fitness for a particular purpose, title, |
| and non-infringement, with regard to the Software, and the provision of or failure to  |                                                                                               |
| provide Support Services.                                                              |                                                                                               |
| 7.3  To the maximum extent permitted by applicable law, in no event shall Surgical     |                                                                                               |
|                                                                                        | Science or its suppliers be liable for any special, incidental, indirect, or consequential    |
| damages whatsoever (including, without limitation, damages for loss of business        |                                                                                               |
|                                                                                        | profits, business interruption or loss of business information) arising out of the use of     |
| or inability to use the Software or the provision of or failure to provide Support     |                                                                                               |
| Services. However, if you have entered into a Surgical Science Support Services        |                                                                                               |
| agreement, Surgical Science’ entire liability regarding Support Services shall be      |                                                                                               |
| governed by the terms of that agreement.                                               |                                                                                               |
| 7.4  Surgical Science’ entire liability under any provision of this Agreement and your |                                                                                               |
|                                                                                        | exclusive remedy shall be, at Surgical Science’ sole discretion to, either (i) return of the  |
|                                                                                        | amount actually paid by you for the Software, if any, or (ii) repair or replacement of the    |
| Software that does not meet Surgical Science’ warranty and which is returned to        |                                                                                               |
| Surgical Science with a copy of your receipt.                                          |                                                                                               |

[OCR_TABLE]
Chapter 12

[OCR_TABLE]
7 WARRAT

[OCR_TABLE]
IA Qiyirnin

[OCR_TABLE]
fe —h—e ws

accordanc

[OCR]
Chapter 12 End-User Software License Agreement

7 WARRANTY AND LIMITATION OF LIABILITY

7.1 Surgical Science warrants that (i) the Software will perform substantially in
accordance with the accompanying written materials for a period of ninety (90) days
from the date of receipt, and (ii) any Support Services provided by Surgical Science
shall be substantially as described in applicable written materials provided to you by
Surgical Science, and Surgical Science support engineers will make commercially
reasonable efforts to solve any problem issues. Some jurisdictions do not allow
limitations on duration of an implied warranty, so the above limitation may not apply to
you. To the extent allowed by applicable law, implied warranties on the Software, if
any, are limited to ninety (90) days.

The above said warranty is void if failure of the Software has resulted from accident,
abuse, or misapplication. Any replacement Software will be warranted for the
remainder of the original warranty period or thirty (30) days, whichever is longer.
Neither these remedies nor any Support Services offered by Surgical Science are
available without proof of purchase from an authorized source.

7.2 To the maximum extent permitted by applicable law, Surgical Science and its
suppliers disclaim all other warranties and conditions, either express or implied,
including, but not limited to, implied warranties of fitness for a particular purpose, title,
and non-infringement, with regard to the Software, and the provision of or failure to
provide Support Services.

7.3 To the maximum extent permitted by applicable law, in no event shall Surgical
Science or its suppliers be liable for any special, incidental, indirect, or consequential
damages whatsoever (including, without limitation, damages for loss of business
profits, business interruption or loss of business information) arising out of the use of
or inability to use the Software or the provision of or failure to provide Support
Services. However, if you have entered into a Surgical Science Support Services
agreement, Surgical Science’ entire liability regarding Support Services shall be
governed by the terms of that agreement.

7.4 Surgical Science’ entire liability under any provision of this Agreement and your
exclusive remedy shall be, at Surgical Science’ sole discretion to, either (i) return of the
amount actually paid by you for the Software, if any, or (ii) repair or replacement of the
Software that does not meet Surgical Science’ warranty and which is returned to
Surgical Science with a copy of your receipt.

surgicalscience Page 128


# Page 140

Chapter 12 
 End-User Software License Agreement
 
Page 129
 
8  TERMINATION 
8.1  If this license is a Trial license, you shall be entitled to return the Software to 
Surgical Science on or before Trial Expiry Date specified in the License Key Issue Note 
and, in that event, this Agreement shall then terminate. Unless otherwise agreed under 
special conditions, no license fee or other charges shall be payable by you in respect 
of the trial. 
8.2  Unless terminated pursuant to 8.3 below this Agreement shall continue until the 
expiry date, if any, specified in the Particulars or the License Key Issue Note. 
8.3  This Agreement may be terminated by Surgical Science at any time by written 
notice of termination: 
8.3.1.  if you shall expressly or impliedly repudiate this license by refusing or 
threatening to refuse to observe any of the conditions to which this license is subject; 
or 
8.3.2  if you shall fail to make payment of any amount due to and invoiced by Surgical 
Science or to observe any of the conditions to which this license is subject and, after 
your attention has been drawn by notice to such failure, shall fail to remedy the matter 
to Surgical Science's reasonable satisfaction within thirty days of the giving or such 
notice; or 
8.3.3  if you shall have a receiver or administrative receiver or administrator appointed 
or shall enter into liquidation whether compulsory or voluntary or if you or any member 
of your partnership shall be unable to pay its debts as and when they fall due or any 
judgment or execution or other process issued in respect of any judgment against you 
is unsatisfied for fourteen days. 
8.4  On expiry, surrender or other termination of this Agreement, however such 
termination may arise, you shall cease to load, store, copy or use the Software, shall 
delete the Software from the any computers on which the Software is installed or 
copied and at Surgical Science's option shall either surrender the Software and all 
documentation and other related materials to Surgical Science or shall destroy the 
Software with all documentation and other related materials and deliver to Surgical 
Science a certificate of comprehensive destruction. You shall continue after 
termination to observe and enforce confidence and secrecy in respect of the Software 
and its documentation and related materials for the benefit of Surgical Science, and 
however termination may occur it shall not prejudice any right of action or remedy 
which may have accrued prior to termination. 


[TABLE]
| Chapter 12                                                                               | End-User Software License Agreement                                                       |
|:-----------------------------------------------------------------------------------------|:------------------------------------------------------------------------------------------|
| 8  TERMINATION                                                                           |                                                                                           |
| 8.1  If this license is a Trial license, you shall be entitled to return the Software to |                                                                                           |
|                                                                                          | Surgical Science on or before Trial Expiry Date specified in the License Key Issue Note   |
|                                                                                          | and, in that event, this Agreement shall then terminate. Unless otherwise agreed under    |
|                                                                                          | special conditions, no license fee or other charges shall be payable by you in respect    |
| of the trial.                                                                            |                                                                                           |
| 8.2  Unless terminated pursuant to 8.3 below this Agreement shall continue until the     |                                                                                           |
| expiry date, if any, specified in the Particulars or the License Key Issue Note.         |                                                                                           |
| 8.3  This Agreement may be terminated by Surgical Science at any time by written         |                                                                                           |
| notice of termination:                                                                   |                                                                                           |
| 8.3.1.  if you shall expressly or impliedly repudiate this license by refusing or        |                                                                                           |
|                                                                                          | threatening to refuse to observe any of the conditions to which this license is subject;  |
| or                                                                                       |                                                                                           |
|                                                                                          | 8.3.2  if you shall fail to make payment of any amount due to and invoiced by Surgical    |
|                                                                                          | Science or to observe any of the conditions to which this license is subject and, after   |
|                                                                                          | your attention has been drawn by notice to such failure, shall fail to remedy the matter  |
| to Surgical Science's reasonable satisfaction within thirty days of the giving or such   |                                                                                           |
| notice; or                                                                               |                                                                                           |
|                                                                                          | 8.3.3  if you shall have a receiver or administrative receiver or administrator appointed |
|                                                                                          | or shall enter into liquidation whether compulsory or voluntary or if you or any member   |
| of your partnership shall be unable to pay its debts as and when they fall due or any    |                                                                                           |
|                                                                                          | judgment or execution or other process issued in respect of any judgment against you      |
| is unsatisfied for fourteen days.                                                        |                                                                                           |
| 8.4  On expiry, surrender or other termination of this Agreement, however such           |                                                                                           |
| termination may arise, you shall cease to load, store, copy or use the Software, shall   |                                                                                           |
| delete the Software from the any computers on which the Software is installed or         |                                                                                           |
| copied and at Surgical Science's option shall either surrender the Software and all      |                                                                                           |
| documentation and other related materials to Surgical Science or shall destroy the       |                                                                                           |
| Software with all documentation and other related materials and deliver to Surgical      |                                                                                           |
| Science a certificate of comprehensive destruction. You shall continue after             |                                                                                           |
|                                                                                          | termination to observe and enforce confidence and secrecy in respect of the Software      |
| and its documentation and related materials for the benefit of Surgical Science, and     |                                                                                           |
| however termination may occur it shall not prejudice any right of action or remedy       |                                                                                           |
| which may have accrued prior to termination.                                             |                                                                                           |

[OCR_TABLE]
Q TERMIN

[OCR_TABLE]
8.1 If this |
Surgical Sc

[OCR]
Chapter 12 End-User Software License Agreement

8 TERMINATION

8.1 If this license is a Trial license, you shall be entitled to return the Software to
Surgical Science on or before Trial Expiry Date specified in the License Key Issue Note
and, in that event, this Agreement shall then terminate. Unless otherwise agreed under
special conditions, no license fee or other charges shall be payable by you in respect
of the trial.

8.2 Unless terminated pursuant to 8.3 below this Agreement shall continue until the
expiry date, if any, specified in the Particulars or the License Key Issue Note.

8.3 This Agreement may be terminated by Surgical Science at any time by written
notice of termination:

8.3.1. if you shall expressly or impliedly repudiate this license by refusing or
threatening to refuse to observe any of the conditions to which this license is subject;
or

8.3.2 if you shall fail to make payment of any amount due to and invoiced by Surgical
Science or to observe any of the conditions to which this license is subject and, after
your attention has been drawn by notice to such failure, shall fail to remedy the matter
to Surgical Science's reasonable satisfaction within thirty days of the giving or such
notice; or

8.3.3 if you shall have a receiver or administrative receiver or administrator appointed
or shall enter into liquidation whether compulsory or voluntary or if you or any member
of your partnership shall be unable to pay its debts as and when they fall due or any
judgment or execution or other process issued in respect of any judgment against you
is unsatisfied for fourteen days.

8.4 On expiry, surrender or other termination of this Agreement, however such
termination may arise, you shall cease to load, store, copy or use the Software, shall
delete the Software from the any computers on which the Software is installed or
copied and at Surgical Science's option shall either surrender the Software and all
documentation and other related materials to Surgical Science or shall destroy the
Software with all documentation and other related materials and deliver to Surgical
Science a certificate of comprehensive destruction. You shall continue after
termination to observe and enforce confidence and secrecy in respect of the Software
and its documentation and related materials for the benefit of Surgical Science, and
however termination may occur it shall not prejudice any right of action or remedy
which may have accrued prior to termination.

surgicalscience Page 129


# Page 141

Chapter 12 
 End-User Software License Agreement
 
Page 130
 
9.  MISCELLANEOUS 
9.1  This Agreement is governed by Swedish law and any disputes arising out of or in 
connection to this Agreement shall be submitted to the exclusive jurisdiction of the 
Swedish courts. 
9.2  The headings to these Conditions are included for convenience only and do not 
affect their interpretation. 
9.3  Should you have any questions concerning this Agreement, or if you desire to 
contact Surgical Science for any reason, please contact Surgical Science (write or e-
mail): Surgical Science Sweden AB, Drakegatan 7, SE-412 50 Göteborg, Sweden, 
[info@surgical-science.com]. 
 
 


[TABLE]
| Chapter 12                                                                            | End-User Software License Agreement                                                  |
|:--------------------------------------------------------------------------------------|:-------------------------------------------------------------------------------------|
| 9.  MISCELLANEOUS                                                                     |                                                                                      |
|                                                                                       | 9.1  This Agreement is governed by Swedish law and any disputes arising out of or in |
| connection to this Agreement shall be submitted to the exclusive jurisdiction of the  |                                                                                      |
| Swedish courts.                                                                       |                                                                                      |
| 9.2  The headings to these Conditions are included for convenience only and do not    |                                                                                      |
| affect their interpretation.                                                          |                                                                                      |
| 9.3  Should you have any questions concerning this Agreement, or if you desire to     |                                                                                      |
| contact Surgical Science for any reason, please contact Surgical Science (write or e- |                                                                                      |
| mail): Surgical Science Sweden AB, Drakegatan 7, SE-412 50 Göteborg, Sweden,          |                                                                                      |
| [info@surgical-science.com].                                                          |                                                                                      |

[OCR_TABLE]
METAMAS! TS

[OCR]
Chapter 12 End-User Software License Agreement

9. MISCELLANEOUS

9.1 This Agreement is governed by Swedish law and any disputes arising out of or in
connection to this Agreement shall be submitted to the exclusive jurisdiction of the
Swedish courts.

9.2 The headings to these Conditions are included for convenience only and do not
affect their interpretation.

9.3 Should you have any questions concerning this Agreement, or if you desire to
contact Surgical Science for any reason, please contact Surgical Science (write or e-
mail): Surgical Science Sweden AB, Drakegatan 7, SE-412 50 Géteborg, Sweden,
[info@surgical-science.com].

surgicalscience Page 130


# Page 142

Index
 
Page 131
 
Index 
3 
3D map · 57, 86 
A 
Accessing a module or course · 40 
easy access buttons · 42 
Adjusting height · 12 
Adjusting platform height · 12 
Anatomy atlas · 57, 72 
filters · 61 
Anatomy atlas display · 60 
B 
Benchmarks 
on the Library page · 46 
report graph · 120 
report rating scale · 120 
report scoreboard · 118 
Best score · 118 
Bookmarking reports · 114 
BRONCH Express 
basic display mode · 30 
carry-on case · 20 
components · 21 
display mode · 31 
laptop connections · 30 
setup · 24 
simulation unit · 22 
simulation unit connections · 28 
turning on · 30 
unique features · 33 
using the bronchoscope · 34 
BRONCH Express platform · 20 
Bronchial segment identification · 54, 
68, 90 
Bronchoscope · 15 
BRONCH Express · 23 
using · 34 
Bronchoscopic and endobronchial 
ultrasound display 
Main View · 66 
Bronchoscopic tools · 103 
Browsing between report sessions · 116 
C 
Cloud configuration · 39 
Compass button · 54 
Complementary displays · 57, 71, 86 
Completion status 
viewing in Library · 46 
Connecting the scope · 10 
Consciousness level monitoring · 98 
Consecutive times · 48, 119 
CT Slices, browsing · 62 
D 
Designated Tasks display modes · 84 
Designated Tasks Display Modes 
educational aids · 85 
features · 85 
screen layout · 84 
Directional guidance · 88 
Display modes · 50 
BRONCH Express · 31 
designated tasks · 84 
enhanced simulation · 51 
Display windows 


[TABLE]
| Index                             |                                        |
|:----------------------------------|:---------------------------------------|
|                                   | Bronchial segment identification · 54, |
|                                   | 68, 90                                 |
| 3                                 |                                        |
|                                   | Bronchoscope · 15                      |
|                                   | BRONCH Express · 23                    |
| 3D map · 57, 86                   |                                        |
|                                   | using · 34                             |
|                                   | Bronchoscopic and endobronchial        |
|                                   | ultrasound display                     |
| A                                 |                                        |
|                                   | Main View · 66                         |
|                                   | Bronchoscopic tools · 103              |
| Accessing a module or course · 40 |                                        |
|                                   | Browsing between report sessions · 116 |
| easy access buttons · 42          |                                        |

[OCR_TABLE]
naex

[OCR]
Index

| Index

3

3D map - 57, 86

A

Accessing a module or course - 40
easy access buttons - 42
Adjusting height - 12
Adjusting platform height - 12
Anatomy atlas - 57, 72
filters - 61
Anatomy atlas display - 60

B

Benchmarks
on the Library page - 46
report graph - 120
report rating scale - 120
report scoreboard - 118
Best score - 118
Bookmarking reports - 114
BRONCH Express
basic display mode - 30
carry-on case - 20
components : 21
display mode - 31
laptop connections - 30
setup - 24
simulation unit - 22
simulation unit connections - 28
turning on - 30
unique features - 33
using the bronchoscope - 34
BRONCH Express platform - 20

Bronchial segment identification - 54,
68, 90
Bronchoscope - 15
BRONCH Express : 23
using - 34
Bronchoscopic and endobronchial
ultrasound display
Main View - 66
Bronchoscopic tools - 103
Browsing between report sessions - 116

c

Cloud configuration - 39
Compass button - 54
Complementary displays - 57, 71, 86
Completion status

viewing in Library - 46
Connecting the scope - 10
Consciousness level monitoring - 98
Consecutive times - 48, 119
CT Slices, browsing - 62

D

Designated Tasks display modes - 84
Designated Tasks Display Modes
educational aids - 85
features - 85
screen layout - 84
Directional guidance - 88
Display modes - 50
BRONCH Express : 31
designated tasks - 84
enhanced simulation - 51
Display windows

surgicalscience

Page 131


# Page 143

Index
 
Page 132
 
anatomy atlas · 60 
dynamic 3D map · 58 
Doppler feature · 69 
Dynamic 3D map · 58 
E 
EBUS needle · 19 
ENDO Mentor Suite 
GI Mentor platform · 6 
Enhanced Simulation display modes · 
51 
screen layout 
video bronchoscopy and 
endobronchial ultrasound · 65 
simulation environment · 51 
Exporting performance results · 122 
F 
Filter button · 61 
Foot · 15 
Foot switch · 15 
Freeze feature · 63 
Full screen · 53, 67 
layout 
video bronchoscopy · 81 
video bronchoscopy and 
endobronchial ultrasound · 82 
Full screen mode · 63, 80 
G 
General buttons · 64, 79, 86 
GI-BRONCH interchangeable panel · 7 
H 
Hardware · 5 
Height elevation mechanism · 12 
I 
Imaging results/CT browser · 57, 61, 72 
Instructional aids · 85 
L 
Lateral working position · 11 
Logging in to MentorLearn · 37 
Lung anatomy, bronchial segments 
task 
procedure · 54, 68 
Lymph node stations map · 73 
M 
Master tool · 17, 105 
MentorLearn 
Library page · 41 
Logging in · 37 
reviewing didactic materials · 43 
starting case or task · 44 
workflow · 36 
Modality extensions · 11 
Modes · 50 
N 
Non-consecutive times · 48, 119 


[TABLE]
|                                     | Index                                   |
|:------------------------------------|:----------------------------------------|
| anatomy atlas · 60                  |                                         |
|                                     | H                                       |
| dynamic 3D map · 58                 |                                         |
| Doppler feature · 69                |                                         |
|                                     | Hardware · 5                            |
| Dynamic 3D map · 58                 |                                         |
|                                     | Height elevation mechanism · 12         |
| E                                   |                                         |
|                                     | I                                       |
| EBUS needle · 19                    |                                         |
|                                     | Imaging results/CT browser · 57, 61, 72 |
| ENDO Mentor Suite                   |                                         |
|                                     | Instructional aids · 85                 |
| GI Mentor platform · 6              |                                         |
| Enhanced Simulation display modes · |                                         |
| 51                                  |                                         |
|                                     | L                                       |
| screen layout                       |                                         |
| video bronchoscopy and              |                                         |
| endobronchial ultrasound · 65       | Lateral working position · 11           |
| simulation environment · 51         | Logging in to MentorLearn · 37          |
| Exporting performance results · 122 | Lung anatomy, bronchial segments        |
|                                     | task                                    |
|                                     | procedure · 54, 68                      |
| F                                   | Lymph node stations map · 73            |
| Filter button · 61                  |                                         |
| Foot · 15                           | M                                       |
| Foot switch · 15                    |                                         |
| Freeze feature · 63                 | Master tool · 17, 105                   |
| Full screen · 53, 67                | MentorLearn                             |
| layout                              | Library page · 41                       |
| video bronchoscopy · 81             | Logging in · 37                         |
| video bronchoscopy and              | reviewing didactic materials · 43       |
| endobronchial ultrasound · 82       | starting case or task · 44              |
|                                     | workflow · 36                           |
| Full screen mode · 63, 80           |                                         |
|                                     | Modality extensions · 11                |
|                                     | Modes · 50                              |
| G                                   |                                         |
| General buttons · 64, 79, 86        | N                                       |
| GI-BRONCH interchangeable panel · 7 |                                         |
|                                     | Non-consecutive times · 48, 119         |
|                                     | Page 132                                |

[OCR_TABLE]
oppler 1

WIN aAmIn

[OCR]
Index

anatomy atlas - 60

dynamic 3D map - 58
Doppler feature - 69
Dynamic 3D map - 58

E

EBUS needle - 19
ENDO Mentor Suite
Gl Mentor platform - 6
Enhanced Simulation display modes -
51
screen layout
video bronchoscopy and
endobronchial ultrasound - 65
simulation environment - 51
Exporting performance results - 122

F

Filter button - 61
Foot - 15
Foot switch - 15
Freeze feature - 63
Full screen - 53, 67
layout
video bronchoscopy - 81
video bronchoscopy and
endobronchial ultrasound - 82
Full screen mode - 63, 80

G

General buttons - 64, 79, 86
GI-BRONCH interchangeable panel - 7

H

Hardware - 5
Height elevation mechanism - 12

/

Imaging results/CT browser - 57, 61, 72

Instructional aids - 85

L

Lateral working position - 11
Logging in to MentorLearn - 37
Lung anatomy, bronchial segments
task
procedure - 54, 68
Lymph node stations map - 73

M

Master tool - 17, 105
MentorLearn
Library page - 41
Logging in - 37
reviewing didactic materials - 43
starting case or task - 44
workflow - 36
Modality extensions : 11
Modes - 50

N

Non-consecutive times - 48, 119

surgicalscience

Page 132


# Page 144

Index
 
Page 133
 
O 
Oxygen administration · 99 
Oxygen supplement · 99 
P 
Patient management · 62, 80, 97 
Patient Monitoring · 62, 80, 97 
Performance reports · 113 
Performance video 
deleting · 117 
downloading · 117 
viewing · 116 
Performing clinical procedure · 51 
Procedure 
bronchial segment identification · 54, 68 
Proficiency 
in reports · 120 
Proficiency scoreboard 
cases and tasks · 48 
module and courses · 47 
R 
Real-time alerts · 62 
Report 
with benchmarks · 114 
without benchmarks · 116 
Reports 
bookmarking · 114 
browsing between sessions · 116 
exporting · 122 
viewing recorded videos · 116 
Reports with benchmarks 
learning curve graph · 120 
rating scale · 120 
scoreboard · 118 
Reviewing didactic materials · 43 
S 
Scope 
connectors · 10 
hanger · 9 
Scopes 
bronchoscope · 15 
Sedation administration · 99, 100 
Setup 
BRONCH Express · 24 
Simulation performance video · 116 
Simulator 
hardware · 5 
Starting a simulation case or task · 44 
Step-by-step instructions · 78, 86, 95 
Stop breathing · 54 
Superior working position · 11 
Switching interchangeable panels · 8 
Syringe · 17 
Syringe tool · 106 
T 
Tool 
virtual activation · 106 
Tool panel · 80 
Tool tray · 13 
connection outlets · 14 
Tools menu, opening · 103 
Top rods · 26 
Training management mode · 90 
Training mode · 4 
Training with MentorLearn within a 
module or course · 40 
Transparency · 55 
Turning on BRONCH Express · 30 
Turning on the simulator · 12 
Tutorial movies · 73 


[TABLE]
| O                                         | S                                       |
|:------------------------------------------|:----------------------------------------|
| Oxygen administration · 99                | Scope                                   |
| Oxygen supplement · 99                    | connectors · 10                         |
|                                           | hanger · 9                              |
|                                           | Scopes                                  |
|                                           |                                         |
| P                                         | bronchoscope · 15                       |
|                                           | Sedation administration · 99, 100       |
|                                           | Setup                                   |
| Patient management · 62, 80, 97           |                                         |
|                                           | BRONCH Express · 24                     |
| Patient Monitoring · 62, 80, 97           |                                         |
|                                           | Simulation performance video · 116      |
| Performance reports · 113                 |                                         |
|                                           | Simulator                               |
| Performance video                         |                                         |
|                                           | hardware · 5                            |
| deleting · 117                            |                                         |
|                                           | Starting a simulation case or task · 44 |
| downloading · 117                         |                                         |
| viewing · 116                             | Step-by-step instructions · 78, 86, 95  |
| Performing clinical procedure · 51        | Stop breathing · 54                     |
| Procedure                                 | Superior working position · 11          |
| bronchial segment identification · 54, 68 | Switching interchangeable panels · 8    |
| Proficiency                               | Syringe · 17                            |
| in reports · 120                          | Syringe tool · 106                      |
| Proficiency scoreboard                    |                                         |
| cases and tasks · 48                      |                                         |
|                                           |                                         |
| module and courses · 47                   | T                                       |

[OCR_TABLE]
xygen a

[OCR_TABLE]
xygen s

[OCR]
Index

oO

Oxygen administration - 99
Oxygen supplement - 99

P

Patient management : 62, 80, 97
Patient Monitoring - 62, 80, 97
Performance reports - 113
Performance video

deleting - 117

downloading - 117

viewing - 116
Performing clinical procedure - 51
Procedure

bronchial segment identification - 54, 68
Proficiency

in reports - 120
Proficiency scoreboard

cases and tasks - 48

module and courses - 47

R

Real-time alerts - 62
Report
with benchmarks - 114
without benchmarks - 116
Reports
bookmarking - 114
browsing between sessions - 116
exporting - 122
viewing recorded videos - 116
Reports with benchmarks
learning curve graph - 120
rating scale - 120
scoreboard - 118
Reviewing didactic materials - 43

Ss

Scope

connectors - 10

hanger - 9
Scopes

bronchoscope - 15
Sedation administration - 99, 100
Setup

BRONCH Express : 24
Simulation performance video - 116
Simulator

hardware - 5
Starting a simulation case or task - 44
Step-by-step instructions - 78, 86, 95
Stop breathing - 54
Superior working position - 11
Switching interchangeable panels - 8
Syringe - 17
Syringe tool - 106

7

Tool
virtual activation - 106
Tool panel - 80

Tool tray - 13
connection outlets - 14

Tools menu, opening - 103

Top rods - 26

Training management mode - 90

Training mode : 4

Training with MentorLearn within a
module or course - 40

Transparency - 55

Turning on BRONCH Express - 30

Turning on the simulator - 12

Tutorial movies - 73

surgicalscience

Page 133


# Page 145

Index
 
Page 134
 
U 
Ultrasound image 
displaying · 67 
URO interchangeable panel · 8 
V 
Video bronchoscopy and 
endobronchial ultrasound · 65 
full screen · 82 
Viewing 
recorded videos · 116 
report sessions · 116 
Viewing performance reports · 113 
Virtual activation · 106 
Virtual instructor · 62 
Vital signs monitoring · 97 
W 
Workflow · 35 
Working 
locally · 39 
on the cloud site · 39 
Working locally configuration · 39 
Working positions · 11 
BRONCH Express · 33 
Working with bronchoscopic tools · 103 
 


[TABLE]
|                                   | Index                                  |
|:----------------------------------|:---------------------------------------|
|                                   | Virtual activation · 106               |
| U                                 |                                        |
|                                   | Virtual instructor · 62                |
|                                   | Vital signs monitoring · 97            |
| Ultrasound image                  |                                        |
| displaying · 67                   |                                        |
| URO interchangeable panel · 8     |                                        |
|                                   | W                                      |
|                                   | Workflow · 35                          |
| V                                 |                                        |
|                                   | Working                                |
|                                   | locally · 39                           |
| Video bronchoscopy and            |                                        |
|                                   | on the cloud site · 39                 |
| endobronchial ultrasound · 65     |                                        |
|                                   | Working locally configuration · 39     |
| full screen · 82                  |                                        |
|                                   | Working positions · 11                 |
| Viewing                           |                                        |
|                                   | BRONCH Express · 33                    |
| recorded videos · 116             |                                        |
|                                   | Working with bronchoscopic tools · 103 |
| report sessions · 116             |                                        |
| Viewing performance reports · 113 |                                        |
|                                   | Page 134                               |

[OCR]
Index

U Virtual activation - 106
Virtual instructor - 62

Ultrasound image Vital signs monitoring - 97

displaying - 67
URO interchangeable panel : 8 W
V Workflow - 35
Working
locally - 39

Video bronchoscopy and
endobronchial ultrasound - 65
full screen - 82

Viewing
recorded videos - 116
report sessions - 116

Viewing performance reports - 113

on the cloud site - 39
Working locally configuration - 39
Working positions : 11

BRONCH Express - 33
Working with bronchoscopic tools - 103

surgicalscience Page 134