

# Page 1

Lower Gastrointestinal  
Endoscopy (Colonoscopy)
First Module -
1
GI Mentor
The module is intended for trainees who have just begun the “hands-on” phase 
of learning and training in Colonoscopy.
The module objectives are:
	
 Performing a complete survey of the Lower GI tract with a forward viewing 
video-endoscope.
	
 Performing diagnostic and therapeutic procedures in “patients” with 
different colon anatomies.
	
 Recognition of typical lesions and abnormalities.
	
 Performing basic therapeutic procedures.
The module consists of 10 cases. The cases are arranged hierarchically from a 
simple diagnostic procedure to a difficult case, involving all training objectives 
of this module.


[TABLE]
| Endoscopy (Colonoscopy)                                                            |
|:-----------------------------------------------------------------------------------|
| The module is intended for trainees who have just begun the “hands-on” phase       |
| of learning and training in Colonoscopy.                                           |
| The module objectives are:                                                         |
|  Performing a complete survey of the Lower GI tract with a forward viewing                                                                                    |
| video-endoscope.                                                                   |
|  Performing diagnostic and therapeutic procedures in “patients” with                                                                                    |
| different colon anatomies.                                                         |
|  Recognition of typical lesions and abnormalities.                                                                                    |
|  Performing basic therapeutic procedures.                                                                                    |
| The module consists of 10 cases. The cases are arranged hierarchically from a      |
| simple diagnostic procedure to a difficult case, involving all training objectives |
| of this module.                                                                    |

[OCR]
First Module -

Lower Gastrointestinal
Endoscopy (Colonoscopy)

The module is intended for trainees who have just begun the “hands-on” phase
of learning and training in Colonoscopy.

The module objectives are:
= Performing a complete survey of the Lower Gl tract with a forward viewing
video-endoscope.

= Performing diagnostic and therapeutic procedures in “patients” with
different colon anatomies.

= Recognition of typical lesions and abnormalities.

= Performing basic therapeutic procedures.

The module consists of 10 cases. The cases are arranged hierarchically from a
simple diagnostic procedure to a difficult case, involving all training objectives
of this module.

surgical GI Mentor


# Page 2

Lower Gastrointestinal  
Endoscopy (Colonoscopy)
First Module -
2
GI Mentor
1
Anatomy:  
An average colon with no findings.
Medical History: 
A 30-year-old female, with irregular bowel movements, alternates between 
constipation and diarrhea. Stool is negative for parasites. She was referred for 
colonoscopy.
Biological Tests: 
Hgb: 
11.3 g/dL 
(12-18) 
Hct: 
39% 
 
(36-54) 
Alb: 
4.2 g/dL 
(3.5-5.5) 
Ca: 
9.6 mg/dL 
(9.0-10.5) 
TSH: 
2.0 mU/dL 
(0.2-3.0) 
FT4: 
17 pmol/L 
(11.7-28)
X-ray: 
The barium fills the entire colon all the way to caecum. No pathology is seen.
Take Home Message: 
Becoming familiar with colonoscopy, both the scope and the colon.
Anatomy
Case 1 
Normal tissue


[TABLE]
|                                                                                  |        |            |
|:---------------------------------------------------------------------------------|:-------|:-----------|
| 1                                                                                | Case 1 |            |
| Anatomy:                                                                         |        |            |
| An average colon with no findings.                                               |        |            |
| Medical History:                                                                 |        |            |
| A 30-year-old female, with irregular bowel movements, alternates between         |        |            |
| constipation and diarrhea. Stool is negative for parasites. She was referred for |        |            |
| colonoscopy.                                                                     |        |            |
| Biological Tests:                                                                |        |            |
| Hgb:                                                                             | 11.3	g/dL        | (12-18)    |
| Hct:                                                                             | 39%    | (36-54)    |
| Alb:                                                                             | 4.2	g/dL        | (3.5-5.5)  |
| Ca:                                                                              | 9.6	mg/dL        | (9.0-10.5) |
| TSH:                                                                             | 2.0	mU/dL        | (0.2-3.0)  |
| FT4:                                                                             | 17	pmol/L        | (11.7-28)  |
| X-ray:                                                                           |        |            |
| The barium fills the entire colon all the way to caecum. No pathology is seen.   |        |            |
| Take Home Message:                                                               |        |            |
| Becoming familiar with colonoscopy, both the scope and the colon.                |        |            |

[OCR]
First Module -

Lower Gastrointestinal
Endoscopy (Colonoscopy)

Case 1

Anatomy:
An average colon with no

Medical History:
A 30-year-old female, wit!

constipation and diarrhea.

colonoscopy.

Biological Tests:
Hgb: = 11.3 g/dL
Het: 39%

Alb: 4.2 g/dL
Ca: 9.6 mg/dL
TSH: = 2.0 mU/dL
FT4: 17 pmol/L

X-ray:
The barium fills the entire

Take Home Message:
Becoming familiar with co!

Anatomy No

surgical

findings.

h irregular bowel movements, alternates between
Stool is negative for parasites. She was referred for

12-18)
36-54)
3.5-5.5)
9.0-10.5)
0.2-3.0)
11.7-28)

colon all the way to caecum. No pathology is seen.

lonoscopy, both the scope and the colon.

rmal tissue

GI Mentor


# Page 3

Lower Gastrointestinal  
Endoscopy (Colonoscopy)
First Module -
3
GI Mentor
2
Anatomy: 
Long redundant sigmoid and transverse colon. No pathology.
Medical History: 
A 70-year-old male with constipation for 40 years. He has been taking 
laxatives for 30 years. He was referred for colonoscopy.
Biological Tests: 
Hgb: 
 
14.2 g/dL 
(12-18) 
Hct: 
 
50% 
 
(36-54) 
Alb: 
 
4.1 g/dL  
(3.5-5.5) 
Alk Phos: 
85 U/L  
(45-115) 
Ca: 
 
9.8 mg/dL 
(9.0-10.5) 
TSH: 
 
1.8 mU/dL 
(0.2-3.0) 
FT4: 
 
12.5 pmol/L 
(11.7-28)
X-ray: 
The barium fills the entire colon all the way to caecum. There is a dolicho-
mega-sigmoid colon. There is some loss of haustration in the left colon.
Take Home Message: 
Dolicho-colon in a patient with long-standing constipation. A more difficult 
colonoscopy.
Case 2 
Anatomy
Melanosis


[TABLE]
|                                                                              |        |            |
|:-----------------------------------------------------------------------------|:-------|:-----------|
| 2                                                                            | Case 2 |            |
| Anatomy:                                                                     |        |            |
| Long redundant sigmoid and transverse colon. No pathology.                   |        |            |
| Medical History:                                                             |        |            |
| A	70-year-old	male	with	constipation	for	40	years.	He	has	been	taking                                                                              |        |            |
| laxatives for 30 years. He was referred for colonoscopy.                     |        |            |
| Biological Tests:                                                            |        |            |
| Hgb:                                                                         | 14.2	g/dL        | (12-18)    |
| Hct:                                                                         | 50%    | (36-54)    |
| Alb:                                                                         | 4.1	g/dL        | (3.5-5.5)  |
| Alk	Phos:                                                                              | 85	U/L        | (45-115)   |
| Ca:                                                                          | 9.8	mg/dL        | (9.0-10.5) |
| TSH:                                                                         | 1.8	mU/dL        | (0.2-3.0)  |
| FT4:                                                                         | 12.5	pmol/L        | (11.7-28)  |
| X-ray:                                                                       |        |            |
| The barium fills the entire colon all the way to caecum. There is a dolicho- |        |            |
| mega-sigmoid colon. There is some loss of haustration in the left colon.     |        |            |
| Take Home Message:                                                           |        |            |
| Dolicho-colon in a patient with long-standing constipation. A more difficult |        |            |
| colonoscopy.                                                                 |        |            |

[OCR]
First Module -

Lower Gastrointestinal
Endoscopy (Colonoscopy)

Case 2

Anatomy:
Long redundant sigmoid and transverse colon. No pathology.

Medical History:
A 70-year-old male with constipation for 40 years. He has been taking
laxatives for 30 years. He was referred for colonoscopy.

Biological Tests:

Hgb: 14.2 g/dL 12-18)

Het: 50% 36-54)

Alb: 4.1 g/dL 3.5-5.5)

Alk Phos: 85 U/L 45-115)

Ca: 9.8 mg/dL 9.0-10.5)

TSH: 1.8 mU/dL 0.2-3.0)

FT4: 12.5 pmol/L 11.7-28)

X-ray:

The barium fills the entire colon all the way to caecum. There is a dolicho-

mega-sigmoid colon. There is some loss of haustration in the left colon.

Take Home Message:
Dolicho-colon in a patient with long-standing constipation. A more difficult
colonoscopy.

Anatomy Melanosis

surgical GI Mentor


# Page 4

Lower Gastrointestinal  
Endoscopy (Colonoscopy)
First Module -
4
GI Mentor
3
Anatomy: 
A sigmoid with a loop. “Reversed” splenic flexure. Caecum which is shifted to 
mid abdomen. No findings.
Medical History: 
A 50-year-old female is referred to you because of family history of colon 
cancer. Both her parents and her older brother had colon cancer. Stool 
examination for occult blood was negative. She was referred for colonoscopy.
Biological Tests:
Hgb: 
 
11.9 g/dL 
(12-18) 
Hct: 
 
35% 
 
(36-54) 
Alb: 
 
4.5 g/dL 
(3.5-5.5) 
Cholesterol: 
205 mg/dL 
(<200) 
AST: 
 
35 U/L  
(0-35) 
Alk Phos: 
115 U/L  
(45-115)
X-ray: 
The barium fills the entire colon all the way to caecum. No filling defect is 
noticed.
Take Home Message: 
Being aware of early detection of colon cancer. The trainee becomes familiar 
with a difficult colonoscopy.
Case 3
Anatomy
Normal tissue


[TABLE]
|                                                                               |        |           |
|:------------------------------------------------------------------------------|:-------|:----------|
| 3                                                                             | Case 3 |           |
| Anatomy:                                                                      |        |           |
| A sigmoid with a loop. “Reversed” splenic flexure. Caecum which is shifted to |        |           |
| mid abdomen. No findings.                                                     |        |           |
| Medical History:                                                              |        |           |
| A	50-year-old	female	is	referred	to	you	because	of	family	history	of	colon                                                                               |        |           |
| cancer. Both her parents and her older brother had colon cancer. Stool        |        |           |
| examination for occult blood was negative. She was referred for colonoscopy.  |        |           |
| Biological Tests:                                                             |        |           |
| Hgb:                                                                          | 11.9	g/dL        | (12-18)   |
| Hct:                                                                          | 35%    | (36-54)   |
| Alb:                                                                          | 4.5	g/dL        | (3.5-5.5) |
| Cholesterol:                                                                  | 205	mg/dL        | (<200)    |
| AST:                                                                          | 35	U/L        | (0-35)    |
| Alk	Phos:                                                                               | 115	U/L        | (45-115)  |
| X-ray:                                                                        |        |           |
| The barium fills the entire colon all the way to caecum. No filling defect is |        |           |
| noticed.                                                                      |        |           |
| Take Home Message:                                                            |        |           |
| Being aware of early detection of colon cancer. The trainee becomes familiar  |        |           |
| with a difficult colonoscopy.                                                 |        |           |

[OCR]
First Module -

Lower Gastrointestinal
Endoscopy (Colonoscopy)

Case 3

Anatomy:
A sigmoid with a loop. “Reversed” splenic flexure. Caecum which is shifted to
mid abdomen. No findings.

Medical History:

A 50-year-old female is referred to you because of family history of colon
cancer. Both her parents and her older brother had colon cancer. Stool
examination for occult blood was negative. She was referred for colonoscopy.

Biological Tests:

Hgb: 11.9 g/dL (12-18)

Het: 35% (36-54)

Alb: 4.5 g/dL (3.5-5.5)

Cholesterol: 205 mg/dL (<200)

AST: 35 U/L (0-35)

Alk Phos: 115 U/L (45-115)

X-ray:

The barium fills the entire colon all the way to caecum. No filling defect is
noticed.

Take Home Message:
Being aware of early detection of colon cancer. The trainee becomes familiar
with a difficult colonoscopy.

Anatomy Normal tissue

surgical GI Mentor


# Page 5

Lower Gastrointestinal  
Endoscopy (Colonoscopy)
First Module -
5
GI Mentor
4
Anatomy:
Pseudomembranes in rectum. Long sigmoid with diverticula. “Reversed” 
splenic flexure. Very redundant transverse colon. Angiodysplasia in caecum.
Medical History:
A 60-year-old male with diarrhea and crampy abdominal pain for 2 weeks. On 
stool examination neither pathological bacteria nor parasites were seen. He 
was treated with antibiotics 3 weeks ago because of urinary tract infection. He 
was referred for colonoscopy.
Biological Tests:
Hgb: 
 
14.3 g/dL 
(12-18) 
Hct: 
 
47% 
 
(36-54) 
Alb: 
 
3.5 g/dL 
(3.5-5.5) 
Alk Phos: 
99 U/L  
(45-115) 
TSH: 
 
1.8 mU/dL 
(0.2-3.0)
X-ray: 
The barium fills the entire colon all the way to caecum. There is a very 
redundant sigmoid and transverse colon. No pathologies are noticed.
Take Home Message: 
Learning to identify pseudomembranes and performing colonoscopy in a 
difficult redundant colon. Practicing an easy biopsy (in the rectum).
Case 4
Anatomy
Diverticula
Angiodysplasia
Pseudomembranes


[TABLE]
|                                                                             |                                                                          |           |
|:----------------------------------------------------------------------------|:-------------------------------------------------------------------------|:----------|
| 4                                                                           | Case 4                                                                   |           |
| Anatomy:                                                                    |                                                                          |           |
| Pseudomembranes in rectum. Long sigmoid with diverticula. “Reversed”        |                                                                          |           |
| splenic flexure. Very redundant transverse colon. Angiodysplasia in caecum. |                                                                          |           |
| Medical History:                                                            |                                                                          |           |
| A	60-year-old	male	with	diarrhea	and	crampy	abdominal	pain	for	2	weeks.	On                                                                             |                                                                          |           |
| stool examination neither pathological bacteria nor parasites were seen. He |                                                                          |           |
| was	treated	with	antibiotics	3	weeks	ago	because	of	urinary	tract	infection.	He                                                                             |                                                                          |           |
| was referred for colonoscopy.                                               |                                                                          |           |
| Biological Tests:                                                           |                                                                          |           |
| Hgb:                                                                        | 14.3	g/dL                                                                          | (12-18)   |
| Hct:                                                                        | 47%                                                                      | (36-54)   |
| Alb:                                                                        | 3.5	g/dL                                                                          | (3.5-5.5) |
| Alk	Phos:                                                                             | 99	U/L                                                                          | (45-115)  |
| TSH:                                                                        | 1.8	mU/dL                                                                          | (0.2-3.0) |
| X-ray:                                                                      |                                                                          |           |
|                                                                             | The barium fills the entire colon all the way to caecum. There is a very |           |
|                                                                             | redundant sigmoid and transverse colon. No pathologies are noticed.      |           |
| Take Home Message:                                                          |                                                                          |           |
|                                                                             | Learning to identify pseudomembranes and performing colonoscopy in a     |           |
|                                                                             | difficult redundant colon. Practicing an easy biopsy (in the rectum).    |           |

[OCR]
First Module -

Lower Gastrointestinal
Endoscopy (Colonoscopy)

Case 4

Anatomy:

Pseudomembranes in rectum. Long sigmoid with diverticula. “Reversed”
splenic flexure. Very redundant transverse colon. Angiodysplasia in caecum.

Medical History:

A 60-year-old male with diarrhea and crampy abdominal pain for 2 weeks. On
stool examination neither pathological bacteria nor parasites were seen. He
was treated with antibiotics 3 weeks ago because of urinary tract infection. He
was referred for colonoscopy.

Biological Tests:

Hgb: 14.3 g/dL (12-18)
Het: 47% (36-54)
Alb: 3.5 g/dL (3.5-5.5)
Alk Phos: 99 U/L (45-115)
TSH: 1.8 mU/dL (0.2-3.0)
X-ray:

The barium fills the entire colon all the way to caecum. There is a very
redundant sigmoid and transverse colon. No pathologies are noticed.

Take Home Message:
Learning to identify pseudomembranes and performing colonoscopy in a
difficult redundant colon. Practicing an easy biopsy (in the rectum).

Anatomy Angiodysplasia Diverticula Pseudomembranes

surgical GI Mentor


# Page 6

Lower Gastrointestinal  
Endoscopy (Colonoscopy)
First Module -
6
GI Mentor
5
Anatomy: 
Long sigmoid with tumor. Pedunculated polyp in descending colon. Long and 
twisted hepatic flexure.
Medical History: 
A 60-year-old female with family history of colon cancer. She complained of 
rectal bleeding for the last 3 months. She was referred for colonoscopy.
Biological Tests: 
Hgb: 
 
11.9 g/dL 
 
(12-18) 
Hct: 
 
37% 
 
 
(36-54) 
Alb: 
 
4.6 g/dL 
 
(3.5-5.5) 
INR: 
 
1.1 
Platelets: 
250,000 cells/mm³ 
(130,000-440,000) 
Alk Phos: 
102 U/L  
 
(45-115)
X-ray: 
The barium fills the entire colon all the way to caecum. There is a solid non-
obstructing mass in the sigmoid colon and a small filling defect in the shape of 
a polyp in the descending colon.
Take Home Message: 
Practicing the technique of polypectomy.
Case 5
Anatomy
Pedunculated polyp
lschaemic colitis


[TABLE]
|                                                                                  |        |                   |
|:---------------------------------------------------------------------------------|:-------|:------------------|
| 5                                                                                | Case 5 |                   |
| Anatomy:                                                                         |        |                   |
| Long sigmoid with tumor. Pedunculated polyp in descending colon. Long and        |        |                   |
| twisted hepatic flexure.                                                         |        |                   |
| Medical History:                                                                 |        |                   |
| A	60-year-old	female	with	family	history	of	colon	cancer.	She	complained	of                                                                                  |        |                   |
| rectal bleeding for the last 3 months. She was referred for colonoscopy.         |        |                   |
| Biological Tests:                                                                |        |                   |
| Hgb:                                                                             | 11.9	g/dL        | (12-18)           |
| Hct:                                                                             | 37%    | (36-54)           |
| Alb:                                                                             | 4.6	g/dL        | (3.5-5.5)         |
| INR:                                                                             | 1.1    |                   |
| Platelets:                                                                       | 250,000	cells/mm³        | (130,000-440,000) |
| Alk	Phos:                                                                                  | 102	U/L        | (45-115)          |
| X-ray:                                                                           |        |                   |
| The barium fills the entire colon all the way to caecum. There is a solid non-   |        |                   |
| obstructing mass in the sigmoid colon and a small filling defect in the shape of |        |                   |
| a polyp in the descending colon.                                                 |        |                   |
| Take Home Message:                                                               |        |                   |
| Practicing the technique of polypectomy.                                         |        |                   |

[OCR]
First Module -

Lower Gastrointestinal
Endoscopy (Colonoscopy)

Case 5

Anatomy:
Long sigmoid with tumor. Pedunculated polyp in descending colon. Long and
twisted hepatic flexure.

Medical History:
A 60-year-old female with family history of colon cancer. She complained of
rectal bleeding for the last 3 months. She was referred for colonoscopy.

Biological Tests:

Hgb: 11.9 g/dL (12-18)

Het: 37% (36-54)

Alb: 4.6 g/dL (3.5-5.5)

INR: 1.1

Platelets: 250,000 cells/mm? (130,000-440,000)
Alk Phos: 102 U/L (45-115)

X-ray:

The barium fills the entire colon all the way to caecum. There is a solid non-
obstructing mass in the sigmoid colon and a small filling defect in the shape of
a polyp in the descending colon.

Take Home Message:
Practicing the technique of polypectomy.

Anatomy Pedunculated polyp Ischaemic colitis

surgical GI Mentor


# Page 7

Lower Gastrointestinal  
Endoscopy (Colonoscopy)
First Module -
7
GI Mentor
6
Anatomy: 
Very long sigmoid with ischaemic colitis. Descending colon with diverticulum. 
Splenic flexure with pedunculated polyp. Very redundant transverse colon. 
Caecum which is shifted to mid abdomen.
Medical History: 
A 64-year-old male with heart disease. Intermittent angina pectoris. Treated 
with aspirin. He suffered from bloody diarrhea and lower abdomen obliquely 
pain. He was referred for colonoscopy.
Biological Tests: 
Hgb: 
11.5 g/dL 
(12-18) 
Hct: 
35% 
 
(36-54) 
MCH: 
26 pg/cell 
(28-33) 
MCV: 
75 fl 
 
(86-98) 
TSH: 
1.2 mU/dL 
(0.2-3.0) 
Stool examination: Few cysts of Entamoeba Coli. No trophozoites seen.
X-ray: 
The barium fills the entire colon all the way to caecum. There is one 
diverticulum in the descending colon and a 1 cm large filling defect in the 
shape of a polyp in the splenic flexure.
Take Home Message: 
Colonoscopy should be an important part of the work-up of iron deficiency 
anemia. Discussion about the approach to the polyp in the splenic flexure, 
which is difficult to remove and may be an invasive cancer.
Case 6
Anatomy
Pedunculated polyp
Tumor


[TABLE]
|                                                                             |                                                                               |                    |
|:----------------------------------------------------------------------------|:------------------------------------------------------------------------------|:-------------------|
| Case 6                                                                      |                                                                               |                    |
| 6                                                                           |                                                                               |                    |
| Anatomy:                                                                    |                                                                               |                    |
|                                                                             | Very long sigmoid with ischaemic colitis. Descending colon with diverticulum. |                    |
|                                                                             | Splenic flexure with pedunculated polyp. Very redundant transverse colon.     |                    |
|                                                                             | Caecum which is shifted to mid abdomen.                                       |                    |
| Medical History:                                                            |                                                                               |                    |
|                                                                             | A	64-year-old	male	with	heart	disease.	Intermittent	angina	pectoris.	Treated                                                                               |                    |
| with aspirin. He suffered from bloody diarrhea and lower abdomen obliquely  |                                                                               |                    |
| pain. He was referred for colonoscopy.                                      |                                                                               |                    |
| Biological Tests:                                                           |                                                                               |                    |
| Hgb:	                                                                             | (12-18)                                                                       |                    |
| 11.5	g/dL                                                                             |                                                                               |                    |
| Hct:	                                                                             | (36-54)                                                                       |                    |
| 35%                                                                         |                                                                               |                    |
| MCH:	                                                                             | (28-33)                                                                       |                    |
| 26	pg/cell                                                                             |                                                                               |                    |
| MCV:	                                                                             | (86-98)                                                                       |                    |
| 75	fl                                                                             |                                                                               |                    |
| TSH:	                                                                             | (0.2-3.0)                                                                     |                    |
| 1.2	mU/dL                                                                             |                                                                               |                    |
| Stool examination: Few cysts of Entamoeba Coli. No trophozoites seen.       |                                                                               |                    |
| X-ray:                                                                      |                                                                               |                    |
| The barium fills the entire colon all the way to caecum. There is one       |                                                                               |                    |
| diverticulum in the descending colon and a 1 cm large filling defect in the |                                                                               |                    |
| shape of a polyp in the splenic flexure.                                    |                                                                               |                    |
| Take Home Message:                                                          |                                                                               |                    |
| Colonoscopy	should	be	an	important	part	of	the	work-up	of	iron	deficiency                                                                             |                                                                               |                    |
| anemia. Discussion about the approach to the polyp in the splenic flexure,  |                                                                               |                    |
| which is difficult to remove and may be an invasive cancer.                 |                                                                               |                    |
| Anatomy                                                                     | Tumor                                                                         | Pedunculated polyp |

[OCR]
First Module -

Lower Gastrointestinal
Endoscopy (Colonoscopy)

Case 6

Anatomy:

Very long sigmoid with ischaemic colitis. Descending colon with diverticulum.
Splenic flexure with pedunculated polyp. Very redundant transverse colon.
Caecum which is shifted to mid abdomen.

Medical History:

A 64-year-old male with heart disease. Intermittent angina pectoris. Treated
with aspirin. He suffered from bloody diarrhea and lower abdomen obliquely
pain. He was referred for colonoscopy.

Biological Tests:

Hgb: 11.5 g/dL (12-18)
Hct: 35% (36-54)
MCH: 26 pg/cell (28-33)
MCV: 75 fl (86-98)
TSH: 1.2 mU/dL (0.2-3.0)

Stool examination: Few cysts of Entamoeba Coli. No trophozoites seen.

X-ray:
The barium fills the entire colon all the way to caecum. There is one
diverticulum in the descending colon and a1 cm large filling defect in the
shape of a polyp in the splenic flexure.

Take Home Message:

Colonoscopy should be an important part of the work-up of iron deficiency
anemia. Discussion about the approach to the polyp in the splenic flexure,
which is difficult to remove and may be an invasive cancer.

Anatomy Pedunculated polyp

surgical GI Mentor


# Page 8

Lower Gastrointestinal  
Endoscopy (Colonoscopy)
First Module -
8
GI Mentor
7
Anatomy: 
Long sigmoid. Long and twisted hepatic flexure. Sessile polyp in the transverse 
colon. Pedunculated polyp in the descending colon.
Medical History: 
A 45-year-old male with family history of colon cancer. Recently he noticed, on 
two occasions, the presence of bloody stool. He was referred for colonoscopy.
Biological Tests: 
Hgb: 
 
13.9 g/dL 
(12-18) 
Hct: 
 
48% 
 
(36-54) 
Alb: 
 
4.8 g/dL 
(3.5-5.5) 
Alk Phos: 
96 U/L  
(45-115) 
ALT: 
 
48 U/L  
(6-45)
X-ray: 
The barium fills the entire colon all the way to caecum. There is a dolicho-
mega-sigmoid colon and a 2 cm large polyp in the transverse colon. In 
addition, there is a filling defect in the shape of a pedunculated polyp in the 
descending colon.
Take Home Message: 
Genetics of colon cancer. Follow-up at an early stage. At the age of 45 years, 
already two polyps available.
Case 7
Anatomy
Pedunculated polyp
Sessile polyp


[TABLE]
|                                                                                 |                                                                                 |           |
|:--------------------------------------------------------------------------------|:--------------------------------------------------------------------------------|:----------|
| 7                                                                               | Case 7                                                                          |           |
| Anatomy:                                                                        |                                                                                 |           |
|                                                                                 | Long sigmoid. Long and twisted hepatic flexure. Sessile polyp in the transverse |           |
|                                                                                 | colon. Pedunculated polyp in the descending colon.                              |           |
| Medical History:                                                                |                                                                                 |           |
|                                                                                 | A	45-year-old	male	with	family	history	of	colon	cancer.	Recently	he	noticed,	on                                                                                 |           |
|                                                                                 | two occasions, the presence of bloody stool. He was referred for colonoscopy.   |           |
| Biological Tests:                                                               |                                                                                 |           |
| Hgb:                                                                            | 13.9	g/dL                                                                                 | (12-18)   |
| Hct:                                                                            | 48%                                                                             | (36-54)   |
| Alb:                                                                            | 4.8	g/dL                                                                                 | (3.5-5.5) |
| Alk	Phos:                                                                                 | 96	U/L                                                                                 | (45-115)  |
| ALT:                                                                            | 48	U/L                                                                                 | (6-45)    |
| X-ray:                                                                          |                                                                                 |           |
| The barium fills the entire colon all the way to caecum. There is a dolicho-    |                                                                                 |           |
| mega-sigmoid	colon	and	a	2	cm	large	polyp	in	the	transverse	colon.	In                                                                                 |                                                                                 |           |
| addition, there is a filling defect in the shape of a pedunculated polyp in the |                                                                                 |           |
| descending colon.                                                               |                                                                                 |           |
| Take Home Message:                                                              |                                                                                 |           |
| Genetics	of	colon	cancer.	Follow-up	at	an	early	stage.	At	the	age	of	45	years,                                                                                 |                                                                                 |           |
| already two polyps available.                                                   |                                                                                 |           |

[OCR]
First Module -

Lower Gastrointestinal
Endoscopy (Colonoscopy)

Case 7

Anatomy:
Long sigmoid. Long and twisted hepatic flexure. Sessile polyp in the transverse
colon. Pedunculated polyp in the descending colon.

Medical History:
A 45-year-old male with family history of colon cancer. Recently he noticed, on
two occasions, the presence of bloody stool. He was referred for colonoscopy.

Biological Tests:

Hgb: 13.9 g/dL (12-18)
Het: 48% (36-54)
Alb: 4.8 g/dL (3.5-5.5)
Alk Phos: 96 U/L (45-115)
ALT: 48 U/L (6-45)
X-ray:

The barium fills the entire colon all the way to caecum. There is a dolicho-
mega-sigmoid colon and a 2 cm large polyp in the transverse colon. In
addition, there is a filling defect in the shape of a pedunculated polyp in the
descending colon.

Take Home Message:
Genetics of colon cancer. Follow-up at an early stage. At the age of 45 years,
already two polyps available.

Anatomy Sessile polyp Pedunculated polyp

surgical GI Mentor


# Page 9

Lower Gastrointestinal  
Endoscopy (Colonoscopy)
First Module -
9
GI Mentor
8
Anatomy: 
Very large tumor in the transverse colon.
Medical History: 
A 85-year-old male with normal bowel movements up until one year ago. In the 
last year, there has been progressive constipation. Recently there is hardly any 
effect of laxative.  
On physical examination, there is a mass in the mid-upper abdomen. He was 
referred for colonoscopy.
Biological Tests: 
Hgb: 
 
9.9 g/dL 
(12-18) 
Hct: 
 
30% 
 
(36-54) 
Alb: 
 
3.3 g/dL 
(3.5-5.5) 
Alk Phos: 
128 U/L  
(45-115)
X-ray: 
The barium fills the colon up to the mid transverse colon. At this level, there is 
an apple core shape of the barium with further filling of the colon beyond this 
lesion.
Take Home Message: 
Any change in bowel movements at an advanced age justifies colonoscopy, 
looking for colon cancer.
Case 8
Anatomy
Tumor


[TABLE]
|                                                                                    |        |           |
|:-----------------------------------------------------------------------------------|:-------|:----------|
| 8                                                                                  | Case 8 |           |
| Anatomy:                                                                           |        |           |
| Very large tumor in the transverse colon.                                          |        |           |
| Medical History:                                                                   |        |           |
| A	85-year-old	male	with	normal	bowel	movements	up	until	one	year	ago.	In	the                                                                                    |        |           |
| last year, there has been progressive constipation. Recently there is hardly any   |        |           |
| effect of laxative.                                                                |        |           |
| On	physical	examination,	there	is	a	mass	in	the	mid-upper	abdomen.	He	was                                                                                    |        |           |
| referred for colonoscopy.                                                          |        |           |
| Biological Tests:                                                                  |        |           |
| Hgb:                                                                               | 9.9	g/dL        | (12-18)   |
| Hct:                                                                               | 30%    | (36-54)   |
| Alb:                                                                               | 3.3	g/dL        | (3.5-5.5) |
| Alk	Phos:                                                                                    | 128	U/L        | (45-115)  |
| X-ray:                                                                             |        |           |
| The barium fills the colon up to the mid transverse colon. At this level, there is |        |           |
| an apple core shape of the barium with further filling of the colon beyond this    |        |           |
| lesion.                                                                            |        |           |
| Take Home Message:                                                                 |        |           |
| Any change in bowel movements at an advanced age justifies colonoscopy,            |        |           |
| looking	for	colon	cancer.                                                                                    |        |           |

[OCR_TABLE]
Endo

[OCR]
First Module -

Lower Gastrointestinal
Endoscopy (Colonoscopy)

Case 8

Anatomy:
Very large tumor in the transverse colon.

Medical History:

A 85-year-old male with normal bowel movements up until one year ago. In the
last year, there has been progressive constipation. Recently there is hardly any
effect of laxative.

On physical examination, there is a mass in the mid-upper abdomen. He was
referred for colonoscopy.

Biological Tests:

Hgb: 9.9 g/dL (12-18)
Het: 30% (36-54)
Alb: 3.3 g/dL (3.5-5.5)
Alk Phos: 128 U/L (45-115)
X-ray:

The barium fills the colon up to the mid transverse colon. At this level, there is
an apple core shape of the barium with further filling of the colon beyond this
lesion.

Take Home Message:
Any change in bowel movements at an advanced age justifies colonoscopy,
looking for colon cancer.

Anatomy Tumor

surgical GI Mentor


# Page 10

Lower Gastrointestinal  
Endoscopy (Colonoscopy)
First Module -
10
GI Mentor
9
Anatomy: 
Sigmoid with a loop and with Crohn’s disease. Descending colon with 
diverticula. Long and twisted hepatic flexure. Ascending colon and caecum 
with pseudopolyps.
Medical History: 
A 30-year-old female with diarrhea, and occasionally bloody stool, of one-year 
duration. She lost 7 kg. Suffered from diarrhea for the last 5 years and bloody 
stool intermittently. She was referred for colonoscopy.
Biological Tests: 
Hgb: 
10 g/dL   
(12-18) 
Hct: 
28%  
 
(36-54) 
Alb: 
3.5 g/dL 
(3.5-5.5) 
AST: 
42 U/L   
(0-35)
X-ray: 
The barium fills the entire colon all the way to caecum. The mucosa of the 
sigmoid colon is slightly irregular giving the impression of small erosions in the 
mucosa. The ascending colon has multiple lesions resembling polyps.
Take Home Message: 
Identify inflammatory bowel disease and discuss the clinical significance of 
pseudopolyps.
Case 9
Anatomy
Diverticulum
Pseudopolyps
Crohn’s disease


[TABLE]
|                                                                                |                                                                                    |           |
|:-------------------------------------------------------------------------------|:-----------------------------------------------------------------------------------|:----------|
| 9                                                                              | Case 9                                                                             |           |
| Anatomy:                                                                       |                                                                                    |           |
| Sigmoid with a loop and with Crohn’s disease. Descending colon with            |                                                                                    |           |
| diverticula. Long and twisted hepatic flexure. Ascending colon and caecum      |                                                                                    |           |
| with pseudopolyps.                                                             |                                                                                    |           |
| Medical History:                                                               |                                                                                    |           |
| A 30-year-old female with diarrhea, and occasionally bloody stool, of one-year |                                                                                    |           |
| duration.	She	lost	7	kg.	Suffered	from	diarrhea	for	the	last	5	years	and	bloody                                                                                |                                                                                    |           |
| stool intermittently. She was referred for colonoscopy.                        |                                                                                    |           |
| Biological Tests:                                                              |                                                                                    |           |
| Hgb:                                                                           | 10	g/dL                                                                                    | (12-18)   |
| Hct:                                                                           | 28%                                                                                | (36-54)   |
| Alb:                                                                           | 3.5	g/dL                                                                                    | (3.5-5.5) |
| AST:                                                                           | 42	U/L                                                                                    | (0-35)    |
| X-ray:                                                                         |                                                                                    |           |
|                                                                                | The barium fills the entire colon all the way to caecum. The mucosa of the         |           |
|                                                                                | sigmoid colon is slightly irregular giving the impression of small erosions in the |           |
|                                                                                | mucosa. The ascending colon has multiple lesions resembling polyps.                |           |
|                                                                                | Take Home Message:                                                                 |           |
|                                                                                | Identify inflammatory bowel disease and discuss the clinical significance of       |           |
| pseudopolyps.                                                                  |                                                                                    |           |

[OCR]
First Module -

Lower Gastrointestinal
Endoscopy (Colonoscopy)

Case 9

Anatomy:

Sigmoid with a loop and with Crohn's disease. Descending colon with
diverticula. Long and twisted hepatic flexure. Ascending colon and caecum
with pseudopolyps.

Medical History:

A 30-year-old female with diarrhea, and occasionally bloody stool, of one-year
duration. She lost 7 kg. Suffered from diarrhea for the last 5 years and bloody
stool intermittently. She was referred for colonoscopy.

Biological Tests:

Hgb: = 10 g/dL (12-18)
Het: 28% (36-54)
Alb: 3.5 g/dL (3.5-5.5)
AST: = 42 U/L (0-35)
X-ray:

The barium fills the entire colon all the way to caecum. The mucosa of the
sigmoid colon is slightly irregular giving the impression of small erosions in the
mucosa. The ascending colon has multiple lesions resembling polyps.

Take Home Message:
Identify inflammatory bowel disease and discuss the clinical significance of
pseudopolyps.

Anatomy Pseudopolyps Diverticulum Crohn's disease

surgical GI Mentor


# Page 11

Lower Gastrointestinal  
Endoscopy (Colonoscopy)
First Module -
11
GI Mentor
10
Anatomy: 
Rectum with Crohn’s disease. Sigmoid with diverticula. Descending colon with 
Crohn’s and stenosis. Splenic flexure with acute angle. Long transverse colon. 
Ascending colon, caecum and small intestine with Crohn’s disease.
Medical History: 
A 55-year-old female with long-standing Crohn’s disease with diarrhea and 
blood streaks intermittently. Recently she became constipated. She was 
referred for colonoscopy.
Biological Tests: 
Hgb: 
 
10.8 g/dL 
(12-18) 
Hct: 
 
32% 
 
(36-54) 
Alb: 
 
3.3 g/dL 
(3.5-5.5) 
AST: 
 
34 U/L  
(7-35) 
Alk Phos: 
90 U/L  
(45-115) 
Ca: 
 
10 mg/dL 
(8.8-10.5)
X-ray: 
The barium fills the entire colon all the way to caecum. There are multiple 
diverticular in the sigmoid colon. There is a narrowing of the lumen in the 
descending colon with irregular mucosa at the ascending colon.
Take Home Message: 
The differential diagnosis of stricture in such a patient and how to approach it 
therapeutically.
Case 10
Anatomy
Crohn’s disease


[TABLE]
|                                                                                  |         |            |
|:---------------------------------------------------------------------------------|:--------|:-----------|
| 10                                                                               | Case 10 |            |
| Anatomy:                                                                         |         |            |
| Rectum with Crohn’s disease. Sigmoid with diverticula. Descending colon with     |         |            |
| Crohn’s and stenosis. Splenic flexure with acute angle. Long transverse colon.   |         |            |
| Ascending colon, caecum and small intestine with Crohn’s disease.                |         |            |
| Medical History:                                                                 |         |            |
| A	55-year-old	female	with	long-standing	Crohn’s	disease	with	diarrhea	and                                                                                  |         |            |
| blood	streaks	intermittently.	Recently	she	became	constipated.	She	was                                                                                  |         |            |
| referred for colonoscopy.                                                        |         |            |
| Biological Tests:                                                                |         |            |
| Hgb:                                                                             | 10.8	g/dL         | (12-18)    |
| Hct:                                                                             | 32%     | (36-54)    |
| Alb:                                                                             | 3.3	g/dL         | (3.5-5.5)  |
| AST:                                                                             | 34	U/L         | (7-35)     |
| Alk	Phos:                                                                                  | 90	U/L         | (45-115)   |
| Ca:                                                                              | 10	mg/dL         | (8.8-10.5) |
| X-ray:                                                                           |         |            |
| The barium fills the entire colon all the way to caecum. There are multiple      |         |            |
| diverticular in the sigmoid colon. There is a narrowing of the lumen in the      |         |            |
| descending colon with irregular mucosa at the ascending colon.                   |         |            |
| Take Home Message:                                                               |         |            |
| The differential diagnosis of stricture in such a patient and how to approach it |         |            |
| therapeutically.                                                                 |         |            |

[OCR]
First Module -

Lower Gastrointestinal
Endoscopy (Colonoscopy)

Case 10

Anatomy:

Rectum with Crohn's disease. Sigmoid with diverticula. Descending colon with
Crohn’s and stenosis. Splenic flexure with acute angle. Long transverse colon.
Ascending colon, caecum and small intestine with Crohn’s disease.

Medical History:

A 55-year-old female with long-standing Crohn's disease with diarrhea and
blood streaks intermittently. Recently she became constipated. She was
referred for colonoscopy.

Biological Tests:

Hgb: 10.8 g/dL (12-18)
Het: 32% (36-54)
Alb: 3.3 g/dL (3.5-5.5)
AST: 34 U/L (7-35)
Alk Phos: 90 U/L (45-115)
Ca: 10 mg/dL (8.8-10.5)
X-ray:

The barium fills the entire colon all the way to caecum. There are multiple
diverticular in the sigmoid colon. There is a narrowing of the lumen in the
descending colon with irregular mucosa at the ascending colon.
T
T

ake Home Message:
he differential diagnosis of stricture in such a patient and how to approach it
therapeutically.

Anatomy Crohn’s disease

surgical GI Mentor