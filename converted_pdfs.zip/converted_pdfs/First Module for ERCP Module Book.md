

# Page 1

First Module -
Endoscopic Retrograde 
Cholangio-Pancreatography (ERCP)
First Module -
1
GI Mentor
The module is designed to provide skilled endoscopists, trainees, and nurses 
with the opportunity for basic training of diagnostic and therapeutic ERCP 
procedures.
The module objectives are:
	
 Performing the manoeuvre required to find the papilla using an actual 
duodenoscope.
	
 Performing cannulation of the papilla and radiographic demonstration of 
the biliary tree and pancreatic duct.
	
 Performing diagnostic procedures in “patients” with different biliary and 
pancreatic diseases.
	
 Performing basic therapeutic procedures using a variety of accessories 
(tools).
The module consists of 10 cases which include all the indicated training 
objectives.


[TABLE]
| Cholangio-Pancreatography (ERCP)                                             |
|:-----------------------------------------------------------------------------|
| First Module -                                                               |
| The module is designed to provide skilled endoscopists, trainees, and nurses |
| with the opportunity for basic training of diagnostic and therapeutic ERCP   |
| procedures.                                                                  |
| The module objectives are:                                                   |
|  Performing the manoeuvre required to find the papilla using an actual                                                                              |
| duodenoscope.                                                                |
|  Performing cannulation of the papilla and radiographic demonstration of                                                                              |
| the biliary tree and pancreatic duct.                                        |
|  Performing diagnostic procedures in “patients” with different biliary and                                                                              |
| pancreatic diseases.                                                         |
|  Performing basic therapeutic procedures using a variety of accessories                                                                              |
| (tools).                                                                     |
| The module consists of 10 cases which include all the indicated training     |
| objectives.                                                                  |

[OCR]
First Module -
Endoscopic Retrograde
Cholangio-Pancreatography (ERCP) I

The module is designed to provide skilled endoscopists, trainees, and nurses
with the opportunity for basic training of diagnostic and therapeutic ERCP
procedures.

The module objectives are:
= Performing the manoeuvre required to find the papilla using an actual
duodenoscope.

= Performing cannulation of the papilla and radiographic demonstration of
the biliary tree and pancreatic duct.

= Performing diagnostic procedures in “patients” with different biliary and
pancreatic diseases.

= Performing basic therapeutic procedures using a variety of accessories
(tools).

The module consists of 10 cases which include all the indicated training
objectives.

surgical GI Mentor


# Page 2

First Module -
Endoscopic Retrograde 
Cholangio-Pancreatography (ERCP)
First Module -
2
GI Mentor
1
Medical History: 
A 75-year-old male. One week ago he started with nausea, occasional vomiting, 
and right upper abdominal discomfort. He noticed his urine turned dark. 
Physical examination revealed a slightly enlarged and tender liver. Spleen was 
not palpable. No other pathology noticed.
Biological Tests: 
Hb: 
 
14.5 g/dL 
(12-18) 
WBC: 
 
7,900 cells/mm³ (4,500-11000) 
Total bilirubin: 
8.8 mg/dL 
(0.1-1.1) 
AST: 
 
820 U/L  
(0-35) 
ALT: 
 
730 U/L  
(6-45) 
Alk. Phos: 
226 U/L  
(45-115) 
Albumin: 
3.9 g/dL 
(3.5-5.5) 
HBs Ag:		
Pending
Ultrasound: 
Slightly enlarged homogeneous liver. The intrahepatic bile ducts were slightly 
dilated. The diameter of the common bile duct was 8 mm. No pathology was 
identified within the common bile duct. The spleen was smooth and of normal 
size.
ERCP was performed.
Comments: 
Becoming familiar with normal anatomy of the biliary system and pancreatic duct.
Fluoroscopic view
Case 1 


[TABLE]
|                                                                                |                                                                                  |           |
|:-------------------------------------------------------------------------------|:---------------------------------------------------------------------------------|:----------|
| 1                                                                              | Case 1                                                                           |           |
| Medical History:                                                               |                                                                                  |           |
|                                                                                | A 75-year-old male. One week ago he started with nausea, occasional vomiting,    |           |
|                                                                                | and right upper abdominal discomfort. He noticed his urine turned dark.          |           |
| Physical examination revealed a slightly enlarged and tender liver. Spleen was |                                                                                  |           |
| not palpable. No other pathology noticed.                                      |                                                                                  |           |
| Biological Tests:                                                              |                                                                                  |           |
| Hb:                                                                            | 14.5	g/dL                                                                                  | (12-18)   |
| WBC:                                                                           | 7,900	cells/mm³	 (4,500-11000)                                                                                  |           |
| Total	bilirubin:                                                                                | 8.8	mg/dL                                                                                  | (0.1-1.1) |
| AST:                                                                           | 820	U/L                                                                                  | (0-35)    |
| ALT:                                                                           | 730	U/L                                                                                  | (6-45)    |
| Alk.	Phos:                                                                                | 226	U/L                                                                                  | (45-115)  |
| Albumin:                                                                       | 3.9	g/dL                                                                                  | (3.5-5.5) |
| HBs Ag:                                                                        | Pending                                                                          |           |
| Ultrasound:                                                                    |                                                                                  |           |
|                                                                                | Slightly enlarged homogeneous liver. The intrahepatic bile ducts were slightly   |           |
|                                                                                | dilated.	The	diameter	of	the	common	bile	duct	was	8	mm.	No	pathology	was                                                                                  |           |
|                                                                                | identified within the common bile duct. The spleen was smooth and of normal      |           |
| size.                                                                          |                                                                                  |           |
| ERCP was performed.                                                            |                                                                                  |           |
| Comments:                                                                      |                                                                                  |           |
|                                                                                | Becoming familiar with normal anatomy of the biliary system and pancreatic duct. |           |

[OCR_TABLE]
be FPS
fF~L. I

[OCR]
First Module -
Endoscopic Retrograde
Cholangio-Pancreatography (ERCP) I

Case 1

Medical History:

A 75-year-old male. One week ago he started with nausea, occasional vomiting,
and right upper abdominal discomfort. He noticed his urine turned dark.
Physical examination revealed a slightly enlarged and tender liver. Spleen was
not palpable. No other pathology noticed.

Biological Tests:

Hb: 14.5 g/dL (12-18)

WBC: 7,900 cells/mm? (4,500-11000)
Total bilirubin: 8.8 mg/dL (0.1-1.1)

AST: 820 U/L (0-35)

ALT: 730 U/L (6-45)

Alk. Phos: 226 U/L (45-115)
Albumin: 3.9 g/dL (3.5-5.5)

HBs Ag: Pending

Ultrasound:

Slightly enlarged homogeneous liver. The intrahepatic bile ducts were slightly
dilated. The diameter of the common bile duct was 8 mm. No pathology was
identified within the common bile duct. The spleen was smooth and of normal
size.

ERCP was performed.

Comments:
Becoming familiar with normal anatomy of the biliary system and pancreatic duct.

Fluoroscopic view

*

surgical GI Mentor


# Page 3

First Module -
Endoscopic Retrograde 
Cholangio-Pancreatography (ERCP)
First Module -
3
GI Mentor
2
Medical History: 
A 57-year-old female who underwent cholecystectomy 8 months ago because 
of cholelithiasis. In the last four months, an itching sensation appeared, which 
increased in intensity. 
Physical examination revealed evidence of scratching over the skin. The sclera 
looked slightly yellowish. The liver was slightly enlarged.
Biological Tests: 
Total bilirubin: 
2.8 mg/dL 
(0.1-1.1) 
AST: 
 
68 U/L  
(0-35) 
ALT: 
 
72 U/L  
(6-45) 
Alk. Phos: 
720 U/L  
(45-115)
Ultrasound: 
Moderately dilated intrahepatic ducts. The common bile duct was of normal 
size.
ERCP was performed.
Comments: 
Identifying a benign stricture of the common bile duct. The stricture is the 
result of ligation of the cystic duct too close to the common bile duct.
Case 2 
Fluoroscopic view


[TABLE]
|                                                                                  |        |           |
|:---------------------------------------------------------------------------------|:-------|:----------|
| 2                                                                                | Case 2 |           |
| Medical History:                                                                 |        |           |
| A	57-year-old	female	who	underwent	cholecystectomy	8	months	ago	because                                                                                  |        |           |
| of cholelithiasis. In the last four months, an itching sensation appeared, which |        |           |
| increased in intensity.                                                          |        |           |
| Physical examination revealed evidence of scratching over the skin. The sclera   |        |           |
| looked slightly yellowish. The liver was slightly enlarged.                      |        |           |
| Biological Tests:                                                                |        |           |
| Total	bilirubin:                                                                                  | 2.8	mg/dL        | (0.1-1.1) |
| AST:                                                                             | 68	U/L        | (0-35)    |
| ALT:                                                                             | 72	U/L        | (6-45)    |
| Alk.	Phos:                                                                                  | 720	U/L        | (45-115)  |
| Ultrasound:                                                                      |        |           |
| Moderately dilated intrahepatic ducts. The common bile duct was of normal        |        |           |
| size.                                                                            |        |           |
| ERCP was performed.                                                              |        |           |
| Comments:                                                                        |        |           |
| Identifying a benign stricture of the common bile duct. The stricture is the     |        |           |
| result of ligation of the cystic duct too close to the common bile duct.         |        |           |

[OCR_TABLE]
bet IY
Ahal-

[OCR]
First Module -
Endoscopic Retrograde
Cholangio-Pancreatography (ERCP) I

Case 2

Medical History:

A 57-year-old female who underwent cholecystectomy 8 months ago because
of cholelithiasis. In the last four months, an itching sensation appeared, which
increased in intensity.

Physical examination revealed evidence of scratching over the skin. The sclera
looked slightly yellowish. The liver was slightly enlarged.

Biological Tests:

Total bilirubin: 2.8 mg/dL (0.1-1.1)

AST: 68 U/L (0-35)

ALT: 72 U/L (6-45)

Alk. Phos: 720 U/L (45-115)

Ultrasound:

Moderately dilated intrahepatic ducts. The common bile duct was of normal
size.

ERCP was performed.

Comments:
Identifying a benign stricture of the common bile duct. The stricture is the
result of ligation of the cystic duct too close to the common bile duct.

Fluoroscopic view

surgical GI Mentor


# Page 4

First Module -
Endoscopic Retrograde 
Cholangio-Pancreatography (ERCP)
First Module -
4
GI Mentor
3
Medical History: 
A 62-year-old male who was presented with painless jaundice and  
weight loss which started one month prior to his admission to the hospital.
Physical examination revealed an enlarged liver. Spleen is not palpable.
Biological Tests: 
Total bilirubin: 
15.2 mg/dL 
(0.1-1.1) 
AST: 
 
88 U/L  
(0-35) 
ALT: 
 
55 U/L  
(6-45) 
Alk. Phos: 
458 U/L  
(45-115)
Ultrasound: 
Dilated intrahepatic and extrahepatic ducts.
ERCP was performed.
Comments: 
Identify malignant stricture of the common bile duct. The pancreatic 
duct is normal and therefore the cause of the stricture is most probably 
cholangiocarcinoma.
Case 3
Fluoroscopic view


[TABLE]
|                                                                             |        |           |
|:----------------------------------------------------------------------------|:-------|:----------|
| 3                                                                           | Case 3 |           |
| Medical History:                                                            |        |           |
| A	62-year-old	male	who	was	presented	with	painless	jaundice	and                                                                             |        |           |
| weight loss which started one month prior to his admission to the hospital. |        |           |
| Physical examination revealed an enlarged liver. Spleen is not palpable.    |        |           |
| Biological Tests:                                                           |        |           |
| Total	bilirubin:                                                                             | 15.2	mg/dL        | (0.1-1.1) |
| AST:                                                                        | 88	U/L        | (0-35)    |
| ALT:                                                                        | 55	U/L        | (6-45)    |
| Alk.	Phos:                                                                             | 458	U/L        | (45-115)  |
| Ultrasound:                                                                 |        |           |
| Dilated intrahepatic and extrahepatic ducts.                                |        |           |
| ERCP was performed.                                                         |        |           |
| Comments:                                                                   |        |           |
| Identify malignant stricture of the common bile duct. The pancreatic        |        |           |
| duct is normal and therefore the cause of the stricture is most probably    |        |           |
| cholangiocarcinoma.                                                         |        |           |

[OCR]
First Module -
Endoscopic Retrograde
Cholangio-Pancreatography (ERCP) I

Case 3

Medical History:

A 62-year-old male who was presented with painless jaundice and

weight loss which started one month prior to his admission to the hospital.
Physical examination revealed an enlarged liver. Spleen is not palpable.

Biological Tests:

Total bilirubin: = 15.2 mg/dL (0.1-1.1)
AST: 88 U/L (0-35)
ALT: 55 U/L (6-45)
Alk. Phos: 458 U/L (45-115)
Ultrasound:

Dilated intrahepatic and extrahepatic ducts.
ERCP was performed.

Comments:

Identify malignant stricture of the common bile duct. The pancreatic
duct is normal and therefore the cause of the stricture is most probably
cholangiocarcinoma.

Fluoroscopic view

*

surgical GI Mentor


# Page 5

First Module -
Endoscopic Retrograde 
Cholangio-Pancreatography (ERCP)
First Module -
5
GI Mentor
4
Medical History: 
A 70-year-old female, who developed severe right upper quadrant pain 
following a fatty meal. The pain radiated to her back and right shoulder and 8 
hours later she developed chills and fever of 38.5°C. 
On her arrival she was found to be febrile and jaundiced. The pain subsided 
one hour later. 
Plain film of the abdomen revealed several distended loops of small intestine.
Biological Tests: 
WBC: 
 
 
11,200 cells/mm³ 
(4,500-11,000) 
Neutrophils: 
 
80% 
 
 
(<70) 
Hb: 
 
 
12.8 g/dL 
 
(12-18) 
Hct: 
 
 
43% 
 
 
(36-54) 
Total bilirubin: 
 
4.1 mg/dL 
 
(0.1-1.1) 
Conjugated bilirubin: 
3.0 mg/dL 
 
(0-0.2) 
AST: 
 
 
150 U/L  
 
(0-35) 
ALT: 
 
 
215 U/L  
 
(6-45) 
Alk. Phos: 
 
250 U/L  
 
(45-115) 
INR: 
 
 
1.1
Ultrasound: 
Gallbladder contained multiple small stones. The diameter of the common 
bile duct was 9 mm with a suspected impacted stone at the distal end of the 
common bile duct.
The patient was hospitalized and an ERCP was performed.
Comments: 
Clinical presentation of abdominal pain, fever, and jaundice lead to suspicion of 
cholangitis due to choledocholithiasis.
Case 4
Fluoroscopic view


[TABLE]
|                                                                                   |     |                |
|:----------------------------------------------------------------------------------|:----|:---------------|
| Case 4                                                                            |     |                |
| 4                                                                                 |     |                |
| Medical History:                                                                  |     |                |
| A 70-year-old female, who developed severe right upper quadrant pain              |     |                |
| following	a	fatty	meal.	The	pain	radiated	to	her	back	and	right	shoulder	and	8                                                                                   |     |                |
| hours	later	she	developed	chills	and	fever	of	38.5°C.                                                                                   |     |                |
| On her arrival she was found to be febrile and jaundiced. The pain subsided       |     |                |
| one hour later.                                                                   |     |                |
| Plain film of the abdomen revealed several distended loops of small intestine.    |     |                |
| Biological Tests:                                                                 |     |                |
| WBC:                                                                              | 11,200	cells/mm³     | (4,500-11,000) |
| Neutrophils:                                                                      | 80% | (<70)          |
| Hb:                                                                               | 12.8	g/dL     | (12-18)        |
| Hct:                                                                              | 43% | (36-54)        |
| Total	bilirubin:                                                                                   | 4.1	mg/dL     | (0.1-1.1)      |
| Conjugated	bilirubin:                                                                                   | 3.0	mg/dL     | (0-0.2)        |
| AST:                                                                              | 150	U/L     | (0-35)         |
| ALT:                                                                              | 215	U/L     | (6-45)         |
| Alk.	Phos:                                                                                   | 250	U/L     | (45-115)       |
| INR:                                                                              | 1.1 |                |
| Ultrasound:                                                                       |     |                |
| Gallbladder contained multiple small stones. The diameter of the common           |     |                |
| bile	duct	was	9	mm	with	a	suspected	impacted	stone	at	the	distal	end	of	the                                                                                   |     |                |
| common bile duct.                                                                 |     |                |
| The patient was hospitalized and an ERCP was performed.                           |     |                |
| Comments:                                                                         |     |                |
| Clinical presentation of abdominal pain, fever, and jaundice lead to suspicion of |     |                |
| cholangitis due to choledocholithiasis.                                           |     |                |

[OCR_TABLE]
Chol

[OCR]
First Module -
Endoscopic Retrograde
Cholangio-Pancreatography (ERCP) I

Case 4

Medical History:

A 70-year-old female, who developed severe right upper quadrant pain
following a fatty meal. The pain radiated to her back and right shoulder and 8
hours later she developed chills and fever of 38.5°C.

On her arrival she was found to be febrile and jaundiced. The pain subsided
one hour later.

Plain film of the abdomen revealed several distended loops of small intestine.

Biological Tests:

WBC: 1,200 cells/mm? (4,500-11,000)
Neutrophils: 80% (<70)
Hb: 2.8 g/dL (12-18)
Het: 43% (36-54)
Total bilirubin: 4.1 mg/dL (0.1-1.1)
Conjugated bilirubin: 3.0 mg/dL (0-0.2)
AST: 50 U/L (0-35)
ALT: 215 U/L (6-45)
Alk. Phos: 250 U/L (45-115)
INR: “1

Ultrasound:

Gallbladder contained multiple small stones. The diameter of the common
bile duct was 9 mm with a suspected impacted stone at the distal end of the
common bile duct.

The patient was hospitalized and an ERCP was performed.

Comments:
Clinical presentation of abdominal pain, fever, and jaundice lead to suspicion of
cholangitis due to choledocholithiasis.

Fluoroscopic view

surgical GI Mentor


# Page 6

First Module -
Endoscopic Retrograde 
Cholangio-Pancreatography (ERCP)
First Module -
6
GI Mentor
5
Medical History: 
A 58-year-old man was admitted to the hospital because of weakness. In the 
last week, he noticed his urine turned dark.
Biological Tests: 
Hb: 
 
10 g/dL  
(12-18) 
MCV: 
 
72 fl 
 
(86-98) 
MCH: 
 
24 pg/cell 
(28-33) 
Total bilirubin: 
2.5 mg/dL 
(0.1-1.1) 
Alk. Phos: 
410 U/L  
(45-115) 
AST: 
 
92 U/L  
(0-35) 
ALT: 
 
75 U/L  
(6-45)
Ultrasound: 
Dilatation of the entire biliary system was seen. The pancreatic duct was 
dilated as well (5 mm).
ERCP was performed.
Comments: 
Cancer of the papilla of Vater is associated with anemia and abnormal liver 
function tests.
Case 5
Fluoroscopic view


[TABLE]
|                                                                             |        |           |
|:----------------------------------------------------------------------------|:-------|:----------|
| 5                                                                           | Case 5 |           |
| Medical History:                                                            |        |           |
|                                                                             | A	58-year-old	man	was	admitted	to	the	hospital	because	of	weakness.	In	the        |           |
| last week, he noticed his urine turned dark.                                |        |           |
| Biological Tests:                                                           |        |           |
| Hb:                                                                         | 10	g/dL        | (12-18)   |
| MCV:                                                                        | 72	fl        | (86-98)   |
| MCH:                                                                        | 24	pg/cell        | (28-33)   |
| Total	bilirubin:                                                                             | 2.5	mg/dL        | (0.1-1.1) |
| Alk.	Phos:                                                                             | 410	U/L        | (45-115)  |
| AST:                                                                        | 92	U/L        | (0-35)    |
| ALT:                                                                        | 75	U/L        | (6-45)    |
| Ultrasound:                                                                 |        |           |
| Dilatation of the entire biliary system was seen. The pancreatic duct was   |        |           |
| dilated	as	well	(5	mm).                                                                             |        |           |
| ERCP was performed.                                                         |        |           |
| Comments:                                                                   |        |           |
| Cancer of the papilla of Vater is associated with anemia and abnormal liver |        |           |
| function tests.                                                             |        |           |

[OCR]
First Module -
Endoscopic Retrograde
Cholangio-Pancreatography (ERCP) I

Case 5

Medical History:
A 58-year-old man was admitted to the hospital because of weakness. In the
last week, he noticed his urine turned dark.

Biological Tests:

Hb: 10 g/dL (12-18)
MCV: 72 fl (86-98)
MCH: 24 pg/cell (28-33)
Total bilirubin: 2.5 mg/dL (0.1-1.1)
Alk. Phos: 410 U/L (45-115)
AST: 92 U/L (0-35)
ALT: 75 U/L (6-45)
Ultrasound:

Dilatation of the entire biliary system was seen. The pancreatic duct was
dilated as well (5 mm).

ERCP was performed.

Comments:
Cancer of the papilla of Vater is associated with anemia and abnormal liver
function tests.

Fluoroscopic view

*

surgical GI Mentor


# Page 7

First Module -
Endoscopic Retrograde 
Cholangio-Pancreatography (ERCP)
First Module -
7
GI Mentor
6
Medical History: 
A 93-year-old female presented to her physician because of painless jaundice.
Biological Tests: 
Total bilirubin: 
 
6.0 mg/dL 
(0.1-1.1) 
Conjugated bilirubin: 
4.5 mg/dL 
(0.0-0.2) 
AST: 
 
 
15 U/L  
(0-35) 
ALT: 
 
 
21 U/L  
(6-45) 
Alk. Phos: 
 
450 U/L  
(45-115)
Ultrasound: 
An irregular hyperechoic mass 1.8 x 2.5 cm was seen in the head of the 
pancreas. The common bile duct is 12 mm in size, and the intrahepatic ducts 
are dilated.
Endoscopic Ultrasound: 
Hyperechoic mass in the head of the pancreas 2.1 x 2.8 cm in size. There is 
invasion into the splenic vein. Lymph nodes are of normal size.
Comments: 
Painless jaundice in an elderly woman led to suspicion of pancreatic cancer. 
Prognosis is bad, and palliative drainage is recommended.
Case 6
Fluoroscopic view


[TABLE]
|                                                                              |    |           |
|:-----------------------------------------------------------------------------|:---|:----------|
| Case 6                                                                       |    |           |
| 6                                                                            |    |           |
| Medical History:                                                             |    |           |
| A	93-year-old	female	presented	to	her	physician	because	of	painless	jaundice.                                                                              |    |           |
| Biological Tests:                                                            |    |           |
| Total	bilirubin:                                                                              | 6.0	mg/dL    | (0.1-1.1) |
| Conjugated	bilirubin:                                                                              | 4.5	mg/dL    | (0.0-0.2) |
| AST:                                                                         | 15	U/L    | (0-35)    |
| ALT:                                                                         | 21	U/L    | (6-45)    |
| Alk.	Phos:                                                                              | 450	U/L    | (45-115)  |
| Ultrasound:                                                                  |    |           |
| An	irregular	hyperechoic	mass	1.8	x	2.5	cm	was	seen	in	the	head	of	the                                                                              |    |           |
| pancreas.	The	common	bile	duct	is	12	mm	in	size,	and	the	intrahepatic	ducts                                                                              |    |           |
| are dilated.                                                                 |    |           |
| Endoscopic Ultrasound:                                                       |    |           |
| Hyperechoic	mass	in	the	head	of	the	pancreas	2.1	x	2.8	cm	in	size.	There	is                                                                              |    |           |
| invasion into the splenic vein. Lymph nodes are of normal size.              |    |           |
| Comments:                                                                    |    |           |
| Painless jaundice in an elderly woman led to suspicion of pancreatic cancer. |    |           |
| Prognosis is bad, and palliative drainage is recommended.                    |    |           |

[OCR]
First Module -
Endoscopic Retrograde
Cholangio-Pancreatography (ERCP) I

Case 6

Medical History:
A 93-year-old female presented to her physician because of painless jaundice.

Biological Tests:

Total bilirubin: 6.0 mg/dL (0.1-1.1)
Conjugated bilirubin: 4.5 mg/dL (0.0-0.2)
AST: 15 U/L (0-35)
ALT: 21 U/L (6-45)
Alk. Phos: 450 U/L (45-115)
Ultrasound:

An irregular hyperechoic mass 1.8 x 2.5 cm was seen in the head of the
pancreas. The common bile duct is 12 mm in size, and the intrahepatic ducts
are dilated.

Endoscopic Ultrasound:
Hyperechoic mass in the head of the pancreas 2.1 x 2.8 cm in size. There is
invasion into the splenic vein. Lymph nodes are of normal size.

Comments:
Painless jaundice in an elderly woman led to suspicion of pancreatic cancer.
Prognosis is bad, and palliative drainage is recommended.

Fluoroscopic view

surgical GI Mentor


# Page 8

First Module -
Endoscopic Retrograde 
Cholangio-Pancreatography (ERCP)
First Module -
8
GI Mentor
7
Medical History: 
An 87-year-old lady was admitted to the emergency room because of several 
bouts of right upper quadrant pain with radiation to the right shoulder. 
Two days prior to her admission, she noticed her urine turned dark. On her 
admission, she was jaundiced and developed shaking chills and fever.
Biological Tests: 
WBC: 
 
 
16,000 cells/mm³ 
(4,500-11,000) 
Neutrophils: 
 
90% 
 
 
(<70) 
Total bilirubin: 
 
10.5 mg/dL 
 
(0.1-1.1) 
Conjugated bilirubin: 
7.5 mg/dL 
 
(0-0.2) 
AST: 
 
 
150 U/L  
 
(0-35) 
ALT: 
 
 
425 U/L  
 
(6-45) 
Alk. Phos: 
 
550 U/L  
 
(45-115) 
INR: 
 
 
1.1 
Platelets: 
 
250,000 cells/mm³ (130,000-440,000)
Ultrasound: 
Dilated common bile duct with one large hyperechoic lesion (20 mm). The 
gallbladder contained multiple stones. The gallbladder wall was of normal size.
With a working diagnosis of acute cholangitis, IV parenteral antibiotics were 
initiated, and ERCP was performed.
Comments: 
A large stone in the common bile duct. Such a stone has to undergo 
mechanical lithotripsy before extraction.
Case 7
Fluoroscopic view


[TABLE]
|                                                                            |                                                                                 |                |
|:---------------------------------------------------------------------------|:--------------------------------------------------------------------------------|:---------------|
| Case 7                                                                     |                                                                                 |                |
| 7                                                                          |                                                                                 |                |
| Medical History:                                                           |                                                                                 |                |
| An	87-year-old	lady	was	admitted	to	the	emergency	room	because	of	several                                                                            |                                                                                 |                |
| bouts of right upper quadrant pain with radiation to the right shoulder.   |                                                                                 |                |
| Two days prior to her admission, she noticed her urine turned dark. On her |                                                                                 |                |
| admission, she was jaundiced and developed shaking chills and fever.       |                                                                                 |                |
| Biological Tests:                                                          |                                                                                 |                |
| WBC:                                                                       | 16,000	cells/mm³                                                                                 | (4,500-11,000) |
| Neutrophils:                                                               | 90%                                                                             | (<70)          |
| Total	bilirubin:                                                                            | 10.5	mg/dL                                                                                 | (0.1-1.1)      |
| Conjugated	bilirubin:                                                                            | 7.5	mg/dL                                                                                 | (0-0.2)        |
| AST:                                                                       | 150	U/L                                                                                 | (0-35)         |
| ALT:                                                                       | 425	U/L                                                                                 | (6-45)         |
| Alk.	Phos:                                                                            | 550	U/L                                                                                 | (45-115)       |
| INR:                                                                       | 1.1                                                                             |                |
| Platelets:                                                                 | 250,000	cells/mm³	(130,000-440,000)                                                                                 |                |
| Ultrasound:                                                                |                                                                                 |                |
| Dilated	common	bile	duct	with	one	large	hyperechoic	lesion	(20	mm).	The                                                                            |                                                                                 |                |
|                                                                            | gallbladder contained multiple stones. The gallbladder wall was of normal size. |                |
|                                                                            | With a working diagnosis of acute cholangitis, IV parenteral antibiotics were   |                |
| initiated, and ERCP was performed.                                         |                                                                                 |                |
| Comments:                                                                  |                                                                                 |                |
|                                                                            | A large stone in the common bile duct. Such a stone has to undergo              |                |
| mechanical lithotripsy before extraction.                                  |                                                                                 |                |

[OCR_TABLE]
ben FEE
fF~L. I

[OCR_TABLE]
wil

[OCR]
First Module -
Endoscopic Retrograde
Cholangio-Pancreatography (ERCP) I

Case 7

Medical History:

An 87-year-old lady was admitted to the emergency room because of several
bouts of right upper quadrant pain with radiation to the right shoulder.

Two days prior to her admission, she noticed her urine turned dark. On her
admission, she was jaundiced and developed shaking chills and fever.

Biological Tests:

WBC: 16,000 cells/mm? (4,500-11,000)
Neutrophils: 90% (<70)

Total bilirubin: 10.5 mg/dL (0.1-1.1)

Conjugated bilirubin: 7.5 mg/dL (0-0.2)

AST: 150 U/L (0-35)

ALT: 425 U/L (6-45)

Alk. Phos: 550 U/L (45-115)

INR: 1.1

Platelets: 250,000 cells/mm* (130,000-440,000)
Ultrasound:

Dilated common bile duct with one large hyperechoic lesion (20 mm). The
gallbladder contained multiple stones. The gallbladder wall was of normal size.

With a working diagnosis of acute cholangitis, |V parenteral antibiotics were
initiated, and ERCP was performed.

Comments:
A large stone in the common bile duct. Such a stone has to undergo
mechanical lithotripsy before extraction.

Fluoroscopic view

surgical GI Mentor


# Page 9

First Module -
Endoscopic Retrograde 
Cholangio-Pancreatography (ERCP)
First Module -
9
GI Mentor
8
Medical History: 
A 58-year-old lady underwent a cholecystectomy 3 days ago. Surgery was 
difficult, and it had to be converted from laparoscopic to open cholecystectomy. 
She complained of right upper quadrant discomfort and abdominal distention. 
There is an increased drainage of bile from a drain located at the bed of the 
gallbladder.
Biological Tests: 
Total bilirubin: 
2.5 mg/dL 
(0.1-1.1) 
AST: 
 
42 U/L  
(0-35) 
ALT: 
 
95 U/L  
(6-45) 
Alk. Phos: 
300 U/L  
(45-115)
Ultrasound: 
Collection of fluid adjacent to the liver.
ERCP was performed.
Comments: 
The cholecystectomy was complicated and therefore had to be converted to 
an open one. In such a case, injury to the common bile duct is more likely. In 
this case, complete transection of the common bile duct had occurred.
Case 8
Fluoroscopic view


[TABLE]
|                     |                                                                                  |           |
|:--------------------|:---------------------------------------------------------------------------------|:----------|
| 8                   | Case 8                                                                           |           |
| Medical History:    |                                                                                  |           |
| A	58-year-old	lady	underwent	a	cholecystectomy	3	days	ago.	Surgery	was                     |                                                                                  |           |
|                     | difficult, and it had to be converted from laparoscopic to open cholecystectomy. |           |
|                     | She complained of right upper quadrant discomfort and abdominal distention.      |           |
|                     | There is an increased drainage of bile from a drain located at the bed of the    |           |
| gallbladder.        |                                                                                  |           |
| Biological Tests:   |                                                                                  |           |
| Total	bilirubin:                     | 2.5	mg/dL                                                                                  | (0.1-1.1) |
| AST:                | 42	U/L                                                                                  | (0-35)    |
| ALT:                | 95	U/L                                                                                  | (6-45)    |
| Alk.	Phos:                     | 300	U/L                                                                                  | (45-115)  |
| Ultrasound:         |                                                                                  |           |
|                     | Collection of fluid adjacent to the liver.                                       |           |
| ERCP was performed. |                                                                                  |           |
| Comments:           |                                                                                  |           |
|                     | The cholecystectomy was complicated and therefore had to be converted to         |           |
|                     | an open one. In such a case, injury to the common bile duct is more likely. In   |           |
|                     | this case, complete transection of the common bile duct had occurred.            |           |

[OCR_TABLE]
Bet PUY

[OCR]
First Module -
Endoscopic Retrograde
Cholangio-Pancreatography (ERCP) I

Case 8

Medical History:

A 58-year-old lady underwent a cholecystectomy 3 days ago. Surgery was
difficult, and it had to be converted from laparoscopic to open cholecystectomy.
She complained of right upper quadrant discomfort and abdominal distention.
There is an increased drainage of bile from a drain located at the bed of the

gallbladder.

Biological Tests:

Total bilirubin: 2.5 mg/dL (0.1-1.1)
AST: 42 U/L (0-35)
ALT: 95 U/L (6-45)
Alk. Phos: 300 U/L (45-115)
Ultrasound:

Collection of fluid adjacent to the liver.
ERCP was performed.

Comments:

The cholecystectomy was complicated and therefore had to be converted to
an open one. In such a case, injury to the common bile duct is more likely. In
this case, complete transection of the common bile duct had occurred.

Fluoroscopic view

*

surgical GI Mentor


# Page 10

First Module -
Endoscopic Retrograde 
Cholangio-Pancreatography (ERCP)
First Module -
10
GI Mentor
9
Medical History: 
A 49-year-old female with cholecystolithiasis. She underwent cholecystectomy 
4 days ago. She complained of right upper quadrant abdominal discomfort. 
She also realized that her abdomen became swollen. Physical examination 
revealed tenderness in the right upper abdomen.
Biological Tests: 
Total bilirubin: 
2.1 mg/dL 
(0.1-1.1) 
AST: 
 
43 U/L  
(0-35) 
ALT: 
 
51 U/L  
(6-45) 
Alk. Phos: 
127 U/L  
(45-115)
Ultrasound: 
Collection of fluid in the bed of the gallbladder. The intrahepatic and 
extrahepatic ducts are not dilated.
ERCP was performed.
Comments: 
There was a leak of contrast material from the cystic stump; otherwise, the 
entire biliary system looks normal. Small sphincterotomy was performed, and 
a stent was inserted. Six weeks later, the stent was removed, and injection 
of contrast material during ERCP did not show any leak of bile. This case 
demonstrates a bile leak from the cystic duct following cholecystectomy.
It is because the clip, which was left on the cystic duct, fell down. Treatment is 
endoscopic sphincterotomy with or without stent insertion.
Case 9
Fluoroscopic view


[TABLE]
|                                                                                    |        |           |
|:-----------------------------------------------------------------------------------|:-------|:----------|
| 9                                                                                  | Case 9 |           |
| Medical History:                                                                   |        |           |
|                                                                                    | A	49-year-old	female	with	cholecystolithiasis.	She	underwent	cholecystectomy        |           |
| 4 days ago. She complained of right upper quadrant abdominal discomfort.           |        |           |
| She also realized that her abdomen became swollen. Physical examination            |        |           |
| revealed tenderness in the right upper abdomen.                                    |        |           |
| Biological Tests:                                                                  |        |           |
| Total	bilirubin:                                                                                    | 2.1	mg/dL        | (0.1-1.1) |
| AST:                                                                               | 43	U/L        | (0-35)    |
| ALT:                                                                               | 51	U/L        | (6-45)    |
| Alk.	Phos:                                                                                    | 127	U/L        | (45-115)  |
| Ultrasound:                                                                        |        |           |
| Collection of fluid in the bed of the gallbladder. The intrahepatic and            |        |           |
| extrahepatic ducts are not dilated.                                                |        |           |
| ERCP was performed.                                                                |        |           |
| Comments:                                                                          |        |           |
| There was a leak of contrast material from the cystic stump; otherwise, the        |        |           |
| entire biliary system looks normal. Small sphincterotomy was performed, and        |        |           |
| a stent was inserted. Six weeks later, the stent was removed, and injection        |        |           |
| of contrast material during ERCP did not show any leak of bile. This case          |        |           |
| demonstrates a bile leak from the cystic duct following cholecystectomy.           |        |           |
| It is because the clip, which was left on the cystic duct, fell down. Treatment is |        |           |
| endoscopic sphincterotomy with or without stent insertion.                         |        |           |

[OCR_TABLE]
ben FEE
fF~L. 1.

[OCR]
First Module -
Endoscopic Retrograde
Cholangio-Pancreatography (ERCP) I

Case 9

Medical History:

A 49-year-old female with cholecystolithiasis. She underwent cholecystectomy
4 days ago. She complained of right upper quadrant abdominal discomfort.
She also realized that her abdomen became swollen. Physical examination
revealed tenderness in the right upper abdomen.

Biological Tests:

Total bilirubin: 2.1 mg/dL (0.1-1.1)
AST: 43 U/L (0-35)
ALT: 51 U/L (6-45)
Alk. Phos: 127 U/L (45-115)
Ultrasound:

Collection of fluid in the bed of the gallbladder. The intrahepatic and
extrahepatic ducts are not dilated.

ERCP was performed.

Comments:

There was a leak of contrast material from the cystic stump; otherwise, the
entire biliary system looks normal. Small sphincterotomy was performed, and
a stent was inserted. Six weeks later, the stent was removed, and injection
of contrast material during ERCP did not show any leak of bile. This case
demonstrates a bile leak from the cystic duct following cholecystectomy.

It is because the clip, which was left on the cystic duct, fell down. Treatment is
endoscopic sphincterotomy with or without stent insertion.

Fluoroscopic view

surgical GI Mentor


# Page 11

First Module -
Endoscopic Retrograde 
Cholangio-Pancreatography (ERCP)
First Module -
11
GI Mentor
10
Medical History: 
A 76-year-old lady underwent laparoscopic cholecystectomy one year ago. The 
pathological examination revealed a small mucous-secreting adenocarcinoma of 
the gallbladder. At present time she noticed that she became jaundiced and her 
urine turned dark.
Biological Tests: 
Total bilirubin: 
 
5.0 mg/dL 
(0.1-1.1) 
Conjugated bilirubin: 
3.2 mg/dL 
(0-0.2) 
AST: 
 
 
15 U/L  
(0-35) 
ALT: 
 
 
65 U/L  
(6-45) 
Alk. Phos: 
 
700 U/L  
(45-115)
Ultrasound: 
Intrahepatic bile ducts in the right lobe of the liver were dilated. There was a 
mass at the hilum of the liver.
ERCP was performed.
Comments: 
Adenocarcinoma of the gallbladder is a highly malignant tumor. Excision of the 
gallbladder does not solve the problem for most patients.
There is a possibility, like in this case, of obstruction of the biliary drainage to 
one lobe of the liver only. In this case, drainage of the right lobe of the liver is 
impaired.
Case 10
Fluoroscopic view


[TABLE]
|                                 |                                                                                      |           |
|:--------------------------------|:-------------------------------------------------------------------------------------|:----------|
| Case 10                         |                                                                                      |           |
| 10                              |                                                                                      |           |
| Medical History:                |                                                                                      |           |
| A	76-year-old	lady	underwent	laparoscopic	cholecystectomy	one	year	ago.	The                                 |                                                                                      |           |
|                                 | pathological examination revealed a small mucous-secreting adenocarcinoma of         |           |
|                                 | the gallbladder. At present time she noticed that she became jaundiced and her       |           |
| urine turned dark.              |                                                                                      |           |
| Biological Tests:               |                                                                                      |           |
| Total	bilirubin:                                 | 5.0	mg/dL                                                                                      | (0.1-1.1) |
| Conjugated	bilirubin:                                 | 3.2	mg/dL                                                                                      | (0-0.2)   |
| AST:                            | 15	U/L                                                                                      | (0-35)    |
| ALT:                            | 65	U/L                                                                                      | (6-45)    |
| Alk.	Phos:                                 | 700	U/L                                                                                      | (45-115)  |
| Ultrasound:                     |                                                                                      |           |
|                                 | Intrahepatic bile ducts in the right lobe of the liver were dilated. There was a     |           |
| mass at the hilum of the liver. |                                                                                      |           |
| ERCP was performed.             |                                                                                      |           |
| Comments:                       |                                                                                      |           |
|                                 | Adenocarcinoma of the gallbladder is a highly malignant tumor. Excision of the       |           |
|                                 | gallbladder does not solve the problem for most patients.                            |           |
|                                 | There is a possibility, like in this case, of obstruction of the biliary drainage to |           |
|                                 | one lobe of the liver only. In this case, drainage of the right lobe of the liver is |           |
| impaired.                       |                                                                                      |           |

[OCR_TABLE]
be FI
fF~L. I

[OCR]
First Module -
Endoscopic Retrograde
Cholangio-Pancreatography (ERCP) I

Case 10

Medical History:
A 76-year-old lady underwent laparoscopic cholecystectomy one year ago. The
pathological examination revealed a small mucous-secreting adenocarcinoma of
the gallbladder. At present time she noticed that she became jaundiced and her
urine turned dark.

Biological Tests:

Total bilirubin: 5.0 mg/dL (0.1-1.1)
Conjugated bilirubin: 3.2 mg/dL (0-0.2)
AST: 15 U/L (0-35)
ALT: 65 U/L (6-45)
Alk. Phos: 700 U/L (45-115)
Ultrasound:

Intrahepatic bile ducts in the right lobe of the liver were dilated. There was a
mass at the hilum of the liver.

ERCP was performed.

Comments:
Adenocarcinoma of the gallbladder is a highly malignant tumor. Excision of the
gallbladder does not solve the problem for most patients.

There is a possibility, like in this case, of obstruction of the biliary drainage to
one lobe of the liver only. In this case, drainage of the right lobe of the liver is
impaired.

Fluoroscopic view

surgical GI Mentor